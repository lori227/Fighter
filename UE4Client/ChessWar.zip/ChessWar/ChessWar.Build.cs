﻿// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;

public class ChessWar : ModuleRules
{
    public ChessWar(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicIncludePaths.AddRange(
            new string[] 
            {
                "ChessWar/Public"
            }
        );
        PrivateIncludePaths.AddRange(
            new string[]
            {
                "ChessWar/Private"
            }
        );

        PublicDependencyModuleNames.AddRange(
            new string[] {
                "Core", "CoreUObject", "Engine", "InputCore",

                "Slate", "SlateCore", "MoviePlayer", "ApexDestruction",

                "SLoadingScreen", "AkAudio", "slua_unreal",  "HTTP", "Json",

                "PakFile", "Sockets", "Networking", "libprotobuf"
            }
        );
        PrivateDependencyModuleNames.AddRange(
            new string[] 
            {
                "DungeonArchitectRuntime"
            }
        );

        PrivateIncludePathModuleNames.AddRange(
            new string[]
            {
                "DungeonArchitectRuntime"
            }
        );

        bEnableShadowVariableWarnings = false;
        bEnableUndefinedIdentifierWarnings = false;
        bEnableExceptions = true;
    }
}
