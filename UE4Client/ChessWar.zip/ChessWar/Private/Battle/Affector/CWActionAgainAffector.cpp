#include "CWActionAgainAffector.h"
#include "CWCommonUtil.h"
#include "CWAffectorDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWBuff.h"
#include "CWBuffManager.h"
#include "CWPawn.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattleCalculate.h"
#include "CWGameInstance.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWActionAgainAffector, All, All);


//UCWActionAgainAffector::UCWActionAgainAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

UCWActionAgainAffector::UCWActionAgainAffector()
{
	AffectorType = ECWAffectorType::ActionAgain;
}

UCWActionAgainAffector::~UCWActionAgainAffector()
{
	OnAffectorEnd();
}


bool UCWActionAgainAffector::OnAffect()
{
	return true;
}

bool UCWActionAgainAffector::OnAffectorBegin()
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* TempPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnBattlePropertComponent = TempPawn->GetBattleProperty();
	check(TempPawnBattlePropertComponent);

	//服务器才处理
	if (!TempPawn->IsInServer())
		return false;

	//角色是否已死
	if (TempPawn->IsDieOrDeath())
		return true;

	if (ArrayAffectorParams.Num() < 2)
	{
		UE_LOG(LogCWActionAgainAffector, Error, TEXT("UCWActionAgainAffector::OnAffectorBegin ArrayAffectorParams.Num() < 2, ArrayAffectorParams.Num():%d."), ArrayAffectorParams.Num());
		return false;
	}
	
	uint8  TempInstructs = (uint8)ArrayAffectorParams[0];
	int32  TempCount = (int32)ArrayAffectorParams[1];
	TempInstructs |= (uint8)ECWInstructType::Defence;
	TempInstructs |= (uint8)ECWInstructType::Await;
	uint8 NewInstructs = 0xff;

	NewInstructs &= ~TempInstructs;

	TSharedPtr<UCWCastSkillContext> CasterSkillContext = ParantBuff->GetCastSkillContext();
	const int32 CasterSkillId = CasterSkillContext.IsValid() ? CasterSkillContext->CastSkillDataStruct->SkillId : INDEX_NONE;

	TempPawn->AddInstructs(
		NewInstructs,
		false,
		(int32)TempPawn->GetCampTag(),
		(int32)TempPawn->GetCampControllerIndex(),
		(int32)TempPawn->GetControllerPawnIndex(),
		CasterSkillId,
		ParantBuff->GetBuffId(),
		ParantBuff->GetBuffUniqueId(),
		this->GetAffectorId());

	return true;
}

bool UCWActionAgainAffector::OnAffectorEnd()
{
	return true;
}
