
#include "CWAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWCastSkillContext.h"
#include "CWBattlePropertySet.h"
#include "CWAffectorDataStruct.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWAffector, All, All);

//UCWAffector::UCWAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

UCWAffector::UCWAffector()
{
	ParantBuff = nullptr;
	CastSkillContextPtr = nullptr;
	AffectorType = ECWAffectorType::None;
	AffectorId = 0;
	AffectorSubType = 0;
	AffectorOperationType = 0;
	AffectorDataAffectType = 0;
	AffectorDataAffectKeyTimeType = 0;
	AffectorLimitDistanceType = 0;
}

UCWAffector::~UCWAffector()
{
	OnAffectorEnd();
}

bool UCWAffector::Init(UCWBuff* ParamParantBuff, int ParamAffetorId, TSharedPtr<UCWCastSkillContext> ParamCastSkillContextPtr)
{
	check(ParamParantBuff);

	ParantBuff = ParamParantBuff;
	AffectorId = ParamAffetorId;
	CastSkillContextPtr = ParamCastSkillContextPtr;

	return true;
}


int32 UCWAffector::GetAffectorId() const
{
	return AffectorId;
}

const FCWAffectorDataStruct* UCWAffector::GetAffectorDataStruct() const
{
	FCWAffectorDataStruct* TempAffectorData = FCWCommonUtil::FindCSVRow<FCWAffectorDataStruct>(TEXT("CWAffectorDataTable"), AffectorId);
	if (TempAffectorData == nullptr)
	{
		UE_LOG(LogCWAffector, Error, TEXT("UCWAffector::GetAffectorDataStruct, TempAffectorData == nullptr, AffectorId:%d."), AffectorId);
		return nullptr;
	}
	return TempAffectorData;
}

void UCWAffector::SetAffectorSubType(int32 ParamAffectorSubType)
{
	AffectorSubType = ParamAffectorSubType;
}

int32 UCWAffector::GetAffectorSubType() const
{
	return AffectorSubType;
}


void UCWAffector::SetAffectorOperationType(int32 ParamAffectorOperationType)
{
	AffectorOperationType = ParamAffectorOperationType;
}


int32 UCWAffector::GetAffectorOperationType() const
{
	return AffectorOperationType;
}


void UCWAffector::SetArrayAffectorParams(const std::vector<float>& ParamArrayAffectorParams)
{
	ArrayAffectorParams.Empty();
	for (std::vector<float>::const_iterator iter = ParamArrayAffectorParams.begin(); iter != ParamArrayAffectorParams.end(); ++iter)
	{
		ArrayAffectorParams.Add(*iter);
	}
}


void UCWAffector::SetAffectorDataAffectType(int32 ParamAffectorDataAffectType)
{
	AffectorDataAffectType = ParamAffectorDataAffectType;
}

int32 UCWAffector::GetAffectorDataAffectType()
{
	return AffectorDataAffectType;
}

void UCWAffector::SetAffectorDataAffectKeyTimeType(int32 ParamAffectorDataAffectKeyTimeType)
{
	AffectorDataAffectKeyTimeType = ParamAffectorDataAffectKeyTimeType;
}

int32 UCWAffector::GetAffectorDataAffectKeyTimeType()
{
	return AffectorDataAffectKeyTimeType;
}

bool UCWAffector::OnAffect()
{
	return true;
}

bool UCWAffector::OnAffectorBegin()
{
	return true;
}

bool UCWAffector::OnAffectorEnd()
{
	return true;
}

bool UCWAffector::IsAffectInKeyTime(ECWKeyTimeType ParamKeyTimeType)
{
	if ((ECWPropertyAffectorDataAffectType)AffectorDataAffectType == ECWPropertyAffectorDataAffectType::Persistent)
	{
		return false;
	}
	else if ((ECWPropertyAffectorDataAffectType)AffectorDataAffectType == ECWPropertyAffectorDataAffectType::InstantInKeyTime)
	{
		if (ParantBuff->IsSameKeyTime((ECWKeyTimeType)AffectorDataAffectKeyTimeType, ParamKeyTimeType))
		{
			return true;
		}
	}

	return false;
}

bool UCWAffector::IsFinishInKeyTime(ECWKeyTimeType ParamKeyTimeType)
{
	return false;
}

bool UCWAffector::RemoveAffectorDataFromArrayPropertyAffectorData(int ParamAffectorId, int ParamBuffId, int ParamBuffUniqueId)
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* TempPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnBattlePropertComponent = TempPawn->GetBattleProperty();
	check(TempPawnBattlePropertComponent);

	TArray<FCWBattlePropertyAffectorData>& TempArray = TempPawnBattlePropertComponent->GetArrayPropertyAffectorData();
	TempArray.RemoveAll(
		[&](FCWBattlePropertyAffectorData& Element) -> bool
		{
			return (/*Element.SouceType == ECWPropertyAffectorDataSouceType::Buff &&*/
				Element.SourceTypeId == ParamBuffId &&
				Element.SourceUniqueId == ParamBuffUniqueId &&
				Element.SourceCustomParam1 == ParamAffectorId);
		}
	);

	return true;
}

bool UCWAffector::AddAffectorDataFromArrayPropertyAffectorData(const FCWBattlePropertyAffectorData& ParamAffectorData)
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* TempPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnBattlePropertComponent = TempPawn->GetBattleProperty();
	check(TempPawnBattlePropertComponent);

	TArray<FCWBattlePropertyAffectorData>& TempArray = TempPawnBattlePropertComponent->GetArrayPropertyAffectorData();
	TempArray.Add(ParamAffectorData);

	return true;
}

bool UCWAffector::IsAffectorType(const ECWAffectorType InAffectorType)
{
	return AffectorType != ECWAffectorType::None && InAffectorType != ECWAffectorType::None && AffectorType == InAffectorType;
}

void UCWAffector::SetAffectorLimitDistanceType(uint8 InTypeValue)
{

}

bool UCWAffector::IsValidParamsWithModifyOp(const ECWBattlePropertyModifyOp InModifyOpType, const int32 InParamsSize)
{
	bool bIsValidParams = false;
	switch (InModifyOpType)
	{
	case ECWBattlePropertyModifyOp::Add_Param1:
	{
		bIsValidParams = (InParamsSize >= 1);
	}break;
	case ECWBattlePropertyModifyOp::Base_Multiply_Param1_Add_Param2:
	case ECWBattlePropertyModifyOp::Base_Multiply_Param1_ClampMax_Param2:
	{
		bIsValidParams = (InParamsSize >= 2);
	}break;
	}

	if (!bIsValidParams)
	{
		CWG_ERROR(">> BattlePropertyModifyAffector::IsValidParamsWithModifyOp, ModifyOpType[%s] InParamsSize[%d] NoImplementation/ParamsError.",
			*FCWCommonUtil::EnumToString(TEXT("ECWBattlePropertyModifyOp"), InModifyOpType), InParamsSize);
	}
	return bIsValidParams;
}

