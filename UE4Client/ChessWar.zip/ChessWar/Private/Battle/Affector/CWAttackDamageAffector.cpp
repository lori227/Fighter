
#include "CWAttackDamageAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWGameInstance.h"
#include "CWBattleCalculate.h"
#include "CWBattleCalculate.h"
#include "CWCastSkillContext.h"
#include "CWBattlePropertySet.h"
#include "CWAffectorDataStruct.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWAttackDamageAffector, All, All);


//UCWAttackDamageAffector::UCWAttackDamageAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

UCWAttackDamageAffector::UCWAttackDamageAffector()
{
	AffectorType = ECWAffectorType::AttackDamage;
}

UCWAttackDamageAffector::~UCWAttackDamageAffector()
{
	OnAffectorEnd();
}

bool UCWAttackDamageAffector::IsAffectInKeyTime(ECWKeyTimeType ParamKeyTimeType)
{
	if ((ECWPropertyAffectorDataAffectType)AffectorDataAffectType == ECWPropertyAffectorDataAffectType::Persistent)
	{
		return false;
	}
	else if ((ECWPropertyAffectorDataAffectType)AffectorDataAffectType == ECWPropertyAffectorDataAffectType::InstantInKeyTime)
	{
		if (ParantBuff->IsSameKeyTime((ECWKeyTimeType)AffectorDataAffectKeyTimeType, ParamKeyTimeType))
		{
			return true;
		}
	}

	return false;
}

bool UCWAttackDamageAffector::OnAffect()
{
	if (!CastSkillContextPtr.IsValid())
	{
		return false;
	}

	check(ParantBuff);
	UCWBuffManager* OwnerBuffMgr = ParantBuff->GetBuffManager();
	check(OwnerBuffMgr);
	ACWPawn* TempPawn = OwnerBuffMgr->GetPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnBattlePropertComponent = TempPawn->GetBattleProperty();
	check(TempPawnBattlePropertComponent);

	//服务器才处理
	if (!TempPawn->IsInServer())
		return false;

	//角色是否已死
	if (TempPawn->IsDieOrDeath())
		return true;

	if (ArrayAffectorParams.Num() < 2)
	{
		UE_LOG(LogCWAttackDamageAffector, Error, TEXT("UCWAttackDamageAffector::OnAffect ArrayAffectorParams.Num() < 2, ArrayAffectorParams.Num():%d."), ArrayAffectorParams.Num());
		return false;
	}

	float SkillFactorValue = ArrayAffectorParams[0];
	float SkillValue = ArrayAffectorParams[1];

	//计算基础属性
	float PropertyValueBase = CastSkillContextPtr->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::Attack);

	//计算装备加成属性
	float PropertyEquipValue = 0.0f;
	for (int32 i = 0; i < CastSkillContextPtr->PawnArrayPropertyAffectorData.Num(); ++i)
	{
		FCWBattlePropertyAffectorData& TempAffectorData = CastSkillContextPtr->PawnArrayPropertyAffectorData[i];
		if (TempAffectorData.SouceType == ECWBuffSouceType::Equip &&
			TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Attack &&
			TempAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
		{
			PropertyEquipValue += TempAffectorData.GetResultValue(PropertyValueBase);
		}
	}

	//技能加成属性
	float PropertySkillValue = (PropertyValueBase + PropertyEquipValue) * SkillFactorValue + SkillValue;

	float FinalAttack = PropertyValueBase + PropertyEquipValue + PropertySkillValue;
	//------------------------------------------------------------------
	UCWBattleCalculate* BattleCalculate = UCWBattleCalculate::Get();
	//2：计算被伤害者的防御力
	//计算出基础防御力
	float DefinceBase = BattleCalculate->CalculateDefinceBase(CastSkillContextPtr, TempPawnBattlePropertComponent);

	//计算出装备加成
	float DefinceEquip = BattleCalculate->CalculateDefinceEquip(CastSkillContextPtr, TempPawnBattlePropertComponent, DefinceBase);

	//计算出被动技能加成
	float DefincePassivitySkill = BattleCalculate->CalculatDefincePassivitySkill(CastSkillContextPtr, TempPawnBattlePropertComponent, DefinceBase, DefinceEquip);

	//计算出Buff加成
	float DefinceBuff = BattleCalculate->CalculateDefinceBuff(CastSkillContextPtr, TempPawnBattlePropertComponent, DefinceBase, DefinceEquip);

	float FinalDefince = DefinceBase + DefinceEquip + DefincePassivitySkill + DefinceBuff;
	//------------------------------------------------------------------
	//3：计算最终伤害
	int32 intRealFinalDamage = BattleCalculate->CalculateRealFinalDamage(CastSkillContextPtr, FinalAttack, FinalDefince);
	UCWBattleCalculate::Get()->ExecHealthCalculate(CastSkillContextPtr, TempPawn, intRealFinalDamage);

	return true;
}
