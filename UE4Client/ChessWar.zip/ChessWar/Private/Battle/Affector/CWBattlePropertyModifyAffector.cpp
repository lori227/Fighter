﻿
#include "CWBattlePropertyModifyAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWBattlePropertySet.h"
#include "CWAffectorDataStruct.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"


UCWBattlePropertyModifyAffector::UCWBattlePropertyModifyAffector()
{
	AffectorType = ECWAffectorType::BattlePropertyModify;
}

UCWBattlePropertyModifyAffector::~UCWBattlePropertyModifyAffector()
{
	OnAffectorEnd();
}

bool UCWBattlePropertyModifyAffector::OnAffect()
{
	return true;
}

bool UCWBattlePropertyModifyAffector::OnAffectorBegin()
{
	check(ParantBuff);
	UCWBuffManager* OwnerBuffMgr = ParantBuff->GetBuffManager();
	check(OwnerBuffMgr);
	check(OwnerBuffMgr->GetPawn());
	ACWPawn* OwnerPawn = OwnerBuffMgr->GetPawn();
	check(OwnerPawn);
	UCWPawnBattlePropertyComponent* OwnerPawnPropertyComp = OwnerPawn->GetBattleProperty();
	check(OwnerPawnPropertyComp);

	// 服务器才处理
	if (!OwnerPawn->IsInServer())
	{
		return false;
	}

	// 角色是否已死
	if (OwnerPawn->IsDieOrDeath())
	{
		return true;
	}

	// 参数检测是否有效
	const ECWBattlePropertyModifyOp OperationType = (ECWBattlePropertyModifyOp)AffectorOperationType;
	if (!IsValidParamsWithModifyOp(OperationType, ArrayAffectorParams.Num()))
	{
		return false;
	}

	// 移除效果器数据
	const FCWAffectorDataStruct* AffectorData = GetAffectorDataStruct();
	RemoveAffectorDataFromArrayPropertyAffectorData(
		AffectorData->AffectorId,
		ParantBuff->GetBuffId(),
		ParantBuff->GetBuffUniqueId());

	// 添加效果器数据
	FCWBattlePropertyAffectorData TempAffectorData = FCWBattlePropertyAffectorData();
	TempAffectorData.SouceType = ParantBuff->GetSouceType();
	TempAffectorData.SourceUniqueId = ParantBuff->GetBuffUniqueId();
	TempAffectorData.SourceTypeId = ParantBuff->GetBuffId();
	TempAffectorData.SourceCustomParam1 = AffectorData->AffectorId;
	TempAffectorData.SourceCustomParam2 = 0;
	TempAffectorData.AffectType = ECWPropertyAffectorDataAffectType::Persistent;
	TempAffectorData.AffectKeyTimeType = ECWKeyTimeType::None;
	TempAffectorData.AffectBattlePropertyType = (ECWBattleProperty)AffectorSubType;
	TempAffectorData.BattlePropertyModifyOpType = OperationType;
	TempAffectorData.BattlePropertyModifyOpParams = ArrayAffectorParams;
	// Temp Code
	TempAffectorData.AffectorLimitDistanceType = AffectorLimitDistanceType;
	AddAffectorDataFromArrayPropertyAffectorData(TempAffectorData);

	return true;
}

bool UCWBattlePropertyModifyAffector::OnAffectorEnd()
{
	check(ParantBuff);

	// 移除效果器数据
	const FCWAffectorDataStruct* AffectorData = GetAffectorDataStruct();
	RemoveAffectorDataFromArrayPropertyAffectorData(
		AffectorData->AffectorId,
		ParantBuff->GetBuffId(),
		ParantBuff->GetBuffUniqueId());

	return true;
}
