#include "CWBeatBackAffector.h"
#include "CWCommonUtil.h"
#include "CWAffectorDataStruct.h"
#include "CWCastSkillContext.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBeatBackAffector, All, All);

//UCWBeatBackAffector::UCWBeatBackAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}
UCWBeatBackAffector::UCWBeatBackAffector()
{
	AffectorType = ECWAffectorType::BeatBack;
}

UCWBeatBackAffector::~UCWBeatBackAffector()
{
	OnAffectorEnd();
}

bool UCWBeatBackAffector::OnAffect()
{
	return true;
}
