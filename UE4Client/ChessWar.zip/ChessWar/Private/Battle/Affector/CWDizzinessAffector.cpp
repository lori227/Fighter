﻿
#include "CWDizzinessAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWBuffManager.h"
#include "CWCastSkillContext.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"


UCWDizzinessAffector::UCWDizzinessAffector()
{
	AffectorType = ECWAffectorType::Dizziness;
}

UCWDizzinessAffector::~UCWDizzinessAffector()
{
	OnAffectorEnd();
}

bool UCWDizzinessAffector::OnAffectorBegin()
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* OwnerPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(OwnerPawn);

	// 服务器才处理
	if (!OwnerPawn->IsInServer())
	{
		return false;
	}

	// 角色是否已死
	if (OwnerPawn->IsDieOrDeath())
	{
		return true;
	}

	// 添加无法操作指令&眩晕标志
	uint8 NewInstructs = Instruct_InValid;
	OwnerPawn->SetCurInstructs(NewInstructs);
	uint8 NewDizzinessState = 0x01;
	OwnerPawn->SetDizzinessFlag(NewDizzinessState);

	// 进入眩晕状态
	OwnerPawn->NetMulticastBeDizziness();

	return true;
}

bool UCWDizzinessAffector::OnAffectorEnd()
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* OwnerPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(OwnerPawn);

	// 服务器才处理
	if (!OwnerPawn->IsInServer())
	{
		return false;
	}

	// 角色是否已死
	if (OwnerPawn->IsDieOrDeath())
	{
		return true;
	}

	// 退出眩晕状态
	OwnerPawn->NetMulticastBeDizzinessExit();

	// 撤销无法操作指令&眩晕标志
	/*uint8 NewInstructs = OwnerPawn->GetCurInstructs();
	NewInstructs &= ~Instruct_InValid;
	OwnerPawn->SetCurInstructs(NewInstructs);*/
	uint8 NewDizzinessState = 0x00;
	OwnerPawn->SetDizzinessFlag(NewDizzinessState);

	return true;
}
