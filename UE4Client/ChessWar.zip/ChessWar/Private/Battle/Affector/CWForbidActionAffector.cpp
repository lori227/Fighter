#include "CWForbidActionAffector.h"
#include "CWCommonUtil.h"
#include "CWAffectorDataStruct.h"
#include "CWCastSkillContext.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWForbidActionAffector, All, All);

//UCWForbidActionAffector::UCWForbidActionAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}
UCWForbidActionAffector::UCWForbidActionAffector()
{
	AffectorType = ECWAffectorType::ForbidAction;
}

UCWForbidActionAffector::~UCWForbidActionAffector()
{
	OnAffectorEnd();
}

bool UCWForbidActionAffector::OnAffect()
{
	return true;
}
