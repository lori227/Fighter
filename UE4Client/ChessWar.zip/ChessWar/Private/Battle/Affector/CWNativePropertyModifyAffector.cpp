﻿
#include "CWNativePropertyModifyAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"


UCWNativePropertyModifyAffector::UCWNativePropertyModifyAffector()
{
	AffectorType = ECWAffectorType::NativePropertyModify;
}

UCWNativePropertyModifyAffector::~UCWNativePropertyModifyAffector()
{
	OnAffectorEnd();
}

bool UCWNativePropertyModifyAffector::OnAffect()
{
	check(ParantBuff);
	UCWBuffManager* OwnerBuffMgr = ParantBuff->GetBuffManager();
	check(OwnerBuffMgr);
	check(OwnerBuffMgr->GetPawn());
	ACWPawn* OwnerPawn = OwnerBuffMgr->GetPawn();
	check(OwnerPawn);
	UCWPawnBattlePropertyComponent* OwnerPawnPropertyComp = OwnerPawn->GetBattleProperty();
	check(OwnerPawnPropertyComp);

	// 服务器才处理
	if (!OwnerPawn->IsInServer())
	{
		return false;
	}

	// 角色是否已死
	if (OwnerPawn->IsDieOrDeath())
	{
		return true;
	}

	// 原生属性才有效(HP/SP)
	const ECWBattleProperty ModifyProperty = (ECWBattleProperty)AffectorSubType;
	if (ModifyProperty != ECWBattleProperty::Health && ModifyProperty != ECWBattleProperty::Energy)
	{
		CWG_ERROR(">> CWNativePropertyModifyAffector::OnAffect, ModifyProperty Fail!!! (Must is HP/SP).");
		return false;
	}

	// 属性修改值
	int32 ModifyValue = 0;
	if (!GetResultValue(ModifyValue, OwnerPawnPropertyComp))
	{
		return false;
	}

	// 伤害检测护盾消耗
	if (ModifyProperty == ECWBattleProperty::Health && ModifyValue < 0)
	{
		ModifyValue = -OwnerBuffMgr->CheckAndConsumeShield(-ModifyValue);
	}

	// 属性修改值检测
	if (0 != ModifyValue)
	{
		// TODO: MaxValue 上限值 !!!
		const float MaxValue = OwnerPawnPropertyComp->GetCurMaxTheoreticalPropertySet().GetPropertyByFloat(ModifyProperty);
		FCWBattlePropertyModifier Modifier(ModifyProperty,
			/*(ECWBattlePropertyModifyOp)AffectorOperationType*/ECWBattlePropertyModifyOp::Add_Param1, ModifyValue, 0.0f, MaxValue);
		OwnerPawn->NetMulticastFlyWordsEffect(ModifyValue < 0 ? FMT_DamageComm : FMT_ReplyComm, ModifyValue);

		OwnerPawnPropertyComp->GetCurPropertySet().ModifyProperty(Modifier);
	}

	return true;
}

bool UCWNativePropertyModifyAffector::GetResultValue(int32& OutModifyValue, class UCWPawnBattlePropertyComponent* InBattleProperty)
{
	check(InBattleProperty);

	bool bGetResultOk = false;
	const int32 AffectorParams = ArrayAffectorParams.Num();
	const ECWBattlePropertyModifyOp ModifyOpType = (ECWBattlePropertyModifyOp)AffectorOperationType;
	switch (ModifyOpType)
	{
	case ECWBattlePropertyModifyOp::Add_Param1:
	{
		if ((bGetResultOk = (AffectorParams >= 1)) == true)
		{
			const float NewParam1 = ArrayAffectorParams[0];
			OutModifyValue = NewParam1;
		}
	}break;
	case ECWBattlePropertyModifyOp::Base_Multiply_Param1_Add_Param2:
	{
		if ((bGetResultOk = (AffectorParams >= 2)) == true)
		{
			const float BaseValue = InBattleProperty->GetPropertySetBase().GetPropertyByFloat((ECWBattleProperty)AffectorSubType);
			const float NewParam1 = ArrayAffectorParams[0];
			const float NewParam2 = ArrayAffectorParams[1];
			OutModifyValue = BaseValue * NewParam1 + NewParam2;
		}
	}break;
	}

	if (!bGetResultOk)
	{
		CWG_ERROR(">> NativePropertyModifyAffector::GetResultValue, ModifyOpType[%s] NoImplementation/ParamsError.",
			*FCWCommonUtil::EnumToString(TEXT("ECWBattlePropertyModifyOp"), ModifyOpType));
	}
	return bGetResultOk;
}
