﻿
#include "CWShieldAffector.h"

#include "CWBuff.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWBuffManager.h"
#include "CWCastSkillContext.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorDataRef.h"


UCWShieldAffector::UCWShieldAffector()
{
	AffectorType = ECWAffectorType::Shield;

	NetPawnUniqueIdx = INDEX_NONE;
	NetPawnSkillId = INDEX_NONE;
	RemainDamageCnt = INDEX_NONE;
}

UCWShieldAffector::~UCWShieldAffector()
{
	OnAffectorEnd();
}

bool UCWShieldAffector::OnAffect()
{
	/*check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* OwnerPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(OwnerPawn);
	UCWPawnBattlePropertyComponent* OwnerPawnPropertComp = OwnerPawn->GetBattleProperty();
	check(OwnerPawnPropertComp);

	//服务器才处理 || 角色是否已死 || 参数为空
	if (!OwnerPawn->IsInServer() || OwnerPawn->IsDieOrDeath() ||
		(ArrayAffectorParams.Num() < 1))
	{
		return false;
	}*/

	return true;
}

bool UCWShieldAffector::ConsumeShield(TSharedPtr<UCWCastSkillContext> InCastSkillContext)
{
	if (!InCastSkillContext.IsValid())
	{
		return (NetPawnUniqueIdx == INDEX_NONE && NetPawnSkillId == INDEX_NONE);
	}
	else if (NetPawnUniqueIdx == INDEX_NONE && NetPawnSkillId == INDEX_NONE)
	{
		NetPawnUniqueIdx = InCastSkillContext->CastSkillPropertySet.GetPropertyByInt(ECWBattleProperty::UniqueId);
		NetPawnSkillId = InCastSkillContext->CastSkillDataStruct->SkillId;
		RemainDamageCnt = InCastSkillContext->CastSkillDataStruct->DamageCount;
		CWG_WARNING(">> CWShieldAffector::ConsumeShield, ShieldAffector[%s].", *ToString());
	}
	else
	{
		const int32 TmpNetPawnUniqueIdx = InCastSkillContext->CastSkillPropertySet.GetPropertyByInt(ECWBattleProperty::UniqueId);
		const int32 TmpNetPawnSkillId = InCastSkillContext->CastSkillDataStruct->SkillId;
		// 同一个技能
		if (TmpNetPawnUniqueIdx == NetPawnUniqueIdx && TmpNetPawnSkillId == NetPawnSkillId)
		{
			--RemainDamageCnt;
		}
		else
		{	// 不是同一个技能
			CWG_ERROR(">> CWShieldAffector::ConsumeShield, <Not the same skill> ShieldAffector[%s] TmpNetPawnUniqueIdx[%d] TmpNetPawnSkillId[%d].", 
				*ToString(), TmpNetPawnUniqueIdx, TmpNetPawnSkillId);
		}
	}

	return RemainDamageCnt <= 1;
}

FString UCWShieldAffector::ToString()
{
	return FString::Printf(TEXT("NetPawnUniqueIdx[%d] NetPawnSkillId[%d] RemainDamageCnt[%d]"), NetPawnUniqueIdx, NetPawnSkillId, RemainDamageCnt);
}
