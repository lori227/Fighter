#include "CWStrengthenNormalAttackDamageAffector.h"
#include "CWCommonUtil.h"
#include "CWAffectorDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWBuff.h"
#include "CWBuffManager.h"
#include "CWPawn.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattleCalculate.h"
#include "CWGameInstance.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertyModifier.h"
#include "CWBattlePropertyAffectorData.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWStrengthenNormalAttackDamageAffector, All, All);

//UCWStrengthenNormalAttackDamageAffector::UCWStrengthenNormalAttackDamageAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}
UCWStrengthenNormalAttackDamageAffector::UCWStrengthenNormalAttackDamageAffector()
{
	AffectorType = ECWAffectorType::StrengthenNormalAttackDamage;
}

UCWStrengthenNormalAttackDamageAffector::~UCWStrengthenNormalAttackDamageAffector()
{
	OnAffectorEnd();
}


bool UCWStrengthenNormalAttackDamageAffector::OnAffect()
{
	return true;
}

bool UCWStrengthenNormalAttackDamageAffector::OnAffectorBegin()
{
	check(ParantBuff);
	check(ParantBuff->GetBuffManager());
	check(ParantBuff->GetBuffManager()->GetPawn());
	ACWPawn* TempPawn = ParantBuff->GetBuffManager()->GetPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnBattlePropertComponent = TempPawn->GetBattleProperty();
	check(TempPawnBattlePropertComponent);

	//服务器才处理
	if (!TempPawn->IsInServer())
		return false;

	//角色是否已死
	if (TempPawn->IsDieOrDeath())
		return true;


	RemoveAffectorDataFromArrayPropertyAffectorData(
		this->GetAffectorDataStruct()->AffectorId,
		ParantBuff->GetBuffId(), 
		ParantBuff->GetBuffUniqueId());

	if (ArrayAffectorParams.Num() < 2)
	{
		UE_LOG(LogCWStrengthenNormalAttackDamageAffector, Error, TEXT("UCWStrengthenNormalAttackDamageAffector::OnAffectorBegin ArrayAffectorParams.Num() < 2, ArrayAffectorParams.Num():%d."), ArrayAffectorParams.Num());
		return false;
	}

	FCWBattlePropertyAffectorData TempAffectorData = FCWBattlePropertyAffectorData();
	TempAffectorData.SouceType = ParantBuff->GetSouceType();
	TempAffectorData.SourceUniqueId = ParantBuff->GetBuffUniqueId();
	TempAffectorData.SourceTypeId = ParantBuff->GetBuffId();
	TempAffectorData.SourceCustomParam1 = this->GetAffectorDataStruct()->AffectorId;
	TempAffectorData.SourceCustomParam2 = 0;
	TempAffectorData.AffectType = ECWPropertyAffectorDataAffectType::Persistent;
	TempAffectorData.AffectKeyTimeType = ECWKeyTimeType::None;
	TempAffectorData.AffectBattlePropertyType = ECWBattleProperty::Attack;
	TempAffectorData.BattlePropertyModifyOpType = (ECWBattlePropertyModifyOp)AffectorOperationType;
	TempAffectorData.BattlePropertyModifyOpParams = ArrayAffectorParams;
	AddAffectorDataFromArrayPropertyAffectorData(TempAffectorData);
	return true;
}

bool UCWStrengthenNormalAttackDamageAffector::OnAffectorEnd()
{
	check(ParantBuff);
	
	RemoveAffectorDataFromArrayPropertyAffectorData(
		this->GetAffectorDataStruct()->AffectorId, 
		ParantBuff->GetBuffId(), 
		ParantBuff->GetBuffUniqueId());

	return true;
}
