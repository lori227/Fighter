#include "CWTakeThePlaceOfSomePawnForFightingAffector.h"
#include "CWCommonUtil.h"
#include "CWAffectorDataStruct.h"
#include "CWCastSkillContext.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWTakeThePlaceOfSomePawnForFightingAffector, All, All);

//UCWTakeThePlaceOfSomePawnForFightingAffector::UCWTakeThePlaceOfSomePawnForFightingAffector(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}
UCWTakeThePlaceOfSomePawnForFightingAffector::UCWTakeThePlaceOfSomePawnForFightingAffector()
{
	AffectorType = ECWAffectorType::TakeThePlaceOfSomePawnForFighting;
}

UCWTakeThePlaceOfSomePawnForFightingAffector::~UCWTakeThePlaceOfSomePawnForFightingAffector()
{
	OnAffectorEnd();
}

bool UCWTakeThePlaceOfSomePawnForFightingAffector::OnAffect()
{
	return true;
}
