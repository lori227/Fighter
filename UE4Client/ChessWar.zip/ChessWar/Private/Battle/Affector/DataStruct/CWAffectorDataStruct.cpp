#include "CWAffectorDataStruct.h"

FCWAffectorDataStruct::FCWAffectorDataStruct()
	: AffectorId(0)
	, AffectorType(0)
{
}

FCWAffectorDataStruct::~FCWAffectorDataStruct()
{
}