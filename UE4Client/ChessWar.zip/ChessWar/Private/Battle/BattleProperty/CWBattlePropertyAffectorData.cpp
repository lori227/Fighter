
#include "CWBattlePropertyAffectorData.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWStructDefine.h"
#include "CWPawnDataStruct.h"
#include "CWCastSkillContext.h"


FCWBattlePropertyAffectorData::FCWBattlePropertyAffectorData()
{
	Reset();
}

FCWBattlePropertyAffectorData::FCWBattlePropertyAffectorData(const FCWBattlePropertyAffectorData& r)
{
	*this = r;
}

FCWBattlePropertyAffectorData& FCWBattlePropertyAffectorData::operator = (const FCWBattlePropertyAffectorData& r)
{
	if (this == &r)
		return *this;

	this->SouceType = r.SouceType;
	this->SourceUniqueId = r.SourceUniqueId;
	this->SourceTypeId = r.SourceTypeId;
	this->SourceCustomParam1 = r.SourceCustomParam1;
	this->SourceCustomParam2 = r.SourceCustomParam2;
	this->AffectType = r.AffectType; 
	this->AffectKeyTimeType = r.AffectKeyTimeType;
	this->AffectBattlePropertyType = r.AffectBattlePropertyType;
	this->BattlePropertyModifyOpType = r.BattlePropertyModifyOpType;
	this->BattlePropertyModifyOpParams = r.BattlePropertyModifyOpParams;
	AffectorLimitDistanceType = r.AffectorLimitDistanceType;
	return *this;
}

bool operator == (const FCWBattlePropertyAffectorData& l, const FCWBattlePropertyAffectorData& r)
{
	if (l.SouceType == r.SouceType &&
		l.SourceUniqueId == r.SourceUniqueId &&
		l.SourceTypeId == r.SourceTypeId &&
		l.SourceCustomParam1 == r.SourceCustomParam1 &&
		l.SourceCustomParam2 == r.SourceCustomParam2 &&
		l.AffectType == r.AffectType &&
		l.AffectKeyTimeType == r.AffectKeyTimeType &&
		l.AffectBattlePropertyType == r.AffectBattlePropertyType &&
		l.BattlePropertyModifyOpType == r.BattlePropertyModifyOpType &&
		l.AffectorLimitDistanceType == r.AffectorLimitDistanceType)
	{
		if (l.BattlePropertyModifyOpParams.Num() == r.BattlePropertyModifyOpParams.Num())
		{
			for (int i = 0; i < l.BattlePropertyModifyOpParams.Num(); ++i)
			{
				if (l.BattlePropertyModifyOpParams[i] != r.BattlePropertyModifyOpParams[i])
					return false;
			}

			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}

void FCWBattlePropertyAffectorData::Reset()
{
	this->SouceType = ECWBuffSouceType::None;
	this->SourceUniqueId = 0;
	this->SourceTypeId = 0;
	this->SourceCustomParam1 = 0;
	this->SourceCustomParam2 = 0;
	this->AffectType = ECWPropertyAffectorDataAffectType::None;
	this->AffectKeyTimeType = ECWKeyTimeType::None;
	this->AffectBattlePropertyType = ECWBattleProperty::None;
	this->BattlePropertyModifyOpType = ECWBattlePropertyModifyOp::None;
	//this->BattlePropertyModifyOpParams;
	AffectorLimitDistanceType = 0;
}

bool FCWBattlePropertyAffectorData::IsSameConditioin(TSharedPtr<UCWCastSkillContext> InCastSkillContext) const
{
	// Temp Code
	if (AffectBattlePropertyType == ECWBattleProperty::FinalDamageFactor)
	{
		if (0 == AffectorLimitDistanceType)
		{
			return true;
		}

		const ACWPawn* CasterPawn = InCastSkillContext.IsValid() ? InCastSkillContext->PawnWeakPtr.Get() : nullptr;
		const int32 CasterPawnId = IsValidActor(CasterPawn) ? CasterPawn->GetPawnId() : INDEX_NONE;
		if (const FCWPawnDataStruct* CasterPawnData = FCWCfgUtils::GetPawnData(CasterPawn, CasterPawnId))
		{
			return (CasterPawnData->IsMelee == 1 && 1 == AffectorLimitDistanceType) ||
				(CasterPawnData->IsLongRange == 1 && 2 == AffectorLimitDistanceType);
		}
	}
	return false;
}

float FCWBattlePropertyAffectorData::GetResultValue(const float InBaseValue, const float InDefaultValue) const
{
	const int32 ModifyOpParamsNum = BattlePropertyModifyOpParams.Num();
	switch (BattlePropertyModifyOpType)
	{
	case ECWBattlePropertyModifyOp::Add_Param1:
	{
		if (ModifyOpParamsNum >= 1)
		{
			const float NewParam1 = BattlePropertyModifyOpParams[0];
			return NewParam1;
		}
	}break;
	case ECWBattlePropertyModifyOp::Base_Multiply_Param1_Add_Param2:
	{
		if (ModifyOpParamsNum >= 2)
		{
			const float NewParam1 = BattlePropertyModifyOpParams[0];
			const float NewParam2 = BattlePropertyModifyOpParams[1];
			const float ResultValue = InBaseValue * NewParam1 + NewParam2;
			return ResultValue;
		}
	}break;
	case ECWBattlePropertyModifyOp::Base_Multiply_Param1_ClampMax_Param2:
	{
		if (ModifyOpParamsNum >= 2)
		{
			const float NewParam1 = BattlePropertyModifyOpParams[0];
			const float NewParam2 = BattlePropertyModifyOpParams[1];
			const float ResultValue = FMath::Clamp(InBaseValue * NewParam1, 0.f, NewParam2);
			return ResultValue;
		}
	}break;
	}

	CWG_ERROR(">> BattlePropertyAffectorData::GetResultValue, ERROR! AffectorData[%s].", *ToDebugString());
	return InDefaultValue;
}

FString FCWBattlePropertyAffectorData::ToDebugString() const
{
	return FString::Printf(TEXT("SouceType[%s] SourceUniqueId[%d] SourceTypeId[%d] SourceCustomParam1[%d] AffectType[%s] AffectBattlePropertyType[%s] BattlePropertyModifyOpType[%s] ModifyOpParams[%d]"),
		*FCWToString::ToString(SouceType), SourceUniqueId, SourceTypeId, SourceCustomParam1, *FCWToString::ToString(AffectType), *FCWToString::ToString(AffectBattlePropertyType), *FCWToString::ToString(BattlePropertyModifyOpType), BattlePropertyModifyOpParams.Num());
}
