#include "CWBattlePropertyAffectorDataRef.h"

UCWBattlePropertyAffectorDataRef::UCWBattlePropertyAffectorDataRef(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWBattlePropertyAffectorDataRef::Copy(const FCWBattlePropertyAffectorData& ParamPropertyAffectorData)
{
	PropertyAffectorData = ParamPropertyAffectorData;
}

FCWBattlePropertyAffectorData& UCWBattlePropertyAffectorDataRef::GetPropertyAffectorData()
{
	return PropertyAffectorData;
}

const FCWBattlePropertyAffectorData& UCWBattlePropertyAffectorDataRef::GetPropertyAffectorData() const
{
	return PropertyAffectorData;
}