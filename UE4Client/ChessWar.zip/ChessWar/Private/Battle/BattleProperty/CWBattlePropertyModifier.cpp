#include "CWBattlePropertyModifier.h"

FCWBattlePropertyModifier::FCWBattlePropertyModifier()
{
	PropertyType = ECWBattleProperty::None;
	ModifyOperateType = ECWBattlePropertyModifyOp::None;
	Param1 = 0.0f;
	Param2 = 0.0f;
	ValueMin = 0.0f;
	ValueMax = 0.0f;
}


FCWBattlePropertyModifier::FCWBattlePropertyModifier(
	ECWBattleProperty ParamPropertyType,
	ECWBattlePropertyModifyOp ParamModifyOperateType,
	float ParamParam1,
	float ParamMin,
	float ParamMax
	)
{
	PropertyType = ParamPropertyType;
	ModifyOperateType = ParamModifyOperateType;
	Param1 = ParamParam1;
	Param2 = 0.0f;
	ValueMin = ParamMin;
	ValueMax = ParamMax;
}


FCWBattlePropertyModifier::FCWBattlePropertyModifier(
	ECWBattleProperty ParamPropertyType,
	ECWBattlePropertyModifyOp ParamModifyOperateType,
	float ParamParam1,
	float ParamParam2,
	float ParamMin,
	float ParamMax
	)
{
	PropertyType = ParamPropertyType;
	ModifyOperateType = ParamModifyOperateType;
	Param1 = ParamParam1;
	Param2 = ParamParam2;
	ValueMin = ParamMin;
	ValueMax = ParamMax;
}