﻿#include "CWBattlePropertySet.h"
#include "CWBattlePropertyModifier.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBattlePropertySet, All, All);

FCWBattlePropertySet::FCWBattlePropertySet()
{	
	Reset();
}

FCWBattlePropertySet::FCWBattlePropertySet(const FCWBattlePropertySet& r)
{
	*this = r;
}

FCWBattlePropertySet& FCWBattlePropertySet::operator = (const FCWBattlePropertySet& r)
{
	if (this == &r)
		return *this;

	AttackValue = r.AttackValue;								//01
	PhysicalDefenceValue = r.PhysicalDefenceValue;				//02
	MagicDefenceValue = r.MagicDefenceValue;					//03
	HealthValue = r.HealthValue;								//04
	EnergyValue = r.EnergyValue;								//05
	TalentValue = r.TalentValue;								//06
	MoveValue = r.MoveValue;									//07
	CriticalDamageFactorValue = r.CriticalDamageFactorValue;	//08
	CriticalHitRateValue = r.CriticalHitRateValue;				//09
	AttackSpeedValue = r.AttackSpeedValue;						//10
	SpeedValue = r.SpeedValue;									//11
	HitRateValue = r.HitRateValue;								//12
	AvoidanceRateValue = r.AvoidanceRateValue;					//13
	BlockRateValue = r.BlockRateValue;							//14

	AttackFactorValue = r.AttackFactorValue;					//15
	PhysicalDefenceFactorValue = r.PhysicalDefenceFactorValue;	//16
	MagicDefenceFactorValue = r.MagicDefenceFactorValue;		//17
	HealthFactorValue = r.HealthFactorValue;					//18
	EnergyFactorValue = r.EnergyFactorValue;					//19
	TalentFactorValue = r.TalentFactorValue;					//20
	MoveFactorValue = r.MoveFactorValue;						//21
	CriticalDamageFFValue = r.CriticalDamageFFValue;			//22
	CriticalHitRateFactorValue = r.CriticalHitRateFactorValue;	//23
	AttackSpeedFactorValue = r.AttackSpeedFactorValue;			//24
	SpeedFactorValue = r.SpeedFactorValue;						//25
	HitRateFactorValue = r.HitRateFactorValue;					//26
	AvoidanceRateFactorValue = r.AvoidanceRateFactorValue;		//27
	BlockRateFactorValue = r.BlockRateFactorValue;				//28

	DefincePostureFactorValue = r.DefincePostureFactorValue;	//29
	DefincePostureValue = r.DefincePostureValue;				//30
	FinalDamageFactorValue = r.FinalDamageFactorValue;			//31
	FinalDamageValue = r.FinalDamageValue;						//32

	UniqueIdValue = r.UniqueIdValue;							//33
	ProfessionValue = r.ProfessionValue;						//34
	AttackTypeValue = r.AttackTypeValue;						//35
	
	PropertySetAffectorTypeValue = r.PropertySetAffectorTypeValue;		//36
	
	return *this;
}

void FCWBattlePropertySet::Reset()
{
	AttackValue = 0.0f;							//01
	PhysicalDefenceValue = 0.0f;				//02
	MagicDefenceValue = 0.0f;					//03
	HealthValue = 0.0f;							//04
	EnergyValue = 0.0f;							//05
	TalentValue = 0.0f;							//06
	MoveValue = 0.0f;							//07
	CriticalDamageFactorValue = 0.0f;			//08
	CriticalHitRateValue = 0.0f;				//09
	AttackSpeedValue = 0.0f;					//10
	SpeedValue = 0.0f,							//11
	HitRateValue = 0.0f;						//12
	AvoidanceRateValue = 0.0f;					//13
	BlockRateValue = 0.0f;						//14

	AttackFactorValue = 0.0f;					//15
	PhysicalDefenceFactorValue = 0.0f;			//16
	MagicDefenceFactorValue = 0.0f;				//17
	HealthFactorValue = 0.0f;					//18
	EnergyFactorValue = 0.0f;					//19
	TalentFactorValue = 0.0f;					//20
	MoveFactorValue = 0.0f;						//21
	CriticalDamageFFValue = 0.0f;				//22
	CriticalHitRateFactorValue = 0.0f;			//23
	AttackSpeedFactorValue = 0.0f;				//24
	SpeedFactorValue = 0.0f;					//25
	HitRateFactorValue = 0.0f;					//26
	AvoidanceRateFactorValue = 0.0f;			//27
	BlockRateFactorValue = 0.0f;				//28

	DefincePostureFactorValue = 0.0f;			//29
	DefincePostureValue = 0.0f;					//30
	FinalDamageFactorValue = 0.0f;				//31
	FinalDamageValue = 0.0f;					//32

	UniqueIdValue = 0;											//33
	ProfessionValue = 0;										//34
	AttackTypeValue = ECWBattleAttackType::None;				//35
	

	PropertySetAffectorTypeValue = ECWPropertySetAffectorType::All;	//36
}


float FCWBattlePropertySet::GetPropertyByFloat(ECWBattleProperty ParamBattlePropertyType) const
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::Attack:						//01
		return AttackValue;
		break;
	case ECWBattleProperty::PhysicalDefence:			//02
		return PhysicalDefenceValue;
		break;
	case ECWBattleProperty::MagicDefence:				//03
		return MagicDefenceValue;
		break;
	case ECWBattleProperty::Health:						//04
		return HealthValue;
		break;	
	case ECWBattleProperty::Energy:						//05
		return EnergyValue;
		break;
	case ECWBattleProperty::Talent:						//06
		return TalentValue;
		break;
	case ECWBattleProperty::Move:						//07
		return MoveValue;
		break;
	case ECWBattleProperty::CriticalDamageFactor:		//08
		return CriticalDamageFactorValue;
		break;
	case ECWBattleProperty::CriticalHitRate:			//09
		return CriticalHitRateValue;
		break;
	case ECWBattleProperty::AttackSpeed:				//10
		return AttackSpeedValue;
		break;
	case ECWBattleProperty::Speed:						//11
		return SpeedValue;
		break;
	case ECWBattleProperty::HitRate:					//12
		return HitRateValue;
		break;
	case ECWBattleProperty::AvoidanceRate:				//13
		return AvoidanceRateValue;
		break;
	case ECWBattleProperty::BlockRate:					//14
		return BlockRateValue;
		break;
		
	case ECWBattleProperty::AttackFactor:				//15
		return AttackFactorValue;
		break;
	case ECWBattleProperty::PhysicalDefenceFactor:		//16
		return PhysicalDefenceFactorValue;
		break;
	case ECWBattleProperty::MagicDefenceFactor:			//17
		return MagicDefenceFactorValue;
		break;
	case ECWBattleProperty::HealthFactor:				//18
		return HealthFactorValue;
		break;
	case ECWBattleProperty::EnergyFactor:				//19
		return EnergyFactorValue;
		break;
	case ECWBattleProperty::TalentFactor:				//20
		return TalentFactorValue;
		break;
	case ECWBattleProperty::MoveFactor:					//21
		return MoveFactorValue;
		break;
	case ECWBattleProperty::CriticalDamageFF:			//22
		return CriticalDamageFFValue;
		break;
	case ECWBattleProperty::CriticalHitRateFactor:		//23
		return CriticalHitRateFactorValue;
		break;
	case ECWBattleProperty::AttackSpeedFactor:			//24
		return AttackSpeedFactorValue;
		break;
	case ECWBattleProperty::SpeedFactor:				//25
		return SpeedFactorValue;
		break;
	case ECWBattleProperty::HitRateFactor:				//26
		return HitRateValue;
		break;
	case ECWBattleProperty::AvoidanceRateFactor:		//27
		return AvoidanceRateFactorValue;
		break;
	case ECWBattleProperty::BlockRateFactor:			//28
		return BlockRateFactorValue;
		break;
	case ECWBattleProperty::DefincePostureFactor:		//29
		return DefincePostureFactorValue;
		break;
	case ECWBattleProperty::DefincePosture:				//30
		return DefincePostureValue;
		break;
	case ECWBattleProperty::FinalDamageFactor:			//31
		return FinalDamageFactorValue;
		break;
	case ECWBattleProperty::FinalDamage:				//32
		return FinalDamageValue;
		break;

	default:
		return 0.0f;
		break;
	}
}


int32 FCWBattlePropertySet::GetPropertyByInt(ECWBattleProperty ParamBattlePropertyType) const
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::UniqueId:					//33
		return UniqueIdValue;
		break;
	case ECWBattleProperty::Profession:					//34
		return ProfessionValue;
		break;
	default:
		return 0;
		break;
	}
}


ECWBattleAttackType FCWBattlePropertySet::GetPropertyForAttackType(ECWBattleProperty ParamBattlePropertyType) const
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::AttackType:					//35
		return AttackTypeValue;
		break;
	default:
		return ECWBattleAttackType::None;
		break;
	}
}


ECWPropertySetAffectorType FCWBattlePropertySet::GetPropertyForAffectorType(ECWBattleProperty ParamBattlePropertyType) const
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::PropertySetAffectorType:	//36
		return PropertySetAffectorTypeValue;
		break;
	default:
		return ECWPropertySetAffectorType::None;
		break;
	}
}

template<>
void FCWBattlePropertySet::SetProperty(ECWBattleProperty ParamBattlePropertyType, float ParamBattleProperty)
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::Attack:							//01
		AttackValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::PhysicalDefence:				//02
		PhysicalDefenceValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::MagicDefence:					//03
		MagicDefenceValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Health:							//04
		HealthValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Energy:							//05
		EnergyValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Talent:							//06
		TalentValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Move:							//07
		MoveValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::CriticalDamageFactor:			//08
		CriticalDamageFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::CriticalHitRate:				//09
		CriticalHitRateValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::AttackSpeed:					//10
		AttackSpeedValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Speed:							//11
		SpeedValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::HitRate:						//12
		HitRateValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::AvoidanceRate:					//13
		AvoidanceRateValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::BlockRate:						//14
		BlockRateValue = ParamBattleProperty;
		break;

	case ECWBattleProperty::AttackFactor:					//15
		AttackFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::PhysicalDefenceFactor:			//16
		PhysicalDefenceFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::MagicDefenceFactor:				//17
		MagicDefenceFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::HealthFactor:					//18
		HealthFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::EnergyFactor:					//19
		EnergyFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::TalentFactor:					//20
		TalentFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::MoveFactor:						//21
		MoveFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::CriticalDamageFF:				//22
		CriticalDamageFFValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::CriticalHitRateFactor:			//23
		CriticalHitRateFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::AttackSpeedFactor:				//24
		AttackSpeedFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::SpeedFactor:					//25
		SpeedFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::HitRateFactor:					//26
		HitRateFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::AvoidanceRateFactor:			//27
		AvoidanceRateFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::BlockRateFactor:				//28
		BlockRateFactorValue = ParamBattleProperty;
		break;

	case ECWBattleProperty::DefincePostureFactor:			//29
		DefincePostureFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::DefincePosture:					//30
		DefincePostureValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::FinalDamageFactor:				//31
		FinalDamageFactorValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::FinalDamage:					//32
		FinalDamageValue = ParamBattleProperty;
		break;

	default:
		break;
	}
}

template<>
void FCWBattlePropertySet::SetProperty(ECWBattleProperty ParamBattlePropertyType, int32 ParamBattleProperty)
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::UniqueId:						//33
		UniqueIdValue = ParamBattleProperty;
		break;
	case ECWBattleProperty::Profession:						//34
		ProfessionValue = ParamBattleProperty;
		break;
	default:
		break;
	}
}

template<>
void FCWBattlePropertySet::SetProperty(ECWBattleProperty ParamBattlePropertyType, ECWBattleAttackType ParamBattleProperty)
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::AttackType:						//35
		AttackTypeValue = ParamBattleProperty;
		break;
	default:
		break;
	}
}

template<>
void FCWBattlePropertySet::SetProperty(ECWBattleProperty ParamBattlePropertyType, ECWPropertySetAffectorType ParamPropertySetAffectorTypeValue)
{
	switch (ParamBattlePropertyType)
	{
	case ECWBattleProperty::PropertySetAffectorType:		//36
		PropertySetAffectorTypeValue = ParamPropertySetAffectorTypeValue;
		break;
	default:
		break;
	}
}


bool FCWBattlePropertySet::ModifyProperty(const FCWBattlePropertyModifier& Modifier)
{
	switch(Modifier.ModifyOperateType)
	{
	case  ECWBattlePropertyModifyOp::Add_Param1:
	{
		float CurPropertyValue = GetPropertyByFloat(Modifier.PropertyType);
		float Result = CurPropertyValue + Modifier.Param1;
		check(Modifier.ValueMin <= Modifier.ValueMax);
		Result = Result < Modifier.ValueMin ? Modifier.ValueMin : Result;
		Result = Result > Modifier.ValueMax ? Modifier.ValueMax : Result;
		SetProperty<float>(Modifier.PropertyType, Result);
		return true;
		break;
	}
	/*case ECWBattlePropertyModifyOp::Add_Origin_Multiply_Param1:
	{
		float CurPropertyValue = GetPropertyByFloat(Modifier.PropertyType);
		float Result = CurPropertyValue + CurPropertyValue * Modifier.Param1;
		check(Modifier.ValueMin <= Modifier.ValueMax);
		Result = Result < Modifier.ValueMin ? Modifier.ValueMin : Result;
		Result = Result > Modifier.ValueMax ? Modifier.ValueMax : Result;
		SetProperty<float>(Modifier.PropertyType, Result);
		return true;
		break;
	}
	case ECWBattlePropertyModifyOp::Add_Origin_Multiply_Param1_Add_Param2:
	{
		float CurPropertyValue = GetPropertyByFloat(Modifier.PropertyType);
		float Result = CurPropertyValue + CurPropertyValue * Modifier.Param1 + Modifier.Param2;
		check(Modifier.ValueMin <= Modifier.ValueMax);
		Result = Result < Modifier.ValueMin ? Modifier.ValueMin : Result;
		Result = Result > Modifier.ValueMax ? Modifier.ValueMax : Result;
		SetProperty<float>(Modifier.PropertyType, Result);
		return true;
		break;
	}*/
	default:
		UE_LOG(LogCWBattlePropertySet, Error, TEXT("FCWBattlePropertySet::ModifyProperty Modifier.ModifyOperateType is Invalid, Modifier.ModifyOperateType:%d."), (int32)Modifier.ModifyOperateType);
		return false;
		break;
	}
}