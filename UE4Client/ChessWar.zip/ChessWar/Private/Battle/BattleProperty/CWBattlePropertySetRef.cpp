#include "CWBattlePropertySetRef.h"

//UCWBattlePropertySetRef::UCWBattlePropertySetRef(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

void UCWBattlePropertySetRef::Copy(const FCWBattlePropertySet& ParamPropertySet)
{
	PropertySet = ParamPropertySet;
}

FCWBattlePropertySet& UCWBattlePropertySetRef::GetPropertySet()
{
	return PropertySet;
}

const FCWBattlePropertySet& UCWBattlePropertySetRef::GetPropertySet() const
{
	return PropertySet;
}