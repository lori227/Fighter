
#include "CWBuff.h"

#include <ctime>
#include <random>
#include <functional>

#include "CWPawn.h"
#include "CWSkill.h"
#include "CWComDef.h"
#include "CWCommonUtil.h"
#include "CWSkillManager.h"
#include "CWBuffManager.h"
#include "CWSkillDataUtils.h"
#include "CWBuffDataUtils.h"
#include "CWShieldAffector.h"
#include "CWBuffDataStruct.h"
#include "CWEffectDataUtils.h"
#include "CWCastSkillContext.h"
#include "CWBeatBackAffector.h"
#include "CWEffectDataStruct.h"
#include "CWDizzinessAffector.h"
#include "CWElementSystemCtrl.h"
#include "CWBattlePropertySet.h"
#include "CWAffectorDataStruct.h"
#include "CWActionAgainAffector.h"
#include "CWForbidActionAffector.h"
#include "CWAttackDamageAffector.h"
#include "CWBattlePropertySetRef.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWNativePropertyModifyAffector.h"
#include "CWBattlePropertyModifyAffector.h"
#include "CWStrengthenNormalAttackDamageAffector.h"
#include "CWTakeThePlaceOfSomePawnForFightingAffector.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBuff, All, All);

//UCWBuff::UCWBuff(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

UCWBuff::UCWBuff()
{
	// 默认来源技能
	SouceType = ECWBuffSouceType::Skill;
}

UCWBuff::~UCWBuff()
{
	ACWPawn* TempTargetPawn = nullptr;
	if (this->GetBuffManager())
	{
		TempTargetPawn = this->GetBuffManager()->GetPawn();
	}

	UCWElementSystemCtrl* OwnerElemSysCtrl = IsValid(TempTargetPawn) ? TempTargetPawn->GetElemSysCtrl() : nullptr;
	if (IsValid(OwnerElemSysCtrl))
	{
		// Buff销毁回调
		OnBuffDestroyed.Broadcast(BuffUniqueId, BuffId, RefElemType, SouceType);
		OnBuffDestroyed.Clear();
	}

	CastSkillContextPtr.Reset();

	if (MapAffector.size() > 0)
	{
		for (std::map<int32, UCWAffector*>::iterator iter = MapAffector.begin(); iter != MapAffector.end(); ++iter)
		{
			UCWAffector* TempAffector = iter->second;
			TempAffector->OnAffectorEnd();
			delete TempAffector;
		}
		MapAffector.clear();
	}

	if (ListBuffEffectId.size() > 0)
	{
		for (std::list<int32>::iterator iter = ListBuffEffectId.begin(); iter != ListBuffEffectId.end(); ++iter)
		{
			int32 TempBuffEffectId = *iter;
			if (TempTargetPawn)
			{
				TempTargetPawn->RemoveBuffEffect(TempBuffEffectId);
			}
		}
		ListBuffEffectId.clear();
	}
	
	ParantBuffManager = nullptr;
}

bool UCWBuff::InitInServer(UCWBuffManager* ParamParantBuffManager, int ParamBuffUniqueId, int ParamBuffId, TSharedPtr<UCWCastSkillContext> ParamCastSkillContext)
{
	check(ParamParantBuffManager);
	//check(ParamCastSkillContext);
	ParantBuffManager = ParamParantBuffManager;
	BuffUniqueId = ParamBuffUniqueId;
	BuffId = ParamBuffId;
	CastSkillContextPtr = ParamCastSkillContext;
	TriggerAffectorCountForRound = 0;
	TotalNormalAttackCount = 0;

	const FCWBuffDataStruct* TempBuffData = this->GetBuffDataStruct();
	if (TempBuffData->LifeType == 1)
	{
		CurRemainLifeRoundCount = TempBuffData->LifeRoundCount;
	}

	return true;
}


bool UCWBuff::InitInClient(UCWBuffManager* ParamParantBuffManager, int ParamBuffUniqueId, int ParamBuffId)
{
	check(ParamParantBuffManager);
	ParantBuffManager = ParamParantBuffManager;
	BuffUniqueId = ParamBuffUniqueId;
	BuffId = ParamBuffId;
	CastSkillContextPtr = nullptr;
	TriggerAffectorCountForRound = 0;
	TotalNormalAttackCount = 0;

	const FCWBuffDataStruct* TempBuffData = this->GetBuffDataStruct();
	if (TempBuffData->LifeType == 1)
	{
		CurRemainLifeRoundCount = TempBuffData->LifeRoundCount;
	}

	return true;
}

bool UCWBuff::ResetForRound()
{
	TriggerAffectorCountForRound = 0;

	return true;
}

void UCWBuff::DecreaseRemainLifeRoundCount()
{
	CurRemainLifeRoundCount--;

	OnUpdateBuffData();
}

int32 UCWBuff::GetCurRemainLifeRoundCount() const
{
	return CurRemainLifeRoundCount;
}

const FCWBuffDataStruct* UCWBuff::GetBuffDataStruct() const
{
	FCWBuffDataStruct* TempBuffData = FCWCommonUtil::FindCSVRow<FCWBuffDataStruct>(TEXT("CWBuffDataTable"), BuffId);
	if (TempBuffData == nullptr)
	{
		UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GetBuffDataStruct, TempBuffData == nullptr, BuffId:%d."), BuffId);
		return nullptr;
	}
	return TempBuffData;
}

TSharedPtr<UCWCastSkillContext> UCWBuff::GetCastSkillContext() const
{
	return CastSkillContextPtr;
}

int32 UCWBuff::GetBuffUniqueId() const
{
	return BuffUniqueId;
}

int32 UCWBuff::GetBuffId() const
{
	return BuffId;
}

UCWBuffManager* UCWBuff::GetBuffManager()
{
	return ParantBuffManager;
}

float UCWBuff::RandomFloat(float min, float max)
{
	std::default_random_engine Generator(time(NULL));
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

bool UCWBuff::GenerateAffector(ECWKeyTimeType ParamKeyTimeType)
{
	check(this->GetBuffManager());
	check(this->GetBuffManager()->GetPawn());
	ACWPawn* TempTargetPawn = this->GetBuffManager()->GetPawn();
	UCWPawnBattlePropertyComponent* TempTargetPawnBattlePropertComponent = TempTargetPawn->GetBattleProperty();
	check(TempTargetPawnBattlePropertComponent);

	bool OneMoreSuccess = false;
	const FCWBuffDataStruct* TempBuffDataStruct = this->GetBuffDataStruct();
	if (TempBuffDataStruct->LifeType == 1)
	{
		bool TempIsKeyTime = false;
		const bool bNeedBuffBeginToggle = (TempBuffDataStruct->bAffactImmediatelyWhenBuffBegin && ParamKeyTimeType == ECWKeyTimeType::BuffBegin);
		if (IsSameKeyTime((ECWKeyTimeType)(TempBuffDataStruct->AffactRoundTimeType), ParamKeyTimeType) || bNeedBuffBeginToggle)
		{
			TempIsKeyTime = true;
		}

		if (TempIsKeyTime)
		{
			std::vector<int32> ArrayAffectorId = FCWBuffDataUtils::GetArrayAffectorIdFromString(TempBuffDataStruct->ArrayAffectorId);
			std::vector<int32> ArrayAffectorSubType = FCWBuffDataUtils::GetArrayAffectorSubTypeFromString(TempBuffDataStruct->ArrayAffectorSubType);
			std::vector<int32> ArrayAffectorOperationType = FCWBuffDataUtils::GetArrayAffectorOperationTypeFromString(TempBuffDataStruct->ArrayAffectorOperationType);
			std::vector<std::vector<float> > ArrayArrayAffectorParams = FCWBuffDataUtils::GetArrayArrayAffectorParamsFromString(TempBuffDataStruct->ArrayArrayAffectorParams);
			std::vector<int32> ArrayAffectorDataAffectType = FCWBuffDataUtils::GetArrayAffectorDataAffectTypeFromString(TempBuffDataStruct->ArrayAffectorDataAffectType);
			std::vector<int32> ArrayAffectorDataAffectKeyTimeType = FCWBuffDataUtils::GetArrayAffectorDataAffectKeyTimeTypeFromString(TempBuffDataStruct->ArrayAffectorDataAffectKeyTimeType);

			const int32 AffectorIdNum = ArrayAffectorId.size();
			if (AffectorIdNum != TempBuffDataStruct->AffectorNum)
			{
				CWG_ERROR(">> CWBuff::AddPassivityBuff, AffectorIdNum[%d] AffectorNum[%d] BuffId[%d].",
					AffectorIdNum, TempBuffDataStruct->AffectorNum, BuffId);
			}
			for (int i = 0; i < AffectorIdNum; ++i)
			{
				if (ArrayAffectorId.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, AffectorIdNum[%d], i[%d] BuffId[%d].", ArrayAffectorId.size(), i, BuffId);
					return false;
				}

				if (ArrayAffectorSubType.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, ArrayAffectorSubType.size():%d i:%d, BuffId[%d].", ArrayAffectorSubType.size(), i, BuffId);
					return false;
				}

				if (ArrayAffectorOperationType.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, ArrayAffectorOperationType.size():%d, i:%d BuffId[%d].", ArrayAffectorOperationType.size(), i, BuffId);
					return false;
				}

				if (ArrayArrayAffectorParams.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, ArrayArrayAffectorParams.size():%d, i:%d BuffId[%d].", ArrayArrayAffectorParams.size(), i, BuffId);
					return false;
				}

				if (ArrayAffectorDataAffectType.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, ArrayAffectorDataAffectType.size():%d, i:%d BuffId[%d].", ArrayAffectorDataAffectType.size(), i, BuffId);
					return false;
				}

				if (ArrayAffectorDataAffectKeyTimeType.size() <= i)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector InServer, ArrayAffectorDataAffectKeyTimeType.size():%d, i:%d BuffId[%d].", ArrayAffectorDataAffectKeyTimeType.size(), i, BuffId);
					return false;
				}

				int32 TempAffectorId = ArrayAffectorId[i];
				int32 TempAffectorSubType = ArrayAffectorSubType[i];
				int32 TempAffectorOperationType = ArrayAffectorOperationType[i];
				std::vector<float> ArrayAffectorParams = ArrayArrayAffectorParams[i];
				int32 TempAffectorDataAffectType = ArrayAffectorDataAffectType[i];
				int32 TempAffectorDataAffectKeyTimeType = ArrayAffectorDataAffectKeyTimeType[i];

				FCWAffectorDataStruct* TempAffectorData = FCWCommonUtil::FindCSVRow<FCWAffectorDataStruct>(TEXT("CWAffectorDataTable"), TempAffectorId);
				if (TempAffectorData == nullptr)
				{
					CWG_ERROR(">> UCWBuff::GenerateAffector fail, TempAffectorData == nullptr, TempAffectorId:%d BuffId[%d].", TempAffectorId, BuffId);
					continue;
				}

				UCWAffector* TempAffector = AffectorCreateByAffectorType((ECWAffectorType)(TempAffectorData->AffectorType));
				if (TempAffector != nullptr)
				{
					if (TempAffector->Init(this, TempAffectorId, CastSkillContextPtr))
					{
						TempAffector->SetAffectorSubType(TempAffectorSubType);
						TempAffector->SetAffectorOperationType(TempAffectorOperationType);
						TempAffector->SetArrayAffectorParams(ArrayAffectorParams);
						TempAffector->SetAffectorDataAffectType(TempAffectorDataAffectType);
						TempAffector->SetAffectorDataAffectKeyTimeType(TempAffectorDataAffectKeyTimeType);
						TempAffector->SetAffectorLimitDistanceType(TempBuffDataStruct->AffectorLimitDistanceType);
						
						if (TempAffector->IsAffectInKeyTime(ParamKeyTimeType) || bNeedBuffBeginToggle)
						{
							TempAffector->OnAffectorBegin();
							TempAffector->OnAffect();
							TempAffector->OnAffectorEnd();
							delete TempAffector;
						}
						else
						{
							AddToMap(TempAffectorId, TempAffector);

							// PS: 确保先前相同移出AffectorId
							TempAffector->OnAffectorBegin();
						}
						OneMoreSuccess = true;

						UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::GenerateAffector InServer, BuffId:%d Generate Affector Success. AffectorId:%d, BuffDataStruct->LifeType%d, KeyTimeType:%d, Affect to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffId, TempAffectorId, TempBuffDataStruct->LifeType, (int)ParamKeyTimeType, (int)TempTargetPawn->GetCampTag(), (int)TempTargetPawn->GetCampControllerIndex(), (int)TempTargetPawn->GetControllerPawnIndex());

						float TempCurTargetHealth = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);

						//血量检测
						if (TempCurTargetHealth <= 0.0f)
						{
							TempTargetPawn->DieInServer();
						}
					}
					else
					{
						CWG_ERROR("UCWBuff::GenerateAffector InServer fail. TempAffector->Init fail, TempAffectorId:%d BuffId[%d].", TempAffectorId, BuffId);
						delete TempAffector;
						continue;
					}
				}
				else
				{
					CWG_ERROR("UCWBuff::GenerateAffector InServer, AffectorCreateByAffectorType fail, AffectorType:%d, TempAffectorId:%d  BuffId[%d].", TempAffectorData->AffectorType, TempAffectorId, BuffId);
					return false;
				}
			}
		}

		if (OneMoreSuccess)
			return true;
		else
			return false;
	}
	else if (TempBuffDataStruct->LifeType == 0)
	{
		std::vector<std::vector<int32> > ArrayArrayAffectorTriggerConditionType = FCWBuffDataUtils::GetArrayArrayAffectorTriggerConditionType(TempBuffDataStruct->ArrayArrayAffectorTriggerConditionType);
		std::vector<std::vector<int32> > ArrayArrayAffectorTriggerConditionLogicOp = FCWBuffDataUtils::GetArrayArrayAffectorTriggerConditionLogicOp(TempBuffDataStruct->ArrayArrayAffectorTriggerConditionLogicOp);
		std::vector<std::vector<int32> > ArrayArrayAffectorTriggerConcretenessCondition = FCWBuffDataUtils::GetArrayArrayAffectorTriggerConcretenessCondition(TempBuffDataStruct->ArrayArrayAffectorTriggerConcretenessCondition);
		std::vector<std::vector<int32> > ArrayArrayAffectorTriggerCompareRelatioinOp = FCWBuffDataUtils::GetArrayArrayAffectorTriggerCompareRelatioinOp(TempBuffDataStruct->ArrayArrayAffectorTriggerCompareRelatioinOp);
		std::vector<std::vector<int32> > ArrayArrayAffectorTriggerCompareRelatioinOpValueType = FCWBuffDataUtils::GetArrayArrayAffectorTriggerCompareRelatioinOpValueType(TempBuffDataStruct->ArrayArrayAffectorTriggerCompareRelatioinOpValueType);
		std::vector<std::vector<float> > ArrayArrayAffectorTriggerConcretenessParams = FCWBuffDataUtils::GetArrayArrayAffectorTriggerConcretenessParams(TempBuffDataStruct->ArrayArrayAffectorTriggerConcretenessParams);
		std::vector<int32> ArrayAffectorId = FCWBuffDataUtils::GetArrayAffectorIdFromString(TempBuffDataStruct->ArrayAffectorId);
		std::vector<int32> ArrayAffectorSubType = FCWBuffDataUtils::GetArrayAffectorSubTypeFromString(TempBuffDataStruct->ArrayAffectorSubType);
		std::vector<int32> ArrayAffectorOperationType = FCWBuffDataUtils::GetArrayAffectorOperationTypeFromString(TempBuffDataStruct->ArrayAffectorOperationType);
		std::vector<std::vector<float> > ArrayArrayAffectorParams = FCWBuffDataUtils::GetArrayArrayAffectorParamsFromString(TempBuffDataStruct->ArrayArrayAffectorParams);
		std::vector<int32> ArrayAffectorDataAffectType = FCWBuffDataUtils::GetArrayAffectorDataAffectTypeFromString(TempBuffDataStruct->ArrayAffectorDataAffectType);
		std::vector<int32> ArrayAffectorDataAffectKeyTimeType = FCWBuffDataUtils::GetArrayAffectorDataAffectKeyTimeTypeFromString(TempBuffDataStruct->ArrayAffectorDataAffectKeyTimeType);
		
		const int32 AffectorIdNum = ArrayAffectorId.size();
		if (AffectorIdNum != TempBuffDataStruct->AffectorNum)
		{
			CWG_ERROR(">> CWBuff::AddPassivityBuff, AffectorIdNum[%d] AffectorNum[%d] BuffId[%d].",
				AffectorIdNum, TempBuffDataStruct->AffectorNum, BuffId);
		}
		for (int i = 0; i < AffectorIdNum; ++i)
		{
			if (ArrayArrayAffectorTriggerConditionType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerConditionType.size() <= i, ArrayArrayAffectorTriggerConditionType.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerConditionType.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorTriggerConditionLogicOp.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerConditionLogicOp.size() <= i, ArrayArrayAffectorTriggerConditionLogicOp.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerConditionLogicOp.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorTriggerConcretenessCondition.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerConcretenessCondition.size() <= i, ArrayArrayAffectorTriggerConcretenessCondition.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerConcretenessCondition.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorTriggerCompareRelatioinOp.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerCompareRelatioinOp.size() <= i, ArrayArrayAffectorTriggerCompareRelatioinOp.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerCompareRelatioinOp.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorTriggerCompareRelatioinOpValueType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerCompareRelatioinOpValueType.size() <= i, ArrayArrayAffectorTriggerCompareRelatioinOpValueType.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerCompareRelatioinOpValueType.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorTriggerConcretenessParams.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorTriggerConcretenessParams.size() <= i, ArrayArrayAffectorTriggerConcretenessParams.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorTriggerConcretenessParams.size(), i, BuffId);
				return false;
			}

			if (ArrayAffectorId.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorId.size() <= i, ArrayAffectorId.size():%d, i:%d BuffId[%d]."), ArrayAffectorId.size(), i, BuffId);
				return false;
			}

			if (ArrayAffectorSubType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorSubType.size() <= i, ArrayAffectorSubType.size():%d, i:%d BuffId[%d]."), ArrayAffectorSubType.size(), i, BuffId);
				return false;
			}

			if (ArrayAffectorOperationType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorOperationType.size() <= i, ArrayAffectorOperationType.size():%d, i:%d BuffId[%d]."), ArrayAffectorOperationType.size(), i, BuffId);
				return false;
			}

			if (ArrayArrayAffectorParams.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayArrayAffectorParams.size() <= i, ArrayArrayAffectorParams.size():%d, i:%d BuffId[%d]."), ArrayArrayAffectorParams.size(), i, BuffId);
				return false;
			}

			if (ArrayAffectorDataAffectType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorDataAffectType.size() <= i, ArrayAffectorDataAffectType.size():%d, i:%d BuffId[%d]."), ArrayAffectorDataAffectType.size(), i, BuffId);
				return false;
			}

			if (ArrayAffectorDataAffectKeyTimeType.size() <= i)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorDataAffectKeyTimeType.size() <= i, ArrayAffectorDataAffectKeyTimeType.size():%d, i:%d BuffId[%d]."), ArrayAffectorDataAffectKeyTimeType.size(), i, BuffId);
				return false;
			}

			std::vector<int32> ArrayAffectorTriggerConditionType = ArrayArrayAffectorTriggerConditionType[i];
			std::vector<int32> ArrayAffectorTriggerConditionLogicOp = ArrayArrayAffectorTriggerConditionLogicOp[i];
			std::vector<int32> ArrayAffectorTriggerConcretenessCondition = ArrayArrayAffectorTriggerConcretenessCondition[i];
			std::vector<int32> ArrayAffectorTriggerCompareRelatioinOp = ArrayArrayAffectorTriggerCompareRelatioinOp[i];
			std::vector<int32> ArrayAffectorTriggerCompareRelatioinOpValueType = ArrayArrayAffectorTriggerCompareRelatioinOpValueType[i];
			std::vector<float> ArrayAffectorTriggerConcretenessParams = ArrayArrayAffectorTriggerConcretenessParams[i];
			int32 TempAffectorId = ArrayAffectorId[i];
			int32 TempAffectorSubType = ArrayAffectorSubType[i];
			int32 TempAffectorOperationType = ArrayAffectorOperationType[i];
			std::vector<float> ArrayAffectorParams = ArrayArrayAffectorParams[i];
			int32 TempAffectorDataAffectType = ArrayAffectorDataAffectType[i];
			int32 TempAffectorDataAffectKeyTimeType = ArrayAffectorDataAffectKeyTimeType[i];

			std::vector<bool> ArrayConditionResult;
			for (int j = 0; j < ArrayAffectorTriggerConditionType.size(); ++j)
			{
				ECWTriggerConditionType TriggerConditionType = (ECWTriggerConditionType)ArrayAffectorTriggerConditionType[j];

				/*if (TriggerConditionType == ECWTriggerConditionType::None)
				{
				ArrayConditionResult.push_back(true);
				}*/

				if (TriggerConditionType == ECWTriggerConditionType::KeyTime)
				{
					if (ArrayAffectorTriggerConcretenessCondition.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerConcretenessCondition.size() <= j, ArrayAffectorTriggerConcretenessCondition.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerConcretenessCondition.size(), j, BuffId);
						return false;
					}

					ECWKeyTimeType TempKeyTimeType = (ECWKeyTimeType)ArrayAffectorTriggerConcretenessCondition[j];
					if (IsSameKeyTime(TempKeyTimeType, ParamKeyTimeType))
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}

				if (TriggerConditionType == ECWTriggerConditionType::Probability)
				{
					if (ArrayAffectorTriggerConcretenessParams.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerConcretenessParams.size() <= j, ArrayAffectorTriggerConcretenessParams.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerConcretenessParams.size(), j, BuffId);
						return false;
					}

					float TempProbability = ArrayAffectorTriggerConcretenessParams[j];
					float TempRandom = RandomFloat(0.0f, 1.0f);
					if (TempRandom <= TempProbability)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);

						UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::GenerateAffector InServer, BuffId:%d Generate Affector fail. Because TempRandom:%f, TempProbability:%f,  AffectorId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffId, TempRandom, TempProbability, TempAffectorId, (int)TempTargetPawn->GetCampTag(), (int)TempTargetPawn->GetCampControllerIndex(), (int)TempTargetPawn->GetControllerPawnIndex());
					}
				}

				if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty ||
					TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
				{
					if (ArrayAffectorTriggerConcretenessCondition.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerConcretenessCondition.size() <= j, ArrayAffectorTriggerConcretenessCondition.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerConcretenessCondition.size(), j, BuffId);
						return false;
					}

					if (ArrayAffectorTriggerCompareRelatioinOp.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerCompareRelatioinOp.size() <= j, ArrayAffectorTriggerCompareRelatioinOp.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerCompareRelatioinOp.size(), j, BuffId);
						return false;
					}

					if (ArrayAffectorTriggerCompareRelatioinOpValueType.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerCompareRelatioinOpValueType.size() <= j, ArrayAffectorTriggerCompareRelatioinOpValueType.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerCompareRelatioinOpValueType.size(), j, BuffId);
						return false;
					}

					if (ArrayAffectorTriggerConcretenessParams.size() <= j)
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayAffectorTriggerConcretenessParams.size() <= j, ArrayAffectorTriggerConcretenessParams.size():%d, j:%d BuffId[%d]."), ArrayAffectorTriggerConcretenessParams.size(), j, BuffId);
						return false;
					}

					ECWBattleProperty TempBattlePropertyType = (ECWBattleProperty)ArrayAffectorTriggerConcretenessCondition[j];
					ECWTriggerConditionTypeRelationOp TempRelationOp = (ECWTriggerConditionTypeRelationOp)ArrayAffectorTriggerCompareRelatioinOp[j];
					ECWTriggerConditionTypeRelationOpValueType TempRelationOpValueType = (ECWTriggerConditionTypeRelationOpValueType)ArrayAffectorTriggerCompareRelatioinOpValueType[j];
					float TempBattlePropertyValue = 0.0f;
					if (TempRelationOpValueType == ECWTriggerConditionTypeRelationOpValueType::Value)
					{
						if (CastSkillContextPtr.IsValid())
						{
							if (CastSkillContextPtr->CastSkillDataStruct->IsPassivitySkill == 1)
							{
								if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty)
									TempBattlePropertyValue = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
								if (TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
									TempBattlePropertyValue = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
							}
							else
							{
								if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty)
									TempBattlePropertyValue = CastSkillContextPtr->PawnCurPropertySet.GetPropertyByFloat(TempBattlePropertyType);
								if (TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
									TempBattlePropertyValue = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
							}
						}
					}
					else if (TempRelationOpValueType == ECWTriggerConditionTypeRelationOpValueType::CurPercentMax)
					{
						if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty)
						{
							if (CastSkillContextPtr.IsValid())
							{
								if (CastSkillContextPtr->CastSkillDataStruct->IsPassivitySkill == 1)
								{
									float TempCurValue = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
									float TempCurMaxTheoreticalValue = TempTargetPawnBattlePropertComponent->GetCurMaxTheoreticalPropertySet().GetPropertyByFloat(TempBattlePropertyType);
									if (FMath::Abs(TempCurMaxTheoreticalValue) > 0.0001f)
									{
										TempBattlePropertyValue = TempCurValue / TempCurMaxTheoreticalValue;
									}
									else
									{
										TempBattlePropertyValue = 0.0f;
									}
								}
								else
								{
									float TempCurValue = CastSkillContextPtr->PawnCurPropertySet.GetPropertyByFloat(TempBattlePropertyType);
									float TempCurMaxTheoreticalValue = CastSkillContextPtr->PawnCurMaxTheoreticalPropertySet.GetPropertyByFloat(TempBattlePropertyType);
									if (FMath::Abs(TempCurMaxTheoreticalValue) > 0.0001f)
									{
										TempBattlePropertyValue = TempCurValue / TempCurMaxTheoreticalValue;
									}
									else
									{
										TempBattlePropertyValue = 0.0f;
									}
								}
							}
						}
						if (TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
						{
							float TempCurValue = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
							float TempCurMaxTheoreticalValue = TempTargetPawnBattlePropertComponent->GetCurMaxTheoreticalPropertySet().GetPropertyByFloat(TempBattlePropertyType);
							if (FMath::Abs(TempCurMaxTheoreticalValue) > 0.0001f)
							{
								TempBattlePropertyValue = TempCurValue / TempCurMaxTheoreticalValue;
							}
							else
							{
								TempBattlePropertyValue = 0.0f;
							}
						}
					}

					float TempParam = ArrayAffectorTriggerConcretenessParams[j];
					if (TempRelationOp == ECWTriggerConditionTypeRelationOp::Equal)
					{
						if (FMath::Abs(TempBattlePropertyValue - TempParam) <= 0.0000001f)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::NoEqual)
					{
						if (FMath::Abs(TempBattlePropertyValue - TempParam) > 0.0000001f)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::LessThan)
					{
						if (TempBattlePropertyValue < TempParam)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::EqualOrLessThan)
					{
						if (TempBattlePropertyValue <= TempParam)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::GreaterThan)
					{
						if (TempBattlePropertyValue > TempParam)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::GreaterOrLessThan)
					{
						if (TempBattlePropertyValue >= TempParam)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else
					{
						UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, TempRelationOp is invalid value, TempRelationOp:%d BuffId[%d]."), (int)TempRelationOp, BuffId);
						return false;
					}
				}

				if (TriggerConditionType == ECWTriggerConditionType::RoundTriggerCount)
				{
					float TempParam = ArrayAffectorTriggerConcretenessParams[j];
					if (CastSkillContextPtr.IsValid() && CastSkillContextPtr->PawnWeakPtr.IsValid())
					{
						if (this->GetTriggerAffectorCountForRound() < TempParam)
						{
							ArrayConditionResult.push_back(true);
						}
						else
						{
							ArrayConditionResult.push_back(false);
						}
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
			}

			if (ArrayConditionResult.size() == 0)
			{
				//return true;
			}
			else if (ArrayConditionResult.size() == 1)
			{
				bool TempResult = ArrayConditionResult[0];
				if (!TempResult)
					continue;
			}
			else
			{
				if (ArrayConditionResult.size() - 1 != ArrayAffectorTriggerConditionLogicOp.size())
				{
					UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, ArrayConditionResult.size() - 1 != ArrayAffectorTriggerConditionLogicOp.size(), ArrayConditionResult.size():%d, ArrayAffectorTriggerConditionLogicOp.size():%d BuffId[%d]."), ArrayConditionResult.size(), ArrayAffectorTriggerConditionLogicOp.size(), BuffId);
					return false;
				}

				bool TempFinalResult = true;
				for (int m = 1; m < ArrayConditionResult.size(); ++m)
				{
					bool TempResult1 = ArrayConditionResult[m - 1];
					bool TempResult2 = ArrayConditionResult[m];
					ECWTriggerConditionTypeLogicOp TempLogicOp = (ECWTriggerConditionTypeLogicOp)ArrayAffectorTriggerConditionLogicOp[m - 1];
					if (TempLogicOp == ECWTriggerConditionTypeLogicOp::And)
					{
						if (TempResult1 && TempResult2)
						{
						}
						else
						{
							TempFinalResult = false;
						}
					}
					else if (TempLogicOp == ECWTriggerConditionTypeLogicOp::Or)
					{
						if (TempResult1 || TempResult2)
						{
						}
						else
						{
							TempFinalResult = false;
						}
					}
				}

				//这个Affector最终是否触发
				if (!TempFinalResult)
					continue;
			}

			FCWAffectorDataStruct* TempAffectorData = FCWCommonUtil::FindCSVRow<FCWAffectorDataStruct>(TEXT("CWAffectorDataTable"), TempAffectorId);
			if (TempAffectorData == nullptr)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector fail, TempAffectorData == nullptr, TempAffectorId:%d BuffId[%d]."), TempAffectorId, BuffId);
				continue;
			}

			UCWAffector* TempAffector = AffectorCreateByAffectorType((ECWAffectorType)(TempAffectorData->AffectorType));
			if (TempAffector != nullptr)
			{
				if (TempAffector->Init(this, TempAffectorId, CastSkillContextPtr))
				{
					TempAffector->SetAffectorSubType(TempAffectorSubType);
					TempAffector->SetAffectorOperationType(TempAffectorOperationType);
					TempAffector->SetArrayAffectorParams(ArrayAffectorParams);
					TempAffector->SetAffectorDataAffectType(TempAffectorDataAffectType);
					TempAffector->SetAffectorDataAffectKeyTimeType(TempAffectorDataAffectKeyTimeType);
					TempAffector->SetAffectorLimitDistanceType(TempBuffDataStruct->AffectorLimitDistanceType);

					TempAffector->OnAffectorBegin();
					if (TempAffector->IsAffectInKeyTime(ParamKeyTimeType))
					{
						TempAffector->OnAffect();
						TempAffector->OnAffectorEnd();
						delete TempAffector;
					}
					else
					{
						AddToMap(TempAffectorId, TempAffector);
					}
					OneMoreSuccess = true;

					UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::GenerateAffector InServer, BuffId:%d Generate Affector Success. AffectorId:%d, BuffDataStruct->LifeType%d, KeyTimeType:%d, Affect to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffId, TempAffectorId, TempBuffDataStruct->LifeType, (int)ParamKeyTimeType, (int)TempTargetPawn->GetCampTag(), (int)TempTargetPawn->GetCampControllerIndex(), (int)TempTargetPawn->GetControllerPawnIndex());

					float TempCurTargetHealth = TempTargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);

					//血量检测
					if (TempCurTargetHealth <= 0.0f)
					{
						TempTargetPawn->DieInServer();
					}
				}
				else
				{
					UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer fail. TempAffector->Init fail, TempAffectorId:%d BuffId[%d]."), TempAffectorId, BuffId);
					delete TempAffector;
					continue;
				}
			}
			else
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, AffectorCreateByAffectorType fail, AffectorType:%d, TempAffectorId:%d BuffId[%d]."), TempAffectorData->AffectorType, TempAffectorId, BuffId);
				return false;
			}
		}

		if (OneMoreSuccess)
			return true;
		else
			return false;
	}
	else
	{
		UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::GenerateAffector InServer, BuffDataStruct->LifeType invalid value, BuffDataStruct->LifeType:%d BuffId[%d]."), TempBuffDataStruct->LifeType, BuffId);
		return false;
	}
}

void UCWBuff::AddToMap(int32 ParamAffectorId, UCWAffector* ParamAffector)
{
	std::map<int32, UCWAffector*>::iterator findIter = MapAffector.find(ParamAffectorId);
	if (findIter != MapAffector.end())
	{
		UCWAffector* TempAffector = findIter->second;
		TempAffector->OnAffectorEnd();
		delete TempAffector;
		MapAffector.erase(findIter);
	}

	MapAffector.insert({ParamAffectorId , ParamAffector});
}

UCWAffector* UCWBuff::AffectorCreateByAffectorType(ECWAffectorType ParamAffectorType)
{
	switch (ParamAffectorType)
	{
	case ECWAffectorType::NativePropertyModify:		// 原生属性修改(HP/SP)
		return new UCWNativePropertyModifyAffector();
		break;
	case ECWAffectorType::BattlePropertyModify:		// 战斗属性修改(ATK/DEF...)
		return new UCWBattlePropertyModifyAffector();
		break;
	case ECWAffectorType::Shield:					// 护盾
		return new UCWShieldAffector();
		break;
	case ECWAffectorType::AttackDamage:				// 攻击伤害型
		return new UCWAttackDamageAffector();
		break;
	case ECWAffectorType::StrengthenNormalAttackDamage:
		return new UCWStrengthenNormalAttackDamageAffector();
		break;
	case ECWAffectorType::ActionAgain:
		return new UCWActionAgainAffector();
		break;
	case ECWAffectorType::ForbidAction:
		return new UCWForbidActionAffector();
		break;
	case ECWAffectorType::BeatBack:
		return new UCWBeatBackAffector();
		break;
	case ECWAffectorType::TakeThePlaceOfSomePawnForFighting:
		return new UCWTakeThePlaceOfSomePawnForFightingAffector();
		break;
	case ECWAffectorType::Dizziness:				// 眩晕型
		return new UCWDizzinessAffector();
		break;
	}

	return nullptr;
}

void UCWBuff::OnBuffBeginInServer()
{
	if (GenerateAffector(ECWKeyTimeType::BuffBegin))
	{
		this->IncreaseTriggerAffectorCountForRound();
	}

	for (std::map<int32, UCWAffector*>::iterator iter = MapAffector.begin(); iter != MapAffector.end(); )
	{
		UCWAffector* TempAffector = iter->second;
		if (TempAffector->IsFinishInKeyTime(ECWKeyTimeType::BuffBegin))
		{
			TempAffector->OnAffectorEnd();

			UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::OnBuffBeginInServer, BuffId:%d Release Affector Success. AffectorId:%d,  Removed from Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffId, TempAffector->GetAffectorId(), (int)ParantBuffManager->GetPawn()->GetCampTag(), (int)ParantBuffManager->GetPawn()->GetCampControllerIndex(), (int)ParantBuffManager->GetPawn()->GetControllerPawnIndex());

			delete TempAffector;
			iter = MapAffector.erase(iter);
		}
		else
		{
			++iter;
		}
	}
}

void UCWBuff::OnBuffEndInServer()
{
	if (GenerateAffector(ECWKeyTimeType::BuffEnd))
	{
		this->IncreaseTriggerAffectorCountForRound();
	}

	for (std::map<int32, UCWAffector*>::iterator iter = MapAffector.begin(); iter != MapAffector.end(); ++iter)
	{
		UCWAffector* TempAffector = iter->second;
		TempAffector->OnAffectorEnd();

		UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::OnBuffEndInServer, BuffId:%d Release Affector Success. AffectorId:%d,  Removed from Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffId, TempAffector->GetAffectorId(), (int)ParantBuffManager->GetPawn()->GetCampTag(), (int)ParantBuffManager->GetPawn()->GetCampControllerIndex(), (int)ParantBuffManager->GetPawn()->GetControllerPawnIndex());

		delete TempAffector;
	}

	MapAffector.clear();
}

void UCWBuff::OnBuffBeginInClient()
{
	check(this->GetBuffManager());
	check(this->GetBuffManager()->GetPawn());
	ACWPawn* TempTargetPawn = this->GetBuffManager()->GetPawn();

	const FCWBuffDataStruct* TempBuffDataStruct = this->GetBuffDataStruct();
	if (GenerateAffector(ECWKeyTimeType::BuffBegin))
	{
		//this->IncreaseTriggerAffectorCountForRound();
	}
	
	std::vector<int32> TempArrayEffectId = FCWSkillDataUtils::GetArrayAttackEffectIdFromString(TempBuffDataStruct->ArrayBuffEffectId);
	for (int i = 0; i < TempArrayEffectId.size(); ++i)
	{
		int32 TempEffectId = TempArrayEffectId[i];
		int32 BuffEffectRefId = TempTargetPawn->AddBuffEffect(TempEffectId);
		if (BuffEffectRefId != INDEX_NONE)
		{
			ListBuffEffectId.push_back(BuffEffectRefId);
		}
	}
}


void UCWBuff::OnBuffEndInClient()
{
	check(this->GetBuffManager());
	check(this->GetBuffManager()->GetPawn());
	ACWPawn* TempTargetPawn = this->GetBuffManager()->GetPawn();

	for (std::list<int32>::iterator iter = ListBuffEffectId.begin(); iter != ListBuffEffectId.end(); ++iter)
	{
		int32 TempBuffEffectId = *iter;
		TempTargetPawn->RemoveBuffEffect(TempBuffEffectId);
	}
	ListBuffEffectId.clear();
}

void UCWBuff::IncreaseTriggerAffectorCountForRound()
{
	TriggerAffectorCountForRound++;
}

int32 UCWBuff::GetTriggerAffectorCountForRound() const
{
	return TriggerAffectorCountForRound;
}

void UCWBuff::OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType)
{
	if (GenerateAffector(ParamKeyTimeType))
	{
		this->IncreaseTriggerAffectorCountForRound();
	}

	for (std::map<int32, UCWAffector*>::iterator iter = MapAffector.begin(); iter != MapAffector.end(); )
	{
		UCWAffector* TempAffector = iter->second;
		if (TempAffector->IsFinishInKeyTime(ParamKeyTimeType))
		{
			TempAffector->OnAffectorEnd();

			UE_LOG(LogCWBuff, Log, TEXT("UCWBuff::OnKeyTimeInServer, KeyTimeType:%d, BuffId:%d Release Affector Success. AffectorId:%d,  Removed from Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)ParamKeyTimeType, BuffId, TempAffector->GetAffectorId(), (int)ParantBuffManager->GetPawn()->GetCampTag(), (int)ParantBuffManager->GetPawn()->GetCampControllerIndex(), (int)ParantBuffManager->GetPawn()->GetControllerPawnIndex());

			delete TempAffector;
			iter = MapAffector.erase(iter);
		}
		else
		{
			++iter;
		}
	}

	if (ParamKeyTimeType == ECWKeyTimeType::NormalAttackEnd)
	{
		TotalNormalAttackCount++;
	}
}

bool UCWBuff::IsSameFinishKeyTime(ECWBuffLifeFinishType ParamLifeFinishType, ECWKeyTimeType ParamKeyTimeType)
{
	if (ParamLifeFinishType == ECWBuffLifeFinishType::NormalAttackCount)
	{
		if (ParamKeyTimeType == ECWKeyTimeType::NormalAttackEnd)
		{
			const FCWBuffDataStruct* TempBuffDataStruct = this->GetBuffDataStruct();
			std::vector<float> ArrayLifeFinishParams = FCWBuffDataUtils::GetArrayLifeFinishParamsFromString(TempBuffDataStruct->ArrayLifeFinishParams);
			if (ArrayLifeFinishParams.size() != 1)
			{
				UE_LOG(LogCWBuff, Error, TEXT("UCWBuff::IsSameFinishKeyTime, ArrayLifeFinishParams.size() != 1, LifeFinishType:%d, KeyTimeType:%d, BuffId:%d, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)ParamLifeFinishType, (int)ParamKeyTimeType, BuffId, (int)ParantBuffManager->GetPawn()->GetCampTag(), (int)ParantBuffManager->GetPawn()->GetCampControllerIndex(), (int)ParantBuffManager->GetPawn()->GetControllerPawnIndex());
				return true;
			}
			float NormalAttackCountParam = ArrayLifeFinishParams[0];
			if (TotalNormalAttackCount >= (int)NormalAttackCountParam)
			{
				return true;
			}
		}
	}

	return false;
}

bool UCWBuff::IsFinishInKeyTime(ECWKeyTimeType ParamKeyTimeType)
{
	const FCWBuffDataStruct* TempBuffDataStruct = GetBuffDataStruct();
	ECWBuffLifeFinishType LifeFinishType = (ECWBuffLifeFinishType)(TempBuffDataStruct->LifeFinishType);
	if (IsSameFinishKeyTime(LifeFinishType, ParamKeyTimeType))
		return true;

	return false;
}

bool UCWBuff::IsSameKeyTime(ECWKeyTimeType ParamKeyTimeType1, ECWKeyTimeType ParamKeyTimeType2)
{
	if (ParamKeyTimeType1 == ParamKeyTimeType2)
	{
		return true;
	}
	else
	{
		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackBegin)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackBegin ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillBegin)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackEnd)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackEnd ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillEnd)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage01)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage02)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage03)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackAllDamage ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillAllDamage)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::NormalAttackAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackAllDamage)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeSkillAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillAllDamage)
			{
				return true;
			}
		}

		return false;
	}
}

bool UCWBuff::CheckAndConsumeShield(const int32 InDamageValue, 
	const bool bIsHasImmediatelyUsing, TSharedPtr<UCWCastSkillContext> InCastSkillContext)
{
	check(ParantBuffManager);

	std::map<int32, UCWAffector*>::iterator Iter = MapAffector.begin();
	for (; Iter != MapAffector.end(); ++Iter)
	{
		UCWAffector* TmpAffector = Iter->second;
		if (nullptr != TmpAffector && TmpAffector->IsAffectorType(ECWAffectorType::Shield))
		{	// 防御护盾
			UCWShieldAffector* ShieldAffector = static_cast<UCWShieldAffector*>(TmpAffector);
			if (bIsHasImmediatelyUsing && ShieldAffector->ConsumeShield(InCastSkillContext))
			{
				delete TmpAffector;
				MapAffector.erase(Iter);

				// 通知客户端移除
				if (ACWPawn* OwnerPawn = ParantBuffManager->GetPawn())
				{
					OwnerPawn->NetMulticastRPCRemoveBuff(BuffUniqueId, BuffId);
					//ParantBuffManager->RemoveBuffInClient(BuffUniqueId, BuffId);
				}
			}
			return true;
		}
	}
	return false;
}

ECWBuffSouceType UCWBuff::GetSouceType() const
{
	return SouceType;
}

void UCWBuff::SetSouceType(const ECWBuffSouceType InSouceType)
{
	SouceType = InSouceType;
}

void UCWBuff::SetCurRemainLifeRoundCount(const int32 InRemain)
{
	CurRemainLifeRoundCount = InRemain;
}

void UCWBuff::OnUpdateBuffData()
{
	// 更新剩余回合数
	ACWPawn* OwnerPawn = ParantBuffManager ? ParantBuffManager->GetPawn() : nullptr;
	if (nullptr != OwnerPawn && OwnerPawn->IsInServer())
	{
		OwnerPawn->NetMulticastUpdateBuff(BuffUniqueId, BuffId, CurRemainLifeRoundCount);
	}
}
