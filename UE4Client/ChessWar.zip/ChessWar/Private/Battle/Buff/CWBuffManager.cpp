
#include "CWBuffManager.h"

#include "CWPawn.h"
#include "CWBuff.h"
#include "CWSkill.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWUIDefine.h"
#include "CWCommonUtil.h"
#include "CWBuffDataStruct.h"
#include "CWSkillDataUtils.h"
#include "CWPawnDataStruct.h"
#include "CWBuffDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWPawnBattlePropertyComponent.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBuffManager, All, All);

UCWBuffManager::UCWBuffManager(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	BuffUniqueIdGenerator = 0;
}

//UCWBuffManager::~UCWBuffManager()
//{
//	
//}

void UCWBuffManager::DestoryAll()
{
	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		for (std::list<UCWBuff*>::iterator subIter = ListBuff->begin(); subIter != ListBuff->end(); ++subIter)
		{
			UCWBuff* TempBuff = *subIter;
			check(TempBuff);
			delete TempBuff;
		}

		ListBuff->clear();
		delete ListBuff;
	}

	MapListBuff.clear();


	for(std::list<UCWBuff*>::iterator iter = ListPassivityBuff.begin(); iter != ListPassivityBuff.end(); ++iter)
	{
		UCWBuff* TempPassivityBuff = *iter;
		check(TempPassivityBuff);
		delete TempPassivityBuff;
	}
	ListPassivityBuff.clear();
}

bool UCWBuffManager::ResetForRound()
{
	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		for (std::list<UCWBuff*>::iterator subIter = ListBuff->begin(); subIter != ListBuff->end(); ++subIter)
		{
			UCWBuff* TempBuff = *subIter;
			check(TempBuff);
			TempBuff->ResetForRound();
		}
	}

	for (std::list<UCWBuff*>::iterator iter = ListPassivityBuff.begin(); iter != ListPassivityBuff.end(); ++iter)
	{
		UCWBuff* TempPassivityBuff = *iter;
		TempPassivityBuff->ResetForRound();
	}

	return true;
}

bool UCWBuffManager::Init(ACWPawn* ParamParentPawn)
{
	ParentPawn = ParamParentPawn;
	return true;
}

bool UCWBuffManager::AddBuffInServer(UCWBuff* ParamBuff)
{
	check(ParamBuff);
	check(ParentPawn);

	const FCWBuffDataStruct* BuffData = ParamBuff->GetBuffDataStruct();
	if ((BuffData->LifeType == 1 && BuffData->LifeRoundCount > 0) ||
		(BuffData->LifeType == 0))
	{
		int32 TempTotalBuffSizeFromDifferentBuffId = GetTotalBuffSizeFromDifferentBuffId();
		if (TempTotalBuffSizeFromDifferentBuffId >= MAX_PAWN_BUFF)
		{
			//替换不同BuffId的Buff
			int32 RepacedBuffIdByDifferentBuffId = FindReplacedBuffIdByDifferentBuffId(ParamBuff->GetBuffId());
			if (RepacedBuffIdByDifferentBuffId == -1)
			{
				UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::AddBuffInServer, RepacedBuffIdByDifferentBuffId == -1, BuffId:%d, BuffUniqueId:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
				return false;
			}

			if (!RemoveBuffByDifferentBuffId(RepacedBuffIdByDifferentBuffId))
			{
				return false;
			}

			if (!AddBuffToSameBuffId(ParamBuff))
			{
				return false;
			}
		}
		else
		{
			if (!AddBuffToSameBuffId(ParamBuff))
			{
				return false;
			}
		}

		ParamBuff->OnBuffBeginInServer();
		ParentPawn->NetMulticastRPCAddBuff(ParamBuff->GetBuffUniqueId(), ParamBuff->GetBuffId(), ParamBuff->GetSouceType());
		return true;
	}
	else if (BuffData->LifeType == 1 && BuffData->LifeRoundCount == 0)
	{
		TSharedPtr<UCWCastSkillContext> CasterSkillContext = ParamBuff->GetCastSkillContext();
		const int32 CasterSkillId = CasterSkillContext.IsValid() ? CasterSkillContext->CastSkillDataStruct->SkillId : INDEX_NONE;

		UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::AddBuffInServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

		ParamBuff->OnBuffBeginInServer();
		ParamBuff->OnBuffEndInServer();

		UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::AddBuffInServer, LifeType == 1 && LifeRoundCount == 0, TempBuff Removed success, BuffId:%d, BuffUniqueId:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

		delete ParamBuff;
		return true;
	}
	else
	{
		UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::AddBuffInServer, AddBuff fail, LifeType:%d, LifeRoundCount:%d, BuffId:%d, BuffUniqueId:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), BuffData->LifeType, BuffData->LifeRoundCount, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
		return false;
	}
}

bool UCWBuffManager::AddBuffInClient(UCWBuff* ParamBuff)
{
	check(ParamBuff);
	check(ParentPawn);

	std::map<int32, std::list<UCWBuff*>*>::iterator iterFind = MapListBuff.find(ParamBuff->GetBuffId());
	if (iterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = iterFind->second;

		//添加
		ListBuff->push_back(ParamBuff);

		ParamBuff->OnBuffBeginInClient();
		return true;
	}
	else
	{
		//添加
		std::list<UCWBuff*>* NewListBuff = new std::list<UCWBuff*>();
		if (NewListBuff != nullptr)
		{
			NewListBuff->push_back(ParamBuff);
			int32 TempBuffId = ParamBuff->GetBuffId();
			MapListBuff.insert({ TempBuffId, NewListBuff });

			ParamBuff->OnBuffBeginInClient();
			return true;
		}
		else
		{
			UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::AddBuffInClient fail. NewListBuff == nullptr, BuffId:%d."), ParamBuff->GetBuffId());
			return false;
		}
	}
}

void UCWBuffManager::RemoveBuffInServer(int32 InBuffUniqueId, int32 InBuffId)
{
	std::map<int32, std::list<UCWBuff*>*>::iterator IterFind = MapListBuff.find(InBuffId);
	if (IterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = IterFind->second;

		for (std::list<UCWBuff*>::iterator IterSub = ListBuff->begin(); IterSub != ListBuff->end(); ++IterSub)
		{
			UCWBuff* TempBuff = *IterSub;
			check(TempBuff);
			if (TempBuff->GetBuffUniqueId() == InBuffUniqueId)
			{
				TempBuff->OnBuffEndInServer();

				delete TempBuff;
				ListBuff->erase(IterSub);
				break;
			}
		}
	}
}

void UCWBuffManager::RemoveBuffInClient(int32 ParamBuffUniqueId, int32 ParamBuffId)
{
	std::map<int32, std::list<UCWBuff*>*>::iterator iterFind = MapListBuff.find(ParamBuffId);
	if (iterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = iterFind->second;

		for (std::list<UCWBuff*>::iterator iterSub = ListBuff->begin(); iterSub != ListBuff->end(); ++iterSub)
		{
			UCWBuff* TempBuff = *iterSub;
			check(TempBuff);
			if (TempBuff->GetBuffUniqueId() == ParamBuffUniqueId)
			{
				TempBuff->OnBuffEndInClient();
				delete TempBuff;
				ListBuff->erase(iterSub);
				return;
			}
		}
	}
}

void UCWBuffManager::OnUpdateBuffInClient(const int32 InBuffUniqueId, const int32 InBuffId, const int32 InRemain)
{
	std::map<int32, std::list<UCWBuff*>*>::iterator Iter = MapListBuff.find(InBuffId);
	if (Iter != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = Iter->second;
		std::list<UCWBuff*>::iterator IterSub = ListBuff->begin();
		for (; IterSub != ListBuff->end(); ++IterSub)
		{
			UCWBuff* TempBuff = *IterSub;
			if (TempBuff->GetBuffUniqueId() == InBuffUniqueId)
			{
				TempBuff->SetCurRemainLifeRoundCount(InRemain);
				break;
			}
		}
	}
}

bool UCWBuffManager::AddPassivityBuff(UCWSkill* ParamPassivitySkill)
{
	check(ParamPassivitySkill);
	const FCWSkillDataStruct* PassivitySkillData = ParamPassivitySkill->GetSkillDataStruct();
	if (PassivitySkillData->IsPassivitySkill == 0)
		return false;

	check(ParentPawn);
	//-------------------------------------------------------------------------
	//施法上下文
	UCWPawnBattlePropertyComponent* MyPawnBattlePropertComponent = ParentPawn->GetBattleProperty();
	check(MyPawnBattlePropertComponent);

	FCWBattlePropertySet TempSkillPropertySet;
	TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::UniqueId, ParentPawn->GetPawnUniqueIdx());
	TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::Profession, ParentPawn->GetProfession());
	TempSkillPropertySet.SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

	TSharedPtr<UCWCastSkillContext> NewCastSkillContextForBuff = TSharedPtr<UCWCastSkillContext>(new UCWCastSkillContext());
	NewCastSkillContextForBuff->PawnWeakPtr = ParentPawn;
	NewCastSkillContextForBuff->CastSkillPropertySet = TempSkillPropertySet;
	NewCastSkillContextForBuff->CastSkillDataStruct = ParamPassivitySkill->GetSkillDataStruct();
	NewCastSkillContextForBuff->PawnPropertySetBase = MyPawnBattlePropertComponent->GetPropertySetBase();
	NewCastSkillContextForBuff->CopyMapStatisticsData(ParentPawn->GetStatisticsSysMapData());
	NewCastSkillContextForBuff->CopyArrayAffectorData(MyPawnBattlePropertComponent->GetArrayPropertyAffectorData());
	NewCastSkillContextForBuff->PawnCurMaxTheoreticalPropertySet = MyPawnBattlePropertComponent->GetCurMaxTheoreticalPropertySet();
	NewCastSkillContextForBuff->PawnCurPropertySet = MyPawnBattlePropertComponent->GetCurPropertySet();
	//-------------------------------------------------------------------------
	// BUFF来源设置
	const ECWSkillSouceType SkillSouceType = ParamPassivitySkill->GetSouceType();
	ECWBuffSouceType BuffSouceType = ToBuffSouceType(SkillSouceType);

	std::vector<int32> ArrayBuffId = FCWSkillDataUtils::GetArrayBuffIdFromString(PassivitySkillData->ArrayBuffId);
	if (ArrayBuffId.size() != PassivitySkillData->BuffNum)
	{
		CWG_ERROR(">> %s::AddPassivityBuff, ArrayBuffId.size[%d] BuffNum[%d] SkillId[%d].", 
			*GetName(), ArrayBuffId.size(), PassivitySkillData->BuffNum, PassivitySkillData->SkillId);
	}
	for (int i = 0; i < ArrayBuffId.size(); ++i)
	{
		const int32 TempBuffId = ArrayBuffId[i];
		const FCWBuffDataStruct* BuffData = FCWCfgUtils::GetBuffData(this, TempBuffId);
		if (nullptr == BuffData)
		{
			CWG_ERROR(">> %s::AddPassivityBuff, ERROR! SkillSouceType[%s] TempBuffId[%d] not found.", 
				*GetName(), *FCWToString::ToString(SkillSouceType), TempBuffId);
			continue;
		}

		UCWBuff* TempBuff = new UCWBuff();
		if (TempBuff != nullptr)
		{
			int TempBuffUniqueId = GenerateBuffUniqueId();
			TempBuff->SetSouceType(BuffSouceType);
			if (TempBuff->InitInServer(this, TempBuffUniqueId, TempBuffId, NewCastSkillContextForBuff))
			{
				TempBuff->OnBuffBeginInServer();
				ListPassivityBuff.push_back(TempBuff);
				return true;
			}
		}
	}
	
	return false;
}

void UCWBuffManager::RemovePassivityBuff(UCWSkill* ParamPassivitySkill)
{
	for (std::list<UCWBuff*>::iterator iter = ListPassivityBuff.begin(); iter != ListPassivityBuff.end(); ++iter)
	{
		UCWBuff* TempBuff = *iter;
		TSharedPtr<UCWCastSkillContext> CasterSkillContext = TempBuff->GetCastSkillContext();
		const int32 CasterSkillId = CasterSkillContext.IsValid() ? CasterSkillContext->CastSkillDataStruct->SkillId : INDEX_NONE;
		if (ParamPassivitySkill->GetSkillId() == CasterSkillId)
		{
			delete TempBuff;
			ListPassivityBuff.erase(iter);
			break;
		}
	}
}

void UCWBuffManager::RemovePassivityBuffInClient(const int32 InBuffUniqueId, const int32 InBuffId)
{
	std::list<UCWBuff*>::iterator Iter = ListPassivityBuff.begin();
	for (; Iter != ListPassivityBuff.end(); ++Iter)
	{
		UCWBuff* TempBuff = *Iter;
		check(TempBuff);
		if (TempBuff->GetBuffUniqueId() == InBuffUniqueId && TempBuff->GetBuffId() == InBuffId)
		{
			const int32 OwnerUniqueIdx = (ParentPawn ? ParentPawn->GetPawnUniqueIdx() : INDEX_NONE);
			CWG_LOG(">> %s::RemovePassivityBuffInClient, OwnerUniqueIdx[%d] InBuffUniqueId[%d] InBuffId[%d].", *GetName(), OwnerUniqueIdx, InBuffUniqueId, InBuffId);
			TempBuff->OnBuffEndInClient();
			delete TempBuff;
			ListPassivityBuff.erase(Iter);
			break;
		}
	}
}

bool UCWBuffManager::GetBuffInfoList(TArray<FUIBuffNodeData>& OutList)
{
	OutList.Empty();
	
	std::map<int32, std::list<UCWBuff*>*>::iterator Iter = MapListBuff.begin();
	for (; Iter != MapListBuff.end(); ++Iter)
	{
		const int32 BuffId = Iter->first;
		const int32 LayerNum = Iter->second ? Iter->second->size() : INDEX_NONE;
		const FCWBuffDataStruct* BuffData = FCWCfgUtils::GetBuffData(this, BuffId);
		if (nullptr == BuffData || LayerNum <= 0)
		{
			continue;
		}

		std::list<UCWBuff*>* BuffList = Iter->second;
		std::list<UCWBuff*>::iterator IterSub = BuffList->begin();
		for (; IterSub != BuffList->end(); ++IterSub)
		{
			UCWBuff* MyBuff = *IterSub;
			if (nullptr != MyBuff)
			{
				const int32 BuffRemain = MyBuff->GetCurRemainLifeRoundCount();
				FUIBuffNodeData NodeData = FUIBuffNodeData(BuffId, LayerNum, BuffRemain, *BuffData);
				OutList.Add(NodeData);

				//CWG_WARNING(">> %s::GetBuffInfoList, BuffId[%d] LayerNum[%d].", *GetName(), BuffId, LayerNum);
			}
		}
	}

	return true;
}


int32 UCWBuffManager::CheckAndConsumeShield(const int32 InDamageValue, 
	const bool bIsHasImmediatelyUsing, TSharedPtr<UCWCastSkillContext> InCastSkillContext)
{
	if (InDamageValue <= 0)
	{
		return 0;
	}

	int32 NeedReceiveDamage = InDamageValue;
	std::map<int32, std::list<UCWBuff*>*>::iterator Iter = MapListBuff.begin();
	for (; Iter != MapListBuff.end(); ++Iter)
	{
		std::list<UCWBuff*>* BuffList = Iter->second;
		std::list<UCWBuff*>::iterator IterSub = BuffList->begin();
		for (; IterSub != BuffList->end(); ++IterSub)
		{
			UCWBuff* MyBuff = *IterSub;
			if (nullptr != MyBuff && MyBuff->CheckAndConsumeShield(InDamageValue, bIsHasImmediatelyUsing, InCastSkillContext))
			{	// 有护盾直接不伤害
				return 0;
			}
		}
	}
	return NeedReceiveDamage;
}

ECWBuffSouceType UCWBuffManager::ToBuffSouceType(const ECWSkillSouceType InSkillSouceType)
{
	ECWBuffSouceType BuffSouceType = ECWBuffSouceType::None;
	switch (InSkillSouceType)
	{
	case ECWSkillSouceType::Skill:	{ BuffSouceType = ECWBuffSouceType::Skill; } break;
	case ECWSkillSouceType::TalentSys: { BuffSouceType = ECWBuffSouceType::TalentSys; } break;
	}
	return BuffSouceType;
}

int UCWBuffManager::GenerateBuffUniqueId()
{
	return ++BuffUniqueIdGenerator;
}


ACWPawn* UCWBuffManager::GetPawn()
{
	return ParentPawn;
}

void UCWBuffManager::OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType)
{
	check(ParentPawn);

	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		for (std::list<UCWBuff*>::iterator subIter = ListBuff->begin(); subIter != ListBuff->end(); ++subIter)
		{
			UCWBuff* TempBuff = *subIter;
			check(TempBuff);
			TempBuff->OnKeyTimeInServer(ParamKeyTimeType);
		}
	}

	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		for (std::list<UCWBuff*>::iterator subIter = ListBuff->begin(); subIter != ListBuff->end(); )
		{
			UCWBuff* TempBuff = *subIter;
			check(TempBuff);
			if (TempBuff->IsFinishInKeyTime(ParamKeyTimeType))
			{
				TempBuff->OnBuffEndInServer();
				ParentPawn->NetMulticastRPCRemoveBuff(TempBuff->GetBuffUniqueId(), TempBuff->GetBuffId());

				UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::OnKeyTimeInServer InServer, IsFinishInKeyTime, KeyTimeType:%d, TempBuff Removed success, BuffId:%d, BuffUniqueId:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)ParamKeyTimeType, TempBuff->GetBuffId(), TempBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

				delete TempBuff;
				TempBuff = nullptr;
				subIter = ListBuff->erase(subIter);
			}
			else
			{
				++subIter;
			}
		}
	}

	for (std::list<UCWBuff*>::iterator iter = ListPassivityBuff.begin(); iter != ListPassivityBuff.end(); ++iter)
	{
		UCWBuff* TempPassivityBuff = *iter;
		check(TempPassivityBuff);
		TempPassivityBuff->OnKeyTimeInServer(ParamKeyTimeType);
	}

	// 检测所有回合BUFF剩余回合
	if (ParamKeyTimeType == ECWKeyTimeType::TurnEnd)
	{
		DecreaseAllBuffRemainLifeRoundCount();
	}
}

void UCWBuffManager::DecreaseAllBuffRemainLifeRoundCount()
{
	check(ParentPawn);

	// 普通BUFF
	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		for (std::list<UCWBuff*>::iterator subIter = ListBuff->begin(); subIter != ListBuff->end();)
		{
			UCWBuff* TempBuff = *subIter;
			check(TempBuff);

			const FCWBuffDataStruct* BuffData = TempBuff->GetBuffDataStruct();
			if (BuffData->LifeType == 1)
			{
				TempBuff->DecreaseRemainLifeRoundCount();

				if (TempBuff->GetCurRemainLifeRoundCount() <= 0)
				{
					TempBuff->OnBuffEndInServer();
					ParentPawn->NetMulticastRPCRemoveBuff(TempBuff->GetBuffUniqueId(), TempBuff->GetBuffId());
					UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::DecreaseAllBuffRemainLifeRoundCount InServer, TempBuff Removed success, BuffId:%d, BuffUniqueId:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), TempBuff->GetBuffId(), TempBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

					delete TempBuff;
					TempBuff = nullptr;
					subIter = ListBuff->erase(subIter);
				}
				else
				{
					++subIter;
				}
			}
		}
	}

	// 被动BUFF
	std::list<UCWBuff*>::iterator IterPassivity = ListPassivityBuff.begin();
	for (; IterPassivity != ListPassivityBuff.end(); )
	{
		UCWBuff* TempBuff = *IterPassivity;
		check(TempBuff);

		const FCWBuffDataStruct* BuffData = TempBuff->GetBuffDataStruct();
		if (BuffData->LifeType == 1 && BuffData->LifeRoundCount > INDEX_NONE)
		{
			TempBuff->DecreaseRemainLifeRoundCount();

			if (TempBuff->GetCurRemainLifeRoundCount() <= 0)
			{
				TempBuff->OnBuffEndInServer();
				ParentPawn->NetMulticastRemovePassivityBuff(TempBuff->GetBuffUniqueId(), TempBuff->GetBuffId());
				CWG_LOG(">> %s::DecreaseAllBuffRemainLifeRoundCount, [InServer], Remove Passivity-Buff, PawnUniqueIdx[%d] BuffId[%d] BuffUniqueId[%d].", 
					*GetName(), ParentPawn->GetPawnUniqueIdx(), TempBuff->GetBuffId(), TempBuff->GetBuffUniqueId());

				delete TempBuff;
				TempBuff = nullptr;
				IterPassivity = ListPassivityBuff.erase(IterPassivity);
				continue;
			}
		}

		++IterPassivity;
	}
}

int32 UCWBuffManager::FindReplacedBuffIdByDifferentBuffId(int ParamBuffId)
{
	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);

		if (ListBuff->empty())
			continue;

		return ListBuff->back()->GetBuffId();
	}

	return -1;
}

bool UCWBuffManager::RemoveBuffByDifferentBuffId(int32 ParamBuffId)
{
	check(ParentPawn);
	std::map<int32, std::list<UCWBuff*>*>::iterator iterFind = MapListBuff.find(ParamBuffId);
	if (iterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = iterFind->second;
		check(ListBuff);
		if (ListBuff->empty())
		{
			UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::RemoveBuffByDifferentBuffId fail. ListBuff->empty(), BuffId:%d."), ParamBuffId);
			return false;
		}
		else if (ListBuff->size() == 1)
		{
			UCWBuff* OldBuff = ListBuff->back();
			check(OldBuff);
			OldBuff->OnBuffEndInServer();
			ParentPawn->NetMulticastRPCRemoveBuff(OldBuff->GetBuffUniqueId(), OldBuff->GetBuffId());

			UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::RemoveBuffByDifferentBuffId 1 InServer, OldBuff Removed success, OldBuffId:%d, OldBuffUniqueId:%d, TotalBuffSize:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), OldBuff->GetBuffId(), OldBuff->GetBuffUniqueId(), GetTotalBuffSizeFromDifferentBuffId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

			delete OldBuff;
			OldBuff = nullptr;
			ListBuff->clear();

			delete ListBuff;
			MapListBuff.erase(iterFind);
			return true;
		}
		else
		{
			std::qsort(ListBuff, ListBuff->size(), sizeof(ListBuff[0]), &UCWBuffManager::BuffRemainLifeRoundCompare);
			UCWBuff* OldBuff = ListBuff->front();
			OldBuff->OnBuffEndInServer();
			ParentPawn->NetMulticastRPCRemoveBuff(OldBuff->GetBuffUniqueId(), OldBuff->GetBuffId());

			UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::RemoveBuffByDifferentBuffId 2 InServer, OldBuff Removed success, OldBuffId:%d, OldBuffUniqueId:%d, TotalBuffSize:%d,  Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), OldBuff->GetBuffId(), OldBuff->GetBuffUniqueId(), GetTotalBuffSizeFromDifferentBuffId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

			delete OldBuff;
			OldBuff = nullptr;
			ListBuff->pop_front();
			return true;
		}
	}
	else
	{
		UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::RemoveBuffByDifferentBuffId fail. iterFind == MapListBuff.end(), BuffId:%d."), ParamBuffId);
		return false;
	}
}

int32 UCWBuffManager::GetTotalBuffSizeFromDifferentBuffId()
{
	int32 TempTotalBuffSize = 0;
	for (std::map<int32, std::list<UCWBuff*>*>::iterator iter = MapListBuff.begin(); iter != MapListBuff.end(); ++iter)
	{
		std::list<UCWBuff*>* ListBuff = iter->second;
		check(ListBuff);
		if (ListBuff->empty())
			continue;

		TempTotalBuffSize++;
	}

	return TempTotalBuffSize;
}

bool UCWBuffManager::AddBuffToSameBuffId(UCWBuff* ParamBuff)
{
	check(ParamBuff);
	TSharedPtr<UCWCastSkillContext> CasterSkillContext = ParamBuff->GetCastSkillContext();
	const int32 CasterSkillId = CasterSkillContext.IsValid() ? CasterSkillContext->CastSkillDataStruct->SkillId : INDEX_NONE;

	std::map<int32, std::list<UCWBuff*>*>::iterator iterFind = MapListBuff.find(ParamBuff->GetBuffId());
	if (iterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = iterFind->second;
		if (ListBuff->size() > 0)
		{
			if (ListBuff->size() >= ParamBuff->GetBuffDataStruct()->OverlayCount)
			{
				//大于或等于叠加数量

				//替换相同BuffId的Buff
				if (!ReplacedBuffBySameBuffId(ParamBuff))
				{
					return false;
				}

				return true;
			}
			else
			{
				//小于叠加数量

				//添加
				ListBuff->push_back(ParamBuff);
				UE_LOG(LogCWBuffManager, Log, TEXT("ACWPawn::AddBuffToSameBuffId InServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
				return true;
			}
		}
		else
		{
			//添加
			ListBuff->push_back(ParamBuff);
			UE_LOG(LogCWBuffManager, Log, TEXT("ACWPawn::AddBuffToSameBuffId InServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
			return true;
		}
	}
	else
	{
		//添加
		std::list<UCWBuff*>* NewListBuff = new std::list<UCWBuff*>();
		if (NewListBuff != nullptr)
		{
			NewListBuff->push_back(ParamBuff);
			int32 TempBuffId = ParamBuff->GetBuffId();
			MapListBuff.insert({ TempBuffId, NewListBuff });

			UE_LOG(LogCWBuffManager, Log, TEXT("ACWPawn::AddBuffToSameBuffId InServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
			return true;
		}
		else
		{
			UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::AddBuffToSameBuffId fail. NewListBuff == nullptr, BuffId:%d."), ParamBuff->GetBuffId());
			return false;
		}
	}
}

int UCWBuffManager::BuffRemainLifeRoundCompare(const void* ParamBuff1, const void* ParamBuff2)
{
	UCWBuff* Buff1 = (UCWBuff*) ParamBuff1;
	UCWBuff* Buff2 = (UCWBuff*) ParamBuff2;
	const FCWBuffDataStruct* BuffData1 = Buff1->GetBuffDataStruct();
	const FCWBuffDataStruct* BuffData2 = Buff2->GetBuffDataStruct();

	if (BuffData1->LifeType == 1 && BuffData2->LifeType == 1)
	{
		if (Buff1->GetCurRemainLifeRoundCount() < Buff2->GetCurRemainLifeRoundCount())
			return -1;
		else if (Buff1->GetCurRemainLifeRoundCount() > Buff2->GetCurRemainLifeRoundCount())
			return 1;
		else
			return 0;
	}
	else
	{
		if (BuffData2->LifeType == 1)
			return -1;
		else if (BuffData1->LifeType == 1)
			return 1;
		else
			return 0;
	}
}

bool UCWBuffManager::ReplacedBuffBySameBuffId(UCWBuff* ParamBuff)
{
	check(ParamBuff);
	check(ParentPawn);

	TSharedPtr<UCWCastSkillContext> CasterSkillContext = ParamBuff->GetCastSkillContext();
	const int32 CasterSkillId = CasterSkillContext.IsValid() ? CasterSkillContext->CastSkillDataStruct->SkillId : INDEX_NONE;
	
	std::map<int32, std::list<UCWBuff*>*>::iterator iterFind = MapListBuff.find(ParamBuff->GetBuffId());
	if (iterFind != MapListBuff.end())
	{
		std::list<UCWBuff*>* ListBuff = iterFind->second;
		if (ListBuff->size() == 0)
		{
			ListBuff->push_back(ParamBuff);
		}
		else if (ListBuff->size() == 1)
		{
			UCWBuff* OldBuff = ListBuff->back();
			check(OldBuff);
			OldBuff->OnBuffEndInServer();
			ParentPawn->NetMulticastRPCRemoveBuff(OldBuff->GetBuffUniqueId(), OldBuff->GetBuffId());

			UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::ReplacedBuffBySameBuffId 1 InServer, OldBuff Removed success, OldBuffId:%d, OldBuffUniqueId:%d, Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), OldBuff->GetBuffId(), OldBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

			delete OldBuff;
			OldBuff = nullptr;
			ListBuff->clear();
			ListBuff->push_back(ParamBuff);

			UE_LOG(LogCWBuffManager, Log, TEXT("ACWPawn::ReplacedBuffBySameBuffId InServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
		}
		else
		{
			std::qsort(ListBuff, ListBuff->size(), sizeof(ListBuff[0]), &UCWBuffManager::BuffRemainLifeRoundCompare);
			UCWBuff* OldBuff = ListBuff->front();
			OldBuff->OnBuffEndInServer();
			ParentPawn->NetMulticastRPCRemoveBuff(OldBuff->GetBuffUniqueId(), OldBuff->GetBuffId());

			UE_LOG(LogCWBuffManager, Log, TEXT("UCWBuffManager::ReplacedBuffBySameBuffId 2 InServer, OldBuff Removed success, OldBuffId:%d, OldBuffUniqueId:%d, Pawn  CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), OldBuff->GetBuffId(), OldBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());

			delete OldBuff;
			OldBuff = nullptr;
			ListBuff->pop_front();
			ListBuff->push_back(ParamBuff);

			UE_LOG(LogCWBuffManager, Log, TEXT("ACWPawn::ReplacedBuffBySameBuffId InServer, SkillId:%d Generate Buff Success. BuffId:%d, BuffUniqueId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), CasterSkillId, ParamBuff->GetBuffId(), ParamBuff->GetBuffUniqueId(), (int)ParentPawn->GetCampTag(), (int)ParentPawn->GetCampControllerIndex(), (int)ParentPawn->GetControllerPawnIndex());
		}
		return true;
	}
	else
	{
		UE_LOG(LogCWBuffManager, Error, TEXT("UCWBuffManager::ReplacedBuffBySameBuffId fail. iterFind == MapListBuff.end(), BuffId:%d."), ParamBuff->GetBuffId());
		return false;
	}
}