#include "CWBuffDataStruct.h"

FCWBuffDataStruct::FCWBuffDataStruct()
	: BuffId(0)
	, bAffactImmediatelyWhenBuffBegin(false)
	, IsDebuff(0)
	, LifeType(0)
	, LifeRoundCount(0)
	, AffactRoundTimeType(0)
	, LifeFinishType(0)
	, OverlayCount(0)
	, ReplaceType(0)
	, SkillNum(0)
	, AffectorNum(0)
{
	AffectorLimitDistanceType = 0;
}

FCWBuffDataStruct::~FCWBuffDataStruct()
{
}