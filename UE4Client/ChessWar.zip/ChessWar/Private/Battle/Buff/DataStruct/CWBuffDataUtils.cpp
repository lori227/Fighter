#include "CWBuffDataUtils.h"

std::vector<int32> FCWBuffDataUtils::GetArrayBuffIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayBuffId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempBuffId = FCString::Atoi(*TempString);
		ArrayBuffId.push_back(TempBuffId);
	}

	return ArrayBuffId;
}

std::vector<std::vector<int32> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerConditionType(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionType;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConditionType.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCondintionType = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConditionType.back().push_back(TempBuffTriggerCondintionType);
		}
	}

	return ArrayArrayBuffTriggerConditionType;
}

std::vector<std::vector<int32> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerConditionLogicOp(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionLogicOp;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConditionLogicOp.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerConditionLogicOp = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConditionLogicOp.back().push_back(TempBuffTriggerConditionLogicOp);
		}
	}

	return ArrayArrayBuffTriggerConditionLogicOp;
}


std::vector<std::vector<int32> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerConcretenessCondition(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConcretenessCondition;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConcretenessCondition.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerConcretenessCondition = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConcretenessCondition.back().push_back(TempBuffTriggerConcretenessCondition);
		}
	}

	return ArrayArrayBuffTriggerConcretenessCondition;
}

std::vector<std::vector<int32> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerCompareRelatioinOp(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOp;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerCompareRelatioinOp.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCompareRelatioinOp = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerCompareRelatioinOp.back().push_back(TempBuffTriggerCompareRelatioinOp);
		}
	}

	return ArrayArrayBuffTriggerCompareRelatioinOp;
}

std::vector<std::vector<int32> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerCompareRelatioinOpValueType(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOpValueType;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerCompareRelatioinOpValueType.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCompareRelatioinOpValueType = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerCompareRelatioinOpValueType.back().push_back(TempBuffTriggerCompareRelatioinOpValueType);
		}
	}

	return ArrayArrayBuffTriggerCompareRelatioinOpValueType;
}


std::vector<std::vector<float> > FCWBuffDataUtils::GetArrayArrayAffectorTriggerConcretenessParams(const FString& ParamString)
{
	std::vector<std::vector<float> > ArrayArrayBuffTriggerConcretenessParams;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConcretenessParams.push_back(std::vector<float>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			float TempBuffTriggerConcretenessParam = FCString::Atof(*TempString2);
			ArrayArrayBuffTriggerConcretenessParams.back().push_back(TempBuffTriggerConcretenessParam);
		}
	}

	return ArrayArrayBuffTriggerConcretenessParams;
}

std::vector<int32> FCWBuffDataUtils::GetArrayAffectorIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayBuffId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempBuffId = FCString::Atoi(*TempString);
		ArrayBuffId.push_back(TempBuffId);
	}

	return ArrayBuffId;
}

std::vector<int32> FCWBuffDataUtils::GetArrayAffectorSubTypeFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAffectorSubType;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffectorSubType = FCString::Atoi(*TempString);
		ArrayAffectorSubType.push_back(TempAffectorSubType);
	}

	return ArrayAffectorSubType;
}

std::vector<int32> FCWBuffDataUtils::GetArrayAffectorOperationTypeFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAffectorOperationType;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffectorOperationType = FCString::Atoi(*TempString);
		ArrayAffectorOperationType.push_back(TempAffectorOperationType);
	}

	return ArrayAffectorOperationType;
}

std::vector<std::vector<float> > FCWBuffDataUtils::GetArrayArrayAffectorParamsFromString(const FString& ParamString)
{
	std::vector<std::vector<float> > ArrayArrayAffectorParams;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayAffectorParams.push_back(std::vector<float>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			float TempAffectorParam = FCString::Atof(*TempString2);
			ArrayArrayAffectorParams.back().push_back(TempAffectorParam);
		}
	}

	return ArrayArrayAffectorParams;
}

std::vector<int32> FCWBuffDataUtils::GetArrayAffectorDataAffectTypeFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAffectorDataAffectType;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffectorDataAffectType = FCString::Atoi(*TempString);
		ArrayAffectorDataAffectType.push_back(TempAffectorDataAffectType);
	}

	return ArrayAffectorDataAffectType;
}

std::vector<int32> FCWBuffDataUtils::GetArrayAffectorDataAffectKeyTimeTypeFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAffectorDataAffectKeyTimeType;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffectorDataAffectKeyTimeType = FCString::Atoi(*TempString);
		ArrayAffectorDataAffectKeyTimeType.push_back(TempAffectorDataAffectKeyTimeType);
	}

	return ArrayAffectorDataAffectKeyTimeType;
}

std::vector<float> FCWBuffDataUtils::GetArrayLifeFinishParamsFromString(const FString& ParamString)
{
	std::vector<float> ArrayLifeFinishParams;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempLifeFinishParam = FCString::Atof(*TempString);
		ArrayLifeFinishParams.push_back(TempLifeFinishParam);
	}

	return ArrayLifeFinishParams;
}

std::vector<int32> FCWBuffDataUtils::GetArrayBuffEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayBuffEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempBuffEffectId = FCString::Atoi(*TempString);
		ArrayBuffEffectId.push_back(TempBuffEffectId);
	}

	return ArrayBuffEffectId;
}

