﻿
#include "CWBattleCalculate.h"

#include <random>
#include <ctime>
#include <functional>

#include "CWSkill.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWMapTile.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWGameState.h"
#include "CWBuffManager.h"
#include "CWWeatherData.h"
#include "CWCfgManager.h"
#include "CWGameDefine.h"
#include "CWDungeonTile.h"
#include "CWSkillManager.h"
#include "CWPawnDataStruct.h"
#include "CWSkillDataUtils.h"
#include "CWSkillDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWPhysicsSystemCtrl.h"
#include "CWElementSystemCtrl.h"
#include "CWRefrainFactorData.h"
#include "CWPhysicsSystemData.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWRefrainRelationData.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyModifier.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWBattlePropertyAffectorDataRef.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBattleCalculate, All, All);

UCWBattleCalculate::UCWBattleCalculate(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UCWBattleCalculate* UCWBattleCalculate::Get()
{
	// GetDefault<UCWBattleCalculate>()
	return UCWBattleCalculate::StaticClass()->GetDefaultObject<UCWBattleCalculate>();
}

int32 UCWBattleCalculate::PredictCalculateDamageBySkill(ACWPawn* AttackPawn, ACWPawn* BeDamagedPawn, FUIPreviewExtData& ExtData)
{
	ExtData = FUIPreviewExtData();

	if (AttackPawn == nullptr)
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::PredictCalculateDamageBySkill Fail, AttackPawn == nullptr."));
		return 0.0f;
	}

	if (BeDamagedPawn == nullptr)
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::PredictCalculateDamageBySkill Fail, BeDamagedPawn == nullptr."));
		return 0.0f;
	}

	UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent = BeDamagedPawn->GetBattleProperty();
	if (BeDamagedPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::PredictCalculateDamageBySkill Fail, Target->GetBattleProperty() == nullptr."));
		return 0.0f;
	}

	UCWSkill* TempSkill = AttackPawn->GetAutoSelectSkillRecord();
	if (TempSkill == nullptr)
	{
		//UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::PredictCalculateDamageBySkill Fail, GetAutoSelectSkillRecord fail."));
		return 0.0f;
	}

	UCWPawnBattlePropertyComponent* AttackPawnBattlePropertComponent = AttackPawn->GetBattleProperty();
	check(AttackPawnBattlePropertComponent);
	FCWBattlePropertySet TempSkillPropertySet;
	TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::UniqueId, AttackPawn->GetPawnUniqueIdx());
	TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::Profession, AttackPawn->GetProfession());
	TempSkillPropertySet.SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

	TSharedPtr<UCWCastSkillContext> CastSkillContext = TSharedPtr<UCWCastSkillContext>(new UCWCastSkillContext());
	CastSkillContext->PawnWeakPtr = AttackPawn;
	CastSkillContext->BeDamagedPawnPtr = BeDamagedPawn;
	CastSkillContext->CastSkillPropertySet = TempSkillPropertySet;
	const FCWSkillDataStruct* CastSkillData = TempSkill->GetSkillDataStruct();
	CastSkillContext->CastSkillDataStruct = CastSkillData;
	CastSkillContext->PawnPropertySetBase = AttackPawnBattlePropertComponent->GetPropertySetBase();
	CastSkillContext->CopyMapStatisticsData(AttackPawn->GetStatisticsSysMapData());
	CastSkillContext->CopyArrayAffectorData(AttackPawnBattlePropertComponent->GetArrayPropertyAffectorData());
	CastSkillContext->PawnCurMaxTheoreticalPropertySet = AttackPawnBattlePropertComponent->GetCurMaxTheoreticalPropertySet();
	CastSkillContext->PawnCurPropertySet = AttackPawnBattlePropertComponent->GetCurPropertySet();
	//------------------------------------------------------------------
	//1：计算施法者的攻击力
	//计算基础攻击力
	float AttackBase = CalculateAttackBase(CastSkillContext);

	//计算攻击力的装备加成
	float AttackEquip = CalculateAttackEquip(CastSkillContext, AttackBase);

	//计算攻击力的暴击加成(里面根据暴击率，计算是否产生暴击)
	//float AttackCritical = CalculateAttackCritical(CastSkillContext, BeDamagedPawnPropertyComponent, AttackBase, AttackEquip);
	float AttackCritical = 0.0f;

	//计算攻击力的被动技能加成
	float AttackPassivitySkill = CalculateAttackPassivitySkill(CastSkillContext, AttackBase, AttackEquip);

	//计算攻击力的Buff加成
	float AttackBuff = CalculateAttackBuff(CastSkillContext, AttackBase, AttackEquip);

	//计算此施法技能加成
	float AttackCastSkill = CalculateAttackCastSkill(CastSkillContext, AttackBase, AttackEquip);

	//计算属性克制加成(兵种克制)
	float AttackBuffSkill = CalculateAttackBuffSkill(CastSkillContext, AttackBase, AttackEquip);	// Skill BUFF
	float AttackArmBeat = CalculateAttackArmBeat(CastSkillContext, BeDamagedPawn, AttackBase,
		AttackEquip, AttackCritical, AttackPassivitySkill, AttackBuffSkill, AttackCastSkill);

	// 计算攻击力天气加成
	float AttackWeather = CalculateAttackWeather(CastSkillContext);

	// 计算攻击力加成地势差
	/*float AttackWavedLandform = CalculateAttackWavedLandform(CastSkillContext, AttackBase, 
		AttackEquip, AttackCritical, AttackPassivitySkill, AttackBuff, AttackCastSkill);*/

	float FinalAttack = AttackBase + AttackEquip /*+ AttackCritical*/ + AttackBuff + 
						AttackPassivitySkill + AttackCastSkill + AttackArmBeat + AttackWeather/* + AttackWavedLandform*/;
	//------------------------------------------------------------------
	//2：计算被伤害者的防御力
	//计算出基础防御力
	float DefinceBase = CalculateDefinceBase(CastSkillContext, BeDamagedPawnPropertyComponent);

	//计算出装备加成
	float DefinceEquip = CalculateDefinceEquip(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase);

	//计算出防御姿态加成
	float DefinceDefincePosture = CalculateDefinceDefincePosture(CastSkillContext, BeDamagedPawnPropertyComponent, BeDamagedPawn, DefinceBase, DefinceEquip);

	//计算出被动技能加成
	float DefincePassivitySkill = CalculatDefincePassivitySkill(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase, DefinceEquip);

	//计算出Buff加成
	float DefinceBuff = CalculateDefinceBuff(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase, DefinceEquip);

	//计算出地形加成
	float DefinceTerrain = CalculateDefinceTerrain(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase,
		DefinceEquip, DefinceDefincePosture, DefincePassivitySkill, DefinceBuff);

	// 计算防御天气加成
	float DefinceWeather = CalculateDefinceWeather(BeDamagedPawn);

	float FinalDefince = DefinceBase + DefinceEquip + DefinceDefincePosture + DefincePassivitySkill + DefinceBuff + DefinceTerrain + DefinceWeather;
	
	//3：计算最终伤害
	int32 RealFinalDamage = CalculateRealFinalDamage(CastSkillContext, FinalAttack, FinalDefince);

	// 4:检测是否有护盾消耗(角色)
	UCWBuffManager* BeDamagedBuffMgr = BeDamagedPawn->IsPawnType(ECWPawnType::Character) ? BeDamagedPawn->GetBuffManager() : nullptr;
	if ((nullptr != BeDamagedBuffMgr) && RealFinalDamage > 0)
	{	// 伤害检测护盾消耗
		RealFinalDamage = BeDamagedBuffMgr->CheckAndConsumeShield(RealFinalDamage, false);
	}

	// 获取额外数据
	ExtData.RefrainFactor = AttackArmBeat;
	ExtData.ConsumeEnergy = CastSkillData ? CastSkillData->ConsumeEnergy : 0;

	return RealFinalDamage;
}

bool UCWBattleCalculate::CalculateDamageBySkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, ACWPawn* BeDamagedPawn, int DamageIndex)
{
	//if (CastSkillContext == nullptr)
	//{
	//	UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateDamageBySkill Fail, CastSkillContext == nullptr"));
	//	return false;
	//}

	if (BeDamagedPawn == nullptr)
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateDamageBySkill Fail, BeDamagedPawn == nullptr"));
		return false;
	}

	UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent = BeDamagedPawn->GetBattleProperty();
	if (BeDamagedPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateDamageBySkill Fail, Target->GetBattleProperty() == nullptr"));
		return false;
	}

	// 设置接收伤害对象
	CastSkillContext->BeDamagedPawnPtr = BeDamagedPawn;

	//------------------------------------------------------------------
	//1：计算施法者的攻击力
	//计算基础攻击力
	float AttackBase = CalculateAttackBase(CastSkillContext);

	//计算攻击力的装备加成
	float AttackEquip = CalculateAttackEquip(CastSkillContext, AttackBase);
	
	//计算攻击力的暴击加成(里面根据暴击率，计算是否产生暴击)
	float AttackCritical = CalculateAttackCritical(CastSkillContext, BeDamagedPawnPropertyComponent, AttackBase, AttackEquip);

	//计算攻击力的被动技能加成
	float AttackPassivitySkill = CalculateAttackPassivitySkill(CastSkillContext, AttackBase, AttackEquip);

	//计算攻击力的Buff加成
	float AttackBuff = CalculateAttackBuff(CastSkillContext, AttackBase, AttackEquip);

	//计算此施法技能加成
	float AttackCastSkill = CalculateAttackCastSkill(CastSkillContext, AttackBase, AttackEquip);

	//计算属性克制加成(兵种克制)
	float AttackBuffSkill = CalculateAttackBuffSkill(CastSkillContext, AttackBase, AttackEquip);	// Skill BUFF
	float AttackArmBeat = CalculateAttackArmBeat(CastSkillContext, BeDamagedPawn, AttackBase, 
		AttackEquip, AttackCritical, AttackPassivitySkill, AttackBuffSkill, AttackCastSkill);

	// 计算攻击力天气加成
	float AttackWeather = CalculateAttackWeather(CastSkillContext);

	// 计算攻击力加成地势差
	/*float AttackWavedLandform = CalculateAttackWavedLandform(CastSkillContext, AttackBase,
		AttackEquip, AttackCritical, AttackPassivitySkill, AttackBuff, AttackCastSkill);*/

	float FinalAttack = AttackBase + AttackEquip + AttackCritical + AttackBuff + 
						AttackPassivitySkill + AttackCastSkill + AttackArmBeat + AttackWeather/* + AttackWavedLandform*/;

	//------------------------------------------------------------------
	//2：计算被伤害者的防御力
	//计算出基础防御力
	float DefinceBase = CalculateDefinceBase(CastSkillContext, BeDamagedPawnPropertyComponent);

	//计算出装备加成
	float DefinceEquip = CalculateDefinceEquip(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase);

	//计算出防御姿态加成
	float DefinceDefincePosture = CalculateDefinceDefincePosture(CastSkillContext, BeDamagedPawnPropertyComponent, BeDamagedPawn, DefinceBase, DefinceEquip);

	//计算出被动技能加成
	float DefincePassivitySkill = CalculatDefincePassivitySkill(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase, DefinceEquip);

	//计算出Buff加成
	float DefinceBuff = CalculateDefinceBuff(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase, DefinceEquip);

	//计算出地形加成
	float DefinceTerrain = CalculateDefinceTerrain(CastSkillContext, BeDamagedPawnPropertyComponent, DefinceBase, 
		DefinceEquip, DefinceDefincePosture, DefincePassivitySkill, DefinceBuff);

	// 计算防御天气加成
	float DefinceWeather = CalculateDefinceWeather(BeDamagedPawn);

	float FinalDefince = DefinceBase + DefinceEquip + DefinceDefincePosture + DefincePassivitySkill + DefinceBuff + DefinceTerrain + DefinceWeather;
	//------------------------------------------------------------------
	// 3：计算最终伤害
	int32 RealFinalDamage = CalculateRealFinalDamage(CastSkillContext, FinalAttack, FinalDefince);

	// 4：计算(单次伤害=总伤害/伤害次数)
	float floatRealFinalDamage = RealFinalDamage;
	int32 intRealFinalDamage = RealFinalDamage;
	if (CastSkillContext->CastSkillDataStruct != nullptr)
	{
		if (CastSkillContext->CastSkillDataStruct->DamageCount > 0)
		{
			floatRealFinalDamage /= CastSkillContext->CastSkillDataStruct->DamageCount;
			intRealFinalDamage = (int)(floatRealFinalDamage + 0.5f);
		}
	}

	// 5: 被伤害者减血(HP)
	const bool bIsExecHealth = ExecHealthCalculate(CastSkillContext, BeDamagedPawn, intRealFinalDamage);
	if (bIsExecHealth)
	{
		// 6: 计算元素反应
		CalculateElemReactionBySkill(CastSkillContext, BeDamagedPawn);

		// 7: 计算物理交互
		CalculatePhysicsSystemBySkill(CastSkillContext, BeDamagedPawn);
	}

	
	return bIsExecHealth;
}

bool UCWBattleCalculate::CalculateElemReactionBySkill(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn)
{
	const FCWSkillDataStruct* CasterSkillData = InCasterContext.IsValid() ? InCasterContext->CastSkillDataStruct : nullptr;
	const EObjElemType CasterSkillElemType = CasterSkillData ? CasterSkillData->OwnElemType : EObjElemType::OET_None;
	if (!FElemUtils::IsValidObjElemType(CasterSkillElemType))
	{
		CWG_LOG(">> %s::CalculateElemSysReactionBySkill, CasterSkillElemType[%d] is None!", *GetName(), (int32)CasterSkillElemType);
		return false;
	}

	if (!IsValid(InBeDamagedPawn) || !IsValid(InBeDamagedPawn->GetBattleProperty()))
	{
		CWG_ERROR(">> %s::CalculateElemSysReactionBySkill, InBeDamagedPawn is invalid!", *GetName());
		return false;
	}

	UCWElementSystemCtrl* BeDamagedPawnElemSysCtrl = InBeDamagedPawn->GetElemSysCtrl();
	if (!IsValid(BeDamagedPawnElemSysCtrl))
	{
		CWG_LOG(">> %s::CalculateElemSysReactionBySkill, BeDamagedPawnElemSysCtrl[%s] is invalid!", *GetName(), *InBeDamagedPawn->ToDebugString());
		return false;
	}

	/** 检测是否已经反应 */
	if (BeDamagedPawnElemSysCtrl->CheckContextHasReaction(InCasterContext))
	{
		CWG_WARNING(">> %s::CalculateElemSysReactionBySkill, BeDamagedPawnElem Has Reaction Ok!", *GetName(), *InBeDamagedPawn->ToDebugString());
		return false;
	}

	// 设置上下文数据
	//InCasterContext->BeDamagedPawnPtr = InBeDamagedPawn;

	// 执行元素系统反应
	FCWElemWithElemResultData OutResultData;
	const bool bHasElemElemReaction = BeDamagedPawnElemSysCtrl->GetElemElemResult(CasterSkillElemType, OutResultData);
	if (bHasElemElemReaction)
	{	// 执行元素元素反应
		BeDamagedPawnElemSysCtrl->ExecElemElemResult(OutResultData, ECWBuffSouceType::Skill);
	}
	else
	{	// 执行元素性质反应
		BeDamagedPawnElemSysCtrl->ExecElemNatureReaction(CasterSkillElemType, ECWBuffSouceType::Skill);
	}
	return true;
}

bool UCWBattleCalculate::CalculateElemReaction(const EObjElemType InNewElemType, ACWPawn* InBeDamagedPawn, const ECWBuffSouceType InSouceType)
{
	if (EObjElemType::OET_None == InNewElemType)
	{
		CWG_LOG(">> %s::CalculateElemSysReactionBySkill, InNewElemType[%d] is None!", *GetName(), (int32)InNewElemType);
		return false;
	}

	if (nullptr == InBeDamagedPawn || nullptr == InBeDamagedPawn->GetBattleProperty())
	{
		CWG_ERROR(">> %s::CalculateElemSysReactionBySkill, InBeDamagedPawn is invalid!", *GetName());
		return false;
	}

	UCWElementSystemCtrl* BeDamagedPawnElemSysCtrl = InBeDamagedPawn->GetElemSysCtrl();
	if (nullptr == BeDamagedPawnElemSysCtrl)
	{
		CWG_LOG(">> %s::CalculateElemSysReactionBySkill, BeDamagedPawnElemSysCtrl[%s] is invalid!", *GetName(), *InBeDamagedPawn->ToDebugString());
		return false;
	}

	/** 检测是否已经反应 */
	if (BeDamagedPawnElemSysCtrl->CheckContextHasReaction(nullptr))
	{
		CWG_WARNING(">> %s::CalculateElemSysReactionBySkill, BeDamagedPawnElem Has Reaction Ok!", *GetName(), *InBeDamagedPawn->ToDebugString());
		return false;
	}

	// 执行元素系统反应
	FCWElemWithElemResultData OutResultData;
	const bool bHasElemElemReaction = BeDamagedPawnElemSysCtrl->GetElemElemResult(InNewElemType, OutResultData);
	if (bHasElemElemReaction)
	{	// 执行元素元素反应
		BeDamagedPawnElemSysCtrl->ExecElemElemResult(OutResultData, InSouceType);
	}
	else
	{	// 执行元素性质反应
		BeDamagedPawnElemSysCtrl->ExecElemNatureReaction(InNewElemType, InSouceType);
	}
	return true;
}

bool UCWBattleCalculate::CalculatePhysicsSystemBySkill(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn)
{
	const FCWSkillDataStruct* CasterSkillData = InCasterContext.IsValid() ? InCasterContext->CastSkillDataStruct : nullptr;
	const bool bAddLateralForce = CasterSkillData ? CasterSkillData->bAddLateralForce : false;
	if (!bAddLateralForce)
	{
		CWG_LOG(">> %s::CalculatePhysicsSystemBySkill, SkillData.bAddLateralForce is False!", *GetName());
		return false;
	}

	if (!IsValid(InBeDamagedPawn) || !IsValid(InBeDamagedPawn->GetBattleProperty()))
	{
		CWG_ERROR(">> %s::CalculatePhysicsSystemBySkill, InBeDamagedPawn is invalid!", *GetName());
		return false;
	}
	
	UCWPhysicsSystemCtrl* BeDamagedPhysicsSysCtrl = InBeDamagedPawn->GetPhysicsSysCtrl();
	if (!IsValid(BeDamagedPhysicsSysCtrl) || !BeDamagedPhysicsSysCtrl->IsAllowReceiveHorizontalForce())
	{
		CWG_LOG(">> %s::CalculatePhysicsSystemBySkill, BeDamagedPhysicsSysCtrl[Horizontal Force][None] is invalid!", *GetName());
		return false;
	}

	return BeDamagedPhysicsSysCtrl->ExecHorizontalForce(InCasterContext->PawnWeakPtr.Get());
}

bool UCWBattleCalculate::ExecHealthCalculate(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn, const int32 InDamageValue)
{
	UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComp = IsValid(InBeDamagedPawn) ? InBeDamagedPawn->GetBattleProperty() : nullptr;
	if (/*InDamageValue <= 0 ||*/ !IsValid(BeDamagedPawnPropertyComp))
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::ExecHealthCalculate Fail, !IsValid(BeDamagedPawnPropertyComp)"));
		return false;
	}

	// 伤害检测护盾消耗
	bool bConsumeShield = false;
	int32 FinalDamage = InDamageValue;
	UCWBuffManager* BeDamagedBuffMgr = InBeDamagedPawn->IsPawnType(ECWPawnType::Character) ? InBeDamagedPawn->GetBuffManager() : nullptr;
	if ((nullptr != BeDamagedBuffMgr) && FinalDamage > 0)
	{
		FinalDamage = BeDamagedBuffMgr->CheckAndConsumeShield(FinalDamage, true, InCasterContext);
		bConsumeShield = (FinalDamage <= 0);		// 消耗护盾抵挡
	}

	// 被伤害者减血(HP)
	if (!bConsumeShield && FinalDamage > 0)
	{
		const float MinValue = 0.f;
		const float MaxValue = 100000.0f;
		// 非棋子则是算伤害次数
		FinalDamage = InBeDamagedPawn->IsPawnType(ECWPawnType::Character) ? InDamageValue : 1;
		FCWBattlePropertyModifier Modifier(
			ECWBattleProperty::Health, ECWBattlePropertyModifyOp::Add_Param1, -FinalDamage, MinValue, MaxValue);
		InBeDamagedPawn->NetMulticastFlyWordsEffect(FMT_DamageComm, -FinalDamage);

		UE_LOG(LogCWBattleCalculate, Log, TEXT("UCWBattleCalculate::ExecHealthCalculate 1, FinalDamage:%d, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), FinalDamage, (int)InBeDamagedPawn->GetCampTag(), (int)InBeDamagedPawn->GetCampControllerIndex(), (int)InBeDamagedPawn->GetControllerPawnIndex());
		return BeDamagedPawnPropertyComp->GetCurPropertySet().ModifyProperty(Modifier);
	}
	else
	{
		InBeDamagedPawn->NetMulticastFlyWordsEffect(FMT_DamageComm, 0);

		UE_LOG(LogCWBattleCalculate, Log, TEXT("UCWBattleCalculate::ExecHealthCalculate 2, FinalDamage:%d, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), FinalDamage, (int)InBeDamagedPawn->GetCampTag(), (int)InBeDamagedPawn->GetCampControllerIndex(), (int)InBeDamagedPawn->GetControllerPawnIndex());
	}

	return false;
}

float UCWBattleCalculate::GetResultValue(TSharedPtr<UCWCastSkillContext> InCasterContext, const TArray<FCWBattlePropertyAffectorData>& AffectorDataArray,
	const float InBaseValue, const ECWBattleProperty InBattleProperty, const ECWBuffSouceType InSouceType)
{
	float RetValue = 0.f;
	for (const FCWBattlePropertyAffectorData& AffectorData : AffectorDataArray)
	{
		if ((InSouceType == ECWBuffSouceType::None || InSouceType == AffectorData.SouceType) &&
			 AffectorData.AffectBattlePropertyType == InBattleProperty &&
			 IsSameConditioin(AffectorData, InCasterContext))
		{
			RetValue += AffectorData.GetResultValue(InBaseValue);
		}
	}
	return RetValue;
}

float UCWBattleCalculate::RandomFloat(float min, float max)
{
	std::default_random_engine Generator(time(NULL));
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

bool UCWBattleCalculate::IsGenerateCritical(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent
)
{
	check(BeDamagedPawnPropertyComponent);

	//----------------------------------------------------------------
	//1:计算施法者的暴击值
	//计算出施法者技巧值(基础)
	float TalentBase = CalculateTalentBase(CastSkillContext);

	//计算出装备加成
	float CriticalEquip = CalculateCriticalEquip(CastSkillContext, TalentBase);

	//计算出被动技能加成
	float CriticalPassivitySkill = CalculateCriticalPassivitySkill(CastSkillContext, TalentBase, CriticalEquip);

	//计算出Buff加成
	float CriticalBuff = CalculateCriticalBuff(CastSkillContext, TalentBase, CriticalEquip);

	//计算此施法技能加成
	float CriticalCastSkill = CalculateCriticalCastSkill(CastSkillContext, TalentBase, CriticalEquip);

	//计算出地形加成
	float CriticalTerrain = CalculateCriticalTerrain(CastSkillContext, TalentBase, CriticalEquip, CriticalPassivitySkill, CriticalBuff, CriticalCastSkill);

	float FinalCritical = TalentBase + CriticalEquip + CriticalPassivitySkill + CriticalBuff + CriticalCastSkill + CriticalTerrain;
	//----------------------------------------------------------------
	//2:计算被伤害者的暴击值
	//计算出被伤害者技巧值(基础)
	float DefinceTalentBase = CalculateDefinceTalentBase(BeDamagedPawnPropertyComponent);

	//计算出装备加成
	float DefinceCriticalEquip = CalculateDefinceCriticalEquip(BeDamagedPawnPropertyComponent, DefinceTalentBase);

	//计算出被动技能加成
	float DefinceCriticalPassivitySkill = CalculateDefinceCriticalPassivitySkill(BeDamagedPawnPropertyComponent, DefinceTalentBase, DefinceCriticalEquip);

	//计算出Buff加成
	float DefinceCriticalBuff = CalculateDefinceCriticalBuff(BeDamagedPawnPropertyComponent, DefinceTalentBase, DefinceCriticalEquip);

	//计算出地形加成
	float DefinceCriticalTerrain = CalculatDefinceeCriticalTerrain(BeDamagedPawnPropertyComponent, DefinceTalentBase, DefinceCriticalEquip, DefinceCriticalPassivitySkill, DefinceCriticalBuff);

	float FinalDefinceCritical = DefinceTalentBase + DefinceCriticalEquip + DefinceCriticalPassivitySkill + DefinceCriticalBuff + DefinceCriticalTerrain;
	//----------------------------------------------------------------
	//3：计算最终暴击率
	float FinalCritial = CalculateFinalCritical(FinalCritical, FinalDefinceCritical);
	//----------------------------------------------------------------
	const float RandomValue = RandomFloat(0.0f, 1.0f);
	if (RandomValue < FinalCritial)
	{
		return true;
	}
	else
	{
		return false;
	}
}

float UCWBattleCalculate::GetRefrainFactor(const ACWPawn* CasterPawn, const ACWPawn* ReceiverPawn) const
{
	if (nullptr != CasterPawn && CasterPawn->IsPawnType(ECWPawnType::Character) && 
		nullptr != ReceiverPawn && ReceiverPawn->IsPawnType(ECWPawnType::Character))
	{
		// 武器克制
		const FString& CasterWeaponId = CasterPawn->GetWeaponId();
		const FString& ReceiverWeaponId = ReceiverPawn->GetWeaponId();
		// 行动克制
		const FString& CasterActingId = CasterPawn->GetActingId();
		const FString& ReceiverActingId = ReceiverPawn->GetActingId();
		// 种族克制
		const FString& CasterRaceId = CasterPawn->GetRaceId();
		const FString& ReceiverRaceId = ReceiverPawn->GetRaceId();

		// 检测增加克制系数
		auto CheckAddRefrainFactor = [CasterPawn](const int32 InRefrainIdx, const FString& InCasterPrefix, const FString& InTargetKey) -> float
		{
			// 0: 无克制  1:克制  -1:被克制
			if (InRefrainIdx != 0)
			{
				const FString& RefrainFactorKey = InCasterPrefix + InTargetKey;
				if (const FCWRefrainFactorData* RefrainFactor = FCWCfgUtils::GetRefrainFactorData(CasterPawn, RefrainFactorKey))
				{
					return (InRefrainIdx > 0) ? RefrainFactor->RefrainFactor : RefrainFactor->BeRefrainFactor;
				}
			}
			return 0.f;
		};

		// 获取克制系数 (By Key)
		auto GetRefrainFactorById = [&, CasterPawn](const FString& InCasterId, const FString& InCasterPrefix) -> float
		{
			if (InCasterId.IsEmpty() || InCasterPrefix.IsEmpty())
			{
				return 0.f;
			}

			// 获取所属克制类型
			float OutRefrainFactor = 0.f;
			if (const FCWRefrainRelationData* CasterRelation = FCWCfgUtils::GetRefrainRelationData(CasterPawn, InCasterId))
			{
				// 武器克制系数
				int32 RefrainIdx = ReceiverWeaponId.IsEmpty() ? 0 :
					CasterRelation->WeaponStrength.Contains(ReceiverWeaponId) ? 1 :
					CasterRelation->WeaponWeak.Contains(ReceiverWeaponId) ? -1 : 0;
				OutRefrainFactor += CheckAddRefrainFactor(RefrainIdx, InCasterPrefix, TEXT("Weapon"));

				// 行动克制系数
				RefrainIdx = ReceiverActingId.IsEmpty() ? 0 :
					CasterRelation->ActingStrength.Contains(ReceiverActingId) ? 1 :
					CasterRelation->ActingWeak.Contains(ReceiverActingId) ? -1 : 0;
				OutRefrainFactor += CheckAddRefrainFactor(RefrainIdx, InCasterPrefix, TEXT("Acting"));

				// 职阶克制系数
				RefrainIdx = ReceiverRaceId.IsEmpty() ? 0 :
					CasterRelation->RaceStrength.Contains(ReceiverRaceId) ? 1 :
					CasterRelation->RaceWeak.Contains(ReceiverRaceId) ? -1 : 0;
				OutRefrainFactor += CheckAddRefrainFactor(RefrainIdx, InCasterPrefix, TEXT("Race"));
			}
			return OutRefrainFactor;
		};

		// 计算不同克制方案
		const float WeaponFactor = GetRefrainFactorById(CasterWeaponId, TEXT("Weapon_"));
		const float ActingFactor = GetRefrainFactorById(CasterActingId, TEXT("Acting_"));
		const float RaceFactor = GetRefrainFactorById(CasterRaceId, TEXT("Race_"));
		return WeaponFactor + ActingFactor + RaceFactor;
	}
	return 0.f;
}

bool UCWBattleCalculate::IsInDefincePosture(ACWPawn* BeDamagedPawn) const
{
	check(BeDamagedPawn);
	return BeDamagedPawn->IsInDefincePosture();
}

float UCWBattleCalculate::GetDefincePostureFactor(bool IsInDP, const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent) const
{
	if (IsInDP)
	{
		check(BeDamagedPawnPropertyComponent);
		float DefincePostureFactorValue = BeDamagedPawnPropertyComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::DefincePostureFactor);
		return DefincePostureFactorValue;
	}
	else
	{
		return 0.0f;
	}
}


float UCWBattleCalculate::CalculateAttackBase(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	//获得施法者的攻击类型（物理或魔法）
	ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	if (CastSkillPawnAttackType == ECWBattleAttackType::Physical)
	{
		float PhysicalAttackValue = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::Attack);
		return PhysicalAttackValue;
	}
	else if (CastSkillPawnAttackType == ECWBattleAttackType::Magic)
	{
		float MagicAttackValue = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::Attack);
		return MagicAttackValue;
	}
	else
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateAttackBase Fail, CastSkillPawnAttackType == ECWBattleAttackType::None"));
		return 0.0f;
	}
}

float UCWBattleCalculate::CalculateAttackEquip(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase)
{
	//获得施法者的攻击类型（物理或魔法）
	//ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	float AttackEquipValue = 0.0f;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : CastSkillContext->PawnArrayPropertyAffectorData)
	{
		if (TempAffectorData.SouceType == ECWBuffSouceType::Equip &&
			TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Attack &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			AttackEquipValue += TempAffectorData.GetResultValue(AttackBase);
		}
	}
	return AttackEquipValue;
}

bool UCWBattleCalculate::IsSameConditioin(const FCWBattlePropertyAffectorData& ParamAffectorData, TSharedPtr<UCWCastSkillContext> ParamCastSkillContext)
{
	if (ParamAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
	{
		return true;
	}
		
	if (ParamAffectorData.AffectType == ECWPropertyAffectorDataAffectType::InstantInKeyTime &&
		ParamCastSkillContext->CastSkillDataStruct->IsNormalAttack == 1)
	{
		if (ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::NormalAttackAllDamage ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::NormalAttackDamage01 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::NormalAttackDamage02 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::NormalAttackDamage03)
		{
			return true;
		}
	}

	if (ParamAffectorData.AffectType == ECWPropertyAffectorDataAffectType::InstantInKeyTime &&
		ParamCastSkillContext->CastSkillDataStruct->IsNormalAttack == 0 &&
		ParamCastSkillContext->CastSkillDataStruct->IsPassivitySkill == 0)
	{
		if (ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::InitiativeSkillAllDamage ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::InitiativeSkillDamage01 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::InitiativeSkillDamage02 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::InitiativeSkillDamage03)
		{
			return true;
		}
	}

	if (ParamAffectorData.AffectType == ECWPropertyAffectorDataAffectType::InstantInKeyTime &&
		ParamCastSkillContext->CastSkillDataStruct->IsNormalAttack == 0 &&
		ParamCastSkillContext->CastSkillDataStruct->IsPassivitySkill == 1)
	{
		if (ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::PassivitySkillAllDamage ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::PassivitySkillDamage01 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::PassivitySkillDamage02 ||
			ParamAffectorData.AffectKeyTimeType == ECWKeyTimeType::PassivitySkillDamage03)
		{
			return true;
		}
	}

	return false;
}

float UCWBattleCalculate::CalculateAttackCritical(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float AttackBase, 
	float AttackEquip
)
{
	check(BeDamagedPawnPropertyComponent);

	if (IsGenerateCritical(CastSkillContext, BeDamagedPawnPropertyComponent))
	{
		float CriticalDamageFactorValue = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::CriticalDamageFactor);
		float AttackCriticalValue = (AttackBase + AttackEquip) * CriticalDamageFactorValue;
		return AttackCriticalValue;
	}
	else
	{
		return 0.0f;
	}
}

float UCWBattleCalculate::CalculateAttackPassivitySkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip)
{
	return 0.0f;
}

float UCWBattleCalculate::CalculateAttackBuff(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip)
{
	//获得施法者的攻击类型（物理或魔法）
	//ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	float AttackBuffValue = 0.0f;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : CastSkillContext->PawnArrayPropertyAffectorData)
	{
		if (TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Attack &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			AttackBuffValue += TempAffectorData.GetResultValue(AttackBase + AttackEquip);
		}
	}
	return AttackBuffValue;
}

float UCWBattleCalculate::CalculateAttackBuffSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip)
{
	//获得施法者的攻击类型（物理或魔法）
	//ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	float AttackBuffSkillValue = 0.0f;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : CastSkillContext->PawnArrayPropertyAffectorData)
	{
		if (TempAffectorData.SouceType == ECWBuffSouceType::Skill &&
			TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Attack &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			AttackBuffSkillValue += TempAffectorData.GetResultValue(AttackBase + AttackEquip);
		}
	}
	return AttackBuffSkillValue;
}

float UCWBattleCalculate::CalculateAttackCastSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip)
{
	//获得施法者的攻击类型（物理或魔法）
	ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	if (CastSkillPawnAttackType == ECWBattleAttackType::Physical)
	{
		float AttackFactorValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::AttackFactor);
		float PhysicalAttackValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::Attack);
		float AttackFactorBySkill = 0.0f;
		int index = 0;
		if (CastSkillContext->CastSkillDataStruct == nullptr)
		{
			return PhysicalAttackValue;
		}
		AttackFactorValue += CastSkillContext->CastSkillDataStruct->DamageFactor;
		float PhysicalAttackCastSkillValue = ((AttackBase + AttackEquip) * AttackFactorValue + PhysicalAttackValue);
		return PhysicalAttackCastSkillValue;
	}
	else if (CastSkillPawnAttackType == ECWBattleAttackType::Magic)
	{
		float AttackFactorValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::AttackFactor);
		float MagicAttackValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::Attack);
		float AttackFactorBySkill = 0.0f;
		int index = 0;
		if (CastSkillContext->CastSkillDataStruct == nullptr)
		{
			return MagicAttackValue;
		}
		AttackFactorValue += CastSkillContext->CastSkillDataStruct->DamageFactor;
		float MagicAttackCastSkillValue = ((AttackBase + AttackEquip) * AttackFactorValue + MagicAttackValue);
		return MagicAttackCastSkillValue;
	}
	else
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateAttackCastSkill Fail, CastSkillPawnAttackType == ECWBattleAttackType::None"));
		return 0.0f;
	}
}

float UCWBattleCalculate::CalculateAttackArmBeat(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const ACWPawn* BeDamagedPawn,
	float AttackBase,
	float AttackEquip,
	float AttackCritical,
	float AttackPassivitySkill,
	float AttackBuffSkill,
	float AttackCastSkill
)
{
	check(BeDamagedPawn);

	UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent = BeDamagedPawn->GetBattleProperty();
	check(BeDamagedPawnPropertyComponent);

	// 属性克制
	ACWPawn* AttackPawn = CastSkillContext->PawnWeakPtr.Get();
	const float TotalFactor = GetRefrainFactor(AttackPawn, BeDamagedPawn);
	float AttackArmBeat = (AttackBase + AttackEquip + AttackCritical + AttackPassivitySkill + AttackBuffSkill + AttackCastSkill) * TotalFactor;
	return AttackArmBeat;
}

float UCWBattleCalculate::CalculateAttackWeather(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	ACWPawn* MyPawn = CastSkillContext->PawnWeakPtr.Get();
	return MyPawn ? MyPawn->GetAttackWeatherExtValue() : 0.f;
}

float UCWBattleCalculate::CalculateAttackWavedLandform(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	float AttackBase,
	float AttackEquip,
	float AttackCritical,
	float AttackPassivitySkill,
	float AttackBuff,
	float AttackCastSkill)
{
	ACWPawn* AttackPawn = CastSkillContext->PawnWeakPtr.Get();
	ACWPawn* BeDamagedPawn = CastSkillContext->BeDamagedPawnPtr.Get();
	check(AttackPawn && BeDamagedPawn);

	const float Factor = AttackPawn->GetAttackWavedLandformExtFactor(BeDamagedPawn->GetTile());
	float RetVal = (AttackBase + AttackEquip + AttackCritical + AttackPassivitySkill + AttackBuff + AttackCastSkill) * Factor;
	return RetVal;
}

float UCWBattleCalculate::GetAttackWavedLandformFactor(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	ACWPawn* AttackPawn = CastSkillContext->PawnWeakPtr.Get();
	ACWPawn* BeDamagedPawn = CastSkillContext->BeDamagedPawnPtr.Get();
	if (nullptr == AttackPawn || nullptr == BeDamagedPawn)
	{
		CWG_WARNING(">> %s::GetAttackWavedLandformFactor, AttackPawn/BeDamagedPawn is nullptr.", *GetName());
		return 0.f;
	}

	return AttackPawn->GetAttackWavedLandformExtFactor(BeDamagedPawn->GetTile());
}

float UCWBattleCalculate::CalculateDefinceBase(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent
)
{
	check(BeDamagedPawnPropertyComponent);

	//获得施法者的攻击类型（物理或魔法）
	ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);
	if (CastSkillPawnAttackType == ECWBattleAttackType::Physical)
	{
		float PhysicalDefenceValue = BeDamagedPawnPropertyComponent->GetPropertySetBase().GetPropertyByFloat(ECWBattleProperty::PhysicalDefence);
		return PhysicalDefenceValue;
	}
	else if (CastSkillPawnAttackType == ECWBattleAttackType::Magic)
	{
		float MagicDefenceValue = BeDamagedPawnPropertyComponent->GetPropertySetBase().GetPropertyByFloat(ECWBattleProperty::MagicDefence);
		return MagicDefenceValue;
	}
	else
	{
		UE_LOG(LogCWBattleCalculate, Error, TEXT("UCWBattleCalculate::CalculateDefinceBase Fail, CastSkillPawnAttackType == ECWBattleAttackType::None"));
		return 0.0f;
	}
}

float UCWBattleCalculate::CalculateDefinceEquip(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceBase
)
{
	check(BeDamagedPawnPropertyComponent);

	//获得施法者的攻击类型（物理或魔法）
	ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	float DefinceEquipValue = 0.0f;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : BeDamagedPawnPropertyComponent->GetArrayPropertyAffectorData())
	{
		if (TempAffectorData.SouceType == ECWBuffSouceType::Equip)
		{
			if ((CastSkillPawnAttackType == ECWBattleAttackType::Physical && TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::PhysicalDefence) ||
				(CastSkillPawnAttackType == ECWBattleAttackType::Magic && TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::MagicDefence))
			{
				if (IsSameConditioin(TempAffectorData, CastSkillContext))
				{
					DefinceEquipValue += TempAffectorData.GetResultValue(DefinceBase);
				}
			}
		}
	}
	return DefinceEquipValue;
}

float UCWBattleCalculate::CalculateDefinceDefincePosture(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	ACWPawn* BeDamagedPawn,
	float DefinceBase,
	float DefinceEquip
)
{
	check(BeDamagedPawnPropertyComponent);

	bool IsInDP = IsInDefincePosture(BeDamagedPawn);
	float DefincePostureFactorValue = GetDefincePostureFactor(IsInDP, BeDamagedPawnPropertyComponent);

	float DefincePostureValue = BeDamagedPawnPropertyComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::DefincePosture);
	float FinalDefincePostureValue = (DefinceBase + DefinceEquip) * DefincePostureFactorValue + DefincePostureValue;
	return FinalDefincePostureValue;
}


float UCWBattleCalculate::CalculatDefincePassivitySkill(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceBase,
	float DefinceEquip
)
{
	return 0.0f;
}


float UCWBattleCalculate::CalculateDefinceBuff(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceBase,
	float DefinceEquip
)
{
	check(BeDamagedPawnPropertyComponent);

	//获得施法者的攻击类型（物理或魔法）
	ECWBattleAttackType CastSkillPawnAttackType = CastSkillContext->PawnPropertySetBase.GetPropertyForAttackType(ECWBattleProperty::AttackType);

	float DefinceBuffValue = 0.0f;
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = BeDamagedPawnPropertyComponent->GetArrayPropertyAffectorData();
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if ((CastSkillPawnAttackType == ECWBattleAttackType::Physical && TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::PhysicalDefence) ||
			(CastSkillPawnAttackType == ECWBattleAttackType::Magic && TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::MagicDefence))
		{
			if (IsSameConditioin(TempAffectorData, CastSkillContext))
			{
				DefinceBuffValue += TempAffectorData.GetResultValue(DefinceBase + DefinceEquip);
			}
		}
	}

	return DefinceBuffValue;
}

float UCWBattleCalculate::CalculateDefinceTerrain(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceBase,
	float DefinceEquip,
	float DefinceDefincePosture,
	float DefincePassivitySkill,
	float DefinceBuff
)
{
	check(BeDamagedPawnPropertyComponent);

	// TODO: 地形防御系数
	ACWPawn* BeDamagedPawn = Cast<ACWPawn>(BeDamagedPawnPropertyComponent->GetOwner());
	float TarrainDefinceFactor = BeDamagedPawn ? BeDamagedPawn->GetDefinceTerrainExtFactor() : 0.0f;
	float DefinceTarrain = (DefinceBase + DefinceEquip + DefinceDefincePosture + DefincePassivitySkill + DefinceBuff) * TarrainDefinceFactor;
	return DefinceTarrain;
}

float UCWBattleCalculate::CalculateDefinceWeather(ACWPawn* BeDamagedPawn)
{
	return BeDamagedPawn ? BeDamagedPawn->GetDefinceWeatherExtValue(): 0.f;
}

int UCWBattleCalculate::CalculateRealFinalDamage(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	float FinalAttack,
	float FinalDefince
)
{
	float FinalDamageFactorTotal = CalculateFinalDamageFactorTotal(CastSkillContext);
	float FinalDamageTotal = CalculateFinalDamageTotal(CastSkillContext);

	int RealDamage = (int)(FinalAttack + 0.5f) - (int)(FinalDefince + 0.5f);
	if (RealDamage < 0)
	{
		RealDamage = 0;
	}

	int RealFinalDamage = (int)((float)RealDamage * FinalDamageFactorTotal + 0.5f) + (int)FinalDamageTotal;
	if (RealFinalDamage < 0)
	{
		return 0;
	}
	else
	{
		return RealFinalDamage;
	}
}


float UCWBattleCalculate::CalculateTalentBase(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	float TalentValue = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::Talent);
	return TalentValue;
}


float UCWBattleCalculate::CalculateCriticalEquip(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase)
{
	float CriticalEquipValue = 0.0f;
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = CastSkillContext->PawnArrayPropertyAffectorData;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.SouceType == ECWBuffSouceType::Equip &&
			TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Talent &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			CriticalEquipValue += TempAffectorData.GetResultValue(TalentBase);
		}
	}

	return CriticalEquipValue;
}

float UCWBattleCalculate::CalculateCriticalPassivitySkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip)
{
	/*float CriticalPassivitySkillValue = 0.0f;
	const TArray<UCWBattlePropertySetRef*>& Array = CastSkillContext->PawnArrayPropertySetPassivitySkill;
	for (auto Ref : Array)
	{
		float TalentFactorValue = Ref->GetPropertySet().GetPropertyByFloat(ECWBattleProperty::TalentFactor);
		float TalentValue = Ref->GetPropertySet().GetPropertyByFloat(ECWBattleProperty::Talent);
		float CriticalHitRateValue = Ref->GetPropertySet().GetPropertyByFloat(ECWBattleProperty::CriticalHitRate);
		CriticalPassivitySkillValue += ((TalentBase + CriticalEquip) * TalentFactorValue + TalentValue + CriticalHitRateValue * 100.0f);
	}

	return CriticalPassivitySkillValue;*/

	return 0.0f;
}

float UCWBattleCalculate::CalculateCriticalBuff(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip)
{
	float CriticalBuffValue = 0.0f;
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = CastSkillContext->PawnArrayPropertyAffectorData;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Talent &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			CriticalBuffValue += TempAffectorData.GetResultValue(TalentBase + CriticalEquip);
		}
	}

	return CriticalBuffValue;
}

float UCWBattleCalculate::CalculateCriticalCastSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip)
{
	float TalentFactorValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::TalentFactor);
	float TalentValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::Talent);
	float CriticalHitRateValue = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::CriticalHitRate);
	float CriticalCastSkillValue = ((TalentBase + CriticalEquip) * TalentFactorValue + TalentValue + CriticalHitRateValue * 100.0f);
	return CriticalCastSkillValue;
}

float UCWBattleCalculate::CalculateCriticalTerrain(
	TSharedPtr<UCWCastSkillContext> CastSkillContext,
	float TalentBase,
	float CriticalEquip,
	float CriticalPassivitySkill,
	float CriticalBuff,
	float CriticalCastSkill
)
{
	//TODO:得到进攻地形技巧系数
	float TerrainTalentFactor = 0.0f;
	float CriticalTerrainValue = (TalentBase + CriticalEquip + CriticalPassivitySkill + CriticalBuff + CriticalCastSkill) * TerrainTalentFactor;
	return CriticalTerrainValue;
}

float UCWBattleCalculate::CalculateDefinceTalentBase(const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent)
{
	check(BeDamagedPawnPropertyComponent);

	float DefenceTalentValue = BeDamagedPawnPropertyComponent->GetPropertySetBase().GetPropertyByFloat(ECWBattleProperty::Talent);
	return DefenceTalentValue;
}

float UCWBattleCalculate::CalculateDefinceCriticalEquip(
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceTalentBase
)
{
	check(BeDamagedPawnPropertyComponent);

	float DefinceCriticalEquipValue = 0.0f;
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = BeDamagedPawnPropertyComponent->GetArrayPropertyAffectorData();
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.SouceType == ECWBuffSouceType::Equip &&
			TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Talent &&
			TempAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
		{
			DefinceCriticalEquipValue += TempAffectorData.GetResultValue(DefinceTalentBase);
		}
	}

	return DefinceCriticalEquipValue;
}

float UCWBattleCalculate::CalculateDefinceCriticalPassivitySkill(
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceTalentBase,
	float DefinceCriticalEquip
)
{
	return 0.0f;
}

float UCWBattleCalculate::CalculateDefinceCriticalBuff(
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceTalentBase,
	float DefinceCriticalEquip
)
{
	check(BeDamagedPawnPropertyComponent);

	float DefinceCriticalBuffValue = 0.0f;
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = BeDamagedPawnPropertyComponent->GetArrayPropertyAffectorData();
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::Talent &&
			TempAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
		{
			DefinceCriticalBuffValue += TempAffectorData.GetResultValue(DefinceTalentBase + DefinceCriticalEquip);
		}
	}

	return DefinceCriticalBuffValue;
}

float UCWBattleCalculate::CalculatDefinceeCriticalTerrain(
	const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
	float DefinceTalentBase,
	float DefinceCriticalEquip,
	float DefinceCriticalPassivitySkill,
	float DefinceCriticalBuff
)
{
	//TODO:得到防御地形技巧系数
	float DefinceTerrainTalentFactor = 0.0f;
	float DefinceCriticalTerrainValue = (DefinceTalentBase + DefinceCriticalEquip + DefinceCriticalPassivitySkill + DefinceCriticalBuff) * DefinceTerrainTalentFactor;
	return DefinceCriticalTerrainValue;
}

float UCWBattleCalculate::CalculateFinalCritical(float FinalAttack, float FinalDefince)
{
	float tmp = FinalAttack - FinalDefince;
	if (tmp <= 0.0f)
	{
		return 0.0f;
	}

	return tmp / 100.0f;
}

float UCWBattleCalculate::CalculateFinalDamageFactorTotal(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	// 基础
	float FinalDamageFactorBase = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::FinalDamageFactor);
	float FinalDamageFactorTotal = FinalDamageFactorBase;

	// 施法者影响器最终伤害系数加成
	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = CastSkillContext->PawnArrayPropertyAffectorData;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::FinalDamageFactor)
		{
			if (IsSameConditioin(TempAffectorData, CastSkillContext))
			{
				if (TempAffectorData.BattlePropertyModifyOpType == ECWBattlePropertyModifyOp::Base_Multiply_Param1_ClampMax_Param2)
				{
					const int32 BaseValue = CastSkillContext->GetStatisticsDataValue(ECWStatisticsType::RoundMoveAttackStep);
					const float NewAddFactor = TempAffectorData.GetResultValue(BaseValue);
					FinalDamageFactorTotal += NewAddFactor;
					CWG_WARNING(">> %s::CalculateFinalDamageFactorTotal, Caster ModifyOp[3] -> BaseValue[%d] NewAddFactor[%f] FinalDamageFactorTotal[%f].", BaseValue, NewAddFactor, FinalDamageFactorTotal);
				}
				else
				{
					FinalDamageFactorTotal += TempAffectorData.GetResultValue(FinalDamageFactorBase);
				}
			}
		}
	}

	// 地势差
	FinalDamageFactorTotal += GetAttackWavedLandformFactor(CastSkillContext);

	// 施法技能
	float FinalDamageFactorCastSkill = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::FinalDamageFactor);
	FinalDamageFactorTotal += FinalDamageFactorCastSkill;

	// 受伤者最终伤害系数修正
	ACWPawn* BeDamager = CastSkillContext->BeDamagedPawnPtr.Get();
	UCWPawnBattlePropertyComponent* BeDamagerPropertyComp = IsValidActor(BeDamager) ? BeDamager->GetBattleProperty() : nullptr;
	if (IsValidObject(BeDamagerPropertyComp))
	{
		const TArray<FCWBattlePropertyAffectorData>& BeDamagerAffectorArray = BeDamagerPropertyComp->GetArrayPropertyAffectorData();
		for (const FCWBattlePropertyAffectorData& AffectorData : BeDamagerAffectorArray)
		{
			if (AffectorData.AffectBattlePropertyType == ECWBattleProperty::FinalDamageFactor)
			{
				if (IsSameConditioin(AffectorData, CastSkillContext) && AffectorData.IsSameConditioin(CastSkillContext))
				{
					FinalDamageFactorTotal += AffectorData.GetResultValue(0.f);
				}
			}
		}
	}

	// 控制伤害系数正确
	if (FinalDamageFactorTotal < 0.f)
	{
		FinalDamageFactorTotal = 0.f;
	}

	return FinalDamageFactorTotal;
}


float UCWBattleCalculate::CalculateFinalDamageTotal(TSharedPtr<UCWCastSkillContext> CastSkillContext)
{
	//基础
	float FinalDamageBase = CastSkillContext->PawnPropertySetBase.GetPropertyByFloat(ECWBattleProperty::FinalDamage);
	float FinalDamageTotal = FinalDamageBase;

	const TArray<FCWBattlePropertyAffectorData>& AffectorArray = CastSkillContext->PawnArrayPropertyAffectorData;
	for (const FCWBattlePropertyAffectorData& TempAffectorData : AffectorArray)
	{
		if (TempAffectorData.AffectBattlePropertyType == ECWBattleProperty::FinalDamage &&
			IsSameConditioin(TempAffectorData, CastSkillContext))
		{
			FinalDamageTotal += TempAffectorData.GetResultValue(FinalDamageBase);
		}
	}

	//施法技能
	float FinalDamageCastSkill = CastSkillContext->CastSkillPropertySet.GetPropertyByFloat(ECWBattleProperty::FinalDamage);
	FinalDamageTotal += FinalDamageCastSkill;

	return FinalDamageTotal;
}
