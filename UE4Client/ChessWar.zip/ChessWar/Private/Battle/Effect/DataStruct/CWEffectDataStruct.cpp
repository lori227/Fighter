
#include "CWEffectDataStruct.h"

#include "Kismet/GameplayStatics.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"


FCWEffectDataStruct::FCWEffectDataStruct()
	: EffectAttachType(0)
	, DelayPlayTime(0.f)
{
}

FCWEffectDataStruct::~FCWEffectDataStruct()
{
}

void FCWEffectDataStruct::SpawnEmitterAttached(const int32 InEffectId, class USceneComponent* AttachToComponent, 
	TFunction<void(UParticleSystemComponent*, UParticleSystem*)> InCallable)
{
	AActor* AttachCompOwner = IsValidObject(AttachToComponent) ? AttachToComponent->GetOwner() : nullptr;
	if (!IsValidActor(AttachCompOwner) || !IsValidObject(AttachToComponent))
	{
		CWG_WARNING(">> SpawnEmitterAttached, InEffectId[%d]/AttachToComponent[None] is invalid.", InEffectId);
		return;
	}

	const FCWEffectDataStruct* EffectData = FCWCfgUtils::GetEffectData(AttachToComponent, InEffectId);
	if (nullptr == EffectData)
	{
		CWG_WARNING(">> SpawnEmitterAttached, InEffectId[%d] is invalid.", InEffectId);
		return;
	}

	FTimerDelegate TimerCallback;
	TimerCallback.BindLambda([=]()
	{
		AActor* AttachCompOwner = IsValidObject(AttachToComponent) ? AttachToComponent->GetOwner() : nullptr;
		if (!IsValidActor(AttachCompOwner) || !IsValidObject(AttachToComponent))
		{
			return;
		}

		// ����������Ч
		UParticleSystem* EffectTemplate = FCWCfgUtils::GetAssetObjectFromCfg<UParticleSystem>(
			AttachToComponent, FCWCfgKey::ParticleAsset, EffectData->EffectResId);
		if (EffectTemplate != nullptr)
		{
			const FName AttachName = FName(*EffectData->EffectAttachName);
			const FVector NewOffset = FCWCfgUtils::FString_To_FVector(EffectData->EffectOffset);
			const FVector OutRotation = FCWCfgUtils::FString_To_FVector(EffectData->EffectRotator);
			const FRotator NewRotation = FRotator(OutRotation.X, OutRotation.Y, OutRotation.Z);
			const FVector NewScale = FCWCfgUtils::FString_To_FVector(EffectData->EffectScale, FVector::OneVector);
			UParticleSystemComponent* NewPSC = UGameplayStatics::SpawnEmitterAttached(
				EffectTemplate,
				AttachToComponent, AttachName,
				NewOffset, NewRotation, NewScale);
			NewPSC->ActivateSystem(true);

			if (nullptr != InCallable)
			{
				InCallable(NewPSC, EffectTemplate);
			}
		}
		else if (nullptr != InCallable)
		{
			CWG_WARNING(">> SpawnEmitterAttached, EffectData->EffectResId[%s] is invalid.", *EffectData->EffectResId);
			InCallable(nullptr, nullptr);
		}
	});

	FTimerHandle EffectTimer;
	FTimerManager& TimerMgr = AttachToComponent->GetWorld()->GetTimerManager();
	TimerMgr.SetTimer(EffectTimer, TimerCallback, 1.0f, false, EffectData->DelayPlayTime);
}
