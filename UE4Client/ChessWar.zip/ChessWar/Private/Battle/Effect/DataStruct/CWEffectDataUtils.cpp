#include "CWEffectDataUtils.h"


std::vector<float> FCWEffectDataUtils::GetArrayEffectOffsetFromString(const FString& ParamString)
{
	std::vector<float> ArrayEffectOffset;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempOffset = FCString::Atof(*TempString);
		ArrayEffectOffset.push_back(TempOffset);
	}

	return ArrayEffectOffset;
}

std::vector<float> FCWEffectDataUtils::GetArrayEffectRotatorFromString(const FString& ParamString)
{
	std::vector<float> ArrayEffectRotator;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempRotator = FCString::Atof(*TempString);
		ArrayEffectRotator.push_back(TempRotator);
	}

	return ArrayEffectRotator;
}