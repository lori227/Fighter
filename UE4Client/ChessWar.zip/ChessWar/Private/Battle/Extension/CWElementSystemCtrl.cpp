﻿
#include "CWElementSystemCtrl.h"

#include "UnrealNetwork.h"
#include "GameFramework/Actor.h"

#include "CWPawn.h"
#include "CWBuff.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWCastSkillContext.h"


UCWElementSystemCtrl::UCWElementSystemCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ObjElemId(INDEX_NONE)
	, ObjNatureTypes(0)
	, ObjElemType(EObjElemType::OET_None)
	, ObjElemRefBuffId(INDEX_NONE)
	, ObjElemRefBuffUniqueId(INDEX_NONE)
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;
	bAutoRegister = true;

	NetPawnUniqueIdx = INDEX_NONE;
	NetPawnSkillId = INDEX_NONE;
	RemainDamageCnt = INDEX_NONE;
}

UCWElementSystemCtrl::~UCWElementSystemCtrl()
{
}

bool UCWElementSystemCtrl::InitInServer(const int32 InObjElemId)
{
	OwnerPawn = Cast<ACWPawn>(GetOwner());
	check(OwnerPawn);

	const FCWObjElemInfoData* ObjElemInfo = FCWCfgUtils::GetObjElemInfoData(this, InObjElemId);
	if (nullptr == ObjElemInfo)
	{
		CWG_ERROR(">> ElemSys::InitInServer, Owner[%s] InObjElemId[%d] config is invalid.", *OwnerPawn->GetName(), InObjElemId);
		return false;
	}

	ObjElemId = InObjElemId;
	ObjElemType = ObjElemInfo->ObjElemType;
	ObjNatureTypes = FElemUtils::ParseObjNatures(ObjElemInfo->ObjNatures);

	//CWG_LOG(">> ElemSys::InitInServer, OwnerPawn[%s] CfgElemInfo[%s] Init Ok...", *OwnerPawn->ToDebugString(), *ObjElemInfo->ToDebugString());
	return true;
}

bool UCWElementSystemCtrl::ResetInServer(const int32 InObjElemId)
{
	return InitInServer(InObjElemId);
}

void UCWElementSystemCtrl::BeginDestroy()
{
	Super::BeginDestroy();

}

void UCWElementSystemCtrl::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UCWElementSystemCtrl, ObjElemId);
	DOREPLIFETIME(UCWElementSystemCtrl, ObjElemType);
	DOREPLIFETIME(UCWElementSystemCtrl, ObjNatureTypes);
	DOREPLIFETIME(UCWElementSystemCtrl, ObjElemRefBuffId);
	DOREPLIFETIME(UCWElementSystemCtrl, ObjElemRefBuffUniqueId);
}

FCWElemWithElemResultData UCWElementSystemCtrl::GetElemWithElemReactionResult_Implementation(
	const EObjElemType InOriginalElem, const EObjElemType InCasterElem)
{
	return FCWElemWithElemResultData();
}

FCWElemWithObjNatureResultData UCWElementSystemCtrl::GetElemWithObjNatureReactionResult_Implementation(
	const EObjElemType InCasterElem, const EObjNatureType InObjNatureType, const ECWPawnType InObjType)
{
	return FCWElemWithObjNatureResultData();
}

bool UCWElementSystemCtrl::GetElemElemResult(const EObjElemType InElemType, FCWElemWithElemResultData& OutResultData)
{
	const ENetMode NetMode = GetNetMode();
	if (!FElemUtils::IsValidObjElemType(InElemType) || !FElemUtils::IsValidObjElemType(ObjElemType) || IsNetMode(NM_Client))
	{
		CWG_WARNING(">> ElemSys::GetElemElemResult, InElemType[%d] ObjElemType[%d] NetMode[%d], so no reaction(elem with elem).", (int32)InElemType, (int32)ObjElemType, (int32)NetMode);
		return false;
	}
	
	OutResultData = GetElemWithElemReactionResult(ObjElemType, InElemType);
	return (OutResultData.ResultType != EElemWithElemResultType::EWERT_None);
}

bool UCWElementSystemCtrl::ExecElemElemResult(const FCWElemWithElemResultData& InReactionResult, const ECWBuffSouceType InSouceType)
{
	if (FElemUtils::IsValidObjElemType(ObjElemType))
	{
		CWG_WARNING(">> ElemSys::ExecElemElemResult, Exec Ok~ InReactionResult[%s].", *InReactionResult.ToDebugString());

		const ECWPawnType OwnerPawnType = GetOwnerPawnType();
		check(OwnerPawnType != ECWPawnType::None);
		const int32 NewBuffId = InReactionResult.GetOutBuffId(OwnerPawnType);

		if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_None)
		{	// 不反应
			CWG_ERROR(">> ElemSys::ExecElemElemResult, Exec Error! ReactionResult is None!!!");
			return false;
		}
		else if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_Clear)
		{	// 抵消(消除现在元素)
			ResetObjElemType(EObjElemType::OET_None);
		}
		else if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_ClearAlsoAddBuff)
		{	// 抵消并附加Buff(例如:爆炸..)
			ResetObjElemType(EObjElemType::OET_None);
			AddBuffForOwner(NewBuffId, InSouceType);
		}
		else if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_OnlyAddBuff)
		{	// 只附加Buff
			AddBuffForOwner(NewBuffId, InSouceType);
		}
		else if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_GenElem)
		{	// 生成元素
			ResetObjElemType(InReactionResult.OutElemType);

			// 执行元素与性质反应
			ExecElemNatureReaction(InReactionResult.OutElemType, InSouceType);
		}
		else if (InReactionResult.ResultType == EElemWithElemResultType::EWERT_CoverElem)
		{	// 覆盖元素
			const EObjElemType NewElemType = (ObjElemType != InReactionResult.OutElemType) ? InReactionResult.OutElemType : InReactionResult.OutExtraElemType;
			ResetObjElemType(NewElemType);
			AddBuffAndResetElemForOwner(NewBuffId, NewElemType, InSouceType);
		}
	}
	else
	{
		CWG_ERROR(">> ElemSys::ExecElemElemResult, Exec Error! ObjElemType[%d] is None!!!", (int32)ObjElemType);
		return false;
	}
	return true;
}

bool UCWElementSystemCtrl::ExecElemNatureReaction(const EObjElemType InElemType, const ECWBuffSouceType InSouceType)
{
	const ENetMode NetMode = GetNetMode();
	if (!FElemUtils::IsValidObjElemType(InElemType) || 0 == ObjNatureTypes || IsNetMode(NM_Client))
	{
		CWG_WARNING(">> ElemSys::ExecElemNatureReaction, InElemType[%d] ObjNatureTypes[%d] NetMode[%d].", (int32)InElemType, (int32)ObjNatureTypes, (int32)NetMode);
		return false;
	}

	// 拥有者对象
	UCWBuffManager* OwnerBuffMgr = OwnerPawn ? OwnerPawn->GetBuffManager() : nullptr;
	if (IsPendingKill() || !IsValid(OwnerPawn) || !IsValid(OwnerBuffMgr))
	{
		CWG_ERROR(">> ElemSys::ExecElemNatureReaction, OwnerPawn/OwnerBuffMgr is nullptr.");
		return false;
	}

	const bool CanReaction = FElemUtils::ObjHasNatureType(ObjNatureTypes, (EObjNatureType)InElemType);
	if (CanReaction)
	{
		const FCWElemWithObjNatureResultData ReactionResult = 
			GetElemWithObjNatureReactionResult(InElemType, (EObjNatureType)InElemType, OwnerPawn->GetPawnType());
		ResetObjElemType(ReactionResult.ResultElemType);
		AddBuffAndResetElemForOwner(ReactionResult.ResultBuffId, ReactionResult.ResultElemType, InSouceType);
	}

	return CanReaction;
}

bool UCWElementSystemCtrl::CheckContextHasReaction(TSharedPtr<UCWCastSkillContext> InCasterContext)
{
	if (!InCasterContext.IsValid())
	{	// 无上下文则是单次伤害
		NetPawnUniqueIdx = INDEX_NONE;
		NetPawnSkillId = INDEX_NONE;
		RemainDamageCnt = INDEX_NONE;
		return false;
	}
	else if (NetPawnUniqueIdx == INDEX_NONE && NetPawnSkillId == INDEX_NONE)
	{	// 没有被技能反应则重置
		NetPawnUniqueIdx = InCasterContext->CastSkillPropertySet.GetPropertyByInt(ECWBattleProperty::UniqueId);
		NetPawnSkillId = InCasterContext->CastSkillDataStruct->SkillId;
		RemainDamageCnt = InCasterContext->CastSkillDataStruct->DamageCount;
	}
	else
	{
		const int32 TmpNetPawnUniqueIdx = InCasterContext->CastSkillPropertySet.GetPropertyByInt(ECWBattleProperty::UniqueId);
		const int32 TmpNetPawnSkillId = InCasterContext->CastSkillDataStruct->SkillId;
		// 同一个技能,剩余次数减少,确保已经反应
		if (TmpNetPawnUniqueIdx == NetPawnUniqueIdx && TmpNetPawnSkillId == NetPawnSkillId)
		{
			--RemainDamageCnt;
		}
		else
		{	// 不是同一个技能直接重置
			NetPawnUniqueIdx = TmpNetPawnUniqueIdx;
			NetPawnSkillId = TmpNetPawnSkillId;
			RemainDamageCnt = InCasterContext->CastSkillDataStruct->DamageCount;
		}
	}

	/** 数量不相同则已经反应 */
	const bool IsHasReaction = (RemainDamageCnt != InCasterContext->CastSkillDataStruct->DamageCount);
	if (RemainDamageCnt <= 1)
	{	// 剩余次数清理
		NetPawnUniqueIdx = INDEX_NONE;
		NetPawnSkillId = INDEX_NONE;
		RemainDamageCnt = INDEX_NONE;
	}
	return IsHasReaction;
}

FString UCWElementSystemCtrl::ToDebugString() const
{
	return FString::Printf(TEXT("Owner[%s] ObjElemId[%d] ObjElemType[%s] ObjNatureTypes[%d]"), 
		*GetOwner()->GetName(), ObjElemId, *FElemUtils::ToOETString(ObjElemType), (int32)ObjNatureTypes);
}

bool UCWElementSystemCtrl::ResetObjElemType(const EObjElemType InNewElemType)
{
	if (!FElemUtils::IsObjElemTypeInRange(InNewElemType))
	{
		CWG_ERROR(">> ElemSys::ResetObjElemType, InNewElemType[%s] is error!", *FElemUtils::ToOETString(InNewElemType));
		return false;
	}

	// 拥有者对象
	UCWBuffManager* OwnerBuffMgr = OwnerPawn ? OwnerPawn->GetBuffManager() : nullptr;
	if (IsPendingKill() || !IsValid(OwnerPawn) || !IsValid(OwnerBuffMgr))
	{
		CWG_ERROR(">> ElemSys::ResetObjElemType, OwnerPawn/OwnerBuffMgr is nullptr.");
		return false;
	}
	
	const int32 CurBuffId = ObjElemRefBuffId;
	const int32 CurBuffUniqueId = ObjElemRefBuffUniqueId;
	if (CurBuffId > 0 && CurBuffUniqueId > 0)
	{	// 清理旧Buff
		OwnerBuffMgr->RemoveBuffInServer(CurBuffUniqueId, CurBuffId);
		OwnerPawn->NetMulticastRPCRemoveBuff(CurBuffUniqueId, CurBuffId);

		ObjElemRefBuffId = INDEX_NONE;
		ObjElemRefBuffUniqueId = INDEX_NONE;
	}
	ObjElemType = InNewElemType;

	return true;
}

bool UCWElementSystemCtrl::AddBuffAndResetElemForOwner(const int32 InNewBuffId, const EObjElemType InNewElemType, const ECWBuffSouceType InSouceType)
{
	if (InNewBuffId <= 0)
	{
		CWG_WARNING(">> ElemSys::ResetObjElemType, InNewBuffId[%d] is invalid.", InNewBuffId);
		return false;
	}

	// 拥有者对象
	UCWBuffManager* OwnerBuffMgr = OwnerPawn ? OwnerPawn->GetBuffManager() : nullptr;
	if (IsPendingKill() || !IsValid(OwnerPawn) || !IsValid(OwnerBuffMgr))
	{
		CWG_ERROR(">> ElemSys::ResetObjElemType, OwnerPawn/OwnerBuffMgr is nullptr.");
		return false;
	}

	// 添加新Buff
	if (UCWBuff* NewBuff = OwnerPawn->GenerateBuff(InNewBuffId, InSouceType))
	{
		if (FElemUtils::IsValidObjElemType(InNewElemType))
		{
			ObjElemRefBuffId = NewBuff->GetBuffId();
			ObjElemRefBuffUniqueId = NewBuff->GetBuffUniqueId();

			// 绑定数据Buff
			TScriptDelegate<> NewDelegate;
			NewDelegate.BindUFunction(this, FName("OnElemRefBuffDestroyed"));
			NewBuff->RefElemType = InNewElemType;
			NewBuff->OnBuffDestroyed.AddUnique(NewDelegate);
		}
		ObjElemType = InNewElemType;

		return true;
	}

	return false;
}

bool UCWElementSystemCtrl::AddBuffForOwner(const int32 InNewBuffId, const ECWBuffSouceType InSouceType)
{
	if (InNewBuffId <= 0)
	{
		CWG_WARNING(">> ElemSys::ResetObjElemType, InNewBuffId[%d] is invalid.", InNewBuffId);
		return false;
	}

	// 拥有者对象
	UCWBuffManager* OwnerBuffMgr = OwnerPawn ? OwnerPawn->GetBuffManager() : nullptr;
	if (IsPendingKill() || !IsValid(OwnerPawn) || !IsValid(OwnerBuffMgr))
	{
		CWG_WARNING(">> ElemSys::ResetObjElemType, OwnerPawn/OwnerBuffMgr is nullptr.");
		return false;
	}

	// 添加新Buff
	UCWBuff* NewBuff = OwnerPawn->GenerateBuff(InNewBuffId, InSouceType);
	return nullptr != NewBuff;
}

ECWPawnType UCWElementSystemCtrl::GetOwnerPawnType()
{
	return IsValid(OwnerPawn) ? OwnerPawn->GetPawnType() : ECWPawnType::None;
}

void UCWElementSystemCtrl::OnElemRefBuffDestroyed(const int32 InBuffUniqueId, const int32 InBuffId, const EObjElemType InOwnElemType, const ECWBuffSouceType InSouceType)
{
	CWG_WARNING(">> ElemSys::OnElemRefBuffDestroyed, InOwnElemType[%s] InBuffUniqueId[%d] InBuffId[%d] ObjElemRefBuffUniqueId[%d] ObjElemRefBuffId[%d] InSouceType[%s].",
		*FElemUtils::ToOETString(InOwnElemType), InBuffUniqueId, InBuffId, ObjElemRefBuffUniqueId, ObjElemRefBuffId, *FCWToString::ToString(InSouceType));

	if (FElemUtils::IsValidObjElemType(InOwnElemType) && (ObjElemType == InOwnElemType) &&
		InBuffUniqueId > 0 && InBuffId > 0 &&
		ObjElemRefBuffUniqueId == InBuffUniqueId && ObjElemRefBuffId == InBuffId)
	{
		CWG_WARNING(">> ElemSys::OnElemRefBuffDestroyed, Clear Buff Id Ok~");

		ObjElemType = EObjElemType::OET_None;
		ObjElemRefBuffId = INDEX_NONE;
		ObjElemRefBuffUniqueId = INDEX_NONE;
	}
}
