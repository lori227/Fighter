﻿
#include "CWLevelRenderCtrl.h"

#include "UnrealNetwork.h"
#include "GameFramework/Actor.h"

#include "CWPawn.h"


UCWLevelRenderCtrl::UCWLevelRenderCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.bAllowTickOnDedicatedServer = false;

	bAutoRegister = true;
}

UCWLevelRenderCtrl::~UCWLevelRenderCtrl()
{
}

void UCWLevelRenderCtrl::BeginDestroy()
{
	Super::BeginDestroy();

}
