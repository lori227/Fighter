﻿
#include "CWPhysicsSystemCtrl.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWSkill.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWDungeonItem.h"
#include "CWDungeonTile.h"
#include "CWBattleCalculate.h"
#include "CWRandomDungeonGenerator.h"


UCWPhysicsSystemCtrl::UCWPhysicsSystemCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;
	bAutoRegister = true;
}

UCWPhysicsSystemCtrl::~UCWPhysicsSystemCtrl()
{
}

void UCWPhysicsSystemCtrl::BeginDestroy()
{
	Super::BeginDestroy();

}

void UCWPhysicsSystemCtrl::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UCWPhysicsSystemCtrl, PhysicsSysData);
}

bool UCWPhysicsSystemCtrl::InitInServer(const FCWPhysicsSysData& InPhysicsSysData)
{
	OwnerPawn = Cast<ACWPawn>(GetOwner());
	check(OwnerPawn);

	check((InPhysicsSysData.bPhyBFallenForce || InPhysicsSysData.bPhyBMovedForce) && TEXT("PhysicsSysData is invalid!!!"));
	PhysicsSysData = InPhysicsSysData;

	return true;
}

bool UCWPhysicsSystemCtrl::ExecHorizontalForce(const ACWPawn* InCaster /*= nullptr*/)
{
	if (!IsValidCompnent(this) || !IsValidActor(OwnerPawn) || !PhysicsSysData.bPhyBMovedForce)
	{
		CWG_LOG(">> PhysicsSys::ExecHorizontalForce, Owner/Self is pengding kill! bPhyBMovedForce[False].");
		return false;
	}
	//ExecEventForPawn(InCaster, OwnerPawn, true);
	ExecBuffForPawn(InCaster, OwnerPawn, true);
	ExecHurtForPawn(InCaster, OwnerPawn, true);
	ExecForced2MoveForPawn(InCaster, OwnerPawn, true);

	return true;
}

bool UCWPhysicsSystemCtrl::ExecVerticalForce(const ACWPawn* InCaster /*= nullptr*/)
{
	if (!IsValidCompnent(this) || !IsValidActor(OwnerPawn) || !PhysicsSysData.bPhyBFallenForce)
	{
		CWG_LOG(">> PhysicsSys::ExecHorizontalForce, Owner/Self is pengding kill! bPhyBFallenForce[False].");
		return false;
	}
	//ExecEventForPawn(InCaster, OwnerPawn, false);
	ExecBuffForPawn(InCaster, OwnerPawn, false);
	ExecHurtForPawn(InCaster, OwnerPawn, false);
	ExecForced2MoveForPawn(InCaster, OwnerPawn, false);

	return true;
}

bool UCWPhysicsSystemCtrl::IsAllowReceiveForce()
{
	return IsAllowReceiveHorizontalForce() || IsAllowReceiveVerticalForce();
}

bool UCWPhysicsSystemCtrl::IsAllowReceiveHorizontalForce()
{
	return PhysicsSysData.bPhyBMovedForce;
}

bool UCWPhysicsSystemCtrl::IsAllowReceiveVerticalForce()
{
	return PhysicsSysData.bPhyBFallenForce;
}

FString UCWPhysicsSystemCtrl::ToDebugString() const
{
	return PhysicsSysData.ToDebugString();
}

void UCWPhysicsSystemCtrl::ExecEventForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce)
{
	check(InReceiver);
	const int32 NewEventId = bHorizontalForce ? PhysicsSysData.PhyLateralFEvent : PhysicsSysData.PhyVerticalFEvent;
	CWG_LOG(">> PhysicsSys::ExecEventForPawn, NewEventId[%d].", NewEventId);
	if (NewEventId > 0)
	{
		// TODO: EXEC EVENT
	}
}

void UCWPhysicsSystemCtrl::ExecBuffForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce)
{
	check(InReceiver);
	const int32 NewBuffId = bHorizontalForce ? PhysicsSysData.PhyLateralFBuff : PhysicsSysData.PhyVerticalFBuff;
	CWG_LOG(">> PhysicsSys::ExecBuffForPawn, NewBuffId[%d].", NewBuffId);
	if (NewBuffId > 0)
	{
		InReceiver->GenerateBuff(NewBuffId, ECWBuffSouceType::PhySicsSys);
	}
}

void UCWPhysicsSystemCtrl::ExecHurtForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce)
{
	check(InReceiver);
	const int32 NewDMG = bHorizontalForce ? PhysicsSysData.PhyLateralFDMG : PhysicsSysData.PhyVerticalFDMG;
	CWG_LOG(">> PhysicsSys::ExecHurtForPawn, NewDMG[%d].", NewDMG);
	if (NewDMG > 0)
	{
		if (UCWBattleCalculate::Get()->ExecHealthCalculate(nullptr, InReceiver, NewDMG))
		{
			InReceiver->NetMulticastBeForceMovePresentation();
		}
	}
}

void UCWPhysicsSystemCtrl::ExecForced2MoveForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce)
{
	const int32 NewMoveNum = bHorizontalForce ? PhysicsSysData.PhyLateralFMove : PhysicsSysData.PhyVerticalFMove;
	CWG_LOG(">> PhysicsSys::ExecForced2MoveForPawn, NewMoveNum[%d].", NewMoveNum);
	if (IsValidActor(InReceiver) && NewMoveNum > 0)
	{
		if (bHorizontalForce)
		{
			ExecHorizontalForced2Move(InCaster, InReceiver, NewMoveNum);
		}
		else
		{
			ExecVerticalForced2Move(InCaster, InReceiver, NewMoveNum);
		}
	}
}

void UCWPhysicsSystemCtrl::ExecHorizontalForced2Move(const ACWPawn* InCaster, ACWPawn* InReceiver, const int32 InMoveNum)
{
	ACWMap* MyMap = UCWFuncLib::GetActor<ACWMap>(this);
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	check(MyMap && Generator && InCaster && IsValidActor(InReceiver) && TEXT("ExecHorizontalForced2Move: Exec Obj is invalid!!!"));

	// 获取发起者/接受者数据
	const int32 CasterTileNumber = InCaster->GetTile();
	int32 CasterX = INDEX_NONE, CasterY = INDEX_NONE;
	MyMap->tile2xy(CasterTileNumber, CasterX, CasterY);
	const int32 ReceiverTileNumber = InReceiver->GetTile();
	int32 ReceiverX = INDEX_NONE, ReceiverY = INDEX_NONE;
	MyMap->tile2xy(ReceiverTileNumber, ReceiverX, ReceiverY);
	CWG_WARNING(">>> Out: Caster, CasterTileNumber[%d], CasterX[%d], CasterY[%d].", CasterTileNumber, CasterX, CasterY);
	CWG_LOG(">>> Out: Receiver, ReceiverTileNumber[%d], ReceiverX[%d], ReceiverY[%d].", ReceiverTileNumber, ReceiverX, ReceiverY);

	// 查找预移动点
	const int32 MapWidth = MyMap->getWidth();
	const int32 MapHeight = MyMap->getHeight();
	const int32 OpXTileNumber = CasterX - ReceiverX;
	const int32 OpYTileNumber = CasterY - ReceiverY;
	//~ 坐标X / 坐标Y / Z:TileNumber
	TArray<FIntVector> ReceiverPreMoveXYArray;
	CWG_LOG(">>> Out: Search-Start, MapWidth[%d] MapHeight[%d] OpXTileNumber[%d] OpYTileNumber[%d].", MapWidth, MapHeight, OpXTileNumber, OpYTileNumber);
	
	if (0 == OpXTileNumber || 0 == OpYTileNumber || 
		OpXTileNumber == OpYTileNumber || OpXTileNumber == -OpYTileNumber)
	{	// 水平/垂直/或者45'
		FIntVector LastPoint(ReceiverX, ReceiverY, 0);
		while (ReceiverPreMoveXYArray.Num() < InMoveNum)
		{
			const int32 NewX = LastPoint.X - OpXTileNumber;
			const int32 NewY = LastPoint.Y - OpYTileNumber;
			LastPoint.X = NewX;							// 坐标X
			LastPoint.Y = NewY;							// 坐标Y
			LastPoint.Z = MyMap->xy2tile(NewX, NewY);	// Tile Number
			ReceiverPreMoveXYArray.Push(LastPoint);
			CWG_LOG(">>> Out: Search-ing, NewX[%d] NewY[%d].", NewX, NewY);

			if (NewX < 0 || NewY < 0 || NewX > MapWidth || NewY > MapHeight)
			{
				break;
			}
		}
	}
	else
	{	// 其他角度
		CWG_WARNING(">>> Out: Search-ing, Now is Not implemented!!!");
		return;
	}
	CWG_LOG(">>> Out: Search-Over");

	// 进入被迫移动状态
	CWG_WARNING(">> %s::ExecHorizontalForced2Move, Out: StartForceMove, PreMoveXYArray.Num[%d].", *GetName(), ReceiverPreMoveXYArray.Num());
	if (IsValidActor(InReceiver) && InReceiver->IsInServer() && ReceiverPreMoveXYArray.Num() > 0)
	{
		InReceiver->NetMulticastBeForceMove(CasterTileNumber, ReceiverPreMoveXYArray);
	}
}

void UCWPhysicsSystemCtrl::TestHorizontalForced2Move(const AActor* InWorldContext, const int32 InCasterNetIdx, const int32 InReceiverNetIdx, const int32 InMoveNum)
{
	UWorld* MyWorld = InWorldContext ? InWorldContext->GetWorld() : nullptr;
	if (!IsValidObject(MyWorld) || InMoveNum <= 0)
	{
		return;
	}

	ACWPawn* CasterPawn = UCWFuncLib::GetActor<ACWPawn>(MyWorld, 
	[=](const ACWPawn* InPawn)
	{
		return InPawn->GetPawnUniqueIdx() == InCasterNetIdx;
	});

	ACWPawn* ReceiverPawn = UCWFuncLib::GetActor<ACWPawn>(MyWorld,
	[=](const ACWPawn* InPawn)
	{
		return InPawn->GetPawnUniqueIdx() == InReceiverNetIdx;
	});

	if (!IsValidActor(CasterPawn) || !IsValidActor(ReceiverPawn))
	{
		return;
	}

	if (UCWPhysicsSystemCtrl* ReceiverPhysicsSys = ReceiverPawn->GetPhysicsSysCtrl())
	{
		ReceiverPhysicsSys->ExecHorizontalForced2Move(CasterPawn, ReceiverPawn, InMoveNum);
	}
}

void UCWPhysicsSystemCtrl::ExecVerticalForced2Move(const ACWPawn* InCaster, ACWPawn* InReceiver, const int32 InMoveNum)
{
}

int32 UCWPhysicsSystemCtrl::GetTargetNearOptimumTile(const UObject* InWorldContext, const int32 InTargetTile, const int32 InParamTile)
{
	ACWMap* MyMap = UCWFuncLib::GetActor<ACWMap>(InWorldContext);
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(InWorldContext);
	if (IsValidActor(MyMap) && IsValidActor(Generator) && InTargetTile > INDEX_NONE)
	{
		// 范围大小: 四方格子
		int32 CX, CY;
		ACWMap::tile2xy(InTargetTile, CX, CY);
		auto GetRangePoint = [=](const int32 InRange)
		{
			TArray<FIntPoint> OutPointArray;
			OutPointArray.Add(FIntPoint(CX + InRange, CY + InRange));
			OutPointArray.Add(FIntPoint(CX + InRange, CY - InRange));
			OutPointArray.Add(FIntPoint(CX + InRange, CY));
			OutPointArray.Add(FIntPoint(CX - InRange, CY + InRange));
			OutPointArray.Add(FIntPoint(CX - InRange, CY - InRange));
			OutPointArray.Add(FIntPoint(CX - InRange, CY));
			OutPointArray.Add(FIntPoint(CX, CY + InRange));
			OutPointArray.Add(FIntPoint(CX, CY - InRange));
			return OutPointArray;
		};

		// 查找范围1格子
		int32 CurFindRange = 1;
		//bool bIsFindOkTile = false;
		//while (!bIsFindOkTile)
		{
			TArray<int32> TileArray;
			TArray<FIntPoint> NewXYArray = GetRangePoint(CurFindRange++);
			for (int32 i = 0; i < NewXYArray.Num(); ++i)
			{
				const FIntPoint& NewPoint = NewXYArray[i];
				const int32 NewTile = ACWMap::xy2tile(NewPoint.X, NewPoint.Y);
				if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(NewTile))
				{
					if (ACWPawn* GamePawn = MyMap->GetPawnByTile(NewTile).Get())
					{	// 场景棋子
						if (GamePawn->IsPawnType(ECWPawnType::Character))
						{
							continue;
						}
					}
					// 阻挡地块格子属性
					if ((MyMap->getMapTileAttribute(NewTile) & (uint8)ECWDungeonTileAttribute::Obstacle) > 0)
					{
						continue;
					}
					TileArray.Push(NewTile);
				}
			}
			
			// 排序:Z位置低至高
			TileArray.Sort(
			[Generator](const int32 InTileA, const int32 InTileB) -> bool
			{
				/*const int32 NewALayer = Generator->GetGridLayerByTile(InTileA);
				const int32 NewBLayer = Generator->GetGridLayerByTile(InTileB);
				return NewALayer < NewBLayer;*/
				const float NewAOffsetZ = Generator->GetOffsetZ(InTileA);
				const float NewBOffsetZ = Generator->GetOffsetZ(InTileB);
				return NewAOffsetZ < NewBOffsetZ;
			});
			if (TileArray.Num() > 0)
			{
				return TileArray[0];
			}
		}
	}

	CWG_WARNING(">> PhysicsSys::GetTargetNearOptimumTile, Search Target fail! return InParamTile[%d].", InParamTile);
	return InParamTile;
}
