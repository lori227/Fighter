﻿
#include "CWRandomEventCtrl.h"

#include "CWMap.h"
#include "CWMapTile.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWCfgUtils.h"
#include "CWGameMode.h"
#include "CWCommonUtil.h"
#include "CWGameState.h"
#include "CWCfgManager.h"
#include "CWDungeonItem.h"
#include "CWDungeonTile.h"
#include "CWRandEvtEffect.h"
#include "CWBattleCalculate.h"
#include "CWDungeonItemDataStruct.h"
#include "CWRandomDungeonGenerator.h"


UCWRandomEventCtrl::UCWRandomEventCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;
	bAutoRegister = true;
}

UCWRandomEventCtrl::~UCWRandomEventCtrl()
{
}

void UCWRandomEventCtrl::BeginDestroy()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		REMOVE_EVT_DELEGATE(Evt_Mgr->OnRoundIndexChangeInServer, this);
	}

	Super::BeginDestroy();
}

bool UCWRandomEventCtrl::InitInServer()
{
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	check(Generator);

	DungeonGeneratorRef = Generator;
	ENetMode NetMode = Generator->GetNetMode();
	if (NetMode != NM_DedicatedServer && NetMode != NM_Standalone)
	{
		CWG_WARNING(">>> %s::InitRandomEvent, NM_Client is not need init...", *GetName());
		return false;
	}

	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{	// 添加回合改变委托
		ADD_EVT_DELEGATE(Evt_Mgr->OnRoundIndexChangeInServer, this, &UCWRandomEventCtrl::OnRoundChangeInServer, "OnRoundChangeInServer");
	}

	// Clear 
	InitEvtArray.Empty();
	ActiveEvtArray.Empty();
	InactiveEvtArray.Empty();

	// Init
	if (UCWCfgManager* Cfg_Mgr = CFG_MGR(this))
	{
		// 初始化随机事件列表
		if (const UCWConfigTable* CfgTable = Cfg_Mgr->GetConfigTable(FCWCfgKey::RandomEvt))
		{
			TArray<FName> AllRows = CfgTable->GetRowNames();
			for (auto& RowId : AllRows)
			{
				if (FCWRandomEvtData* EvtData = CfgTable->GetRow<FCWRandomEvtData>(RowId))
				{
					FCWRandomEvtGameData EvtGameData;
					EvtGameData.EvtId = FNAME_TO_INT(RowId);
					EvtGameData.CfgData = *EvtData;
					EvtGameData.CoolingValue = EvtData->CycleValue;
					EvtGameData.WaitActiveRound = EvtData->bNeedWarn ? 1 : 0;

					if (EvtData->GenerateType == 0)
					{	// 每回合都有可能产生
						InactiveEvtArray.AddUnique(EvtGameData);
					}else if (EvtData->GenerateType == 1)
					{	// 开局随场景生成产生
						InitEvtArray.AddUnique(EvtGameData);
					}
				}
			}
		}
	}

	return true;
}

void UCWRandomEventCtrl::OnRoundChangeInServer(int32 InCurRoundIdx, int32 InMaxRoundIdx)
{
	if (1 == InCurRoundIdx)
	{
		ExecInitEvtArray();
	}
	else
	{
		ExecEventArrayReset();
	}
}

void UCWRandomEventCtrl::ExecInitEvtArray()
{
	// 生成场景物件 BUFF
	if (InitEvtArray.Num() > 0)
	{
		for (auto& InitEvt : InitEvtArray)
		{
			ExecuteRandomEvt(InitEvt);
		}
	}
}

void UCWRandomEventCtrl::ExecEventArrayReset(const bool bFirstRound)
{
	// 执行激活列表事件
	bool bHasExecuteRandomEvt = false;
	for (auto& ActiveEvt : ActiveEvtArray)
	{
		if (--ActiveEvt.WaitActiveRound == 0)
		{
			ToggleEventWarn(ActiveEvt, false);
			ExecuteRandomEvt(ActiveEvt);
			bHasExecuteRandomEvt = true;
		}
	}

	// 未激活列表冷却
	TArray<int32> AllowRandomEvts;
	if (!bFirstRound)
	{	// 第一回合不减冷却
		for (auto& InactiveEvt : InactiveEvtArray)
		{
			if (--InactiveEvt.CoolingValue <= 0)
			{
				AllowRandomEvts.AddUnique(InactiveEvt.EvtId);
			}
		}
	}

	// 随机新事件
	if (!bHasExecuteRandomEvt && AllowRandomEvts.Num() > 0)
	{
		int32 RandomIdx = FMath::RandRange(0, AllowRandomEvts.Num() - 1);
		//if (AllowRandomEvts.IsValidIndex(RandomIdx))
		{
			int32 AllowRandomEvtId = AllowRandomEvts[RandomIdx];
			FCWRandomEvtGameData& EvtGameData = *InactiveEvtArray.FindByPredicate(
			[AllowRandomEvtId](FCWRandomEvtGameData& ElemsData) -> bool
			{
				return ElemsData.EvtId == AllowRandomEvtId;
			}
			);

			if (IsConditionOk(EvtGameData))
			{	// 条件是否符合
				int32 RandomProb = FMath::RandRange(0, 100);
				if (RandomProb <= EvtGameData.CfgData.Prob)
				{	// 生成新事件...
					//EvtGameData.CfgData = EvtGameData.CfgData;
					EvtGameData.CoolingValue = EvtGameData.CfgData.CycleValue;
					EvtGameData.WaitActiveRound = EvtGameData.CfgData.bNeedWarn ? 1 : 0;
					EvtGameData.TargetTile = GetNeedWarnTargetTile(EvtGameData);

					if (EvtGameData.WaitActiveRound <= 0)
					{
						ExecuteRandomEvt(EvtGameData);
					}
					else
					{
						ToggleEventWarn(EvtGameData, true);
						ActiveEvtArray.AddUnique(EvtGameData);
					}

					CWG_WARNING(">> %s.CreateNewEvent, EvtId[%d] WaitActiveRound[%d] TargetTile[%d] \t\t CfgData[%s].", *GetName(),
						EvtGameData.EvtId, (int32)EvtGameData.WaitActiveRound, EvtGameData.TargetTile, *EvtGameData.CfgData.ToDebugString());
				}
			}
		}
	}

	// 移出激活列表已执行事件 & 并加入未激活列表
	ActiveEvtArray.RemoveAll(
	[this](const FCWRandomEvtGameData& ElemData) -> bool
	{
		if (ElemData.WaitActiveRound <= 0)
		{
			FCWRandomEvtGameData NewEvtData;
			NewEvtData.EvtId = ElemData.EvtId;
			NewEvtData.CfgData = ElemData.CfgData;

			NewEvtData.CoolingValue = ElemData.CfgData.CycleValue;
			NewEvtData.WaitActiveRound = ElemData.CfgData.bNeedWarn ? 1 : 0;
			NewEvtData.TargetTile = INDEX_NONE;
			InactiveEvtArray.AddUnique(NewEvtData);
			return true;
		}
		return false;
	});
}

int32 UCWRandomEventCtrl::GetNeedWarnTargetTile(const FCWRandomEvtGameData& InRandomEvtData)
{
	return GetCommTargetTile(InRandomEvtData);
}

int32 UCWRandomEventCtrl::GetCommTargetTile(const FCWRandomEvtGameData& InRandomEvtData)
{
	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	ACWMap* MapActor = Generator ? UCWFuncLib::GetActor<ACWMap>(Generator) : nullptr;
	if (nullptr != Generator && nullptr != MapActor)
	{
		TArray<int32> LevelTerrainArray;	// RandomArrayIdx = 0 | 1 | 2
		TArray<int32> HighTerrainArray;		// RandomArrayIdx = 1
		TArray<int32> LowTerrainArray;		// RandomArrayIdx = 2
		TArray<int32> InvalidTileArray = Generator->GetDungeonFallTileArray();
		TArray<ACWDungeonTile*>& TileArray = Generator->GetDungeonTileList();
		for (const ACWDungeonTile* DungeonTile : TileArray)
		{
			if (IsValid(DungeonTile) && !InvalidTileArray.Contains(DungeonTile->GetTile()))
			{
				int32 TileNum = DungeonTile->GetTile();
				int32 LayerNum = Generator->GetGridLayerByTile(TileNum);
				if (LayerNum < 0)
				{
					LowTerrainArray.AddUnique(TileNum);
				}else if (LayerNum > 0)
				{
					HighTerrainArray.AddUnique(TileNum);
				}else 
				{
					LevelTerrainArray.AddUnique(TileNum);
				}
			}
		}

		TArray<int32> RandomTerrainArray;
		// 生成位置(0:任意地势 1:高地势 2:低地势)
		const uint8 GenerateLandType = InRandomEvtData.CfgData.GenerateLandType;
		int32 RandomArrayIdx = (GenerateLandType == 0) ? FMath::RandRange(0, 2) : GenerateLandType;
		switch (RandomArrayIdx)
		{
		case 0: { RandomTerrainArray = MoveTemp(LevelTerrainArray); }break;
		case 1: { RandomTerrainArray = MoveTemp(HighTerrainArray); }break;
		case 2: { RandomTerrainArray = MoveTemp(LowTerrainArray); }break;
		}

		if (RandomTerrainArray.Num() > 0)
		{
			// 生成目标(0:任意目标 1:空地块(不包括棋子))
			const uint8 GenerateTargetType = InRandomEvtData.CfgData.GenerateTargetType;
			if (GenerateTargetType == 0)
			{
				const int32 RandElemIdx = FMath::RandRange(0, RandomTerrainArray.Num() - 1);
				return RandomTerrainArray[RandElemIdx];
			}else if (GenerateTargetType == 1)
			{
				TArray<int32> EmptyTerrainArray;
				for (int32 i = 0; i < RandomTerrainArray.Num(); ++i)
				{
					const int32 TileNum = RandomTerrainArray[i];
					const bool bHasGamePawn = MapActor->GetPawnByTile(TileNum).IsValid();
					const TArray<ACWDungeonItem*>& DungeonItems = Generator->GetAllDungeonItem(TileNum);
					if (!bHasGamePawn && DungeonItems.Num() <= 0)
					{
						EmptyTerrainArray.AddUnique(TileNum);
					}
				}
				// 选取空地块为目标
				if (EmptyTerrainArray.Num() > 0)
				{
					const int32 RandElemIdx = FMath::RandRange(0, EmptyTerrainArray.Num() - 1);
					return EmptyTerrainArray[RandElemIdx];
				}
			}
		}
	}

	return INDEX_NONE;
}

bool UCWRandomEventCtrl::IsConditionOk(const FCWRandomEvtGameData& InRandomEvtData)
{
	const ECWWeatherType WeatherType = InRandomEvtData.CfgData.GenerateWeather;
	if (ECWWeatherType::None == WeatherType)
	{
		return true;
	}

	ACWGameState* MyGameState = UCWFuncLib::GetActor<ACWGameState>(this);
	bool bIsConditionOk = MyGameState ? (WeatherType == (ECWWeatherType)MyGameState->GetWeatherIdx()) : false;
	if (!bIsConditionOk)
	{	// 天气限制
		CWG_WARNING(">> %s::IsConditionOk, WeatherType limit. EvtInfo[%s].", *GetName(), *InRandomEvtData.CfgData.ToDebugString());
	}

	return bIsConditionOk;
}

void UCWRandomEventCtrl::ToggleEventWarn(const FCWRandomEvtGameData InRandomEvtData, bool bNewVisible)
{
	if (ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get())
	{
		const int32 TagetTileNum = InRandomEvtData.TargetTile;
		if (InRandomEvtData.CfgData.bNeedWarn && (TagetTileNum > 0))
		{
			NetMulticastToggleRandEvtWarn(bNewVisible, InRandomEvtData);

			if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TagetTileNum))
			{	// 增加预警地块销毁检测
				if (bNewVisible)
				{
					ADD_EVT_DELEGATE(DungeonTile->OnDestroyed, this, &UCWRandomEventCtrl::OnActorDestroyedImpl, "OnActorDestroyedImpl");
				}
				else
				{
					REMOVE_EVT_DELEGATE(DungeonTile->OnDestroyed, this);
				}
			}
		}
	}
}

void UCWRandomEventCtrl::OnToggleMeteoriteDamage(const FCWRandomEvtGameData& InRandomEvtData)
{
	if (IsNetMode(NM_Client))
	{
		return;
	}

	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	ACWMap* MapActor = UCWFuncLib::GetActor<ACWMap>(Generator);
	if (nullptr == Generator || nullptr == MapActor || InRandomEvtData.TargetTile <= INDEX_NONE)
	{
		return;
	}
	CWG_WARNING(">>> %s::OnToggleMeteoriteDamage, InRandomEvtData[%s].", *GetName(), *InRandomEvtData.CfgData.ToDebugString());

	// 查找&伤害 范围内对象
	bool bHasGPawn = false;
	TArray<int32> ToggleArray = UCWRandomEventCtrl::GetDamageRangeArray(Generator, InRandomEvtData);
	for (auto& TileNum : ToggleArray)
	{
		if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TileNum))
		{
			if (ACWPawn* GamePawn = MapActor->GetPawnByTile(TileNum).Get())
			{
				bHasGPawn = true;
				AddRandEvtToPawn(GamePawn, InRandomEvtData);
			}

			const TArray<ACWDungeonItem*>& DungeonItems = Generator->GetAllDungeonItem(TileNum);
			for (int32 i = 0; i < DungeonItems.Num(); ++i)
			{
				ACWDungeonItem* DungeonItem = DungeonItems[i];
				if (nullptr != DungeonItem && !DungeonItem->IsBuffObject())
				{
					bHasGPawn = true;
					AddRandEvtToPawn(DungeonItem, InRandomEvtData);
				}
			}
		}
	}

	if (!bHasGPawn && ToggleArray.Num() > 0)
	{	// 没有就生成一个阻挡石头
		CreateDungeonItem(InRandomEvtData);
	}
}

void UCWRandomEventCtrl::OnToggleDarkHoleDamage(const FCWRandomEvtGameData& InRandomEvtData)
{
	if (IsNetMode(NM_Client))
	{
		return;
	}

	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	ACWMap* MapActor = UCWFuncLib::GetActor<ACWMap>(Generator);
	if (nullptr == Generator || nullptr == MapActor || InRandomEvtData.TargetTile <= INDEX_NONE)
	{
		return;
	}
	CWG_WARNING(">>> %s::OnToggleDarkHoleDamage, InRandomEvtData[%s].", *GetName(), *InRandomEvtData.CfgData.ToDebugString());

	// 查找范围内对象
	TArray<ACWPawn*> TogglePawnArray;
	TArray<int32> ToggleArray = UCWRandomEventCtrl::GetDamageRangeArray(Generator, InRandomEvtData);
	for (auto& TileNum : ToggleArray)
	{
		if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TileNum))
		{
			if (ACWPawn* GamePawn = MapActor->GetPawnByTile(TileNum).Get())
			{
				TogglePawnArray.AddUnique(GamePawn);
			}

			const TArray<ACWDungeonItem*>& DungeonItems = Generator->GetAllDungeonItem(TileNum);
			for (int32 i = 0; i < DungeonItems.Num(); ++i)
			{
				ACWDungeonItem* DungeonItem = DungeonItems[i];
				if (nullptr != DungeonItem && !DungeonItem->IsBuffObject())
				{
					TogglePawnArray.AddUnique(DungeonItem);
				}
			}
		}
	}

	// 移动范围内对象
	/*ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(InRandomEvtData.TargetTile);
	for (ACWPawn* MyGamePawn : TogglePawnArray)
	{
		if (IsValid(MyGamePawn) && !MyGamePawn->IsDieOrDeath())
		{
			MyGamePawn->EnableMoveToTargetComp(DungeonTile->GetActorLocation());
		}
	}*/

	// 销毁范围内对象
	FTimerHandle TimerHandle;
	FTimerDelegate TimerCallback;
	TimerCallback.BindLambda([this, TogglePawnArray, InRandomEvtData]()
	{
		for (ACWPawn* MyGamePawn : TogglePawnArray)
		{	// 直接销毁范围内物体和角色
			if (IsValid(MyGamePawn) && !MyGamePawn->IsDieOrDeath())
			{
				AddRandEvtToPawn(MyGamePawn, InRandomEvtData);
			}
		}
	});
	GetWorld()->GetTimerManager().SetTimer(TimerHandle, TimerCallback, 1.f, false);
}

void UCWRandomEventCtrl::OnToggleThunderDamage(const FCWRandomEvtGameData& InRandomEvtData)
{
	if (IsNetMode(NM_Client))
	{
		return;
	}

	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	ACWMap* MapActor = UCWFuncLib::GetActor<ACWMap>(Generator);
	if (nullptr == Generator || nullptr == MapActor || InRandomEvtData.TargetTile <= INDEX_NONE)
	{
		return;
	}
	CWG_LOG(">>> %s::OnToggleThunderDamage, InRandomEvtData[%s].", *GetName(), *InRandomEvtData.CfgData.ToDebugString());

	// 查找&伤害 范围内对象
	TArray<int32> ToggleArray = UCWRandomEventCtrl::GetDamageRangeArray(Generator, InRandomEvtData);
	for (auto& TileNum : ToggleArray)
	{
		if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TileNum))
		{
			if (ACWPawn* GamePawn = MapActor->GetPawnByTile(TileNum).Get())
			{
				AddRandEvtToPawn(GamePawn, InRandomEvtData);
			}

			const TArray<ACWDungeonItem*>& DungeonItems = Generator->GetAllDungeonItem(TileNum);
			for (int32 i = 0; i < DungeonItems.Num(); ++i)
			{
				ACWDungeonItem* DungeonItem = DungeonItems[i];
				if (nullptr != DungeonItem && !DungeonItem->IsBuffObject())
				{
					AddRandEvtToPawn(DungeonItem, InRandomEvtData);
				}
			}
		}
	}
}

void UCWRandomEventCtrl::AddRandEvtToPawn(ACWPawn* InPawn, const FCWRandomEvtGameData& InRandomEvtData)
{
	CWG_LOG(">>> %s::AddRandEvtToPawn, InPawn[%s] InRandomEvtData[%s].",
		*GetName(), *InPawn->GetDisplayName(), *InRandomEvtData.CfgData.ToDebugString());

	if (IsValid(InPawn) && !InPawn->IsDieOrDeath())
	{
		if (InPawn->IsPawnType(ECWPawnType::Character))
		{
			// 施加Buff
			InPawn->GenerateBuff(InRandomEvtData.CfgData.BuffId, ECWBuffSouceType::RandEvt);

			// 施加元素反应
			const EObjElemType EvtOwnElemType = InRandomEvtData.CfgData.OwnElemType;
			if (FElemUtils::IsValidObjElemType(EvtOwnElemType))
			{	// 计算元素反应
				UCWBattleCalculate::Get()->CalculateElemReaction(EvtOwnElemType, InPawn, ECWBuffSouceType::RandEvt);
			}
		}
		else
		{	// 非棋子直接销毁
			InPawn->DieInServer();
		}
	}
}

bool UCWRandomEventCtrl::CreateDungeonItem(const FCWRandomEvtGameData& InRandomEvtData)
{
	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	UWorld* const MyWorld = Generator ? Generator->GetWorld() : nullptr;
	ACWGameMode* MyGameMode = MyWorld ? MyWorld->GetAuthGameMode<ACWGameMode>() : nullptr;
	ACWGameState* MyGameState = MyGameMode ? MyGameMode->GetGameState<ACWGameState>() : nullptr;
	if (nullptr == MyWorld || nullptr == MyGameMode || nullptr == MyGameState)
	{
		return false;
	}

	const int32 TargetTile = InRandomEvtData.TargetTile;
	const int32 LevelItemId = InRandomEvtData.CfgData.ItemId;
	if (TargetTile <= INDEX_NONE || LevelItemId <= 0)
	{
		CWG_WARNING(">> %s::CreateDungeonItem, TargetTile[%d] LevelItemId[%d].", *GetName(), TargetTile, LevelItemId);
		return false;
	}

	if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TargetTile))
	{
		//if (const FCWDungeonItemDataStruct* ItemCfgData = FCWCfgUtils::GetLevelItemData(MyWorld, LevelItemId))
		//{
		//	
		//	ACWDungeonItem* TempItem = MyWorld->SpawnActor<ACWDungeonItem>();
		//	if (nullptr != TempItem && TempItem->InitInServer(Generator, TargetTile, LevelItemId))
		//	{
		//		FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
		//		TempItem->AttachToActor(DungeonTile, AttachmentRules);
		//		TempItem->SetOwner(DungeonTile);

		//		//TempItem->SetActorLocation(DungeonTile->GetActorLocation());
		//		if (!ItemCfgData->DungeonItemResName.IsEmpty())
		//		{
		//			TempItem->LoadMesh(ItemCfgData->DungeonItemResName);
		//		}

		//		TempItem->SetCampTag(ECWCampTag::H);
		//		TempItem->SetCampControllerIndex(ECWCampControllerIndex::Eight);
		//		TempItem->SetControllerPawnIndex(0);
		//		TempItem->ForceNetUpdate();

		//		Generator->SetDungeonItem(TargetTile, TempItem);

		//		CWG_WARNING(">>> %s::CreateDungeonItem, TargetTile[%d] InRandomEvtData[%s] .", 
		//			*GetName(), TargetTile, *InRandomEvtData.CfgData.ToDebugString());

		//		return true;
		//	}
		//}
		//else
		//{
		//	CWG_WARNING(">> %s::CreateDungeonItem, ItemCfgData is Null.. TargetTile[%d] LevelItemId[%d].", *GetName(), TargetTile, LevelItemId);
		//}
	}
	else
	{
		CWG_WARNING(">> %s::CreateDungeonItem, DungeonTile is Null.. TargetTile[%d] LevelItemId[%d].", *GetName(), TargetTile, LevelItemId);
	}
	return false;
}

bool UCWRandomEventCtrl::CreateEvtEffectActor(const FCWRandomEvtGameData& InRandomEvtData, TFunction<void(int32)>&& Callback)
{
	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	UWorld* const MyWorld = Generator ? Generator->GetWorld() : nullptr;
	if (nullptr == MyWorld || InRandomEvtData.TargetTile <= INDEX_NONE)
	{
		return false;
	}

	if (InRandomEvtData.CfgData.EffectId <= 0)
	{	// 无特效直接执行
		if (nullptr != Callback)
		{
			Callback(0);
		}
		return false;
	}

	if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(InRandomEvtData.TargetTile))
	{
		const FString& EffectAssetId = INT_TO_FSTRING(InRandomEvtData.CfgData.EffectId);
		if (UClass* TempleteClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::LevelItemAsset, EffectAssetId))
		{
			ACWRandEvtEffect* EvtEffect = MyWorld->SpawnActor<ACWRandEvtEffect>(TempleteClass);
			if (nullptr != EvtEffect && EvtEffect->InitInServer(InRandomEvtData))
			{
				FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
				EvtEffect->AttachToActor(DungeonTile, AttachmentRules);
				EvtEffect->SetOwner(DungeonTile);

				//EvtEffect->SetActorLocation(DungeonTile->GetActorLocation());
				EvtEffect->OnToggleDamage.AddLambda(Callback);

				CWG_LOG(">>> %s::CreateEvtEffectActor, TargetTile[%d] InRandomEvtData[%s] .",
					*GetName(), InRandomEvtData.TargetTile, *InRandomEvtData.CfgData.ToDebugString());

				return true;
			}
		}
	}

	return false;
}

void UCWRandomEventCtrl::NetMulticastToggleRandEvtWarn_Implementation(bool bNewVisible, const FCWRandomEvtGameData InRandomEvtData)
{
	if (/*!IsInServer() || */!IsNetMode(NM_DedicatedServer))
	{
		OnToggleRandEvtWarnInClient(bNewVisible, InRandomEvtData);

		//const ENetMode NetMode = GetNetMode();
		//CWG_WARNING(">>> NetMulticastToggleRandEvtWarn, NetMode[%s].", *UCWFuncLib::ENetMode_To_String(NetMode));
	}
}

void UCWRandomEventCtrl::OnToggleRandEvtWarnInClient(bool bNewVisible, const FCWRandomEvtGameData InRandomEvtData)
{
	ACWMap* MapActor = UCWFuncLib::GetActor<ACWMap>(GetWorld());
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(GetWorld());
	if (nullptr != MapActor && nullptr != Generator)
	{
		TArray<int32> NeedOpTileArray = UCWRandomEventCtrl::GetDamageRangeArray(Generator, InRandomEvtData, bNewVisible);

		for (auto& TileNum : NeedOpTileArray)
		{
			if (ACWMapTile* MapTile = MapActor->GetTile(TileNum))
			{
				MapTile->ToggleRandEvtWarn(bNewVisible);
			}
		}
	}
}

void UCWRandomEventCtrl::OnActorDestroyedImpl(AActor* InActor)
{
	const ENetMode NetMode = GetWorld()->GetNetMode();
	if (NetMode != NM_DedicatedServer && NetMode != NM_Standalone)
	{
		CWG_WARNING(">>> %s::OnActorDestroyedImpl, NM_Client is not need op...", *GetName());
		return ;
	}

	if (ACWDungeonTile* DungeonTile = Cast<ACWDungeonTile>(InActor))
	{
		const int32 InTile = DungeonTile->GetTile();
		if (InTile > 0 && ActiveEvtArray.Num() > 0)
		{	// 地块销毁时,关闭对应的预警
			for (auto& ActiveEvt : ActiveEvtArray)
			{
				if (ActiveEvt.TargetTile == InTile)
				{
					ToggleEventWarn(ActiveEvt, false);
				}
			}
		}
	}
}

TArray<int32> UCWRandomEventCtrl::GetDamageRangeArray(ACWRandomDungeonGenerator* Generator, 
	const FCWRandomEvtGameData& InEvtData, const bool bCheckTargetTileValid)
{
	TArray<int32> OutRangeArray;
	if (nullptr != Generator && InEvtData.TargetTile > INDEX_NONE)
	{
		const int32 InCenterTile = InEvtData.TargetTile;
		ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(InCenterTile);
		ACWMap* MapActor = UCWFuncLib::GetActor<ACWMap>(Generator);

		const bool bTargetValid = bCheckTargetTileValid ? (nullptr != DungeonTile) : true;
		if (bTargetValid && nullptr != MapActor)
		{
			OutRangeArray.AddUnique(InCenterTile);
			if (InEvtData.CfgData.RangeType == 1)
			{
				if (InEvtData.CfgData.RangeSize == 2)
				{	// 范围大小: 四方格子
					int32 CX, CY;
					ACWMap::tile2xy(InCenterTile, CX, CY);
					TArray<FIntPoint> RangePointArray;
					RangePointArray.Add(FIntPoint(CX + 1, CY + 1));
					RangePointArray.Add(FIntPoint(CX + 1, CY - 1));
					RangePointArray.Add(FIntPoint(CX + 1, CY));
					RangePointArray.Add(FIntPoint(CX - 1, CY + 1));
					RangePointArray.Add(FIntPoint(CX - 1, CY - 1));
					RangePointArray.Add(FIntPoint(CX - 1, CY));
					RangePointArray.Add(FIntPoint(CX, CY + 1));
					RangePointArray.Add(FIntPoint(CX, CY - 1));
					for (auto& Elem : RangePointArray)
					{
						OutRangeArray.AddUnique(ACWMap::xy2tile(Elem.X, Elem.Y));
					}
				}
			}
		}
	}
	return OutRangeArray;
}

void UCWRandomEventCtrl::TestCreateDungeonItem(const int32 InTile, const int32 InItemId)
{
	FCWRandomEvtGameData RandomEvtData;
	RandomEvtData.TargetTile = InTile;
	RandomEvtData.CfgData.ItemId = InItemId;
	CreateDungeonItem(RandomEvtData);
}

void UCWRandomEventCtrl::TestCreateDungeonEvt(const int32 InTile, const int32 InEvtId)
{
	if (UCWCfgManager* Cfg_Mgr = CFG_MGR(this))
	{
		if (const FCWRandomEvtData* EvtData = FCWCfgUtils::GetRandomEvtData(this, InEvtId))
		{
			FCWRandomEvtGameData RandomEvtData;
			RandomEvtData.EvtId = InEvtId;
			RandomEvtData.TargetTile = InTile;
			RandomEvtData.CfgData = *EvtData;
			RandomEvtData.CfgData.GenerateWeather = ECWWeatherType::None;
			ExecuteRandomEvt(RandomEvtData);

			CWG_LOG(">> %s::TestCreateDungeonEvt, Ok!", *GetName());
		}
	}
}

bool UCWRandomEventCtrl::ExecuteRandomEvt(FCWRandomEvtGameData& InRandomEvtData)
{
	ACWRandomDungeonGenerator* Generator = DungeonGeneratorRef.Get();
	UWorld* const MyWorld = Generator ? Generator->GetWorld() : nullptr;
	ACWGameMode* MyGameMode = MyWorld ? MyWorld->GetAuthGameMode<ACWGameMode>() : nullptr;
	ACWGameState* MyGameState = MyGameMode ? MyGameMode->GetGameState<ACWGameState>() : nullptr;
	if (nullptr == MyWorld || nullptr == MyGameMode || nullptr == MyGameState)
	{
		return false;
	}

	if (!IsConditionOk(InRandomEvtData))
	{	// 条件是否符合
		return false;
	}

	int32 TargetTile = InRandomEvtData.TargetTile;
	if (TargetTile <= INDEX_NONE)
	{	// 重置生成目标格子编号
		TargetTile = GetCommTargetTile(InRandomEvtData);
		InRandomEvtData.TargetTile = TargetTile;
	}

	if (TargetTile > INDEX_NONE)
	{
		if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(TargetTile))
		{
			/** 特效ID(特效播放完->触发伤害范围->生成场景物品) */

			bool bIsEventOpOk = false;
			if (InRandomEvtData.CfgData.EvtType == 0)
			{	// 0:生成物件
				bIsEventOpOk = CreateDungeonItem(InRandomEvtData);
			}
			else if (InRandomEvtData.CfgData.EvtType == 1)
			{	// 1:火陨石
				bIsEventOpOk = CreateEvtEffectActor(InRandomEvtData,
				[this, InRandomEvtData](int32)
				{
					OnToggleMeteoriteDamage(InRandomEvtData);
				});
			}
			else if (InRandomEvtData.CfgData.EvtType == 2)
			{	// 2:黑洞
				bIsEventOpOk = CreateEvtEffectActor(InRandomEvtData,
				[this, InRandomEvtData](int32)
				{
				});
				OnToggleDarkHoleDamage(InRandomEvtData);
			}
			else if (InRandomEvtData.CfgData.EvtType == 3)
			{	// 3:惊雷(直接加BUFF)
				bIsEventOpOk = CreateEvtEffectActor(InRandomEvtData,
				[this, InRandomEvtData](int32)
				{
				});
				OnToggleThunderDamage(InRandomEvtData);
			}

			return bIsEventOpOk;
		}
	}

	return false;
}
