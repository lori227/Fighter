﻿
#include "CWStatisticsSystemCtrl.h"

#include "UnrealNetwork.h"
#include "GameFramework/Actor.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCommonUtil.h"


UCWStatisticsSystemCtrl::UCWStatisticsSystemCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;
	bAutoRegister = true;
}

UCWStatisticsSystemCtrl::~UCWStatisticsSystemCtrl()
{
}

bool UCWStatisticsSystemCtrl::InitInServer()
{
	OwnerPawn = Cast<ACWPawn>(GetOwner());
	check(OwnerPawn);

	MapStatisticsData.Empty();

	//CWG_LOG(">> StatisticsSys::InitInServer, OwnerPawn[%s] CfgInfo[%s] Init Ok...", *OwnerPawn->ToDebugString(), *ObjInfo->ToDebugString());
	return true;
}

void UCWStatisticsSystemCtrl::SetStatisticsData(ECWStatisticsType InType, int32 InParamValue)
{
	if (!IsValidActor(OwnerPawn) || OwnerPawn->IsNetMode(NM_Client))
	{
		return;
	}

	MapStatisticsData.FindOrAdd(InType) = InParamValue;
}

void UCWStatisticsSystemCtrl::AddStatisticsData(ECWStatisticsType InType, int32 InAddValue)
{
	if (!IsValidActor(OwnerPawn) || OwnerPawn->IsNetMode(NM_Client))
	{
		return;
	}

	MapStatisticsData.FindOrAdd(InType) += InAddValue;
}

int32 UCWStatisticsSystemCtrl::GetStatisticsData(ECWStatisticsType InType)
{
	return MapStatisticsData.FindRef(InType);
}

const TMap<ECWStatisticsType, int32>& UCWStatisticsSystemCtrl::GetMapStatisticsData()
{
	return MapStatisticsData;
}

void UCWStatisticsSystemCtrl::BeginDestroy()
{
	Super::BeginDestroy();

}

void UCWStatisticsSystemCtrl::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	//DOREPLIFETIME(UCWElementSystemCtrl, ObjElemId);
}

FString UCWStatisticsSystemCtrl::ToDebugString() const
{
	FString OutValue = OwnerPawn->ToDebugString() + TEXT("	*	\n");
	for (const TPair<ECWStatisticsType, int32> MapPair : MapStatisticsData)
	{
		OutValue += ToString(MapPair.Key) + TEXT(" - ") + INT_TO_FSTRING(MapPair.Value);
	}
	return OutValue;
}

FString UCWStatisticsSystemCtrl::ToString(ECWStatisticsType InStatisticsType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWStatisticsType"), InStatisticsType);
}
