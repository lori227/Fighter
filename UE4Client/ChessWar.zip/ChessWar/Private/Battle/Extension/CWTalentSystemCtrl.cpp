﻿
#include "CWTalentSystemCtrl.h"

#include "UnrealNetwork.h"
#include "GameFramework/Actor.h"

#include "CWPawn.h"


UCWTalentSystemCtrl::UCWTalentSystemCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;
	bAutoRegister = true;
}

UCWTalentSystemCtrl::~UCWTalentSystemCtrl()
{
}

bool UCWTalentSystemCtrl::InitInServer(const int32 InObjTalentId)
{
	OwnerPawn = Cast<ACWPawn>(GetOwner());
	check(OwnerPawn);

	//CWG_LOG(">> TalentSys::InitInServer, OwnerPawn[%s] CfgInfo[%s] Init Ok...", *OwnerPawn->ToDebugString(), *ObjInfo->ToDebugString());
	return true;
}

const TArray<int32>& UCWTalentSystemCtrl::GetArrayTalentIds()
{
	return ArrayTalentIds;
}

void UCWTalentSystemCtrl::BeginDestroy()
{
	Super::BeginDestroy();

}

void UCWTalentSystemCtrl::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	//DOREPLIFETIME(UCWElementSystemCtrl, ObjElemId);
}

FString UCWTalentSystemCtrl::ToDebugString() const
{
	return FString::Printf(TEXT("Owner[%s] "), *GetOwner()->GetName());
}
