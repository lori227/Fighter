﻿
#include "MovementActorComp.h"

#include "Net/UnrealNetwork.h"
#include "Containers/Ticker.h"
#include "GameFramework/Actor.h"


UMovementActorComp::UMovementActorComp(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;
	bAutoRegister = true;
}

UMovementActorComp::~UMovementActorComp()
{
}

void UMovementActorComp::BeginPlay()
{
	Super::BeginPlay();

	if (AActor* Owner = GetOwner())
	{
		const FVector& OwnerPoint = Owner->GetActorLocation();
		if (!TargetPoint.IsNearlyZero() && !TargetPoint.Equals(OwnerPoint))
		{
			SimpleMoveToTargetImpl();
		}
		else
		{
			TargetPoint = OwnerPoint;
		}
	}
}

void UMovementActorComp::BeginDestroy()
{
	StopSimpleMoveToTarget();

	Super::BeginDestroy();
}

void UMovementActorComp::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UMovementActorComp, TargetPoint);
}

void UMovementActorComp::SimpleMoveToTarget(const FVector& InTargetPoint)
{
	TargetPoint = InTargetPoint;
}

void UMovementActorComp::StopSimpleMoveToTarget()
{
	FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
}

void UMovementActorComp::OnRep_TargetPoint()
{
	SimpleMoveToTargetImpl();
}

void UMovementActorComp::SimpleMoveToTargetImpl()
{
	FTickerDelegate OnTickDel = FTickerDelegate::CreateUObject(this, &UMovementActorComp::OnTick);
	TickDelegateHandle = FTicker::GetCoreTicker().AddTicker(OnTickDel);
}

bool UMovementActorComp::OnTick(float DeltaTime)
{
	if (IsPendingKill())
	{
		FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
		return false;
	}

	if (AActor* Owner = GetOwner())
	{
		const FVector& OwnerPoint = Owner->GetActorLocation();
		const FVector& MoveDir = (TargetPoint - OwnerPoint).GetSafeNormal();
		FVector MovePoint = MoveDir * 9.8f * DeltaTime;
		if (FVector::Distance(MovePoint, TargetPoint) <= 5.f)
		{
			MovePoint = TargetPoint;
			StopSimpleMoveToTarget();
		}
		Owner->SetActorLocation(MovePoint);
		return true;
	}

	StopSimpleMoveToTarget();
	return true;
}
