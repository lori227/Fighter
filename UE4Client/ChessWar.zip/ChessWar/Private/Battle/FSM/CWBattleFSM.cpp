#include "CWBattleFSM.h"
#include "CWGameMode.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBattleFSM, All, All);


UCWBattleFSM::UCWBattleFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWBattleFSM::Init(ACWGameMode* ParamGameMode)
{
	GameMode = ParamGameMode;
}

ACWGameMode* UCWBattleFSM::GetGameMode()
{
	return GameMode;
}

void UCWBattleFSM::BeginDestroy()
{
	Super::BeginDestroy();
}
