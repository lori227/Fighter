#include "CWBattleFightingToWaitingDungeonTileFallEvent.h"


FCWBattleFightingToWaitingDungeonTileFallEvent::FCWBattleFightingToWaitingDungeonTileFallEvent()
	:FCWFSMEvent()
{

}


FCWBattleFightingToWaitingDungeonTileFallEvent::FCWBattleFightingToWaitingDungeonTileFallEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}