#include "CWBattleReadyTimeOutEvent.h"


FCWBattleReadyTimeOutEvent::FCWBattleReadyTimeOutEvent()
	:FCWFSMEvent()
{

}


FCWBattleReadyTimeOutEvent::FCWBattleReadyTimeOutEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}