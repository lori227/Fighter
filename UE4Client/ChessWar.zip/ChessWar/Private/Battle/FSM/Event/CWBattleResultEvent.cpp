#include "CWBattleResultEvent.h"


FCWBattleResultEvent::FCWBattleResultEvent()
	:FCWFSMEvent()
{

}


FCWBattleResultEvent::FCWBattleResultEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ECWCampTag ParamCampTag)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,WinCampTag(ParamCampTag)
{


}