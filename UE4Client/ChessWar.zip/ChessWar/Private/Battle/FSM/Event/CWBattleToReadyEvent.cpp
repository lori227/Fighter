#include "CWBattleToReadyEvent.h"


FCWBattleToReadyEvent::FCWBattleToReadyEvent()
	:FCWFSMEvent()
{

}


FCWBattleToReadyEvent::FCWBattleToReadyEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}