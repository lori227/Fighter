﻿
#include "CWBattleFightingState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWGameMode.h"
#include "CWGameState.h"
#include "CWBattleFSM.h"
#include "CWBattleFightingFSM.h"
#include "CWBattleFightingToNormalEvent.h"
#include "CWBattleFightingToNoRunningEvent.h"

#include "CWPawn.h"
#include "CWPlayerController.h"
#include "CWComDef.h"


FCWBattleFightingState::FCWBattleFightingState(UCWFSM* ParamParent, int ParamStateId)
	:FCWBattleStateBase(ParamParent, ParamStateId)
{

}

bool FCWBattleFightingState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleFightingState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	ACWGameMode* GameMode = GetGameMode();
	check(GameMode);
	ACWGameState* GameState = GetGameState();
	check(GameState);
	UCWBattleFightingFSM* BattleFightingFSM = GameMode->GetBattleFightingFSM();
	check(BattleFightingFSM);

	GameState->SetCurBattleState(ECWBattleState::Fighting);

	if (Event->EventId == (int)ECWBattleEvent::ReadyTimeOut)
	{
		ECWBattleFightingState CurBattleFightingState = (ECWBattleFightingState)(BattleFightingFSM->GetCurrentStateId());
		if (CurBattleFightingState == ECWBattleFightingState::NoRunning)
		{
			FCWBattleFightingToNormalEvent* ToNormalEvent = new FCWBattleFightingToNormalEvent((int)ECWBattleFightingEvent::ToNormal, (int)ECWBattleFightingState::Normal, ECWFSMStackOp::Set);
			BattleFightingFSM->DoEvent(ToNormalEvent);
		}
		GameMode->SetCampNum();
		GameMode->NextTurn();
	}
	else
	{
		//UE_LOG(LogCWBattleFSM, Log, TEXT("FCWBattleFightingState::OnEnter impossible"));
	}
}

void FCWBattleFightingState::OnExit(const FCWFSMEvent* Event)
{
	check(Event);
	check(Parent);
	ACWGameMode* GameMode = GetGameMode();
	check(GameMode);
	ACWGameState* GameState = GetGameState();
	check(GameState);
	UCWBattleFightingFSM* BattleFightingFSM = GameMode->GetBattleFightingFSM();
	check(BattleFightingFSM);

	FCWBattleFightingToNoRunningEvent* ToNoRunningEvent = new FCWBattleFightingToNoRunningEvent((int)ECWBattleFightingEvent::ToNoRunning, (int)ECWBattleFightingState::NoRunning, ECWFSMStackOp::Set);
	BattleFightingFSM->DoEvent(ToNoRunningEvent);
}

void FCWBattleFightingState::DoEvent(const FCWFSMEvent* Event)
{
	check(Event);
	check(Parent);
	ACWGameMode* GameMode = GetGameMode();
	check(GameMode);
	ACWGameState* GameState = GetGameState();
	check(GameState);
	UCWBattleFightingFSM* BattleFightingFSM = GameMode->GetBattleFightingFSM();
	check(BattleFightingFSM);

	if (Event->EventId <= (int)ECWBattleEvent::Max)
	{
		/*switch (Event->EventId)
		{

		}*/
	}
	else
	{
		BattleFightingFSM->DoEvent(Event);
	}
}

void FCWBattleFightingState::Tick(float DeltaTime)
{
	check(Parent);
	ACWGameMode* GameMode = GetGameMode();
	check(GameMode);
	ACWGameState* GameState = GetGameState();
	check(GameState);
	UCWBattleFightingFSM* BattleFightingFSM = GameMode->GetBattleFightingFSM();
	check(BattleFightingFSM);

	ECWBattleFightingState CurBattleFightingState = (ECWBattleFightingState)(BattleFightingFSM->GetCurrentStateId());
	if (!GameState->IsPauseGame() && CurBattleFightingState == ECWBattleFightingState::Normal)
	{
		// 每回合时间倒计时
		float CurActionRemainTime = GameState->GetCurActionRemainTime();
		CurActionRemainTime -= DeltaTime;
		GameState->SetCurActionRemainTime(CurActionRemainTime);

		// 每回合时间是否超时
		if (CurActionRemainTime <= 0.0f)
		{
			ECWCampTag CurCampTag = GameState->GetCurCampTag();
			ECWCampControllerIndex CurCampControllerIndex = GameState->GetCurCampControllerIndex();
			GameMode->SomePlayerControllerForceActionEnd(CurCampTag, CurCampControllerIndex);
		}
	}
}
