#include "CWBattleFightingWaitingDungeonTileFallState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "CWBattleFSM.h"
#include "Pawn/Controller//Player/CWPlayerController.h"
#include "Pawn/CWPawn.h"
#include "CWBattleFightingFSM.h"

FCWBattleFightingWaitingDungeonTileFallState::FCWBattleFightingWaitingDungeonTileFallState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWBattleFightingWaitingDungeonTileFallState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleFightingWaitingDungeonTileFallState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	ACWGameMode* TempGameMode = ((UCWBattleFightingFSM*)Parent)->GetGameMode();
	check(TempGameMode);

	TempGameMode->GenerateGungeonTileFall();
}

void FCWBattleFightingWaitingDungeonTileFallState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleFightingWaitingDungeonTileFallState::DoEvent(const FCWFSMEvent* Event)
{
	/*switch (Event->EventId)
	{

	}*/
}

void FCWBattleFightingWaitingDungeonTileFallState::Tick(float DeltaTime)
{
	check(Parent);
	ACWGameMode* TempGameMode = ((UCWBattleFightingFSM*)Parent)->GetGameMode();
	check(TempGameMode);

	//TempGameMode->GungeonTileFallEndAndNextTurnBegin();
}
