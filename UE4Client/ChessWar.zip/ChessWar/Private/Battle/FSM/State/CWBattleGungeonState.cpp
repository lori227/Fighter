#include "CWBattleGungeonState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"

FCWBattleGungeonState::FCWBattleGungeonState(UCWFSM* ParamParent, int ParamStateId)
	:FCWBattleStateBase(ParamParent, ParamStateId)
{

}


bool FCWBattleGungeonState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleGungeonState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	ACWGameState* GameState = GetGameState();
	check(GameState);

	GameState->SetCurBattleState(ECWBattleState::Dungeon);
}

void FCWBattleGungeonState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleGungeonState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWBattleGungeonState::Tick(float DeltaTime)
{

}