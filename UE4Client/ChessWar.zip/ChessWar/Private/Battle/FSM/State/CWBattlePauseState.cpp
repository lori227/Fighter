﻿#include "CWBattlePauseState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"

FCWBattlePauseState::FCWBattlePauseState(UCWFSM* ParamParent, int ParamStateId)
	:FCWBattleStateBase(ParamParent, ParamStateId)
{

}


bool FCWBattlePauseState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattlePauseState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	check(((UCWBattleFSM*)Parent)->GetGameMode());
	check(((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>());

	((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>()->SetCurBattleState(ECWBattleState::Pause);
}

void FCWBattlePauseState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattlePauseState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWBattlePauseState::Tick(float DeltaTime)
{

}