﻿#include "CWBattleReadyState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "Battle/FSM//Event/CWBattleReadyTimeOutEvent.h"

FCWBattleReadyState::FCWBattleReadyState(UCWFSM* ParamParent, int ParamStateId)
:FCWBattleStateBase(ParamParent, ParamStateId)
{
}

bool FCWBattleReadyState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleReadyState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	ACWGameState* GameState = GetGameState();
	check(GameState);

	GameState->SetCurBattleState(ECWBattleState::Ready);
}

void FCWBattleReadyState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleReadyState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWBattleReadyState::Tick(float DeltaTime)
{
	ACWGameState* GameState = GetGameState();
	if (!IsValid(GameState) || GameState->IsPauseGame())
	{
		return;
	}

	//战前准备时间倒计时
	float CurReadyRemainTime = GameState->GetCurReadyRemainTime();
	CurReadyRemainTime -= DeltaTime;
	GameState->SetCurReadyRemainTime(CurReadyRemainTime);

	// 战前准备时间是否超时 or 所有连接玩家都准备OK
	if (CurReadyRemainTime <= KINDA_SMALL_NUMBER || (GameState->GetCurReadyOkPlayerCnt() >= GameState->GetCurNetPlayerCount()))
	{
		FCWBattleReadyTimeOutEvent* ReadyTimeOutEvent = new FCWBattleReadyTimeOutEvent((int)ECWBattleEvent::ReadyTimeOut, (int)ECWBattleState::Fighting, ECWFSMStackOp::Set);
		Parent->DoEvent(ReadyTimeOutEvent);
	}
}
