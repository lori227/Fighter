﻿#include "CWBattleSettlementState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "CWBattleResultEvent.h"

FCWBattleSettlementState::FCWBattleSettlementState(UCWFSM* ParamParent, int ParamStateId)
	:FCWBattleStateBase(ParamParent, ParamStateId)
{

}


bool FCWBattleSettlementState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleSettlementState::OnEnter(const FCWFSMEvent* Event)
{
	const FCWBattleResultEvent* ResultEvent = (const FCWBattleResultEvent*)(Event);
	check(ResultEvent);

	check(Parent);
	check(((UCWBattleFSM*)Parent)->GetGameMode());
	check(((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>());

	((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>()->SetCurBattleState(ECWBattleState::Settlement);
	((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>()->NetMulticastRPCResult(ResultEvent->WinCampTag);
	
}

void FCWBattleSettlementState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleSettlementState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWBattleSettlementState::Tick(float DeltaTime)
{

}