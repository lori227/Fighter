﻿
#include "CWBattleStateBase.h"

#include "CWGameMode.h"
#include "CWGameState.h"

FCWBattleStateBase::FCWBattleStateBase(UCWFSM* ParamParent, int ParamStateId)
	: Super(ParamParent, ParamStateId)
{
}

/*
template<class T>
T* FCWBattleStateBase::GetGameMode() const
{
	UCWBattleFSM* BattleFSM = Cast<UCWBattleFSM>(Parent);
	if (nullptr != BattleFSM)
	{
		return BattleFSM->GetGameMode();
	}
	return nullptr;
}

template<class T>
T* FCWBattleStateBase::GetGameState() const
{
	ACWGameMode* GameMode = GetGameMode();
	if (nullptr != GameMode)
	{
		return GameMode->GetGameState<T>();
	}
	return nullptr;
}*/
