#include "CWBattleWaitingLoadingGungeonState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"

FCWBattleWaitingLoadingGungeonState::FCWBattleWaitingLoadingGungeonState(UCWFSM* ParamParent, int ParamStateId)
	:FCWBattleStateBase(ParamParent, ParamStateId)
{

}


bool FCWBattleWaitingLoadingGungeonState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleWaitingLoadingGungeonState::OnEnter(const FCWFSMEvent* Event)
{
	check(Parent);
	check(((UCWBattleFSM*)Parent)->GetGameMode());
	check(((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>());

	//((UCWBattleFSM*)Parent)->GetGameMode()->GetGameState<ACWGameState>()->SetCurBattleState(ECWBattleState::RandomGungeon);
}

void FCWBattleWaitingLoadingGungeonState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleWaitingLoadingGungeonState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWBattleWaitingLoadingGungeonState::Tick(float DeltaTime)
{

}