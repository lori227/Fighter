#include "CWBattleFightingFSM.h"
#include "CWBattleFSM.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBattleFightingFSM, All, All);


UCWBattleFightingFSM::UCWBattleFightingFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWBattleFightingFSM::Init(ACWGameMode* ParamGameMode)
{
	GameMode = ParamGameMode;
}

ACWGameMode* UCWBattleFightingFSM::GetGameMode()
{
	return GameMode;
}