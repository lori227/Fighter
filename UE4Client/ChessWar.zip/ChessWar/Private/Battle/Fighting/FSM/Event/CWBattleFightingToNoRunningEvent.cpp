#include "CWBattleFightingToNoRunningEvent.h"


FCWBattleFightingToNoRunningEvent::FCWBattleFightingToNoRunningEvent()
	:FCWFSMEvent()
{

}


FCWBattleFightingToNoRunningEvent::FCWBattleFightingToNoRunningEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}