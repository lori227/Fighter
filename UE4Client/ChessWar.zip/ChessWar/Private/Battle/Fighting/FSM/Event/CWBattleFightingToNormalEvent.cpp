#include "CWBattleFightingToNormalEvent.h"


FCWBattleFightingToNormalEvent::FCWBattleFightingToNormalEvent()
	:FCWFSMEvent()
{

}


FCWBattleFightingToNormalEvent::FCWBattleFightingToNormalEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}