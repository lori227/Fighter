#include "CWBattleFightingToWaitingEndEvent.h"


FCWBattleFightingToWaitingEndEvent::FCWBattleFightingToWaitingEndEvent()
	:FCWFSMEvent()
{

}


FCWBattleFightingToWaitingEndEvent::FCWBattleFightingToWaitingEndEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}