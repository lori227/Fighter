#include "CWBattleFightingNoRunningState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "CWBattleFSM.h"
#include "Pawn/Controller//Player/CWPlayerController.h"
#include "Pawn/CWPawn.h"

FCWBattleFightingNoRunningState::FCWBattleFightingNoRunningState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWBattleFightingNoRunningState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleFightingNoRunningState::OnEnter(const FCWFSMEvent* Event)
{

}

void FCWBattleFightingNoRunningState::OnExit(const FCWFSMEvent* Event)
{
}

void FCWBattleFightingNoRunningState::DoEvent(const FCWFSMEvent* Event)
{
	/*switch (Event->EventId)
	{

	}*/
}

void FCWBattleFightingNoRunningState::Tick(float DeltaTime)
{

}
