#include "CWBattleFightingNormalState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "CWBattleFSM.h"
#include "Pawn/Controller//Player/CWPlayerController.h"
#include "Pawn/CWPawn.h"

FCWBattleFightingNormalState::FCWBattleFightingNormalState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWBattleFightingNormalState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleFightingNormalState::OnEnter(const FCWFSMEvent* Event)
{
	
}

void FCWBattleFightingNormalState::OnExit(const FCWFSMEvent* Event)
{
}

void FCWBattleFightingNormalState::DoEvent(const FCWFSMEvent* Event)
{
	/*switch (Event->EventId)
	{

	}*/
}

void FCWBattleFightingNormalState::Tick(float DeltaTime)
{

}
