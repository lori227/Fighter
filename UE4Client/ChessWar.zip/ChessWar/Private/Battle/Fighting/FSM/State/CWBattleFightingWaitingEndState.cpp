#include "CWBattleFightingWaitingEndState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWBattleFSM.h"
#include "CWGameMode.h"
#include "Global/CWGameState.h"
#include "CWBattleFSM.h"
#include "Pawn/Controller//Player/CWPlayerController.h"
#include "Pawn/CWPawn.h"
#include "CWBattleFightingFSM.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBattleFightingWaitingEndState, All, All);

FCWBattleFightingWaitingEndState::FCWBattleFightingWaitingEndState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWBattleFightingWaitingEndState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWBattleFightingWaitingEndState::OnEnter(const FCWFSMEvent* Event)
{

}

void FCWBattleFightingWaitingEndState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWBattleFightingWaitingEndState::DoEvent(const FCWFSMEvent* Event)
{
	/*switch (Event->EventId)
	{

	}*/
}

void FCWBattleFightingWaitingEndState::Tick(float DeltaTime)
{
	check(Parent);
	ACWGameMode* TempGameMode = ((UCWBattleFightingFSM*)Parent)->GetGameMode();
	check(TempGameMode);
	ACWGameState* TempGameState = TempGameMode->GetGameState<ACWGameState>();
	check(TempGameState);

	ECWCampTag TempCampTag = TempGameState->GetCurCampTag();
	ECWCampControllerIndex TempCampControllerIndex = TempGameState->GetCurCampControllerIndex();
	if (TempGameMode->IsCampControllerActionEnd(TempCampTag, TempCampControllerIndex) &&
		TempGameMode->IsAllCampArrayActionEmpty())
	{
		ACWPlayerController* TempPlayerController = TempGameMode->GetPlayerControllerByCampTagAndControllerIndex(TempCampTag, TempCampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			TempGameMode->TryNext(TempPlayerController);
			FCWBattleFightingToNormalEvent* ToToNormalEvent = new FCWBattleFightingToNormalEvent((int)ECWBattleFightingEvent::ToNormal, (int)ECWBattleFightingState::Normal, ECWFSMStackOp::Set);
			TempGameMode->GetBattleFightingFSM()->DoEvent(ToToNormalEvent);
		}
		else
		{
			UE_LOG(LogCWBattleFightingWaitingEndState, Error, TEXT("FCWBattleFightingWaitingEndState::Tick TempPlayerController == nullptr, TempCampTag:%d, TempCampControllerIndex:%d."), (int)TempCampTag, (int)TempCampControllerIndex);
		}
	}
}
