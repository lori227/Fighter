#include "Skill/CWCastSkillContext.h"
#include "CWPawn.h"
#include "Component/CWPawnBattlePropertyComponent.h"
#include "BattleProperty/CWBattlePropertySet.h"
#include "BattleProperty/CWBattlePropertySetRef.h"
#include "CWBattlePropertyAffectorDataRef.h"
#include "CWBattlePropertyAffectorData.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWCastSkillContext, All, All);

//UCWCastSkillContext::UCWCastSkillContext(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}


UCWCastSkillContext::UCWCastSkillContext()
{
}

UCWCastSkillContext::~UCWCastSkillContext()
{
	PawnArrayPropertyAffectorData.Empty();
	PawnMapStatisticsData.Empty();
}

UCWCastSkillContext::UCWCastSkillContext(const UCWCastSkillContext& r)
{
	*this = r;
}

UCWCastSkillContext& UCWCastSkillContext::operator = (const UCWCastSkillContext& r)
{
	if (this == &r)
		return *this;

	this->PawnWeakPtr = r.PawnWeakPtr;
	this->PawnCampTag = r.PawnCampTag;
	this->PawnCampControllerIndex = r.PawnCampControllerIndex;
	this->PawnControllerPawnIndex = r.PawnControllerPawnIndex;
	this->bIsCounterAttack = r.bIsCounterAttack;
	this->PawnPos = r.PawnPos;
	this->PawnRotator = r.PawnRotator;
	this->ArrayDamageTile = r.ArrayDamageTile;
	this->PlayerControllerWeakPtr = r.PlayerControllerWeakPtr;
	this->ProjectileTargetPawnWeakPtr = r.ProjectileTargetPawnWeakPtr;
	this->CastSkillPropertySet = r.CastSkillPropertySet;
	this->CastSkillDataStruct = r.CastSkillDataStruct;
	this->PawnPropertySetBase = r.PawnPropertySetBase;
	this->PawnCurMaxTheoreticalPropertySet = r.PawnCurMaxTheoreticalPropertySet;
	this->PawnCurPropertySet = r.PawnCurPropertySet;
	this->CopyArrayAffectorData(r.PawnArrayPropertyAffectorData);
	this->CopyMapStatisticsData(r.PawnMapStatisticsData);
	return *this;
}


void UCWCastSkillContext::CopyArrayAffectorData(const TArray<FCWBattlePropertyAffectorData>& ParamArrayAffectorData)
{
	/*PawnArrayPropertyAffectorData.Empty();
	for (TArray<UCWBattlePropertyAffectorDataRef>::TConstIterator iter = ParamArrayAffectorData.CreateConstIterator(); iter; ++iter)
	{
		UCWBattlePropertyAffectorDataRef TempPropertyAffectorDataRef = *iter;
		UCWBattlePropertyAffectorDataRef NewPropertyAffectorDataRef;
		NewPropertyAffectorDataRef->Copy(TempPropertyAffectorDataRef->GetPropertyAffectorData());
		PawnArrayPropertyAffectorData.Add(NewPropertyAffectorDataRef);
	}*/

	PawnArrayPropertyAffectorData = ParamArrayAffectorData;
}

void UCWCastSkillContext::CopyMapStatisticsData(const TMap<enum ECWStatisticsType, int32>& InStatisticsData)
{
	PawnMapStatisticsData = InStatisticsData;
}

bool UCWCastSkillContext::RecalculateCurMaxTheoreticalPropertySet()
{
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Attack);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::PhysicalDefence);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::MagicDefence);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Health);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Energy);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Talent);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Move);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::CriticalDamageFactor);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::CriticalHitRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::AttackSpeed);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Speed);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::HitRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::AvoidanceRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::BlockRate);

	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::DefincePosture);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::FinalDamage);
	return true;
}

bool UCWCastSkillContext::RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty ParamBattleProperty)
{
	//计算基础属性
	float PropertyValueBase = PawnPropertySetBase.GetPropertyByFloat(ParamBattleProperty);

	//Buff加成属性
	float PropertyBuffValue = 0.0f;
	for (int32 i = 0; i < PawnArrayPropertyAffectorData.Num(); ++i)
	{
		FCWBattlePropertyAffectorData& TempAffectorData = PawnArrayPropertyAffectorData[i];
		if (TempAffectorData.AffectBattlePropertyType == ParamBattleProperty &&
			TempAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
		{
			PropertyBuffValue += TempAffectorData.GetResultValue(PropertyValueBase);
		}
	}

	float CurMaxTheoreticalProperty = PropertyValueBase + PropertyBuffValue;
	PawnCurMaxTheoreticalPropertySet.SetProperty<float>(ParamBattleProperty, CurMaxTheoreticalProperty);
	return true;
}

int32 UCWCastSkillContext::GetStatisticsDataValue(ECWStatisticsType InType, const int32 InDefaultValue) const
{
	if (PawnMapStatisticsData.Contains(InType))
	{
		return PawnMapStatisticsData.FindRef(InType);
	}
	return InDefaultValue;
}
