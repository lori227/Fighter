﻿
#include "CWSkill.h"

#include "CWPawn.h"
#include "CWCfgUtils.h"
#include "CWProjectile.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWSkillManager.h"
#include "CWPawnDataStruct.h"
#include "CWSkillDataUtils.h"
#include "CWSkillDataStruct.h"
#include "CWEffectDataUtils.h"
#include "CWEffectDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertyModifier.h"
#include "CWPawnBattlePropertyComponent.h"
#include "UObject/WeakObjectPtrTemplates.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWSkill, All, All);

UCWSkill::UCWSkill(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	SkillId = -1;
	SkillIndex = -1;
	SkillAnim = nullptr;
	//SkillData = nullptr;
	ParentSkillManager = nullptr;
	TriggerBuffCountForRound = 0;
	SourceType = ECWSkillSouceType::None;
}

bool UCWSkill::Init(UCWSkillManager* ParamParantSkillManager, int ParamSkillId, int ParamSkillIndex)
{
	check(ParamParantSkillManager);
	ParentSkillManager = ParamParantSkillManager;
	SkillId = ParamSkillId;
	SkillIndex = ParamSkillIndex;

	if (!LoadSkillAnim())
	{
		return false;
	}

	if (IsPassivitySkill())
	{
		check(ParentSkillManager);
		ParentSkillManager->GetParentPawn()->GetBuffManager()->AddPassivityBuff(this);
	}
	return true;
}

void UCWSkill::DestoryAll()
{
	SkillAnim = nullptr;
	//SkillData = nullptr;
	ParentSkillManager = nullptr;
}

bool UCWSkill::ResetForRound()
{
	TriggerBuffCountForRound = 0;

	return true;
}

bool UCWSkill::IsEnoughEnergy() const
{
	check(ParentSkillManager);
	check(ParentSkillManager->GetParentPawn());
	ACWPawn* TempPawn = ParentSkillManager->GetParentPawn();
	UCWPawnBattlePropertyComponent* TempPawnPropertyComponent = TempPawn->GetBattleProperty();
	if (TempPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::IsEnoughEnergy Fail, ParantSkillManager->GetParantPawn()->GetBattleProperty() == nullptr"));
		return false;
	}
		
	float CurEnergy = TempPawnPropertyComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Energy);

	const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		return false;
	}

	if (CurEnergy >= TempSkillData->ConsumeEnergy)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool UCWSkill::CastSkillToPawn(ACWPawn* ParamTargetPawn)
{
	check(ParamTargetPawn);
	check(ParentSkillManager);
	ACWPawn* TempPawn = ParentSkillManager->GetParentPawn();
	check(TempPawn);
	UCWPawnBattlePropertyComponent* TempPawnPropertyComponent = TempPawn->GetBattleProperty();
	if (TempPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::CastSkillToPawn Fail, ParantSkillManager->GetParantPawn()->GetBattleProperty() == nullptr"));
		return false;
	}

	if (!IsNormalAttack())
	{
		//指令处理
		TempPawn->SetCurInstructs((uint8)ECWInstructType::CastSkill);
		TempPawn->SetCurInstructs((uint8)ECWInstructType::Await);

		//消耗能量，只在服务器处理
		//确保客户端复制检测
		if (TempPawn->IsInServer())
		{	
			float CurEnergy = TempPawnPropertyComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Energy);
			const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
			if (TempSkillData != nullptr)
			{
				FCWBattlePropertyModifier Modifier(ECWBattleProperty::Energy, ECWBattlePropertyModifyOp::Add_Param1, -TempSkillData->ConsumeEnergy, 0.0f, 100000.0f);
				TempPawnPropertyComponent->GetCurPropertySet().ModifyProperty(Modifier);
			}
		}

		//设置当前释放技能的技能Id
		TempPawn->SetSkillIdWhenCastSkill(this->SkillId);

		//设置当前释放技能不是反击
		TempPawn->SetIsCounterAttackWhenCastSkill(false);

		//设置当前释放技能的伤害下标
		TempPawn->SetDamageIndexWhenCastSkill(0);
	}
	else
	{
		//指令处理
		TempPawn->SetCurInstructs((uint8)ECWInstructType::NormalAttack);
		TempPawn->SetCurInstructs((uint8)ECWInstructType::Await);

		//设置当前释放技能的技能Id
		TempPawn->SetSkillIdWhenCastSkill(-1);

		//设置当前释放技能不是反击
		TempPawn->SetIsCounterAttackWhenCastSkill(false);

		//设置当前释放技能的伤害下标
		TempPawn->SetDamageIndexWhenCastSkill(0);
	}

	//设置角色朝向(面向目标释放技能)
	FVector TargetPos = ParamTargetPawn->GetActorLocation();
	FVector SourcePos = TempPawn->GetActorLocation();
	FVector TempDir = TargetPos - SourcePos;
	TempDir.Z = 0.0f;
	FRotator NewRotation = TempDir.Rotation();
	NewRotation.Yaw -= 90.0f;
	TempPawn->SetActorRotation(NewRotation);
	
	//播放技能动画
	//TempPawn->PlayAnimSequence(this->GetSkillAnim(), 0.25f, 0.25f, 1.0f, 1);
	TempPawn->PlayAnimSequence(this->GetSkillAnimType(), 0.25f, 0.25f, 1.0f, 1);

	//挂攻击特效，并播放
	SetupAttackEffectInClient();
	
	//如果是客户端，隐藏头顶相关UI
	if (!TempPawn->IsInServer())
	{
		TempPawn->RestoreEnemyHeadIconInAttackRange();
		TempPawn->RestorePartnerHeadIconInSupportRange();
	}

	return true;
}


bool UCWSkill::CastSkillToTile(int ParamTile)
{
	check(ParentSkillManager);
	ACWPawn* TempPawn = ParentSkillManager->GetParentPawn();
	check(TempPawn);
	check(TempPawn->GetDungeonGenerator());
	UCWPawnBattlePropertyComponent* TempPawnPropertyComponent = TempPawn->GetBattleProperty();
	if (TempPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::CastSkillToTile Fail, ParantSkillManager->GetParantPawn()->GetBattleProperty() == nullptr"));
		return false;
	}

	if (!IsNormalAttack())
	{
		//指令处理
		TempPawn->SetCurInstructs((uint8)ECWInstructType::CastSkill);
		TempPawn->SetCurInstructs((uint8)ECWInstructType::Await);

		//消耗能量，只在服务器处理
		//确保客户端复制检测
		if (TempPawn->IsInServer())
		{
			float CurEnergy = TempPawnPropertyComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Energy);
			const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
			if (TempSkillData != nullptr)
			{
				FCWBattlePropertyModifier Modifier(ECWBattleProperty::Energy, ECWBattlePropertyModifyOp::Add_Param1, -TempSkillData->ConsumeEnergy, 0.0f, 100000.0f);
				TempPawnPropertyComponent->GetCurPropertySet().ModifyProperty(Modifier);
			}
		}

		//设置当前释放技能的技能Id
		TempPawn->SetSkillIdWhenCastSkill(this->SkillId);

		//设置当前释放技能不是反击
		TempPawn->SetIsCounterAttackWhenCastSkill(false);

		//设置当前释放技能的伤害下标
		TempPawn->SetDamageIndexWhenCastSkill(0);
	}
	else
	{
		//指令处理
		TempPawn->SetCurInstructs((uint8)ECWInstructType::NormalAttack);
		TempPawn->SetCurInstructs((uint8)ECWInstructType::Await);

		//设置当前释放技能的技能Id
		TempPawn->SetSkillIdWhenCastSkill(-1);

		//设置当前释放技能不是反击
		TempPawn->SetIsCounterAttackWhenCastSkill(false);

		//设置当前释放技能的伤害下标
		TempPawn->SetDamageIndexWhenCastSkill(0);
	}

	//设置角色朝向(面向目标释放技能)
	ACWDungeonTile* TempTile = TempPawn->GetDungeonGenerator()->GetDungeonTile(ParamTile);
	if (TempTile == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::CastSkillToTile Fail, TempTile == nullptr, ParamTile:%d."), ParamTile);
		return false;
	}
	FVector TargetPos = TempTile->GetActorLocation();
	FVector SourcePos = TempPawn->GetActorLocation();
	float TempDistance = FVector::Distance(TargetPos, SourcePos);
	if (!FMath::IsNearlyZero(TempDistance))
	{
		FVector TempDir = TargetPos - SourcePos;
		TempDir.Z = 0.0f;
		FRotator NewRotation = TempDir.Rotation();
		NewRotation.Yaw -= 90.0f;
		TempPawn->SetActorRotation(NewRotation);
	}

	//播放技能动画
	//TempPawn->PlayAnimSequence(this->GetSkillAnim(), 0.25f, 0.25f, 1.0f, 1);
	TempPawn->PlayAnimSequence(this->GetSkillAnimType(), 0.25f, 0.25f, 1.0f, 1);

	//挂攻击特效，并播放
	SetupAttackEffectInClient();

	//如果是客户端，隐藏头顶相关UI
	if (!TempPawn->IsInServer())
	{
		TempPawn->RestoreEnemyHeadIconInAttackRange();
		TempPawn->RestorePartnerHeadIconInSupportRange();
	}

	return true;
}

bool UCWSkill::CounterAttackToTile(int ParamTile)
{
	check(ParentSkillManager);
	ACWPawn* TempPawn = ParentSkillManager->GetParentPawn();
	check(TempPawn);
	check(TempPawn->GetDungeonGenerator());
	UCWPawnBattlePropertyComponent* TempPawnPropertyComponent = TempPawn->GetBattleProperty();
	if (TempPawnPropertyComponent == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::CounterAttackToTile Fail, ParantSkillManager->GetParantPawn()->GetBattleProperty() == nullptr"));
		return false;
	}

	//设置当前释放技能的技能Id
	TempPawn->SetSkillIdWhenCastSkill(-1);

	//设置当前释放技能不是反击
	TempPawn->SetIsCounterAttackWhenCastSkill(true);

	//设置当前释放技能的伤害下标
	TempPawn->SetDamageIndexWhenCastSkill(0);
	

	//设置角色朝向(面向目标释放技能)
	ACWDungeonTile* TempTile = TempPawn->GetDungeonGenerator()->GetDungeonTile(ParamTile);
	if (TempTile == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::CounterAttackToTile Fail, TempTile == nullptr, ParamTile:%d."), ParamTile);
		return false;
	}
	FVector TargetPos = TempTile->GetActorLocation();
	FVector SourcePos = TempPawn->GetActorLocation();
	float TempDistance = FVector::Distance(TargetPos, SourcePos);
	if (!FMath::IsNearlyZero(TempDistance))
	{
		FVector TempDir = TargetPos - SourcePos;
		TempDir.Z = 0.0f;
		FRotator NewRotation = TempDir.Rotation();
		NewRotation.Yaw -= 90.0f;
		TempPawn->SetActorRotation(NewRotation);
	}

	//播放技能动画
	//TempPawn->PlayAnimSequence(this->GetSkillAnim(), 0.25f, 0.25f, 1.0f, 1);
	TempPawn->PlayAnimSequence(this->GetSkillAnimType(), 0.25f, 0.25f, 1.0f, 1);

	//挂攻击特效，并播放
	SetupAttackEffectInClient();

	//如果是客户端，隐藏头顶相关UI
	if (!TempPawn->IsInServer())
	{
		TempPawn->RestoreEnemyHeadIconInAttackRange();
		TempPawn->RestorePartnerHeadIconInSupportRange();
	}

	return true;
}

bool UCWSkill::IsNormalAttack() const
{
	const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		return false;
	}

	if (TempSkillData->IsNormalAttack == 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool UCWSkill::IsThereAnimSequence()
{
	if (SkillAnim == nullptr)
	{
		return false;
	}
	else
	{
		return true;
	}
}

bool UCWSkill::GenerateProjectileToPawn(ACWPawn* ParamTargetPawn, TSharedPtr<UCWCastSkillContext> ParamCastSkillContextPtr)
{
	check(ParamTargetPawn);
	check(ParentSkillManager);
	check(ParentSkillManager->GetParentPawn());
	UCWPawnBattlePropertyComponent* MyPawnBattlePropertComponent = ParentSkillManager->GetParentPawn()->GetBattleProperty();
	check(MyPawnBattlePropertComponent);

	const FCWSkillDataStruct* TempSkillData = this->GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		return false;
	}

	std::vector<float> TempProjectileOffset = FCWSkillDataUtils::GetProjectileOffsetFromString(TempSkillData->ProjectileOffset);
	if (TempProjectileOffset.size() != 3)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::GenerateProjectileToPawn Fail, TempProjectileOffset.size() != 3, TempProjectileOffset.size():%d."), TempProjectileOffset.size());
		return false;
	}

	FVector r = ParamTargetPawn->GetActorLocation() - ParentSkillManager->GetParentPawn()->GetActorLocation();
	FVector l = ParentSkillManager->GetParentPawn()->GetActorLocation();

	UClass* ProjectileClass = LoadClass<ACWProjectile>(nullptr, *(TempSkillData->ProjectileName));
	if (ProjectileClass != nullptr)
	{
		ACWPawn* ParentPawn = ParentSkillManager->GetParentPawn();
		FActorSpawnParameters SpawnParameters;
		SpawnParameters.Owner = ParentPawn;
		SpawnParameters.Instigator = ParentPawn;
		SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		check(SpawnParameters.Instigator);
		const FVector& TmpLocation = FVector(l.X + TempProjectileOffset[0], l.Y + TempProjectileOffset[1], l.Z + TempProjectileOffset[2]);
		ACWProjectile* TempProjectile = ParentPawn->GetWorld()->SpawnActor<ACWProjectile>(ProjectileClass, TmpLocation, r.Rotation(), SpawnParameters);
		if (TempProjectile != nullptr)
		{
			TempProjectile->Init(ParamCastSkillContextPtr);
			return true;
		}
	}
	
	return false;
}

const FCWSkillDataStruct* UCWSkill::GetSkillDataStruct() const
{
	FCWSkillDataStruct* TempSkillData = nullptr;
	switch (SourceType)
	{
	case ECWSkillSouceType::Skill:
	{
		TempSkillData = FCWCommonUtil::FindCSVRow<FCWSkillDataStruct>(TEXT("CWSkillDataTable"), SkillId);
	}break;
	case ECWSkillSouceType::TalentSys:
	{
		TempSkillData = FCWCfgUtils::GetTalentData(this, SkillId);
	}break;
	}

	if (TempSkillData == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::GetSkillDataStruct, TempSkillData == nullptr, SkillId:%d SkillSource[%s]."), 
			SkillId, *FCWCommonUtil::EnumToString(TEXT("ECWSkillSouceType"), SourceType));
		return nullptr;
	}
	return TempSkillData;
}

UAnimSequence* UCWSkill::GetSkillAnim()
{
	return SkillAnim;
}

ECWPawnAnim UCWSkill::GetSkillAnimType()
{
	return SkillAnimType;
}

bool UCWSkill::LoadSkillAnim()
{
	const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::LoadSkillAnim Fail. SkillId:%d, PawnCombinationName:%s."), SkillId, *(ParentSkillManager->GetParentPawn()->GetCombinationName()));
		return false;
	}

	if (TempSkillData->IsHasAnim == 0)
	{
		return true;
	}
	else
	{
		UAnimSequence* SkillAnimAsset = FCWCfgUtils::GetPawnAssetObject<UAnimSequence>(this, TempSkillData->AnimNameId);
		if (SkillAnimAsset != nullptr)
		{
			SkillAnim = SkillAnimAsset;

			ACWPawn* ParentPawn = ParentSkillManager->GetParentPawn();
			check(ParentPawn);

			if (TempSkillData->IsNormalAttack == 1)
			{
				SkillAnimType = ECWPawnAnim::NormalAttack01;
				ParentPawn->AddAnim(ECWPawnAnim::NormalAttack01, SkillAnim);
			}
			else
			{
				switch (SkillIndex)
				{
				case 0:
				{
					SkillAnimType = ECWPawnAnim::Skill01;
					ParentPawn->AddAnim(ECWPawnAnim::Skill01, SkillAnim);
				}break;
				case 1:
				{
					SkillAnimType = ECWPawnAnim::Skill02;
					ParentPawn->AddAnim(ECWPawnAnim::Skill02, SkillAnim);
				}break;
				case 2:
				{
					SkillAnimType = ECWPawnAnim::Skill03;
					ParentPawn->AddAnim(ECWPawnAnim::Skill03, SkillAnim);
				}break;
				default:
					UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::LoadSkillAnim Fail. SkillIndex:%d, PawnCombinationName:%s."), SkillIndex, *(ParentSkillManager->GetParentPawn()->GetCombinationName()));
					break;
				}
			}
		}
		else
		{
			UE_LOG(LogCWSkill, Error, TEXT("UCWSkill::LoadSkillAnim Fail. CharSkillAnimName:%s, PawnCombinationName:%s."), *TempSkillData->AnimNameId, *(ParentSkillManager->GetParentPawn()->GetCombinationName()));
			return false;
		}
	
		return true;
	}
}

void UCWSkill::SetupAttackEffectInClient()
{
	ACWPawn* TempPawn = ParentSkillManager->GetParentPawn();
	check(TempPawn);

	if (TempPawn->IsInServer())
		return;

	const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		return;
	}

	std::vector<int32> TempArrayAttackEffectId = FCWSkillDataUtils::GetArrayAttackEffectIdFromString(TempSkillData->ArrayAttackEffectId);
	for (int i = 0; i < TempArrayAttackEffectId.size(); ++i)
	{
		int32 TempEffectId = TempArrayAttackEffectId[i];
		TempPawn->AddAttackEffect(TempEffectId);
	}
}

bool UCWSkill::IsPassivitySkill() const
{
	const FCWSkillDataStruct* TempSkillData = GetSkillDataStruct();
	if (TempSkillData == nullptr)
	{
		return false;
	}
	return (TempSkillData->IsPassivitySkill == 1);
}

int32 UCWSkill::GetSkillId() const
{
	return SkillId;
}

int32 UCWSkill::GetSkillIndex() const
{
	return SkillIndex;
}

ECWSkillSouceType UCWSkill::GetSouceType()
{
	return SourceType;
}

void UCWSkill::SetSouceType(ECWSkillSouceType InSkillSource)
{
	SourceType = InSkillSource;
}

void UCWSkill::IncreaseTriggerBuffCountForRound()
{
	TriggerBuffCountForRound++;
}

int32 UCWSkill::GetTriggerBuffCountForRound() const
{
	return TriggerBuffCountForRound;
}