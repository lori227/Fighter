
#include "CWSkillManager.h"

#include "CWPawn.h"
#include "CWSkill.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWSkillDataUtils.h"
#include "CWPawnDataStruct.h"
#include "CWTalentSystemCtrl.h"
#include "CWPlayerController.h"
#include "CWProfessionDataStruct.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWSkillManager, All, All);

UCWSkillManager::UCWSkillManager(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	ParentPawn = nullptr;
}

//UCWSkillManager::~UCWSkillManager()
//{
//
//}

bool UCWSkillManager::Init(ACWPawn* ParamParentPawn)
{
	check(ParamParentPawn);
	ParentPawn = ParamParentPawn;

	const FCWPawnNetData& TempPawnNetData = ParentPawn->GetPawnNetData();
	TArray<int32> TempArrayActiveSkillId = TempPawnNetData.ActiveSkillId;
	if (TempArrayActiveSkillId.Num() <= 0)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. TempArrayActiveSkillId.Num:%d."), TempArrayActiveSkillId.Num());
		return false;
	}

	ArraySkills.Empty();
	for (TArray<int32>::TConstIterator iter = TempArrayActiveSkillId.CreateConstIterator(); iter; ++iter)
	{
		int32 TempSkillId = *iter;
		if (TempSkillId == 0)
			continue;

		UCWSkill* TempSkill = NewObject<UCWSkill>();
		if (TempSkill != nullptr)
		{
			TempSkill->SetSouceType(ECWSkillSouceType::Skill);
			if (TempSkill->Init(this, TempSkillId, ArraySkills.Num()))
			{
				ArraySkills.AddUnique(TempSkill);


				UE_LOG(LogCWSkillManager, Log, TEXT("UCWSkillManager::Init. TempSkill->Init, TempSkillId:%d, CombinationName:%s."), TempSkillId, *(ParentPawn->GetCombinationName()));
			}
			else
			{
				UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. TempSkill->Init fail, TempSkillId:%d, CombinationName:%s."), TempSkillId, *(ParentPawn->GetCombinationName()));
				return false;
			}
		}
		else
		{
			UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. NewObject<UCWSkill>() fail, TempSkillId:%d, CombinationName:%s."), TempSkillId, *(ParentPawn->GetCombinationName()));
			return false;
		}
	}

	TArray<int32> TempArrayPassivitySkillId = TempPawnNetData.PassivitySkillId;
	if (TempArrayPassivitySkillId.Num() <= 0)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. TempArrayPassivitySkillId.Num:%d."), TempArrayPassivitySkillId.Num());
		return false;
	}

	for (TArray<int32>::TConstIterator iter = TempArrayPassivitySkillId.CreateConstIterator(); iter; ++iter)
	{
		int32 TempSkillId = *iter;
		if (TempSkillId == 0)
			continue;

		UCWSkill* TempSkill = NewObject<UCWSkill>();
		if (TempSkill != nullptr)
		{
			TempSkill->SetSouceType(ECWSkillSouceType::Skill);
			if (TempSkill->Init(this, TempSkillId, ArraySkills.Num()))
			{
				ArraySkills.AddUnique(TempSkill);
			}
			else
			{
				UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. TempSkill->Init fail, TempSkillId:%d, CombinationName:%s."), TempSkillId, *(ParentPawn->GetCombinationName()));
				return false;
			}
		}
		else
		{
			UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. NewObject<UCWSkill>() fail, TempSkillId:%d, CombinationName:%s."), TempSkillId, *(ParentPawn->GetCombinationName()));
			return false;
		}
	}

	TArray<int32> TempArrayInnateSkillId = TempPawnNetData.InnateSkillId;
	if (TempArrayInnateSkillId.Num() <= 0)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. TempArrayInnateSkillId.Num:%d."), TempArrayInnateSkillId.Num());
		return false;
	}

	// �츳����
	ArrayTalentSkill.Empty();
	for (TArray<int32>::TConstIterator iter = TempArrayInnateSkillId.CreateConstIterator(); iter; ++iter)
	{
		int32 NewTalentId = *iter;
		if (NewTalentId == 0)
			continue;

		if (const FCWSkillDataStruct* TalentData = FCWCfgUtils::GetTalentData(ParentPawn, NewTalentId))
		{
			const FName NewTalentName = FName(*FString::Printf(TEXT("Talent_%d"), NewTalentId));
			if (UCWSkill* NewTalent = NewObject<UCWSkill>(this, NewTalentName))
			{
				NewTalent->SetSouceType(ECWSkillSouceType::TalentSys);
				if (NewTalent->Init(this, NewTalentId, ArraySkills.Num()/*ArrayTalentSkill.Num()*/))
				{
					// TODO: ��ʱ�ż�����,�����ȡ�Ǵ�ȫ�������ж�ȡ,�����Ȳ߻�ȷ����ͳһ�޸�
					ArraySkills.AddUnique(NewTalent);//ArrayTalentSkill.AddUnique(NewTalent);
				}
			}
		}
		else
		{
			CWG_ERROR(">> %s::Init, NewTalentId[%d] is not found, CombinationName:%s.", *GetName(), NewTalentId, *(ParentPawn->GetCombinationName()));
		}
	}
	
	FCWProfessionDataStruct* TempProfessionData = FCWCommonUtil::FindCSVRow<FCWProfessionDataStruct>(TEXT("CWProfessionDataTable"), TempPawnNetData.Profession);
	if (TempProfessionData == nullptr)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail, TempProfessionData == nullptr, Profession:%d."), TempPawnNetData.Profession);
		return false;
	}

	// �չ�
	NormalAttackBySkill = NewObject<UCWSkill>();
	if (NormalAttackBySkill != nullptr)
	{
		NormalAttackBySkill->SetSouceType(ECWSkillSouceType::Skill);
		if (NormalAttackBySkill->Init(this, TempProfessionData->NormalAttackId, 0))
		{
		}
		else
		{
			UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. NormalAttackBySkill->Init fail, Profession:%d, SkillIdForNormalAttack:%d."), TempPawnNetData.Profession, TempProfessionData->NormalAttackId);
			return false;
		}
	}
	else
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::Init fail. NewObject<UCWSkill>() fail, Profession:%d, SkillIdForNormalAttack:%d."), TempPawnNetData.Profession, TempProfessionData->NormalAttackId);
		return false;
	}

	return true;
}

void UCWSkillManager::DestoryAll()
{
	if (NormalAttackBySkill != nullptr)
	{
		NormalAttackBySkill->DestoryAll();
		NormalAttackBySkill = nullptr;
	}

	for (TArray<UCWSkill*>::TConstIterator iter = ArraySkills.CreateConstIterator(); iter; ++iter)
	{
		UCWSkill* TempSkill = *iter;
		TempSkill->DestoryAll();
		TempSkill = nullptr;
	}
	ArraySkills.Empty();

	ParentPawn = nullptr;
}

bool UCWSkillManager::ResetForRound()
{
	if (NormalAttackBySkill == nullptr)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::ResetForRound fail. NormalAttackBySkill == nullptr."));
		return false;
	}

	NormalAttackBySkill->ResetForRound();

	for (TArray<UCWSkill*>::TConstIterator iter = ArraySkills.CreateConstIterator(); iter; ++iter)
	{
		UCWSkill* TempSkill = *iter;
		TempSkill->ResetForRound();
	}

	return true;
}

bool UCWSkillManager::CanCastSkill(int ParamSkillId) const
{
	/*const ACWPawn* TempPawn = GetParantPawn();
	if (TempPawn == nullptr)
		return false;

	ACWPlayerController* TempPlayerController = (ACWPlayerController*)(TempPawn->GetParantController());
	if (TempPlayerController == nullptr)
		return false;

	if (!TempPlayerController->IsMyTurn())
		return false;

	if (TempPawn->GetCurInstructs() == 0 || (((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::Await) == 0) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::CastSkill) == 0)) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::NormalAttack) == 0)))))
	{*/
		if (IsEnoughEnergy(ParamSkillId))
			return true;
	//}

	return false;
}

bool UCWSkillManager::CanCastSkillByIndex(int ParamSkillIndex) const
{
	/*const ACWPawn* TempPawn = GetParantPawn();
	if (TempPawn == nullptr)
		return false;*/

	/*ACWPlayerController* TempPlayerController = (ACWPlayerController*)(TempPawn->GetParantController());
	if (TempPlayerController == nullptr)
		return false;

	if (!TempPlayerController->IsMyTurn())
		return false;

	if (TempPawn->GetCurInstructs() == 0 || (((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::Await) == 0) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::CastSkill) == 0)) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::NormalAttack) == 0)))))
	{*/
		if (IsEnoughEnergyByIndex(ParamSkillIndex))
			return true;
	//}

	return false;
}


bool UCWSkillManager::CanNormalAttack() const
{
	/*const ACWPawn* TempPawn = GetParantPawn();
	if (TempPawn == nullptr)
		return false;

	ACWPlayerController* TempPlayerController = (ACWPlayerController*)(TempPawn->GetParantController());
	if (TempPlayerController == nullptr)
		return false;

	if (!TempPlayerController->IsMyTurn())
		return false;

	if (TempPawn->GetCurInstructs == 0 || (((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::Await) == 0) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::CastSkill) == 0)) && ((TempPawn->GetCurInstructs() > 0) && ((TempPawn->GetCurInstructs() & (uint8)ECWInstructType::NormalAttack) == 0)))))
	{
		return true;
	}

	return false;*/

	return true;
}

bool UCWSkillManager::IsEnoughEnergy(int ParamSkillId) const
{
	const UCWSkill* TempSkill = GetSkill(ParamSkillId);
	if (TempSkill != nullptr)
	{
		return TempSkill->IsEnoughEnergy();
	}
	else
	{
		return false;
	}
}

bool UCWSkillManager::IsEnoughEnergyByIndex(int ParamSkillIndex) const
{
	const UCWSkill* TempSkill = GetSkillByIndex(ParamSkillIndex);
	if (TempSkill != nullptr)
	{
		return TempSkill->IsEnoughEnergy();
	}
	else
	{
		return false;
	}
}

bool UCWSkillManager::NormalAttackToPawn(ACWPawn* ParamTargetPawn)
{
	check(ParamTargetPawn);
	check(NormalAttackBySkill);

	return NormalAttackBySkill->CastSkillToPawn(ParamTargetPawn);
}

bool UCWSkillManager::NormalAttackToTile(int32 ParamTile)
{
	check(NormalAttackBySkill);

	return NormalAttackBySkill->CastSkillToTile(ParamTile);
}

bool UCWSkillManager::CounterAttackToTile(int32 ParamTile)
{
	check(NormalAttackBySkill);

	return NormalAttackBySkill->CounterAttackToTile(ParamTile);
}

bool UCWSkillManager::CastSkillToPawn(int32 ParamSkillId, ACWPawn* ParamTargetPawn)
{
	check(ParamTargetPawn);

	UCWSkill* TempSkill = GetSkill(ParamSkillId);
	if (TempSkill == nullptr)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::CastSkillToPawn fail. MapSkills[ParamSkillId] == nullptr, ParamSkillId:%d."), ParamSkillId);
		return false;
	}

	return TempSkill->CastSkillToPawn(ParamTargetPawn);
}


bool UCWSkillManager::CastSkillToTile(int32 ParamSkillId, int ParamTile)
{
	UCWSkill* TempSkill = GetSkill(ParamSkillId);
	if (TempSkill == nullptr)
	{
		UE_LOG(LogCWSkillManager, Error, TEXT("UCWSkillManager::CastSkillToTile fail. MapSkills[ParamSkillId] == nullptr, ParamSkillId:%d."), ParamSkillId);
		return false;
	}

	return TempSkill->CastSkillToTile(ParamTile);
}

ACWPawn* UCWSkillManager::GetParentPawn()
{
	return ParentPawn;
}

const ACWPawn* UCWSkillManager::GetParentPawn() const
{
	return ParentPawn;
}

const UCWSkill* UCWSkillManager::GetNormalAttack() const
{
	return NormalAttackBySkill;
}

UCWSkill* UCWSkillManager::GetNormalAttack()
{
	return NormalAttackBySkill;
}

UCWSkill* UCWSkillManager::GetCounterAttack()
{
	return NormalAttackBySkill;
}


const UCWSkill* UCWSkillManager::GetSkill(int ParamSkillId) const
{
	for (TArray<UCWSkill*>::TConstIterator iter = ArraySkills.CreateConstIterator(); iter; ++iter)
	{
		const UCWSkill* TempSkill = *iter;
		if (TempSkill != nullptr)
		{
			if (TempSkill->GetSkillId() == ParamSkillId)
			{
				return TempSkill;
			}
		}
	}

	return nullptr;
}


UCWSkill* UCWSkillManager::GetSkill(int ParamSkillId)
{
	for (TArray<UCWSkill*>::TConstIterator iter = ArraySkills.CreateConstIterator(); iter; ++iter)
	{
		UCWSkill* TempSkill = *iter;
		if (TempSkill != nullptr)
		{
			if (TempSkill->GetSkillId() == ParamSkillId)
			{
				return TempSkill;
			}
		}
	}

	return nullptr;
}


const UCWSkill* UCWSkillManager::GetSkillByIndex(int ParamSkillIndex) const
{
	if (ParamSkillIndex < 0 || ParamSkillIndex >= ArraySkills.Num())
		return nullptr;

	return ArraySkills[ParamSkillIndex];
}


UCWSkill* UCWSkillManager::GetSkillByIndex(int ParamSkillIndex)
{
	if (ParamSkillIndex < 0 || ParamSkillIndex >= ArraySkills.Num())
		return nullptr;

	return ArraySkills[ParamSkillIndex];
}