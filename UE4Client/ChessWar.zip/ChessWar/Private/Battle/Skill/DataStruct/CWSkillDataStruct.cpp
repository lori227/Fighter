
#include "CWSkillDataStruct.h"

FCWSkillDataStruct::FCWSkillDataStruct()
{
	SkillId = 0;
	IsNormalAttack = 0;
	IsGenerateProjectile = 0;
	IsPassivitySkill = 0;
	TargetType = 0;
	ConsumeEnergy = 0;
	IsHasAnim = 0;
	bAddLateralForce = false;
	OwnElemType = EObjElemType::OET_None;
	AttackRangeType = 0;
	AttackRangeRowNum = 0;
	AttackRangeColumnNum = 0;
	ProjectileInitialSpeed = 0.f;
	IsAOE = 0;
	TargetMax = 0;
	AutoSelectedPriority = 0;
	DamageCount = 0;
	DamageFactor = 0.f;
	BuffNum = 0;
}

FCWSkillDataStruct::~FCWSkillDataStruct()
{
}
