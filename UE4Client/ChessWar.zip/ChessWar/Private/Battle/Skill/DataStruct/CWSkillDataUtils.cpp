#include "CWSkillDataUtils.h"

std::vector<int32> FCWSkillDataUtils::GetArraySkillIdFromString(const FString& ParamString)
{
	std::vector<int32> ArraySkillId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{ 
		FString TempString = *iter;
		int32 TempSkillId = FCString::Atoi(*TempString);
		ArraySkillId.push_back(TempSkillId);
	}

	return ArraySkillId;
}

std::vector<int32> FCWSkillDataUtils::GetArrayAttackRangeParamsFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAttackRangeParams;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAttackRangeParam = FCString::Atoi(*TempString);
		ArrayAttackRangeParams.push_back(TempAttackRangeParam);
	}

	return ArrayAttackRangeParams;
}

std::vector<float> FCWSkillDataUtils::GetProjectileOffsetFromString(const FString& ParamString)
{
	std::vector<float> ProjectileOffset;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempParam = FCString::Atof(*TempString);
		ProjectileOffset.push_back(TempParam);
	}

	return ProjectileOffset;
}


std::vector<std::vector<int32> > FCWSkillDataUtils::GetAffectRangeFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > AffectRange;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		AffectRange.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempAffectRange = FCString::Atoi(*TempString2);
			AffectRange.back().push_back(TempAffectRange);
		}
	}

	return AffectRange;
}


std::vector<int32> FCWSkillDataUtils::GetAffectCenterFromString(const FString& ParamString)
{
	std::vector<int32> AffectCenter;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		AffectCenter.push_back(TempAffect);
	}

	return AffectCenter;
}


std::vector<std::vector<int32> > FCWSkillDataUtils::GetArrayArrayBuffTriggerConditionType(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionType;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConditionType.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCondintionType = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConditionType.back().push_back(TempBuffTriggerCondintionType);
		}
	}

	return ArrayArrayBuffTriggerConditionType;
}

std::vector<std::vector<int32> > FCWSkillDataUtils::GetArrayArrayBuffTriggerConditionLogicOp(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionLogicOp;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConditionLogicOp.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerConditionLogicOp = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConditionLogicOp.back().push_back(TempBuffTriggerConditionLogicOp);
		}
	}

	return ArrayArrayBuffTriggerConditionLogicOp;
}


std::vector<std::vector<int32> > FCWSkillDataUtils::GetArrayArrayBuffTriggerConcretenessCondition(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConcretenessCondition;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConcretenessCondition.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerConcretenessCondition = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerConcretenessCondition.back().push_back(TempBuffTriggerConcretenessCondition);
		}
	}

	return ArrayArrayBuffTriggerConcretenessCondition;
}

std::vector<std::vector<int32> > FCWSkillDataUtils::GetArrayArrayBuffTriggerCompareRelatioinOp(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOp;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerCompareRelatioinOp.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCompareRelatioinOp = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerCompareRelatioinOp.back().push_back(TempBuffTriggerCompareRelatioinOp);
		}
	}

	return ArrayArrayBuffTriggerCompareRelatioinOp;
}

std::vector<std::vector<int32> > FCWSkillDataUtils::GetArrayArrayBuffTriggerCompareRelatioinOpValueType(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOpValueType;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerCompareRelatioinOpValueType.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempBuffTriggerCompareRelatioinOpValueType = FCString::Atoi(*TempString2);
			ArrayArrayBuffTriggerCompareRelatioinOpValueType.back().push_back(TempBuffTriggerCompareRelatioinOpValueType);
		}
	}

	return ArrayArrayBuffTriggerCompareRelatioinOpValueType;
}


std::vector<std::vector<float> > FCWSkillDataUtils::GetArrayArrayBuffTriggerConcretenessParams(const FString& ParamString)
{
	std::vector<std::vector<float> > ArrayArrayBuffTriggerConcretenessParams;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayBuffTriggerConcretenessParams.push_back(std::vector<float>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			float TempBuffTriggerConcretenessParam = FCString::Atof(*TempString2);
			ArrayArrayBuffTriggerConcretenessParams.back().push_back(TempBuffTriggerConcretenessParam);
		}
	}

	return ArrayArrayBuffTriggerConcretenessParams;
}

std::vector<int32> FCWSkillDataUtils::GetArrayBuffIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayBuffId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempBuffId = FCString::Atoi(*TempString);
		ArrayBuffId.push_back(TempBuffId);
	}

	return ArrayBuffId;
}


std::vector<int32> FCWSkillDataUtils::GetArrayAttackEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAttackEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempEffectId = FCString::Atoi(*TempString);
		ArrayAttackEffectId.push_back(TempEffectId);
	}

	return ArrayAttackEffectId;
}


std::vector<int32> FCWSkillDataUtils::GetArrayBeAttackedEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayBeAttackedEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempEffectId = FCString::Atoi(*TempString);
		ArrayBeAttackedEffectId.push_back(TempEffectId);
	}

	return ArrayBeAttackedEffectId;
}


std::vector<int32> FCWSkillDataUtils::GetArrayIntensifyAttackEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayIntensifyAttackEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempEffectId = FCString::Atoi(*TempString);
		ArrayIntensifyAttackEffectId.push_back(TempEffectId);
	}

	return ArrayIntensifyAttackEffectId;
}


std::vector<int32> FCWSkillDataUtils::GetArrayIntensifyBeAttackedEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayIntensifyBeAttackedEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempEffectId = FCString::Atoi(*TempString);
		ArrayIntensifyBeAttackedEffectId.push_back(TempEffectId);
	}

	return ArrayIntensifyBeAttackedEffectId;
}