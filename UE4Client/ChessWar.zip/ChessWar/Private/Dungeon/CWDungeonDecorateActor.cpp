
#include "CWDungeonDecorateActor.h"



DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonDecorateActor, All, All);

ACWDungeonDecorateActor::ACWDungeonDecorateActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SetRootComponent(SceneComponent);
}