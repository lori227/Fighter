﻿
#include "CWDungeonDecorateComponent.h"

#include "Components/StaticMeshComponent.h"
#include "Engine.h"
#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWAssetDefine.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonRegionDataUtils.h"
#include "CWGameDataStruct.h"
#include "CWCommonUtil.h"
#include "CWGameInfo.h"
#include "CWAudioVideoMgr.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonDecorate, All, All);

UCWDungeonDecorateComponent::UCWDungeonDecorateComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIsDoFall(false)
	, CurFallSpeed(0.0f)
	, TotalFallTime(0.0f)
	, bIsDoRise(false)
	, CurRiseSpeed(100.0f)
	, OriginLocation(FVector::ZeroVector)
	, bIsDoRiseEnd(false)
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UCWDungeonDecorateComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (IsInServer())
	{
		if (bIsDoFall)
		{
			FallingInServer(DeltaTime);
		}
	}
	else
	{
		if (bIsDoRise)
		{
			RisingInClient(DeltaTime);
		}

		if (bIsDoFall)
		{
			FallingInClient(DeltaTime);
		}
	}
}

void UCWDungeonDecorateComponent::DoFallInServer()
{
	if (!IsInServer())
		return;

	this->GetOwner()->Destroy();
	//bIsDoFall = true;

	//NetMulticastRPCDoFall();
}

void UCWDungeonDecorateComponent::NetMulticastRPCDoFall_Implementation()
{
	if (IsInServer())
		return;

	bIsDoFall = true;
}

void UCWDungeonDecorateComponent::DoFallInClient()
{
	if (IsInServer())
		return;

	bIsDoFall = true;
	bIsDoRise = false;
}

void UCWDungeonDecorateComponent::FallingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	check(this->GetOwner());
	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = this->GetOwner()->GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	this->GetOwner()->SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		this->GetOwner()->Destroy();
	}
}

void UCWDungeonDecorateComponent::FallingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = this->GetOwner()->GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	this->GetOwner()->SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		bIsDoFall = false;
		this->GetOwner()->Destroy(true);
	}
}

void UCWDungeonDecorateComponent::ResetBeforeRiseInClient()
{
	if (IsInServer())
		return;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	OriginLocation = GetOwner()->GetActorLocation();

	FVector TempLocation = GetOwner()->GetActorLocation();
	TempLocation.Z = TempGameData->DungeonTileRiseBeginZ;
	GetOwner()->SetActorLocation(TempLocation);
}

void UCWDungeonDecorateComponent::DoRiseInClient()
{
	if (IsInServer())
		return;

	bIsDoFall = false;
	bIsDoRise = true;
	bIsDoRiseEnd = false;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;
}

void UCWDungeonDecorateComponent::RisingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = CurRiseSpeed * DeltaTime;
	FVector TempLocation = GetOwner()->GetActorLocation();
	float TempZ = TempLocation.Z + CurRiseSpeed;
	if (TempZ > OriginLocation.Z)
	{
		TempZ = OriginLocation.Z;
		bIsDoRise = false;
		bIsDoRiseEnd = true;
		OnRiseCompleteInClient();
	}
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempZ);
	GetOwner()->SetActorLocation(TempLocation);

	if (CurRiseSpeed <= 10.0f)
		CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;
}

void UCWDungeonDecorateComponent::OnRiseCompleteInClient()
{
	AActor* Owner = GetOwner();
	if (nullptr != Owner && Owner->IsA<AStaticMeshActor>())
	{	// 播放上升完成声音(场景外围)
		if (UCWAudioVideoMgr* AV_Mgr = AV_MGR(this))
		{
			const FString& AudioId = GetAkEventByOwnerName();
			if (!AudioId.IsEmpty())
			{
				AV_Mgr->PlayAudioByCfg(Owner, AudioId);
			}
		}
	}
}

FString UCWDungeonDecorateComponent::GetAkEventByOwnerName()
{
	const FString& OwnerName = GetOwner()->GetName();
	if (OwnerName.Contains(FPeripherySceneObj::StoneKey))
	{
		return FPeripherySceneObj::StoneEvt;
	}
	else if(OwnerName.Contains(FPeripherySceneObj::TreeKey))
	{
		return FPeripherySceneObj::TreeEvt;
	}
	return TEXT("");
}

int32 UCWDungeonDecorateComponent::GetGameId()
{
	for (TActorIterator<ACWGameInfo> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWGameInfo* GameInfo = *Iter;
		check(GameInfo != nullptr);
		return GameInfo->GetGameId();
		break;
	}

	return 0;
}

bool UCWDungeonDecorateComponent::IsDoRiseEnd()
{
	return bIsDoRiseEnd;
}

bool UCWDungeonDecorateComponent::IsInServer() const
{
	return this->GetOwner()->GetLocalRole() == ROLE_Authority;
}
