
#include "CWDungeonDecorateRegion.h"

#include <random>
#include <ctime>
#include <functional>
#include "Engine.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWGameInfo.h"
#include "CWEventMgr.h"
#include "CWGameState.h"
#include "CWAssetDefine.h"
#include "CWDungeonItem.h"
#include "CWCommonUtil.h"
#include "CWGameDataUtils.h"
#include "CWGameDataStruct.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonRegionDataUtils.h"
#include "CWDungeonDecorateTile.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonDecorateRegion, All, All);

UCWDungeonDecorateRegion::UCWDungeonDecorateRegion(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Coord((int32)ECWEdgeOutSideDecorateCoord::None)
	, Orient(ECWEdgeOutSideDecorateOrientation::None)
	, Count(0)
{
	
}

void UCWDungeonDecorateRegion::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}
