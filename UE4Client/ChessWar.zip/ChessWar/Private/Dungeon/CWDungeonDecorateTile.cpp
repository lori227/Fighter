﻿
#include "CWDungeonDecorateTile.h"

#include <random>
#include <ctime>
#include <functional>
#include "Engine.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWGameInfo.h"
#include "CWEventMgr.h"
#include "CWGameState.h"
#include "CWAssetDefine.h"
#include "CWDungeonItem.h"
#include "CWCommonUtil.h"
#include "CWGameDataUtils.h"
#include "CWGameDataStruct.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonRegionDataUtils.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonDecorateTile, All, All);

ACWDungeonDecorateTile::ACWDungeonDecorateTile(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Tile(-1)
	, X(-1)
	, Y(-1)
	, Coord((int32)ECWEdgeOutSideDecorateCoord::None)
	, Orient(ECWEdgeOutSideDecorateOrientation::None)
	, Adjacent(ECWDecorateAdjacent::None)
	, AdjacentTile(-1)
	, Count(0)
	, ParentDungeonGeneratorInServer(nullptr)
	, bIsDoFall(false)
	, TickTime(0.0f)
	, CurFallSpeed(0.0f)
	, TotalFallTime(0.0f)
	, bIsBeginPlayInClient(false)
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SetRootComponent(SceneComponent);

	StaticMesh = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, "StaticMesh");
	StaticMesh->SetupAttachment(SceneComponent);
	StaticMesh->SetIsReplicated(true);

	StaticMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	//StaticMesh->SetCollisionResponseToAllChannels(ECR_Block);
}

void ACWDungeonDecorateTile::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWDungeonDecorateTile, Tile);
	DOREPLIFETIME(ACWDungeonDecorateTile, X);
	DOREPLIFETIME(ACWDungeonDecorateTile, Y);
	DOREPLIFETIME(ACWDungeonDecorateTile, Coord);
	DOREPLIFETIME(ACWDungeonDecorateTile, Orient);
	DOREPLIFETIME(ACWDungeonDecorateTile, Adjacent);
	DOREPLIFETIME(ACWDungeonDecorateTile, AdjacentTile);
	DOREPLIFETIME(ACWDungeonDecorateTile, Count);
}

bool ACWDungeonDecorateTile::ServerInitForTest(ACWRandomDungeonGenerator* ParamDungeonGenerator, int32 ParamX, int32 ParamY)
{
	ParentDungeonGeneratorInServer = ParamDungeonGenerator;

	X = ParamX;
	Y = ParamY;
	SceneComponent->SetWorldScale3D(FVector(0.75f,0.75f,0.75f));
	//LoadMesh("StaticMesh'/Game/ArtResource/SceneResource/Mesh/Floor_Red_N.Floor_Red_N'");
	return true;
}

bool ACWDungeonDecorateTile::InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, int32 ParamX, int32 ParamY)
{
	ParentDungeonGeneratorInServer = ParamDungeonGenerator;

	X = ParamX;
	Y = ParamY;
	
	//LoadMesh("StaticMesh'/Game/ArtResource/SceneResource/Mesh/Floor_Red_N.Floor_Red_N'");
	return true;
}

void ACWDungeonDecorateTile::LoadMesh(const FString& MeshPath)
{
	UStaticMesh* Mesh = LoadObject<UStaticMesh>(this, *MeshPath);
	if (Mesh == nullptr)
	{
		UE_LOG(LogCWDungeonDecorateTile, Error, TEXT("ACWDungeonDecorateTile::LoadMesh Fail. MeshPath:%s."), *MeshPath);
		return;
	}

	StaticMesh->SetStaticMesh(Mesh);

	//UE_LOG(LogCWDungeonDecorateTile, Log, TEXT("ACWDungeonDecorateTile::LoadMesh. MeshPath:%s."), *MeshPath);
}

void ACWDungeonDecorateTile::BeginPlay()
{
	Super::BeginPlay();

	// 禁用碰撞/重叠
	TArray<UActorComponent*> MyComps = GetComponentsByClass(UStaticMeshComponent::StaticClass());
	for (int32 i = 0; i < MyComps.Num(); ++i)
	{
		if (UStaticMeshComponent* StaticMeshComp = Cast<UStaticMeshComponent>(MyComps[i]))
		{
			StaticMeshComp->SetGenerateOverlapEvents(false);
			StaticMeshComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			StaticMeshComp->SetCollisionResponseToAllChannels(ECR_Ignore);
		}
	}

	bIsBeginPlayInClient = true;
}

void ACWDungeonDecorateTile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	TickTime += DeltaTime;

	if (IsInServer())
	{
		if (bIsDoFall)
		{
			FallingInServer(DeltaTime);
		}
	}
	else
	{
		if (bIsDoFall)
		{
			FallingInClient(DeltaTime);
		}
	}
}

ACWMap* ACWDungeonDecorateTile::GetMap()
{
	for (TActorIterator<ACWMap> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWMap* TempMap = *Iter;
		return TempMap;
	}

	return nullptr;
}

ACWRandomDungeonGenerator* ACWDungeonDecorateTile::GetDungeonGenerator()
{
	for (TActorIterator<ACWRandomDungeonGenerator> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWRandomDungeonGenerator* TempDungeonGenerator = *Iter;
		return TempDungeonGenerator;
	}

	return nullptr;
}

int32 ACWDungeonDecorateTile::GetGameId()
{
	for (TActorIterator<ACWGameInfo> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWGameInfo* TempGameInfo = *Iter;
		return TempGameInfo->GetGameId();
	}

	return 0;
}

bool ACWDungeonDecorateTile::IsBeginPlayInClient()
{
	return bIsBeginPlayInClient;
}

float ACWDungeonDecorateTile::RandomFloat(float min, float max)
{
	if (min > max)
	{
		UE_LOG(LogCWDungeonDecorateTile, Error, TEXT("ACWDungeonDecorateTile::RandomFloat fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(NULL) + rand() % 60017);
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

int ACWDungeonDecorateTile::RandomInt(int min, int max)
{
	if (min > max)
	{
		UE_LOG(LogCWDungeonDecorateTile, Error, TEXT("ACWDungeonDecorateTile::RandomInt fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(NULL) + rand() % 60017);
	std::uniform_int_distribution<int> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

void ACWDungeonDecorateTile::DoFallInServer()
{
	if (!IsInServer())
		return;

	bIsDoFall = true;

	NetMulticastRPCDoFall();
}

void ACWDungeonDecorateTile::NetMulticastRPCDoFall_Implementation()
{
	if (IsInServer())
		return;

	bIsDoFall = true;

	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		TempMap->RemoveTile(Tile);
	}
}

void ACWDungeonDecorateTile::FallingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		check(ParentDungeonGeneratorInServer);
		ParentDungeonGeneratorInServer->DestroyDungeonTileInServer(this->Tile);
	}
}

void ACWDungeonDecorateTile::FallingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
}

bool ACWDungeonDecorateTile::IsInServer() const
{
	return Role == ROLE_Authority;
}
