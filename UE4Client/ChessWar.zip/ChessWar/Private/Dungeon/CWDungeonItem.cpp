﻿
#include "CWDungeonItem.h"

#include "Components/StaticMeshComponent.h"

#include <random>
#include <ctime>
#include <functional>

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWFuncLib.h"
#include "CWGameState.h"
#include "CWGameInfo.h"
#include "CWCfgManager.h"
#include "CWWidgetComp.h"
#include "CWGameDefine.h"
#include "CWCommonUtil.h"
#include "CWDungeonItem.h"
#include "CWCommonUtil.h"
#include "CWDungeonTile.h"
#include "CWPawnInputFSM.h"
#include "CWPawnActionFSM.h"
#include "CWUIItemWidget.h"
#include "CWAudioVideoMgr.h"
#include "CWGameDataUtils.h"
#include "CWGameDataStruct.h"
#include "CWClientConstData.h"
#include "CWEffectDataStruct.h"
#include "CWDungeonItemGroup.h"
#include "CWDungeonItemChild.h"
#include "CWPlayerController.h"
#include "CWDestructibleActor.h"
#include "CWElementSystemCtrl.h"
#include "CWDungeonItemDataStruct.h"
#include "CWRandomDungeonGenerator.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWUIFightWindow.h"
#include "CWDungeonItemVisibility.h"
#include "CWDungeonItemDataUtils.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonItem, All, All);

ACWDungeonItem::ACWDungeonItem(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	PawnType = ECWPawnType::DungeonItem;

	StaticMesh = CreateDefaultSubobject<UStaticMeshComponent>("StaticMesh");
	StaticMesh->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
	StaticMesh->SetCollisionResponseToAllChannels(ECR_Ignore);
	StaticMesh->SetGenerateOverlapEvents(false);
	StaticMesh->SetupAttachment(RootComponent);
	StaticMesh->SetIsReplicated(true);
	//StaticMesh->SetCollisionProfileName();
	
#if !UE_SERVER
	static ConstructorHelpers::FClassFinder<UCWUIItemWidget> WidgetClass(TEXT("/Game/Blueprints/UI/Widget/Pawn/WB_UIItemWidget"));
	WidgetComp->SetWidgetClass(WidgetClass.Class);
	//WidgetComp->SetRelativeLocation(FVector(0.f, 0.f, 300.f));
#endif // !UE_SERVER

	bIsDoFall = false;
	ParentDungeonGeneratorInServer = nullptr;
	CurFallSpeed = 0.0f;
	TotalFallTime = 0.0f;
	bIsCursorOver = false;
	bIsSelected = false;
	bIsBeginPlayInClient = false;
	TickTime = 0.0f;

	LifespanRound = -1;
}

void ACWDungeonItem::BeginPlay()
{
	Super::BeginPlay();

#if !UE_SERVER
	ShowUserWidget(false);
#endif // !UE_SERVER

	if (!IsInServer())
	{
		bIsBeginPlayInClient = true;

		if (PawnType == ECWPawnType::DungeonItem)
		{
			ACWPlayerController* TempPlayerController = GetLocalPC();
			if (TempPlayerController != nullptr)
			{
				if (TempPlayerController->IsInitInClient())
				{
					TempPlayerController->RegisterDungeonItemInClient(this);
				}
				else
				{
					TScriptDelegate<> MyDelegate1;
					MyDelegate1.BindUFunction(this, FName("RespondAfterPlayerControllerSetupInClientForDungeonItem"));
					TempPlayerController->OnAfterPlayerControllerSetupInClient.AddUnique(MyDelegate1);
				}
			}

			ACWMap* TempMap = GetMap();
			if (TempMap != nullptr)
			{
				if (TempMap->IsInitInClient())
				{
					const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
					if (TempDungeonItemData->IsObstacle == 1)
					{
						SetObstacle(TempMap, Tile, TempDungeonItemData, QEuler);
					}

					if (TempDungeonItemData->CanAttack == 1)
					{
						//if (!TempMap->IsTherePawn(Tile))
						//{
						//	TempMap->MovePawn(this, -1, Tile);
						//}
					}
				}
				else
				{
					TScriptDelegate<> MyDelegate1;
					MyDelegate1.BindUFunction(this, FName("RespondAfterMapSetupInClientForDungeonItem"));
					TempMap->OnAfterMapSetupInClient.AddUnique(MyDelegate1);
				}
			}
		}
	}
}

void ACWDungeonItem::Destroyed()
{
	// 生成可破碎物体
	CreateDestructibleActor();

	// 销毁所有绑定子对象
	UCWFuncLib::DestroyActorChildren(this);

	Super::Destroyed();
}

void ACWDungeonItem::RespondAfterPlayerControllerSetupInClientForDungeonItem()
{
	ACWPlayerController* TempPlayerController = GetLocalPC();
	if (TempPlayerController != nullptr)
	{
		if (TempPlayerController->IsInitInClient())
		{
			TempPlayerController->RegisterDungeonItemInClient(this);
		}
	}
}

void ACWDungeonItem::RespondAfterMapSetupInClientForDungeonItem()
{
	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
		if (TempDungeonItemData->IsObstacle == 1)
		{
			SetObstacle(TempMap, Tile, TempDungeonItemData, QEuler);
		}

		if (TempDungeonItemData->CanAttack == 1)
		{
			//TempMap->MovePawn(this, -1, GetTile());
		}
	}
}

void ACWDungeonItem::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWDungeonItem, OwnerBuffId);
	DOREPLIFETIME(ACWDungeonItem, LifespanRound);
	DOREPLIFETIME(ACWDungeonItem, DungeonItemId);
	DOREPLIFETIME(ACWDungeonItem, ItemVisibilityActor);
}

void ACWDungeonItem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	TickTime += DeltaTime;

	if (IsInServer())
	{
		if (bIsDoFall)
		{
			FallingInServer(DeltaTime);
		}
	}
	else
	{
		if (bIsDoFall)
		{
			FallingInClient(DeltaTime);
		}
	}
}

void ACWDungeonItem::BeginCursorOver()
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	//UE_LOG(LogCWDungeonItem, Log, TEXT("ACWDungeonItem::BeginCursorOver. Tile:%d, NoCollision:%d, CanInteractive:%d."), Tile, TempDungeonItemData->NoCollision, TempDungeonItemData->CanInteractive);
	if (TempDungeonItemData->NoCollision == 0 &&
		TempDungeonItemData->CanInteractive == 1)
	{
		SetCustomDepthStencilValueEx(102);
	}

	if (IsBuffObject())
	{
		ACWPlayerController* LocalPC = GetLocalPC();
		UCWUIFightWindow* UIFightWindow = LocalPC? LocalPC->GetUIFightWindow() : nullptr;
		const FCWBuffDataStruct* TempBuffData = FCWCfgUtils::GetBuffData(this, TempDungeonItemData->BuffId);
		if (nullptr != UIFightWindow && nullptr != TempBuffData)
		{
			UIFightWindow->ShowItemBuffTips(TempBuffData->BuffDescForDoc);
		}
	}

	bIsCursorOver = true;
}

void ACWDungeonItem::EndCursorOver()
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	//UE_LOG(LogCWDungeonItem, Log, TEXT("ACWDungeonItem::EndCursorOver. Tile:%d, NoCollision:%d, CanInteractive:%d."), Tile, TempDungeonItemData->NoCollision, TempDungeonItemData->CanInteractive);
	if (TempDungeonItemData->NoCollision == 0 &&
		TempDungeonItemData->CanInteractive == 1)
	{
		if (bIsSelected)
		{
			SetCustomDepthStencilValueEx(101);
		}
		else
		{
			SetCustomDepthStencilValueEx(0);
		}
	}

	ACWPlayerController* LocalPC = GetLocalPC();
	UCWUIFightWindow* UIFightWindow = LocalPC ? LocalPC->GetUIFightWindow() : nullptr;
	if (nullptr != UIFightWindow)
	{
		UIFightWindow->HideItemBuffTips();
	}

	bIsCursorOver = false;
}

bool ACWDungeonItem::InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, const int32 ParamTile, const int32 ParamDungeonItemId, float ParamQEuler, const bool bNeedUniqueIdx)
{
	ParentDungeonGeneratorInServer = ParamDungeonGenerator;
	QEuler = ParamQEuler;

	if (ParamTile < 0 || ParamDungeonItemId < 0)
	{
		CWG_ERROR(">>> %s::InitInServer, Fail: InTile[%d] InRegionId[%d].", ParamTile, ParamDungeonItemId);
		return false;
	}
	Tile = ParamTile;
	DungeonItemId = ParamDungeonItemId;
	//~ 提到这里(后面初始化需要这个)
	if (bNeedUniqueIdx)
	{
		SetPawnUniqueIdx(GenerateNetPawnUniqueIdx());
	}

	ACWMap* TempMap = GetMap();
	if (TempMap == nullptr)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::InitInServer Fail. TempMap == nullptr."));
		return false;
	}

	const FCWDungeonItemDataStruct* TempDungeonItemData = FCWCfgUtils::GetLevelItemData(this, DungeonItemId);
	if (TempDungeonItemData == nullptr)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::InitInServer Fail. TempDungeonItemData == nullptr, DungeonItemId:%d."), DungeonItemId);
		return false;
	}

	if (TempDungeonItemData->IsObstacle == 1)
	{
		SetObstacle(TempMap, Tile, TempDungeonItemData, ParamQEuler);
	}

	if (TempDungeonItemData->CanAttack == 1)
	{
		if (!TempMap->IsTherePawn(Tile))
		{
			TempMap->MovePawn(this, -1, Tile);
		}
	}

	if (TempDungeonItemData->NoCollision != 1)
	{
		StaticMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		StaticMesh->SetCollisionResponseToAllChannels(ECR_Overlap);
		StaticMesh->SetGenerateOverlapEvents(true);
	}

	SetupBuffManager();
	//SetupSkillManager();
	SetupBattleProperty();
	SetupAction();

	/** 初始化元素系统数据 */
	InitElemSysData();

	/** 初始化物理系统数据 */
	InitPhysicsSysData();

	// Lifespan
	if (TempDungeonItemData->LifespanRound != INDEX_NONE)
	{
		SetLifespanRound(TempDungeonItemData->LifespanRound);
		if (TempDungeonItemData->LifespanTime > 0)
		{
			SetLifeSpan(TempDungeonItemData->LifespanTime);
		}
	}

	// 子对象 Actor
	/*const FString& ItemChildAssetId = TempDungeonItemData->ItemAssetId;
	if (!ItemChildAssetId.IsEmpty())
	{
		if (UClass* TempleteClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::LevelItemAsset, ItemChildAssetId))
		{
			ItemChildActor = GetWorld()->SpawnActor<ACWDungeonItemChild>(TempleteClass);

			FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
			ItemChildActor->AttachToActor(this, AttachmentRules);
			ItemChildActor->SetOwner(this);

			if (UCWElementSystemCtrl* ElemSysCtrl = GetElemSysCtrl())
			{	// 绑定元素变化事件
				ADD_EVT_DELEGATE(ElemSysCtrl->OnObjElemTypeEvent, ItemChildActor, &ACWDungeonItemChild::NetMulticastOnObjElemTypeEvent, TEXT("NetMulticastOnObjElemTypeEvent"));
			}
		}
	}*/

	// 碰撞球检测(buff)
	OwnerBuffId = TempDungeonItemData->BuffId;
	if (OwnerBuffId > 0)
	{
		/*SphereComp = NewObject<USphereComponent>(this, TEXT("SphereComp"));
		check(SphereComp);

		// 球半径(读取配置表)
		float NewSphereRadius = 10.f;
		if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("BuffItemSphereRadius")))
		{
			const float CfgRadius = FSTRING_TO_FLOAT(ConstData->Param);
			NewSphereRadius = (CfgRadius > 3.f) ? CfgRadius : NewSphereRadius;
		}

		AddOwnedComponent(SphereComp);
		SphereComp->RegisterComponent();
		SphereComp->AttachToComponent(RootComponent, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false));
		//SphereComp->SetRelativeLocation(FVector::ZeroVector);
		SphereComp->SetCollisionEnabled(ECollisionEnabled::Type::QueryAndPhysics);
		SphereComp->SetCollisionResponseToAllChannels(ECR_Ignore);
		SphereComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Overlap);
		SphereComp->SetGenerateOverlapEvents(true);
		SphereComp->SetSphereRadius(NewSphereRadius);
		SphereComp->SetHiddenInGame(false);*/
		//SphereComp->SetIsReplicated(true);	// Temp
	}

	return true;
}

bool ACWDungeonItem::SetObstacle(ACWMap* ParamMap, int32 ParamTile, const FCWDungeonItemDataStruct* ParamDungeonItemData, float ParamQEuler)
{
	check(ParamMap);
	check(ParamDungeonItemData);
	std::vector<int32> TempArrayObstacle = FCWDungeonItemDataUtils::GetArrayObstacleFromString(ParamDungeonItemData->Obstacle);
	if (TempArrayObstacle.size() != 2)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::SetObstacle Fail. TempArrayObstacle.size() != 2, TempArrayObstacle.size():%d."), TempArrayObstacle.size());
		return false;
	}

	int32 M = TempArrayObstacle[0];
	int32 N = TempArrayObstacle[1];
	if (M <= 0)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::SetObstacle Fail. M <= 0, M:%d."), M);
		return false;
	}

	if (N <= 0)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::SetObstacle Fail. N <= 0, N:%d."), N);
		return false;
	}

	int x, y;
	ACWMap::tile2xy(ParamTile, x, y);

	int32 TempM = M;
	int32 TempN = N;
	int32 TempTile = ParamTile;
	int32 TempX = 0;
	int32 TempY = 0;
	if (FMath::IsNearlyEqual(ParamQEuler, 0.0f))
	{
		TempM = M;
		TempN = N;
		TempTile = ParamTile;
		TempX = x;
		TempY = y;
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 90.0f))
	{
		TempM = N;
		TempN = M;
		TempTile = ParamTile;
		TempX = x;
		TempY = y;
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 180.0f))
	{
		TempM = M;
		TempN = N;
		TempX = x - TempM + 1;
		TempY = y;
		TempTile = ACWMap::xy2tile(TempX, TempY);
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 270.0f))
	{
		int32 TempM = N;
		int32 TempN = M;
		TempX = x - TempM + 1;
		TempY = y - TempN + 1;
		TempTile = ACWMap::xy2tile(TempX, TempY);
	}
	else
	{
		return false;
	}
	
	for (int vy = TempY; vy < TempY + TempN; ++vy)
	{
		for (int vx = TempX; vx < TempX + TempM; ++vx)
		{
			int32 vt = ACWMap::xy2tile(TempX, TempY);
			ParamMap->setMapTileAttribute(vt, (uint8)ECWDungeonTileAttribute::Obstacle);
		}
	}

	return true;
}

bool ACWDungeonItem::InitInClient(ACWPlayerController* InPc)
{
	SetParantController(InPc);

	SetupBuffManager();
	//SetupSkillManager();
	SetupAction();
	SetupInputFSM();
	GetInputFSM()->Startup((int)ECWPawnInputState::NoCtrlInReady);

	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();

#if !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer))
	{
		if (UCWUIItemWidget* UIWidget = GetUserWidget<UCWUIItemWidget>())
		{
			UIWidget->UpdateName(TempDungeonItemData->DungeonItemName);
		}
	}
#endif // !UE_SERVER

	// 设置开启自定义深度值(客户端)
	this->StaticMesh->SetRenderCustomDepth(true);

	// 粒子特效
	if (TempDungeonItemData->EffectId > 0)
	{
		FCWEffectDataStruct::SpawnEmitterAttached(TempDungeonItemData->EffectId, GetRootComponent(),
		[this](UParticleSystemComponent* InPSC, UParticleSystem* InPS)
		{
			if (!IsPendingKillPending())
			{
				if (IsValid(ParticleComp))
				{
					ParticleComp->DestroyComponent();
				}
				ParticleComp = InPSC;
			}
		});
	}

	return true;
}

void ACWDungeonItem::LoadMesh(const FString& MeshPath)
{
	if (MeshPath.IsEmpty())
	{
		return;
	}

	UStaticMesh* Mesh = FCWCfgUtils::GetMeshAssetObject<UStaticMesh>(this, MeshPath);
	if (Mesh == nullptr)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::LoadMesh Fail. MeshPath:%s."), *MeshPath);
		return;
	}

	StaticMesh->SetStaticMesh(Mesh);

	//UE_LOG(LogCWDungeonItem, Log, TEXT("ACWDungeonItem::LoadMesh. MeshPath:%s."), *MeshPath);
}

void ACWDungeonItem::DieEndInServer()
{
	ACWMap* TempMap = GetMap();
	if (TempMap == nullptr)
	{
		UE_LOG(LogCWDungeonItem, Error, TEXT("ACWDungeonItem::DieEndInServer Fail. TempMap == nullptr."));
		return;
	}

	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	if (TempDungeonItemData->IsObstacle == 1)
	{
		uint8 TempTileAttribute = TempMap->getMapTileAttribute(Tile);
		TempTileAttribute &= ~(uint8)ECWDungeonTileAttribute::Obstacle;
		TempMap->setMapTileAttribute(Tile, TempTileAttribute);
	}

	Super::DieEndInServer();
}

FString ACWDungeonItem::GetDisplayName() const
{
	const FCWDungeonItemDataStruct* ItemData = GetDungeonItemDataStruct();
	return ItemData ? ItemData->DungeonItemName : TEXT("");
}

bool ACWDungeonItem::IsMoveTile(int ParamTile)
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return !(TempDungeonItemData && TempDungeonItemData->CanInteractive);
}

UCWSkill* ACWDungeonItem::GetAutoSelectSkillRecord()
{
	return nullptr;
}

bool ACWDungeonItem::IsAllowOperate() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return NetPawnUniqueIdx > 0 && TempDungeonItemData && (TempDungeonItemData->CanInteractive == 1);
}

FString ACWDungeonItem::GetWeaponId() const
{
	return TEXT("");
}

FString ACWDungeonItem::GetActingId() const
{
	return TEXT("");
}

FString ACWDungeonItem::GetRaceId() const
{
	return TEXT("");
}

int32 ACWDungeonItem::GetGameId()
{
	ACWGameInfo* GameInfo = UCWFuncLib::GetActor<ACWGameInfo>(this);
	return (nullptr != GameInfo) ? GameInfo->GetGameId() : 0;
}

bool ACWDungeonItem::IsBeginPlayInClient()
{
	return bIsBeginPlayInClient;
}

float ACWDungeonItem::GetTickTime()
{
	return TickTime;
}

bool ACWDungeonItem::IsBuffObject()
{
	return OwnerBuffId > 0;
}

void ACWDungeonItem::AddEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0)
	{
		FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, StaticMesh);
	}
}

void ACWDungeonItem::AddBeAttackedEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0)
	{
		FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, StaticMesh);
	}
}

void ACWDungeonItem::DoFallInServer()
{
	if (!IsInServer())
		return;

	bIsDoFall = true;

	NetMulticastRPCDoFall();
}

void ACWDungeonItem::FallingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		check(ParentDungeonGeneratorInServer);
		ParentDungeonGeneratorInServer->DestroyDungeonItemInServer(this->GetTile());
	}
}

void ACWDungeonItem::FallingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
}

void ACWDungeonItem::SelectedInReady(ACWPlayerController* ParamPc)
{
	Super::SelectedInReady(ParamPc);

	ShowUserWidget(true);
}

void ACWDungeonItem::CancelSelectedInReady(bool bNeedJumpState /*= true*/)
{
	Super::CancelSelectedInReady(bNeedJumpState);

	ShowUserWidget(false);
}

void ACWDungeonItem::SelectedInClient(ACWPlayerController* ParamPc, bool bLongDown)
{
	Super::SelectedInClient(ParamPc, bLongDown);

	ShowUserWidget(true);

	bIsSelected = true;
}

void ACWDungeonItem::CancelSelectedInClient()
{
	Super::CancelSelectedInClient();

	ShowUserWidget(false);

	if (bIsCursorOver)
	{
		SetCustomDepthStencilValueEx(101);
	}
	else
	{
		SetCustomDepthStencilValueEx(0);
	}

	bIsSelected = false;
}

void ACWDungeonItem::OnBecomeSelectedTarget(bool bSelected, ACWPawn* InOpPawn /*= nullptr*/)
{
	Super::OnBecomeSelectedTarget(bSelected, InOpPawn);

	ShowUserWidget(bSelected);
}

void ACWDungeonItem::PlayClickAudio()
{
	if (UCWAudioVideoMgr* AV_Mgr = AV_MGR(this))
	{	// 点击音效
		const FCWDungeonItemDataStruct* ItemData = GetDungeonItemDataStruct();
		if (nullptr != ItemData && !ItemData->ClickAudioId.IsEmpty())
		{
			AV_Mgr->PlayAudioByCfg(this, ItemData->ClickAudioId);
		}
	}
}

bool ACWDungeonItem::IsCanAttack() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return TempDungeonItemData && (TempDungeonItemData->CanAttack == 1);
}

bool ACWDungeonItem::IsNoCollision() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return TempDungeonItemData && (TempDungeonItemData->NoCollision == 1);
}

bool ACWDungeonItem::CanInteractive() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return TempDungeonItemData && (TempDungeonItemData->CanInteractive == 1);
}

FString ACWDungeonItem::ToString() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct();
	return FString::Printf(TEXT("\t-> Name[%s] Tile[%d] ItemId[%d] Data[%s]."),
		*GetName(), Tile, DungeonItemId, *(TempDungeonItemData ? TempDungeonItemData->ToString() : FString("Null")));
}

void ACWDungeonItem::SetItemVisibilityActor(ACWDungeonItemVisibility* ParamItemVisibility)
{
	ItemVisibilityActor = ParamItemVisibility;
}

ACWDungeonItemVisibility* ACWDungeonItem::GetItemVisibilityActor()
{
	return ItemVisibilityActor;
}

void ACWDungeonItem::SetCustomDepthStencilValueEx(int32 ParamValue)
{
	//UE_LOG(LogCWDungeonItem, Log, TEXT("ACWDungeonItem::SetCustomDepthStencilValueEx. ParamValue:%d, Tile:%d."), ParamValue, Tile);

	this->StaticMesh->SetCustomDepthStencilValue(ParamValue);

	if (ItemVisibilityActor)
	{
		ItemVisibilityActor->HandleCustomDepthStencilValue(ParamValue);
	}
}

const FCWDungeonItemDataStruct* ACWDungeonItem::GetDungeonItemDataStruct() const
{
	const FCWDungeonItemDataStruct* TempDungeonItemDataStruct = FCWCfgUtils::GetLevelItemData(this, DungeonItemId);
	check(TempDungeonItemDataStruct);
	return TempDungeonItemDataStruct;
}

ACWRandomDungeonGenerator* ACWDungeonItem::GetDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
}

bool ACWDungeonItem::CheckOverlapPickup(AActor* InOtherActor)
{
	if (!IsBuffObject() || !IsValidActor(this) || !IsValidActor(InOtherActor) || IsNetMode(NM_Client))
	{
		return false;
	}

	ACWGameState* MyGameState = GetGameState();
	if (!IsValidActor(MyGameState) || MyGameState->GetCurBattleState() != ECWBattleState::Fighting)
	{
		return false;
	}

	ACWPawn* OverlapPawn = Cast<ACWPawn>(InOtherActor);
	if (IsValidActor(OverlapPawn) && OverlapPawn->IsPawnType(ECWPawnType::Character) &&
		!OverlapPawn->IsDieOrDeath() && OverlapPawn->GetPawnUniqueIdx() > 0 && OverlapPawn->GetTile() == GetTile())
	{	// 场景物件(携带Buff)
		CWG_LOG(">> ACWDungeonItem::OnBeginOverlap, Add buff[%d] to Pawn[%s].", OwnerBuffId, *OverlapPawn->GetDisplayName());

		OverlapPawn->GenerateBuff(OwnerBuffId, ECWBuffSouceType::Scene);

		// 销毁自己
		return Destroy();
	}
	return false;
}

void ACWDungeonItem::SetTile(int32 ParamTile)
{
	Super::SetTile(ParamTile);

	ResetMapTileAttribute();
	ResetMapObjectGroup();
}

void ACWDungeonItem::SetTile(int32 ParamOldTile, int32 ParamTile)
{
	Super::SetTile(ParamOldTile, ParamTile);

	ResetMapTileAttribute();
	ResetMapObjectGroup();
}

void ACWDungeonItem::ResetMapTileAttribute()
{
	// 重置地图导航层数据(障碍)
	const FCWDungeonItemDataStruct* ItemData = GetDungeonItemDataStruct();
	if (nullptr != ItemData && ItemData->IsObstacle == 1)
	{
		if (ACWMap* MyMap = GetMap())
		{
			uint8 OldTileAttribute = MyMap->getMapTileAttribute(OldTile);
			OldTileAttribute &= ~(uint8)ECWDungeonTileAttribute::Obstacle;
			MyMap->setMapTileAttribute(OldTile, OldTileAttribute);

			uint8 CurTileAttribute = MyMap->getMapTileAttribute(Tile);
			CurTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
			MyMap->setMapTileAttribute(Tile, CurTileAttribute);
		}
	}
}

void ACWDungeonItem::ResetMapObjectGroup()
{
	if (!IsInServer())
	{
		return;
	}

	if (ACWRandomDungeonGenerator* Generator = GetDungeonGenerator())
	{
		//// 清理旧组数据
		//if (ACWDungeonItemGroup* OldItemGroup = Generator->GetDungeonItemGroup(OldTile))
		//{
		//	OldItemGroup->ClearObjectInGroup(this);
		//}
		//// 添加到当前组
		//ACWDungeonItemGroup* CurItemGroup = Generator->GetDungeonItemGroup(Tile);
		//if (!IsValidActor(CurItemGroup) || !CurItemGroup->HasItem(this))
		//{
		//	Generator->SetDungeonItem(Tile, this);
		//}
	}
}

int32 ACWDungeonItem::GetOwnElemIdByCfg()
{
	const FCWDungeonItemDataStruct* ItemData = GetDungeonItemDataStruct();
	return ItemData ? ItemData->OwnElemId : INDEX_NONE;
}

FCWPhysicsSysData ACWDungeonItem::GetPhysicsSysData()
{
	FCWPhysicsSysData OutData;
	if (const FCWDungeonItemDataStruct* ItemData = FCWCfgUtils::GetLevelItemData(this, DungeonItemId))
	{
		OutData.InitByItemData(ItemData);
	}
	return OutData;
}

void ACWDungeonItem::SetupBattleProperty()
{
	const FCWDungeonItemDataStruct* ItemData = GetDungeonItemDataStruct();
	if (nullptr != ItemData && IsValid(BattleProperty))
	{
		BattleProperty->GetPropertySetBase().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetPawnUniqueIdx());
		BattleProperty->GetPropertySetBase().SetProperty<int32>(ECWBattleProperty::Profession, 0);
		BattleProperty->GetPropertySetBase().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);
		BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Health, ItemData->HealthValue);

		BattleProperty->GetCurPropertySet().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetPawnUniqueIdx());
		BattleProperty->GetCurPropertySet().SetProperty<int32>(ECWBattleProperty::Profession, 0);
		BattleProperty->GetCurPropertySet().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

		BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetPawnUniqueIdx());
		BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<int32>(ECWBattleProperty::Profession, 0);
		BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

		BattleProperty->RecalculateCurMaxTheoreticalPropertySet();
		BattleProperty->GetCurPropertySet() = BattleProperty->GetCurMaxTheoreticalPropertySet();
	}
}

bool ACWDungeonItem::IsInClient() const
{
	return !IsNetMode(NM_DedicatedServer) && Role != ROLE_Authority;
}

bool ACWDungeonItem::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWDungeonItem::CreateDestructibleActor()
{
	UWorld* const MyWorld = GetWorld();
	if (NetPawnUniqueIdx <= 0 || nullptr == MyWorld || IsNetMode(NM_DedicatedServer))
	{
		return false;
	}

	if (const FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemDataStruct())
	{
		const FString& BrokenAssetId = TempDungeonItemData->BrokenAssetId;
		if (!BrokenAssetId.IsEmpty() &&
			(TempDungeonItemData->CanInteractive == 1) &&
			(TempDungeonItemData->CanAttack == 1))
		{
			if (UClass* TempleteClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::LevelItemAsset, BrokenAssetId))
			{
				ACWDestructibleActor* DestructibleActor = 
					MyWorld->SpawnActor<ACWDestructibleActor>(TempleteClass, GetActorLocation(), GetActorRotation());
				return (nullptr != DestructibleActor);
			}
		}
	}
	return false;
}

void ACWDungeonItem::SetLifespanRound(const int32 InLifespanRound)
{
	if (InLifespanRound > 0)
	{
		return;
	}

	LifespanRound = InLifespanRound;
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		REMOVE_EVT_DELEGATE(Evt_Mgr->OnRoundIndexChangeInServer, this);
		if (LifespanRound > 0)
		{
			ADD_EVT_DELEGATE(Evt_Mgr->OnRoundIndexChangeInServer, this, &ACWDungeonItem::OnRoundChange, "OnRoundChange");
		}
	}
}

void ACWDungeonItem::NotifyUpdatePropertyData()
{
	//CWG_LOG(">>> %s::OnPropertySetChangeInClient Camp[%d] CtrlIdx[%d] Idx[%d]...", 
		//*GetName(), (int32)CampTag, (int32)ControllerIndex, (int32)PawnIndex);
	UCWUIItemWidget* UIItemWidget = GetUserWidget<UCWUIItemWidget>();
	if (nullptr != UIItemWidget && nullptr != BattleProperty)
	{
		const FCWBattlePropertySet& CurVProperty = BattleProperty->GetCurPropertySet();
		const FCWBattlePropertySet& MaxVProperty = BattleProperty->GetCurMaxTheoreticalPropertySet();

		float CurHp = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		float MaxHp = MaxVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		UIItemWidget->UpdateHp((int32)CurHp, (int32)MaxHp);

		const FString& ItemName = GetDisplayName();
		UIItemWidget->UpdateName(ItemName);
	}
}

void ACWDungeonItem::OnRoundChange(int32 InCurRound, int32 InMaxRound)
{
	if (--LifespanRound <= 0)
	{	// 生命回合
		Destroy(/*true*/);
	}
}

void ACWDungeonItem::OnBeginOverlap(AActor* OtherActor)
{
	//CheckOverlapPickup(OtherActor);
}

void ACWDungeonItem::OnEndOverlap(AActor* OtherActor)
{
}
