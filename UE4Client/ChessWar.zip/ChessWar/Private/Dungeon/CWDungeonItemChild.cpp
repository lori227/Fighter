﻿
#include "CWDungeonItemChild.h"

#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Particles/ParticleSystemComponent.h"

#include "CWDungeonItem.h"


ACWDungeonItemChild::ACWDungeonItemChild(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	DefaultStaticMeshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DefaultStaticMeshComp"));
	DefaultStaticMeshComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
	DefaultStaticMeshComp->SetCollisionResponseToAllChannels(ECR_Ignore);
	DefaultStaticMeshComp->SetGenerateOverlapEvents(false);
	DefaultStaticMeshComp->bApplyImpulseOnDamage = false;
	DefaultStaticMeshComp->SetEnableGravity(false);
	DefaultStaticMeshComp->SetupAttachment(RootComponent);

	DefaultParticleComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("DefaultParticleComp"));
	DefaultParticleComp->SetupAttachment(DefaultStaticMeshComp);
}

ACWDungeonItemChild::~ACWDungeonItemChild()
{
}

void ACWDungeonItemChild::OnObjElemTypeEvent_Implementation(const EObjElemType InObjElemType)
{
}

void ACWDungeonItemChild::NetMulticastOnObjElemTypeEvent_Implementation(const EObjElemType InObjElemType)
{
	OnObjElemTypeEvent(InObjElemType);
}
