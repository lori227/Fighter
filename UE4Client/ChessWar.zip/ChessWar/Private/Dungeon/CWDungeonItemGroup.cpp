﻿
#include "CWDungeonItemGroup.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "UnrealNetwork.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonItemGroup, All, All);

ACWDungeonItemGroup::ACWDungeonItemGroup(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>("DungeonItemGroup");

	int32 TempNum = ((int32)ECWDungeonLogicLayer::Max) - 1;
	ArrayDungeonItem.Init(nullptr, TempNum);
}

void ACWDungeonItemGroup::BeginPlay()
{
	Super::BeginPlay();

}

void ACWDungeonItemGroup::Destroyed()
{
	Super::Destroyed();
}

void ACWDungeonItemGroup::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ACWDungeonItemGroup::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWDungeonItemGroup, Tile);
	DOREPLIFETIME(ACWDungeonItemGroup, ArrayDungeonItem);
}

void ACWDungeonItemGroup::Init(int32 ParamTile)
{
	Tile = ParamTile;
}

void ACWDungeonItemGroup::DoFallInServer()
{
	for (int i = 0; i < ArrayDungeonItem.Num(); ++i) 
	{
		ACWDungeonItem* TempItem = ArrayDungeonItem[i];
		if (TempItem != nullptr)
		{
			TempItem->DoFallInServer();
		}
	}
	ArrayDungeonItem.Empty();
}

bool ACWDungeonItemGroup::IsBeginPlayInClient()
{
	//TArray<ACWDungeonItem*> ArrayDungeonItem;
	return true;
}

bool ACWDungeonItemGroup::GetAllArrayItem(TArray<ACWDungeonItem*>& ParamOutArrayItem)
{
	ParamOutArrayItem = ArrayDungeonItem;
	return true;
}

bool ACWDungeonItemGroup::GetAllDungeonItemByCanBeAttacked(TArray<ACWDungeonItem*>& ParamOutArrayItem)
{
	ParamOutArrayItem.Empty();
	for (TArray<ACWDungeonItem*>::TIterator iter = ArrayDungeonItem.CreateIterator(); iter; ++iter)
	{
		ACWDungeonItem* TempDungeonItem = *iter;

		if (nullptr == TempDungeonItem)
		{
			continue;
		}
		FCWDungeonItemDataStruct* TempDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), TempDungeonItem->DungeonItemId);
		if (TempDungeonItemData == nullptr)
		{
			UE_LOG(LogCWDungeonItemGroup, Error, TEXT("ACWDungeonItemGroup::GetAllDungeonItemByCanBeAttacked, TempDungeonItemData == nullptr, ParamItemId:%d."), TempDungeonItem->DungeonItemId);
			continue;
		}

		if (TempDungeonItemData->CanAttack == 1)
		{
			ParamOutArrayItem.Add(TempDungeonItem);
		}
	}

	return true;
}

bool ACWDungeonItemGroup::GetAllBuffObjects(TArray<ACWDungeonItem*>& ParamOutArrayItem)
{
	ParamOutArrayItem.Empty();
	for (TArray<ACWDungeonItem*>::TIterator iter = ArrayDungeonItem.CreateIterator(); iter; ++iter)
	{
		ACWDungeonItem* TempDungeonItem = *iter;
		if (nullptr != TempDungeonItem && TempDungeonItem->IsBuffObject())
		{
			ParamOutArrayItem.Add(TempDungeonItem);
		}
	}

	return true;
}

bool ACWDungeonItemGroup::AddItem(int32 ParamLayer, ACWDungeonItem* ParamDungeonItem)
{
	if (!ArrayDungeonItem.IsValidIndex(ParamLayer))
	{
		UE_LOG(LogCWDungeonItemGroup, Error, TEXT("ACWDungeonItemGroup::AddItem, ArrayDungeonItem.IsValidIndex, ParamLayer:%d, Tile:%d, ArrayDungeonItem.Num():%d."), ParamLayer, Tile, ArrayDungeonItem.Num());
		return false;
	}
	
	if (ArrayDungeonItem[ParamLayer] != nullptr)
	{
		UE_LOG(LogCWDungeonItemGroup, Error, TEXT("ACWDungeonItemGroup::AddItem, ArrayDungeonItem[ParamLayer] != nullptr, ParamLayer:%d, Tile:%d."), ParamLayer, Tile);
		return false;
	}

	ArrayDungeonItem[ParamLayer] = ParamDungeonItem;
	return true;
}