
#include "CWDungeonItemGroupData.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "UnrealNetwork.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonItemGroupData, All, All);

FCWDungeonItemGroupData::FCWDungeonItemGroupData()
{
	Generator = nullptr;

	ArrayItem.Reserve((int32)(ECWDungeonLogicLayer::Max)-1);
	ArrayItemQEuler.Reserve((int32)(ECWDungeonLogicLayer::Max) - 1);
	for(int i = (int32)ECWDungeonLogicLayer::None + 1; i < (int32)ECWDungeonLogicLayer::Max; ++i)
	{
		ArrayItem.Add(0);
		ArrayItemQEuler.Add(0.0f);
	}
}

FCWDungeonItemGroupData::~FCWDungeonItemGroupData()
{
}

void FCWDungeonItemGroupData::Init(ACWRandomDungeonGenerator* ParamGenerator, int32 ParamTile)
{
	check(ParamGenerator);
	Generator = ParamGenerator;
	Tile = ParamTile;
}

bool FCWDungeonItemGroupData::CanAdd(int32 ParamItemId)
{
	FCWDungeonItemDataStruct* OtherDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), ParamItemId);
	if (OtherDungeonItemData == nullptr)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::CanAdd, OtherDungeonItemData == nullptr, ParamItemId:%d."), ParamItemId);
		return false;
	}

	if (OtherDungeonItemData->ObjLayer <= ECWDungeonLogicLayer::None || OtherDungeonItemData->ObjLayer >= ECWDungeonLogicLayer::Max)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::CanAdd, OtherDungeonItemData->ObjLayer Invalid, ParamItemId:%d, ObjLayer:%d."), ParamItemId, (int32)OtherDungeonItemData->ObjLayer);
		return false;
	}

	//ͬ���������
	if (ArrayItem[(int32)(OtherDungeonItemData->ObjLayer)] != 0)
	{
		return false;
	}
	else
	{
		for (int i = 0; i < ArrayItem.Num(); ++i)
		{
			int32 TempItemId = ArrayItem[i];
			if (TempItemId <= 0)
				continue;

			FCWDungeonItemDataStruct* TempDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), TempItemId);
			if (TempDungeonItemData == nullptr)
			{
				UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::CanAdd, TempDungeonItemData == nullptr, TempItemId:%d."), TempItemId);
				continue;
			}

			//��������Ƿ����ֹ
			if (TempDungeonItemData->CreationExclusion && TempDungeonItemData->ExclusionPriority > OtherDungeonItemData->ExclusionPriority)
			{
				return false;
			}
		}
	}

	return true;
}

bool FCWDungeonItemGroupData::AddItem(int32 ParamItemId, float ParamQEuler)
{
	if (!CanAdd(ParamItemId))
		return false;

	FCWDungeonItemDataStruct* OtherDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), ParamItemId);
	if (OtherDungeonItemData == nullptr)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::AddItem, OtherDungeonItemData == nullptr, ParamItemId:%d."), ParamItemId);
		return false;
	}

	if (OtherDungeonItemData->ObjLayer <= ECWDungeonLogicLayer::None || OtherDungeonItemData->ObjLayer >= ECWDungeonLogicLayer::Max)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::AddItem, OtherDungeonItemData->ObjLayer Invalid, ParamItemId:%d, ObjLayer:%d."), ParamItemId, (int32)OtherDungeonItemData->ObjLayer);
		return false;
	}

	if (OtherDungeonItemData->CreationExclusion)
	{
		int index = 0;
		for (int i = 0; i < ArrayItem.Num(); ++i)
		{
			int32 TempItemId = ArrayItem[i];
			if (TempItemId != 0)
			{
				FCWDungeonItemDataStruct* TempDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), TempItemId);
				if (TempDungeonItemData == nullptr)
				{
					UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::AddItem, TempDungeonItemData == nullptr, TempItemId:%d."), TempItemId);
					continue;
				}

				if (OtherDungeonItemData->ExclusionPriority < TempDungeonItemData->ExclusionPriority)
				{
					ArrayItem[i] = 0;
					ArrayItemQEuler[i] = 0.0f;
				}
			}
		}
	}

	if (OtherDungeonItemData->IsObstacle && !SetObstacleData(Tile, OtherDungeonItemData, ParamQEuler))
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::SetObstacleData, fail, Tile:%d, ParamItemId:%d, ParamQEuler:%f."), Tile, ParamItemId, ParamQEuler);
		return false;
	}

	ArrayItem[(int32)OtherDungeonItemData->ObjLayer] = ParamItemId;
	ArrayItemQEuler[(int32)OtherDungeonItemData->ObjLayer] = ParamQEuler;
	UE_LOG(LogCWDungeonItemGroupData, Log, TEXT("FCWDungeonItemGroupData::AddItem, Tile:%d, ObjLayer:%d, ParamItemId:%d, ParamQEuler:%f."), Tile, (int32)OtherDungeonItemData->ObjLayer, ParamItemId, ParamQEuler);
	
	return true;
}

bool FCWDungeonItemGroupData::SetObstacleData(int32 ParamTile, const FCWDungeonItemDataStruct* ParamDungeonItemData, float ParamQEuler)
{
	check(Generator);
	check(ParamDungeonItemData);
	std::vector<int32> TempArrayObstacle = FCWDungeonItemDataUtils::GetArrayObstacleFromString(ParamDungeonItemData->Obstacle);
	if (TempArrayObstacle.size() != 2)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::SetObstacleData Fail. TempArrayObstacle.size() != 2, TempArrayObstacle.size():%d."), TempArrayObstacle.size());
		return false;
	}

	int32 M = TempArrayObstacle[0];
	int32 N = TempArrayObstacle[1];
	if (M <= 0)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::SetObstacleData Fail. M <= 0, M:%d."), M);
		return false;
	}

	if (N <= 0)
	{
		UE_LOG(LogCWDungeonItemGroupData, Error, TEXT("FCWDungeonItemGroupData::SetObstacleData Fail. N <= 0, N:%d."), N);
		return false;
	}

	int x, y;
	ACWMap::tile2xy(ParamTile, x, y);

	int32 TempM = M;
	int32 TempN = N;
	int32 TempTile = ParamTile;
	int32 TempX = 0;
	int32 TempY = 0;
	if (FMath::IsNearlyEqual(ParamQEuler, 0.0f))
	{
		TempM = M;
		TempN = N;
		TempTile = ParamTile;
		TempX = x;
		TempY = y;
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 90.0f))
	{
		TempM = N;
		TempN = M;
		TempTile = ParamTile;
		TempX = x;
		TempY = y;
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 180.0f))
	{
		TempM = M;
		TempN = N;
		TempX = x - TempM + 1;
		TempY = y;
		TempTile = ACWMap::xy2tile(TempX, TempY);
	}
	else if (FMath::IsNearlyEqual(ParamQEuler, 270.0f))
	{
		int32 TempM = N;
		int32 TempN = M;
		TempX = x - TempM + 1;
		TempY = y - TempN + 1;
		TempTile = ACWMap::xy2tile(TempX, TempY);
	}
	else
	{
		return false;
	}

	for (int vy = TempY; vy < TempY + TempN; ++vy)
	{
		for (int vx = TempX; vx < TempX + TempM; ++vx)
		{
			int32 vt = ACWMap::xy2tile(TempX, TempY);
			Generator->SetArrayDungeonItemObstacle(vt, 1);
		}
	}

	return true;
}

bool FCWDungeonItemGroupData::GetArrayItem(TArray<int32>& ParamOutArrayItem)
{
	ParamOutArrayItem = ArrayItem;
	return true;
}

bool FCWDungeonItemGroupData::GetArrayItemQEuler(TArray<float>& ParamOutArrayItemQEuler)
{
	ParamOutArrayItemQEuler = ArrayItemQEuler;
	return true;
}