
#include "CWDungeonItemVisibility.h"

#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Particles/ParticleSystemComponent.h"

#include "CWDungeonItem.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonItemVisibility, All, All);

ACWDungeonItemVisibility::ACWDungeonItemVisibility(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

ACWDungeonItemVisibility::~ACWDungeonItemVisibility()
{
	

}

void ACWDungeonItemVisibility::BeginPlay()
{
	TArray<UStaticMeshComponent*> TempArrayMeshComponent;
	GetComponents<UStaticMeshComponent>(TempArrayMeshComponent, true);
	for (TArray<UStaticMeshComponent*>::TIterator iter = TempArrayMeshComponent.CreateIterator(); iter; ++iter)
	{
		UStaticMeshComponent* TempMeshCompoent = *iter;
		TempMeshCompoent->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
		TempMeshCompoent->SetCollisionResponseToAllChannels(ECR_Ignore);
		TempMeshCompoent->SetGenerateOverlapEvents(false);
		TempMeshCompoent->SetCollisionObjectType(ECC_WorldStatic);
		TempMeshCompoent->bApplyImpulseOnDamage = false;
		TempMeshCompoent->SetEnableGravity(false);

		TempMeshCompoent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		TempMeshCompoent->SetCollisionResponseToAllChannels(ECR_Overlap);
		TempMeshCompoent->SetGenerateOverlapEvents(true);

		if (IsInClient())
		{
			// ���ÿ����Զ������ֵ(�ͻ���)
			TempMeshCompoent->SetRenderCustomDepth(true);
		}
	}
}

void ACWDungeonItemVisibility::NotifyActorBeginCursorOver()
{
	Super::NotifyActorBeginCursorOver();

	//UE_LOG(LogCWDungeonItemVisibility, Log, TEXT("ACWDungeonItemVisibility::NotifyActorBeginCursorOver."));

	ACWPlayerController* TempPC = Cast<ACWPlayerController>(this->GetWorld()->GetFirstPlayerController());
	if (TempPC != nullptr)
	{
		AActor* TempLastCursorActor = TempPC->GetLastCursorActor();
		if (TempLastCursorActor != nullptr && TempLastCursorActor != this)
		{
			ACWMapTile* TempMapTile = Cast<ACWMapTile>(TempLastCursorActor);
			if (TempMapTile)
			{
				TempMapTile->EndCursorOver();
			}
		}
	}

	BeginCursorOver();

	if (TempPC != nullptr)
	{
		TempPC->SetLastCursorActor(this);
	}
}

void ACWDungeonItemVisibility::NotifyActorEndCursorOver()
{
	Super::NotifyActorEndCursorOver();

	//UE_LOG(LogCWDungeonItemVisibility, Log, TEXT("ACWDungeonItemVisibility::NotifyActorEndCursorOver."));

	EndCursorOver();
}


void ACWDungeonItemVisibility::BeginCursorOver()
{
	ACWDungeonItem* TempDungeonItem = Cast<ACWDungeonItem>(GetOwner());
	if (TempDungeonItem != nullptr)
	{
		if (!TempDungeonItem->IsValidToCursorOver())
		{
			return;
		}

		ACWPlayerController* LocalPC = TempDungeonItem->GetLocalPC();
		if (IsValid(LocalPC))
		{
			LocalPC->NotifyPawnBeginCursorOver(TempDungeonItem);
		}
	}
}

void ACWDungeonItemVisibility::EndCursorOver()
{
	ACWDungeonItem* TempDungeonItem = Cast<ACWDungeonItem>(GetOwner());
	if (TempDungeonItem != nullptr)
	{
		if (!TempDungeonItem->IsValidToCursorOver())
		{
			return;
		}

		ACWPlayerController* LocalPC = TempDungeonItem->GetLocalPC();
		if (IsValid(LocalPC))
		{
			LocalPC->NotifyPawnEndCursorOver(TempDungeonItem);
		}
	}
}

void ACWDungeonItemVisibility::SetItemVisibilityCollision(bool ParamCollision)
{
	TArray<UStaticMeshComponent*> TempArrayMeshComponent;
	GetComponents<UStaticMeshComponent>(TempArrayMeshComponent, true);
	int index = 0;
	for (TArray<UStaticMeshComponent*>::TIterator iter = TempArrayMeshComponent.CreateIterator(); iter; ++iter)
	{
		UStaticMeshComponent* TempMeshCompoent = *iter;
		if (ParamCollision)
		{
			TempMeshCompoent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
			TempMeshCompoent->SetCollisionResponseToAllChannels(ECR_Overlap);
			TempMeshCompoent->SetGenerateOverlapEvents(true);
		}
		else
		{
			TempMeshCompoent->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
			TempMeshCompoent->SetCollisionResponseToAllChannels(ECR_Ignore);
			TempMeshCompoent->SetGenerateOverlapEvents(false);
		}

		index++;
	}
}

void ACWDungeonItemVisibility::HandleCustomDepthStencilValue(int32 ParamValue)
{
	TArray<UStaticMeshComponent*> TempArrayMeshComponent;
	GetComponents<UStaticMeshComponent>(TempArrayMeshComponent, true);
	for (TArray<UStaticMeshComponent*>::TIterator iter = TempArrayMeshComponent.CreateIterator(); iter; ++iter)
	{
		UStaticMeshComponent* TempMeshCompoent = *iter;
		TempMeshCompoent->SetCustomDepthStencilValue(ParamValue);
	}
}

bool ACWDungeonItemVisibility::IsInClient() const
{
	return !IsNetMode(NM_DedicatedServer) && Role != ROLE_Authority;
}

bool ACWDungeonItemVisibility::IsInServer() const
{
	return Role == ROLE_Authority;
}

