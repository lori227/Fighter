﻿
#include "CWDungeonTile.h"

#include <random>
#include <ctime>
#include <functional>
#include "Engine.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWGameInfo.h"
#include "CWEventMgr.h"
#include "CWGameState.h"
#include "CWAssetDefine.h"
#include "CWDungeonItem.h"
#include "CWCommonUtil.h"
#include "CWGameDataUtils.h"
#include "CWGameDataStruct.h"
#include "CWClientConstData.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonRegionDataUtils.h"
#include "CWComDef.h"
#include "CWPlayerController.h"
#include "CWUIFightWindow.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWDungeonTile, All, All);

ACWDungeonTile::ACWDungeonTile(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Tile(-1)
	, X(-1)
	, Y(-1)
	, RegionId(-1)
	, OffsetZ(0.0f)
	, bIsDoFall(false)
	, ParentDungeonGeneratorInServer(nullptr)
	, CurFallSpeed(0.0f)
	, TotalFallTime(0.0f)
	, bIsDoRise(false)
	, bIsDoRised(false)
	, bIsDoRiseEnd(false)
	, CurRiseSpeed(10.0f)
	, bIsTriggerRise(false)
	, bIsBeginPlayInClient(false)
	, TickTime(0.0f)
	, OverrideMaterialIdx(INDEX_NONE)
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SetRootComponent(SceneComponent);

	StaticMesh = ObjectInitializer.CreateDefaultSubobject<UCWStaticMeshComponent>(this, "StaticMesh");
	StaticMesh->SetupAttachment(SceneComponent);
	StaticMesh->SetIsReplicated(true);

	StaticMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	StaticMesh->SetCollisionResponseToAllChannels(ECR_Block);
	// 忽略摄像机移动触发响应
	StaticMesh->SetCollisionResponseToChannel(COLLISION_PANCAMERA, ECR_Ignore);
}

void ACWDungeonTile::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWDungeonTile, Tile);
	DOREPLIFETIME(ACWDungeonTile, X);
	DOREPLIFETIME(ACWDungeonTile, Y);
	DOREPLIFETIME(ACWDungeonTile, RegionId);
	DOREPLIFETIME(ACWDungeonTile, OffsetZ);
	DOREPLIFETIME(ACWDungeonTile, ResNameIndex);
	DOREPLIFETIME(ACWDungeonTile, OverrideMaterialIdx);
}

void ACWDungeonTile::BeginCursorOver()
{
	FTimerDelegate ShowTileTipsCallback;
	ShowTileTipsCallback.BindLambda([=]()
	{
		ACWRandomDungeonGenerator * rdg = GetDungeonGenerator();
		if (nullptr == rdg) return;
		
		FCWDungeonRegionDataStruct* regionData = rdg->GetDungeonRegionData(RegionId);
		if (nullptr == regionData) return;
		
		int32 TerrainHeight = rdg->GetGridLayerByTile(this->Tile);
		FString TileTypeName = regionData->DungeonRegionName;
		
		ACWPlayerController * pc = Cast<ACWPlayerController>(GetWorld()->GetFirstPlayerController());
		if (nullptr == pc) return;

		UCWUIFightWindow* uiFightWindow = pc->GetUIFightWindow();
		if (nullptr == uiFightWindow) return;
		
		FString TxtTerrainDefince = TEXT("");
		const float TerrainDefinceFactor = regionData->TerrainDefinceFactor;
		if (!FMath::IsNearlyZero(TerrainDefinceFactor))
		{
			TxtTerrainDefince = UCWUIFightWindow::GetTerrainPropertyTxt(TerrainDefinceFactor);
		}
		uiFightWindow->ShowTileTips(TileTypeName, TerrainHeight, TxtTerrainDefince);
	});

	const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("TileTipsDelayTime"));
	const float DelayTime = ConstData ? FSTRING_TO_FLOAT(ConstData->Param) : 1.5f;
	GetWorldTimerManager().SetTimer(ShowTileTipsTimer, ShowTileTipsCallback, DelayTime, false);
}

void ACWDungeonTile::EndCursorOver()
{
	GetWorldTimerManager().ClearTimer(ShowTileTipsTimer);
	ACWPlayerController * pc = Cast<ACWPlayerController>(GetWorld()->GetFirstPlayerController());
	if (nullptr == pc) return;
	UCWUIFightWindow* uiFightWindow = pc->GetUIFightWindow();
	if (nullptr == uiFightWindow) return;
	uiFightWindow->HideTileTips();
}

bool ACWDungeonTile::InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, const int32 InTile, const int32 InRegionId)
{
	ParentDungeonGeneratorInServer = ParamDungeonGenerator;

	if (InTile < 0 || InRegionId < 0)
	{
		CWG_ERROR(">>> %s::InitInServer, Fail: InTile[%d] InRegionId[%d].", InTile, InRegionId);
		return false;
	}
	Tile = InTile;
	RegionId = InRegionId;
	ACWMap::tile2xy(Tile, X, Y);
	return true;
}

bool ACWDungeonTile::ClientUpdate()
{
	if (!HasActorBegunPlay() || IsPendingKill())
	{
		return false;
	}

	if (Tile < 0 || RegionId <= 0)
	{
		CWG_WARNING(">> %s::ClientUpdate, Fail: Tile[%d] RegionId[%d] .", *GetName(), Tile, RegionId);
		return false;
	}

	ACWRandomDungeonGenerator* DungeonGenerator = GetDungeonGenerator();
	if (nullptr == DungeonGenerator)
	{
		CWG_WARNING(">> %s::ClientUpdate, Fail: DungeonGenerator is nullptr .", *GetName());
		return false;
	}

	FCWDungeonRegionDataStruct* RegionDataPtr = DungeonGenerator->GetDungeonRegionData(RegionId);
	if (nullptr == RegionDataPtr)
	{
		CWG_ERROR(">>> %s::ClientUpdate, Fail: RegionDataPtr is nullptr. Tile[%d] RegionId[%d] .", *GetName(), Tile, RegionId);
		return false;
	}

	/*std::vector<FString> TempArrayDungeonRegionResName = FCWDungeonRegionDataUtils::GetArrayDungeonRegionResNameFromString(RegionDataPtr->ArrayRegionResId);
	if (ResNameIndex < 0 || ResNameIndex >= TempArrayDungeonRegionResName.size())
	{
		CWG_ERROR(">>> %s::ClientUpdate, Fail: ResNameIndex < 0 || ResNameIndex >= TempArrayDungeonRegionResName.size(), ResNameIndex[%d] RegionId[%d].", *GetName(), ResNameIndex, RegionId);
		return false;
	}

	const FString& TempResName = TempArrayDungeonRegionResName[ResNameIndex];
	this->LoadMesh(TempResName);*/

	return true;
}

void ACWDungeonTile::LoadMesh(const FString& MeshId)
{
	UStaticMesh* NewMesh = FCWCfgUtils::GetAssetObjectFromCfg<UStaticMesh>(this, FCWCfgKey::DecorateAsset, MeshId);
	if (nullptr == NewMesh)
	{
		UE_LOG(LogCWDungeonTile, Error, TEXT("ACWDungeonTile::LoadMesh Fail. MeshId:%s."), *MeshId);
		return;
	}
	StaticMesh->SetStaticMesh(NewMesh);
}

void ACWDungeonTile::SetOverrideMaterialIdx(const int32 InIdx)
{
	OverrideMaterialIdx = InIdx;
}

void ACWDungeonTile::SetOffsetZ(float ParamOffsetZ)
{
	OffsetZ = ParamOffsetZ;
}

float ACWDungeonTile::GetOffsetZ() const
{
	return OffsetZ;
}

void ACWDungeonTile::OnRep_RegionId()
{
	//ClientUpdate();
}

void ACWDungeonTile::OnRep_ResNameIndex()
{
	//ClientUpdate();
}

void ACWDungeonTile::OnRep_OverrideMaterialIdx()
{
	InitStaticMeshMaterial();
}

void ACWDungeonTile::OnStaticMeshChanged()
{
	if (!IsNetMode(NM_DedicatedServer))
	{
		InitStaticMeshMaterial();
	}
}

void ACWDungeonTile::OnWeatherIdxChange(ECWWeatherType InWeatherType, ECWWeatherType InOldWeatherType)
{
	if (nullptr != GridSwitchComp)
	{
		GridSwitchComp->UpdateGridMeshMaterial(InWeatherType);
	}
}

void ACWDungeonTile::InitStaticMeshMaterial()
{
	UStaticMesh* TileStaticMesh = StaticMesh->GetStaticMesh();
	const FCWDungeonRegionDataStruct* RegionData = FCWCfgUtils::GetDungeonRegionData(this, RegionId);
	if (nullptr == TileStaticMesh || nullptr == RegionData)
	{
		CWG_WARNING(">> InitStaticMeshMaterial, TileStaticMesh/RegionData is nullptr!!!");
		return;
	}

	TArray<FString> ArrayString = FCWCfgUtils::FString_To_Array_FString(RegionData->ArrayRegionCenterMaterialId);
	const FString& NewMaterialId = ArrayString.IsValidIndex(OverrideMaterialIdx) ? ArrayString[OverrideMaterialIdx] : TEXT("");
	UMaterialInstance* NewNewMaterial = FCWCfgUtils::GetAssetObjectFromCfg<UMaterialInstance>(this, FCWCfgKey::DecorateAsset, NewMaterialId);
	if (nullptr != NewNewMaterial)
	{
		if (nullptr == GridSwitchComp)
		{
			UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_GridSwitchEx);
			if (nullptr != TempleteClass)
			{
				GridSwitchComp = NewObject<UCWGridSwitchComponen>(this, TempleteClass);
				check(GridSwitchComp);
				AddOwnedComponent(GridSwitchComp);
				GridSwitchComp->RegisterComponent();
			}else
			{
				CWG_WARNING(">> InitStaticMeshMaterial, Fail!!! BP_GridSwitchEx is invalid!");
			}
		}
		if (IsValidCompnent(GridSwitchComp))
		{
			GridSwitchComp->InitGridMeshMaterial(StaticMesh, NewNewMaterial);
		}
	}else
	{
		CWG_WARNING(">> InitStaticMeshMaterial, Fail!!! NewNewMaterial is invalid! NewMaterialId[%s] OverrideMaterialIdx[%d].", *NewMaterialId, OverrideMaterialIdx);
	}
}

void ACWDungeonTile::BeginPlay()
{
	Super::BeginPlay();

	if (IsInServer())
	{
		//DoRiseInServer();
	}
	else
	{
		bIsBeginPlayInClient = true;

		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), RegionId);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWDungeonTile, Error, TEXT("ACWRandomDungeonGenerator::GenerateShow_2, TempDungeonRegionData == nullptr, RegionId:%d."), RegionId);
			return;
		}

		const FCWClientConstData* TempConstData = FCWCfgUtils::GetConstData(nullptr, FCWCfgKey::BattleConst, TEXT("IsShowTileNum"));
		if (TempConstData != nullptr)
		{
			int IsShowNum = FCString::Atoi(*TempConstData->Param);
			if (IsShowNum != 0)
			{
				if (RegionId == 4)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Green, 200.0f, 125.f);
				}
				if (RegionId == 1)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Red, 200.0f, 125.f);
				}
				if (RegionId == 7)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Red, 200.0f, 125.f);
				}
				if (RegionId == 8)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::White, 200.0f, 125.f);
				}
				if (RegionId == 6)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Purple, 200.0f, 125.f);
				}
				if (RegionId == 5)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Yellow, 200.0f, 125.f);
				}
				if (RegionId == 3)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Cyan, 200.0f, 125.f);
				}
				if (RegionId == 2)
				{
					UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(RegionId)), FColor::Blue, 200.0f, 125.f);
				}
			}
		}
		
		//UCWFuncLib::PrintTxtInfo(this, FText::FromString(FString::FromInt(TempDungeonRegionData->ZoneType)), FColor(0x267158), 70.0f, 225.f);
	}

	if (!IsNetMode(NM_DedicatedServer))
	{
		InitStaticMeshMaterial();

		ADD_EVT_DELEGATE(StaticMesh->OnCWStaticMeshChanged(), this, &ACWDungeonTile::OnStaticMeshChanged, "OnStaticMeshChanged");

		UCWEventMgr* EventMgr = EVT_MGR(this);
		if (nullptr != EventMgr)
		{
			ADD_EVT_DELEGATE(EventMgr->OnWeatherIdxChange, this, &ACWDungeonTile::OnWeatherIdxChange, "OnWeatherIdxChange");
		}
	}
}

void ACWDungeonTile::Destroyed()
{
	if (!IsNetMode(NM_DedicatedServer))
	{
		REMOVE_EVT_DELEGATE(StaticMesh->OnCWStaticMeshChanged(), this);

		UCWEventMgr* EventMgr = EVT_MGR(this);
		if (nullptr != EventMgr)
		{
			REMOVE_EVT_DELEGATE(EventMgr->OnWeatherIdxChange, this);
		}
	}

	UCWFuncLib::DestroyActorChildren(this);

	Super::Destroyed();
}

void ACWDungeonTile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	TickTime += DeltaTime;

	if (!IsInServer())
	{
		if (HasActorBegunPlay() && !bIsTriggerRise)
		{
			ACWGameState* TempGameState = GetWorld()->GetGameState<ACWGameState>();
			if (TempGameState != nullptr)
			{
				if (TempGameState->GetCurBattleState() == ECWBattleState::Dungeon)
				{
					FVector TempLocation = GetActorLocation();
					ACWRandomDungeonGenerator* TempGenerator = GetDungeonGenerator();
					if (TempGenerator != nullptr)
					{
						bool isTrigger = false;

						int32 TempGameId = GetGameId();
						FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
						check(TempGameData);
						std::vector<float> TempArrayMinMax = FCWGameDataUtils::GetArrayDungeonTileRiseRandomMinMaxFromString(TempGameData->DungeonTileRiseRandomMinMax);
						if (TempArrayMinMax.size() != 2)
						{
							return;
						}

						float RandomMin = TempArrayMinMax[0];
						float RandomMax = TempArrayMinMax[1];

						float TempRandom = RandomFloat(RandomMin, RandomMax);

						ACWDungeonItem* TempDungeonItem = TempGenerator->GetDungeonItem(this->Tile);
						if (TempGenerator->IsAllDungeonTileBeginPlayInClient() && TempGenerator->IsAllDungeonItemBeginPlayInClient() &&
							TempGenerator->IsAllDungeonTileTickTimeOKInClient() && TempGenerator->IsAllDungeonItemTickTimeOKInClient())
						{
							isTrigger = true;

							TempRandom = RandomFloat(RandomMin, RandomMax);
						}

						{
							if (isTrigger)
							{
								bIsTriggerRise = true;
								FTimerDelegate DungeonRiseCallback;
								DungeonRiseCallback.BindLambda([this]()
								{
									DoRiseInClient();

									if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
									{
										Evt_Mgr->OnLevelSiteRise.Broadcast(this);
									}
								});

								FTimerHandle DungeonRiseTimer;
								GetWorldTimerManager().SetTimer(DungeonRiseTimer, DungeonRiseCallback, 1.0f, false, TempRandom);
								ArrayTimerHandler.Add(DungeonRiseTimer);
							}
						}
					}
					
				}
			}
		}
	}


	if (IsInServer())
	{
		if (bIsDoRise)
		{
			RisingInServer(DeltaTime);
		}

		if (bIsDoFall)
		{
			FallingInServer(DeltaTime);
		}
	}
	else
	{
		if (bIsDoRise)
		{
			RisingInClient(DeltaTime);
		}

		if (bIsDoFall)
		{
			FallingInClient(DeltaTime);
		}
	}
}

ACWMap* ACWDungeonTile::GetMap()
{
	for (TActorIterator<ACWMap> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWMap* TempMap = *Iter;
		return TempMap;
	}

	return nullptr;
}

ACWRandomDungeonGenerator* ACWDungeonTile::GetDungeonGenerator()
{
	if (!DungeonGeneratorPtr.IsValid())
	{
		DungeonGeneratorPtr = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	}
	return DungeonGeneratorPtr.Get();
}

int32 ACWDungeonTile::GetGameId()
{
	if (!GameInfoPtr.IsValid())
	{
		GameInfoPtr = UCWFuncLib::GetActor<ACWGameInfo>(this);
	}
	return GameInfoPtr.IsValid() ? GameInfoPtr->GetGameId() : 0;
}

bool ACWDungeonTile::IsDoRise()
{
	return bIsDoRise;
}

bool ACWDungeonTile::IsDoRised()
{
	return bIsDoRised;
}

bool ACWDungeonTile::IsDoRiseEnd()
{
	return bIsDoRiseEnd;
}

bool ACWDungeonTile::IsBeginPlayInClient()
{
	return bIsBeginPlayInClient;
}

float ACWDungeonTile::GetTickTime()
{
	return TickTime;
}

int32 ACWDungeonTile::GetTile() const
{
	return Tile;
}

float ACWDungeonTile::RandomFloat(float min, float max)
{
	if (min > max)
	{
		UE_LOG(LogCWDungeonTile, Error, TEXT("ACWDungeonTile::RandomFloat fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(nullptr) + rand() % 60017);
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

int ACWDungeonTile::RandomInt(int min, int max)
{
	if (min > max)
	{
		UE_LOG(LogCWDungeonTile, Error, TEXT("ACWDungeonTile::RandomInt fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(nullptr) + rand() % 60017);
	std::uniform_int_distribution<int> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

void ACWDungeonTile::DoFallInServer()
{
	if (!IsInServer())
		return;
	
	bIsDoFall = true;
	bIsDoRise = false;

	NetMulticastRPCDoFall();
}

void ACWDungeonTile::NetMulticastRPCDoFall_Implementation()
{
	if (IsInServer())
		return;

	bIsDoFall = true;
	bIsDoRise = false;

	// 掉落通知
	OnBeginFallInClient.Broadcast(this);

	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		TempMap->RemoveTile(Tile);
	}
}

void ACWDungeonTile::FallingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		check(ParentDungeonGeneratorInServer);
		ParentDungeonGeneratorInServer->DestroyDungeonTileInServer(this->Tile);
	}
}

void ACWDungeonTile::FallingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
}

void ACWDungeonTile::NetMulticastRPCDoRise_Implementation()
{
	if (IsInServer())
		return;

	bIsDoRise = true;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;
}

void ACWDungeonTile::DoRiseInServer()
{
	if (!IsInServer())
		return;

	bIsDoRise = true;
	bIsDoRised = true;
	bIsDoRiseEnd = false;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;

	NetMulticastRPCDoRise();
}

void ACWDungeonTile::RisingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = CurRiseSpeed * DeltaTime;
	FVector TempLocation = GetActorLocation();
	float TempZ = TempLocation.Z + CurRiseSpeed;
	if (TempZ > OffsetZ)
	{
		TempZ = OffsetZ;

		bIsDoRise = false;
		bIsDoRiseEnd = true;
	}
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempZ);
	SetActorLocation(TempLocation);

	if (CurRiseSpeed <= 10.0f)
		CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;
}

void ACWDungeonTile::DoRiseInClient()
{
	if (IsInServer())
		return;

	bIsDoRise = true;
	bIsDoRised = true;
	bIsDoRiseEnd = false;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;
}

void ACWDungeonTile::DoRiseEndInClient()
{
	if (IsInServer())
		return;

	bIsDoRise = false;
	bIsDoRiseEnd = true;

	for (TArray<FTimerHandle>::TIterator iter = ArrayTimerHandler.CreateIterator(); iter; ++iter)
	{
		FTimerHandle TempTimerHandle = *iter;
		GetWorldTimerManager().ClearTimer(TempTimerHandle);
	}
	ArrayTimerHandler.Empty();
}

void ACWDungeonTile::RisingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	CurRiseSpeed = CurRiseSpeed * DeltaTime;
	FVector TempLocation = GetActorLocation();
	float TempZ = TempLocation.Z + CurRiseSpeed;
	if (TempZ > OffsetZ)
	{
		TempZ = OffsetZ;

		bIsDoRise = false;
		bIsDoRiseEnd = true;
	}
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempZ);
	SetActorLocation(TempLocation);

	if (CurRiseSpeed <= 10.0f)
		CurRiseSpeed = TempGameData->DungeonTileRiseBeginSpeed;

	//UE_LOG(LogCWDungeonTile, Warning, TEXT("ACWDungeonTile::RisingInClient tile:%d, Z:%f."), Tile, TempLocation.Z);

	ACWRandomDungeonGenerator* TempGenerator = GetDungeonGenerator();
	if (TempGenerator != nullptr)
	{
		ACWDungeonItem* TempDungeonItem = TempGenerator->GetDungeonItem(this->Tile);
		if (TempDungeonItem != nullptr)
		{
			TempDungeonItem->SetActorLocation(TempLocation);
		}
	}
}

bool ACWDungeonTile::IsInServer() const
{
	return Role == ROLE_Authority;
}
