﻿
#include "CWGridSwitchComponen.h"


UCWGridSwitchComponen::UCWGridSwitchComponen(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWGridSwitchComponen::~UCWGridSwitchComponen()
{
}

void UCWGridSwitchComponen::BeginPlay()
{
	Super::BeginPlay();
}

void UCWGridSwitchComponen::BeginDestroy()
{
	Super::BeginDestroy();
}

bool UCWGridSwitchComponen::UpdateGridMeshMaterial_Implementation(ECWWeatherType InWeatherType)
{
	return true;
}

bool UCWGridSwitchComponen::InitGridMeshMaterial_Implementation(UStaticMeshComponent* InStaticMeshComp, UMaterialInstance* InBaseMaterial)
{
	return true;
}
