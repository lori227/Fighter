#include "CWLogicRegion.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWPawnDataStruct.h"
#include "CWCastSkillContext.h"


FCWLogicRegion::FCWLogicRegion()
{
	Reset();
}

FCWLogicRegion::FCWLogicRegion(const FCWLogicRegion& r)
{
	*this = r;
}

FCWLogicRegion& FCWLogicRegion::operator = (const FCWLogicRegion& r)
{
	if (this == &r)
		return *this;

	this->X = r.X;
	this->Y = r.Y;
	this->XBegin = r.XBegin;
	this->YBegin = r.YBegin;
	this->XEnd = r.XEnd;
	this->YEnd = r.YEnd;
	this->bIsValid = r.bIsValid;
	this->RegionType = r.RegionType;
	return *this;
}

bool operator == (const FCWLogicRegion& l, const FCWLogicRegion& r)
{
	if (l.X == r.X &&
		l.Y == r.Y &&
		l.XBegin == r.XBegin &&
		l.YBegin == r.YBegin &&
		l.XEnd == r.XEnd &&
		l.YEnd == r.YEnd &&
		l.bIsValid == r.bIsValid &&
		l.RegionType == r.RegionType)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void FCWLogicRegion::Reset()
{
	X = 0;
	Y = 0;
	XBegin = 0;
	YBegin = 0;
	XEnd = 0;
	YEnd = 0;
	bIsValid = false;
	RegionType = ECWDungeonRegionType::None;
}

