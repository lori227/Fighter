﻿
#include "CWRandomDungeonGenerator.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneComponent.h"
  
#include <random>
#include <ctime>
#include <functional>

#include "CW2DBSHL.h"
#include "CW2DAStar.h"
#include "CWMap.h"
#include "CWComDef.h"
#include "CWMapTile.h"
#include "CWEventMgr.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWGameMode.h"
#include "CWBattleFSM.h"
#include "CWGameState.h"
#include "CWGameInfo.h"
#include "CWCfgManager.h"
#include "CWPawnStart.h"
#include "CWDungeonItem.h"
#include "CWCommonUtil.h"
#include "CWDungeonTile.h"
#include "CWCfgManager.h"
#include "CWDungeonItemGroup.h"
#include "CWRandomEventCtrl.h"
#include "CWClientConstData.h"
#include "CWGameDataStruct.h"
#include "CWAudioVideoMgr.h"
#include "CWDungeonDataUtils.h"
#include "CWPlayerController.h"
#include "CWBattleToReadyEvent.h"
#include "CWDungeonDataStruct.h"
#include "CWDungeonItemDataUtils.h"
#include "CWDungeonItemVisibility.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonItemDataStruct.h"
#include "CWDungeonRegionDataUtils.h"
#include "CWDungeonDecorateDataStruct.h"
#include "CWDungeonDecorateComponent.h"
#include "CWDungeonDecorateTile.h"
#include "CWDungeonDecorateRegion.h"
#include "CWDungeonDecorateMeshDataStruct.h"
#include "CWDungeonDecorateMeshDataUtils.h"
#include "CWAIPawn.h"
#include "Kismet/KismetMathLibrary.h"
#include "CWDungeonItemGroupData.h"
#include "StringConv.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWRandomDungeonGenerator, All, All);

ACWRandomDungeonGenerator* ACWRandomDungeonGenerator::s_this = nullptr;


ACWRandomDungeonGenerator::ACWRandomDungeonGenerator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bLevelSiteRiseBegin(false)
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	bIsInit = false;

	DungeonItemIndex = 0;
	DungeonWidth = 0;
	DungeonHeight = 0;
	offsetX = 0;
	offsetY = 0;
	LowestTileZ = 0.5f;

	IsTriggerDungeonDecorateDoRiseInClient = false;
	IsTriggerPawnDoSpawnActionInClient = false;
	IsResetPawnBeforeDoSpawnActionInClient = true;
}

void ACWRandomDungeonGenerator::BeginPlay()
{
	Super::BeginPlay();

	//if (IsInServer())
	{
		if (!IsInit())
		{
			int32 TempGameId = GetGameId();
			FCWGameDataStruct* TempGameData = LoadGameData(TempGameId);
			if (!Init(TempGameData->DungeonId))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::BeginPlay fail, Init fail, RandomDungeonId:%d."), TempGameData->DungeonId);
				return;
			}
		}
	}

	if (IsInServer())
	{

	}
	else
	{
		ResetObjectExtraOffsetZ();
		ResetDungeonDecorateBeforeRiseInClient();
		ResetPawnBeforeDoSpawnActionInClient();

		if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
		{
			ADD_EVT_DELEGATE(Evt_Mgr->OnLevelSiteRise, this, &ACWRandomDungeonGenerator::OnLevelSiteRise, FName("OnLevelSiteRise"));
			ADD_EVT_DELEGATE(Evt_Mgr->OnBattleStateChange, this, &ACWRandomDungeonGenerator::OnBattleStateChange, FName("OnBattleStateChange"));
		}
	}
}

void ACWRandomDungeonGenerator::BeginDestroy()
{
	if (!IsInServer())
	{
		if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
		{
			REMOVE_EVT_DELEGATE(Evt_Mgr->OnLevelSiteRise, this);
			REMOVE_EVT_DELEGATE(Evt_Mgr->OnBattleStateChange, this);
		}
	}

	Super::BeginDestroy();
}

void ACWRandomDungeonGenerator::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayPawnStart);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonTile);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonItemGroup);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonDecorateTile);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonGrid);
	DOREPLIFETIME(ACWRandomDungeonGenerator, DungeonWidth);
	DOREPLIFETIME(ACWRandomDungeonGenerator, DungeonHeight);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonGrid_Z);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonRegionId);
	DOREPLIFETIME(ACWRandomDungeonGenerator, ArrayDungeonRegionSpace);
	DOREPLIFETIME(ACWRandomDungeonGenerator, offsetX);
	DOREPLIFETIME(ACWRandomDungeonGenerator, offsetY); 

	DOREPLIFETIME_CONDITION(ACWRandomDungeonGenerator, ArrayTileOffsetZ, COND_InitialOnly);
}

void ACWRandomDungeonGenerator::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!IsInServer())
	{
		ACWGameState* TempGameState = GetWorld()->GetGameState<ACWGameState>();
		if (TempGameState != nullptr)
		{
			if (TempGameState->GetCurBattleState() == ECWBattleState::Dungeon &&
				IsResetPawnBeforeDoSpawnActionInClient)
			{
				ResetPawnBeforeDoSpawnActionInClient();
				IsResetPawnBeforeDoSpawnActionInClient = false;
			}
		}

		if (IsAllDungeonTileAfterRiseInClient())
		{
			if (!IsTriggerDungeonDecorateDoRiseInClient)
			{
				//DungeonDecorateDoRiseInClient();
				IsTriggerDungeonDecorateDoRiseInClient = true;
			}
		}

		if (IsAllDungeonDecorateTileBeginPlayInClient() &&
			IsTriggerDungeonDecorateDoRiseInClient &&
			!IsTriggerPawnDoSpawnActionInClient)
		{
			PawnDoSpawnActionInClient();
			RefreshAllLocationInClient();
			IsTriggerPawnDoSpawnActionInClient = true;

			APlayerController* TempPlayerController = GetWorld()->GetFirstPlayerController();
			ACWPlayerController* TempCWPlayerController = (ACWPlayerController*)TempPlayerController;
			if (TempCWPlayerController != nullptr)
			{
				TempCWPlayerController->ServerRPCDungeonEnd();
			}
		}
	}
}

void ACWRandomDungeonGenerator::Serialize(FArchive& Ar)
{
	Super::Serialize(Ar);
}

bool ACWRandomDungeonGenerator::Init(int ParamRandomDungeonId)
{
	s_this = this;

	bIsInit = true;

	RandomDungeonId = ParamRandomDungeonId;

	srand(time(NULL));
	std::default_random_engine Generator(time(NULL));

	FCWDungeonDataStruct* TempDungeonData = s_this->GetDungeonData();
	check(TempDungeonData);
	DungeonWidth = TempDungeonData->DungeonWidthExtension;
	DungeonHeight = TempDungeonData->DungeonHeightExtension;
	bshl = new BSHL2D();
	bshl->m_isValidFunc = isCanPassForRegionSplitLine;
	as1 = new AStar2D();
	as1->m_isValidFunc = isCanPassForRegionSplitLine;
	as1->m_costFunc = cost;
	as2 = new AStar2D();
	as2->m_isValidFunc = isCanPassForRegionSplitLine;
	as2->m_costFunc = cost;
	return true;
}

bool ACWRandomDungeonGenerator::IsInit()
{
	return bIsInit;
}

void ACWRandomDungeonGenerator::tile2xy(int tile, int& x, int& y)
{
	check(s_this);
	if (s_this->DungeonWidth == 0)
	{
		x = -1;
		y = -1;
		return;
	}

	x = tile % s_this->DungeonWidth;
	y = tile / s_this->DungeonWidth;
}


void ACWRandomDungeonGenerator::tile2pos(int tile, FVector& pos)
{
	int _x;
	int _y;
	tile2xy(tile, _x, _y);
	xy2pos(_x, _y, pos);
}


int ACWRandomDungeonGenerator::xy2tile(int x, int y)
{
	check(s_this);
	if (s_this->DungeonWidth == 0)
	{
		return -1;
	}

	return y * s_this->DungeonWidth + x;
}


void ACWRandomDungeonGenerator::xy2pos(int x, int y, FVector& pos)
{
	check(s_this);
	FCWDungeonDataStruct* TempDungeonData = s_this->GetDungeonData();
	if (TempDungeonData == nullptr ||
		TempDungeonData->DungeonGridWidth == 0 ||
		TempDungeonData->DungeonGridHeight == 0)
	{
		pos = FVector::ZeroVector;
		return;
	}

	//pos.X = x * s_this->m_gridWidth + s_this->m_gridWidth * 0.5f + xb;
	//pos.Y = y * s_this->m_gridHeight + s_this->m_gridHeight * 0.5f + yb;
	pos.X = x * TempDungeonData->DungeonGridWidth + TempDungeonData->DungeonOffsetX;
	pos.Y = y * TempDungeonData->DungeonGridHeight + TempDungeonData->DungeonOffsetY;
	pos.Z = 0.0f;
}


int ACWRandomDungeonGenerator::pos2tile(const FVector& pos)
{
	int _x;
	int _y;
	pos2xy(pos, _x, _y);
	return xy2tile(_x, _y);
}

void ACWRandomDungeonGenerator::pos2xy(const FVector& pos, int& x, int& y)
{
	check(s_this);
	FCWDungeonDataStruct* TempDungeonData = s_this->GetDungeonData();
	if (TempDungeonData == nullptr ||
		TempDungeonData->DungeonGridWidth == 0 ||
		TempDungeonData->DungeonGridHeight == 0)
	{
		x = -1;
		y = -1;
		return;
	}

	//float xb = -460.0f;
	//float yb = -2070.0f;

	float xb = 0.0f;
	float yb = 0.0f;

	x = (int)((pos.X - xb) / TempDungeonData->DungeonGridWidth);
	y = (int)((pos.Y - yb) / TempDungeonData->DungeonGridHeight);
}

float ACWRandomDungeonGenerator::RandomFloat(float min, float max)
{
	if (min > max)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomFloat fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(nullptr) + rand() % 60017);
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

int ACWRandomDungeonGenerator::RandomInt(int min, int max)
{
	if (min > max)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomInt fail, min > max, min:%d, max:%d."), min, max);
	}

	std::default_random_engine Generator(time(nullptr) + rand() % 60017);
	std::uniform_int_distribution<int> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

bool ACWRandomDungeonGenerator::GenerateDungeon()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	int TempDefaultDungeonRegionTopography = (int)ECWDungeonRegionTopography::FlatLand;
	int TempTotalGridCount = DungeonWidth * DungeonHeight;
	if (TempTotalGridCount <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempTotalGridCount == 0, DungeonWidth:%d, DungeonHeight:%d."), DungeonWidth, DungeonHeight);
		return false;
	}

	ArrayPawnStart.Init(nullptr, TempTotalGridCount);
	ArrayDungeonTile.Init(nullptr, TempTotalGridCount);
	ArrayDungeonDecorateTile.Init(nullptr, TempTotalGridCount);
	
	ArrayDungeonGrid.Reserve(TempTotalGridCount);
	ArrayDungeonGrid_Z.Reserve(TempTotalGridCount);
	ArrayDungeonRegionId.Reserve(TempTotalGridCount);
	ArrayDungeonRegionSpace.Reserve(TempTotalGridCount);
	ArrayDungeonItemForData.Reserve(TempTotalGridCount);
	ArrayDungeonItemObstacle.Reserve(TempTotalGridCount);
	ArrayDungeonItemGroup.Reserve(TempTotalGridCount);
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			ArrayDungeonGrid.Add(TempDefaultDungeonRegionTopography);
			ArrayDungeonGrid_Z.Add(0);
			ArrayDungeonRegionId.Add(0);
			ArrayDungeonRegionSpace.Add(ECWDungeonRegionSpace::None);

			FCWDungeonItemGroupData TempDungeonItemGroupData = FCWDungeonItemGroupData();
			TempDungeonItemGroupData.Init(this, tile);
			ArrayDungeonItemForData.Add(TempDungeonItemGroupData);
			ArrayDungeonItemObstacle.Add(0);

			FActorSpawnParameters SpawnParameters;
			SpawnParameters.Owner = this;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			ACWDungeonItemGroup* TempDungeonItemGroup = GetWorld()->SpawnActor<ACWDungeonItemGroup>(SpawnParameters);
			TempDungeonItemGroup->Init(tile);
			ArrayDungeonItemGroup.Add(TempDungeonItemGroup);
		}
	}

	if (!RandomRemoveDungeonExtension())
	{
		return false;
	}

	if (!GenerateDungeonDecorateRegion())
	{
		return false;
	}

	if (!GenerateDungeonDecorateTile())
	{
		return false;
	}

	if (!this->GeneratePawnStart())
	{
		return false;
	}

	if (!GenerateDungeonForHighLand())
	{
		return false;
	}

	if (!GenerateDungeonForLowLand())
	{
		return false;
	}

	if (!GenerateDungeonForRegion())
	{
		return false;
	}

	
	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	// 随机地块偏移
	TArray<int32> RandArray;
	FVector2D OutOffsetRange;
	TArray<float> OffsetZArray;
	const bool bGetListOk = RandomOffsetTileList(RandArray);
	const bool bGetRangeOk = RandomOffsetTileZRange(OutOffsetRange);
	if (bGetListOk && bGetRangeOk)
	{
		OffsetZArray.Init(0, TempTotalGridCount);
	}

	if (ArrayDungeonGrid.Num() != ArrayDungeonGrid_Z.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, ArrayDungeonGrid.Num() != ArrayDungeonGrid_Z.Num(), ArrayDungeonGrid.Num():%d, ArrayDungeonGrid_Z.Num():%d."), ArrayDungeonGrid.Num(), ArrayDungeonGrid_Z.Num());
		return false;
	}

	if (ArrayDungeonGrid.Num() != ArrayDungeonRegionId.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, ArrayDungeonGrid.Num() != ArrayDungeonRegionId.Num(), ArrayDungeonGrid.Num():%d, ArrayDungeonRegionId.Num():%d."), ArrayDungeonGrid.Num(), ArrayDungeonRegionId.Num());
		return false;
	}

	if (ArrayDungeonGrid.Num() != ArrayDungeonRegionSpace.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, ArrayDungeonGrid.Num() != ArrayDungeonRegionSpace.Num(), ArrayDungeonGrid.Num():%d, ArrayDungeonRegionSpace.Num():%d."), ArrayDungeonGrid.Num(), ArrayDungeonRegionSpace.Num());
		return false;
	}

	
	for (int i = 0; i < ArrayDungeonGrid.Num(); ++i)
	{
		int TempDungeonGrid = ArrayDungeonGrid[i];
		if (TempDungeonGrid <= 0)
			continue;

		int TempDungeonRegionId = ArrayDungeonRegionId[i];
		if (TempDungeonRegionId <= 0)
			continue;


		FActorSpawnParameters SpawnParameters;
		SpawnParameters.Owner = this;
		SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		ACWDungeonTile* TempDungeonTile = GetWorld()->SpawnActor<ACWDungeonTile>(SpawnParameters);
		if (nullptr != TempDungeonTile && TempDungeonTile->InitInServer(this, i, TempDungeonRegionId))
		{
			FCWDungeonRegionDataStruct* TempDungeonRegionData = GetDungeonRegionData(TempDungeonRegionId);
			if (TempDungeonRegionData == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempDungeonRegionData == nullptr, TempDungeonRegionId:%d."), TempDungeonRegionId);
				continue;
			}

			// 随机地块偏移Z轴
			float RandOffsetZ = 0.f;
			if (bGetListOk && bGetRangeOk && RandArray.Contains(i))
			{
				RandOffsetZ = FMath::RandRange((int32)OutOffsetRange.X, (int32)OutOffsetRange.Y);
				RandOffsetZ = FMath::IsNearlyZero(RandOffsetZ) ? (FMath::RandBool() ? 1 : -1) : RandOffsetZ;
				//CWG_WARNING(">> %s::GenerateDungeon, i[%d], RandOffsetZ[%f]", *GetName(), i, RandOffsetZ);
			}

			// 高低洼地的Z值处理
			int32 TempGrid_Z = ArrayDungeonGrid_Z[i];
			float OffsetZ_ByHighLandOrLowLand = TempGrid_Z * TempDungeonData->HighLandOrLowLandGridOffsetZ;
			FVector TempPos = FVector::ZeroVector;
			this->tile2pos(i, TempPos);
			const float NewOffsetZ = OffsetZ_ByHighLandOrLowLand + RandOffsetZ;
			OffsetZArray[i] = NewOffsetZ;
			TempDungeonTile->SetOffsetZ(NewOffsetZ);

			std::vector<FString> TempArrayDungeonRegionResId;
			ECWDungeonRegionSpace TempRegionSpace = ArrayDungeonRegionSpace[i];
			
			if (TempRegionSpace == ECWDungeonRegionSpace::Center)
			{
				TempArrayDungeonRegionResId = FCWDungeonRegionDataUtils::GetArrayDungeonRegionCenterResIdFromString(TempDungeonRegionData->ArrayRegionCenterResId);
			}
			if (TempRegionSpace == ECWDungeonRegionSpace::Border)
			{
				TempArrayDungeonRegionResId = FCWDungeonRegionDataUtils::GetArrayDungeonRegionCenterResIdFromString(TempDungeonRegionData->ArrayRegionBorderResId);
			}

			if (TempArrayDungeonRegionResId.size() <= 0)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempArrayDungeonRegionResId.size() <= 0, TempDungeonRegionId:%d, TempRegionSpace:%d, i:%d."), TempDungeonRegionId, (int32)TempRegionSpace, i);
				continue;
			}

			int TempDungeonRegionResNameIndex = rand() % TempArrayDungeonRegionResId.size();
			TempDungeonTile->ResNameIndex = TempDungeonRegionResNameIndex;
			const FString& TempResName = TempArrayDungeonRegionResId[TempDungeonRegionResNameIndex];
			TempDungeonTile->SetOverrideMaterialIdx(TempDungeonRegionResNameIndex);
			TempDungeonTile->LoadMesh(TempResName);
			TempDungeonTile->SetActorLocation(TempPos);
			FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, RandomDungeonItemEuler()));
			TempDungeonTile->SetActorRotation(TempQ);

			check(ArrayDungeonTile[i] == nullptr);
			ArrayDungeonTile[i] = TempDungeonTile;
		}
	}
	ArrayTileOffsetZ = OffsetZArray;


	//if (!this->GenerateDungeonWall())
	//{
	//	return false;
	//}

	if (!this->GenerateDungeonItem())
	{
		return false;
	}

	// 启用随机事件控制器
	if (!GenerateRandomEvtCtrl())
	{
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeon_2()
{
	FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), RandomDungeonId);
	if (TempDungeonData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon_2, TempDungeonData == nullptr, RandomDungeonId:%d."), RandomDungeonId);
		return false;
	}

	int TempDefaultDungeonRegionTopography = (int)ECWDungeonRegionTopography::FlatLand;
	int TempTotalGridCount = DungeonWidth * DungeonHeight;
	if (TempTotalGridCount <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempTotalGridCount == 0, DungeonWidth:%d, DungeonHeight:%d."), DungeonWidth, DungeonHeight);
		return false;
	}

	ArrayPawnStart.Init(nullptr, TempTotalGridCount);
	ArrayDungeonTile.Init(nullptr, TempTotalGridCount);
	ArrayDungeonDecorateTile.Init(nullptr, TempTotalGridCount);

	ArrayDungeonGrid.Reserve(TempTotalGridCount);
	ArrayDungeonGrid_Z.Reserve(TempTotalGridCount);
	ArrayDungeonRegionId.Reserve(TempTotalGridCount);
	ArrayDungeonRegionSpace.Reserve(TempTotalGridCount);
	ArrayDungeonItemForData.Reserve(TempTotalGridCount);
	ArrayDungeonItemObstacle.Reserve(TempTotalGridCount);
	ArrayDungeonItemGroup.Reserve(TempTotalGridCount);
	ArrayTileType.Reserve(TempTotalGridCount);
	ArrayTileGroup.Reserve(TempTotalGridCount);
	ArrayTileTileType.Reserve(TempTotalGridCount);
	ArrayTileElevation.Reserve(TempTotalGridCount);
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			ArrayDungeonGrid.Add(TempDefaultDungeonRegionTopography);
			ArrayDungeonGrid_Z.Add(0);
			ArrayDungeonRegionId.Add(0);
			ArrayDungeonRegionSpace.Add(ECWDungeonRegionSpace::None);

			FCWDungeonItemGroupData TempDungeonItemGroupData = FCWDungeonItemGroupData();
			TempDungeonItemGroupData.Init(this, tile);
			ArrayDungeonItemForData.Add(TempDungeonItemGroupData);
			ArrayDungeonItemObstacle.Add(0);

			FActorSpawnParameters SpawnParameters;
			SpawnParameters.Owner = this;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			ACWDungeonItemGroup* TempDungeonItemGroup = GetWorld()->SpawnActor<ACWDungeonItemGroup>(SpawnParameters);
			TempDungeonItemGroup->Init(tile);
			ArrayDungeonItemGroup.Add(TempDungeonItemGroup);

			ArrayTileType.Add(ECWDungeonRegionType::None);
			ArrayTileGroup.Add(-1);
			ArrayTileTileType.Add(ECWDungeonTileType::None);
			ArrayTileElevation.Add(1);
		}
	}

	std::vector<std::vector<int32> > ArrayArrayElevationHeightIncrement = FCWDungeonDataUtils::GetArrayArrayElevationHeightIncrementFromString(TempDungeonData->ElevationHeightIncrement);
	if (ArrayArrayElevationHeightIncrement.size() != 7)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, ArrayArrayElevationHeightIncrement.size() != 7, ArrayArrayElevationHeightIncrement.size():%d."), ArrayArrayElevationHeightIncrement.size());
		return false;
	}

	if (!GeneraterDangerRegionElevationMin(TempDungeonData->Style))
	{
		return false;
	}
	
	if (!GeneraterDangerRegionElevationMax(TempDungeonData->Style))
	{
		return false;
	}


	if (!GenerateLogicDungeonRegion_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateLogicPawnStartRegion_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateLogicPawnStart_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateLogicGoThroughLine_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateLogicSplitLine_2(TempDungeonData))
	{
		return false;
	}

	if (!GeneraterMapGroupZoneType(TempDungeonData))
	{
		return false;
	}

	if (!ReplaceDangerToHighSpeed(TempDungeonData))
	{
		return false;
	}

	if (!GenerateLowSpeed_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateHighSpeed_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateHighSpeedLandform_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateDangerBlockLandform_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateDangerForbidLandform_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateDangerLowSpeedLandform_2(TempDungeonData))
	{
		return false;
	}

	if (!GenerateStatistics_2(TempDungeonData))
	{
		return false;
	}

	if (!FixGlobalLowSpeed(TempDungeonData))
	{
		return false;
	}

	TArray<float> OffsetZArray;
	OffsetZArray.Init(0, TempTotalGridCount);
	for (int i = 0; i < ArrayDungeonRegionId.Num(); ++i)
	{
		int TempDungeonRegionId = ArrayDungeonRegionId[i];
		if (TempDungeonRegionId <= 0)
			continue;

		FActorSpawnParameters SpawnParameters;
		SpawnParameters.Owner = this;
		SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		ACWDungeonTile* TempDungeonTile = GetWorld()->SpawnActor<ACWDungeonTile>(SpawnParameters);
		if (nullptr != TempDungeonTile && TempDungeonTile->InitInServer(this, i, TempDungeonRegionId))
		{
			FCWDungeonRegionDataStruct* TempDungeonRegionData = GetDungeonRegionData(TempDungeonRegionId);
			if (TempDungeonRegionData == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempDungeonRegionData == nullptr, TempDungeonRegionId:%d, i:%d."), TempDungeonRegionId, i);
				continue;
			}

			if (TempDungeonRegionData->Elevation == -1)
			{
				FVector TempPos = FVector::ZeroVector;
				this->tile2pos(i, TempPos);

				int32 TempGrid_Z = ArrayDungeonGrid_Z[i];
				float OffsetZ_ByHighLandOrLowLand = TempGrid_Z * TempDungeonData->HighLandOrLowLandGridOffsetZ;
				const float NewOffsetZ = OffsetZ_ByHighLandOrLowLand;
				OffsetZArray[i] = NewOffsetZ;
				TempPos.Z = NewOffsetZ;
				//OffsetZArray[i] = TempPos.Z;

				std::vector<FString> TempArrayDungeonRegionResId = FCWDungeonRegionDataUtils::GetArrayDungeonRegionCenterResIdFromString(TempDungeonRegionData->ArrayRegionCenterResId);
				if (TempArrayDungeonRegionResId.size() <= 0)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempArrayDungeonRegionResId.size() <= 0, TempDungeonRegionId:%d, i:%d."), TempDungeonRegionId, i);
					continue;
				}

				int TempDungeonRegionResNameIndex = rand() % TempArrayDungeonRegionResId.size();
				TempDungeonTile->ResNameIndex = TempDungeonRegionResNameIndex;
				const FString& TempResName = TempArrayDungeonRegionResId[TempDungeonRegionResNameIndex];
				TempDungeonTile->SetOverrideMaterialIdx(TempDungeonRegionResNameIndex);
				TempDungeonTile->LoadMesh(TempResName);
				TempDungeonTile->SetActorLocation(TempPos);
				FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, RandomDungeonItemEuler()));
				TempDungeonTile->SetActorRotation(TempQ);
				TempDungeonTile->SetOffsetZ(TempPos.Z);

				check(ArrayDungeonTile[i] == nullptr);
				ArrayDungeonTile[i] = TempDungeonTile;
			}
			else
			{
				if (TempDungeonRegionData->Elevation < DangerRegionElevationMin || TempDungeonRegionData->Elevation > DangerRegionElevationMax)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempDungeonRegionData->Elevation < 1 || TempDungeonRegionData->Elevation > 7, Elevation:%d, i:%d."), TempDungeonRegionData->Elevation, i);
					continue;
				}

				if (ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation - 1].size() != 2)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation-1].size() != 2, Elevation:%d, i:%d, ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation-1].size():%d."), TempDungeonRegionData->Elevation, i, ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation - 1].size());
					continue;
				}

				int32 TempElevationHeightMin = ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation - 1][0];
				int32 TempElevationHeightMax = ArrayArrayElevationHeightIncrement[TempDungeonRegionData->Elevation - 1][1];
				int32 RandOffsetZ = RandomInt(TempElevationHeightMin, TempElevationHeightMax);
				FVector TempPos = FVector::ZeroVector;
				this->tile2pos(i, TempPos);

				int32 TempGrid_Z = ArrayDungeonGrid_Z[i];
				float OffsetZ_ByHighLandOrLowLand = TempGrid_Z * TempDungeonData->HighLandOrLowLandGridOffsetZ;
				const float NewOffsetZ = OffsetZ_ByHighLandOrLowLand + RandOffsetZ;
				OffsetZArray[i] = NewOffsetZ;
				TempPos.Z = NewOffsetZ;
				//OffsetZArray[i] = TempPos.Z;

				std::vector<FString> TempArrayDungeonRegionResId = FCWDungeonRegionDataUtils::GetArrayDungeonRegionCenterResIdFromString(TempDungeonRegionData->ArrayRegionCenterResId);
				if (TempArrayDungeonRegionResId.size() <= 0)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeon, TempArrayDungeonRegionResId.size() <= 0, TempDungeonRegionId:%d, i:%d."), TempDungeonRegionId, i);
					continue;
				}

				int TempDungeonRegionResNameIndex = rand() % TempArrayDungeonRegionResId.size();
				TempDungeonTile->ResNameIndex = TempDungeonRegionResNameIndex;
				const FString& TempResName = TempArrayDungeonRegionResId[TempDungeonRegionResNameIndex];
				TempDungeonTile->SetOverrideMaterialIdx(TempDungeonRegionResNameIndex);
				TempDungeonTile->LoadMesh(TempResName);
				TempDungeonTile->SetActorLocation(TempPos);
				FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, RandomDungeonItemEuler()));
				TempDungeonTile->SetActorRotation(TempQ);
				TempDungeonTile->SetOffsetZ(TempPos.Z);

				check(ArrayDungeonTile[i] == nullptr);
				ArrayDungeonTile[i] = TempDungeonTile;
			}
		}
	}
	ArrayTileOffsetZ = OffsetZArray;



	//if (!this->GenerateDungeonWall())
	//{
	//	return false;
	//}

	if (!this->GenerateDungeonItem())
	{
		return false;
	}

	// 启用随机事件控制器
	if (!GenerateRandomEvtCtrl())
	{
		return false;
	}

	if (!GenerateShow_2(TempDungeonData))
	{

	}

	if (!GeneratePawnStart_2())
	{
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayDungeonZoneNumFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}
	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];

	if (TempLogicWidthNum > DungeonWidth)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, TempLogicWidthNum > DungeonWidth, TempLogicWidthNum:%d, DungeonWidth:%d."), TempLogicWidthNum, DungeonWidth);
		return false;
	}

	if (TempLogicHeightNum > DungeonHeight)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, TempLogicHeightNum > DungeonHeight, TempLogicHeightNum:%d, DungeonHeight:%d."), TempLogicHeightNum, DungeonHeight);
		return false;
	}

	LogicWidthNum = TempLogicWidthNum;
	LogicHeightNum = TempLogicHeightNum;

	int32 iw = DungeonWidth / TempLogicWidthNum;
	int32 ih = DungeonHeight / TempLogicHeightNum;
	int32 yw = DungeonWidth % TempLogicWidthNum;
	int32 yh = DungeonHeight % TempLogicHeightNum;
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, DungeonWidth:%d, DungeonHeight:%d, TempLogicWidthNum:%d, TempLogicHeightNum:%d, iw:%d, ih:%d, yw:%d, yh:%d."), DungeonWidth, DungeonHeight, TempLogicWidthNum, TempLogicHeightNum, iw, ih, yw, yh);

	as1->setColumnNum(TempLogicWidthNum > TempLogicHeightNum ? TempLogicWidthNum + 1 : TempLogicHeightNum + 1);
	as2->setColumnNum(TempLogicWidthNum > TempLogicHeightNum ? TempLogicWidthNum + 1 : TempLogicHeightNum + 1);

	int32 remain_yw = yw;
	int32 remain_yh = yh;
	int index = 0;
	FCWLogicRegion TempLogicRegion;
	for (int x = 0; x < TempLogicWidthNum; ++x)
	{
		std::map<int32, FCWLogicRegion> TempMapLogicRegionInner;
		TempMapLogicRegionInner.insert(std::map<int32, FCWLogicRegion>::value_type(x, TempLogicRegion));
		for (int y = 0; y < TempLogicHeightNum; ++y)
		{
			MapLogicRegion.insert(std::map<int32, std::map<int32, FCWLogicRegion>>::value_type(x, TempMapLogicRegionInner));
			MapLogicRegion[x][y].X = x;
			MapLogicRegion[x][y].Y = y;
			MapLogicRegion[x][y].XBegin = x * iw;
			MapLogicRegion[x][y].YBegin = y * ih;

			MapLogicRegion[x][y].XEnd = (x + 1) * iw - 1 >= DungeonWidth ? DungeonWidth - 1 : (x + 1) * iw - 1;
			MapLogicRegion[x][y].YEnd = (y + 1) * ih - 1 >= DungeonHeight ? DungeonHeight - 1 : (y + 1) * ih - 1;
			MapLogicRegion[x][y].bIsValid = true;
		}
	}

	for (int x = 0; x < TempLogicWidthNum; ++x)
	{
		MapLogicRegion[x][TempLogicHeightNum - 1].YEnd += remain_yh;
	}

	for (int y = 0; y < TempLogicHeightNum; ++y)
	{
		MapLogicRegion[TempLogicWidthNum-1][y].XEnd += remain_yw;
	}
	
	for (int x = 0; x < TempLogicWidthNum; ++x)
	{
		for (int y = 0; y < TempLogicHeightNum; ++y)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, bIsValid == true, X:%d, Y:%d, XBegin:%d, XEnd:%d, YBegin:%d, YEnd:%d."), x, y, MapLogicRegion[x][y].XBegin, MapLogicRegion[x][y].XEnd, MapLogicRegion[x][y].YBegin, MapLogicRegion[x][y].YEnd);
		}
	}
	

	for (int x = -1; x <= TempLogicWidthNum; ++x)
	{
		if (x >= 0 && x < TempLogicWidthNum)
			continue;

		std::map<int32, FCWLogicRegion> TempMapLogicRegionInner;
		TempMapLogicRegionInner.insert(std::map<int32, FCWLogicRegion>::value_type(x, TempLogicRegion));
		for (int y = -1; y <= TempLogicHeightNum; ++y)
		{
			if (y >= 0 && y < TempLogicHeightNum)
				continue;

			MapLogicRegion.insert(std::map<int32, std::map<int32, FCWLogicRegion>>::value_type(x, TempMapLogicRegionInner));
			MapLogicRegion[x][y].X = x;
			MapLogicRegion[x][y].Y = y;
			MapLogicRegion[x][y].bIsValid = false;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, bIsValid == false, X:%d, Y:%d."), x, y);
		}
	}

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicDungeonRegion_2, TempLogicWidthNum:%d, TempLogicHeightNum:%d."), TempLogicWidthNum, TempLogicHeightNum);
	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayDungeonZoneNumFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}

	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];
	if (TempLogicWidthNum <= 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, TempLogicWidthNum <= 1, TempLogicWidthNum:%d."), TempLogicWidthNum);
		return false;
	}

	if (TempLogicHeightNum <= 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, TempLogicHeightNum <= 1, TempLogicHeightNum:%d."), TempLogicHeightNum);
		return false;
	}

	int32 iy = rand() % TempLogicHeightNum;
	//int32 iy = 1;
	
	SpawnRegionRightX = 0;
	SpawnRegionRightY = iy;
	SpawnRegionLeftX = TempLogicWidthNum - 1;
	SpawnRegionLeftY = TempLogicHeightNum - iy - 1 < 0 ? 0 : TempLogicHeightNum - iy - 1;

	if (!MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].bIsValid)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, !MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].bIsValid, SpawnRegionRightX:%d, SpawnRegionRightY:%d."), SpawnRegionRightX, SpawnRegionRightY);
		return false;
	}
	
	if (!MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].bIsValid)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, !MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].bIsValid, SpawnRegionLeftX:%d, SpawnRegionLeftY:%d."), SpawnRegionLeftX, SpawnRegionLeftY);
		return false;
	}

	while (MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].RegionType == ECWDungeonRegionType::Forbid ||
		MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].RegionType == ECWDungeonRegionType::Forbid)
	{
		int32 iy = rand() % TempLogicHeightNum;

		SpawnRegionRightX = 0;
		SpawnRegionRightY = iy;
		SpawnRegionLeftX = TempLogicWidthNum - 1;
		SpawnRegionLeftY = TempLogicHeightNum - iy - 1 < 0 ? 0 : TempLogicHeightNum - iy - 1;

		if (!MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, while !MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].bIsValid, SpawnRegionRightX:%d, SpawnRegionRightY:%d."), SpawnRegionRightX, SpawnRegionRightY);
			return false;
		}

		if (!MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, while !MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].bIsValid, SpawnRegionLeftX:%d, SpawnRegionLeftY:%d."), SpawnRegionLeftX, SpawnRegionLeftY);
			return false;
		}
	}

	MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY].RegionType = ECWDungeonRegionType::SpawnStart;
	MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY].RegionType = ECWDungeonRegionType::SpawnStart;


	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStartRegion_2, SpawnRegionRightX:%d, SpawnRegionRightY:%d, SpawnRegionLeftX:%d, SpawnRegionLeftY:%d."), SpawnRegionRightX, SpawnRegionRightY, SpawnRegionLeftX, SpawnRegionLeftY);
	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicPawnStart_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	int32 GenerateAIdx = 1, GenerateBIdx = 1;
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayDungeonZoneNumFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}
	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];

	int32 RandomIdx = RandomInt(0, 2);
	PawnStartRandomIdx = RandomIdx;
	if (RandomIdx >= TempDungeonData->ACampPawnStart.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, RandomIdx >= TempDungeonData->ACampPawnStart.Num(), RandomIdx:%d, ACampPawnStart.Num():%d."), RandomIdx, TempDungeonData->ACampPawnStart.Num());
		return false;
	}

	if (RandomIdx >= TempDungeonData->BCampPawnStart.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, RandomIdx >= TempDungeonData->BCampPawnStart.Num(), RandomIdx:%d, BCampPawnStart.Num():%d."), RandomIdx, TempDungeonData->BCampPawnStart.Num());
		return false;
	}
	//--------------------------------------------------------------------------------------------------------------
	std::map<int32, std::map<int32, FCWLogicRegion>>::iterator iterFind1 = MapLogicRegion.find(SpawnRegionRightX);
	if (iterFind1 == MapLogicRegion.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, iterFind1 == MapLogicRegion.end(), SpawnRegionRightX:%d."), SpawnRegionRightX);
		return false;
	}
	std::map<int32, FCWLogicRegion>::iterator iterFind2 = iterFind1->second.find(SpawnRegionRightY);
	if (iterFind2 == iterFind1->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, iterFind2 == iterFind1->second.end(), SpawnRegionRightY:%d."), SpawnRegionRightY);
		return false;
	}

	FCWLogicRegion TempRightLogicRegion = iterFind2->second;
	if (!TempRightLogicRegion.bIsValid)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, !TempRightLogicRegion.bIsValid, SpawnRegionRightX:%d, SpawnRegionRightY:%d."), SpawnRegionRightX, SpawnRegionRightY);
		return false;
	}
	//--------------------------------------------------------------------------------------------------------------
	std::map<int32, std::map<int32, FCWLogicRegion>>::iterator iterFind3 = MapLogicRegion.find(SpawnRegionLeftX);
	if (iterFind3 == MapLogicRegion.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, iterFind3 == MapLogicRegion.end(), SpawnRegionLeftX:%d."), SpawnRegionLeftX);
		return false;
	}
	std::map<int32, FCWLogicRegion>::iterator iterFind4 = iterFind3->second.find(SpawnRegionLeftY);
	if (iterFind4 == iterFind3->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, iterFind4 == iterFind1->second.end(), SpawnRegionLeftY:%d."), SpawnRegionLeftY);
		return false;
	}

	FCWLogicRegion TempLeftLogicRegion = iterFind4->second;
	if (!TempLeftLogicRegion.bIsValid)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, !TempLeftLogicRegion.bIsValid, SpawnRegionLeftX:%d, SpawnRegionLeftY:%d."), SpawnRegionLeftX, SpawnRegionLeftY);
		return false;
	}
	//--------------------------------------------------------------------------------------------------------------
	std::vector<std::vector<int32> > ACampPawnStart = FCWDungeonDataUtils::GetArrayArrayDungeonPawnStartFromString(TempDungeonData->ACampPawnStart[RandomIdx]);
	std::vector<std::vector<int32> > BCampPawnStart = FCWDungeonDataUtils::GetArrayArrayDungeonPawnStartFromString(TempDungeonData->BCampPawnStart[RandomIdx]);
	for (std::vector<std::vector<int32> >::iterator iter = ACampPawnStart.begin(); iter != ACampPawnStart.end(); ++iter)
	{
		if (iter->size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, ACampPawnStart, iter->size() != 2, RandomIdx:%d, iter->size():%d."), RandomIdx, iter->size());
			return false;
		}
		int32 x = iter->at(0);
		int32 y = iter->at(1);
		x = TempRightLogicRegion.XBegin + x;
		y = (SpawnRegionRightY > TempLogicHeightNum / 2) ? TempRightLogicRegion.YEnd - 0 - y : TempRightLogicRegion.YBegin + y;
		x += offsetX;
		y += offsetY;
		int tile = this->xy2tile(x, y);
		if (!ArrayTileType.IsValidIndex(tile))
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, Right !ArrayTileType.IsValidIndex(tile), x:%d, y:%d, tile:%d."), x, y, tile);
			continue;
		}

		ArrayTileType[tile] = ECWDungeonRegionType::SpawnStart;
		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2 1 ArrayTileType[tile] = ECWDungeonTileType::SpawnStart. x:%d, y:%d, tile:%d."), x, y, tile);
		MapPawnStart.Add(tile, FPawnStartData(ECWCampTag::A, ECWCampControllerIndex::One, 0, GenerateAIdx++, -90.f));
	}

	for (std::vector<std::vector<int32> >::iterator iter = BCampPawnStart.begin(); iter != BCampPawnStart.end(); ++iter)
	{
		if (iter->size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, BCampPawnStart, iter->size() != 2, RandomIdx:%d, iter->size():%d."), RandomIdx, iter->size());
			return false;
		}
		int32 x = iter->at(0);
		int32 y = iter->at(1);
		x = TempLeftLogicRegion.XEnd - 0 - x;
		y = (SpawnRegionLeftY > TempLogicHeightNum / 2) ? TempLeftLogicRegion.YEnd - 0 - y : TempLeftLogicRegion.YBegin + y;
		int tile = this->xy2tile(x, y);
		if (!ArrayTileType.IsValidIndex(tile))
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2, Left !ArrayTileType.IsValidIndex(tile), x:%d, y:%d, tile:%d."), x, y, tile);
			continue;
		}
		ArrayTileType[tile] = ECWDungeonRegionType::SpawnStart;
		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2 2 ArrayTileType[tile] = ECWDungeonTileType::SpawnStart. x:%d, y:%d, tile:%d."), x, y, tile);
		MapPawnStart.Add(tile, FPawnStartData(ECWCampTag::B, ECWCampControllerIndex::One, 0, GenerateBIdx++, 90.f));
	}

	FCWLogicRegion TempRightRegionForSpawnStart = MapLogicRegion[SpawnRegionRightX][SpawnRegionRightY];
	FCWLogicRegion TempLeftRegionForSpawnStart = MapLogicRegion[SpawnRegionLeftX][SpawnRegionLeftY];
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			if (((x >= TempRightRegionForSpawnStart.XBegin && x <= TempRightRegionForSpawnStart.XEnd) &&
				(y >= TempRightRegionForSpawnStart.YBegin && y <= TempRightRegionForSpawnStart.YEnd)) ||
				((x >= TempLeftRegionForSpawnStart.XBegin && x <= TempLeftRegionForSpawnStart.XEnd) &&
				(y >= TempLeftRegionForSpawnStart.YBegin && y <= TempLeftRegionForSpawnStart.YEnd)))
			{
				if (ArrayTileType[tile] != ECWDungeonRegionType::SpawnStart)
				{
					ArrayTileType[tile] = ECWDungeonRegionType::HighSpeed;
					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicPawnStart_2 2 ArrayTileType[tile] = ECWDungeonTileType::HighSpeed. x:%d, y:%d, tile:%d."), x, y, tile);
				}
			}
		}
	}
	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicSplitLine_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLine_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}

	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];

	std::vector<int32> TempArrayNumOfSplitLine = FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(TempDungeonData->NumOfSplitLine);
	if (TempArrayNumOfSplitLine.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLine_2, TempArrayNumOfSplitLine.size() != 2, TempArrayNumOfSplitLine.size():%d."), TempArrayNumOfSplitLine.size());
		return false;
	}

	int32 TempSplitLineNumMin = TempArrayNumOfSplitLine[0];
	int32 TempSplitLineNumMax = TempArrayNumOfSplitLine[1];
	int32 TempSplitLineNum = RandomInt(TempSplitLineNumMin, TempSplitLineNumMax);
	//int32 TempSplitLineNum = 3;
	std::vector<std::vector<std::vector<int32>>> TempArrayArrayArrayNumOfSplitLine = FCWDungeonDataUtils::GetArrayArrayArraySplitLineFromString(TempDungeonData->ArraySplitLine);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLine_2, TempSplitLineNumMin:%d, TempSplitLineNumMax:%d, TempSplitLineNum:%d, TempArrayArrayArrayNumOfSplitLine.size():%d."), TempSplitLineNumMin, TempSplitLineNumMax, TempSplitLineNum, TempArrayArrayArrayNumOfSplitLine.size());


	int TempSuccessNum = 0;
	for (int i = 0; i < TempArrayArrayArrayNumOfSplitLine.size(); ++i)
	{
		if (GenerateLogicSplitLineHelp_2(TempDungeonData, i))
		{
			TempSuccessNum++;
		}

		if (TempSuccessNum >= TempSplitLineNum)
			break;
	}

	
	FixLogicDangerBlock(TempDungeonData);
	FixLogicForbidLine(TempDungeonData);

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicGoThroughLine_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLine_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}

	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];

	std::vector<int32> TempArrayNumOfPathLine = FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(TempDungeonData->NumOfPathLine);
	if (TempArrayNumOfPathLine.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLine_2, TempArrayNumOfPathLine.size() != 2, TempArrayNumOfPathLine.size():%d."), TempArrayNumOfPathLine.size());
		return false;
	}

	int32 TempPathLineNumMin = TempArrayNumOfPathLine[0];
	int32 TempPathLineNumMax = TempArrayNumOfPathLine[1];
	int32 TempPathLineNum = RandomInt(TempPathLineNumMin, TempPathLineNumMax);
	//int32 TempPathLineNum = TempPathLineNumMax;

	int32 TempHighRoadIndex = rand() % TempPathLineNum;
	//int32 TempHighRoadIndex = -1;
	HighRoadIndex = TempHighRoadIndex;
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLine_2, TempPathLineNumMin:%d, TempPathLineNumMax:%d, TempPathLineNum:%d, TempHighRoadIndex:%d."), TempPathLineNumMin, TempPathLineNumMax, TempPathLineNum, TempHighRoadIndex);

	for (int i = 0; i < TempPathLineNum; ++i)
	{
		GenerateLogicGoThroughLineHelp_2(TempDungeonData, i, TempPathLineNum, TempHighRoadIndex);
	}

	FixLogicGoThroughLine(TempDungeonData);

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLowSpeed_2(FCWDungeonDataStruct* TempDungeonData)
{
	int _cx;
	int _cy;
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile1 = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile1))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			if (TempRegionType1 == ECWDungeonRegionType::DangerBlock ||
				TempRegionType1 == ECWDungeonRegionType::Danger ||
				TempRegionType1 == ECWDungeonRegionType::HighSpeed ||
				TempRegionType1 == ECWDungeonRegionType::Forbid)
			{
				for (int i = -1; i < 2; ++i)
				{
					for (int j = -1; j < 2; ++j)
					{
						_cx = x + i;
						_cy = y + j;
						if (i == 0 && j == 0)	//是否有效
						{
							continue;
						}

						
						if ((i == -1 && j == -1) ||
							(i == 1 && j == -1) ||
							(i == -1 && j == 1) ||
							(i == 1 && j == 1))
						{
							int tile2 = this->xy2tile(_cx, _cy);
							if (!ArrayTileType.IsValidIndex(tile2))
								continue;

							ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
							if (TempRegionType2 == ECWDungeonRegionType::None)
							{
								ArrayTileType[tile2] = ECWDungeonRegionType::LowSpeed;

								UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLowSpeed_2, x:%d, y:%d, tile2:%d."), x, y, tile2);
							}
							else
							{
								//UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLowSpeed_2, x:%d, y:%d, tile2:%d, TempRegionType2:%d."), x, y, tile2, (int)TempRegionType2);
							}
						}
					}
				}
			}
		}
	}

	FixLogicLowSpeedLine(TempDungeonData);

	return true;
}

bool ACWRandomDungeonGenerator::GenerateHighSpeed_2(FCWDungeonDataStruct* TempDungeonData)
{
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile1 = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile1))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			if (TempRegionType1 == ECWDungeonRegionType::None)
			{
				ArrayTileType[tile1] = ECWDungeonRegionType::LowSpeed;

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateHighSpeed_2  LowSpeed, x:%d, y:%d, tile1:%d."), x, y, tile1);
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::FixGlobalLowSpeed(FCWDungeonDataStruct* TempDungeonData)
{

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			int32 TempRegionId = ArrayDungeonRegionId[tile];
			ECWDungeonRegionType TempDungeonRegionType = ArrayTileType[tile];
			bool TempAdjacentSameRegionId = false;
			if (TempDungeonRegionType == ECWDungeonRegionType::LowSpeed)
			{
				int TempRegionTileIdCountMin = 99999999;
				int tileMin = -1;

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FixGlobalLowSpeed  LowSpeed, x:%d, y:%d, tile:%d."), x, y, tile);

				for (int i = -1; i < 2; ++i)
				{
					for (int j = -1; j < 2; ++j)
					{
						int _cx = x + i;
						int _cy = y + j;
						if (i == 0 && j == 0)	//是否有效
						{
							continue;
						}

						if ((i == -1 && j == -1) ||
							(i == 1 && j == -1) ||
							(i == -1 && j == 1) ||
							(i == 1 && j == 1))
						{
							continue;
						}

						int tile2 = this->xy2tile(_cx, _cy);
						if (!ArrayTileType.IsValidIndex(tile2))
							continue;

						int32 TempRegionId2 = ArrayDungeonRegionId[tile2];
						int32 TempRegionIdCount = MapRegionTileCount[TempRegionId2];
						if (TempRegionIdCount < TempRegionTileIdCountMin)
						{
							TempRegionTileIdCountMin = TempRegionIdCount;
							tileMin = tile2;
						}

						if (TempRegionId == TempRegionId2)
						{
							TempAdjacentSameRegionId = true;
						}
					}
				}

				if (!TempAdjacentSameRegionId && tileMin != -1)
				{
					ArrayDungeonRegionId[tile] = ArrayDungeonRegionId[tileMin];
					ArrayTileGroup[tile] = ArrayTileGroup[tileMin];
					ArrayTileElevation[tile] = ArrayTileElevation[tileMin];
					ArrayTileType[tile] = ArrayTileType[tileMin];
					ArrayDungeonGrid_Z[tile] = ArrayDungeonGrid_Z[tileMin];

					MapRegionTileCount[TempRegionId]++;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FixGlobalLowSpeed  LowSpeed, x:%d, y:%d, tile:%d, tileMin:%d."), x, y, tile, tileMin);
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateStatistics_2(FCWDungeonDataStruct* TempDungeonData)
{
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			int32 TempRegionId = ArrayDungeonRegionId[tile];
			MapRegionTileCount.insert(std::map<int32, int32>::value_type(TempRegionId, 0));
		}
	}

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			int32 TempRegionId = ArrayDungeonRegionId[tile];
			int32 TempGrid_Z = ArrayDungeonGrid_Z[tile];
			ECWDungeonTileType TempTileTileType = ArrayTileTileType[tile];
			ECWDungeonRegionType TempTileType = ArrayTileType[tile];
			int32 TempTileGroup = ArrayTileGroup[tile];
			int32 TempElevation = ArrayTileElevation[tile];

			MapRegionTileCount[TempRegionId]++;
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateStatistics_2, x:%d, y:%d, tile:%d, TempRegionId:%d, TempGrid_Z:%d, TempTileTileType:%d, TempTileType:%d, TempTileGroup:%d, TempElevation:%d."), x, y, tile, TempRegionId, TempGrid_Z, (int)TempTileTileType, (int)TempTileType, (int)TempTileGroup, TempElevation);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateShow_2(FCWDungeonDataStruct* TempDungeonData)
{
	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			int32 TempRegionId = ArrayDungeonRegionId[tile];
			int32 TempGrid_Z = ArrayDungeonGrid_Z[tile];
			ECWDungeonTileType TempTileTileType = ArrayTileTileType[tile];
			ECWDungeonRegionType TempTileType = ArrayTileType[tile];
			int32 TempTileGroup = ArrayTileGroup[tile];
			int32 TempElevation = ArrayTileElevation[tile];
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateShow_2, x:%d, y:%d, tile:%d, TempRegionId:%d, TempGrid_Z:%d, TempTileTileType:%d, TempTileType:%d, TempTileGroup:%d, TempElevation:%d."), x, y, tile, TempRegionId, TempGrid_Z, (int)TempTileTileType, (int)TempTileType, (int)TempTileGroup, TempElevation);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GeneratePawnStart_2()
{
	ACWMap* TempMap = GetMap();
	check(TempMap);
	UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_CWPawnStart);
	check(TempleteClass);

	// 读取常量配置表出生组数据(覆盖)
	TArray<int32> NewPawnIdArray;
	const FString& PawnStartIdKey = FString::Printf(TEXT("StartPawnIdGroup%d"), PawnStartRandomIdx);
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, PawnStartIdKey))
	{
		NewPawnIdArray = FCWCfgUtils::FString_To_Array_Int32(ConstData->Param);
	}

	// 生成棋子出生点
	TArray<ACWPawnStart*> NewPawnStartList;
	NewPawnStartList.Init(nullptr, ArrayPawnStart.Num());
	for (const auto& SpawnData : MapPawnStart)
	{
		TempMap->setMapTileAttribute(SpawnData.Key, (uint8)ECWDungeonTileAttribute::PawnStart);
		FVector TempPos = FVector::ZeroVector;
		this->tile2pos(SpawnData.Key, TempPos);
		ACWPawnStart* TempPawnStart = GetWorld()->SpawnActor<ACWPawnStart>(TempleteClass, TempPos, FRotator(0.0f, SpawnData.Value.PawnYaw, 0.0f));
		if (TempPawnStart != nullptr)
		{
			// 优先读取配置表出生数据(PawnId)
			const int32 NewIdx = SpawnData.Value.PawnIdx;
			const int32 NewId = NewPawnIdArray.IsValidIndex(NewIdx - 1) ? NewPawnIdArray[NewIdx - 1] : SpawnData.Value.PawnId;

			TempPawnStart->Tile = SpawnData.Key;
			TempPawnStart->CampTag = SpawnData.Value.CampTag;
			TempPawnStart->CampControllerIndex = SpawnData.Value.CampIdx;
			TempPawnStart->PawnIndex = NewIdx;
			TempPawnStart->PawnId = NewId;

			int32 TempX = 0, TempY = 0;
			this->tile2xy(TempPawnStart->Tile, TempX, TempY);
			TempPawnStart->X = TempX;
			TempPawnStart->Y = TempY;

			NewPawnStartList[SpawnData.Key] = TempPawnStart;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT(">> SpawnData.Key:%d, x:%d, y:%d, TempPos.X:%f, TempPos.Y:%f."),
				SpawnData.Key, TempPawnStart->X, TempPawnStart->Y, TempPos.X, TempPos.Y);
		}
	}
	ArrayPawnStart = NewPawnStartList;
	return true;
}

bool ACWRandomDungeonGenerator::GenerateHighSpeedLandform_2(FCWDungeonDataStruct* TempDungeonData)
{
	//ZoneType为地貌归属区域类型，-1=禁行区域, 0=高速区域，1=慢速区域，2=危险区域
	int32 ParamOutDungeonRegionId;
	std::vector<int32> ParamExclusive;
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, 0, ParamExclusive, ParamOutDungeonRegionId))
	{
		return false;
	}

	FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamOutDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateHighSpeedLandform_2, TempDungeonRegionData == nullptr ParamOutDungeonRegionId:%d."), ParamOutDungeonRegionId);
		return false;
	}
	
	for (int i = 0; i < ArrayTileType.Num(); ++i)
	{
		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		if (TempRegionType == ECWDungeonRegionType::HighSpeed ||
			TempRegionType == ECWDungeonRegionType::SpawnStart)
		{
			ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
			ArrayTileElevation[i] = TempDungeonRegionData->Elevation;

			int x = 0;
			int y = 0;
			tile2xy(i, x, y);
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateHighSpeedLandform_2, x:%d, y:%d, i:%d, DungeonRegionId:%d, Elevation:%d."), x, y, i, ArrayDungeonRegionId[i], ArrayTileElevation[i]);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::RandomDungeonRegionFromZoneType(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamZoneType, const std::vector<int32>& ParamExclusive, int32& ParamOutDungeonRegionId)
{
	ParamOutDungeonRegionId = -1;
	std::vector<int> TempArrayDungeonRegionData;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomDungeonRegionFromZoneType, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		if (TempDungeonRegionData->Style == ParamDungeonStyle)
		{
			if (TempDungeonRegionData->ZoneType == ParamZoneType)
			{
				bool isFind = false;
				for (int j = 0; j < ParamExclusive.size(); ++j)
				{
					int32 ExclusiveDungeonRegionId = ParamExclusive[j];
					if (ExclusiveDungeonRegionId == i)
					{
						isFind = true;
						break;
					}
				}

				if (!isFind)
				{
					TempArrayDungeonRegionData.push_back(i);
				}
			}
		}
	}

	if (TempArrayDungeonRegionData.size() <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GetZoneTypeFromRandom, TempArrayDungeonRegionData.size() <= 0, TempArrayDungeonRegionData.size():%d."), TempArrayDungeonRegionData.size());
		return false;
	}

	int32 index = rand() % TempArrayDungeonRegionData.size();
	int TempId = TempArrayDungeonRegionData[index];
	FCWDungeonRegionDataStruct* TempFinalDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempId);
	if (TempFinalDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomDungeonRegionFromZoneType, TempFinalDungeonRegionData == nullptr TempId:%d."), TempId);
		return false;
	}
	ParamOutDungeonRegionId = TempFinalDungeonRegionData->DungeonRegionId;
	return true;
}

bool ACWRandomDungeonGenerator::GeneraterMapGroupZoneType(FCWDungeonDataStruct* TempDungeonData)
{
	//ZoneType为地貌归属区域类型，-1=禁行区域, 0=高速区域，1=慢速区域，2=危险区域
	int32 ParamOutDungeonRegionId1;
	std::vector<int32> ParamExclusive;
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, 2, ParamExclusive, ParamOutDungeonRegionId1))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, RandomDungeonRegionFromZoneType fail, 2 1."));
		return false;
	}

	int32 ParamOutDungeonRegionId2 = -1;
	ParamExclusive.push_back(ParamOutDungeonRegionId1);
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, 2, ParamExclusive, ParamOutDungeonRegionId2))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, RandomDungeonRegionFromZoneType fail, 2 2."));
		return false;
	}

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, ParamOutDungeonRegionId1:%d, ParamOutDungeonRegionId2:%d."), ParamOutDungeonRegionId1, ParamOutDungeonRegionId2);


	if (ArrayTileType.Num() != ArrayTileGroup.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, ArrayTileType.Num() != ArrayTileGroup.Num(), ArrayTileType.Num():%d, ArrayTileGroup.Num():%d."), ArrayTileType.Num(), ArrayTileGroup.Num());
		return false;
	}

	bool isUsedDungeonRegionId1 = false;
	bool isUsedDungeonRegionId2 = false;
	MapGroupZoneType.clear();
	for (int i = 0; i < ArrayTileGroup.Num(); ++i)
	{
		int32 TempGroup = ArrayTileGroup[i];
		if (TempGroup >= 0)
		{
			std::map<int32, int32>::iterator iterFind = MapGroupZoneType.find(TempGroup);
			if (iterFind == MapGroupZoneType.end())
			{
				if (!isUsedDungeonRegionId1)
				{
					MapGroupZoneType.insert(std::map<int32, int32>::value_type(TempGroup, ParamOutDungeonRegionId1));
					isUsedDungeonRegionId1 = true;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, MapGroupZoneType.find(TempGroup) 1, TempGroup:%d, i:%d, ParamOutDungeonRegionId1:%d."), TempGroup, i, ParamOutDungeonRegionId1);
				}
				else if (!isUsedDungeonRegionId2)
				{
					MapGroupZoneType.insert(std::map<int32, int32>::value_type(TempGroup, ParamOutDungeonRegionId2));
					isUsedDungeonRegionId2 = true;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GeneraterMapGroupZoneType, MapGroupZoneType.find(TempGroup) 2, TempGroup:%d, i:%d, ParamOutDungeonRegionId1:%d."), TempGroup, i, ParamOutDungeonRegionId1);
				}
			}
		}
		else
		{
			//UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, TempRegionType == ECWDungeonRegionType::DangerBlock && TempGroup >= 0 fail,  TempRegionType:%d, TempGroup:%d, i:%d."), (int)TempRegionType, TempGroup, i);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2(FCWDungeonDataStruct* TempDungeonData)
{
	//ZoneType为地貌归属区域类型，-1=禁行区域, 0=高速区域，1=慢速区域，2=危险区域
	int32 ParamOutDungeonRegionId1;
	std::vector<int32> ParamExclusive;
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, 2, ParamExclusive, ParamOutDungeonRegionId1))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, RandomDungeonRegionFromZoneType fail, 2 1."));
		return false;
	}

	int32 ParamOutDungeonRegionId2 = -1;
	ParamExclusive.push_back(ParamOutDungeonRegionId1);
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, 2, ParamExclusive, ParamOutDungeonRegionId2))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, RandomDungeonRegionFromZoneType fail, 2 2."));
		return false;
	}

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, ParamOutDungeonRegionId1:%d, ParamOutDungeonRegionId2:%d."), ParamOutDungeonRegionId1, ParamOutDungeonRegionId2);


	if (ArrayTileType.Num() != ArrayTileGroup.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, ArrayTileType.Num() != ArrayTileGroup.Num(), ArrayTileType.Num():%d, ArrayTileGroup.Num():%d."), ArrayTileType.Num(), ArrayTileGroup.Num());
		return false;
	}

	bool isUsedDungeonRegionId1 = false;
	bool isUsedDungeonRegionId2 = false;
	int32 TempDungeonRegionId = -1;
	for (int i = 0; i < ArrayTileType.Num(); ++i)
	{
		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		int32 TempGroup = ArrayTileGroup[i];
		if ((TempRegionType == ECWDungeonRegionType::DangerBlock || TempRegionType == ECWDungeonRegionType::Danger) && TempGroup >= 0)
		{
			std::map<int32, int32>::iterator iterFind = MapGroupZoneType.find(TempGroup);
			if (iterFind == MapGroupZoneType.end())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, MapGroupZoneType.find(TempGroup) 1, TempGroup:%d, i:%d."), TempGroup, i);
				continue;
			}
			else
			{ 
				//UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, MapGroupZoneType.find(TempGroup) fail, TempGroup:%d, i:%d."), TempGroup, i);
				//continue;

				TempDungeonRegionId = iterFind->second;

				MapGroupZoneType.insert(std::map<int32, int32>::value_type(TempGroup, TempDungeonRegionId));
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, MapGroupZoneType.find(TempGroup) 2, TempGroup:%d, i:%d."), TempGroup, i);
			}

			FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempDungeonRegionId);
			if (TempDungeonRegionData == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, TempDungeonRegionData == nullptr TempDungeonRegionId:%d."), TempDungeonRegionId);
				continue;
			}

			ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
			ArrayTileElevation[i] = TempDungeonRegionData->Elevation;

			int x = 0;
			int y = 0;
			tile2xy(i, x, y);
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, x:%d, y:%d, i:%d, DungeonRegionId:%d, Elevation:%d."), x, y, i, ArrayDungeonRegionId[i], ArrayTileElevation[i]);
		}
		else
		{
			//UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, TempRegionType == ECWDungeonRegionType::DangerBlock && TempGroup >= 0 fail,  TempRegionType:%d, TempGroup:%d, i:%d."), (int)TempRegionType, TempGroup, i);
		}

		/*if (TempRegionType == ECWDungeonRegionType::DangerBlock || TempRegionType == ECWDungeonRegionType::Danger)
		{
			FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamOutDungeonRegionId1);
			if (TempDungeonRegionData == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, TempDungeonRegionData == nullptr ParamOutDungeonRegionId1:%d."), ParamOutDungeonRegionId1);
				continue;
			}

			ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
			ArrayDungeonGrid_Z[i] = TempDungeonRegionData->Elevation;
		}*/
	}

	for (std::map<int32, int32>::iterator iter = MapGroupZoneType.begin(); iter != MapGroupZoneType.end(); ++iter)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerBlockLandform_2, iter->first:%d, iter->second:%d."), iter->first, iter->second);
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDangerForbidLandform_2(FCWDungeonDataStruct* TempDungeonData)
{
	//ZoneType为地貌归属区域类型，-1=禁行区域, 0=高速区域，1=慢速区域，2=危险区域
	int32 ParamOutDungeonRegionId;
	std::vector<int32> ParamExclusive;
	if (!RandomDungeonRegionFromZoneType(TempDungeonData->Style, -1, ParamExclusive, ParamOutDungeonRegionId))
	{
		return false;
	}

	FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamOutDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerForbidLandform_2, TempDungeonRegionData == nullptr ParamOutDungeonRegionId:%d."), ParamOutDungeonRegionId);
		return false;
	}

	for (int i = 0; i < ArrayTileType.Num(); ++i)
	{
		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		if (TempRegionType == ECWDungeonRegionType::Forbid)
		{
			ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
			ArrayTileElevation[i] = TempDungeonRegionData->Elevation;
			ArrayDungeonGrid[i] = (int)ECWDungeonRegionTopography::LowLand;
			ArrayDungeonGrid_Z[i] = -1;

			int x = 0;
			int y = 0;
			tile2xy(i, x, y);
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerForbidLandform_2, x:%d, y:%d, i:%d, DungeonRegionId:%d, Elevation:%d."), x, y, i, ArrayDungeonRegionId[i], ArrayTileElevation[i]);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	for (int i = 0; i < ArrayTileType.Num(); ++i)
	{
		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		int32 TempGroup = ArrayTileGroup[i];
		if (TempRegionType == ECWDungeonRegionType::LowSpeed)
		{
			int x = 0;
			int y = 0;
			tile2xy(i, x, y);

			int32 elevationStart = 0;
			int32 elevationEnd = 0;
			std::vector<FIntPoint> arrayStart;
			std::vector<FIntPoint> arrayEnd;
			int32 start = 0;
			int32 end = 0;
			if (FindShortest(x, y, elevationStart, elevationEnd, arrayStart, arrayEnd, start, end))
			{
				float e = 0.0f;
				if (arrayStart.empty())
				{
					e = DangerRegionElevationMax + 1.0f * ((float)(elevationEnd - DangerRegionElevationMax) / (float)(arrayEnd.size() + 1));
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, arrayStart.empty(), sxValid eeValid, x:%d, y:%d, i:%d, elevationStart:%d, elevationEnd:%d, start:%d, end:%d."), x, y, i, elevationStart, elevationEnd, start, end);
				}

				if (arrayEnd.empty())
				{
					e = elevationStart + (float)arrayStart.size() * ((float)(DangerRegionElevationMax - elevationStart) / (float)(1.0f + arrayStart.size()));
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, arrayEnd.empty(), sxValid eeValid, x:%d, y:%d, i:%d, elevationStart:%d, elevationEnd:%d, start:%d, end:%d."), x, y, i, elevationStart, elevationEnd, start, end);
				}

				bool sxValid = true;
				FIntPoint se = arrayStart.at(arrayStart.size()-1);
				if (se.X < 0 || se.X >= this->DungeonWidth || se.Y < 0 || se.Y >= this->DungeonHeight)
				{
					sxValid = false;
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, arrayEnd.empty(), sxValid eeValid, x:%d, y:%d, i:%d, elevationStart:%d, elevationEnd:%d, start:%d, end:%d, se.X:%d, se.Y:%d."), x, y, i, elevationStart, elevationEnd, start, end, se.X, se.Y);
				}

				bool eeValid = true;
				FIntPoint ee = arrayEnd.at(arrayEnd.size() - 1);
				if (ee.X < 0 || ee.X >= this->DungeonWidth || ee.Y < 0 || ee.Y >= this->DungeonHeight)
				{
					eeValid = false;
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, arrayEnd.empty(), sxValid eeValid, x:%d, y:%d, i:%d, elevationStart:%d, elevationEnd:%d, start:%d, end:%d, ee.X:%d, ee.Y:%d."), x, y, i, elevationStart, elevationEnd, start, end, ee.X, ee.Y);
				}

				bool isInterim = true;
				if (sxValid && eeValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2 1, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, elevationEnd:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d, arrayStart.size():%d, arrayEnd.size():%d, start:%d, end:%d."), x, y, i, sxValid, eeValid, elevationStart, elevationEnd, DangerRegionElevationMin, DangerRegionElevationMax, arrayStart.size(), arrayEnd.size(), start, end);
					e = elevationStart + (float)arrayStart.size() * ((float)(elevationEnd - elevationStart) / (float)(arrayEnd.size() + arrayStart.size()));
					/*if (elevationStart != elevationEnd)
					{
						e = elevationStart + (((float)(elevationEnd - elevationStart) * (float)arrayStart.size()) / (float)(arrayEnd.size() + arrayStart.size()));
					}
					else if (elevationStart == elevationEnd)
					{*/
						//if (elevationEnd == DangerRegionElevationMin)
						//{
						//	//公式1
						//	e = elevationEnd + GetR(TempDungeonData) * (1.0f - (float)FMath::Abs((float)arrayEnd.size() - (float)arrayEnd.size()) / (float)(arrayStart.size() + arrayEnd.size()));
						//}
						//else if (elevationEnd == DangerRegionElevationMax)
						//{
						//	//公式2
						//	e = elevationEnd - GetR(TempDungeonData) * (1.0f - (float)FMath::Abs((float)arrayEnd.size() - (float)arrayEnd.size()) / (float)(arrayStart.size() + arrayEnd.size()));
						//}
						//else
						//{
						//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d."), x, y, i, sxValid, eeValid, elevationStart, DangerRegionElevationMin, DangerRegionElevationMax);
						//	e = 4;
						//	isInterim = false;
						//}
						/*}
						else
						{
							UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d."), x, y, i, sxValid, eeValid, elevationStart, DangerRegionElevationMin, DangerRegionElevationMax);
							e = 4;
							isInterim = false;
						}*/
				}
				else if (!sxValid && eeValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2 2, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, elevationEnd:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d, arrayStart.size():%d, arrayEnd.size():%d, start:%d, end:%d."), x, y, i, sxValid, eeValid, elevationStart, elevationEnd, DangerRegionElevationMin, DangerRegionElevationMax, arrayStart.size(), arrayEnd.size(), start, end);
					e = this->DangerRegionElevationMax + (float)arrayStart.size() * ((float)(elevationEnd - this->DangerRegionElevationMax) / (float)(arrayEnd.size() + arrayStart.size()));
					
					//e = 7 + (float)arrayStart.size() * ((float)(elevationEnd - 7) / (float)(arrayEnd.size() + arrayStart.size()));
					//if (elevationEnd == DangerRegionElevationMin)
					//{
					//	//公式1
					//	e = elevationEnd + GetR(TempDungeonData) * (1.0f - (float)arrayEnd.size() / (float)(arrayStart.size() + arrayEnd.size()));
					//}
					//else if (elevationEnd == DangerRegionElevationMax)
					//{
					//	//公式2
					//	e = elevationEnd - GetR(TempDungeonData) * (1.0f - (float)arrayEnd.size() / (float)(arrayStart.size() + arrayEnd.size()));
					//}
					//else
					//{
					//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d."), x, y, i, sxValid, eeValid, elevationStart, DangerRegionElevationMin, DangerRegionElevationMax);
					//	e = 4;
					//	isInterim = false;
					//}
				}
				else if (sxValid && !eeValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2 3, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, elevationEnd:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d, arrayStart.size():%d, arrayEnd.size():%d, start:%d, end:%d."), x, y, i, sxValid, eeValid, elevationStart, elevationEnd, DangerRegionElevationMin, DangerRegionElevationMax, arrayStart.size(), arrayEnd.size(), start, end);
					e = elevationStart + (float)arrayStart.size() * ((float)(this->DangerRegionElevationMax - elevationStart) / (float)(arrayEnd.size() + arrayStart.size()));
					//e = elevationStart + (float)arrayStart.size() * ((float)(7 - elevationStart) / (float)(arrayEnd.size() + arrayStart.size()));
					//if (elevationStart == DangerRegionElevationMin)
					//{
					//	//公式1
					//	e = elevationStart + GetR(TempDungeonData) * (1.0f - (float)arrayStart.size()/(float)(arrayStart.size()+ arrayEnd.size()));
					//}
					//else if (elevationStart == DangerRegionElevationMax)
					//{
					//	//公式2
					//	e = elevationStart - GetR(TempDungeonData) * (1.0f - (float)arrayStart.size() / (float)(arrayStart.size() + arrayEnd.size()));
					//}
					//else
					//{
					//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d."), x, y, i, sxValid, eeValid, elevationStart, DangerRegionElevationMin, DangerRegionElevationMax);
					//	e = 4;
					//	isInterim = false;
					//}
				}
				else
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2 4, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, elevationStart:%d, elevationEnd:%d, DangerRegionElevationMin:%d, DangerRegionElevationMax:%d, arrayStart.size():%d, arrayStart.size():%d, start:%d, end:%d."), x, y, i, sxValid, eeValid, elevationStart, elevationEnd, DangerRegionElevationMin, DangerRegionElevationMax, arrayStart.size(), arrayEnd.size(), start, end);
					
					if (arrayEnd.size() + arrayStart.size() == 0)
					{
						e = elevationStart + (float)arrayStart.size() * ((float)(elevationEnd - elevationStart) / (float)(arrayEnd.size() + arrayStart.size() + 1));
					}
					else
					{
						e = elevationStart + (float)arrayStart.size() * ((float)(elevationEnd - elevationStart) / (float)(arrayEnd.size() + arrayStart.size()));
					}
					//continue;
					//e = elevationStart * (float)(arrayStart.size()) - elevationEnd * (float)(arrayStart.size()) / (float)(arrayEnd.size() - arrayStart.size());
					//e = 4;
					//isInterim = false;
				}
				
				int ie = (int)(e + 0.5f);
				if (isInterim)
				{
					if (ie < 2)
						ie = 2;
					if (ie == 4)
						ie = 3;
					if (ie > 6)
						ie = 6; 
				}

				//ZoneType为地貌归属区域类型，-1=禁行区域, 0=高速区域，1=慢速区域，2=危险区域
				int32 ParamOutDungeonRegionId;
				std::vector<int32> ParamExclusive;
				if (!RandomDungeonRegionFromElevation(TempDungeonData->Style, ie, ParamExclusive, ParamOutDungeonRegionId))
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, RandomDungeonRegionFromElevation, x:%d, y:%d, i:%d, sxValid:%d, eeValid:%d, ie:%d."), x, y, i, sxValid, eeValid, ie);
					continue;
				}

				FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamOutDungeonRegionId);
				if (TempDungeonRegionData == nullptr)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, TempDungeonRegionData == nullptr ParamOutDungeonRegionId:%d."), ParamOutDungeonRegionId);
					continue;
				}

				ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
				ArrayTileElevation[i] = TempDungeonRegionData->Elevation;
				//----------------------------------------------------------------------
				if (ArrayDungeonGrid[i] == (int)ECWDungeonRegionTopography::LowLand)
				{
					std::vector<int32> TempArrayRegionHeightMinMax = FCWDungeonRegionDataUtils::GetArrayRegionHeightMinMaxFromString(TempDungeonRegionData->ArrayRegionHeightMinMax);
					if (TempArrayRegionHeightMinMax.size() != 2)
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, TempArrayRegionHeightMinMax.size() != 2, TempArrayRegionHeightMinMax.size():%d, DungeonRegionId:%d."), TempArrayRegionHeightMinMax.size(), TempDungeonRegionData->DungeonRegionId);
						continue;
					}
					int32 TempHeightMin = TempArrayRegionHeightMinMax[0];
					int32 TempHeightMax = TempArrayRegionHeightMinMax[1];
					int32 CurrZ = ArrayDungeonGrid_Z[i];
					if (CurrZ < TempHeightMin && TempHeightMin >= 0)
					{
						ArrayDungeonGrid_Z[i] = 0;
						ArrayDungeonGrid[i] = (int)ECWDungeonRegionTopography::FlatLand;
					}
					else
					{
						ArrayDungeonGrid_Z[i] = -1;
					}
				}

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, x:%d, y:%d, i:%d, DungeonRegionId:%d, Elevation:%d."), x, y, i, ArrayDungeonRegionId[i], ArrayTileElevation[i]);
			}
			else
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, FindShortest(x, y, elevationStart, elevationEnd, arrayStart, arrayEnd), x:%d, y:%d."), x, y);
				continue;
			}
		}
	}

	/*for (int i = 0; i < ArrayTileType.Num(); ++i)
	{
		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		int32 TempGroup = ArrayTileGroup[i];
		if (TempRegionType == ECWDungeonRegionType::LowSpeed)
		{
			int x = 0;
			int y = 0;
			tile2xy(i, x, y);

			int32 ParamOutDungeonRegionId;
			std::vector<int32> ParamExclusive;
			if (!RandomDungeonRegionFromElevation(2, ParamExclusive, ParamOutDungeonRegionId))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, RandomDungeonRegionFromElevation, x:%d, y:%d, i:%d."), x, y, i);
				continue;
			}

			FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamOutDungeonRegionId);
			if (TempDungeonRegionData == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDangerLowSpeedLandform_2, TempDungeonRegionData == nullptr ParamOutDungeonRegionId:%d."), ParamOutDungeonRegionId);
				continue;
			}

			ArrayDungeonRegionId[i] = TempDungeonRegionData->DungeonRegionId;
			ArrayDungeonGrid_Z[i] = TempDungeonRegionData->Elevation;
		}

	}*/
	return true;
}

///查找离目标点最近的非障碍点
bool ACWRandomDungeonGenerator::FindShortest(
	int32 ParamX,
	int32 ParamY,
	int32& ParamElevationStart,
	int32& ParamElevationEnd,
	std::vector<FIntPoint>& ParamArrayStart,
	std::vector<FIntPoint>& ParamArrayEnd,
	int32& ParamS,
	int32& ParamE)
{
	ParamElevationStart = 0;
	ParamElevationEnd = 0;
	ParamArrayStart.clear();
	ParamArrayEnd.clear();

	if (ParamX < 0)
	{
		return false;
	}
	if (ParamX >= this->DungeonWidth)
	{
		return false;
	}
	if (ParamY < 0)
	{
		return false;
	}
	if (ParamY >= this->DungeonHeight)
	{
		return false;
	}

	int32 dx = ParamX;
	int32 dy = ParamY;

	int32 ndx = 0;
	int32 ndy = 0;

	int32 _step = 1;

	bool isNeed0 = true;
	bool isFind0 = false;
	std::vector<FIntPoint> a0;
	int32 elevation0 = 0;

	bool isNeed1 = true;
	bool isFind1 = false;
	std::vector<FIntPoint> a1;
	int32 elevation1 = 0;

	bool isNeed2 = true;
	bool isFind2 = false;
	std::vector<FIntPoint> a2;
	int32 elevation2 = 0;

	bool isNeed3 = true;
	bool isFind3 = false;
	std::vector<FIntPoint> a3;
	int32 elevation3 = 0;

	bool isNeed4 = true;
	bool isFind4 = false;
	std::vector<FIntPoint> a4;
	int32 elevation4 = 0;

	bool isNeed5 = true;
	bool isFind5 = false;
	std::vector<FIntPoint> a5;
	int32 elevation5 = 0;

	bool isNeed6 = true;
	bool isFind6 = false;
	std::vector<FIntPoint> a6;
	int32 elevation6 = 0;

	bool isNeed7 = true;
	bool isFind7 = false;
	std::vector<FIntPoint> a7;
	int32 elevation7 = 0;

	for (;;)
	{
		for (int dir = 0; dir < 8; ++dir)
		{
			switch (dir)
			{
			case 0:
			{
				if (!isNeed0 || isFind0)
					continue;

				ndx = dx;
				ndy = dy - _step;

				a0.push_back(FIntPoint(ndx, ndy));
				if (ndy >= 0)
				{
					elevation0 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind0 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind0 = true;
						break;
					}
				}
				else //ndy < 0
				{
					isNeed0 = false;
					ndy = 0;
					elevation0 = 7;
				}
			}
			break;
			case 1:
			{
				if (!isNeed1 || isFind1)
					continue;

				ndx = dx + _step;
				ndy = dy - _step;

				a1.push_back(FIntPoint(ndx, ndy));
				if (ndx < DungeonWidth && ndy >= 0)
				{
					elevation1 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind1 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind1 = true;	
						break;
					}
				}
				else
				{
					isNeed1 = false;
					if (ndx >= DungeonWidth)
						ndx = DungeonWidth - 1;

					if (ndy < 0)
						ndy = 0;

					elevation1 = 7;
				}
			}
			break;
			case 2:
			{
				if (!isNeed2 || isFind2)
					continue;

				ndx = dx + _step;
				ndy = dy;

				a2.push_back(FIntPoint(ndx, ndy));
				if (ndx < DungeonWidth)
				{
					elevation2 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind2 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind2 = true;	
						break;
					}
				}
				else//ndx >= DungeonWidth
				{
					isNeed2 = false;
					ndx = DungeonWidth - 1;
					elevation2 = 7;
				}
			}
			break;
			case 3:
			{
				if (!isNeed3 || isFind3)
					continue;

				ndx = dx + _step;
				ndy = dy + _step;

				a3.push_back(FIntPoint(ndx, ndy));
				if (ndx < DungeonWidth && ndy < DungeonHeight)
				{
					elevation3 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind3 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind3 = true;
						break;
					}
				}
				else
				{
					isNeed3 = false;
					if (ndx >= DungeonWidth)
						ndx = DungeonWidth - 1;

					if (ndy >= DungeonHeight)
						ndy = DungeonHeight - 1;

					elevation3 = 7;
				}
			}
			break;
			case 4:
			{
				if (!isNeed4 || isFind4)
					continue;

				ndx = dx;
				ndy = dy + _step;

				a4.push_back(FIntPoint(ndx, ndy));
				if (ndy < DungeonHeight)
				{
					elevation4 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind4 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind4 = true;
						break;
					}
				}
				else//ndy >= DungeonHeight
				{
					isNeed4 = false;
					ndy = DungeonHeight - 1;
					elevation4 = 7;
				}
			}
			break;
			case 5:
			{
				if (!isNeed5 || isFind5)
					continue;

				ndx = dx - _step;
				ndy = dy + _step;

				a5.push_back(FIntPoint(ndx, ndy));
				if (ndx >= 0 && ndy < DungeonHeight)
				{
					elevation5 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind5 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind5 = true;
						break;
					}
				}
				else
				{
					isNeed5 = false;
					if (ndx < 0)
						ndx = 0;

					if (ndy >= DungeonHeight)
						ndy = DungeonHeight - 1;

					elevation5 = 7;
				}
			}
			break;
			case 6:
			{
				if (!isNeed6 || isFind6)
					continue;

				ndx = dx - _step;
				ndy = dy;

				a6.push_back(FIntPoint(ndx, ndy));
				if (ndx >= 0)
				{
					elevation6 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind6 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind6 = true;
						break;
					}
				}
				else //ndx < 0
				{
					isNeed6 = false;
					ndx = 0;
					elevation6 = 7;
				}
			}
			break;
			case 7:
			{
				if (!isNeed7 || isFind7)
					continue;

				ndx = dx - _step;
				ndy = dy - _step;

				a7.push_back(FIntPoint(ndx, ndy));
				if (ndx >= 0 && ndy >= 0)
				{
					elevation7 = GetElevation(ndx, ndy);

					//if (canPass(ndx, ndy))
					if (!isFind7 && IsGoThroughLineOrDangerBlock(ndx, ndy) == 1)
					{
						isFind7 = true;
						break;
					}
				}
				else
				{
					isNeed7 = false;
					if (ndx < 0)
						ndx = 0;

					if (ndy < 0)
						ndy = 0;

					elevation7 = 7;
				}
			}
			break;
			default:
				
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("dir = %d, oh, it's impossible!"), dir);
				break;
			}
		}

		//向外一圈找
		_step++;

		if (_step > this->DungeonWidth && _step > this->DungeonHeight)
		{
			break;
		}
	}

	int32 length04 = a0.size() + a4.size();
	int32 length15 = a1.size() + a5.size();
	int32 length26 = a2.size() + a6.size();
	int32 length37 = a3.size() + a7.size();

	std::vector<int32> TempArrayLength;
	TempArrayLength.push_back(length04);
	TempArrayLength.push_back(length15);
	TempArrayLength.push_back(length26);
	TempArrayLength.push_back(length37);

	int32 TempMinLength = length04;
	int32 TempMinLengthIndex = 0;
	for (int i = 1; i < TempArrayLength.size(); ++i)
	{
		int32 TempLength = TempArrayLength[i];
		if (TempLength < TempMinLength)
		{
			TempMinLength = TempLength;
			TempMinLengthIndex = i;
		}
	}
	{
		switch(TempMinLengthIndex)
		{
		case 0:
			ParamArrayStart = a0;
			ParamArrayEnd = a4;
			ParamElevationStart = elevation0;
			ParamElevationEnd = elevation4;
			ParamS = 0;
			ParamE = 4;
			break;
		case 1:
			ParamArrayStart = a1;
			ParamArrayEnd = a5;
			ParamElevationStart = elevation1;
			ParamElevationEnd = elevation5;
			ParamS = 1;
			ParamE = 5;
			break;
		case 2:
			ParamArrayStart = a2;
			ParamArrayEnd = a6;
			ParamElevationStart = elevation2;
			ParamElevationEnd = elevation6;
			ParamS = 2;
			ParamE = 6;
			break;
		case 3:
			ParamArrayStart = a3;
			ParamArrayEnd = a7;
			ParamElevationStart = elevation3;
			ParamElevationEnd = elevation7;
			ParamS = 1;
			ParamE = 7;
			break;
		default:
			return false;
			break;
		}
	}

	return true;
}

int32 ACWRandomDungeonGenerator::IsGoThroughLineOrDangerBlock(int32 ParamX, int32 ParamY)
{
	int32 TempTile = xy2tile(ParamX, ParamY);
	if (!ArrayTileType.IsValidIndex(TempTile))
	{
		return -1;
	}

	if (!ArrayTileTileType.IsValidIndex(TempTile))
	{
		return -1;
	}

	ECWDungeonRegionType TempTileType = ArrayTileType[TempTile];
	ECWDungeonTileType TempTileTileType = ArrayTileTileType[TempTile];
	if (TempTileType == ECWDungeonRegionType::DangerBlock ||
		TempTileTileType == ECWDungeonTileType::GoThroughLine)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int32 ACWRandomDungeonGenerator::GetElevation(int32 ParamX, int32 ParamY)
{
	int32 TempTile = xy2tile(ParamX, ParamY);
	if (!ArrayTileElevation.IsValidIndex(TempTile))
	{
		return -1;
	}

	if (ArrayTileTileType[TempTile] == ECWDungeonTileType::GoThroughLine)
	{
		int32 TempGroup = ArrayTileGroup[TempTile];
		std::map<int32, int32>::iterator iterFind = MapGroupZoneType.find(TempGroup);
		if (iterFind == MapGroupZoneType.end())
		{
			return 4;
		}
		int32 TempDungeonRegionId = MapGroupZoneType[TempGroup];
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempDungeonRegionId);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GetElevation, TempDungeonRegionData == nullptr TempDungeonRegionId:%d."), TempDungeonRegionId);
			return 4;
		}
		return TempDungeonRegionData->Elevation;
	}
	else
	{
		return ArrayTileElevation[TempTile];
	}
}

bool ACWRandomDungeonGenerator::RandomDungeonRegionFromElevation(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamElevation, const std::vector<int32>& ParamExclusive, int32& ParamOutDungeonRegionId)
{
	ParamOutDungeonRegionId = -1;
	std::vector<int> TempArrayDungeonRegionData;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomDungeonRegionFromElevation, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		if (TempDungeonRegionData->Style == ParamDungeonStyle || TempDungeonRegionData->Style == ECWDungeonRegionStyle::Common)
		{
			if (TempDungeonRegionData->Elevation == ParamElevation)
			{
				bool isFind = false;
				for (int j = 0; j < ParamExclusive.size(); ++j)
				{
					int32 ExclusiveDungeonRegionId = ParamExclusive[j];
					if (ExclusiveDungeonRegionId == i)
					{
						isFind = true;
						break;
					}
				}

				if (!isFind)
				{
					TempArrayDungeonRegionData.push_back(i);
				}
			}
		}
	}

	if (TempArrayDungeonRegionData.size() <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomDungeonRegionFromElevation, TempArrayDungeonRegionData.size() <= 0, TempArrayDungeonRegionData.size():%d."), TempArrayDungeonRegionData.size());
		return false;
	}

	int32 index = rand() % TempArrayDungeonRegionData.size();
	int TempId = TempArrayDungeonRegionData[index];
	FCWDungeonRegionDataStruct* TempFinalDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempId);
	if (TempFinalDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomDungeonRegionFromElevation, TempFinalDungeonRegionData == nullptr TempId:%d."), TempId);
		return false;
	}
	ParamOutDungeonRegionId = TempFinalDungeonRegionData->DungeonRegionId;
	return true;
}

int32 ACWRandomDungeonGenerator::GetR(FCWDungeonDataStruct* TempDungeonData)
{
	check(TempDungeonData);
	ECWDungeonRegionStyle TempDungeonStyle = TempDungeonData->Style;
	int TempR = (DangerRegionElevationMax - GetLandformCount(TempDungeonStyle, 2) - GetLandformCount(TempDungeonStyle, 0)) / 2;
	return TempR;
}

int32 ACWRandomDungeonGenerator::GetLandformCount(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamRegionZoneType)
{
	int32 TempDangerLandformCount = 0;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));
	
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForFlatLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ParamDungeonStyle && TempDungeonRegionData->ZoneType == ParamRegionZoneType)
		{
			TempDangerLandformCount++;
		}
	}

	return TempDangerLandformCount;
}

bool ACWRandomDungeonGenerator::GeneraterHighRegionElevation(ECWDungeonRegionStyle ParamDungeonStyle)
{
	std::vector<int> TempArrayDungeonRegionData;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterHighRegionElevation, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		if (TempDungeonRegionData->Style == ParamDungeonStyle)
		{
			if (TempDungeonRegionData->ZoneType == 0)
			{
				/*bool isFind = false;
				for (int j = 0; j < ParamExclusive.size(); ++j)
				{
					int32 ExclusiveDungeonRegionId = ParamExclusive[j];
					if (ExclusiveDungeonRegionId == i)
					{
						isFind = true;
						break;
					}
				}

				if (!isFind)*/
				{
					TempArrayDungeonRegionData.push_back(i);
				}
			}
		}
	}

	if (TempArrayDungeonRegionData.size() <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterHighRegionElevation, TempArrayDungeonRegionData.size() <= 0, TempArrayDungeonRegionData.size():%d."), TempArrayDungeonRegionData.size());
		return false;
	}

	DangerRegionElevationMin = 99999999;
	for (int i = 0; i < TempArrayDungeonRegionData.size(); ++i)
	{
		int TempId = TempArrayDungeonRegionData[i];
		FCWDungeonRegionDataStruct* TempFinalDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempId);
		if (TempFinalDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMin, TempFinalDungeonRegionData == nullptr TempId:%d."), TempId);
			continue;
		}
		if (TempFinalDungeonRegionData->Elevation < DangerRegionElevationMin)
		{
			DangerRegionElevationMin = TempFinalDungeonRegionData->Elevation;
		}
	}
	return true;
}

bool ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMin(ECWDungeonRegionStyle ParamDungeonStyle)
{
	std::vector<int> TempArrayDungeonRegionData;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMin, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		if (TempDungeonRegionData->Style == ParamDungeonStyle)
		{
			if (TempDungeonRegionData->ZoneType == 2)
			{
				/*bool isFind = false;
				for (int j = 0; j < ParamExclusive.size(); ++j)
				{
					int32 ExclusiveDungeonRegionId = ParamExclusive[j];
					if (ExclusiveDungeonRegionId == i)
					{
						isFind = true;
						break;
					}
				}

				if (!isFind)*/
				{
					TempArrayDungeonRegionData.push_back(i);
				}
			}
		}
	}

	if (TempArrayDungeonRegionData.size() <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMin, TempArrayDungeonRegionData.size() <= 0, TempArrayDungeonRegionData.size():%d."), TempArrayDungeonRegionData.size());
		return false;
	}

	DangerRegionElevationMin = 99999999;
	for (int i = 0; i < TempArrayDungeonRegionData.size(); ++i)
	{
		int TempId = TempArrayDungeonRegionData[i];
		FCWDungeonRegionDataStruct* TempFinalDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempId);
		if (TempFinalDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMin, TempFinalDungeonRegionData == nullptr TempId:%d."), TempId);
			continue;
		}
		if (TempFinalDungeonRegionData->Elevation < DangerRegionElevationMin)
		{
			DangerRegionElevationMin = TempFinalDungeonRegionData->Elevation;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMax(ECWDungeonRegionStyle ParamDungeonStyle)
{
	std::vector<int> TempArrayDungeonRegionData;
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMax, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		if (TempDungeonRegionData->Style == ParamDungeonStyle)
		{
			if (TempDungeonRegionData->ZoneType == 2)
			{
				/*bool isFind = false;
				for (int j = 0; j < ParamExclusive.size(); ++j)
				{
					int32 ExclusiveDungeonRegionId = ParamExclusive[j];
					if (ExclusiveDungeonRegionId == i)
					{
						isFind = true;
						break;
					}
				}

				if (!isFind)*/
				{
					TempArrayDungeonRegionData.push_back(i);
				}
			}
		}
	}

	if (TempArrayDungeonRegionData.size() <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMax, TempArrayDungeonRegionData.size() <= 0, TempArrayDungeonRegionData.size():%d."), TempArrayDungeonRegionData.size());
		return false;
	}

	DangerRegionElevationMax = -99999999;
	for (int i = 0; i < TempArrayDungeonRegionData.size(); ++i)
	{
		int TempId = TempArrayDungeonRegionData[i];
		FCWDungeonRegionDataStruct* TempFinalDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempId);
		if (TempFinalDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneraterDangerRegionElevationMax, TempFinalDungeonRegionData == nullptr TempId:%d."), TempId);
			continue;
		}
		if (TempFinalDungeonRegionData->Elevation > DangerRegionElevationMax)
		{
			DangerRegionElevationMax = TempFinalDungeonRegionData->Elevation;
		}
	}

	return true;
}


bool ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2(FCWDungeonDataStruct* TempDungeonData, int32 ParamIndex)
{
	std::vector<std::vector<std::vector<int32>>> TempArrayArrayArrayNumOfSplitLine = FCWDungeonDataUtils::GetArrayArrayArraySplitLineFromString(TempDungeonData->ArraySplitLine);
	if (ParamIndex >= TempArrayArrayArrayNumOfSplitLine.size())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, ParamIndex >= TempArrayArrayArrayNumOfSplitLine.size(), ParamIndex:%d, TempArrayArrayArrayNumOfSplitLine.size():%d."), ParamIndex, TempArrayArrayArrayNumOfSplitLine.size());
		return false;
	}

	std::vector<std::vector<int32>> TempArrayArrayNumOfSplitLine = TempArrayArrayArrayNumOfSplitLine[ParamIndex];
	if (TempArrayArrayNumOfSplitLine.size() < 3)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, TempArrayArrayNumOfSplitLine.size() < 2, TempArrayArrayNumOfSplitLine.size():%d."), TempArrayArrayNumOfSplitLine.size());
		return false;
	}

	for (int i = 0; i < TempArrayArrayNumOfSplitLine.size(); ++i)
	{
		std::vector<int32> TempArrayNumOfSplitLine = TempArrayArrayNumOfSplitLine[i];
		if (TempArrayNumOfSplitLine.size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, TempArrayNumOfSplitLine.size() != 2, TempArrayNumOfSplitLine.size():%d."), TempArrayNumOfSplitLine.size());
			return false;
		}

		int32 x = TempArrayNumOfSplitLine[0];
		int32 y = TempArrayNumOfSplitLine[1];

		if (x == SpawnRegionRightX && y == SpawnRegionRightY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, x == SpawnRegionRightX && y == SpawnRegionRightY, x:%d, y:%d."), x, y);
			return false;
		}

		if (x == SpawnRegionLeftX && y == SpawnRegionLeftY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, x == SpawnRegionLeftX && y == SpawnRegionLeftY, x:%d, y:%d."), x, y);
			return false;
		}

		std::map<int32, std::map<int32, FCWLogicRegion>>::iterator iterFind1 = MapLogicRegion.find(x);
		if (iterFind1 == MapLogicRegion.end())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, iterFind1 == MapLogicRegion.end(), x:%d."), x);
			return false;
		}
		std::map<int32, FCWLogicRegion>::iterator iterFind2 = iterFind1->second.find(y);
		if (iterFind2 == iterFind1->second.end())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, iterFind2 == iterFind1->second.end(), y:%d."), y);
			return false;
		}
	}

	std::vector<FCWLogicRegion> TempArrayLogicRegion;
	for (int i = 0; i < TempArrayArrayNumOfSplitLine.size(); ++i)
	{
		std::vector<int32> TempArrayNumOfSplitLine = TempArrayArrayNumOfSplitLine[i];
		int32 x = TempArrayNumOfSplitLine[0];
		int32 y = TempArrayNumOfSplitLine[1];
		FCWLogicRegion TempLogicRegion = MapLogicRegion[x][y];
		if (!TempLogicRegion.bIsValid)
		{
			TempLogicRegion.X = x;
			TempLogicRegion.Y = y;
		}
		bool isFind = false;
		for (int m = 0; m < TempArrayLogicRegion.size(); ++m)
		{
			FCWLogicRegion Temp = TempArrayLogicRegion[m];
			if (Temp == TempLogicRegion)
			{
				isFind = true;
				break;
			}
		}

		if (!isFind)
		{
			TempArrayLogicRegion.push_back(TempLogicRegion);
			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, TempLogicRegion.X:%d, TempLogicRegion.Y:%d, TempLogicRegion.bIsValid:%d, i:%d."), TempLogicRegion.X, TempLogicRegion.Y, TempLogicRegion.bIsValid, i);
		}
	}

	//--------------------------------------------------------------------------
	if (TempArrayLogicRegion.size() < 3)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelp_2, TempArrayLogicRegion.size() < 3, TempArrayLogicRegion.size():%d, ParamIndex:%d."), TempArrayLogicRegion.size(), ParamIndex);
		return false;
	}

	for (int i = 2; i < TempArrayLogicRegion.size(); ++i)
	{
		if (!GenerateLogicSplitLineHelpInner(TempDungeonData, TempArrayLogicRegion[i - 2], TempArrayLogicRegion[i - 1], TempArrayLogicRegion[i], ECWDungeonRegionType::Forbid, ParamIndex))
		{
			return false;
		}
	}
	//--------------------------------------------------------------------------

	return true;
}

//bool ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldOldLogicRegion, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion)
//{
//	check(TempDungeonData);
//	if (ParamOldOldLogicRegion.X == ParamOldLogicRegion.X &&
//		ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y)
//	{
//		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. ParamOldOldLogicRegion.X == ParamOldLogicRegion.X && ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d."), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y);
//		return false;
//	}
//
//	if (ParamOldLogicRegion.X == ParamLogicRegion.X &&
//		ParamOldLogicRegion.Y == ParamLogicRegion.Y)
//	{
//		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. ParamOldLogicRegion.X == ParamLogicRegion.X && ParamOldLogicRegion.Y == ParamLogicRegion.Y, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y : %d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
//		return false;
//	}
//
//
//	int32 TempTileStartX = 0;
//	int32 TempTileStartY = 0;
//	if (!GenerateIntersectionStartByLogicRegion(ParamOldOldLogicRegion, ParamOldOldLogicRegion, TempTileStartX, TempTileStartY))
//	{
//		return false;
//	}
//
//	int32 TempTileEndX = 0;
//	int32 TempTileEndY = 0;
//	if (!GenerateIntersectionEndByLogicRegion(ParamOldLogicRegion, ParamLogicRegion, TempTileEndX, TempTileEndY))
//	{
//		return false;
//	}
//
//	std::list<CWPEGrid> listPath;
//	bshl->m_isValidFunc = isCanPassForRegionSplitLine;
//	if (bshl->generatePath(TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY))
//	{
//		BSHLNode2D* _node = bshl->getCurBestNode();
//		while (_node)
//		{
//			listPath.push_front(CWPEGrid(_node->x, _node->y));
//			_node = _node->parent;
//		}
//
//		if (listPath.empty())
//		{
//			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. listPath.empty()"));
//			return false;
//		}
//
//		for (std::list<CWPEGrid>::iterator iter = listPath.begin(); iter != listPath.end(); ++iter)
//		{
//			CWPEGrid TempGrid = *iter;
//			int tile = this->xy2tile(TempGrid.x, TempGrid.y);
//			if (ArrayTileType.IsValidIndex(tile))
//			{
//				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
//				continue;
//			}
//
//			if (ArrayTileType[tile] == ECWDungeonRegionType::HighSpeed)
//			{
//				
//			}
//			else if (ArrayTileType[tile] == ECWDungeonRegionType::Danger)
//			{
//				ArrayTileType[tile] = ECWDungeonRegionType::DangerBlock;
//			}
//			else
//			{
//				ArrayTileType[tile] = ECWDungeonRegionType::Forbid;
//			}
//
//			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, ArrayTileType[tile] = ECWDungeonTileType::Block. TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
//		}
//	}
//	else
//	{
//		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, bshl->generatePath Fail. TempTileStartX:%d, TempTileStartY:%d, TempTileEndX:%d, TempTileEndY:%d."), TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY);
//		return false;
//	}
//
//	return true;
//}


bool ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldOldLogicRegion, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex)
{
	check(TempDungeonData);
	if (ParamOldOldLogicRegion.X == ParamOldLogicRegion.X &&
		ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. ParamOldOldLogicRegion.X == ParamOldLogicRegion.X && ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d."), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y);
		return false;
	}

	if (ParamOldLogicRegion.X == ParamLogicRegion.X &&
		ParamOldLogicRegion.Y == ParamLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. ParamOldLogicRegion.X == ParamLogicRegion.X && ParamOldLogicRegion.Y == ParamLogicRegion.Y, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y : %d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d, ParamOldOldLogicRegion.XBegin:%d, ParamOldOldLogicRegion.XEnd:%d, ParamOldOldLogicRegion.YBegin:%d, ParamOldOldLogicRegion.YEnd:%d"), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y, ParamOldOldLogicRegion.XBegin, ParamOldOldLogicRegion.XEnd, ParamOldOldLogicRegion.YBegin, ParamOldOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamOldLogicRegion.XBegin:%d, ParamOldLogicRegion.XEnd:%d, ParamOldLogicRegion.YBegin:%d, ParamOldLogicRegion.YEnd:%d"), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamOldLogicRegion.XBegin, ParamOldLogicRegion.XEnd, ParamOldLogicRegion.YBegin, ParamOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d, ParamLogicRegion.XBegin:%d, ParamLogicRegion.XEnd:%d, ParamLogicRegion.YBegin:%d, ParamLogicRegion.YEnd:%d"), ParamLogicRegion.X, ParamLogicRegion.Y, ParamLogicRegion.XBegin, ParamLogicRegion.XEnd, ParamLogicRegion.YBegin, ParamLogicRegion.YEnd);


	int32 TempTileStartX = 0;
	int32 TempTileStartY = 0;
	if (!GenerateIntersectionStartByLogicRegion(ParamOldOldLogicRegion, ParamOldLogicRegion, TempTileStartX, TempTileStartY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. GenerateIntersectionStartByLogicRegion fail, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d."), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y, ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, TempTileStartX:%d, TempTileStartY:%d."), TempTileStartX, TempTileStartY);

	int32 TempTileEndX = 0;
	int32 TempTileEndY = 0;
	if (!GenerateIntersectionEndByLogicRegion(ParamOldLogicRegion, ParamLogicRegion, TempTileEndX, TempTileEndY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. GenerateIntersectionEndByLogicRegion fail, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamLogicRegion.X, ParamLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, TempTileEndX:%d, TempTileEndY:%d."), TempTileEndX, TempTileEndY);

	std::list<CWPEGrid> listPath;
	bshl->m_isValidFunc = isCanPassForTileGoThroughLine;
	if (bshl->generatePath(TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY))
	{
		BSHLNode2D* _node = bshl->getCurBestNode();
		while (_node)
		{
			listPath.push_front(CWPEGrid(_node->x, _node->y));
			_node = _node->parent;
		}

		if (listPath.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner Fail. listPath.empty()"));
			return false;
		}

		for (std::list<CWPEGrid>::iterator iter = listPath.begin(); iter != listPath.end(); ++iter)
		{
			CWPEGrid TempGrid = *iter;
			int tile = this->xy2tile(TempGrid.x, TempGrid.y);
			if (!ArrayTileType.IsValidIndex(tile))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
				continue;
			}
			/*ArrayTileType[tile] = ParamRegionType;
			ArrayTileGroup[tile] = ParamIndex;
			ArrayTileTileType[tile] = ECWDungeonTileType::GoThroughLine;*/
			if (ArrayTileType[tile] == ECWDungeonRegionType::HighSpeed ||
				ArrayTileType[tile] == ECWDungeonRegionType::SpawnStart)
			{

			}
			else if (ArrayTileType[tile] == ECWDungeonRegionType::Danger)
			{
				ArrayTileType[tile] = ECWDungeonRegionType::DangerBlock;
			}
			else
			{
				ArrayTileType[tile] = ECWDungeonRegionType::Forbid;
			}

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, ArrayTileType[tile] = ECWDungeonTileType::Forbid. TempGrid.x:%d, TempGrid.y:%d, tile:%d, ArrayTileType[tile]:%d."), TempGrid.x, TempGrid.y, tile, (int)ArrayTileType[tile]);
		}

	}
	else
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("CWRandomDungeonGenerator::GenerateLogicSplitLineHelpInner, bshl->generatePath Fail. TempTileStartX:%d, TempTileStartY:%d, TempTileEndX:%d, TempTileEndY:%d."), TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY);
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2(FCWDungeonDataStruct* TempDungeonData, int32 ParamIndex, int32 ParamPathLineNum, int32 ParamHighRoadIndex)
{
	int32 TempHighRoadIndex = ParamHighRoadIndex;
	if (ParamPathLineNum <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, ParamPathLineNum <= 0, ParamPathLineNum:%d."), ParamPathLineNum);
		return false;
	}

	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayDungeonZoneNumFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}
	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];


	int32 SymmetryRegionRightX = 0;
	int32 SymmetryRegionRightY = 0;
	int32 SymmetryRegionLeftX = 0;
	int32 SymmetryRegionLeftY = 0;
		
	if (!FindSymmetryLogicRegionFromSpawnRegion(
		TempDungeonData,
		SpawnRegionRightX,
		SpawnRegionRightY,
		SpawnRegionLeftX,
		SpawnRegionLeftY,
		SymmetryRegionRightX,
		SymmetryRegionRightY,
		SymmetryRegionLeftX,
		SymmetryRegionLeftY))
	{
		return false;
	}

	as1->m_isValidFunc = isCanPassForRegionGoThroughLine;
	as2->m_isValidFunc = isCanPassForRegionGoThroughLine;
	std::vector<FCWLogicRegion> TempArrayGoThroughLine;
	std::list<CWPEGrid> listPath1;
	std::list<CWPEGrid> listPath2;
	if (ParamIndex == 0)
	{
		if (!MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, !MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].bIsValid, SymmetryRegionLeftX:%d, SymmetryRegionLeftY:%d."), SymmetryRegionLeftX, SymmetryRegionLeftY);
			return false;
		}
		ECWDungeonRegionType OldRegionType = MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType;
		MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType = ECWDungeonRegionType::Forbid;

		if (as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, SymmetryRegionRightX, SymmetryRegionRightY, 1000) &&
			as2->generatePath(SymmetryRegionRightX, SymmetryRegionRightY, SpawnRegionLeftX, SpawnRegionLeftY, 1000))
		{
			ASNode2D* _node1 = as1->getCurBestNode();
			while (_node1)
			{
				listPath1.push_front(CWPEGrid(_node1->x, _node1->y));
				_node1 = _node1->parent;
			}

			if (listPath1.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath1.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter1 = listPath1.begin(); iter1 != listPath1.end(); ++iter1)
			{
				CWPEGrid TempGrid1 = *iter1;
				//int tile1 = this->xy2tile(TempGrid1.x, TempGrid1.y);
				if (!MapLogicRegion[TempGrid1.x][TempGrid1.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d."), TempGrid1.x, TempGrid1.y);
					continue;
				}

				MapLogicRegion[TempGrid1.x][TempGrid1.y].RegionType = TempHighRoadIndex == 0 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d, RegionType:%d."), TempGrid1.x, TempGrid1.y, TempHighRoadIndex == 0 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind1 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid1.x][TempGrid1.y];
				for (std::vector<FCWLogicRegion>::iterator iter2 = TempArrayGoThroughLine.begin(); iter2 != TempArrayGoThroughLine.end(); ++iter2)
				{
					FCWLogicRegion TempLogicRegion1 = *iter2;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind1 = true;
						break;
					}
				}
				if (!TempIsFind1)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
			//---------------------------------------------------------------
			ASNode2D* _node2 = as2->getCurBestNode();
			while (_node2)
			{
				listPath2.push_front(CWPEGrid(_node2->x, _node2->y));
				_node2 = _node2->parent;
			}

			if (listPath2.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath2.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter1 = listPath2.begin(); iter1 != listPath2.end(); ++iter1)
			{
				CWPEGrid TempGrid2 = *iter1;
				//int tile2 = this->xy2tile(TempGrid2.x, TempGrid2.y);
				if (!MapLogicRegion[TempGrid2.x][TempGrid2.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d."), TempGrid2.x, TempGrid2.y);
					continue;
				}

				MapLogicRegion[TempGrid2.x][TempGrid2.y].RegionType = TempHighRoadIndex == 0 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d, RegionType:%d."), TempGrid2.x, TempGrid2.y, TempHighRoadIndex == 0 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind2 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid2.x][TempGrid2.y];
				for (std::vector<FCWLogicRegion>::iterator iter2 = TempArrayGoThroughLine.begin(); iter2 != TempArrayGoThroughLine.end(); ++iter2)
				{
					FCWLogicRegion TempLogicRegion1 = *iter2;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind2 = true;
						break;
					}
				}
				if (!TempIsFind2)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
		}
		else
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, SymmetryRegionRightX, SymmetryRegionRightY) && as2->generatePath(SymmetryRegionRightX, SymmetryRegionRightY, SpawnRegionLeftX, SpawnRegionLeftY), ParamIndex:%d."), ParamIndex);
		}

		MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType = OldRegionType;
	}
	else if (ParamIndex == 1)
	{
		if (!MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, !MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].bIsValid, SymmetryRegionRightX:%d, SymmetryRegionRightY:%d."), SymmetryRegionRightX, SymmetryRegionRightY);
			return false;
		}
		ECWDungeonRegionType OldRegionType = MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType;
		MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType = ECWDungeonRegionType::Forbid;

		if (as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, SymmetryRegionLeftX, SymmetryRegionLeftY, 1000) &&
			as2->generatePath(SymmetryRegionLeftX, SymmetryRegionLeftY, SpawnRegionLeftX, SpawnRegionLeftY, 1000))
		{
			ASNode2D* _node1 = as1->getCurBestNode();
			while (_node1)
			{
				listPath1.push_front(CWPEGrid(_node1->x, _node1->y));
				_node1 = _node1->parent;
			}

			if (listPath1.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath1.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter1 = listPath1.begin(); iter1 != listPath1.end(); ++iter1)
			{
				CWPEGrid TempGrid1 = *iter1;
				if (!MapLogicRegion[TempGrid1.x][TempGrid1.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d."), TempGrid1.x, TempGrid1.y);
					continue;
				}

				MapLogicRegion[TempGrid1.x][TempGrid1.y].RegionType = TempHighRoadIndex == 1 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d, RegionType:%d."), TempGrid1.x, TempGrid1.y, TempHighRoadIndex == 1 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind1 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid1.x][TempGrid1.y];
				for (std::vector<FCWLogicRegion>::iterator iter = TempArrayGoThroughLine.begin(); iter != TempArrayGoThroughLine.end(); ++iter)
				{
					FCWLogicRegion TempLogicRegion1 = *iter;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind1 = true;
						break;
					}
				}
				if (!TempIsFind1)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
			//---------------------------------------------------------------
			ASNode2D* _node2 = as2->getCurBestNode();
			while (_node2)
			{
				listPath2.push_front(CWPEGrid(_node2->x, _node2->y));
				_node2 = _node2->parent;
			}

			if (listPath2.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath2.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter2 = listPath2.begin(); iter2 != listPath2.end(); ++iter2)
			{
				CWPEGrid TempGrid2 = *iter2;
				if (!MapLogicRegion[TempGrid2.x][TempGrid2.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d."), TempGrid2.x, TempGrid2.y);
					continue;
				}

				MapLogicRegion[TempGrid2.x][TempGrid2.y].RegionType = TempHighRoadIndex == 1 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d, RegionType:%d."), TempGrid2.x, TempGrid2.y, TempHighRoadIndex == 1 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind2 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid2.x][TempGrid2.y];
				for (std::vector<FCWLogicRegion>::iterator iter = TempArrayGoThroughLine.begin(); iter != TempArrayGoThroughLine.end(); ++iter)
				{
					FCWLogicRegion TempLogicRegion1 = *iter;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind2 = true;
						break;
					}
				}
				if (!TempIsFind2)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
		}
		else
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, SymmetryRegionLeftX, SymmetryRegionLeftY) && as2->generatePath(SymmetryRegionLeftX, SymmetryRegionLeftY, SpawnRegionLeftX, SpawnRegionLeftY), ParamIndex:%d."), ParamIndex);
		}

		MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType = OldRegionType;
	}
	else if (ParamIndex == 2)
	{
		int32 TempHalfX = TempLogicHeightNum / 2;
		int32 TempHalfY = TempLogicHeightNum / 2;

		if (TempHalfX == SpawnRegionRightX && TempHalfY == SpawnRegionRightY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 TempHalfX == SpawnRegionRightX && TempHalfY == SpawnRegionRightY, TempHalfX:%d, TempHalfY:%d, SpawnRegionRightX:%d, SpawnRegionRightY:%d."), TempHalfX, TempHalfY, SpawnRegionRightX, SpawnRegionRightY);
			return false;
		}

		if (TempHalfX == SpawnRegionLeftX && TempHalfY == SpawnRegionLeftY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 TempHalfX == SpawnRegionLeftX && TempHalfY == SpawnRegionLeftY, TempHalfX:%d, TempHalfY:%d, SpawnRegionLeftX:%d, SpawnRegionLeftY:%d."), TempHalfX, TempHalfY, SpawnRegionLeftX, SpawnRegionLeftY);
			return false;
		}
		
		if (TempHalfX == SymmetryRegionRightX && TempHalfY == SymmetryRegionRightY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 TempHalfX == SymmetryRegionRightX && TempHalfY == SymmetryRegionRightY, TempHalfX:%d, TempHalfY:%d, SymmetryRegionRightX:%d, SymmetryRegionRightY:%d."), TempHalfX, TempHalfY, SymmetryRegionRightX, SymmetryRegionRightY);
			return false;
		}

		if (TempHalfX == SymmetryRegionLeftX && TempHalfY == SymmetryRegionLeftY)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 TempHalfX == SymmetryRegionLeftX && TempHalfY == SymmetryRegionLeftY, TempHalfX:%d, TempHalfY:%d, SymmetryRegionLeftX:%d, SymmetryRegionLeftY:%d."), TempHalfX, TempHalfY, SymmetryRegionLeftX, SymmetryRegionLeftY);
			return false;
		}

		if (!MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, !MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].bIsValid, SymmetryRegionRightX:%d, SymmetryRegionRightY:%d."), SymmetryRegionRightX, SymmetryRegionRightY);
			return false;
		}
		ECWDungeonRegionType OldRegionType1 = MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType;
		MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType = ECWDungeonRegionType::Forbid;

		if (!MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].bIsValid)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, !MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].bIsValid, SymmetryRegionLeftX:%d, SymmetryRegionLeftY:%d."), SymmetryRegionLeftX, SymmetryRegionLeftY);
			return false;
		}
		ECWDungeonRegionType OldRegionType2 = MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType;
		MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType = ECWDungeonRegionType::Forbid;

		if (as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, TempHalfX, TempHalfY, 1000) &&
			as2->generatePath(TempHalfX, TempHalfY, SpawnRegionLeftX, SpawnRegionLeftY, 1000))
		{
			ASNode2D* _node1 = as1->getCurBestNode();
			while (_node1)
			{
				listPath1.push_front(CWPEGrid(_node1->x, _node1->y));
				_node1 = _node1->parent;
			}

			if (listPath1.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath1.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter1 = listPath1.begin(); iter1 != listPath1.end(); ++iter1)
			{
				CWPEGrid TempGrid1 = *iter1;
				if (!MapLogicRegion[TempGrid1.x][TempGrid1.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d."), TempGrid1.x, TempGrid1.y);
					continue;
				}

				MapLogicRegion[TempGrid1.x][TempGrid1.y].RegionType = TempHighRoadIndex == 2 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid1.x:%d, TempGrid1.y:%d, RegionType:%d."), TempGrid1.x, TempGrid1.y, TempHighRoadIndex == 2 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind1 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid1.x][TempGrid1.y];
				for (std::vector<FCWLogicRegion>::iterator iter2 = TempArrayGoThroughLine.begin(); iter2 != TempArrayGoThroughLine.end(); ++iter2)
				{
					FCWLogicRegion TempLogicRegion1 = *iter2;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind1 = true;
						break;
					}
				}
				if (!TempIsFind1)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
			//---------------------------------------------------------------
			ASNode2D* _node2 = as2->getCurBestNode();
			while (_node2)
			{
				listPath2.push_front(CWPEGrid(_node2->x, _node2->y));
				_node2 = _node2->parent;
			}

			if (listPath2.empty())
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 Fail. listPath2.empty()"));
				return false;
			}

			for (std::list<CWPEGrid>::iterator iter = listPath2.begin(); iter != listPath2.end(); ++iter)
			{
				CWPEGrid TempGrid2 = *iter;
				if (!MapLogicRegion[TempGrid2.x][TempGrid2.y].bIsValid)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d."), TempGrid2.x, TempGrid2.y);
					continue;
				}

				MapLogicRegion[TempGrid2.x][TempGrid2.y].RegionType = TempHighRoadIndex == 2 ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempGrid2.x:%d, TempGrid2.y:%d, RegionType:%d."), TempGrid2.x, TempGrid2.y, TempHighRoadIndex == 2 ? (int)ECWDungeonRegionType::HighSpeed : (int)ECWDungeonRegionType::Danger);
				//--------------------------------------------------------------------------
				bool TempIsFind2 = false;
				FCWLogicRegion TempLogicRegion2 = MapLogicRegion[TempGrid2.x][TempGrid2.y];
				for (std::vector<FCWLogicRegion>::iterator iter = TempArrayGoThroughLine.begin(); iter != TempArrayGoThroughLine.end(); ++iter)
				{
					FCWLogicRegion TempLogicRegion1 = *iter;
					if (TempLogicRegion1 == TempLogicRegion2)
					{
						TempIsFind2 = true;
						break;
					}
				}
				if (!TempIsFind2)
				{
					TempArrayGoThroughLine.push_back(TempLogicRegion2);
				}
				//--------------------------------------------------------------------------
			}
		}
		else
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2 as1->generatePath(SpawnRegionRightX, SpawnRegionRightY, TempHalfX, TempHalfY) && as2->generatePath(TempHalfX, TempHalfY, SpawnRegionLeftX, SpawnRegionLeftY), ParamIndex:%d."), ParamIndex);
		}

		MapLogicRegion[SymmetryRegionRightX][SymmetryRegionRightY].RegionType = OldRegionType1;
		MapLogicRegion[SymmetryRegionLeftX][SymmetryRegionLeftY].RegionType = OldRegionType2;
	}
	

	//--------------------------------------------------------------------------
	if (TempArrayGoThroughLine.size() < 3)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelp_2, TempArrayGoThroughLine.size() < 3, TempArrayGoThroughLine.size():%d, ParamIndex:%d."), TempArrayGoThroughLine.size(), ParamIndex);
		return false;
	}

	if (!GenerateLogicGoThroughLineStartHelpInner(TempDungeonData, TempArrayGoThroughLine[0], TempArrayGoThroughLine[1], TempHighRoadIndex == ParamIndex ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger, ParamIndex))
	{
		return false;
	}

	for (int i = 2; i < TempArrayGoThroughLine.size(); ++i)
	{
		if (!GenerateLogicGoThroughLineHelpInner(TempDungeonData, TempArrayGoThroughLine[i - 2], TempArrayGoThroughLine[i - 1], TempArrayGoThroughLine[i], TempHighRoadIndex == ParamIndex ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger, ParamIndex))
		{
			return false;
		}
	}

	if (!GenerateLogicGoThroughLineEndHelpInner(TempDungeonData, TempArrayGoThroughLine[TempArrayGoThroughLine.size() - 2], TempArrayGoThroughLine[TempArrayGoThroughLine.size() - 1], TempHighRoadIndex == ParamIndex ? ECWDungeonRegionType::HighSpeed : ECWDungeonRegionType::Danger, ParamIndex))
	{
		return false;
	}
	//--------------------------------------------------------------------------
	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex)
{
	check(TempDungeonData);
	if (ParamOldLogicRegion.X == ParamLogicRegion.X &&
		ParamOldLogicRegion.Y == ParamLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner Fail. ParamOldLogicRegion.X == ParamLogicRegion.X && ParamOldLogicRegion.Y == ParamLogicRegion.Y, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y : %d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamOldLogicRegion.XBegin:%d, ParamOldLogicRegion.XEnd:%d, ParamOldLogicRegion.YBegin:%d, ParamOldLogicRegion.YEnd:%d"), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamOldLogicRegion.XBegin, ParamOldLogicRegion.XEnd, ParamOldLogicRegion.YBegin, ParamOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d, ParamLogicRegion.XBegin:%d, ParamLogicRegion.XEnd:%d, ParamLogicRegion.YBegin:%d, ParamLogicRegion.YEnd:%d"), ParamLogicRegion.X, ParamLogicRegion.Y, ParamLogicRegion.XBegin, ParamLogicRegion.XEnd, ParamLogicRegion.YBegin, ParamLogicRegion.YEnd);

	//int32 TempTileStartX = (float)(ParamOldLogicRegion.XBegin + ParamOldLogicRegion.XEnd) / 2.0f + 0.5f;
	//int32 TempTileStartY = (float)(ParamOldLogicRegion.YBegin + ParamOldLogicRegion.YEnd) / 2.0f + 0.5f;
	int32 TempTileStartX = RandomInt(ParamOldLogicRegion.XBegin, ParamOldLogicRegion.XEnd);
	int32 TempTileStartY = RandomInt(ParamOldLogicRegion.YBegin, ParamOldLogicRegion.YEnd);


	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, TempTileStartX:%d, TempTileStartY:%d."), TempTileStartX, TempTileStartY);
	

	int32 TempTileEndX = 0;
	int32 TempTileEndY = 0;
	if (!GenerateIntersectionEndByLogicRegion(ParamOldLogicRegion, ParamLogicRegion, TempTileEndX, TempTileEndY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. GenerateIntersectionEndByLogicRegion fail, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamLogicRegion.X, ParamLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, TempTileEndX:%d, TempTileEndY:%d."), TempTileEndX, TempTileEndY);
	
	std::list<CWPEGrid> listPath;
	bshl->m_isValidFunc = isCanPassForTileGoThroughLine;
	if (bshl->generatePath(TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY))
	{
		BSHLNode2D* _node = bshl->getCurBestNode();
		while (_node)
		{
			listPath.push_front(CWPEGrid(_node->x, _node->y));
			_node = _node->parent;
		}

		if (listPath.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner Fail. listPath.empty()"));
			return false;
		}

		for (std::list<CWPEGrid>::iterator iter = listPath.begin(); iter != listPath.end(); ++iter)
		{
			CWPEGrid TempGrid = *iter;
			int tile = this->xy2tile(TempGrid.x, TempGrid.y);
			if (!ArrayTileType.IsValidIndex(tile))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
				continue;
			}

			if (ArrayTileType[tile] == ECWDungeonRegionType::None 
				|| (ArrayTileType[tile] != ECWDungeonRegionType::SpawnStart &&
					ArrayTileType[tile] != ECWDungeonRegionType::Danger && 
					ParamRegionType == ECWDungeonRegionType::Danger))
			{
				ArrayTileType[tile] = ParamRegionType;
			}

			ArrayTileGroup[tile] = ParamIndex;
			ArrayTileTileType[tile] = ECWDungeonTileType::GoThroughLine;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, ArrayTileTileType[tile] = ECWDungeonTileType::GoThroughLine. TempGrid.x:%d, TempGrid.y:%d, tile:%d, ArrayTileType[tile]:%d, ArrayTileGroup[tile]:%d."), TempGrid.x, TempGrid.y, tile, (int)ArrayTileType[tile], ArrayTileGroup[tile]);
		}

	}
	else
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineStartHelpInner, bshl->generatePath Fail. TempTileStartX:%d, TempTileStartY:%d, TempTileEndX:%d, TempTileEndY:%d."), TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY);
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldOldLogicRegion, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex)
{
	check(TempDungeonData);
	if (ParamOldOldLogicRegion.X == ParamOldLogicRegion.X &&
		ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. ParamOldOldLogicRegion.X == ParamOldLogicRegion.X && ParamOldOldLogicRegion.Y == ParamOldLogicRegion.Y, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d."), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y);
		return false;
	}

	if (ParamOldLogicRegion.X == ParamLogicRegion.X &&
		ParamOldLogicRegion.Y == ParamLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. ParamOldLogicRegion.X == ParamLogicRegion.X && ParamOldLogicRegion.Y == ParamLogicRegion.Y, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y : %d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d, ParamOldOldLogicRegion.XBegin:%d, ParamOldOldLogicRegion.XEnd:%d, ParamOldOldLogicRegion.YBegin:%d, ParamOldOldLogicRegion.YEnd:%d"), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y, ParamOldOldLogicRegion.XBegin, ParamOldOldLogicRegion.XEnd, ParamOldOldLogicRegion.YBegin, ParamOldOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamOldLogicRegion.XBegin:%d, ParamOldLogicRegion.XEnd:%d, ParamOldLogicRegion.YBegin:%d, ParamOldLogicRegion.YEnd:%d"), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamOldLogicRegion.XBegin, ParamOldLogicRegion.XEnd, ParamOldLogicRegion.YBegin, ParamOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d, ParamLogicRegion.XBegin:%d, ParamLogicRegion.XEnd:%d, ParamLogicRegion.YBegin:%d, ParamLogicRegion.YEnd:%d"), ParamLogicRegion.X, ParamLogicRegion.Y, ParamLogicRegion.XBegin, ParamLogicRegion.XEnd, ParamLogicRegion.YBegin, ParamLogicRegion.YEnd);


	int32 TempTileStartX = 0;
	int32 TempTileStartY = 0;
	if (!GenerateIntersectionStartByLogicRegion(ParamOldOldLogicRegion, ParamOldLogicRegion, TempTileStartX, TempTileStartY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. GenerateIntersectionStartByLogicRegion fail, ParamOldOldLogicRegion.X:%d, ParamOldOldLogicRegion.Y:%d, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d."), ParamOldOldLogicRegion.X, ParamOldOldLogicRegion.Y, ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, TempTileStartX:%d, TempTileStartY:%d."), TempTileStartX, TempTileStartY);

	int32 TempTileEndX = 0;
	int32 TempTileEndY = 0;
	if (!GenerateIntersectionEndByLogicRegion(ParamOldLogicRegion, ParamLogicRegion, TempTileEndX, TempTileEndY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. GenerateIntersectionEndByLogicRegion fail, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamLogicRegion.X, ParamLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, TempTileEndX:%d, TempTileEndY:%d."), TempTileEndX, TempTileEndY);

	std::list<CWPEGrid> listPath;
	bshl->m_isValidFunc = isCanPassForTileGoThroughLine;
	if (bshl->generatePath(TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY))
	{
		BSHLNode2D* _node = bshl->getCurBestNode();
		while (_node)
		{
			listPath.push_front(CWPEGrid(_node->x, _node->y));
			_node = _node->parent;
		}

		if (listPath.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner Fail. listPath.empty()"));
			return false;
		}

		for (std::list<CWPEGrid>::iterator iter = listPath.begin(); iter != listPath.end(); ++iter)
		{
			CWPEGrid TempGrid = *iter;
			int tile = this->xy2tile(TempGrid.x, TempGrid.y);
			if (!ArrayTileType.IsValidIndex(tile))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
				continue;
			}

			if (ArrayTileType[tile] == ECWDungeonRegionType::None
				|| (ArrayTileType[tile] != ECWDungeonRegionType::SpawnStart &&
					ArrayTileType[tile] != ECWDungeonRegionType::Danger &&
					ParamRegionType == ECWDungeonRegionType::Danger))
			{
				ArrayTileType[tile] = ParamRegionType;
			}

			ArrayTileGroup[tile] = ParamIndex;
			ArrayTileTileType[tile] = ECWDungeonTileType::GoThroughLine;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. TempGrid.x:%d, TempGrid.y:%d, tile:%d, ArrayTileType[tile]:%d, ArrayTileGroup[tile]:%d."), TempGrid.x, TempGrid.y, tile, (int)ArrayTileType[tile], ArrayTileGroup[tile]);
		}

	}
	else
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineHelpInner, bshl->generatePath Fail. TempTileStartX:%d, TempTileStartY:%d, TempTileEndX:%d, TempTileEndY:%d."), TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY);
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex)
{
	check(TempDungeonData);
	if (ParamOldLogicRegion.X == ParamLogicRegion.X &&
		ParamOldLogicRegion.Y == ParamLogicRegion.Y)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner Fail. ParamOldLogicRegion.X == ParamLogicRegion.X && ParamOldLogicRegion.Y == ParamLogicRegion.Y, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y : %d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y);
		return false;
	}

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamOldLogicRegion.XBegin:%d, ParamOldLogicRegion.XEnd:%d, ParamOldLogicRegion.YBegin:%d, ParamOldLogicRegion.YEnd:%d"), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamOldLogicRegion.XBegin, ParamOldLogicRegion.XEnd, ParamOldLogicRegion.YBegin, ParamOldLogicRegion.YEnd);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d, ParamLogicRegion.XBegin:%d, ParamLogicRegion.XEnd:%d, ParamLogicRegion.YBegin:%d, ParamLogicRegion.YEnd:%d"), ParamLogicRegion.X, ParamLogicRegion.Y, ParamLogicRegion.XBegin, ParamLogicRegion.XEnd, ParamLogicRegion.YBegin, ParamLogicRegion.YEnd);

	int32 TempTileStartX = 0;
	int32 TempTileStartY = 0;
	if (!GenerateIntersectionStartByLogicRegion(ParamOldLogicRegion, ParamLogicRegion, TempTileStartX, TempTileStartY))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion Fail. GenerateIntersectionEndByLogicRegion fail, ParamOldLogicRegion.X:%d, ParamOldLogicRegion.Y:%d, ParamLogicRegion.X:%d, ParamLogicRegion.Y:%d."), ParamOldLogicRegion.X, ParamOldLogicRegion.Y, ParamLogicRegion.X, ParamLogicRegion.Y);
		return false;
	}
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion, TempTileStartX:%d, TempTileStartY:%d."), TempTileStartX, TempTileStartY);

	//int32 TempTileEndX = (float)(ParamLogicRegion.XBegin + ParamLogicRegion.XEnd) / 2.0f + 0.5f;
	//int32 TempTileEndY = (float)(ParamLogicRegion.YBegin + ParamLogicRegion.YEnd) / 2.0f + 0.5f;
	int32 TempTileEndX = RandomInt(ParamLogicRegion.XBegin, ParamLogicRegion.XEnd);
	int32 TempTileEndY = RandomInt(ParamLogicRegion.YBegin, ParamLogicRegion.YEnd);

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion, TempTileEndX:%d, TempTileEndY:%d."), TempTileEndX, TempTileEndY);

	std::list<CWPEGrid> listPath;
	bshl->m_isValidFunc = isCanPassForTileGoThroughLine;
	if (bshl->generatePath(TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY))
	{
		BSHLNode2D* _node = bshl->getCurBestNode();
		while (_node)
		{
			listPath.push_front(CWPEGrid(_node->x, _node->y));
			_node = _node->parent;
		}

		if (listPath.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner Fail. listPath.empty()"));
			return false;
		}

		for (std::list<CWPEGrid>::iterator iter = listPath.begin(); iter != listPath.end(); ++iter)
		{
			CWPEGrid TempGrid = *iter;
			int tile = this->xy2tile(TempGrid.x, TempGrid.y);
			if (!ArrayTileType.IsValidIndex(tile))
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner, TempGrid.x:%d, TempGrid.y:%d, tile:%d."), TempGrid.x, TempGrid.y, tile);
				continue;
			}

			if (ArrayTileType[tile] == ECWDungeonRegionType::None
				|| (ArrayTileType[tile] != ECWDungeonRegionType::SpawnStart &&
					ArrayTileType[tile] != ECWDungeonRegionType::Danger && 
					ParamRegionType == ECWDungeonRegionType::Danger))
			{
				ArrayTileType[tile] = ParamRegionType;
			}

			ArrayTileGroup[tile] = ParamIndex;
			ArrayTileTileType[tile] = ECWDungeonTileType::GoThroughLine;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. TempGrid.x:%d, TempGrid.y:%d, tile:%d, ArrayTileType[tile]:%d, ArrayTileGroup[tile]:%d."), TempGrid.x, TempGrid.y, tile, (int)ArrayTileType[tile], ArrayTileGroup[tile]);
		}
	}
	else
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("CWRandomDungeonGenerator::GenerateLogicGoThroughLineEndHelpInner, bshl->generatePath Fail. TempTileStartX:%d, TempTileStartY:%d, TempTileEndX:%d, TempTileEndY:%d."), TempTileStartX, TempTileStartY, TempTileEndX, TempTileEndY);
		return false;
	}

	return true;
}

bool ACWRandomDungeonGenerator::FixLogicGoThroughLine(FCWDungeonDataStruct* TempDungeonData)
{
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine..."));
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;
			
			int tile2 = xy2tile(x-1, y+1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x-1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y+1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonTileType TempTileType1 = ArrayTileTileType[tile1];
			ECWDungeonTileType TempTileType2 = ArrayTileTileType[tile2];
			ECWDungeonTileType TempTileType3 = ArrayTileTileType[tile3];
			ECWDungeonTileType TempTileType4 = ArrayTileTileType[tile4];

			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine. 1 x:%d, y:%d, tile1:%d, tile2:%d, tile3:%d, tile4:%d."), x, y, tile1, tile2, tile3, tile4);

			if (TempTileType1 == ECWDungeonTileType::GoThroughLine && 
				TempTileType2 == ECWDungeonTileType::GoThroughLine &&
				TempTileType3 == ECWDungeonTileType::None &&
				TempTileType4 == ECWDungeonTileType::None)
			{
				ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
				ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
				int32 TempGroup1 = ArrayTileGroup[tile1];
				int32 TempGroup2 = ArrayTileGroup[tile2];

				if (TempRegionType1 == TempRegionType2)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileTileType[tile3] = ECWDungeonTileType::GoThroughLine;
						if (ArrayTileType[tile3] == ECWDungeonRegionType::None)
						{
							ArrayTileType[tile3] = TempRegionType1;
							ArrayTileGroup[tile3] = TempGroup1;

							UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. x:%d, y:%d, tile1:%d, tile3:%d, index:%d, TempRegionType:%d."), x, y, tile1, tile3, index, (int32)TempRegionType1);
						}
					}
					else if (index == 1)
					{
						ArrayTileTileType[tile4] = ECWDungeonTileType::GoThroughLine;
						if (ArrayTileType[tile4] == ECWDungeonRegionType::None)
						{
							ArrayTileType[tile4] = TempRegionType1;
							ArrayTileGroup[tile4] = TempGroup1;

							UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. x:%d, y:%d, tile1:%d, tile4:%d, index:%d, TempRegionType:%d."), x, y, tile1, tile4, index, (int32)TempRegionType1);
						}
					}
				}
			}
		}
	}

	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x+1, y+1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x+1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y+1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonTileType TempTileType1 = ArrayTileTileType[tile1];
			ECWDungeonTileType TempTileType2 = ArrayTileTileType[tile2];
			ECWDungeonTileType TempTileType3 = ArrayTileTileType[tile3];
			ECWDungeonTileType TempTileType4 = ArrayTileTileType[tile4];

			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine. 2 x:%d, y:%d, tile1:%d, tile2:%d, tile3:%d, tile4:%d."), x, y, tile1, tile2, tile3, tile4);

			if (TempTileType1 == ECWDungeonTileType::GoThroughLine &&
				TempTileType2 == ECWDungeonTileType::GoThroughLine &&
				TempTileType3 == ECWDungeonTileType::None &&
				TempTileType4 == ECWDungeonTileType::None)
			{
				ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
				ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
				int32 TempGroup1 = ArrayTileGroup[tile1];
				int32 TempGroup2 = ArrayTileGroup[tile2];

				if (TempRegionType1 == TempRegionType2)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileTileType[tile3] = ECWDungeonTileType::GoThroughLine;
						if (ArrayTileType[tile3] == ECWDungeonRegionType::None)
						{
							ArrayTileType[tile3] = TempRegionType1;
							ArrayTileGroup[tile3] = TempGroup1;

							UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. x:%d, y:%d, tile1:%d, tile3:%d, index:%d, TempRegionType:%d."), x, y, tile1, tile3, index, (int32)TempRegionType1);
						}
					}
					else if (index == 1)
					{
						ArrayTileTileType[tile4] = ECWDungeonTileType::GoThroughLine;
						if (ArrayTileType[tile4] == ECWDungeonRegionType::None)
						{
							ArrayTileType[tile4] = TempRegionType1;
							ArrayTileGroup[tile4] = TempGroup1;

							UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicGoThroughLine, ArrayTileType[tile] = ECWDungeonTileType::GoThroughLine. x:%d, y:%d, tile1:%d, tile4:%d, index:%d, TempRegionType:%d."), x, y, tile1, tile4, index, (int32)TempRegionType1);
						}
					}
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::FixLogicDangerBlock(FCWDungeonDataStruct* TempDungeonData)
{
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile = xy2tile(x, y);
			if (!ArrayTileType.IsValidIndex(tile))
				continue;

			ECWDungeonRegionType TempRegionType = ArrayTileType[tile];
			if (TempRegionType != ECWDungeonRegionType::DangerBlock)
				continue;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicDangerBlock, ArrayTileType[tile] = ECWDungeonTileType::DangerBlock. x:%d, y:%d, tile:%d, TempRegionType:%d."), x, y, tile, (int32)TempRegionType);

			int tile1 = xy2tile(x+1, y);
			if (!ArrayTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x-1, y);
			if (!ArrayTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x, y+1);
			if (!ArrayTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y-1);
			if (!ArrayTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
			ECWDungeonRegionType TempRegionType3 = ArrayTileType[tile3];
			ECWDungeonRegionType TempRegionType4 = ArrayTileType[tile4];

			if (TempRegionType1 != ECWDungeonRegionType::DangerBlock &&
				TempRegionType2 != ECWDungeonRegionType::DangerBlock &&
				TempRegionType3 != ECWDungeonRegionType::DangerBlock &&
				TempRegionType4 != ECWDungeonRegionType::DangerBlock)
			{
				int index = rand() % 4;
				if (index == 0)
				{
					ArrayTileType[tile1] = ECWDungeonRegionType::DangerBlock;
					ArrayTileGroup[tile1] = ArrayTileGroup[tile];

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicDangerBlock, ArrayTileType[tile] = ECWDungeonTileType::DangerBlock. x:%d, y:%d, tile:%d, index:%d, tile1:%d, TileGroup:%d."), x, y, tile, index, tile1, ArrayTileGroup[tile]);
				}
				else if (index == 1)
				{
					ArrayTileType[tile2] = ECWDungeonRegionType::DangerBlock;
					ArrayTileGroup[tile2] = ArrayTileGroup[tile];

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicDangerBlock, ArrayTileType[tile] = ECWDungeonTileType::DangerBlock. x:%d, y:%d, tile:%d, index:%d, tile2:%d, TileGroup:%d."), x, y, tile, index, tile2, ArrayTileGroup[tile]);
				}
				else if (index == 2)
				{
					ArrayTileType[tile3] = ECWDungeonRegionType::DangerBlock;
					ArrayTileGroup[tile3] = ArrayTileGroup[tile];

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicDangerBlock, ArrayTileType[tile] = ECWDungeonTileType::DangerBlock. x:%d, y:%d, tile:%d, index:%d, tile3:%d, TileGroup:%d."), x, y, tile, index, tile3, ArrayTileGroup[tile]);
				}
				else if (index == 3)
				{
					ArrayTileType[tile4] = ECWDungeonRegionType::DangerBlock;
					ArrayTileGroup[tile4] = ArrayTileGroup[tile];

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicDangerBlock, ArrayTileType[tile] = ECWDungeonTileType::DangerBlock. x:%d, y:%d, tile:%d, index:%d, tile4:%d, TileGroup:%d."), x, y, tile, index, tile4, ArrayTileGroup[tile]);
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::FixLogicForbidLine(FCWDungeonDataStruct* TempDungeonData)
{
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x - 1, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x - 1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
			ECWDungeonRegionType TempRegionType3 = ArrayTileType[tile3];
			ECWDungeonRegionType TempRegionType4 = ArrayTileType[tile4];
			if (TempRegionType1 == ECWDungeonRegionType::Forbid &&
				TempRegionType2 == ECWDungeonRegionType::Forbid)
			{
				if (TempRegionType3 == ECWDungeonRegionType::None && TempRegionType4 == ECWDungeonRegionType::None)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileType[tile3] = ECWDungeonRegionType::Forbid;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 1. x:%d, y:%d, tile1:%d, tile3:%d, index:%d."), x, y, tile1, tile3, index);
					}
					else if (index == 1)
					{
						ArrayTileType[tile4] = ECWDungeonRegionType::Forbid;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 1. x:%d, y:%d, tile1:%d, tile4:%d, index:%d."), x, y, tile1, tile4, index);
					}
				}
				else if (TempRegionType3 == ECWDungeonRegionType::None && 
					TempRegionType4 != ECWDungeonRegionType::None &&
					TempRegionType4 != ECWDungeonRegionType::Forbid &&
					TempRegionType4 != ECWDungeonRegionType::DangerBlock)
				{
					ArrayTileType[tile3] = ECWDungeonRegionType::Forbid;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 1. x:%d, y:%d, tile1:%d, tile3:%d."), x, y, tile1, tile3);
				}
				else if (TempRegionType3 != ECWDungeonRegionType::None && 
					TempRegionType3 != ECWDungeonRegionType::Forbid &&
					TempRegionType3 != ECWDungeonRegionType::DangerBlock &&
					TempRegionType4 == ECWDungeonRegionType::None)
				{
					ArrayTileType[tile4] = ECWDungeonRegionType::Forbid;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 1. x:%d, y:%d, tile1:%d, tile4:%d."), x, y, tile1, tile4);
				}
			}
		}
	}

	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x + 1, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x + 1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
			ECWDungeonRegionType TempRegionType3 = ArrayTileType[tile3];
			ECWDungeonRegionType TempRegionType4 = ArrayTileType[tile4];
			if (TempRegionType1 == ECWDungeonRegionType::Forbid &&
				TempRegionType2 == ECWDungeonRegionType::Forbid)
			{
				if (TempRegionType3 == ECWDungeonRegionType::None && TempRegionType4 == ECWDungeonRegionType::None)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileType[tile3] = ECWDungeonRegionType::Forbid;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 2. x:%d, y:%d, tile1:%d, tile3:%d, index:%d."), x, y, tile1, tile3, index);
					}
					else if (index == 1)
					{
						ArrayTileType[tile4] = ECWDungeonRegionType::Forbid;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 2. x:%d, y:%d, tile1:%d, tile4:%d, index:%d."), x, y, tile1, tile4, index);
					}
				}
				else if (TempRegionType3 == ECWDungeonRegionType::None && 
					TempRegionType4 != ECWDungeonRegionType::None &&
					TempRegionType4 != ECWDungeonRegionType::Forbid &&
					TempRegionType4 != ECWDungeonRegionType::DangerBlock)
				{
					ArrayTileType[tile3] = ECWDungeonRegionType::Forbid;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 2. x:%d, y:%d, tile1:%d, tile3:%d."), x, y, tile1, tile3);
				}
				else if (TempRegionType3 != ECWDungeonRegionType::None && 
					TempRegionType3 != ECWDungeonRegionType::Forbid &&
					TempRegionType3 != ECWDungeonRegionType::DangerBlock &&
					TempRegionType4 == ECWDungeonRegionType::None)
				{
					ArrayTileType[tile4] = ECWDungeonRegionType::Forbid;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicForbidLine, ArrayTileType[tile] = ECWDungeonTileType::Forbid 2. x:%d, y:%d, tile1:%d, tile4:%d."), x, y, tile1, tile4);
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::FixLogicLowSpeedLine(FCWDungeonDataStruct* TempDungeonData)
{
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x - 1, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x - 1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
			ECWDungeonRegionType TempRegionType3 = ArrayTileType[tile3];
			ECWDungeonRegionType TempRegionType4 = ArrayTileType[tile4];
			if (TempRegionType1 == ECWDungeonRegionType::LowSpeed &&
				TempRegionType2 == ECWDungeonRegionType::LowSpeed)
			{
				if (TempRegionType3 == ECWDungeonRegionType::None && TempRegionType4 == ECWDungeonRegionType::None)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileType[tile3] = ECWDungeonRegionType::LowSpeed;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 1. x:%d, y:%d, tile1:%d, tile3:%d, index:%d."), x, y, tile1, tile3, index);
					}
					else if (index == 1)
					{
						ArrayTileType[tile4] = ECWDungeonRegionType::LowSpeed;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 1. x:%d, y:%d, tile1:%d, tile4:%d, index:%d."), x, y, tile1, tile4, index);
					}
				}
				else if (TempRegionType3 == ECWDungeonRegionType::None && 
					TempRegionType4 != ECWDungeonRegionType::None &&
					TempRegionType4 != ECWDungeonRegionType::LowSpeed)
				{
					ArrayTileType[tile3] = ECWDungeonRegionType::LowSpeed;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 1. x:%d, y:%d, tile1:%d, tile3:%d."), x, y, tile1, tile3);
				}
				else if (TempRegionType3 != ECWDungeonRegionType::None && 
					TempRegionType3 != ECWDungeonRegionType::LowSpeed &&
					TempRegionType4 == ECWDungeonRegionType::None)
				{
					ArrayTileType[tile4] = ECWDungeonRegionType::LowSpeed;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 1. x:%d, y:%d, tile1:%d, tile4:%d."), x, y, tile1, tile4);
				}
			}
		}
	}

	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile1 = xy2tile(x, y);
			if (!ArrayTileTileType.IsValidIndex(tile1))
				continue;

			int tile2 = xy2tile(x + 1, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile2))
				continue;

			int tile3 = xy2tile(x + 1, y);
			if (!ArrayTileTileType.IsValidIndex(tile3))
				continue;

			int tile4 = xy2tile(x, y + 1);
			if (!ArrayTileTileType.IsValidIndex(tile4))
				continue;

			ECWDungeonRegionType TempRegionType1 = ArrayTileType[tile1];
			ECWDungeonRegionType TempRegionType2 = ArrayTileType[tile2];
			ECWDungeonRegionType TempRegionType3 = ArrayTileType[tile3];
			ECWDungeonRegionType TempRegionType4 = ArrayTileType[tile4];
			if (TempRegionType1 == ECWDungeonRegionType::LowSpeed &&
				TempRegionType2 == ECWDungeonRegionType::LowSpeed)
			{
				if (TempRegionType3 == ECWDungeonRegionType::None && TempRegionType4 == ECWDungeonRegionType::None)
				{
					int index = rand() % 2;
					if (index == 0)
					{
						ArrayTileType[tile3] = ECWDungeonRegionType::LowSpeed;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 2. x:%d, y:%d, tile1:%d, tile3:%d, index:%d."), x, y, tile1, tile3, index);
					}
					else if (index == 1)
					{
						ArrayTileType[tile4] = ECWDungeonRegionType::LowSpeed;

						UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 2. x:%d, y:%d, tile1:%d, tile4:%d, index:%d."), x, y, tile1, tile4, index);
					}
				}
				else if (TempRegionType3 == ECWDungeonRegionType::None && 
					TempRegionType4 != ECWDungeonRegionType::None &&
					TempRegionType4 != ECWDungeonRegionType::LowSpeed)
				{
					ArrayTileType[tile3] = ECWDungeonRegionType::LowSpeed;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 2. x:%d, y:%d, tile1:%d, tile3:%d."), x, y, tile1, tile3);
				}
				else if (TempRegionType3 != ECWDungeonRegionType::None && 
					TempRegionType3 != ECWDungeonRegionType::LowSpeed && 
					TempRegionType4 == ECWDungeonRegionType::None)
				{
					ArrayTileType[tile4] = ECWDungeonRegionType::LowSpeed;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::FixLogicLowSpeedLine, ArrayTileType[tile] = ECWDungeonTileType::LowSpeed 2. x:%d, y:%d, tile1:%d, tile4:%d."), x, y, tile1, tile4);
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::ReplaceForbidToLowSpeed(FCWDungeonDataStruct* TempDungeonData)
{
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile = xy2tile(x, y);
			ECWDungeonRegionType TempRegionType = ArrayTileType[tile];
			if (TempRegionType == ECWDungeonRegionType::Forbid)
			{
				//ArrayTileType[tile] = ECWDungeonRegionType::LowSpeed;
				ArrayDungeonGrid[tile] = (int)ECWDungeonRegionTopography::LowLand;
				ArrayDungeonGrid_Z[tile] = -1;
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::ReplaceForbidToLowSpeed, ArrayTileType[tile] = ECWDungeonTileType::Forbid. x:%d, y:%d, tile:%d."), x, y, tile);
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::ReplaceDangerToHighSpeed(FCWDungeonDataStruct* TempDungeonData)
{
	for (int x = 0; x < DungeonWidth; ++x)
	{
		for (int y = 0; y < DungeonHeight; ++y)
		{
			int tile = xy2tile(x, y);
			ECWDungeonRegionType TempRegionType = ArrayTileType[tile];
			if (TempRegionType == ECWDungeonRegionType::Danger)
			{
				ArrayTileType[tile] = ECWDungeonRegionType::HighSpeed;

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("CWRandomDungeonGenerator::ReplaceDangerToHighSpeed, ArrayTileType[tile] = ECWDungeonTileType::HighSpeed. x:%d, y:%d, tile:%d."), x, y, tile);
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion(FCWLogicRegion ParamALogicRegion, FCWLogicRegion ParamBLogicRegion, int32& ParamOutX, int32& ParamOutY)
{
	ParamOutX = 0;
	ParamOutY = 0;
	if (FMath::Abs(ParamALogicRegion.X - ParamBLogicRegion.X) > 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion Fail. FMath::Abs(ParamALogicRegion.X - ParamBLogicRegion.X) > 1, ParamALogicRegion.X:%d, ParamALogicRegion.Y:%d, ParamBLogicRegion.X:%d, ParamBLogicRegion.Y:%d."), ParamALogicRegion.X, ParamALogicRegion.Y, ParamBLogicRegion.X, ParamBLogicRegion.Y);
		return false;
	}

	if (FMath::Abs(ParamALogicRegion.Y - ParamBLogicRegion.Y) > 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateIntersectionStartByLogicRegion Fail. FMath::Abs(ParamALogicRegion.Y - ParamBLogicRegion.Y) > 1, ParamALogicRegion.X:%d, ParamALogicRegion.Y:%d, ParamBLogicRegion.X:%d, ParamBLogicRegion.Y:%d."), ParamALogicRegion.X, ParamALogicRegion.Y, ParamBLogicRegion.X, ParamBLogicRegion.Y);
		return false;
	}

	if (ParamALogicRegion.X - ParamBLogicRegion.X == -1)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			ParamOutX = ParamBLogicRegion.XBegin;
			ParamOutY = ParamBLogicRegion.YBegin;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			ParamOutX = ParamBLogicRegion.XBegin;
			//ParamOutY = (ParamBLogicRegion.YBegin + ParamBLogicRegion.YEnd) / 2;
			ParamOutY = RandomInt(ParamBLogicRegion.YBegin, ParamBLogicRegion.YEnd);
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			ParamOutX = ParamBLogicRegion.XBegin;
			ParamOutY = ParamBLogicRegion.YEnd;
		}

		return true;
	}
	else if (ParamALogicRegion.X - ParamBLogicRegion.X == 0)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			//ParamOutX = (ParamBLogicRegion.XBegin + ParamBLogicRegion.XEnd) / 2;
			ParamOutX = RandomInt(ParamBLogicRegion.XBegin, ParamBLogicRegion.XEnd);
			ParamOutY = ParamBLogicRegion.YBegin;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			return false;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			//ParamOutX = (ParamBLogicRegion.XBegin + ParamBLogicRegion.XEnd) / 2;
			ParamOutX = RandomInt(ParamBLogicRegion.XBegin, ParamBLogicRegion.XEnd);
			ParamOutY = ParamBLogicRegion.YEnd;
		}

		return true;
	}
	else if (ParamALogicRegion.X - ParamBLogicRegion.X == 1)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			ParamOutX = ParamBLogicRegion.XEnd;
			ParamOutY = ParamBLogicRegion.YBegin;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			ParamOutX = ParamBLogicRegion.XEnd;
			//ParamOutY = (ParamBLogicRegion.YBegin + ParamBLogicRegion.YEnd) / 2;
			ParamOutY = RandomInt(ParamBLogicRegion.YBegin, ParamBLogicRegion.YEnd);
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			ParamOutX = ParamBLogicRegion.XEnd;
			ParamOutY = ParamBLogicRegion.YEnd;
		}

		return true;
	}

	return false;
}

bool ACWRandomDungeonGenerator::GenerateIntersectionEndByLogicRegion(FCWLogicRegion ParamALogicRegion, FCWLogicRegion ParamBLogicRegion, int32& ParamOutX, int32& ParamOutY)
{
	ParamOutX = 0;
	ParamOutY = 0;
	if (FMath::Abs(ParamALogicRegion.X - ParamBLogicRegion.X) > 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateIntersectionEndByLogicRegion Fail. FMath::Abs(ParamALogicRegion.X - ParamBLogicRegion.X) > 1, ParamALogicRegion.X:%d, ParamALogicRegion.Y:%d, ParamBLogicRegion.X:%d, ParamBLogicRegion.Y:%d."), ParamALogicRegion.X, ParamALogicRegion.Y, ParamBLogicRegion.X, ParamBLogicRegion.Y);
		return false;
	}

	if (FMath::Abs(ParamALogicRegion.Y - ParamBLogicRegion.Y) > 1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateIntersectionEndByLogicRegion Fail. FMath::Abs(ParamALogicRegion.Y - ParamBLogicRegion.Y) > 1, ParamALogicRegion.X:%d, ParamALogicRegion.Y:%d, ParamBLogicRegion.X:%d, ParamBLogicRegion.Y:%d."), ParamALogicRegion.X, ParamALogicRegion.Y, ParamBLogicRegion.X, ParamBLogicRegion.Y);
		return false;
	}

	if (ParamALogicRegion.X - ParamBLogicRegion.X == -1)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			ParamOutX = ParamALogicRegion.XEnd;
			ParamOutY = ParamALogicRegion.YEnd;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			ParamOutX = ParamALogicRegion.XEnd;
			//ParamOutY = (ParamALogicRegion.YBegin + ParamALogicRegion.YEnd) / 2;
			ParamOutY = RandomInt(ParamALogicRegion.YBegin, ParamALogicRegion.YEnd);
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			ParamOutX = ParamALogicRegion.XEnd;
			ParamOutY = ParamALogicRegion.YBegin;
		}

		return true;
	}
	else if (ParamALogicRegion.X - ParamBLogicRegion.X == 0)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			//ParamOutX = (ParamALogicRegion.XBegin + ParamALogicRegion.XEnd) / 2;
			ParamOutX = RandomInt(ParamALogicRegion.XBegin, ParamALogicRegion.XEnd);
			ParamOutY = ParamALogicRegion.YEnd;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			return false;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			//ParamOutX = (ParamALogicRegion.XBegin + ParamALogicRegion.XEnd) / 2;
			ParamOutX = RandomInt(ParamALogicRegion.XBegin, ParamALogicRegion.XEnd);
			ParamOutY = ParamALogicRegion.YBegin;
		}

		return true;
	}
	else if (ParamALogicRegion.X - ParamBLogicRegion.X == 1)
	{
		if (ParamALogicRegion.Y - ParamBLogicRegion.Y == -1)
		{
			ParamOutX = ParamALogicRegion.XBegin;
			ParamOutY = ParamALogicRegion.YEnd;
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 0)
		{
			ParamOutX = ParamALogicRegion.XBegin;
			//ParamOutY = (ParamALogicRegion.YBegin + ParamALogicRegion.YEnd) / 2;
			ParamOutY = RandomInt(ParamALogicRegion.YBegin, ParamALogicRegion.YEnd);
		}
		else if (ParamALogicRegion.Y - ParamBLogicRegion.Y == 1)
		{
			ParamOutX = ParamALogicRegion.XBegin;
			ParamOutY = ParamALogicRegion.YBegin;
		}

		return true;
	}

	return false;
}

bool ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion(
	FCWDungeonDataStruct* TempDungeonData,
	int32 ParamSpawnRegionRightX,
	int32 ParamSpawnRegionRightY,
	int32 ParamSpawnRegionLeftX,
	int32 ParamSpawnRegionLeftY,
	int32& ParamOutSymmetryRegionRightX,
	int32& ParamOutSymmetryRegionRightY,
	int32& ParamOutSymmetryRegionLeftX,
	int32& ParamOutSymmetryRegionLeftY)
{
	check(TempDungeonData);
	std::vector<int32> TempArrayDungeonZoneNum = FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(TempDungeonData->DungeonZoneNum);
	if (TempArrayDungeonZoneNum.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, TempArrayDungeonZoneNum.size() != 2, TempArrayDungeonZoneNum.size():%d."), TempArrayDungeonZoneNum.size());
		return false;
	}

	int32 TempLogicWidthNum = TempArrayDungeonZoneNum[0];
	int32 TempLogicHeightNum = TempArrayDungeonZoneNum[1];


	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionRightX:%d."), ParamSpawnRegionRightX);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionRightY:%d."), ParamSpawnRegionRightY);
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, FMath::Cos(180.0f):%f, FMath::Sin(180.0f):%f"), FMath::Cos(FMath::DegreesToRadians(180.0f)), FMath::Sin(FMath::DegreesToRadians(180.0f)));
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, TempSpawnRegionRightX * FMath::Cos(180.0f):%f, TempSpawnRegionRightY * FMath::Sin(180.0f):%f."), TempSpawnRegionRightX * FMath::Cos(FMath::DegreesToRadians(180.0f)), TempSpawnRegionRightY * FMath::Sin(FMath::DegreesToRadians(180.0f)));
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, TempSpawnRegionRightX * FMath::Sin(180.0f):%f, TempSpawnRegionRightY * FMath::Cos(180.0f):%f."), TempSpawnRegionRightX * FMath::Sin(FMath::DegreesToRadians(180.0f)), TempSpawnRegionRightY * FMath::Cos(FMath::DegreesToRadians(180.0f)));

	//旋转矩阵
	//ParamOutSymmetryRegionRightX = TempSpawnRegionRightX * FMath::Cos(FMath::DegreesToRadians(180.0f)) - TempSpawnRegionRightY * FMath::Sin(FMath::DegreesToRadians(180.0f));
	//ParamOutSymmetryRegionRightY = TempSpawnRegionRightX * FMath::Sin(FMath::DegreesToRadians(180.0f)) + TempSpawnRegionRightY * FMath::Cos(FMath::DegreesToRadians(180.0f));
	ParamOutSymmetryRegionRightX = -(float)((ParamSpawnRegionLeftY - ParamSpawnRegionRightY) / (float)(ParamSpawnRegionLeftX - ParamSpawnRegionRightX)) * ((float)(TempLogicHeightNum - 1) - (float)(ParamSpawnRegionRightY + ParamSpawnRegionLeftY) / 2.0f) + (float)(ParamSpawnRegionRightX + ParamSpawnRegionLeftX) / 2.0f;
	ParamOutSymmetryRegionRightY = TempLogicHeightNum - 1;

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamOutSymmetryRegionRightX:%d."), ParamOutSymmetryRegionRightX);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamOutSymmetryRegionRightY:%d."), ParamOutSymmetryRegionRightY);

	if (ParamOutSymmetryRegionRightX < 0)
	{
		ParamOutSymmetryRegionRightX = 0;
	}

	if (ParamOutSymmetryRegionRightX >= TempLogicWidthNum)
	{
		ParamOutSymmetryRegionRightX = TempLogicWidthNum - 1;
	}

	if (ParamOutSymmetryRegionRightY < 0)
	{
		ParamOutSymmetryRegionRightY = 0;
	}

	if (ParamOutSymmetryRegionRightY >= TempLogicHeightNum)
	{
		ParamOutSymmetryRegionRightY = TempLogicHeightNum - 1;
	}

	if (ParamSpawnRegionRightX == ParamOutSymmetryRegionRightX &&
		ParamSpawnRegionRightY == ParamOutSymmetryRegionRightY)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionRightX == ParamOutSymmetryRegionRightX && ParamSpawnRegionRightY == ParamOutSymmetryRegionRightY, ParamSpawnRegionRightX:%d, ParamSpawnRegionRightY:%d."), ParamSpawnRegionRightX, ParamSpawnRegionRightY);
		return false;
	}

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionLeftX:%d."), ParamSpawnRegionLeftX);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionLeftY:%d."), ParamSpawnRegionLeftY);
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, FMath::Cos(180.0f):%f, FMath::Sin(180.0f):%f"), FMath::Cos(FMath::DegreesToRadians(180.0f)), FMath::Sin(FMath::DegreesToRadians(180.0f)));
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, TempSpawnRegionLeftX * FMath::Cos(180.0f):%f, TempSpawnRegionLeftY * FMath::Sin(180.0f):%f."), TempSpawnRegionLeftX * FMath::Cos(FMath::DegreesToRadians(180.0f)), TempSpawnRegionLeftY * FMath::Sin(FMath::DegreesToRadians(180.0f)));
	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, TempSpawnRegionLeftX * FMath::Sin(180.0f):%f, TempSpawnRegionLeftY * FMath::Cos(180.0f):%f."), TempSpawnRegionLeftX * FMath::Sin(FMath::DegreesToRadians(180.0f)), TempSpawnRegionLeftY * FMath::Cos(FMath::DegreesToRadians(180.0f)));

	//旋转矩阵
	//ParamOutSymmetryRegionLeftX = TempSpawnRegionLeftX * FMath::Cos(FMath::DegreesToRadians(180.0f)) - TempSpawnRegionLeftY * FMath::Sin(FMath::DegreesToRadians(180.0f));
	//ParamOutSymmetryRegionLeftY = TempSpawnRegionLeftX * FMath::Sin(FMath::DegreesToRadians(180.0f)) + TempSpawnRegionLeftY * FMath::Cos(FMath::DegreesToRadians(180.0f));
	ParamOutSymmetryRegionLeftX = -(float)((ParamSpawnRegionLeftY - ParamSpawnRegionRightY) / (float)(ParamSpawnRegionLeftX - ParamSpawnRegionRightX)) * ((float)(0.0f) - (float)(ParamSpawnRegionRightY + ParamSpawnRegionLeftY) / 2.0f) + (float)(ParamSpawnRegionRightX + ParamSpawnRegionLeftX) / 2.0f;
	ParamOutSymmetryRegionLeftY = 0;

	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamOutSymmetryRegionLeftX:%d."), ParamOutSymmetryRegionLeftX);
	UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamOutSymmetryRegionLeftY:%d."), ParamOutSymmetryRegionLeftY);

	if (ParamOutSymmetryRegionLeftX < 0)
	{
		ParamOutSymmetryRegionLeftX = 0;
	}

	if (ParamOutSymmetryRegionLeftX >= TempLogicWidthNum)
	{
		ParamOutSymmetryRegionLeftX = TempLogicWidthNum - 1;
	}

	if (ParamOutSymmetryRegionLeftY < 0)
	{
		ParamOutSymmetryRegionLeftY = 0;
	}

	if (ParamOutSymmetryRegionLeftY >= TempLogicHeightNum)
	{
		ParamOutSymmetryRegionLeftY = TempLogicHeightNum - 1;
	}

	if (ParamSpawnRegionLeftX == ParamOutSymmetryRegionLeftX &&
		ParamSpawnRegionLeftY == ParamOutSymmetryRegionLeftY)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamSpawnRegionLeftX == ParamOutSymmetryRegionLeftX && ParamSpawnRegionLeftY == ParamOutSymmetryRegionLeftY, ParamSpawnRegionLeftX:%d, ParamSpawnRegionLeftY : %d."), ParamSpawnRegionLeftX, ParamSpawnRegionLeftY);
		return false;
	}

	if (ParamOutSymmetryRegionRightX == ParamOutSymmetryRegionLeftX && ParamOutSymmetryRegionRightY == ParamOutSymmetryRegionLeftY)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindSymmetryLogicRegionFromSpawnRegion, ParamOutSymmetryRegionRightX == ParamOutSymmetryRegionLeftX && ParamOutSymmetryRegionRightY == ParamOutSymmetryRegionLeftY, ParamOutSymmetryRegionRightX:%d, ParamOutSymmetryRegionRightY:%d."), ParamOutSymmetryRegionRightX, ParamOutSymmetryRegionRightY);
		return false;
	}

	return true;
}

int ACWRandomDungeonGenerator::isCanPassForRegionSplitLine(int px, int py, int cx, int cy)
{
	return true;
}

int ACWRandomDungeonGenerator::isCanPassForRegionGoThroughLine(int px, int py, int cx, int cy)
{
	return s_this->canPassForRegionGoThroughLine(cx, cy);
}

int ACWRandomDungeonGenerator::isCanPassForTileGoThroughLine(int px, int py, int cx, int cy)
{
	return s_this->canPassForTileGoThroughLine(cx, cy);
}

int ACWRandomDungeonGenerator::cost(int px, int py, int cx, int cy)
{
	if (px == 0 || py == 0 || px == s_this->LogicWidthNum - 1 || py == s_this->LogicHeightNum - 1)
	{
		if (cx == 0 || cy == 0 || cx == s_this->LogicWidthNum - 1 || cy == s_this->LogicHeightNum - 1)
		{
			return 1;
		}
		else
		{
			return 2;
		}
	}
	else
	{
		if (cx == 0 || cy == 0 || cx == s_this->LogicWidthNum - 1 || cy == s_this->LogicHeightNum - 1)
		{
			return 1;
		}
		else
		{
			return 2;
		}
	}
	return 1;
}

bool ACWRandomDungeonGenerator::canPassForRegionGoThroughLine(int cx, int cy)
{
	if (!MapLogicRegion[cx][cy].bIsValid)
		return false;

	if (MapLogicRegion[cx][cy].RegionType == ECWDungeonRegionType::Forbid)
		return false;

	return true;
}

bool ACWRandomDungeonGenerator::canPassForTileGoThroughLine(int cx, int cy)
{
	int tile = xy2tile(cx, cy);
	if (!ArrayTileTileType.IsValidIndex(tile))
		return false;

	//ArrayTileTileType[tile] == ECWDungeonTileType::
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonForFlatLand()
{
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonForHighLand()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();

	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionHeightFixMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionHeightFixMinMaxFromString(TempDungeonData->ArrayDungeonRegionHeightFixMinMax);
	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionUpperAreaSideMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionUpperAreaSideMinMaxFromString(TempDungeonData->ArrayDungeonRegionUpperAreaSideMinMax);
	std::vector<int32> TempArrayHeightPrefer = FCWDungeonDataUtils::GetArrayHeightPreferFromString(TempDungeonData->HeightPrefer);
	std::vector<int32> TempArrayHeightLimit = FCWDungeonDataUtils::GetArrayDungeonRegionHasWall(TempDungeonData->HeightLimit);

	if (TempArrayArrayDungeonRegionHeightFixMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayArrayDungeonRegionHeightFixMinMax.size() != 2, TempArrayArrayDungeonRegionHeightFixMinMax.size():%d."), TempArrayArrayDungeonRegionHeightFixMinMax.size());
		return false;
	}

	if (TempArrayArrayDungeonRegionUpperAreaSideMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayArrayDungeonRegionUpperAreaSideMinMax.size() != 2, TempArrayArrayDungeonRegionUpperAreaSideMinMax.size():%d."), TempArrayArrayDungeonRegionUpperAreaSideMinMax.size());
		return false;
	}

	if (TempArrayHeightPrefer.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayHeightPrefer.size() != 2, TempArrayHeightPrefer.size():%d."), TempArrayHeightPrefer.size());
		return false;
	}

	if (TempArrayHeightLimit.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayHeightLimit.size() != 2, TempArrayHeightLimit.size():%d."), TempArrayHeightLimit.size());
		return false;
	}
	
	std::vector<int32> TempArrayHighCountMinMax = TempArrayArrayDungeonRegionHeightFixMinMax[0];
	std::vector<int32> TempArrayHighWidthMinMax = TempArrayArrayDungeonRegionUpperAreaSideMinMax[0];
	std::vector<int32> TempArrayHighHeightMinMax = TempArrayArrayDungeonRegionUpperAreaSideMinMax[1];
	if (TempArrayHighCountMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayHighCountMinMax.size() != 2, TempArrayHighCountMinMax.size():%d."), TempArrayHighCountMinMax.size());
		return false;
	}

	if (TempArrayHighWidthMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayHighWidthMinMax.size() != 2, TempArrayHighWidthMinMax.size():%d."), TempArrayHighWidthMinMax.size());
		return false;
	}

	if (TempArrayHighHeightMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayHighHeightMinMax.size() != 2, TempArrayHighHeightMinMax.size():%d."), TempArrayHighHeightMinMax.size());
		return false;
	}

	int32 TempHighCountMin = TempArrayHighCountMinMax[0];
	int32 TempHighCountMax = TempArrayHighCountMinMax[1];
	int32 TempArrayHighWidthMin = TempArrayHighWidthMinMax[0];
	int32 TempArrayHighWidthMax = TempArrayHighWidthMinMax[1];
	int32 TempArrayHighHeightMin = TempArrayHighHeightMinMax[0];
	int32 TempArrayHighHeightMax = TempArrayHighHeightMinMax[1];
	int32 TempHeightPreferForHeigh = TempArrayHeightPrefer[0];
	int32 TempHeightLimitMin = TempArrayHeightLimit[0];
	int32 TempHeightLimitMax = TempArrayHeightLimit[1];

	int32 TempHighCount = TempHighCountMax - TempHighCountMin;
	if (TempHighCount <= 0)
	{
		TempHighCount = TempHighCountMin;
	}
	else
	{
		TempHighCount = rand() % TempHighCount + TempHighCountMin;
	}

	//if (TempHighCount <= 0)
	//{
	//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempHighCount <= 0, TempHighCount:%d."), TempHighCount);
	//	return false;
	//}

	for (int i = 0; i < TempHighCount; ++i)
	{
		int32 TempHighWidth = TempArrayHighWidthMax - TempArrayHighWidthMin;
		if (TempHighWidth <= 0)
		{
			TempHighWidth = TempArrayHighWidthMin;
		}
		else
		{
			TempHighWidth = rand() % TempHighWidth + TempArrayHighWidthMin;
		}

		if (TempHighWidth <= 0)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempHighWidth <= 0, TempHighWidth:%d."), TempHighWidth);
			continue;
		}

		int32 TempHighHeight = TempArrayHighHeightMax - TempArrayHighHeightMin;
		if (TempHighHeight <= 0)
		{
			TempHighHeight = TempArrayHighHeightMin;
		}
		else
		{
			TempHighHeight = rand() % TempHighHeight + TempArrayHighHeightMin;
		}

		if (TempHighHeight <= 0)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempHighHeight <= 0, TempHighHeight:%d."), TempHighHeight);
			continue;
		}

		std::vector<ECWEdgeOutSideDecorateCoord> TempArrayCoord = AnalyzeHeightPrefer(TempHeightPreferForHeigh);
		if (TempArrayCoord.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand fail, TempArrayCoord.empty()."));
			continue;
		}
		int32 TempIndexCoord = rand() % TempArrayCoord.size();
		ECWEdgeOutSideDecorateCoord TempCoord = TempArrayCoord[TempIndexCoord];

		GenerateDungeonRegionTopographyByCoord(TempDungeonData, TempCoord, TempHighWidth, TempHighHeight, ECWDungeonRegionTopography::HighLand);
	}


	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonRegionTopographyByCoord(FCWDungeonDataStruct* ParamDungeonData, ECWEdgeOutSideDecorateCoord ParamCoord, int32 ParamWidth, int32 ParamHeight, ECWDungeonRegionTopography ParamDungeonRegionTopography)
{
	check(ParamDungeonData);

	int32 TempWidth01 = 0;
	int32 TempWidth12 = ParamDungeonData->DungeonWidth / 3;
	int32 TempWidth23 = ParamDungeonData->DungeonWidth / 3 * 2;
	int32 TempWidth34 = ParamDungeonData->DungeonWidth - 1;

	int32 TempHeight01 = 0;
	int32 TempHeight12 = ParamDungeonData->DungeonHeight / 3;
	int32 TempHeight23 = ParamDungeonData->DungeonHeight / 3 * 2;
	int32 TempHeight34 = ParamDungeonData->DungeonHeight - 1;

	int32 TempWidthBegin = 0;
	int32 TempWidthEnd = ParamDungeonData->DungeonWidth - 1;
	int32 TempHeightBegin = 0;
	int32 TempHeightEnd = ParamDungeonData->DungeonHeight - 1;

	//*边缘8个区域的枚举 下边 : 1, 上边 : 2, 右边 : 4, 左边 : 8, 右下角 : 16, 右上角 : 32, 左上角 : 64, 左下角 : 128
	switch (ParamCoord)
	{
	case ECWEdgeOutSideDecorateCoord::YZero:
	{
		TempWidthBegin = TempWidth12;
		TempWidthEnd = TempWidth23;
		TempHeightBegin = TempWidth01;
		TempHeightEnd = TempHeight12;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YHeightMax:
	{
		TempWidthBegin = TempWidth12;
		TempWidthEnd = TempWidth23;
		TempHeightBegin = TempHeight23;
		TempHeightEnd = TempHeight34;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZero:
	{
		TempWidthBegin = TempWidth01;
		TempWidthEnd = TempWidth12;
		TempHeightBegin = TempHeight12;
		TempHeightEnd = TempHeight23;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMax:
	{
		TempWidthBegin = TempWidth23;
		TempWidthEnd = TempWidth34;
		TempHeightBegin = TempHeight12;
		TempHeightEnd = TempHeight23;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZeroYZero:
	{
		TempWidthBegin = TempWidth01;
		TempWidthEnd = TempWidth12;
		TempHeightBegin = TempHeight01;
		TempHeightEnd = TempHeight12;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
	{
		TempWidthBegin = TempWidth01;
		TempWidthEnd = TempWidth12;
		TempHeightBegin = TempHeight23;
		TempHeightEnd = TempHeight34;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
	{
		TempWidthBegin = TempWidth23;
		TempWidthEnd = TempWidth34;
		TempHeightBegin = TempHeight23;
		TempHeightEnd = TempHeight34;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
	{
		TempWidthBegin = TempWidth23;
		TempWidthEnd = TempWidth34;
		TempHeightBegin = TempHeight01;
		TempHeightEnd = TempHeight12;
	}
	break;
	case ECWEdgeOutSideDecorateCoord::Center:
	{
		TempWidthBegin = TempWidth12;
		TempWidthEnd = TempWidth23;
		TempHeightBegin = TempHeight12;
		TempHeightEnd = TempHeight23;
	}
	break;
	}

	int x = 0;
	int y = 0;
	int ri = 0;
	bool isThereRepetition = false;
	do
	{
		if (ri >= 1000)
			break;

		x = RandomInt(TempWidthBegin, TempWidthEnd);
		y = RandomInt(TempHeightBegin, TempHeightEnd);
		x += offsetX;
		y += offsetY;


		ri++;

		//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForHighLand, x:%d, y:%d, i:%d."), x, y, i);
		isThereRepetition = IsThereRepetitionForTopography(x, y);
	} while (isThereRepetition);


	//RegionId == 0为基本地貌
	int32 TempRegionId = 0;
	PlaceRandomRegionTopography(TempRegionId, ParamDungeonRegionTopography, x, y, ParamWidth, ParamHeight);

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonRegionToHelp(FCWDungeonDataStruct* ParamDungeonData, int32 ParamWidth, int32 ParamHeight, int32 ParamDungeonRegionId)
{
	check(ParamDungeonData);
	int32 TempWidthBegin = 0;
	int32 TempWidthEnd = ParamDungeonData->DungeonWidth - ParamWidth - 1;
	int32 TempHeightBegin = 0;
	int32 TempHeightEnd = ParamDungeonData->DungeonHeight - ParamHeight - 1;


	int x = 0;
	int y = 0;
	int ri = 0;
	bool isThereRepetition = false;
	do
	{
		if (ri >= 1000)
			break;

		x = RandomInt(TempWidthBegin, TempWidthEnd);
		y = RandomInt(TempHeightBegin, TempHeightEnd);
		x += offsetX;
		y += offsetY;


		ri++;

		//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonRegionToHelp, x:%d, y:%d, i:%d."), x, y, i);
		isThereRepetition = IsThereRepetitionForRegion(x, y);
	} while (isThereRepetition);

	PlaceRandomRegion(ParamDungeonRegionId, x, y, ParamWidth, ParamHeight);

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonForLowLand()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();

	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionHeightFixMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionHeightFixMinMaxFromString(TempDungeonData->ArrayDungeonRegionHeightFixMinMax);
	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionLowerAreaSideMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionLowerAreaSideMinMaxFromString(TempDungeonData->ArrayDungeonRegionLowerAreaSideMinMax);
	std::vector<int32> TempArrayHeightPrefer = FCWDungeonDataUtils::GetArrayHeightPreferFromString(TempDungeonData->HeightPrefer);
	std::vector<int32> TempArrayHeightLimit = FCWDungeonDataUtils::GetArrayDungeonRegionHasWall(TempDungeonData->HeightLimit);

	if (TempArrayArrayDungeonRegionHeightFixMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayArrayDungeonRegionHeightFixMinMax.size() != 2, TempArrayArrayDungeonRegionHeightFixMinMax.size():%d."), TempArrayArrayDungeonRegionHeightFixMinMax.size());
		return false;
	}

	if (TempArrayArrayDungeonRegionLowerAreaSideMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayArrayDungeonRegionLowerAreaSideMinMax.size() != 2, TempArrayArrayDungeonRegionLowerAreaSideMinMax.size():%d."), TempArrayArrayDungeonRegionLowerAreaSideMinMax.size());
		return false;
	}

	if (TempArrayHeightPrefer.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayHeightPrefer.size() != 2, TempArrayHeightPrefer.size():%d."), TempArrayHeightPrefer.size());
		return false;
	}

	if (TempArrayHeightLimit.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayHeightLimit.size() != 2, TempArrayHeightLimit.size():%d."), TempArrayHeightLimit.size());
		return false;
	}

	std::vector<int32> TempArrayLowerCountMinMax = TempArrayArrayDungeonRegionHeightFixMinMax[1];
	std::vector<int32> TempArrayLowerWidthMinMax = TempArrayArrayDungeonRegionLowerAreaSideMinMax[0];
	std::vector<int32> TempArrayLowerHeightMinMax = TempArrayArrayDungeonRegionLowerAreaSideMinMax[1];
	if (TempArrayLowerCountMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayLowerCountMinMax.size() != 2, TempArrayHighCountMinMax.size():%d."), TempArrayLowerCountMinMax.size());
		return false;
	}

	if (TempArrayLowerWidthMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayLowerWidthMinMax.size() != 2, TempArrayLowerWidthMinMax.size():%d."), TempArrayLowerWidthMinMax.size());
		return false;
	}

	if (TempArrayLowerHeightMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayLowerHeightMinMax.size() != 2, TempArrayHighHeightMinMax.size():%d."), TempArrayLowerHeightMinMax.size());
		return false;
	}

	int32 TempLowerCountMin = TempArrayLowerCountMinMax[0];
	int32 TempLowerCountMax = TempArrayLowerCountMinMax[1];
	int32 TempArrayLowerWidthMin = TempArrayLowerWidthMinMax[0];
	int32 TempArrayLowerWidthMax = TempArrayLowerWidthMinMax[1];
	int32 TempArrayLowerHeightMin = TempArrayLowerHeightMinMax[0];
	int32 TempArrayLowerHeightMax = TempArrayLowerHeightMinMax[1];
	int32 TempHeightPreferForLower = TempArrayHeightPrefer[1];
	int32 TempHeightLimitMin = TempArrayHeightLimit[0];
	int32 TempHeightLimitMax = TempArrayHeightLimit[1];

	int32 TempLowerCount = TempLowerCountMax - TempLowerCountMin;
	if (TempLowerCount <= 0)
	{
		TempLowerCount = TempLowerCountMin;
	}
	else
	{
		TempLowerCount = rand() % TempLowerCount + TempLowerCountMin;
	}

	//if (TempLowerCount <= 0)
	//{
	//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempLowerCount <= 0, TempLowerCount:%d."), TempLowerCount);
	//	return false;
	//}


	for (int i = 0; i < TempLowerCount; ++i)
	{
		int32 TempLowerWidth = TempArrayLowerWidthMax - TempArrayLowerWidthMin;
		if (TempLowerWidth <= 0)
		{
			TempLowerWidth = TempArrayLowerWidthMin;
		}
		else
		{
			TempLowerWidth = rand() % TempLowerWidth + TempArrayLowerWidthMin;
		}

		if (TempLowerWidth <= 0)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempLowerWidth <= 0, TempLowerWidth:%d."), TempLowerWidth);
			continue;
		}

		int32 TempLowerHeight = TempArrayLowerHeightMax - TempArrayLowerHeightMin;
		if (TempLowerHeight <= 0)
		{
			TempLowerHeight = TempArrayLowerHeightMin;
		}
		else
		{
			TempLowerHeight = rand() % TempLowerHeight + TempArrayLowerHeightMin;
		}

		if (TempLowerHeight <= 0)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempLowerHeight <= 0, TempLowerHeight:%d."), TempLowerHeight);
			continue;
		}

		std::vector<ECWEdgeOutSideDecorateCoord> TempArrayCoord = AnalyzeHeightPrefer(TempHeightPreferForLower);
		if (TempArrayCoord.empty())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForLowLand fail, TempArrayCoord.empty()."));
			continue;
		}
		int32 TempIndexCoord = rand() % TempArrayCoord.size();
		ECWEdgeOutSideDecorateCoord TempCoord = TempArrayCoord[TempIndexCoord];

		GenerateDungeonRegionTopographyByCoord(TempDungeonData, TempCoord, TempLowerWidth, TempLowerHeight, ECWDungeonRegionTopography::LowLand);
	}


	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			int TempDungeonRegionTopography = ArrayDungeonGrid[tile];
			if (TempDungeonRegionTopography <= 0)
				continue;

			int32 HighLandCount = 0;
			int32 LowLandCount = 0;
			TempDungeonRegionTopography = this->GetRandomDungeonRegionTopography(tile, HighLandCount, LowLandCount);
			ArrayDungeonGrid[tile] = TempDungeonRegionTopography;

			int TempRealZ = HighLandCount - LowLandCount;
			if (TempRealZ < TempHeightLimitMin)
				TempRealZ = TempHeightLimitMin;
			if (TempRealZ > TempHeightLimitMax)
				TempRealZ = TempHeightLimitMax;
			ArrayDungeonGrid_Z[tile] = TempRealZ;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonForRegion()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (TempDungeonData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempDungeonData == nullptr."));
		return false;
	}

	ECWDungeonRegionStyle TempDungeonStyle = (ECWDungeonRegionStyle)TempDungeonData->Style;
	std::vector<int32> TempArrayDungeonRegionId = FCWDungeonDataUtils::GetArrayDungeonRegionIdFromString(TempDungeonData->ArrayDungeonRegionId);
	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionRandomMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionRandomMinMax(TempDungeonData->ArrayArrayDungeonRegionRandomMinMax);
	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionWidthMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionWidthMinMax(TempDungeonData->ArrayArrayDungeonRegionWidthMinMax);
	std::vector<std::vector<int32> > TempArrayArrayDungeonRegionHeightMinMax = FCWDungeonDataUtils::GetArrayArrayDungeonRegionHeightMinMax(TempDungeonData->ArrayArrayDungeonRegionHeightMinMax);
	if (TempArrayDungeonRegionId.empty())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionId.empty()."));
		return false;
	}

	if (TempArrayDungeonRegionId.size() != TempArrayArrayDungeonRegionRandomMinMax.size())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionId.size():%d, TempArrayArrayDungeonRegionRandomMinMax.size():%d."), TempArrayDungeonRegionId.size(), TempArrayArrayDungeonRegionRandomMinMax.size());
		return false;
	}

	if (TempArrayDungeonRegionId.size() != TempArrayArrayDungeonRegionWidthMinMax.size())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionId.size():%d, TempArrayArrayDungeonRegionWidthMinMax.size():%d."), TempArrayDungeonRegionId.size(), TempArrayArrayDungeonRegionWidthMinMax.size());
		return false;
	}

	if (TempArrayDungeonRegionId.size() != TempArrayArrayDungeonRegionHeightMinMax.size())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionId.size():%d, TempArrayArrayDungeonRegionHeightMinMax.size():%d."), TempArrayDungeonRegionId.size(), TempArrayArrayDungeonRegionHeightMinMax.size());
		return false;
	}

	//RandomShuffle(
	//	TempArrayDungeonRegionId,
	//	TempArrayArrayDungeonRegionRandomMinMax,
	//	TempArrayArrayDungeonRegionSideMinMax);

	for (int i = 0; i < TempArrayDungeonRegionId.size(); ++i)
	{
		int32 TempDungeonRegionId = TempArrayDungeonRegionId[i];

		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempDungeonRegionId);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion, TempDungeonRegionData == nullptr, TempDungeonRegionId:%d."), TempDungeonRegionId);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle != ECWDungeonRegionStyle::Common && TempRegionStyle != TempDungeonStyle)
			continue;

		std::vector<int32> TempArrayDungeonRegionRandomMinMax = TempArrayArrayDungeonRegionRandomMinMax[i];
		if (TempArrayDungeonRegionRandomMinMax.size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionRandomMinMax.size() != 2, TempArrayDungeonRegionRandomMinMax.size():%d."), TempArrayDungeonRegionRandomMinMax.size());
			continue;
		}

		int32 TempRandomMin = TempArrayDungeonRegionRandomMinMax[0];
		int32 TempRandomMax = TempArrayDungeonRegionRandomMinMax[1];
		int32 TempRandom = TempRandomMax - TempRandomMin;
		if (TempRandom <= 0)
		{
			TempRandom = TempRandomMin;
		}
		else
		{
			TempRandom = rand() % TempRandom + TempRandomMin;
		}

		//if (TempRandom <= 0)
		//{
		//	UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempRandom <= 0, TempRandom:%d."), TempRandom);
		//	continue;
		//}

		for (int m = 0; m < TempRandom; ++m)
		{
			std::vector<int32> TempArrayDungeonRegionWidthMinMax = TempArrayArrayDungeonRegionWidthMinMax[i];
			if (TempArrayDungeonRegionWidthMinMax.size() != 2)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionWidthMinMax.size() != 2, TempArrayDungeonRegionWidthMinMax.size():%d."), TempArrayDungeonRegionWidthMinMax.size());
				continue;
			}
			int32 TempDungeonRegionWidthMin = TempArrayDungeonRegionWidthMinMax[0];
			int32 TempDungeonRegionWidthMax = TempArrayDungeonRegionWidthMinMax[1];
			int32 TempDungeonRegionWidth = TempDungeonRegionWidthMax - TempDungeonRegionWidthMin;
			if (TempDungeonRegionWidth <= 0)
			{
				TempDungeonRegionWidth = TempDungeonRegionWidthMin;
			}
			else
			{
				TempDungeonRegionWidth = rand() % TempDungeonRegionWidth + TempDungeonRegionWidthMin;
			}

			if (TempDungeonRegionWidth <= 0)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempDungeonRegionWidth <= 0, TempDungeonRegionWidth:%d."), TempDungeonRegionWidth);
				continue;
			}

			std::vector<int32> TempArrayDungeonRegionHeightMinMax = TempArrayArrayDungeonRegionHeightMinMax[i];
			if (TempArrayDungeonRegionHeightMinMax.size() != 2)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempArrayDungeonRegionHeightMinMax.size() != 2, TempArrayDungeonRegionHeightMinMax.size():%d."), TempArrayDungeonRegionHeightMinMax.size());
				continue;
			}
			int32 TempDungeonRegionHeightMin = TempArrayDungeonRegionHeightMinMax[0];
			int32 TempDungeonRegionHeightMax = TempArrayDungeonRegionHeightMinMax[1];
			int32 TempDungeonRegionHeight = TempDungeonRegionHeightMax - TempDungeonRegionHeightMin;
			if (TempDungeonRegionHeight <= 0)
			{
				TempDungeonRegionHeight = TempDungeonRegionHeightMin;
			}
			else
			{
				TempDungeonRegionHeight = rand() % TempDungeonRegionHeight + TempDungeonRegionHeightMin;
			}

			if (TempDungeonRegionHeight <= 0)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonForRegion fail, TempDungeonRegionHeight <= 0, TempDungeonRegionHeight:%d."), TempDungeonRegionHeight);
				continue;
			}

			GenerateDungeonRegionToHelp(TempDungeonData, TempDungeonRegionWidth, TempDungeonRegionHeight, TempDungeonRegionId);
		}
	}

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			int TempDungeonRegionTopography = ArrayDungeonGrid[tile];
			if (TempDungeonRegionTopography <= 0)
				continue;

			RefreshRandomDungeonRegion(tile);
		}
	}

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			int TempDungeonRegionTopography = ArrayDungeonGrid[tile];
			if (TempDungeonRegionTopography <= 0)
				continue;

			RefreshRandomDungeonRegionCenterOrBorder(x, y, tile);
		}
	}

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			int TempDungeonRegionTopography = ArrayDungeonGrid[tile];
			if (TempDungeonRegionTopography <= 0)
				continue;

			RefreshRandomDungeonRegionBase(tile, TempDungeonStyle);
		}
	}

	for (int y = 0; y < DungeonHeight; ++y)
	{
		for (int x = 0; x < DungeonWidth; ++x)
		{
			int tile = this->xy2tile(x, y);
			int TempDungeonRegionTopography = ArrayDungeonGrid[tile];
			if (TempDungeonRegionTopography <= 0)
				continue;

			RefreshRandomDungeonRegionBaseForPawnStart(TempDungeonData, tile, TempDungeonStyle);
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::RandomRemoveDungeonExtension()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	int32 TempWidthExt = (TempDungeonData->DungeonWidthExtension - TempDungeonData->DungeonWidth)/2;
	if (TempWidthExt <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomRemoveDungeonExtension fail, TempWidthExt <= 0, TempWidthExt:%d, DungeonWidthExtension:%d, DungeonWidth:%d."), TempWidthExt, TempDungeonData->DungeonWidthExtension, TempDungeonData->DungeonWidth);
		return false;
	}
	offsetX = TempWidthExt;

	int32 TempHeightExt = (TempDungeonData->DungeonHeightExtension - TempDungeonData->DungeonHeight)/2;
	if (TempHeightExt <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RandomRemoveDungeonExtension fail, TempHeightExt <= 0, TempWidthExt:%d, DungeonHeightExtension:%d, DungeonHeight:%d."), TempWidthExt, TempDungeonData->DungeonHeightExtension, TempDungeonData->DungeonHeight);
		return false;
	}
	offsetY = TempHeightExt;

	int total = TempDungeonData->DungeonWidthExtension * TempDungeonData->DungeonHeightExtension;
	int oldOffset = 0;
	for (int i = 0; i <= TempDungeonData->DungeonWidthExtension; ++i)
	{
		int r = rand() % TempHeightExt + 1;
		//int r = TempHeightExt;
		int c = r;
		int b = 0;
		//int o = 0;
		//int s = 0;
		int o = rand() % (r / 2 + 1) + 1;
		int s = rand() % 4;
		if (s == 0 || s == 1 || s == 2)
			o = -o;
		c += o + oldOffset;
		b += o + oldOffset;
		oldOffset += o;
		oldOffset += r + 1;
		if (b >= TempDungeonData->DungeonWidthExtension)
			break;

		//if (b >= TempDungeonData->DungeonWidthExtension - TempHeightExt)
		//	break;

		int ry = 0;
		int ny = 0;
		int j = 0;
		for (int x = b; x <= c; ++x)
		{
			ry = ry + ny;
			if (ry > r)
				ry = r;

			float f = (float)(x - b) / (float)r;

			if (f >= 0.6666f)
			{
				ny = 0;
				j++;
				if (j >= 2)
				{
					ny = 1;
					j = 0;
				}
			}
			else if (f < 0.3333f)
			{
				ny = 2;
				j = 0;
			}
			else
			{
				ny = 1;
				j = 0;
			}

			if (ry > TempHeightExt)
				ry = TempHeightExt;

			for (int y = 0; y < ry; ++y)
			{
				int tile = this->xy2tile(x, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}

		ry = 0;
		ny = 0;
		j = 0;
		for (int x = c + r - 1; x > c; --x)
		{
			ry = ry + ny;
			if (ry > r)
				ry = r;

			float f = (float)(x - c) / (float)r;

			if (f >= 0.6666f)
			{
				ny = 2;
				j = 0;
			}
			else if (f < 0.3333f)
			{
				ny = 0;
				j++;
				if (j >= 2)
				{
					ny = 1;
					j = 0;
				}
			}
			else
			{
				ny = 1;
				j = 0;
			}

			if (ry > TempHeightExt)
				ry = TempHeightExt;

			for (int y = 0; y < ry; ++y)
			{
				int tile = this->xy2tile(x, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}
	}

	oldOffset = 0;
	for (int i = 0; i <= TempDungeonData->DungeonWidthExtension; ++i)
	{
		int r = rand() % TempHeightExt + 1;
		//int r = TempHeightExt;
		int c = r;
		int b = 0;
		//int o = 0;
		//int s = 0;
		int o = rand() % (r / 2 + 1) + 1;
		int s = rand() % 4;
		if (s == 0 || s == 1 || s == 2)
			o = -o;
		c += o + oldOffset;
		b += o + oldOffset;
		oldOffset += o;
		oldOffset += r + 1;
		if (b >= TempDungeonData->DungeonWidthExtension)
			break;

		//if (b >= TempDungeonData->DungeonWidthExtension - TempHeightExt)
		//	break;

		int ry = 0;
		int ny = 0;
		int j = 0;
		for (int x = b; x <= c; ++x)
		{
			ry = ry + ny;
			if (ry > r)
				ry = r;

			float f = (float)(x - b) / (float)r;

			if (f >= 0.6666f)
			{
				ny = 0;
				j++;
				if (j >= 2)
				{
					ny = 1;
					j = 0;
				}
			}
			else if (f < 0.3333f)
			{
				ny = 2;
				j = 0;
			}
			else
			{
				ny = 1;
				j = 0;
			}

			if (ry > TempHeightExt)
				ry = TempHeightExt;

			for (int y = 0; y < ry; ++y)
			{
				int tile = this->xy2tile(x, TempDungeonData->DungeonHeightExtension - y - 1);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}

		ry = 0;
		ny = 0;
		j = 0;
		for (int x = c + r - 1; x > c; --x)
		{
			ry = ry + ny;
			if (ry > r)
				ry = r;

			float f = (float)(x - c) / (float)r;

			if (f >= 0.6666f)
			{
				ny = 2;
				j = 0;
			}
			else if (f < 0.3333f)
			{
				ny = 0;
				j++;
				if (j >= 2)
				{
					ny = 1;
					j = 0;
				}
			}
			else
			{
				ny = 1;
				j = 0;
			}

			if (ry > TempHeightExt)
				ry = TempHeightExt;

			for (int y = 0; y < ry; ++y)
			{
				int tile = this->xy2tile(x, TempDungeonData->DungeonHeightExtension - y - 1);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}
	}


	oldOffset = 0;
	for (int i = 0; i <= TempDungeonData->DungeonHeightExtension; ++i)
	{
		int r = rand() % TempWidthExt + 1;
		//int r = TempWidthExt;
		int c = r;
		int b = 0;
		//int o = 0;
		//int s = 0;
		int o = rand() % (r / 2 + 1) + 1;
		int s = rand() % 4;
		if (s == 0 || s == 1 || s == 2)
			o = -o;
		c += o + oldOffset;
		b += o + oldOffset;
		oldOffset += o;
		oldOffset += r + 1;
		if (b >= TempDungeonData->DungeonHeightExtension)
			break;

		//if (b >= TempDungeonData->DungeonHeightExtension - TempWidthExt)
		//	break;

		int rx = 0;
		int nx = 0;
		int j = 0;
		for (int y = b; y <= c; ++y)
		{
			rx = rx + nx;
			if (rx > r)
				rx = r;

			float f = (float)(y - b) / (float)r;

			if (f >= 0.6666f)
			{
				nx = 0;
				j++;
				if (j >= 2)
				{
					nx = 1;
					j = 0;
				}
			}
			else if (f < 0.3333f)
			{
				nx = 2;
				j = 0;
			}
			else
			{
				nx = 1;
				j = 0;
			}

			if (rx > TempWidthExt)
				rx = TempWidthExt;

			for (int x = 0; x < rx; ++x)
			{
				int tile = this->xy2tile(x, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}

		rx = 0;
		nx = 0;
		j = 0;
		for (int y = c + r - 1; y > c; --y)
		{
			rx = rx + nx;
			if (rx > r)
				rx = r;

			float f = (float)(y - c) / (float)r;

			if (f >= 0.6666f)
			{
				nx = 2;
				j = 0;
			}
			else if (f < 0.3333f)
			{
				nx = 0;
				j++;
				if (j >= 2)
				{
					nx = 1;
					j = 0;
				}
			}
			else
			{
				nx = 1;
				j = 0;
			}

			if (rx > TempWidthExt)
				rx = TempWidthExt;

			for (int x = 0; x < rx; ++x)
			{
				int tile = this->xy2tile(x, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}
	}

	oldOffset = 0;
	for (int i = 0; i <= TempDungeonData->DungeonHeightExtension; ++i)
	{
		int r = rand() % TempWidthExt + 1;
		//int r = TempWidthExt;
		int c = r;
		int b = 0;
		//int o = 0;
		//int s = 0;
		int o = rand() % (r / 2 + 1) + 1;
		int s = rand() % 4;
		if (s == 0 || s == 1 || s == 2)
			o = -o;
		c += o + oldOffset;
		b += o + oldOffset;
		oldOffset += o;
		oldOffset += r + 1;
		if (b >= TempDungeonData->DungeonHeightExtension)
			break;

		//if (b >= TempDungeonData->DungeonHeightExtension - TempWidthExt)
		//	break;

		int rx = 0;
		int nx = 0;
		int j = 0;
		for (int y = b; y <= c; ++y)
		{
			rx = rx + nx;
			if (rx > r)
				rx = r;

			float f = (float)(y - b) / (float)r;

			if (f >= 0.6666f)
			{
				nx = 0;
				j++;
				if (j >= 2)
				{
					nx = 1;
					j = 0;
				}
			}
			else if (f < 0.3333f)
			{
				nx = 2;
				j = 0;
			}
			else
			{
				nx = 1;
				j = 0;
			}

			if (rx > TempWidthExt)
				rx = TempWidthExt;

			for (int x = 0; x < rx; ++x)
			{
				int tile = this->xy2tile(TempDungeonData->DungeonWidthExtension - x - 1, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}

		rx = 0;
		nx = 0;
		j = 0;
		for (int y = c + r - 1; y > c; --y)
		{
			rx = rx + nx;
			if (rx > r)
				rx = r;

			float f = (float)(y - c) / (float)r;

			if (f >= 0.6666f)
			{
				nx = 2;
				j = 0;
			}
			else if (f < 0.3333f)
			{
				nx = 0;
				j++;
				if (j >= 2)
				{
					nx = 1;
					j = 0;
				}
			}
			else
			{
				nx = 1;
				j = 0;
			}

			if (rx > TempWidthExt)
				rx = TempWidthExt;

			for (int x = 0; x < rx; ++x)
			{
				int tile = this->xy2tile(TempDungeonData->DungeonWidthExtension - x - 1, y);
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}
		}
	}

	ACWMap* TempMap = GetMap();
	check(TempMap);
	for (int y = 0; y < TempDungeonData->DungeonHeightExtension; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidthExtension; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (y == 0 || y == TempDungeonData->DungeonHeightExtension - 1 ||
				y == 1 || y == TempDungeonData->DungeonHeightExtension - 2)
			{
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}

			if (x == 0 || x == TempDungeonData->DungeonWidthExtension - 1 ||
				x == 1 || x == TempDungeonData->DungeonWidthExtension - 2)
			{
				if (tile >= 0 && tile < total)
				{
					ArrayDungeonGrid[tile] = 0;
				}
			}

			if (tile >= 0 && tile < total)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					uint8 TempTileAttribute = TempMap->getMapTileAttribute(x, y);
					TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
					TempMap->setMapTileAttribute(x, y, TempTileAttribute);
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonDecorateRegion()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	for (int y = 0; y < TempDungeonData->DungeonHeightExtension; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidthExtension; ++x)
		{
			int tile = this->xy2tile(x, y);
			if (y < offsetY && x < offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y, 
						ECWEdgeOutSideDecorateCoord::XZeroYZero, 
						count, 
						TempArrayDecorateTile, 
						OutAdjacent, 
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->ParentDungeonGeneratorInServer = this;
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::XZeroYZero;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}
			
			if (y < offsetY && x >= offsetX && x < TempDungeonData->DungeonWidthExtension - offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y,
						ECWEdgeOutSideDecorateCoord::YZero, 
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::YZero;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (y < offsetY && x >= TempDungeonData->DungeonWidthExtension - offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y, 
						ECWEdgeOutSideDecorateCoord::YZeroXWidthMax, 
						count,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::YZeroXWidthMax;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (x >= TempDungeonData->DungeonWidthExtension - offsetX && y >= offsetY && y < TempDungeonData->DungeonHeightExtension - offsetY)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y,
						ECWEdgeOutSideDecorateCoord::XWidthMax, 
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::YHeightMax;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (x >= TempDungeonData->DungeonWidthExtension - offsetX && y >= TempDungeonData->DungeonHeightExtension - offsetY)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y, 
						ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax, 
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (y >= TempDungeonData->DungeonHeightExtension - offsetY && x >= offsetX && x < TempDungeonData->DungeonWidthExtension - offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y, 
						ECWEdgeOutSideDecorateCoord::YHeightMax, 
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::YHeightMax;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (y >= TempDungeonData->DungeonHeightExtension - offsetY && x < offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y,
						ECWEdgeOutSideDecorateCoord::XZeroYHeightMax,
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::XZeroYHeightMax;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}

			if (y >= offsetY && y < TempDungeonData->DungeonHeightExtension - offsetY && x < offsetX)
			{
				if (ArrayDungeonGrid[tile] == 0)
				{
					int32 count = 0;
					TArray<ACWDungeonDecorateTile*> TempArrayDecorateTile;
					ECWDecorateAdjacent OutAdjacent = ECWDecorateAdjacent::None;
					int32 OutAdjacentTile = -1;
					ECWEdgeOutSideDecorateOrientation orientation = CaculateDecorateOrientation(
						x, 
						y,
						ECWEdgeOutSideDecorateCoord::XZero,
						count, 
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					if (orientation != ECWEdgeOutSideDecorateOrientation::None)
					{
						UCWDungeonDecorateRegion* TempDecorateRegion = NewObject<UCWDungeonDecorateRegion>();
						TempDecorateRegion->Coord = (int32)ECWEdgeOutSideDecorateCoord::XZero;
						TempDecorateRegion->Orient = orientation;
						TempDecorateRegion->X = x;
						TempDecorateRegion->Y = y;
						TempDecorateRegion->Tile = tile;
						TempDecorateRegion->Count = count;
						TempDecorateRegion->RemainCount = count;
						TempDecorateRegion->Adjacent = OutAdjacent;
						TempDecorateRegion->AdjacentTile = OutAdjacentTile;
						TempDecorateRegion->ArrayDecorateTile = TempArrayDecorateTile;
						ArrayDungeonDecorateRegion.Add(TempDecorateRegion);
					}
				}
			}
		}
	}
	return true;
}

void ACWRandomDungeonGenerator::AddDecorateTile(
	int32 ParamX,
	int32 ParamY,
	ECWEdgeOutSideDecorateCoord ParamCoord,
	ECWEdgeOutSideDecorateOrientation ParamOrient,
	int32 ParamCount,
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent ParamAdjacent,
	int32 ParamAdjacentTile)
{
	FVector tilePos = FVector::ZeroVector;
	xy2pos(ParamX, ParamY, tilePos);
	
	ACWDungeonDecorateTile* TempDungeonDecorateTile = GetWorld()->SpawnActor<ACWDungeonDecorateTile>(ACWDungeonDecorateTile::StaticClass(), tilePos, FRotator::ZeroRotator);
	if (nullptr != TempDungeonDecorateTile && TempDungeonDecorateTile->ServerInitForTest(this, ParamX, ParamY))
	{
		TempArrayDecorateTile.Add(TempDungeonDecorateTile);

		TempDungeonDecorateTile->Coord = (int32)ParamCoord;
		TempDungeonDecorateTile->Orient = ParamOrient;
		TempDungeonDecorateTile->Count = ParamCount;
		TempDungeonDecorateTile->Adjacent = ParamAdjacent;
		TempDungeonDecorateTile->AdjacentTile = ParamAdjacentTile;
	}
}

void ACWRandomDungeonGenerator::PlaceDecorateToSingle(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion)
{
	int tile = xy2tile(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y);
	if (ArrayDungeonDecorateTile[tile] != nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, x:%d, y:%d, tile:%d."), TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y, tile);
		return;
	}

	MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Single);
	if (iterFind == MapMapMapListDecorate.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, ECWEdgeOutSideDecorateOrientation::Single is no item."));
		return;
	}

	MapMapList::iterator iterFindSub = iterFind->second.find(TempDungeonDecorateRegion->Adjacent);
	if (iterFindSub == iterFind->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, Adjacent:%d."), (int32)TempDungeonDecorateRegion->Adjacent);
		return;
	}

	MapList::iterator iterFindSubSub = iterFindSub->second.find(1);
	if (iterFindSubSub == iterFindSub->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, Adjacent:%d, 1 is no item."), (int32)TempDungeonDecorateRegion->Adjacent);
		return;
	}

	if (iterFindSubSub->second.size() == 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, Adjacent:%d, size is no item."), (int32)TempDungeonDecorateRegion->Adjacent);
		return;
	}

	std::vector<FCWDecorateAssetParamStruct> TempList;
	for (int i = 0; i < iterFindSubSub->second.size(); ++i)
	{
		uint8 c = (uint8)iterFindSubSub->second[i].Coord & (uint8)TempCoord;
		if (c > 0)
		{
			TempList.push_back(iterFindSubSub->second[i]);
		}
	}

	if (TempList.size() == 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, Adjacent:%d, TempCoord:%d, TempList size is no item."), (int32)TempDungeonDecorateRegion->Adjacent, (uint8)TempCoord);
		return;
	}

	int index = rand() % TempList.size();
	FString strAssetId = TempList[index].AssetId;
	UClass* TempDungeonDecorateTileClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::DecorateAsset, strAssetId);
	if (TempDungeonDecorateTileClass == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, TempDungeonDecorateTileClass == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}
	ACWDungeonDecorateTile* TempDungeonDecorateTile = GetWorld()->SpawnActor<ACWDungeonDecorateTile>(TempDungeonDecorateTileClass);
	if (TempDungeonDecorateTile == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, TempDungeonDecorateTile == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}

	if (TempDungeonDecorateTile->InitInServer(this, TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y))
	{
		TempDungeonDecorateRegion->ArrayDecorateTile.Add(TempDungeonDecorateTile);

		FVector tilePos = FVector::ZeroVector;
		xy2pos(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y, tilePos);
		tilePos = tilePos + TempList[index].RelativeLoc;
		TempDungeonDecorateTile->SetActorLocation(tilePos);
		TempDungeonDecorateTile->SetActorRotation(TempList[index].RelativeRot);
		TempDungeonDecorateTile->SetActorScale3D(TempList[index].RelativeScale);

		TempDungeonDecorateTile->Coord = TempDungeonDecorateRegion->Coord;
		TempDungeonDecorateTile->Orient = TempDungeonDecorateRegion->Orient;
		TempDungeonDecorateTile->Adjacent = TempDungeonDecorateRegion->Adjacent;
		TempDungeonDecorateTile->AdjacentTile = TempDungeonDecorateRegion->AdjacentTile;
		TempDungeonDecorateTile->Count = TempDungeonDecorateRegion->Count;

		//int tile = xy2tile(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y);
		check(ArrayDungeonDecorateTile[tile] == nullptr);
		ArrayDungeonDecorateTile[tile] = TempDungeonDecorateTile;
	}
}

void ACWRandomDungeonGenerator::PlaceDecorateToHorizontal(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion)
{
	PlaceDecorateToHorizontalHelp(TempCoord, TempDungeonDecorateRegion, 0);
}

void ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion, int32 ParamCount)
{
	int tile = xy2tile(TempDungeonDecorateRegion->X + ParamCount, TempDungeonDecorateRegion->Y);
	if (ArrayDungeonDecorateTile[tile] != nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp, x:%d, y:%d, ParamCount:%d, tile:%d."), TempDungeonDecorateRegion->X + ParamCount, TempDungeonDecorateRegion->Y, ParamCount, tile);
		return;
	}

	MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Horizontal);
	if (iterFind == MapMapMapListDecorate.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp, ECWEdgeOutSideDecorateOrientation::Horizontal is no item."));
		return;
	}

	MapMapList::iterator iterFindSub = iterFind->second.find(TempDungeonDecorateRegion->Adjacent);
	if (iterFindSub == iterFind->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp, Adjacent:%d."), (int32)TempDungeonDecorateRegion->Adjacent);
		return;
	}

	int CurCount = TempDungeonDecorateRegion->RemainCount;
	MapList::iterator iterFindSubSub = iterFindSub->second.find(TempDungeonDecorateRegion->RemainCount);
	if (iterFindSubSub == iterFindSub->second.end())
	{
		int i = 1;
		while (TempDungeonDecorateRegion->RemainCount - i > 0)
		{
			CurCount = TempDungeonDecorateRegion->RemainCount - i;
			iterFindSubSub = iterFindSub->second.find(TempDungeonDecorateRegion->RemainCount - i);
			i++;
			if (iterFindSubSub != iterFindSub->second.end())
				break;
		}

		if (iterFindSubSub == iterFindSub->second.end())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp, Adjacent:%d, TempDungeonDecorateRegion->Count:%d is no item."), (int32)TempDungeonDecorateRegion->Adjacent, TempDungeonDecorateRegion->Count);
			return;
		}
	}

	if (iterFindSubSub->second.size() == 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontalHelp, size is no item, Adjacent:%d, TempDungeonDecorateRegion->Count:%d."), (int32)TempDungeonDecorateRegion->Adjacent, TempDungeonDecorateRegion->Count);
		return;
	}

	std::vector<FCWDecorateAssetParamStruct> TempList;
	for (int i = 0; i < iterFindSubSub->second.size(); ++i)
	{
		uint8 c = (uint8)iterFindSubSub->second[i].Coord & (uint8)TempCoord;
		if (c > 0)
		{
			TempList.push_back(iterFindSubSub->second[i]);
		}
	}

	if (TempList.size() == 0)
	{
		TempDungeonDecorateRegion->RemainCount = TempDungeonDecorateRegion->RemainCount - 1;

		if (TempDungeonDecorateRegion->RemainCount > 0)
		{
			PlaceDecorateToHorizontalHelp(TempCoord, TempDungeonDecorateRegion, ParamCount);
			return;
		}
		else
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontal, Adjacent:%d, TempCoord:%d, ParamCount:%d, TempList size is no item."), (int32)TempDungeonDecorateRegion->Adjacent, (uint8)TempCoord, ParamCount);
			return;
		}
	}

	int index = rand() % TempList.size();
	FString strAssetId = TempList[index].AssetId;
	UClass* TempDungeonDecorateTileClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::DecorateAsset, strAssetId);
	if (TempDungeonDecorateTileClass == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontal, TempDungeonDecorateTileClass == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}
	ACWDungeonDecorateTile* TempDungeonDecorateTile = GetWorld()->SpawnActor<ACWDungeonDecorateTile>(TempDungeonDecorateTileClass);
	if (TempDungeonDecorateTile == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, TempDungeonDecorateTile == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}


	if (TempDungeonDecorateTile->InitInServer(this, TempDungeonDecorateRegion->X + ParamCount, TempDungeonDecorateRegion->Y))
	{
		TempDungeonDecorateRegion->ArrayDecorateTile.Add(TempDungeonDecorateTile);

		FVector tilePos = FVector::ZeroVector;
		xy2pos(TempDungeonDecorateRegion->X + ParamCount, TempDungeonDecorateRegion->Y, tilePos);
		tilePos = tilePos + TempList[index].RelativeLoc;
		TempDungeonDecorateTile->SetActorLocation(tilePos);
		TempDungeonDecorateTile->SetActorRotation(TempList[index].RelativeRot);
		TempDungeonDecorateTile->SetActorScale3D(TempList[index].RelativeScale);

		TempDungeonDecorateTile->Coord = TempDungeonDecorateRegion->Coord;
		TempDungeonDecorateTile->Orient = TempDungeonDecorateRegion->Orient;
		TempDungeonDecorateTile->Adjacent = TempDungeonDecorateRegion->Adjacent;
		TempDungeonDecorateTile->AdjacentTile = TempDungeonDecorateRegion->AdjacentTile;
		TempDungeonDecorateTile->Count = CurCount;

		TempDungeonDecorateRegion->RemainCount = TempDungeonDecorateRegion->RemainCount - CurCount;

		//int tile = xy2tile(TempDungeonDecorateRegion->X + ParamCount, TempDungeonDecorateRegion->Y);
		check(ArrayDungeonDecorateTile[tile] == nullptr);
		ArrayDungeonDecorateTile[tile] = TempDungeonDecorateTile;
	}

	if (TempDungeonDecorateRegion->RemainCount > 0)
	{
		PlaceDecorateToHorizontalHelp(TempCoord, TempDungeonDecorateRegion, ParamCount + CurCount);
	}
}

void ACWRandomDungeonGenerator::PlaceDecorateToVertical(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion)
{
	PlaceDecorateToVerticalHelp(TempCoord, TempDungeonDecorateRegion, 0);
}

void ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion, int32 ParamCount)
{
	int tile = xy2tile(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y + ParamCount);
	if (ArrayDungeonDecorateTile[tile] != nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, x:%d, y:%d, ParamCount:%d, tile:%d."), TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y, ParamCount, tile);
		return;
	}

	MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Vertical);
	if (iterFind == MapMapMapListDecorate.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, ECWEdgeOutSideDecorateOrientation::Vertical is no item."));
		return;
	}

	MapMapList::iterator iterFindSub = iterFind->second.find(TempDungeonDecorateRegion->Adjacent);
	if (iterFindSub == iterFind->second.end())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, Adjacent:%d."), (int32)TempDungeonDecorateRegion->Adjacent);
		return;
	}

	int CurCount = TempDungeonDecorateRegion->RemainCount;
	MapList::iterator iterFindSubSub = iterFindSub->second.find(TempDungeonDecorateRegion->RemainCount);
	if (iterFindSubSub == iterFindSub->second.end())
	{
		int i = 1;
		while (TempDungeonDecorateRegion->RemainCount - i > 0)
		{
			CurCount = TempDungeonDecorateRegion->RemainCount - i;
			iterFindSubSub = iterFindSub->second.find(TempDungeonDecorateRegion->RemainCount - i);
			i++;
			if (iterFindSubSub != iterFindSub->second.end())
				break;
		}

		if (iterFindSubSub == iterFindSub->second.end())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, Adjacent:%d, TempDungeonDecorateRegion->Count:%d is no item."), (int32)TempDungeonDecorateRegion->Adjacent, TempDungeonDecorateRegion->Count);
			return;
		}
	}

	if (iterFindSubSub->second.size() == 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, size is no item, Adjacent:%d, TempDungeonDecorateRegion->Count:%d."), (int32)TempDungeonDecorateRegion->Adjacent, TempDungeonDecorateRegion->Count);
		return;
	}

	std::vector<FCWDecorateAssetParamStruct> TempList;
	for (int i = 0; i < iterFindSubSub->second.size(); ++i)
	{
		uint8 c = (uint8)iterFindSubSub->second[i].Coord & (uint8)TempCoord;
		if (c > 0)
		{
			TempList.push_back(iterFindSubSub->second[i]);
		}
	}

	if (TempList.size() == 0)
	{
		TempDungeonDecorateRegion->RemainCount = TempDungeonDecorateRegion->RemainCount - 1;

		if (TempDungeonDecorateRegion->RemainCount > 0)
		{
			PlaceDecorateToVerticalHelp(TempCoord, TempDungeonDecorateRegion, ParamCount);
			return;
		}
		else
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToVerticalHelp, Adjacent:%d, TempCoord:%d, ParamCount:%d, TempList size is no item."), (int32)TempDungeonDecorateRegion->Adjacent, (uint8)TempCoord, ParamCount);
			return;
		}
	}

	int index = rand() % TempList.size();
	FString strAssetId = TempList[index].AssetId;
	UClass* TempDungeonDecorateTileClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::DecorateAsset, strAssetId);
	if (TempDungeonDecorateTileClass == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToHorizontal, TempDungeonDecorateTileClass == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}
	ACWDungeonDecorateTile* TempDungeonDecorateTile = GetWorld()->SpawnActor<ACWDungeonDecorateTile>(TempDungeonDecorateTileClass);
	if (TempDungeonDecorateTile == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::PlaceDecorateToSingle, TempDungeonDecorateTile == nullptr, Adjacent:%d, strAssetId:%s."), (int32)TempDungeonDecorateRegion->Adjacent, *strAssetId);
		return;
	}


	if (TempDungeonDecorateTile->InitInServer(this, TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y + ParamCount))
	{
		TempDungeonDecorateRegion->ArrayDecorateTile.Add(TempDungeonDecorateTile);

		FVector tilePos = FVector::ZeroVector;
		xy2pos(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y + ParamCount, tilePos);
		tilePos = tilePos + TempList[index].RelativeLoc;
		TempDungeonDecorateTile->SetActorLocation(tilePos);
		TempDungeonDecorateTile->SetActorRotation(TempList[index].RelativeRot);
		TempDungeonDecorateTile->SetActorScale3D(TempList[index].RelativeScale);

		TempDungeonDecorateTile->Coord = TempDungeonDecorateRegion->Coord;
		TempDungeonDecorateTile->Orient = TempDungeonDecorateRegion->Orient;
		TempDungeonDecorateTile->Adjacent = TempDungeonDecorateRegion->Adjacent;
		TempDungeonDecorateTile->AdjacentTile = TempDungeonDecorateRegion->AdjacentTile;
		TempDungeonDecorateTile->Count = CurCount;

		TempDungeonDecorateRegion->RemainCount = TempDungeonDecorateRegion->RemainCount - CurCount;

		//int tile = xy2tile(TempDungeonDecorateRegion->X, TempDungeonDecorateRegion->Y + ParamCount);
		check(ArrayDungeonDecorateTile[tile] == nullptr);
		ArrayDungeonDecorateTile[tile] = TempDungeonDecorateTile;
	}

	if (TempDungeonDecorateRegion->RemainCount > 0)
	{
		PlaceDecorateToVerticalHelp(TempCoord, TempDungeonDecorateRegion, ParamCount + CurCount);
	}
}

const TArray<int32>& ACWRandomDungeonGenerator::GetArrayDungeonGrid() const
{
	return ArrayDungeonGrid;
}

const TArray<int32>& ACWRandomDungeonGenerator::GetArrayDungeonGrid_Z() const
{
	return ArrayDungeonGrid_Z;
}

const TArray<int32>& ACWRandomDungeonGenerator::GetArrayDungeonRegionId() const
{
	return ArrayDungeonRegionId;
}

bool ACWRandomDungeonGenerator::SetArrayDungeonItemObstacle(int32 ParamTile, int32 ParamObstacle)
{
	if (!ArrayDungeonItemObstacle.IsValidIndex(ParamTile))
	{
		return false;
	}

	ArrayDungeonItemObstacle[ParamTile] = ParamObstacle;
	return true;
}

int32 ACWRandomDungeonGenerator::GetGridLayerByTile(const int32 InTile)
{
	return ArrayDungeonGrid_Z.IsValidIndex(InTile) ? ArrayDungeonGrid_Z[InTile] : 0;
}

ECWEdgeOutSideDecorateOrientation ACWRandomDungeonGenerator::CaculateDecorateOrientation(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	int32& OutCount, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, 
	ECWDecorateAdjacent& OutAdjacent, 
	int32& OutAdjacentTile)
{
	OutCount = 0;
	OutAdjacent = ECWDecorateAdjacent::None;
	OutAdjacentTile = -1;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (ParamX <= 0 || ParamY <= 0 || ParamX >= TempDungeonData->DungeonWidthExtension - 1 || ParamY >= TempDungeonData->DungeonHeightExtension - 1)
	{
		return ECWEdgeOutSideDecorateOrientation::None;
	}

	int tile = this->xy2tile(ParamX, ParamY);

	int x2minx = ParamX - 1;
	int x2maxx = ParamX + 1;
	int y2miny = ParamY - 1;
	int y2maxy = ParamY + 1;
	int t2minx = this->xy2tile(x2minx, ParamY);
	int t2maxx = this->xy2tile(x2maxx, ParamY);
	int t2miny = this->xy2tile(ParamX, y2miny);
	int t2maxy = this->xy2tile(ParamX, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return ECWEdgeOutSideDecorateOrientation::None;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		ArrayDungeonGrid[tile] = -1;
	
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}
		
		AddDecorateTile(
			ParamX,
			ParamY,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Single,
			1,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return ECWEdgeOutSideDecorateOrientation::Single;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		ArrayDungeonGrid[tile] = -1;

		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		AddDecorateTile(
			ParamX,
			ParamY,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Single,
			1,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return ECWEdgeOutSideDecorateOrientation::Single;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		ArrayDungeonGrid[tile] = -1;

		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		AddDecorateTile(
			ParamX,
			ParamY,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Single,
			1,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return ECWEdgeOutSideDecorateOrientation::Single;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		ArrayDungeonGrid[tile] = -1;

		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		AddDecorateTile(
			ParamX,
			ParamY,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Single,
			1,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return ECWEdgeOutSideDecorateOrientation::Single;
	}

	switch (ParamCoord)
	{
	case ECWEdgeOutSideDecorateCoord::XZeroYZero:
	{
		if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX,
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
	{
		if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
	{
		if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY,
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
	{
		if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YZero:
	{
		if (ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if(ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY,
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMax:
	{
		if (ArrayDungeonGrid[t2minx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YHeightMax:
	{
		if (ArrayDungeonGrid[t2miny] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZero:
	{
		if (ArrayDungeonGrid[t2maxx] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Vertical,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Vertical;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}

		if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
		{
			OutCount = CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
				ParamX, 
				ParamY, 
				ParamCoord, 
				TempArrayDecorateTile,
				OutAdjacent,
				OutAdjacentTile);
			if (OutCount > 0)
			{
				JudgeAdjacent(
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					ArrayDungeonGrid[t2minx],
					t2minx,
					ArrayDungeonGrid[t2maxx],
					t2maxx,
					ArrayDungeonGrid[t2miny],
					t2miny,
					ArrayDungeonGrid[t2maxy],
					t2maxy,
					OutAdjacent,
					OutAdjacentTile);

				OutCount++;
				AddDecorateTile(
					ParamX,
					ParamY,
					ParamCoord,
					ECWEdgeOutSideDecorateOrientation::Horizontal,
					OutCount,
					TempArrayDecorateTile,
					OutAdjacent,
					OutAdjacentTile);
				return ECWEdgeOutSideDecorateOrientation::Horizontal;
			}
			else if (OutCount == 0)
			{
				if (ArrayDungeonGrid[t2minx] > 0 ||
					ArrayDungeonGrid[t2maxx] > 0 ||
					ArrayDungeonGrid[t2miny] > 0 ||
					ArrayDungeonGrid[t2maxy] > 0)
				{
					JudgeAdjacent(
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						ArrayDungeonGrid[t2minx],
						t2minx,
						ArrayDungeonGrid[t2maxx],
						t2maxx,
						ArrayDungeonGrid[t2miny],
						t2miny,
						ArrayDungeonGrid[t2maxy],
						t2maxy,
						OutAdjacent,
						OutAdjacentTile);

					OutCount++;
					AddDecorateTile(
						ParamX,
						ParamY,
						ParamCoord,
						ECWEdgeOutSideDecorateOrientation::Single,
						OutCount,
						TempArrayDecorateTile,
						OutAdjacent,
						OutAdjacentTile);
					return ECWEdgeOutSideDecorateOrientation::Single;
				}
			}
		}
	}
	break;
	}

	return ECWEdgeOutSideDecorateOrientation::None;
}

void ACWRandomDungeonGenerator::JudgeAdjacent(
	ECWEdgeOutSideDecorateCoord ParamCoord,
	ECWEdgeOutSideDecorateOrientation ParamOrient,
	int32 ArrayDungeonGridByt2minx,
	int32 t2minx,
	int32 ArrayDungeonGridByt2maxx,
	int32 t2maxx,
	int32 ArrayDungeonGridByt2miny,
	int32 t2miny,
	int32 ArrayDungeonGridByt2maxy,
	int32 t2maxy,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	OutAdjacent = ECWDecorateAdjacent::None;
	OutAdjacentTile = -1;

	switch (ParamCoord)
	{
	case ECWEdgeOutSideDecorateCoord::XZeroYZero:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YZero:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMax:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::YHeightMax:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
			else if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
	}
	break;
	case ECWEdgeOutSideDecorateCoord::XZero:
	{
		if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Horizontal)
		{
			if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
		else if (ParamOrient == ECWEdgeOutSideDecorateOrientation::Vertical)
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
		}
		else
		{
			if (ArrayDungeonGridByt2maxx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::West;
				OutAdjacentTile = t2maxx;
			}
			else if (ArrayDungeonGridByt2minx > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::East;
				OutAdjacentTile = t2minx;
			}
			else if (ArrayDungeonGridByt2miny > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::South;
				OutAdjacentTile = t2miny;
			}
			else if (ArrayDungeonGridByt2maxy > 0)
			{
				OutAdjacent = ECWDecorateAdjacent::North;
				OutAdjacentTile = t2maxy;
			}
		}
	}
	break;
	}
	
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent, 
	int32& OutAdjacentTile)
{
	int32 x = ParamX + 1;
	int32 y = ParamY;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return 0;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return 0;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		}

		return 0;
	}

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return 0;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2maxy] > 0 || ArrayDungeonGrid[t2miny] > 0)
	{
		int count = 1;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2maxy] > 0)
			OutAdjacent = ECWDecorateAdjacent::South;

		if (ArrayDungeonGrid[t2miny] > 0)
			OutAdjacent = ECWDecorateAdjacent::North;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationHorizontalForToXMaxHelp(
			x, 
			y, 
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return 0;
}

int ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationHorizontalForToXMaxHelp(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	int32 count, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX + 1;
	int32 y = ParamY;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return count;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return count;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
	{
		return count;
	}

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return count;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2maxy] > 0 || ArrayDungeonGrid[t2miny] > 0)
	{
		count++;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2maxy] > 0)
			OutAdjacent = ECWDecorateAdjacent::South;

		if (ArrayDungeonGrid[t2miny] > 0)
			OutAdjacent = ECWDecorateAdjacent::North;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationHorizontalForToXMaxHelp(
			x, 
			y,
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return count;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationHorizontalForToXMin(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX - 1;
	int32 y = ParamY;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return 0;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return 0;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
		return 0;

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return 0;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
	{
		int count = 1;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2maxy] > 0)
			OutAdjacent = ECWDecorateAdjacent::South;

		if (ArrayDungeonGrid[t2miny] > 0)
			OutAdjacent = ECWDecorateAdjacent::North;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationHorizontalForToXMinHelp(
			x, 
			y, 
			ParamCoord,
			count, 
			TempArrayDecorateTile, 
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return 0;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationHorizontalForToXMinHelp(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	int32 count, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX - 1;
	int32 y = ParamY;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return count;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return count;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
		return count;

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return count;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2miny] > 0 || ArrayDungeonGrid[t2maxy] > 0)
	{
		count++;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2maxy] > 0)
			OutAdjacent = ECWDecorateAdjacent::South;

		if (ArrayDungeonGrid[t2miny] > 0)
			OutAdjacent = ECWDecorateAdjacent::North;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationHorizontalForToXMinHelp(
			x, 
			y, 
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return count;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationVerticalForToYMax(
	int32 ParamX, 
	int32 ParamY,
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX;
	int32 y = ParamY + 1;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return 0;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return 0;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = tile;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = tile;
			break;
		}
		return 0;
	}

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return 0;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
	{
		int count = 1;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;
		if (ArrayDungeonGrid[t2minx] > 0)
			OutAdjacent = ECWDecorateAdjacent::West;
		if (ArrayDungeonGrid[t2maxx] > 0)
			OutAdjacent = ECWDecorateAdjacent::East;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationVerticalForToYMaxHelp(
			x,
			y, 
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return 0;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationVerticalForToYMaxHelp(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	int32 count, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX;
	int32 y = ParamY + 1;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return count;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return count;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
		return count;

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return count;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 || ArrayDungeonGrid[t2maxx] > 0)
	{
		count++;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;
		if (ArrayDungeonGrid[t2minx] > 0)
			OutAdjacent = ECWDecorateAdjacent::West;
		if (ArrayDungeonGrid[t2maxx] > 0)
			OutAdjacent = ECWDecorateAdjacent::East;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationVerticalForToYMaxHelp(
			x,
			y,
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return count;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationVerticalForToYMin(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX;
	int32 y = ParamY - 1;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return 0;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return 0;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
		return 0;

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return 0;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return 0;
	}

	if (ArrayDungeonGrid[t2maxx] > 0 || ArrayDungeonGrid[t2minx] > 0)
	{
		int count = 1;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2minx] > 0)
			OutAdjacent = ECWDecorateAdjacent::West;
		if (ArrayDungeonGrid[t2maxx] > 0)
			OutAdjacent = ECWDecorateAdjacent::East;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationVerticalForToYMinHelp(
			x,
			y, 
			ParamCoord, 
			count, 
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return 0;
}

int32 ACWRandomDungeonGenerator::CheckEdgeOutSideDecorateOrientationVerticalForToYMinHelp(
	int32 ParamX, 
	int32 ParamY, 
	ECWEdgeOutSideDecorateCoord ParamCoord, 
	int32 count, 
	TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile,
	ECWDecorateAdjacent& OutAdjacent,
	int32& OutAdjacentTile)
{
	int32 x = ParamX;
	int32 y = ParamY - 1;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (x <= 0 || x >= TempDungeonData->DungeonWidthExtension - 1)
		return count;

	if (y <= 0 || y >= TempDungeonData->DungeonHeightExtension - 1)
		return count;

	int tile = this->xy2tile(x, y);
	if (ArrayDungeonGrid[tile] > 0)
		return count;

	int x2minx = x - 1;
	int x2maxx = x + 1;
	int y2miny = y - 1;
	int y2maxy = y + 1;
	int t2minx = this->xy2tile(x2minx, y);
	int t2maxx = this->xy2tile(x2maxx, y);
	int t2miny = this->xy2tile(x, y2miny);
	int t2maxy = this->xy2tile(x, y2maxy);

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		return count;
	}

	if (ArrayDungeonGrid[t2minx] <= 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] <= 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}

		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] <= 0 &&
		ArrayDungeonGrid[t2maxy] > 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::North;
			OutAdjacentTile = t2maxy;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2minx] > 0 &&
		ArrayDungeonGrid[t2maxx] > 0 &&
		ArrayDungeonGrid[t2miny] > 0 &&
		ArrayDungeonGrid[t2maxy] <= 0)
	{
		switch (ParamCoord)
		{
		case ECWEdgeOutSideDecorateCoord::YZero:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
			OutAdjacent = ECWDecorateAdjacent::West;
			OutAdjacentTile = t2maxx;
			break;
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
			OutAdjacent = ECWDecorateAdjacent::East;
			OutAdjacentTile = t2minx;
			break;
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
			OutAdjacent = ECWDecorateAdjacent::South;
			OutAdjacentTile = t2miny;
			break;
		}
		return count;
	}

	if (ArrayDungeonGrid[t2maxx] > 0 || ArrayDungeonGrid[t2minx] > 0)
	{
		count++;
		ArrayDungeonGrid[tile] = -1;
		OutAdjacentTile = tile;

		if (ArrayDungeonGrid[t2minx] > 0)
			OutAdjacent = ECWDecorateAdjacent::West;
		if (ArrayDungeonGrid[t2maxx] > 0)
			OutAdjacent = ECWDecorateAdjacent::East;

		AddDecorateTile(
			x,
			y,
			ParamCoord,
			ECWEdgeOutSideDecorateOrientation::Horizontal,
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		count = CheckEdgeOutSideDecorateOrientationVerticalForToYMinHelp(
			x, 
			y, 
			ParamCoord, 
			count,
			TempArrayDecorateTile,
			OutAdjacent,
			OutAdjacentTile);
		return count;
	}

	return count;
}

bool ACWRandomDungeonGenerator::GenerateDungeonDecorateTile()
{
	GenerateDecorateMapByConfig();

	for (TArray<UCWDungeonDecorateRegion*>::TIterator iter = ArrayDungeonDecorateRegion.CreateIterator(); iter; ++iter)
	{
		UCWDungeonDecorateRegion* TempDungeonDecorateRegion = *iter;
		check(TempDungeonDecorateRegion);

		switch (TempDungeonDecorateRegion->Coord)
		{
		case ECWEdgeOutSideDecorateCoord::XZero:
		case ECWEdgeOutSideDecorateCoord::YZero:
		case ECWEdgeOutSideDecorateCoord::XWidthMax:
		case ECWEdgeOutSideDecorateCoord::YHeightMax:
		case ECWEdgeOutSideDecorateCoord::XZeroYZero:
		case ECWEdgeOutSideDecorateCoord::YZeroXWidthMax:
		case ECWEdgeOutSideDecorateCoord::XZeroYHeightMax:
		case ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax:
			switch (TempDungeonDecorateRegion->Orient)
			{
			case ECWEdgeOutSideDecorateOrientation::Single:
				PlaceDecorateToSingle((ECWEdgeOutSideDecorateCoord)TempDungeonDecorateRegion->Coord, TempDungeonDecorateRegion);
				break;
			case ECWEdgeOutSideDecorateOrientation::Horizontal:
				PlaceDecorateToHorizontal((ECWEdgeOutSideDecorateCoord)TempDungeonDecorateRegion->Coord, TempDungeonDecorateRegion);
				break;
			case ECWEdgeOutSideDecorateOrientation::Vertical:
				PlaceDecorateToVertical((ECWEdgeOutSideDecorateCoord)TempDungeonDecorateRegion->Coord, TempDungeonDecorateRegion);
				break;
			}
			break;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDecorateMapByConfig()
{
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonDecorateMeshDataStruct>(TEXT("CWDungeonDecorateAssetDataTable"));
	UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::GenerateDecorateMapByConfig, GetCSVRowCount, TotalCount:%d."), TotalCount);
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonDecorateMeshDataStruct* TempDecorateMeshData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateMeshDataStruct>(TEXT("CWDungeonDecorateAssetDataTable"), i);
		if (TempDecorateMeshData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDecorateMapByConfig, TempDecorateMeshData == nullptr i:%d."), i);
			continue;
		}

		std::vector<int32> vecGridRange = CWDungeonDecorateMeshDataUtils::GetArrayDecorateMeshGridRange(TempDecorateMeshData->GridRange);
		if (vecGridRange.size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDecorateMapByConfig, vecGridRange.size() != 2 i:%d."), i);
			continue;
		}

		int32 gridWidth = vecGridRange[0];
		int32 gridHeight = vecGridRange[1];

		FCWDecorateAssetParamStruct TempParam;
		TempParam.AssetId = TempDecorateMeshData->AssetId;
		TempParam.RelativeLoc = TempDecorateMeshData->Offset;
		TempParam.RelativeRot = TempDecorateMeshData->Rotator;
		TempParam.RelativeScale = TempDecorateMeshData->Scale;
		TempParam.Adjacent = TempDecorateMeshData->Adjacent;
		TempParam.Coord = TempDecorateMeshData->Coord;
		TempParam.bIsUsed = TempDecorateMeshData->bIsUsed;

		if (!TempParam.bIsUsed)
			continue;

		if (gridWidth == 1 && gridHeight == 1)
		{
			MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Single);
			if (iterFind == MapMapMapListDecorate.end())
			{
				std::vector<FCWDecorateAssetParamStruct> tempVector;
				tempVector.push_back(TempParam);
				MapList tempMapList;
				tempMapList.insert({1, tempVector });
				MapMapList tempMapMapList;
				tempMapMapList.insert({ TempParam.Adjacent, tempMapList });
				MapMapMapListDecorate.insert({ ECWEdgeOutSideDecorateOrientation::Single, tempMapMapList });
			}
			else
			{
				MapMapList::iterator iterFindSub = iterFind->second.find(TempParam.Adjacent);
				if (iterFindSub != iterFind->second.end())
				{
					MapList::iterator iterFindSubSub = iterFindSub->second.find(1);
					if (iterFindSubSub != iterFindSub->second.end())
					{
						iterFindSubSub->second.push_back(TempParam);
					}
					else
					{
						std::vector<FCWDecorateAssetParamStruct> tempVector;
						tempVector.push_back(TempParam);
						iterFindSub->second.insert({ 1, tempVector });
					}
				}
				else
				{
					std::vector<FCWDecorateAssetParamStruct> tempVector;
					tempVector.push_back(TempParam);
					MapList tempMapList;
					tempMapList.insert({ 1, tempVector });
					iterFind->second.insert({ TempParam.Adjacent, tempMapList });
				}
			}
		}

		{
			MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Horizontal);
			if (iterFind == MapMapMapListDecorate.end())
			{
				std::vector<FCWDecorateAssetParamStruct> tempVector;
				tempVector.push_back(TempParam);
				MapList tempMapList;
				tempMapList.insert({ gridWidth, tempVector });
				MapMapList tempMapMapList;
				tempMapMapList.insert({ TempParam.Adjacent, tempMapList });
				MapMapMapListDecorate.insert({ ECWEdgeOutSideDecorateOrientation::Horizontal, tempMapMapList });
			}
			else
			{
				MapMapList::iterator iterFindSub = iterFind->second.find(TempParam.Adjacent);
				if (iterFindSub != iterFind->second.end())
				{
					MapList::iterator iterFindSubSub = iterFindSub->second.find(gridWidth);
					if (iterFindSubSub != iterFindSub->second.end())
					{
						iterFindSubSub->second.push_back(TempParam);
					}
					else
					{
						std::vector<FCWDecorateAssetParamStruct> tempVector;
						tempVector.push_back(TempParam);
						iterFindSub->second.insert({ gridWidth, tempVector });
					}
				}
				else
				{
					std::vector<FCWDecorateAssetParamStruct> tempVector;
					tempVector.push_back(TempParam);
					MapList tempMapList;
					tempMapList.insert({ gridWidth, tempVector });
					iterFind->second.insert({ TempParam.Adjacent, tempMapList });
				}
			}
		}

		{
			MapMapMapList::iterator iterFind = MapMapMapListDecorate.find(ECWEdgeOutSideDecorateOrientation::Vertical);
			if (iterFind == MapMapMapListDecorate.end())
			{
				std::vector<FCWDecorateAssetParamStruct> tempVector;
				tempVector.push_back(TempParam);
				MapList tempMapList;
				tempMapList.insert({ gridHeight, tempVector });
				MapMapList tempMapMapList;
				tempMapMapList.insert({ TempParam.Adjacent, tempMapList });
				MapMapMapListDecorate.insert({ ECWEdgeOutSideDecorateOrientation::Vertical, tempMapMapList });
			}
			else
			{
				MapMapList::iterator iterFindSub = iterFind->second.find(TempParam.Adjacent);
				if (iterFindSub != iterFind->second.end())
				{
					MapList::iterator iterFindSubSub = iterFindSub->second.find(gridHeight);
					if (iterFindSubSub != iterFindSub->second.end())
					{
						iterFindSubSub->second.push_back(TempParam);
					}
					else
					{
						std::vector<FCWDecorateAssetParamStruct> tempVector;
						tempVector.push_back(TempParam);
						iterFindSub->second.insert({ gridHeight, tempVector });
					}
				}
				else
				{
					std::vector<FCWDecorateAssetParamStruct> tempVector;
					tempVector.push_back(TempParam);
					MapList tempMapList;
					tempMapList.insert({ gridHeight, tempVector });
					iterFind->second.insert({ TempParam.Adjacent, tempMapList });
				}
			}
		}
	}
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonWall()
{
	FCWRandomDungeonRegionData TempFirstDungeonRegionHasWall;
	if (!GetFirstDungeonHasWall(TempFirstDungeonRegionHasWall))
	{
		UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, GetFirstDungeonHasWall fail."));
		return true;
	}

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonRegionWallDoorCountMinMax = FCWDungeonDataUtils::GetArrayDungeonRegionWallDoorCountMinMax(TempDungeonData->ArrayDungeonRegionWallDoorCountMinMax);
	if (TempArrayDungeonRegionWallDoorCountMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, TempArrayDungeonRegionWallDoorCountMinMax.size() != 2, TempArrayDungeonRegionWallDoorCountMinMax.size():%d."), TempArrayDungeonRegionWallDoorCountMinMax.size());
		return false;
	}

	int32 DoorCountMin = TempArrayDungeonRegionWallDoorCountMinMax[0];
	int32 DoorCountMax = TempArrayDungeonRegionWallDoorCountMinMax[1];
	int32 DoorCount = RandomInt(DoorCountMin, DoorCountMax);

	std::vector<int32> TempArrayDungeonRegionWallDoorWidthMinMax = FCWDungeonDataUtils::GetArrayDungeonRegionWallDoorCountMinMax(TempDungeonData->ArrayDungeonRegionWallDoorWidthMinMax);
	if (TempArrayDungeonRegionWallDoorWidthMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, TempArrayDungeonRegionWallDoorWidthMinMax.size() != 2, TempArrayDungeonRegionWallDoorWidthMinMax.size():%d."), TempArrayDungeonRegionWallDoorWidthMinMax.size());
		return false;
	}

	int32 DoorWidthMin = TempArrayDungeonRegionWallDoorWidthMinMax[0];
	int32 DoorWidthMax = TempArrayDungeonRegionWallDoorWidthMinMax[1];
	//int32 DoorWidth = RandomInt(DoorWidthMin, DoorWidthMax);

	int32 realBeginX = TempFirstDungeonRegionHasWall.OriginX - 1;
	int32 realEndX = TempFirstDungeonRegionHasWall.OriginX + TempFirstDungeonRegionHasWall.SizeX ;
	int32 realBeginY = TempFirstDungeonRegionHasWall.OriginY - 1;
	int32 realEndY = TempFirstDungeonRegionHasWall.OriginY + TempFirstDungeonRegionHasWall.SizeY ;
	bool isThereWallForLeft = true;
	bool isThereWallForUp = true;
	bool isThereWallForRight = true;
	bool isThereWallForDown = true;
	for (int y = realBeginY; y <= realEndY; ++y)
	{
		for (int x = realBeginX; x <= realEndX; ++x)
		{
			if ((x == realBeginX || x == realEndX) && (y >= realBeginY && y <= realEndY) ||
				(x >= realBeginX && x <= realEndX) && (y == realBeginY || y == realEndY))
			{
				if (x < 0 || x >= DungeonWidth || y < 0 || y >= DungeonHeight)
				{
					if (x < 0)
					{
						isThereWallForRight = false;
					}

					if (x >= DungeonWidth)
					{
						isThereWallForLeft = false;
					}

					if (y < 0)
					{
						isThereWallForDown = false;
					}

					if (y >= DungeonHeight)
					{
						isThereWallForUp = false;
					}
					continue;
				}
			}
		}
	}

	std::vector<int32> TempArrayDoor;
	if (isThereWallForRight)
		TempArrayDoor.push_back(0);
	if (isThereWallForUp)
		TempArrayDoor.push_back(1);
	if (isThereWallForLeft)
		TempArrayDoor.push_back(2);
	if (isThereWallForDown)
		TempArrayDoor.push_back(3);

	RandomShuffle(TempArrayDoor, TempArrayDoor.size());

	int leftDoorCount = 0;
	int upDoorCount = 0;
	int rightDoorCount = 0;
	int downDoorCount = 0;

	float sameSideRate = 0.0f;

	int leftDoor0 = -1;
	int leftDoor1 = -1;
	int leftDoorWidth = 0;

	int upDoor0 = -1;
	int upDoor1 = -1;
	int upDoorWidth = 0;

	int rightDoor0 = -1;
	int rightDoor1 = -1;
	int rightDoorWidth = 0;

	int downDoor0 = -1;
	int downDoor1 = -1;
	int downDoorWidth = 0;

	for (int i = 0; i < TempArrayDoor.size(); ++i)
	{
		int32 dir = TempArrayDoor[i];

		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d."), dir);
	}

	for (int i = 0; i < TempArrayDoor.size(); ++i)
	{
		int RemainDoorCount = DoorCount - leftDoorCount - upDoorCount - rightDoorCount - downDoorCount;
		if (RemainDoorCount >= 2)
			sameSideRate = 0.75f;
		else
			sameSideRate = 0.25f;

		//if (RemainDoorCount <= 0)
		//	break;

		int32 dir = TempArrayDoor[i];
		if (dir == 0)
		{
			rightDoorWidth = rand() % (DoorWidthMax-DoorWidthMin) + DoorWidthMin;
			int height0 = realEndY - realBeginY;
			float h0 = (float)height0 / (float)rightDoorWidth;
			if (h0 >= 4.0f)
			{
				//if (RandomFloat(0.0f, 1.0f) <= sameSideRate)
				{
					rightDoorCount = 2;

					int u1 = rand() % 2 + 1;
					rightDoor0 = realBeginY + u1;
					int u2 = rand() % 2 + 1;
					rightDoor1 = realBeginY + u1 + rightDoorWidth + u2;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, rightDoorCount:%d, rightDoor0:%d, rightDoor1:%d, h0:%f."), dir, rightDoorCount, rightDoor0, rightDoor1, h0);
				}
				/*else
				{
					rightDoorCount = 1;

					rightDoor0 = RandomInt(realBeginY + 1, realEndY - rightDoorWidth - 1);

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, rightDoorCount:%d, rightDoor0:%d, rightDoor1:%d, h0:%f."), dir, rightDoorCount, rightDoor0, rightDoor1, h0);
				}*/
			}
			else if (h0 > 1.0f)
			{
				rightDoorCount = 1;

				rightDoor0 = RandomInt(realBeginY + 1, realEndY - rightDoorWidth - 1);

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, rightDoorCount:%d, rightDoor0:%d, rightDoor1:%d, h0:%f."), dir, rightDoorCount, rightDoor0, rightDoor1, h0);
			}
		}

		if (dir == 1)
		{
			upDoorWidth = rand() % (DoorWidthMax - DoorWidthMin) + DoorWidthMin;
			int width1 = realEndX - realBeginX;
			float w1 = (float)width1 / (float)upDoorWidth;
			if (w1 >= 4.0f)
			{
				//if (RandomFloat(0.0f, 1.0f) <= sameSideRate)
				{
					upDoorCount = 2;

					int u1 = rand() % 2 + 1;
					upDoor0 = realBeginX + u1;
					int u2 = rand() % 2 + 1;
					upDoor1 = realBeginX + u1 + upDoorWidth + u2;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, upDoorCount:%d, upDoor0:%d, upDoor1:%d, w1:%f."), dir, upDoorCount, upDoor0, upDoor1, w1);
				}
				/*else
				{
					upDoorCount = 1;

					upDoor0 = RandomInt(realBeginX + 1, realEndX - upDoorWidth - 1);

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, upDoorCount:%d, upDoor0:%d, upDoor1:%d, w1:%f."), dir, upDoorCount, upDoor0, upDoor1, w1);
				}*/
			}
			else if (w1 > 1.0f)
			{
				upDoorCount = 1;

				upDoor0 = RandomInt(realBeginX + 1, realEndX - upDoorWidth - 1);

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, upDoorCount:%d, upDoor0:%d, upDoor1:%d, w1:%f."), dir, upDoorCount, upDoor0, upDoor1, w1);
			}
		}

		if (dir == 2)
		{
			leftDoorWidth = rand() % (DoorWidthMax - DoorWidthMin) + DoorWidthMin;
			int height2 = realEndY - realBeginY;
			float h2 = (float)height2 / (float)leftDoorWidth;
			if (h2 >= 4.0f)
			{
				//if (RandomFloat(0.0f, 1.0f) <= sameSideRate)
				{
					leftDoorCount = 2;

					int u1 = rand() % 2 + 1;
					leftDoor0 = realBeginY + u1;
					int u2 = rand() % 2 + 1;
					leftDoor1 = realBeginY + u1 + leftDoorWidth + u2;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, leftDoorCount:%d, leftDoor0:%d, leftDoor1:%d, h2:%f."), dir, leftDoorCount, leftDoor0, leftDoor1, h2);
				}
				/*else
				{
					leftDoorCount = 1;

					leftDoor0 = RandomInt(realBeginY + 1, realEndY - leftDoorWidth - 1);

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, leftDoorCount:%d, leftDoor0:%d, leftDoor1:%d, h2:%f."), dir, leftDoorCount, leftDoor0, leftDoor1, h2);
				}*/
			}
			else if (h2 > 1.0f)
			{
				leftDoorCount = 1;

				leftDoor0 = RandomInt(realBeginY + 1, realEndY - leftDoorWidth - 1);

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, leftDoorCount:%d, leftDoor0:%d, leftDoor1:%d, h2:%f."), dir, leftDoorCount, leftDoor0, leftDoor1, h2);
			}
		}

		if (dir == 3)
		{
			downDoorWidth = rand() % (DoorWidthMax - DoorWidthMin) + DoorWidthMin;
			int width3 = realEndX - realBeginX;
			float w3 = (float)width3 / (float)downDoorWidth;
			if (w3 >= 4.0f)
			{
				//if (RandomFloat(0.0f, 1.0f) <= sameSideRate)
				{
					downDoorCount = 2;

					int u1 = rand() % 2 + 1;
					downDoor0 = realBeginX + u1;
					int u2 = rand() % 2 + 1;
					downDoor1 = realBeginX + u1 + downDoorWidth + u2;

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, downDoorCount:%d, downDoor0:%d, downDoor1:%d, w3:%f."), dir, downDoorCount, downDoor0, downDoor1, w3);
				}
				/*else
				{
					downDoorCount = 1;

					downDoor0 = RandomInt(realBeginX + 1, realEndX - downDoorWidth - 1);

					UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, downDoorCount:%d, downDoor0:%d, downDoor1:%d, w3:%f."), dir, downDoorCount, downDoor0, downDoor1, w3);
				}*/
			}
			else if (w3 > 1.0f)
			{
				downDoorCount = 1;

				downDoor0 = RandomInt(realBeginX + 1, realEndX - downDoorWidth - 1);

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, dir:%d, downDoorCount:%d, rightDoor0:%d, rightDoor1:%d, w3:%f."), dir, downDoorCount, downDoor0, downDoor1, w3);
			}
		}
	}

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	ACWMap* TempMap = GetMap();
	ACWGameMode* MainGM = GetWorld()->GetAuthGameMode<ACWGameMode>();
	check(TempMap && MainGM);
	for (int y = realBeginY; y <= realEndY; ++y)
	{
		for (int x = realBeginX; x <= realEndX; ++x)
		{
			if ((x == realBeginX || x == realEndX) && (y >= realBeginY && y <= realEndY) ||
				(x >= realBeginX && x <= realEndX) && (y == realBeginY || y == realEndY))
			{
				if (x < 0 || x >= DungeonWidth || y < 0 || y >= DungeonHeight)
					continue;

				int TempTile = ACWMap::xy2tile(x, y);

				uint8 TempTileAttribute = TempMap->getMapTileAttribute(x, y);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x-1, y);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x, y-1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x-1, y-1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x-1, y+1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x+1, y);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x, y+1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x+1, y+1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				TempTileAttribute = TempMap->getMapTileAttribute(x+1, y-1);
				if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
				{
					continue;
				}

				if (x == realBeginX && (y >= realBeginY && y <= realEndY))
				{
					if (rightDoorCount == 2)
					{
						if (y >= rightDoor0 && y < rightDoor0 + rightDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}

						if (y >= rightDoor1 && y < rightDoor1 + rightDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}

					if (rightDoorCount == 1)
					{
						if (y >= rightDoor0 && y < rightDoor0 + rightDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}
				}

				if (x == realEndX && (y >= realBeginY && y <= realEndY))
				{
					if (leftDoorCount == 2)
					{
						if (y >= leftDoor0 && y < leftDoor0 + leftDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}

						if (y >= leftDoor1 && y < leftDoor1 + leftDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}

					if (leftDoorCount == 1)
					{
						if (y >= leftDoor0 && y < leftDoor0 + leftDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}
				}

				if (y == realBeginY && (x >= realBeginX && x <= realEndX))
				{
					if (downDoorCount == 2)
					{
						if (x >= downDoor0 && x < downDoor0 + downDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}

						if (x >= downDoor1 && x < downDoor1 + downDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}

					if (downDoorCount == 1)
					{
						if (x >= downDoor0 && x < downDoor0 + downDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}
				}

				if (y == realEndY && (x >= realBeginX && x <= realEndX))
				{
					if (upDoorCount == 2)
					{
						if (x >= upDoor0 && x < upDoor0 + upDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}

						if (x >= upDoor1 && x < upDoor1 + upDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}

					if (upDoorCount == 1)
					{
						if (x >= upDoor0 && x < upDoor0 + upDoorWidth)
						{
							TempMap->setMapTileAttribute(TempTile, (uint8)ECWDungeonTileAttribute::Door);
							continue;
						}
					}
				}

				int tile = this->xy2tile(x, y);
				DungeonItemIndex++;
				ACWDungeonItem* TempItem = GetWorld()->SpawnActor<ACWDungeonItem>();
				int32 TempWallId = 2001;
				if (nullptr != TempItem && TempItem->InitInServer(this, tile, TempWallId, false))
				{
					FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemData(TempWallId);
					if (TempDungeonItemData == nullptr)
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonWall, TempDungeonItemData == nullptr, TempWallId:%d."), TempWallId);
						continue;
					}

					FVector TempPos = FVector::ZeroVector;
					this->tile2pos(tile, TempPos);
					TempPos.Z = TempGameData->DungeonTileRiseBeginZ;

					TempItem->LoadMesh(TempDungeonItemData->DungeonItemResName);
					TempItem->SetActorLocation(TempPos);
					FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, RandomDungeonItemEuler()));
					TempItem->SetActorRotation(TempQ);
					TempItem->SetCampTag(ECWCampTag::H);
					TempItem->SetCampControllerIndex(ECWCampControllerIndex::Eight);
					TempItem->SetControllerPawnIndex(DungeonItemIndex);

					//check(ArrayDungeonItem[tile] == nullptr);
					//ArrayDungeonItem[tile] = TempItem;
				}
			}
		}
	}
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonItemOld()
{
	//ACWGameMode* MainGM = GetWorld()->GetAuthGameMode<ACWGameMode>();
	//check(MainGM);
	//FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	//std::vector<std::vector<int32> > TempArrayArrayDungeonItemGenerateInfo = FCWDungeonDataUtils::GetArrayArrayDungeonItemGenerateInfoFromString(TempDungeonData->ArrayArrayDungeonItemGenerateInfo);
	//for (int i = 0; i < TempArrayArrayDungeonItemGenerateInfo.size(); ++i)
	//{
	//	std::vector<int32> TempArrayDungeonItemGenerateInfo = TempArrayArrayDungeonItemGenerateInfo[i];
	//	if (TempArrayDungeonItemGenerateInfo.size() != 3)
	//	{
	//		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem fail, TempArrayDungeonItemGenerateInfo.size() != 3, TempArrayDungeonItemGenerateInfo.size():%d, i:%d."), TempArrayDungeonItemGenerateInfo.size(), i);
	//		return false;
	//	}

	//	int32 TempDungeonItemId = TempArrayDungeonItemGenerateInfo[0];
	//	int32 TempDungeonItemCountMin = TempArrayDungeonItemGenerateInfo[1];
	//	int32 TempDungeonItemCountMax = TempArrayDungeonItemGenerateInfo[2];

	//	int32 TempDungeonItemCount = this->RandomInt(TempDungeonItemCountMin, TempDungeonItemCountMax);

	//	int32 TempGameId = GetGameId();
	//	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	//	check(TempGameData);

	//	//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemCount:%d, TempDungeonItemId:%d."), TempDungeonItemCount, TempDungeonItemId);
	//	int32 x = 0;
	//	int32 y = 0;
	//	int tile = 0;
	//	for (int k = 0; k < TempDungeonItemCount; ++k)
	//	{
	//		bool isThereRepetitionForDungeonItem = false;

	//		int ri = 0;

	//		do
	//		{
	//			if (ri == 1000)
	//				break;

	//			RandomDungeonItemTile(x, y);
	//			tile = this->xy2tile(x, y);
	//			ri++;

	//			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, x:%d, y:%d, i:%d."), x, y, i);
	//			isThereRepetitionForDungeonItem = IsThereRepetitionForDungeonItem(x, y, tile, TempDungeonItemId);
	//		} while (isThereRepetitionForDungeonItem);

	//		if (isThereRepetitionForDungeonItem)
	//		{
	//			//continue;
	//		}

	//		//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemId:%d, x:%d, y:%d."), TempDungeonItemId, x, y);
	//		//int tile = this->xy2tile(x, y);

	//		DungeonItemIndex++;
	//		ACWDungeonItem* TempItem = GetWorld()->SpawnActor<ACWDungeonItem>();
	//		if (nullptr != TempItem && TempItem->InitInServer(this, tile, TempDungeonItemId))
	//		{
	//			FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemData(TempDungeonItemId);
	//			if (TempDungeonItemData == nullptr)
	//			{
	//				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemData == nullptr, TempDungeonItemId:%d."), TempDungeonItemId);
	//				continue;
	//			}

	//			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemId:%d."), TempDungeonItemId);
	//			FVector TempPos = FVector::ZeroVector;
	//			this->tile2pos(tile, TempPos);
	//			TempPos.Z = TempGameData->DungeonTileRiseBeginZ;

	//			//TempItem->LoadMesh(TempDungeonItemData->DungeonItemResName);
	//			if (!TempItem->IsBuffObject())
	//			{
	//				UClass* TempDungeonItemVisibilityClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::LevelItemAsset, TempDungeonItemData->DungeonItemResName);
	//				if (TempDungeonItemVisibilityClass == nullptr)
	//				{
	//					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemVisibilityClass == nullptr, TempDungeonItemId:%d, DungeonItemResName:%s."), TempDungeonItemId, *TempDungeonItemData->DungeonItemResName);
	//					continue;
	//				}
	//				ACWDungeonItemVisibility* TempDungeonItemVisibility = GetWorld()->SpawnActor<ACWDungeonItemVisibility>(TempDungeonItemVisibilityClass);
	//				if (TempDungeonItemVisibility == nullptr)
	//				{
	//					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemVisibility == nullptr, TempDungeonItemId:%d, DungeonItemResName:%s."), TempDungeonItemId, *TempDungeonItemData->DungeonItemResName);
	//					continue;
	//				}

	//				FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
	//				TempDungeonItemVisibility->AttachToActor(TempItem, AttachmentRules);
	//				TempDungeonItemVisibility->SetOwner(TempItem);

	//				FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, RandomDungeonItemEuler()));
	//				TempItem->SetActorRotation(TempQ);

	//				TempItem->SetItemVisibilityActor(TempDungeonItemVisibility);
	//			}

	//			TempItem->SetActorLocation(TempPos);

	//			TempItem->SetCampTag(ECWCampTag::H);
	//			TempItem->SetCampControllerIndex(ECWCampControllerIndex::Eight);
	//			TempItem->SetControllerPawnIndex(DungeonItemIndex);
	//			TempItem->ForceNetUpdate();

	//			/*check(ArrayDungeonItem[tile] == nullptr);
	//			ArrayDungeonItem[tile] = TempItem;*/

	//			// added by FJC
	//			//ArrayDungeonItemGroup[tile] = ArrayDungeonItemGroup[tile] == nullptr ? GetWorld()->SpawnActor<ACWDungeonItemGroup>() : ArrayDungeonItemGroup[tile];
	//			//ArrayDungeonItemGroup[tile]->AddItem(TempItem);
	//		}
	//	}
	//}
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonItem()
{
	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	if (TempGameData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempGameData == nullptr, TempGameId:%d."), TempGameId);
		return false;
	}

	if (ArrayTileType.Num() != ArrayDungeonRegionId.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, ArrayTileType.Num() != ArrayDungeonRegionId.Num(), TempGameId:%d."), TempGameId);
		return false;
	}

	for (int i = 0; i < ArrayDungeonRegionId.Num(); ++i)
	{
		int TempDungeonRegionId = ArrayDungeonRegionId[i];
		if (TempDungeonRegionId <= 0)
			continue;

		ECWDungeonRegionType TempRegionType = ArrayTileType[i];
		if (TempRegionType == ECWDungeonRegionType::SpawnStart)
			continue;

		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonRegionId:%d, i:%d."), TempDungeonRegionId, i);
		FCWDungeonRegionDataStruct* TempDungeonRegionData = GetDungeonRegionData(TempDungeonRegionId);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonRegionData == nullptr, TempDungeonRegionId:%d, i:%d."), TempDungeonRegionId, i);
			continue;
		}

		std::vector<float> TempArrayPobability = FCWDungeonRegionDataUtils::GetArrayDungeonItemPobabilityFromString(TempDungeonRegionData->ArrayDungeonItemPobability);
		std::vector<std::vector<int32> > TempArrayArrayDungeonItem = FCWDungeonRegionDataUtils::GetArrayArrayDungeonItemFromString(TempDungeonRegionData->ArrayDungeonItem);
		if (TempArrayPobability.size() != TempArrayArrayDungeonItem.size())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempArrayPobability.size() != TempArrayArrayDungeonItem.size(), TempDungeonRegionId:%d, TempArrayPobability.size():%d, TempArrayArrayDungeonItem.size():%d, i:%d."), TempDungeonRegionId, TempArrayPobability.size(), TempArrayArrayDungeonItem.size(), i);
			continue;
		}

		for (int k = 0; k < TempArrayPobability.size(); ++k)
		{
			float TempPobability = TempArrayPobability[k];
			float TempRandom = RandomFloat(0.0, 1.0f);
			if (TempRandom <= TempPobability)
			{
				std::vector<int32> TempArrayDungeonItem = TempArrayArrayDungeonItem[k];
				if (TempArrayDungeonItem.empty())
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempArrayDungeonItem.empty(), TempDungeonRegionId:%d, TempArrayPobability.size():%d, TempArrayArrayDungeonItem.size():%d, k:%d."), TempDungeonRegionId, TempArrayPobability.size(), TempArrayArrayDungeonItem.size(), k);
					continue;
				}

				int32 TempIndex = rand() % TempArrayDungeonItem.size();
				int32 TempDungeonItemId = TempArrayDungeonItem[TempIndex];
				if (TempDungeonItemId == 0)
					continue;

				check(ArrayDungeonItemForData.IsValidIndex(i));
				float TempOutQEuler = RandomDungeonItemEuler();
				if (!IsThereFitForItemByQEuler(i, TempDungeonItemId, TempOutQEuler))
				{
					continue;
				}
				ArrayDungeonItemForData[i].AddItem(TempDungeonItemId, TempOutQEuler);
				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, i:%d, TempDungeonRegionId:%d, TempDungeonItemId:%d, TempOutQEuler:%f."), i, TempDungeonRegionId, TempDungeonItemId, TempOutQEuler);
			}
		}
	}

	for (int i = 0; i < ArrayDungeonItemForData.Num(); ++i)
	{
		FCWDungeonItemGroupData TempDungeonItemGroupData = ArrayDungeonItemForData[i];
		TArray<int32> TempOutArrayItem;
		TArray<float> TempOutArrayItemQEuler;
		TempDungeonItemGroupData.GetArrayItem(TempOutArrayItem);
		TempDungeonItemGroupData.GetArrayItemQEuler(TempOutArrayItemQEuler);
		if (TempOutArrayItem.Num() != TempOutArrayItemQEuler.Num())
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempOutArrayItem.Num() != TempOutArrayItemQEuler.Num(), TempOutArrayItem.Num():%d, TempOutArrayItemQEuler.Num():%d, i:%d."), TempOutArrayItem.Num(), TempOutArrayItemQEuler.Num(), i);
			continue;
		}

		for (int k = 0; k < TempOutArrayItem.Num(); ++k)
		{
			int TempDungeonItemId = TempOutArrayItem[k];
			if (TempDungeonItemId <= 0)
				continue;

			float TempQEuler = TempOutArrayItemQEuler[k];
			ACWDungeonItem* TempItem = GetWorld()->SpawnActor<ACWDungeonItem>();
			if (nullptr != TempItem && TempItem->InitInServer(this, i, TempDungeonItemId, TempQEuler))
			{
				FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemData(TempDungeonItemId);
				if (TempDungeonItemData == nullptr)
				{
					UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemData == nullptr, TempDungeonItemId:%d."), TempDungeonItemId);
					continue;
				}

				UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemId:%d."), TempDungeonItemId);
				FVector TempPos = FVector::ZeroVector;
				this->tile2pos(i, TempPos);
				TempPos.Z = TempGameData->DungeonTileRiseBeginZ;

				if (!TempItem->IsBuffObject())
				{
					UClass* TempDungeonItemVisibilityClass = FCWCfgUtils::GetAssetClassFromCfg<UClass>(this, FCWCfgKey::LevelItemAsset, TempDungeonItemData->DungeonItemResName);
					if (TempDungeonItemVisibilityClass == nullptr)
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemVisibilityClass == nullptr, TempDungeonItemId:%d, DungeonItemResName:%s."), TempDungeonItemId, *TempDungeonItemData->DungeonItemResName);
						continue;
					}
					ACWDungeonItemVisibility* TempDungeonItemVisibility = GetWorld()->SpawnActor<ACWDungeonItemVisibility>(TempDungeonItemVisibilityClass);
					if (TempDungeonItemVisibility == nullptr)
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonItem, TempDungeonItemVisibility == nullptr, TempDungeonItemId:%d, DungeonItemResName:%s."), TempDungeonItemId, *TempDungeonItemData->DungeonItemResName);
						continue;
					}

					FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
					TempDungeonItemVisibility->AttachToActor(TempItem, AttachmentRules);
					TempDungeonItemVisibility->SetOwner(TempItem);

					FQuat TempQ = FQuat::MakeFromEuler(FVector(0.0f, 0.0f, TempQEuler));
					TempItem->SetActorRotation(TempQ);

					TempItem->SetItemVisibilityActor(TempDungeonItemVisibility);
				}

				TempItem->SetActorLocation(TempPos);

				TempItem->SetCampTag(ECWCampTag::H);
				TempItem->SetCampControllerIndex(ECWCampControllerIndex::Eight);
				TempItem->SetControllerPawnIndex(++DungeonItemIndex);
				TempItem->ForceNetUpdate();

				check(ArrayDungeonItemGroup.IsValidIndex(i));
				ArrayDungeonItemGroup[i]->AddItem(k, TempItem);
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GeneratePawnStart()
{
	int TempRandomIndex = RandomInt(0, 2);
	return GeneratePawnStartByIdx(TempRandomIndex);
}


bool ACWRandomDungeonGenerator::GeneratePawnStartByIdx(int32 RandomIdx)
{
	ACWMap* TempMap = GetMap();
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_CWPawnStart);
	check(TempMap && TempDungeonData && TempleteClass);

	if (RandomIdx >= TempDungeonData->ACampPawnStart.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, RandomIdx >= TempDungeonData->ACampPawnStart.Num(), RandomIdx:%d, ACampPawnStart.Num():%d."), RandomIdx, TempDungeonData->ACampPawnStart.Num());
		return false;
	}

	if (RandomIdx >= TempDungeonData->BCampPawnStart.Num())
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, RandomIdx >= TempDungeonData->BCampPawnStart.Num(), RandomIdx:%d, BCampPawnStart.Num():%d."), RandomIdx, TempDungeonData->BCampPawnStart.Num());
		return false;
	}

	// Generate Map (Tile - FPawnStartData)
	int32 GenerateAIdx = 1, GenerateBIdx = 1;	// 生成出生点索引
	TMap<int32, FPawnStartData> GenerateMap;

	std::vector<std::vector<int32> > ACampPawnStart = FCWDungeonDataUtils::GetArrayArrayDungeonPawnStartFromString(TempDungeonData->ACampPawnStart[RandomIdx]);
	std::vector<std::vector<int32> > BCampPawnStart = FCWDungeonDataUtils::GetArrayArrayDungeonPawnStartFromString(TempDungeonData->BCampPawnStart[RandomIdx]);
	for (std::vector<std::vector<int32> >::iterator iter = ACampPawnStart.begin(); iter != ACampPawnStart.end(); ++iter)
	{
		if (iter->size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, ACampPawnStart, iter->size() != 2, RandomIdx:%d, iter->size():%d."), RandomIdx, iter->size());
			return false;
		}
		int32 x = iter->at(0);
		int32 y = iter->at(1);
		x += offsetX;
		y += offsetY;
		int tile = this->xy2tile(x, y);
		if (tile == -1)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, A tile == -1, x:%d, y:%d, RandomIdx:%d."), x, y, RandomIdx);
			continue;
		}
		GenerateMap.Add(tile, FPawnStartData(ECWCampTag::A, ECWCampControllerIndex::One, 0, GenerateAIdx++, -90.f));
		FVector spawnPos = FVector::ZeroVector;
	}

	for (std::vector<std::vector<int32> >::iterator iter = BCampPawnStart.begin(); iter != BCampPawnStart.end(); ++iter)
	{
		if (iter->size() != 2)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, BCampPawnStart, iter->size() != 2, RandomIdx:%d, iter->size():%d."), RandomIdx, iter->size());
			return false;
		}
		int32 x = iter->at(0);
		int32 y = iter->at(1);
		x = TempDungeonData->DungeonWidth - 1 - x + offsetX;
		y = TempDungeonData->DungeonHeight - 1 - y + offsetY;
		int tile = this->xy2tile(x, y);
		if (tile == -1)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GeneratePawnStartByIdx, B tile == -1, x:%d, y:%d, RandomIdx:%d."), x, y, RandomIdx);
			continue;
		}
		GenerateMap.Add(tile, FPawnStartData(ECWCampTag::B, ECWCampControllerIndex::One, 0, GenerateBIdx++, 90.f));
		FVector spawnPos = FVector::ZeroVector;
	}

	// 读取常量配置表出生组数据(覆盖)
	TArray<int32> NewPawnIdArray;
	const FString& PawnStartIdKey = FString::Printf(TEXT("StartPawnIdGroup%d"), RandomIdx);
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, PawnStartIdKey))
	{
		NewPawnIdArray = FCWCfgUtils::FString_To_Array_Int32(ConstData->Param);
	}

	// 生成棋子出生点
	TArray<ACWPawnStart*> NewPawnStartList;
	NewPawnStartList.Init(nullptr, ArrayPawnStart.Num());
	for (const auto& SpawnData : GenerateMap)
	{
		TempMap->setMapTileAttribute(SpawnData.Key, (uint8)ECWDungeonTileAttribute::PawnStart);
		FVector TempPos = FVector::ZeroVector;
		this->tile2pos(SpawnData.Key, TempPos);
		ACWPawnStart* TempPawnStart = GetWorld()->SpawnActor<ACWPawnStart>(TempleteClass, TempPos, FRotator(0.0f, SpawnData.Value.PawnYaw, 0.0f));
		if (TempPawnStart != nullptr)
		{
			// 优先读取配置表出生数据(PawnId)
			const int32 NewIdx = SpawnData.Value.PawnIdx;
			const int32 NewId = NewPawnIdArray.IsValidIndex(NewIdx-1) ? NewPawnIdArray[NewIdx-1] : SpawnData.Value.PawnId;

			TempPawnStart->Tile = SpawnData.Key;
			TempPawnStart->CampTag = SpawnData.Value.CampTag;
			TempPawnStart->CampControllerIndex = SpawnData.Value.CampIdx;
			TempPawnStart->PawnIndex = NewIdx;
			TempPawnStart->PawnId = NewId;

			int32 TempX = 0, TempY = 0;
			this->tile2xy(TempPawnStart->Tile, TempX, TempY);
			TempPawnStart->X = TempX;
			TempPawnStart->Y = TempY;

			NewPawnStartList[SpawnData.Key] = TempPawnStart;

			UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT(">> SpawnData.Key:%d, x:%d, y:%d, TempPos.X:%f, TempPos.Y:%f."), 
				SpawnData.Key, TempPawnStart->X, TempPawnStart->Y, TempPos.X, TempPos.Y);
		}
	}
	ArrayPawnStart = NewPawnStartList;

	return true;
}


std::vector<ECWEdgeOutSideDecorateCoord> ACWRandomDungeonGenerator::AnalyzeHeightPrefer(int32 TempInt32)
{
	std::vector<ECWEdgeOutSideDecorateCoord> TempArrayCoord;

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::YZero) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::YZero);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::YHeightMax) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::YHeightMax);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::XZero) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::XZero);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::XWidthMax) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::XWidthMax);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::XZeroYZero) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::XZeroYZero);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::XZeroYHeightMax) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::XZeroYHeightMax);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::XWidthMaxYHeightMax);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::YZeroXWidthMax) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::YZeroXWidthMax);
	}

	if ((TempInt32 & (int32)ECWEdgeOutSideDecorateCoord::Center) > 0)
	{
		TempArrayCoord.push_back(ECWEdgeOutSideDecorateCoord::Center);
	}

	return TempArrayCoord;
}

void ACWRandomDungeonGenerator::DestroyDungeonTileInServer(int32 ParamTile)
{
	if (ParamTile < 0 || ParamTile >= ArrayDungeonTile.Num())
		return;

	ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[ParamTile];
	if (TempDungeonTile != nullptr)
	{
		TempDungeonTile->Destroy();
		ArrayDungeonTile[ParamTile] = nullptr;
	}
}

void ACWRandomDungeonGenerator::DestroyDungeonItemInServer(int32 ParamTile)
{
	/*if (ParamTile < 0 || ParamTile >= ArrayDungeonItem.Num())
		return;

	ACWDungeonItem* TempDungeonItem = ArrayDungeonItem[ParamTile];
	if (TempDungeonItem != nullptr)
	{
		TempDungeonItem->Destroy();
		ArrayDungeonItem[ParamTile] = nullptr;
	}*/
}

bool ACWRandomDungeonGenerator::GenerateDungeonFall()
{
	return GenerateDungeonFallNew();

	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	ACWGameMode* TempGameMode = GetWorld()->GetAuthGameMode<ACWGameMode>();
	check(TempGameMode);
	ACWGameState* TempGameState = TempGameMode->GetGameState<ACWGameState>();
	check(TempGameState);
	int32 TempCurDungeonTileFallIndex = TempGameState->GetCurDungeonTileFallIndex();
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	NetMulticastRPCHideFallWarning(TempCurDungeonTileFallIndex);

	int TempTotalFallCount = (TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex) * 2 + (TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex) * 2 - 1;

	int index = 0;
	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempCurDungeonTileFallIndex)
			{
				FTimerDelegate DungeonFallCallback;
				DungeonFallCallback.BindLambda([=]()
				{
					int tx = x + offsetX;
					int ty = y + offsetY;

					int TempTile = ACWMap::xy2tile(tx, ty);
					ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
					if (TempDungeonTile != nullptr)
					{
						TempDungeonTile->DoFallInServer();
					}

					ArrayDungeonItemGroup[TempTile]->DoFallInServer();
					
					TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
					if (PawnPtr.IsValid())
					{
						PawnPtr->DoFallInServer();
					}
				});

				FTimerHandle DungeonFallTimer;
				GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonFallCallback, 1.0f, false, index * TempGameData->DungeonTileFallInterval);
				index++;

				int tx = x + offsetX;
				int ty = y + offsetY;
				uint8 TempTileAttribute = TempMap->getMapTileAttribute(tx, ty);
				TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
				TempMap->setMapTileAttribute(tx, ty, TempTileAttribute);

				for (int sy = 0; sy < DungeonHeight; ++sy)
				{
					for (int dx = tx - 1; dx >= 0; --dx)
					{
						FTimerDelegate DFallCallback;
						DFallCallback.BindLambda([=]()
						{
							int TempTile = ACWMap::xy2tile(dx, sy);
							ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
							if (TempDungeonTile != nullptr)
							{
								TempDungeonTile->DoFallInServer();
							}

							ACWDungeonDecorateTile* TempDecorateTile = ArrayDungeonDecorateTile[TempTile];
							if (TempDecorateTile != nullptr)
							{
								TempDecorateTile->DoFallInServer();
							}

							ArrayDungeonItemGroup[TempTile]->DoFallInServer();

							TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
							if (PawnPtr.IsValid())
							{
								PawnPtr->DoFallInServer();
							}
						});

						FTimerHandle DFallTimer;
						GetWorldTimerManager().SetTimer(DFallTimer, DFallCallback, 1.0f, false, (index - 1) * TempGameData->DungeonTileFallInterval);
					}
				}
			}
		}
	}

	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (y == TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex - 1)
			{
				FTimerDelegate DungeonFallCallback;
				DungeonFallCallback.BindLambda([=]()
				{
					int tx = x + offsetX;
					int ty = y + offsetY;

					int TempTile = ACWMap::xy2tile(tx, ty);
					ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
					if (TempDungeonTile != nullptr)
					{
						TempDungeonTile->DoFallInServer();
					}

					ArrayDungeonItemGroup[TempTile]->DoFallInServer();

					TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
					if (PawnPtr.IsValid())
					{
						PawnPtr->DoFallInServer();
					}
				});


				FTimerHandle DungeonFallTimer;
				GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonFallCallback, 1.0f, false, index * TempGameData->DungeonTileFallInterval);
				index++;

				int tx = x + offsetX;
				int ty = y + offsetY;
				uint8 TempTileAttribute = TempMap->getMapTileAttribute(tx, ty);
				TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
				TempMap->setMapTileAttribute(tx, ty, TempTileAttribute);

				for (int sx = 0; sx < DungeonWidth; ++sx)
				{
					for (int dy = ty + 1; dy < DungeonHeight; ++dy)
					{
						FTimerDelegate DFallCallback;
						DFallCallback.BindLambda([=]()
						{
							int TempTile = ACWMap::xy2tile(sx, dy);
							ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
							if (TempDungeonTile != nullptr)
							{
								TempDungeonTile->DoFallInServer();
							}

							ACWDungeonDecorateTile* TempDecorateTile = ArrayDungeonDecorateTile[TempTile];
							if (TempDecorateTile != nullptr)
							{
								TempDecorateTile->DoFallInServer();
							}

							ArrayDungeonItemGroup[TempTile]->DoFallInServer();

							TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
							if (PawnPtr.IsValid())
							{
								PawnPtr->DoFallInServer();
							}
						});

						FTimerHandle DFallTimer;
						GetWorldTimerManager().SetTimer(DFallTimer, DFallCallback, 1.0f, false, (index - 1) * TempGameData->DungeonTileFallInterval);
					}
				}
			}
		}
	}

	for (int y = TempDungeonData->DungeonHeight - 1 - TempCurDungeonTileFallIndex; y >= 0 ; --y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex - 1)
			{
				FTimerDelegate DungeonFallCallback;
				DungeonFallCallback.BindLambda([x, y, TempMap, this]()
				{
					int tx = x + offsetX;
					int ty = y + offsetY;

					int TempTile = ACWMap::xy2tile(tx, ty);
					ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
					if (TempDungeonTile != nullptr)
					{
						TempDungeonTile->DoFallInServer();
					}

					ArrayDungeonItemGroup[TempTile]->DoFallInServer();

					TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
					if (PawnPtr.IsValid())
					{
						PawnPtr->DoFallInServer();
					}
				});


				FTimerHandle DungeonFallTimer;
				GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonFallCallback, 1.0f, false, index * TempGameData->DungeonTileFallInterval);
				index++;

				int tx = x + offsetX;
				int ty = y + offsetY;
				uint8 TempTileAttribute = TempMap->getMapTileAttribute(tx, ty);
				TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
				TempMap->setMapTileAttribute(tx, ty, TempTileAttribute);

				for (int dx = tx + 1; dx < DungeonWidth; ++dx)
				{
					FTimerDelegate DFallCallback;
					DFallCallback.BindLambda([=]()
					{
						int TempTile = ACWMap::xy2tile(dx, ty);
						ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
						if (TempDungeonTile != nullptr)
						{
							TempDungeonTile->DoFallInServer();
						}

						ACWDungeonDecorateTile* TempDecorateTile = ArrayDungeonDecorateTile[TempTile];
						if (TempDecorateTile != nullptr)
						{
							TempDecorateTile->DoFallInServer();
						}

						ArrayDungeonItemGroup[TempTile]->DoFallInServer();

						TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
						if (PawnPtr.IsValid())
						{
							PawnPtr->DoFallInServer();
						}
					});

					FTimerHandle DFallTimer;
					GetWorldTimerManager().SetTimer(DFallTimer, DFallCallback, 1.0f, false, (index - 1) * TempGameData->DungeonTileFallInterval);
				}
			}
		}
	}

	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = TempDungeonData->DungeonWidth - 1 - TempCurDungeonTileFallIndex; x >= 0; --x)
		{
			if (y == TempCurDungeonTileFallIndex)
			{
				FTimerDelegate DungeonFallCallback;
				DungeonFallCallback.BindLambda([=]()
				{
					int tx = x + offsetX;
					int ty = y + offsetY;

					int TempTile = ACWMap::xy2tile(tx, ty);
					ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
					if (TempDungeonTile != nullptr)
					{
						TempDungeonTile->DoFallInServer();
					}

					ArrayDungeonItemGroup[TempTile]->DoFallInServer();

					TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
					if (PawnPtr.IsValid())
					{
						PawnPtr->DoFallInServer();
					}

					if (index == TempTotalFallCount)
					{
						//this->OnDungeonTileFallFinishEventInServer.Broadcast();
						Cast<ACWGameMode>(GetWorld()->GetAuthGameMode())->GungeonTileFallEndAndNextTurnBegin();
					}
				});


				FTimerHandle DungeonFallTimer;
				GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonFallCallback, 1.0f, false, index * TempGameData->DungeonTileFallInterval);
				index++;

				int tx = x + offsetX;
				int ty = y + offsetY;
				uint8 TempTileAttribute = TempMap->getMapTileAttribute(tx, ty);
				TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
				TempMap->setMapTileAttribute(tx, ty, TempTileAttribute);

				for (int sx = 0; sx < DungeonWidth; ++sx)
				{
					for (int dy = ty - 1; dy >= 0; --dy)
					{
						FTimerDelegate DFallCallback;
						DFallCallback.BindLambda([=]()
						{
							int TempTile = ACWMap::xy2tile(sx, dy);
							ACWDungeonTile* TempDungeonTile = ArrayDungeonTile[TempTile];
							if (TempDungeonTile != nullptr)
							{
								TempDungeonTile->DoFallInServer();
							}

							ACWDungeonDecorateTile* TempDecorateTile = ArrayDungeonDecorateTile[TempTile];
							if (TempDecorateTile != nullptr)
							{
								TempDecorateTile->DoFallInServer();
							}

							ArrayDungeonItemGroup[TempTile]->DoFallInServer();

							TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
							if (PawnPtr.IsValid())
							{
								PawnPtr->DoFallInServer();
							}
						});

						FTimerHandle DFallTimer;
						GetWorldTimerManager().SetTimer(DFallTimer, DFallCallback, 1.0f, false, (index - 1) * TempGameData->DungeonTileFallInterval);
					}
				}
			}
		}
	}
	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonFallNew()
{
	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	ACWGameMode* TempGameMode = GetWorld()->GetAuthGameMode<ACWGameMode>();
	check(TempGameMode);
	ACWGameState* TempGameState = TempGameMode->GetGameState<ACWGameState>();
	check(TempGameState);
	int32 TempCurDungeonTileFallIndex = TempGameState->GetCurDungeonTileFallIndex();
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	NetMulticastRPCHideFallWarning(TempCurDungeonTileFallIndex);

	ECWDungeonArea area = (ECWDungeonArea)(TempCurDungeonTileFallIndex % (int)ECWDungeonArea::Max);
	DoMonsterAction(area, ECWDungeonFallPhase::Fall);

	/*int32 dungeonL = TempDungeonData->DungeonWidthExtension;
	int32 dungeonW = TempDungeonData->DungeonHeightExtension;
	int safeAreaStartX = TempGameData->SafeAreaMinX;
	int safeAreaStartY = TempGameData->SafeAreaMinY;
	int safeAreaEndX = TempGameData->SafeAreaMaxX;
	int safeAreaEndY = TempGameData->SafeAreaMaxY;
	int curFallCount = TempGameData->EachRoundFallNum;
	int tmpTotalCount = 0;
	int levelX = 0;
	int levelY = 0;
	int maxLevelX = 0;
	int maxLevelY = 0;
	CWG_LOG("GenerateDungeonFallNew while begin");
	while (tmpTotalCount < curFallCount) {
		tmpTotalCount = 0;
		if (area == ECWDungeonArea::RD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = 0; x <= offsetY + levelX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetY; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - safeAreaStartX - offsetX - 1;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::RT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = 0; x <= levelX + offsetX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = dungeonW - safeAreaStartY - offsetY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetX; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - offsetX - safeAreaStartX - 1;
			maxLevelY = dungeonW - offsetY - safeAreaStartY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else {
			break;
		}
		if (levelX >= maxLevelX && levelY >= maxLevelY) break;
	}
	CWG_LOG("GenerateDungeonFallNew while end");
	Cast<ACWGameMode>(GetWorld()->GetAuthGameMode())->GungeonTileFallEndAndNextTurnBegin();*/


	FTimerDelegate DungeonFallCallback;
	DungeonFallCallback.BindLambda([=]()
	{
		int32 dungeonL = TempDungeonData->DungeonWidthExtension;
		int32 dungeonW = TempDungeonData->DungeonHeightExtension;
		int safeAreaStartX = TempGameData->SafeAreaMinX;
		int safeAreaStartY = TempGameData->SafeAreaMinY;
		int safeAreaEndX = TempGameData->SafeAreaMaxX;
		int safeAreaEndY = TempGameData->SafeAreaMaxY;
		int curFallCount = TempGameData->EachRoundFallNum;
		int tmpTotalCount = 0;
		int levelX = 0;
		int levelY = 0;
		int maxLevelX = 0;
		int maxLevelY = 0;
		CWG_LOG("GenerateDungeonFallNew while begin");
		while (tmpTotalCount < curFallCount) {
			tmpTotalCount = 0;
			if (area == ECWDungeonArea::RD) {
				for (int y = 0; y <= offsetX + levelY; ++y) {
					for (int x = 0; x <= offsetY + levelX; ++x) {
						if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
							continue;
						DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
						if (tmpTotalCount >= curFallCount) break;
					}
				}
				maxLevelX = safeAreaEndX + offsetX;
				maxLevelY = safeAreaEndY + offsetY;
				if (levelX < maxLevelX) levelX++;
				if (levelY < maxLevelY) levelY++;
			}
			else if (area == ECWDungeonArea::LD) {
				for (int y = 0; y <= offsetX + levelY; ++y) {
					for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetY; --x) {
						if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
							continue;
						DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
						if (tmpTotalCount >= curFallCount) break;
					}
				}
				maxLevelX = dungeonL - safeAreaStartX - offsetX - 1;
				maxLevelY = safeAreaEndY + offsetY;
				if (levelX < maxLevelX) levelX++;
				if (levelY < maxLevelY) levelY++;
			}
			else if (area == ECWDungeonArea::RT) {
				for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
					for (int x = 0; x <= levelX + offsetX; ++x) {
						if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
							continue;
						DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
						if (tmpTotalCount >= curFallCount) break;
					}
				}
				maxLevelX = safeAreaEndX + offsetX;
				maxLevelY = dungeonW - safeAreaStartY - offsetY - 1;
				if (levelX < maxLevelX) levelX++;
				if (levelY < maxLevelY) levelY++;
			}
			else if (area == ECWDungeonArea::LT) {
				for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
					for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetX; --x) {
						if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
							continue;
						DoFallDown(TempMap, x, y, tmpTotalCount, curFallCount);
						if (tmpTotalCount >= curFallCount) break;
					}
				}
				maxLevelX = dungeonL - offsetX - safeAreaStartX - 1;
				maxLevelY = dungeonW - offsetY - safeAreaStartY - 1;
				if (levelX < maxLevelX) levelX++;
				if (levelY < maxLevelY) levelY++;
			}
			else {
				break;
			}
			if (levelX >= maxLevelX && levelY >= maxLevelY) break;
		}
		CWG_LOG("GenerateDungeonFallNew while end");
		Cast<ACWGameMode>(GetWorld()->GetAuthGameMode())->GungeonTileFallEndAndNextTurnBegin();
	});

	// 获取延迟掉落时间
	float LandFallDelay = 2.f;
	const int32 MyGameId = GetGameId();
	if (const FCWGameDataStruct* GameData = FCWCfgUtils::GetGameData(this, MyGameId))
	{
		TArray<float> LandFallDelays = FCWCfgUtils::FString_To_Array_Float(GameData->LandFallDelay);
		if (LandFallDelays.Num() >= 2)
		{
			LandFallDelay = (TempCurDungeonTileFallIndex == 1) ? LandFallDelays[0] : LandFallDelays[1];
		}
	}
	FTimerHandle DungeonFallTimer;
	GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonFallCallback, LandFallDelay, false);
	
	return true;
}

void ACWRandomDungeonGenerator::DoFallDown(ACWMap* TempMap, int x, int y, int &tmpTotalCount, int curFallCount)
{
	if (tmpTotalCount > curFallCount) return;

	uint8 TempTileAttribute = TempMap->getMapTileAttribute(x, y);
	TempTileAttribute |= (uint8)ECWDungeonTileAttribute::Obstacle;
	TempMap->setMapTileAttribute(x, y, TempTileAttribute);

	int TempTile = ACWMap::xy2tile(x, y);
	ACWDungeonTile* TempDungeonTile = nullptr;
	if (TempTile >= 0 && TempTile < ArrayDungeonTile.Num()) {
		TempDungeonTile = ArrayDungeonTile[TempTile];
	}
	if (TempDungeonTile != nullptr) {
		TempDungeonTile->DoFallInServer();
		tmpTotalCount++;
	}

	ACWDungeonItemGroup* TempDungeonItemGroup = nullptr;
	if (TempTile >= 0 && TempTile < ArrayDungeonItemGroup.Num()) 
	{
		TempDungeonItemGroup = ArrayDungeonItemGroup[TempTile];
	}
	if (TempDungeonItemGroup != nullptr)
	{
		TempDungeonItemGroup->DoFallInServer();
		TempDungeonItemGroup->Destroy();
	}

	ACWDungeonDecorateTile* TempDecorateTile = nullptr;
	if (TempTile >= 0 && TempTile < ArrayDungeonDecorateTile.Num()) 
	{
		TempDecorateTile = ArrayDungeonDecorateTile[TempTile];
	}

	if (TempDecorateTile != nullptr)
	{
		TempDecorateTile->DoFallInServer();
	}

	TWeakObjectPtr<ACWPawn> PawnPtr = TempMap->GetPawnByTile(TempTile);
	if (PawnPtr.IsValid()) 
	{
		PawnPtr->DoFallInServer();
	}
}

void ACWRandomDungeonGenerator::DoWarning(ACWMap* TempMap, int x, int y, int &tmpTotalCount, int curFallCount)
{
	if (tmpTotalCount > curFallCount) return;

	int TempTile = ACWMap::xy2tile(x, y);
	ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
	ACWDungeonTile* TempDungeonTile = nullptr;
	if (TempTile >= 0 && TempTile < ArrayDungeonTile.Num()) {
		TempDungeonTile = ArrayDungeonTile[TempTile];
	}
	if (TempMapTile != nullptr && TempDungeonTile != nullptr) {
		TempMapTile->FallWarningInClient();
		tmpTotalCount++;
	}
}

void ACWRandomDungeonGenerator::HideWarning(ACWMap* TempMap, int x, int y, int &tmpTotalCount, int curFallCount)
{
	if (tmpTotalCount > curFallCount) return;

	int TempTile = ACWMap::xy2tile(x, y);
	ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
	ACWDungeonTile* TempDungeonTile = nullptr;
	if (TempTile >= 0 && TempTile < ArrayDungeonTile.Num()) {
		TempDungeonTile = ArrayDungeonTile[TempTile];
	}
	if (TempMapTile != nullptr && TempDungeonTile != nullptr) {
		TempMapTile->HideFallWarningInClient();
		tmpTotalCount++;
	}
}

void ACWRandomDungeonGenerator::DoMonsterAction(ECWDungeonArea area, ECWDungeonFallPhase phase)
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	ACWAIPawn* AIPawn = nullptr;
	FVector rd, ld, lt, rt;
	bool isOK = GetEdgeDiagonalPoint(rd, ld, rt, lt, 0);
	
	for (TActorIterator<ACWAIPawn> Iter(GetWorld()); Iter; ++Iter)
		AIPawn = *Iter;
	
	if (nullptr == AIPawn || !IsValid(AIPawn) || !isOK) return;

	FVector location = AIPawn->GetActorLocation();
	if (ECWDungeonArea::RD == area)
		xy2pos(0, 0, location);
	else if (ECWDungeonArea::LD == area)
		xy2pos(TempDungeonData->DungeonWidthExtension - 1, 0, location);
	else if (ECWDungeonArea::LT == area)
		xy2pos(TempDungeonData->DungeonWidthExtension - 1, TempDungeonData->DungeonHeightExtension - 1, location);
	else if (ECWDungeonArea::RT == area)
		xy2pos(0, TempDungeonData->DungeonHeightExtension - 1, location);

	FRotator rot = AIPawn->GetActorRotation();
	FVector centerPos = GetSceneCenterPoint();
	if (IsValidSceneCenterPoint(centerPos))
		rot = UKismetMathLibrary::FindLookAtRotation(location, centerPos);
		UKismetMathLibrary::BreakRotator(rot, rot.Roll, rot.Pitch, rot.Yaw);
		rot = UKismetMathLibrary::MakeRotator(rot.Roll, rot.Pitch, rot.Yaw - 90);
	
	if (phase == ECWDungeonFallPhase::Fall) {
		AIPawn->NetMulticastRPCDoFall(location, rot);
	}
	/*else if (phase == ECWDungeonFallPhase::FallWarn) {
		AIPawn->NetMulticastRPCDoFallWarn(location, rot);
	}
	else if (phase == ECWDungeonFallPhase::HideFallWarn) {
		AIPawn->NetMulticastRPCDoHideWarn(location, rot);
	}*/
}

TArray<int32> ACWRandomDungeonGenerator::GetDungeonFallTileArray()
{
	if (!IsInDungeonFallState())
	{
		return TArray<int32>();
	}

	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	ACWGameMode* TempGameMode = GetWorld()->GetAuthGameMode<ACWGameMode>();
	check(TempGameMode);
	ACWGameState* TempGameState = TempGameMode->GetGameState<ACWGameState>();
	check(TempGameState);
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	TArray<int32> OutTileArray;
	const int32 TempCurDungeonTileFallIndex = TempGameState->GetCurDungeonTileFallIndex();
	const int32 TempTotalFallCount = (TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex) * 2 + (TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex) * 2 - 1;

	for (int32 y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int32 x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempCurDungeonTileFallIndex)
			{
				{
					int32 tx = x + offsetX;
					int32 ty = y + offsetY;
					int32 TempTile = ACWMap::xy2tile(tx, ty);
					OutTileArray.AddUnique(TempTile);
				}

				int32 tx = x + offsetX;
				int32 ty = y + offsetY;
				for (int32 sy = 0; sy < DungeonHeight; ++sy)
				{
					for (int32 dx = tx - 1; dx >= 0; --dx)
					{
						{
							int32 TempTile = ACWMap::xy2tile(dx, sy);
							OutTileArray.AddUnique(TempTile);
						}
					}
				}
			}
		}
	}

	for (int32 y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int32 x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (y == TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex - 1)
			{
				{
					int32 tx = x + offsetX;
					int32 ty = y + offsetY;
					int32 TempTile = ACWMap::xy2tile(tx, ty);
					OutTileArray.AddUnique(TempTile);
				}

				int32 tx = x + offsetX;
				int32 ty = y + offsetY;
				for (int32 sx = 0; sx < DungeonWidth; ++sx)
				{
					for (int32 dy = ty + 1; dy < DungeonHeight; ++dy)
					{
						{
							int32 TempTile = ACWMap::xy2tile(sx, dy);
							OutTileArray.AddUnique(TempTile);
						}
					}
				}
			}
		}
	}

	for (int32 y = TempDungeonData->DungeonHeight - 1 - TempCurDungeonTileFallIndex; y >= 0; --y)
	{
		for (int32 x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex - 1)
			{
				{
					int32 tx = x + offsetX;
					int32 ty = y + offsetY;
					int32 TempTile = ACWMap::xy2tile(tx, ty);
					OutTileArray.AddUnique(TempTile);
				}

				int32 tx = x + offsetX;
				int32 ty = y + offsetY;
				for (int32 dx = tx + 1; dx < DungeonWidth; ++dx)
				{
					{
						int32 TempTile = ACWMap::xy2tile(dx, ty);
						OutTileArray.AddUnique(TempTile);
					}
				}
			}
		}
	}

	for (int32 y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int32 x = TempDungeonData->DungeonWidth - 1 - TempCurDungeonTileFallIndex; x >= 0; --x)
		{
			if (y == TempCurDungeonTileFallIndex)
			{
				{
					int32 tx = x + offsetX;
					int32 ty = y + offsetY;
					int32 TempTile = ACWMap::xy2tile(tx, ty);
					OutTileArray.AddUnique(TempTile);
				}

				int32 tx = x + offsetX;
				int32 ty = y + offsetY;
				for (int32 sx = 0; sx < DungeonWidth; ++sx)
				{
					for (int32 dy = ty - 1; dy >= 0; --dy)
					{
						{
							int32 TempTile = ACWMap::xy2tile(sx, dy);
							OutTileArray.AddUnique(TempTile);
						}
					}
				}
			}
		}
	}

	return OutTileArray;
}

bool ACWRandomDungeonGenerator::IsInDungeonFallState()
{
	const int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	ACWGameState* MyGameState = GetWorld()->GetGameState<ACWGameState>();
	check(MyGameState);

	const int32 CurRoundIndex = MyGameState->GetCurRoundIndex();
	const int32 CurDungeonTileFallIndex = MyGameState->GetCurDungeonTileFallIndex();

	// 掉落已达到最大次数 / 开始回合无效
	const int32 FirstDungeonTileFallRoundIndex = TempGameData->FirstDungeonTileFallRoundIndex;
	if (CurDungeonTileFallIndex >= TempGameData->DungeonTileFallCountMax ||
		FirstDungeonTileFallRoundIndex <= 0)
	{
		return false;
	}

	// 掉落阶段
	if (CurRoundIndex == FirstDungeonTileFallRoundIndex)
	{
		return true;
	}
	else if (CurRoundIndex > FirstDungeonTileFallRoundIndex)
	{
		check(TempGameData->DungeonTileFallRoundInterval > 0);
		const int32 TempIndex = CurRoundIndex - FirstDungeonTileFallRoundIndex;
		if (TempIndex % TempGameData->DungeonTileFallRoundInterval == 0)
		{
			return true;
		}
	}

	// 预警阶段
	if (CurRoundIndex + 1 == FirstDungeonTileFallRoundIndex)
	{
		return true;
	}
	else if (CurRoundIndex + 1 > FirstDungeonTileFallRoundIndex)
	{
		check(TempGameData->DungeonTileFallRoundInterval > 0);
		const int32 TempIndex = CurRoundIndex + 1 - FirstDungeonTileFallRoundIndex;
		if (TempIndex % TempGameData->DungeonTileFallRoundInterval == 0)
		{
			return true;
		}
	}

	return false;
}

bool ACWRandomDungeonGenerator::GenerateRandomEvtCtrl()
{
	RandomEventCtrl = NewObject<UCWRandomEventCtrl>(this, UCWRandomEventCtrl::StaticClass());
	check(RandomEventCtrl);

	AddOwnedComponent(RandomEventCtrl);
	RandomEventCtrl->RegisterComponent();
	RandomEventCtrl->SetIsReplicated(true);
	RandomEventCtrl->InitInServer();
	return true;
}

UCWRandomEventCtrl* ACWRandomDungeonGenerator::GetRandomEvtCtrl()
{
	return RandomEventCtrl;
}

bool ACWRandomDungeonGenerator::GenerateDungeonDecorateFallInServer()
{
	//if (!IsInServer())
	//	return true;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonDecorateTagMinMax = FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(TempDungeonData->ArrayDungeonDecorateTagMinMax);
	if (TempArrayDungeonDecorateTagMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonDecorateFallInServer, TempArrayDungeonDecorateTagMinMax.size() != 2, TempArrayDungeonDecorateTagMinMax.size():%d."), TempArrayDungeonDecorateTagMinMax.size());
		return false;
	}
	int32 TempMin = TempArrayDungeonDecorateTagMinMax[0];
	int32 TempMax = TempArrayDungeonDecorateTagMinMax[1];
	if (TempMin > TempMax)
		TempMin = TempMax;
	for (TActorIterator<AStaticMeshActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AStaticMeshActor* TempActor = *Iter;
		UStaticMeshComponent* SMComp = TempActor ? TempActor->GetStaticMeshComponent() : nullptr;
		if (SMComp != nullptr && SMComp->ComponentTags.Num() > 0)
		{
			for (int32 TempTag = TempMin; TempTag <= TempMax; ++TempTag)
			{
				FString TempFStringTag = FString::FromInt(TempTag);
				FName TempFNameTag = FName(*TempFStringTag);
				if (SMComp->ComponentHasTag(TempFNameTag))
				{
					int32 TempIntTag = FCString::Atoi(*TempFStringTag);
					FCWDungeonDecorateDataStruct* TempDungeonDecorateData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateDataStruct>(TEXT("CWDungeonDecorateDataTable"), TempTag);
					if (TempDungeonDecorateData != nullptr)
					{
						UCWDungeonDecorateComponent* TempDungeonDecorateComponent = TempActor->FindComponentByClass<UCWDungeonDecorateComponent>();
						if (TempDungeonDecorateComponent == nullptr)
						{
							TempDungeonDecorateComponent = NewObject<UCWDungeonDecorateComponent>(TempActor, UCWDungeonDecorateComponent::StaticClass());
							TempActor->AddOwnedComponent(TempDungeonDecorateComponent);
							TempDungeonDecorateComponent->RegisterComponent();
							USceneComponent* TempSceneComponent = (USceneComponent*)(TempActor->GetComponentByClass(USceneComponent::StaticClass()));
							TempDungeonDecorateComponent->AttachToComponent(TempSceneComponent, FAttachmentTransformRules::KeepRelativeTransform);
						}

						FTimerDelegate DungeonDecorateFallCallback;
						DungeonDecorateFallCallback.BindLambda([TempDungeonDecorateComponent]()
						{
							TempDungeonDecorateComponent->DoFallInServer();
						});


						FTimerHandle DungeonFallTimer;
						GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonDecorateFallCallback, 1.0f, false, TempDungeonDecorateData->FallTime);
					}
					else
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonDecorateFall fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
					}
				}
			}

		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::GenerateDungeonDecorateFallInClient()
{
	//if (IsInServer())
	//	return true;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonDecorateTagMinMax = FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(TempDungeonData->ArrayDungeonDecorateTagMinMax);
	if (TempArrayDungeonDecorateTagMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonDecorateFallInClient, TempArrayDungeonDecorateTagMinMax.size() != 2, TempArrayDungeonDecorateTagMinMax.size():%d."), TempArrayDungeonDecorateTagMinMax.size());
		return false;
	}
	int32 TempMin = TempArrayDungeonDecorateTagMinMax[0];
	int32 TempMax = TempArrayDungeonDecorateTagMinMax[1];
	if (TempMin > TempMax)
		TempMin = TempMax;
	for (TActorIterator<AStaticMeshActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AStaticMeshActor* TempActor = *Iter;
		UStaticMeshComponent* SMComp = TempActor ? TempActor->GetStaticMeshComponent() : nullptr;
		if (SMComp != nullptr && SMComp->ComponentTags.Num() > 0)
		{
			for (int32 TempTag = TempMin; TempTag <= TempMax; ++TempTag)
			{
				FString TempFStringTag = FString::FromInt(TempTag);
				FName TempFNameTag = FName(*TempFStringTag);
				if (SMComp->ComponentHasTag(TempFNameTag))
				{
					int32 TempIntTag = FCString::Atoi(*TempFStringTag);
					FCWDungeonDecorateDataStruct* TempDungeonDecorateData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateDataStruct>(TEXT("CWDungeonDecorateDataTable"), TempTag);
					if (TempDungeonDecorateData != nullptr)
					{
						UCWDungeonDecorateComponent* TempDungeonDecorateComponent = TempActor->FindComponentByClass<UCWDungeonDecorateComponent>();
						if (TempDungeonDecorateComponent == nullptr)
						{
							TempDungeonDecorateComponent = NewObject<UCWDungeonDecorateComponent>(TempActor, UCWDungeonDecorateComponent::StaticClass());
							TempActor->AddOwnedComponent(TempDungeonDecorateComponent);
							TempDungeonDecorateComponent->RegisterComponent();
							USceneComponent* TempSceneComponent = (USceneComponent*)(TempActor->GetComponentByClass(USceneComponent::StaticClass()));
							TempDungeonDecorateComponent->AttachToComponent(TempSceneComponent, FAttachmentTransformRules::KeepRelativeTransform);
						}

						FTimerDelegate DungeonDecorateFallCallback;
						DungeonDecorateFallCallback.BindLambda([TempDungeonDecorateComponent]()
						{
							TempDungeonDecorateComponent->DoFallInClient();
						});


						FTimerHandle DungeonFallTimer;
						GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonDecorateFallCallback, 1.0f, false, TempDungeonDecorateData->FallTime);
					}
					else
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GenerateDungeonDecorateFall fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
					}
				}
			}

		}
	}

	return true;
}

void ACWRandomDungeonGenerator::ResetDungeonDecorateBeforeRiseInClient()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonDecorateTagMinMax = FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(TempDungeonData->ArrayDungeonDecorateTagMinMax);
	if (TempArrayDungeonDecorateTagMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::ResetDungeonDecorateBeforeRiseInClient, TempArrayDungeonDecorateTagMinMax.size() != 2, TempArrayDungeonDecorateTagMinMax.size():%d."), TempArrayDungeonDecorateTagMinMax.size());
		return;
	}
	int32 TempMin = TempArrayDungeonDecorateTagMinMax[0];
	int32 TempMax = TempArrayDungeonDecorateTagMinMax[1];
	if (TempMin > TempMax)
		TempMin = TempMax;
	for (TActorIterator<AStaticMeshActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AStaticMeshActor* TempActor = *Iter;
		UStaticMeshComponent* SMComp = TempActor ? TempActor->GetStaticMeshComponent() : nullptr;
		if (SMComp != nullptr && SMComp->ComponentTags.Num() > 0)
		{
			for (int32 TempTag = TempMin; TempTag <= TempMax; ++TempTag)
			{
				FString TempFStringTag = FString::FromInt(TempTag);
				FName TempFNameTag = FName(*TempFStringTag);
				if (SMComp->ComponentHasTag(TempFNameTag))
				{
					int32 TempIntTag = FCString::Atoi(*TempFStringTag);
					FCWDungeonDecorateDataStruct* TempDungeonDecorateData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateDataStruct>(TEXT("CWDungeonDecorateDataTable"), TempTag);
					if (TempDungeonDecorateData != nullptr)
					{
						UCWDungeonDecorateComponent* TempDungeonDecorateComponent = TempActor->FindComponentByClass<UCWDungeonDecorateComponent>();
						if (TempDungeonDecorateComponent == nullptr)
						{
							TempDungeonDecorateComponent = NewObject<UCWDungeonDecorateComponent>(TempActor, UCWDungeonDecorateComponent::StaticClass());
							TempActor->AddOwnedComponent(TempDungeonDecorateComponent);
							TempDungeonDecorateComponent->RegisterComponent();
							USceneComponent* TempSceneComponent = (USceneComponent*)(TempActor->GetComponentByClass(USceneComponent::StaticClass()));
							TempDungeonDecorateComponent->AttachToComponent(TempSceneComponent, FAttachmentTransformRules::KeepRelativeTransform);
						}
						TempDungeonDecorateComponent->ResetBeforeRiseInClient();
					}
					else
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::ResetDungeonDecorateBeforeRiseInClient fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
					}
				}
			}
		}
	}
}

bool ACWRandomDungeonGenerator::DungeonDecorateDoRiseInClient()
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonDecorateTagMinMax = FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(TempDungeonData->ArrayDungeonDecorateTagMinMax);
	if (TempArrayDungeonDecorateTagMinMax.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::DungeonDecorateDoRiseInClient, TempArrayDungeonDecorateTagMinMax.size() != 2, TempArrayDungeonDecorateTagMinMax.size():%d."), TempArrayDungeonDecorateTagMinMax.size());
		return false;
	}
	int32 TempMin = TempArrayDungeonDecorateTagMinMax[0];
	int32 TempMax = TempArrayDungeonDecorateTagMinMax[1];
	if (TempMin > TempMax)
		TempMin = TempMax;
	for (TActorIterator<AStaticMeshActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AStaticMeshActor* TempActor = *Iter;
		UStaticMeshComponent* SMComp = TempActor ? TempActor->GetStaticMeshComponent() : nullptr;
		if (SMComp != nullptr && SMComp->ComponentTags.Num() > 0)
		{
			for (int32 TempTag = TempMin; TempTag <= TempMax; ++TempTag)
			{
				FString TempFStringTag = FString::FromInt(TempTag);
				FName TempFNameTag = FName(*TempFStringTag);
				if (SMComp->ComponentHasTag(TempFNameTag))
				{
					int32 TempIntTag = FCString::Atoi(*TempFStringTag);
					FCWDungeonDecorateDataStruct* TempDungeonDecorateData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateDataStruct>(TEXT("CWDungeonDecorateDataTable"), TempTag);
					if (TempDungeonDecorateData != nullptr)
					{
						UCWDungeonDecorateComponent* TempDungeonDecorateComponent = TempActor->FindComponentByClass<UCWDungeonDecorateComponent>();
						if (TempDungeonDecorateComponent == nullptr)
						{
							TempDungeonDecorateComponent = NewObject<UCWDungeonDecorateComponent>(TempActor, UCWDungeonDecorateComponent::StaticClass());
							TempActor->AddOwnedComponent(TempDungeonDecorateComponent);
							TempDungeonDecorateComponent->RegisterComponent();
							USceneComponent* TempSceneComponent = (USceneComponent*)(TempActor->GetComponentByClass(USceneComponent::StaticClass()));
							TempDungeonDecorateComponent->AttachToComponent(TempSceneComponent, FAttachmentTransformRules::KeepRelativeTransform);
						}

						FTimerDelegate DungeonDecorateFallCallback;
						DungeonDecorateFallCallback.BindLambda([TempDungeonDecorateComponent]()
						{
							TempDungeonDecorateComponent->DoRiseInClient();
						});

						FTimerHandle DungeonFallTimer;
						GetWorldTimerManager().SetTimer(DungeonFallTimer, DungeonDecorateFallCallback, 1.0f, false, TempDungeonDecorateData->FallTime);
					}
					else
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::DungeonDecorateDoRiseInClient fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
					}
				}
			}
		}
	}

	return true;
}

void ACWRandomDungeonGenerator::ResetPawnBeforeDoSpawnActionInClient()
{
	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		TArray<TWeakObjectPtr<ACWPawn>> TempArrayPawns = TempMap->GetArrayPawns();
		for (TArray<TWeakObjectPtr<ACWPawn>>::TIterator iter = TempArrayPawns.CreateIterator(); iter; ++iter)
		{
			TWeakObjectPtr<ACWPawn> TempPawn = *iter;
			if (TempPawn.IsValid() && TempPawn->GetPawnType() == ECWPawnType::Character)
			{
				FVector TempLocation = TempPawn->GetActorLocation();
				TempLocation.Z = 10000.0f;
				TempPawn->SetActorLocation(TempLocation);
			}
		}
	}
}

void ACWRandomDungeonGenerator::PawnDoSpawnActionInClient()
{
	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		TArray<TWeakObjectPtr<ACWPawn>> TempArrayPawns = TempMap->GetArrayPawns();
		for (TArray<TWeakObjectPtr<ACWPawn>>::TIterator iter = TempArrayPawns.CreateIterator(); iter; ++iter)
		{
			TWeakObjectPtr<ACWPawn> TempPawn = *iter;
			if (TempPawn.IsValid() && TempPawn->GetPawnType() == ECWPawnType::Character)
			{
				FVector TempOldLocation = TempPawn->GetActorLocation();
				ACWDungeonTile* TempDungeonTile = GetDungeonTile(TempPawn->GetTile());
				float TempOffsetZ = 0.0f;
				if (TempDungeonTile != nullptr)
				{
					TempOffsetZ = TempDungeonTile->GetOffsetZ();
				}
				TempOldLocation.Z = 0.0f + TempOffsetZ;
				TempPawn->SetActorLocation(TempOldLocation);
				TempPawn->PlayAnimSequence(ECWPawnAnim::SpawnAction01, 0.2f, 0.2f, 1.0f, 1);
				TempPawn->DungeonToReady();
			}
		}

		CWG_LOG(">> %s::PawnDoSpawnActionInClient, ArrayPawns[%d].", *GetName(), TempArrayPawns.Num());
	}

	/** 初始化准备状态数据 */
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->InitReadyStateData();
	}
}

void ACWRandomDungeonGenerator::RefreshAllLocationInServer()
{
	for (TActorIterator<ACWDungeonItem> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWDungeonItem* TempDungeonItem = *Iter;
		if (TempDungeonItem != nullptr)
		{
			FVector TempOldLocation = TempDungeonItem->GetActorLocation();
			ACWDungeonTile* TempDungeonTile = GetDungeonTile(TempDungeonItem->GetTile());
			float TempOffsetZ = 0.0f;
			if (TempDungeonTile != nullptr)
			{
				TempOffsetZ = TempDungeonTile->GetOffsetZ();
			}
			TempOldLocation.Z = 0.0f + TempOffsetZ;
			TempDungeonItem->SetActorLocation(TempOldLocation);
		}
	}

	for (TActorIterator<ACWDungeonTile> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWDungeonTile* TempDungeonTile = *Iter;
		if (TempDungeonTile != nullptr)
		{
			FVector TempOldLocation = TempDungeonTile->GetActorLocation();
			TempOldLocation.Z = TempDungeonTile->GetOffsetZ();
			TempDungeonTile->SetActorLocation(TempOldLocation);
		}
	}

	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr)
		{
			FVector TempOldLocation = TempPawn->GetActorLocation();
			ACWDungeonTile* TempDungeonTile = GetDungeonTile(TempPawn->GetTile());
			float TempOffsetZ = 0.0f;
			if (TempDungeonTile != nullptr)
			{
				TempOffsetZ = TempDungeonTile->GetOffsetZ();
			}
			TempOldLocation.Z = 0.0f + TempOffsetZ;
			TempPawn->SetActorLocation(TempOldLocation);
		}
	}

	NetMulticastRPCRefreshAllLocation();
}

void ACWRandomDungeonGenerator::RefreshAllLocationInClient()
{
	// 重置地形地块位置
	for (TActorIterator<ACWDungeonTile> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWDungeonTile* TempDungeonTile = *Iter;
		if (TempDungeonTile != nullptr)
		{
			FVector TempOldLocation = TempDungeonTile->GetActorLocation();
			TempOldLocation.Z = TempDungeonTile->GetOffsetZ();
			TempDungeonTile->SetActorLocation(TempOldLocation);
			TempDungeonTile->DoRiseEndInClient();
		}
	}

	/** 场景对象额外偏移Z */
	float ObjectOffsetZ = GetObjectExtraOffsetZ();
	
	// 重置地形物件位置
	for (TActorIterator<ACWDungeonItem> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWDungeonItem* TempDungeonItem = *Iter;
		if (TempDungeonItem != nullptr)
		{
			FVector TempOldLocation = TempDungeonItem->GetActorLocation();
			float NewOffsetZ = GetLocationZ(TempDungeonItem->GetTile());
			TempOldLocation.Z = 0.0f + NewOffsetZ;
			TempDungeonItem->SetActorLocation(TempOldLocation);
		}
	}

	// 重置地形棋子位置
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr)
		{
			FVector TempOldLocation = TempPawn->GetActorLocation();
			float NewOffsetZ = GetLocationZ(TempPawn->GetTile());
			TempOldLocation.Z = 0.f + NewOffsetZ;
			TempPawn->SetActorLocation(TempOldLocation);
			//CWG_WARNING(">> RefreshAllLocationInClient, Pawn -> Tile[%d] NewOffsetZ[%f].", TempPawn->GetTile(), NewOffsetZ);
		}
	}
	CWG_LOG(">> %s::RefreshAllLocationInClient, End~", *GetName());

	// 重置地形指示器位置
	OnRep_ArrayTileOffsetZ();
}

void ACWRandomDungeonGenerator::NetMulticastRPCRefreshAllLocation_Implementation()
{
	if (IsInServer())
	{
	}
	else
	{
		RefreshAllLocationInClient();
	}
}

void ACWRandomDungeonGenerator::NetMulticastRPCDungeonDecorateFall_Implementation()
{
	if (IsInServer())
	{
		//GenerateDungeonDecorateFallInServer();
	}
	else
	{
		//GenerateDungeonDecorateFallInClient();
	}
}

bool ACWRandomDungeonGenerator::DungeonFallWarningInClient(int32 ParamCurDungeonTileFallIndex)
{
	return DungeonFallWarningInClientNew(ParamCurDungeonTileFallIndex);

	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	int32 TempCurDungeonTileFallIndex = ParamCurDungeonTileFallIndex;
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	int index = 0;
	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = TempDungeonData->DungeonWidth - 1 - TempCurDungeonTileFallIndex; x >= TempCurDungeonTileFallIndex; --x)
		{
			if (y == TempCurDungeonTileFallIndex)
			{
				int tx = x + offsetX;
				int ty = y + offsetY;

				int TempTile = ACWMap::xy2tile(tx, ty);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->FallWarningInClient();
				}
			}
		}
	}

	for (int y = TempCurDungeonTileFallIndex; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempCurDungeonTileFallIndex)
			{
				int tx = x + offsetX;
				int ty = y + offsetY;

				int TempTile = ACWMap::xy2tile(tx, ty);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->FallWarningInClient();
				}
			}
		}
	}

	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = TempCurDungeonTileFallIndex; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (y == TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex - 1)
			{
				int tx = x + offsetX;
				int ty = y + offsetY;

				int TempTile = ACWMap::xy2tile(tx, ty);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->FallWarningInClient();
				}
			}
		}
	}

	for (int y = TempDungeonData->DungeonHeight - 1 - TempCurDungeonTileFallIndex; y >= TempCurDungeonTileFallIndex; --y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex - 1)
			{
				int tx = x + offsetX;
				int ty = y + offsetY;

				int TempTile = ACWMap::xy2tile(tx, ty);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->FallWarningInClient();
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::DungeonFallWarningInClientNew(int32 ParamCurDungeonTileFallIndex)
{
	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	int32 TempCurDungeonTileFallIndex = ParamCurDungeonTileFallIndex;
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	int32 dungeonL = TempDungeonData->DungeonWidthExtension;
	int32 dungeonW = TempDungeonData->DungeonHeightExtension;
	int safeAreaStartX = TempGameData->SafeAreaMinX;
	int safeAreaStartY = TempGameData->SafeAreaMinY;
	int safeAreaEndX = TempGameData->SafeAreaMaxX;
	int safeAreaEndY = TempGameData->SafeAreaMaxY;
	int curFallCount = TempGameData->EachRoundFallNum;
	ECWDungeonArea area = (ECWDungeonArea)(ParamCurDungeonTileFallIndex % (int)ECWDungeonArea::Max);
	int tmpTotalCount = 0;
	int levelX = 0;
	int levelY = 0;
	int maxLevelX = 0;
	int maxLevelY = 0;

	CWG_LOG("DungeonFallWarningInClientNew while begin");
	while (tmpTotalCount < curFallCount) {
		tmpTotalCount = 0;
		if (area == ECWDungeonArea::RD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = 0; x <= offsetY + levelX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetY; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - safeAreaStartX - offsetX - 1;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::RT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = 0; x <= levelX + offsetX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = dungeonW - safeAreaStartY - offsetY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetX; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					DoWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - offsetX - safeAreaStartX - 1;
			maxLevelY = dungeonW - offsetY - safeAreaStartY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else {
			break;
		}
		if (levelX >= maxLevelX && levelY >= maxLevelY) break;
	}
	CWG_LOG("DungeonFallWarningInClientNew while end");

	return true;
}

void ACWRandomDungeonGenerator::NetMulticastRPCHideFallWarning_Implementation(int32 ParamCurDungeonTileFallIndex)
{
	if (IsInServer())
		return;

	// 地块预警掉落结束
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnLevelDropEarlyWarnClient.Broadcast(false, ParamCurDungeonTileFallIndex);
	}

	HideDungeonFallWarningInClient(ParamCurDungeonTileFallIndex);
}

void ACWRandomDungeonGenerator::HideDungeonFallWarningInClient(int32 ParamCurDungeonTileFallIndex)
{
	HideDungeonFallWarningInClientNew(ParamCurDungeonTileFallIndex);
	return;

	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	int32 TempCurDungeonTileFallIndex = ParamCurDungeonTileFallIndex;
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	int index = 0;
	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = TempDungeonData->DungeonWidth - 1 - TempCurDungeonTileFallIndex; x >= 0; --x)
		{
			if (y == TempCurDungeonTileFallIndex)
			{
				int TempTile = ACWMap::xy2tile(x, y);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->HideFallWarningInClient();
				}
			}
		}
	}

	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempCurDungeonTileFallIndex)
			{
				int TempTile = ACWMap::xy2tile(x, y);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->HideFallWarningInClient();
				}
			}
		}
	}

	for (int y = 0; y < TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex; ++y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (y == TempDungeonData->DungeonHeight - TempCurDungeonTileFallIndex - 1)
			{
				int TempTile = ACWMap::xy2tile(x, y);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->HideFallWarningInClient();
				}
			}
		}
	}

	for (int y = TempDungeonData->DungeonHeight - 1 - TempCurDungeonTileFallIndex; y >= 0; --y)
	{
		for (int x = 0; x < TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex; ++x)
		{
			if (x == TempDungeonData->DungeonWidth - TempCurDungeonTileFallIndex - 1)
			{
				int TempTile = ACWMap::xy2tile(x, y);
				ACWMapTile* TempMapTile = TempMap->GetTile(TempTile);
				if (TempMapTile != nullptr)
				{
					TempMapTile->HideFallWarningInClient();
				}
			}
		}
	}
}

void ACWRandomDungeonGenerator::HideDungeonFallWarningInClientNew(int32 ParamCurDungeonTileFallIndex)
{
	ACWMap* TempMap = GetMap();
	check(TempMap);

	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	int32 TempCurDungeonTileFallIndex = ParamCurDungeonTileFallIndex;
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	check(TempDungeonData);

	int32 dungeonL = TempDungeonData->DungeonWidth;
	int32 dungeonW = TempDungeonData->DungeonHeight;
	int safeAreaStartX = TempGameData->SafeAreaMinX;
	int safeAreaStartY = TempGameData->SafeAreaMinY;
	int safeAreaEndX = TempGameData->SafeAreaMaxX;
	int safeAreaEndY = TempGameData->SafeAreaMaxY;
	int curFallCount = TempGameData->EachRoundFallNum;
	ECWDungeonArea area = (ECWDungeonArea)(ParamCurDungeonTileFallIndex % (int)ECWDungeonArea::Max);
	int tmpTotalCount = 0;
	int levelX = 0;
	int levelY = 0;
	int maxLevelX = 0;
	int maxLevelY = 0;
	CWG_LOG("HideDungeonFallWarningInClientNew while begin");
	while (tmpTotalCount < curFallCount) {
		tmpTotalCount = 0;
		if (area == ECWDungeonArea::RD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = 0; x <= offsetY + levelX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					HideWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LD) {
			for (int y = 0; y <= offsetX + levelY; ++y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetY; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					HideWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - safeAreaStartX - offsetX - 1;
			maxLevelY = safeAreaEndY + offsetY;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::RT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = 0; x <= levelX + offsetX; ++x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					HideWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = safeAreaEndX + offsetX;
			maxLevelY = dungeonW - safeAreaStartY - offsetY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else if (area == ECWDungeonArea::LT) {
			for (int y = dungeonW - 1; y >= dungeonW - levelY - offsetY; --y) {
				for (int x = dungeonL - 1; x >= dungeonL - levelX - offsetX; --x) {
					if (x >= safeAreaStartX + offsetX && x <= safeAreaEndX + offsetX && y >= safeAreaStartY + offsetY && y <= safeAreaEndY + offsetY)
						continue;
					HideWarning(TempMap, x, y, tmpTotalCount, curFallCount);
					if (tmpTotalCount >= curFallCount) break;
				}
			}
			maxLevelX = dungeonL - offsetX - safeAreaStartX - 1;
			maxLevelY = dungeonW - offsetY - safeAreaStartY - 1;
			if (levelX < maxLevelX) levelX++;
			if (levelY < maxLevelY) levelY++;
		}
		else {
			break;
		}
		if (levelX >= maxLevelX && levelY >= maxLevelY) break;
	}
	CWG_LOG("HideDungeonFallWarningInClientNew while end");
}

bool ACWRandomDungeonGenerator::IsThereRepetitionForTopography(int32 x, int32 y)
{
	bool bIsTrue = ArrayRandomDungeonRegionTopography.ContainsByPredicate(
		[&x, &y](const FCWRandomDungeonRegionTopography& TempRegionTopography) -> bool
		{
			return TempRegionTopography.OriginX == x && TempRegionTopography.OriginY == y;
		}
	);

	return bIsTrue;
}

bool ACWRandomDungeonGenerator::IsThereRepetitionForRegion(int32 x, int32 y)
{
	bool bIsTrue = ArrayRandomDungeonRegion.ContainsByPredicate(
		[&x, &y](const FCWRandomDungeonRegionData& TempRegionData) -> bool
	{
		return TempRegionData.OriginX == x && TempRegionData.OriginY == y;
	}
	);

	return bIsTrue;
}

bool ACWRandomDungeonGenerator::IsThereFitForItemByQEuler(int32 ParamTile, int32 ParamDungeonItemId, float ParamQEuler)
{
	FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemData(ParamDungeonItemId);
	if (TempDungeonItemData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::IsThereFitForItemByQEuler, TempDungeonItemData == nullptr, ParamDungeonItemId:%d."), ParamDungeonItemId);
		return false;
	}

	std::vector<int32> TempArrayObstacle = FCWDungeonItemDataUtils::GetArrayObstacleFromString(TempDungeonItemData->Obstacle);
	if (TempArrayObstacle.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItemByQEuler Fail. TempArrayObstacle.size() != 2, TempArrayObstacle.size():%d."), TempArrayObstacle.size());
		return false;
	}

	int32 M = TempArrayObstacle[0];
	int32 N = TempArrayObstacle[1];
	if (M <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItemByQEuler Fail. M <= 0, M:%d."), M);
		return false;
	}

	if (N <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItemByQEuler Fail. N <= 0, N:%d."), N);
		return false;
	}

	int x, y;
	this->tile2xy(ParamTile, x, y);

	if (FMath::IsNearlyEqual(ParamQEuler, 0.0f))
	{
		//0
		int32 TempM = M;
		int32 TempN = N;
		int32 TempTile = ParamTile;
		if (IsMNValid(TempTile, TempM, TempN) &&
			IsMNSameZ(TempTile, TempM, TempN) &&
			(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
			!IsMNObstacle(TempTile, TempM, TempN))
		{
			return true;
		}
	}

	if (FMath::IsNearlyEqual(ParamQEuler, 90.0f))
	{
		//90
		int32 TempM = N;
		int32 TempN = M;
		int32 TempTile = ParamTile;
		if (IsMNValid(TempTile, TempM, TempN) &&
			IsMNSameZ(TempTile, TempM, TempN) &&
			(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
			!IsMNObstacle(TempTile, TempM, TempN))
		{
			return true;
		}
	}

	if (FMath::IsNearlyEqual(ParamQEuler, 180.0f))
	{
		//180
		int32 TempM = M;
		int32 TempN = N;
		int TempX = x - TempM + 1;
		if (TempX >= 0)
		{
			int32 TempTile = this->xy2tile(TempX, y);
			if (IsMNValid(TempTile, TempM, TempN) &&
				IsMNSameZ(TempTile, TempM, TempN) &&
				(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
				!IsMNObstacle(TempTile, TempM, TempN))
			{
				return true;
			}
		}
	}

	if (FMath::IsNearlyEqual(ParamQEuler, 270.0f))
	{
		//270
		int32 TempM = N;
		int32 TempN = M;
		int TempX = x - TempM + 1;
		int TempY = y - TempN + 1;
		if (TempX >= 0 && TempY >= 0)
		{
			int32 TempTile = this->xy2tile(TempX, TempY);
			if (IsMNValid(TempTile, TempM, TempN) &&
				IsMNSameZ(TempTile, TempM, TempN) &&
				(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
				!IsMNObstacle(TempTile, TempM, TempN))
			{
				return true;
			}
		}
	}

	return false;
}

bool ACWRandomDungeonGenerator::IsThereFitForItem(int32 ParamTile, int32 ParamDungeonItemId, float& TempOutQEuler)
{
	FCWDungeonItemDataStruct* TempDungeonItemData = GetDungeonItemData(ParamDungeonItemId);
	if (TempDungeonItemData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::IsThereFitForItem, TempDungeonItemData == nullptr, ParamDungeonItemId:%d."), ParamDungeonItemId);
		return false;
	}

	std::vector<int32> TempArrayObstacle = FCWDungeonItemDataUtils::GetArrayObstacleFromString(TempDungeonItemData->Obstacle);
	if (TempArrayObstacle.size() != 2)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItem Fail. TempArrayObstacle.size() != 2, TempArrayObstacle.size():%d."), TempArrayObstacle.size());
		return false;
	}

	int32 M = TempArrayObstacle[0];
	int32 N = TempArrayObstacle[1];
	if (M <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItem Fail. M <= 0, M:%d."), M);
		return false;
	}

	if (N <= 0)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWDungeonItem::IsThereFitForItem Fail. N <= 0, N:%d."), N);
		return false;
	}

	int x, y;
	this->tile2xy(ParamTile, x, y);

	//0
	int32 TempM = M;
	int32 TempN = N;
	int32 TempTile = ParamTile;
	if (IsMNValid(TempTile, TempM, TempN) &&
		IsMNSameZ(TempTile, TempM, TempN) &&
		(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
		!IsMNObstacle(TempTile, TempM, TempN))
	{
		TempOutQEuler = 0.0f;
		return true;
	}
	
	//90
	TempM = N;
	TempN = M;
	TempTile = ParamTile;
	if (IsMNValid(TempTile, TempM, TempN) &&
		IsMNSameZ(TempTile, TempM, TempN) &&
		(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
		!IsMNObstacle(TempTile, TempM, TempN))
	{
		TempOutQEuler = 90.0f;
		return true;
	}

	//180
	TempM = M;
	TempN = N;
	int TempX = x - TempM + 1;
	if (TempX >= 0)
	{
		int32 TempTile = this->xy2tile(TempX, y);
		if (IsMNValid(TempTile, TempM, TempN) &&
			IsMNSameZ(TempTile, TempM, TempN) &&
			(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
			!IsMNObstacle(TempTile, TempM, TempN))
		{
			TempOutQEuler = 180.0f;
			return true;
		}
	}

	//270
	TempM = N;
	TempN = M;
	TempX = x - TempM + 1;
	int TempY = y - TempN + 1;
	if (TempX >= 0 && TempY >= 0)
	{
		int32 TempTile = this->xy2tile(TempX, TempY);
		if (IsMNValid(TempTile, TempM, TempN) &&
			IsMNSameZ(TempTile, TempM, TempN) &&
			(((TempDungeonItemData->CanInteractive > 0 || TempDungeonItemData->CanAttack > 0) && !IsMNPawnStart(TempTile, TempM, TempN)) || (TempDungeonItemData->CanInteractive == 0 && TempDungeonItemData->CanAttack == 0)) &&
			!IsMNObstacle(TempTile, TempM, TempN))
		{
			TempOutQEuler = 270.0f;
			return true;
		}
	}

	return false;
}

bool ACWRandomDungeonGenerator::IsMNValid(int32 ParamTile, int32 ParamM, int32 ParamN)
{
	int32 x = 0;
	int32 y = 0;
	this->tile2xy(ParamTile, x, y);

	for (int TempY = y; TempY < y + ParamN; ++TempY)
	{
		for (int TempX = x; TempX < x + ParamM; ++TempX)
		{
			int32 TempTile = this->xy2tile(TempX, TempY);
			if (!ArrayDungeonGrid.IsValidIndex(TempTile))
				return false;
			
			if (ArrayDungeonGrid[TempTile] == 0)
				return false;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsMNSameZ(int32 ParamTile, int32 ParamM, int32 ParamN)
{
	int32 x = 0;
	int32 y = 0;
	this->tile2xy(ParamTile, x, y);

	int32 TempZ = 0;
	int32 index = 0;
	for (int TempY = y; TempY < y + ParamN; ++TempY)
	{
		for (int TempX = x; TempX < x + ParamM; ++TempX)
		{
			int32 TempTile = this->xy2tile(TempX, TempY);
			if (!ArrayDungeonGrid_Z.IsValidIndex(TempTile))
				return false;

			if (ArrayDungeonGrid_Z[TempTile] == TempZ || index == 0)
			{
				TempZ = ArrayDungeonGrid_Z[TempTile];
				index++;
			}
			else
			{
				return false;
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsMNObstacle(int32 ParamTile, int32 ParamM, int32 ParamN)
{
	int32 x = 0;
	int32 y = 0;
	this->tile2xy(ParamTile, x, y);

	for (int TempY = y; TempY < y + ParamN; ++TempY)
	{
		for (int TempX = x; TempX < x + ParamM; ++TempX)
		{
			int32 TempTile = this->xy2tile(TempX, TempY);
			if (IsArrayDungeonItemObstacle(TempTile))
			{
				return true;
			}
		}
	}

	return false;
}

bool ACWRandomDungeonGenerator::IsMNPawnStart(int32 ParamTile, int32 ParamM, int32 ParamN)
{
	int32 x = 0;
	int32 y = 0;
	this->tile2xy(ParamTile, x, y);

	int32 TempZ = 0;
	int32 index = 0;
	for (int TempY = y; TempY < y + ParamN; ++TempY)
	{
		for (int TempX = x; TempX < x + ParamM; ++TempX)
		{
			int32 TempTile = this->xy2tile(TempX, TempY);
			if (IsTherePawnStart(TempTile))
			{
				return true;
			}
		}
	}

	return false;
}

bool ACWRandomDungeonGenerator::IsArrayDungeonItemObstacle(int32 ParamTile)
{
	if (!ArrayDungeonItemObstacle.IsValidIndex(ParamTile))
	{
		return true;
	}

	if (ArrayDungeonItemObstacle[ParamTile] > 0)
	{
		return true;
	}

	return false;
}

void ACWRandomDungeonGenerator::RandomGridIndexForHighLand(int32& x, int32& y, int32 TempSizeX, int32 TempSizeY, int32 TempHasWall)
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();

	int32 totalCount = TempSizeX * TempSizeY;

	//x = rand() % DungeonData->DungeonWidth - 1;
	//y = rand() % DungeonData->DungeonHeight - 1;

	/*int32 realBeginX = 0;
	int32 realEndX = DungeonData->DungeonWidth - TempSizeX > realBeginX ? DungeonData->DungeonWidth - TempSizeX : realBeginX;
	int32 realBeginY = 0;
	int32 realEndY = DungeonData->DungeonHeight - TempSizeY > realBeginY ? DungeonData->DungeonHeight - TempSizeY : realBeginY;*/


	if (TempHasWall)
	{
		int x1 = (TempDungeonData->DungeonWidth - TempSizeX) / 2;
		if (x1 > 3)
			x1 = 3;

		int32 realBeginX = x1;
		int32 realEndX = TempDungeonData->DungeonWidth - TempSizeX - x1;

		int y1 = (TempDungeonData->DungeonHeight - TempSizeY) / 2;
		if (y1 > 3)
			y1 = 3;

		int32 realBeginY = y1;
		int32 realEndY = TempDungeonData->DungeonHeight - TempSizeY - y1;
		x = RandomInt(realBeginX, realEndX);
		y = RandomInt(realBeginY, realEndY);
		if (totalCount >= TempDungeonData->HighLandGridCountMin)
		{
			y = TempDungeonData->DungeonHeight - TempSizeY;
		}

		x += offsetX;
		y += offsetY;
	}
	else
	{
		int32 realBeginX = 0;
		int32 realEndX = TempDungeonData->DungeonWidth - TempSizeX;
		int32 realBeginY = 0;
		int32 realEndY = TempDungeonData->DungeonHeight - TempSizeY;
		x = RandomInt(realBeginX, realEndX);
		y = RandomInt(realBeginY, realEndY);
		if (totalCount >= TempDungeonData->HighLandGridCountMin)
		{
			y = TempDungeonData->DungeonHeight - TempSizeY;
		}

		x += offsetX;
		y += offsetY;
	}
}

void ACWRandomDungeonGenerator::RandomGridIndexForLowLand(int32& x, int32& y, int32 TempSizeX, int32 TempSizeY, int32 TempHasWall)
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();

	int32 totalCount = TempSizeX * TempSizeY;

	//x = rand() % DungeonData->DungeonWidth - 1;
	//y = rand() % DungeonData->DungeonHeight - 1;

	/*int32 realBeginX = 0;
	int32 realEndX = DungeonData->DungeonWidth - TempSizeX > realBeginX ? DungeonData->DungeonWidth - TempSizeX : realBeginX;
	int32 realBeginY = 0;
	int32 realEndY = DungeonData->DungeonHeight - TempSizeY > realBeginY ? DungeonData->DungeonHeight - TempSizeY : realBeginY;*/


	if (TempHasWall)
	{
		int x1 = (TempDungeonData->DungeonWidth - TempSizeX) / 2;
		if (x1 > 3)
			x1 = 3;

		int32 realBeginX = x1;
		int32 realEndX = TempDungeonData->DungeonWidth - TempSizeX - x1;

		int y1 = (TempDungeonData->DungeonHeight - TempSizeY) / 2;
		if (y1 > 3)
			y1 = 3;

		int32 realBeginY = y1;
		int32 realEndY = TempDungeonData->DungeonHeight - TempSizeY - y1;

		x = RandomInt(realBeginX, realEndX);
		y = RandomInt(realBeginY, realEndY);
		if (totalCount >= TempDungeonData->HighLandGridCountMin)
		{
			y = 0;
		}

		x += offsetX;
		y += offsetY;
	}
	else
	{
		int32 realBeginX = 0;
		int32 realEndX = TempDungeonData->DungeonWidth - TempSizeX;
		int32 realBeginY = 0;
		int32 realEndY = TempDungeonData->DungeonHeight - TempSizeY;
		x = RandomInt(realBeginX, realEndX);
		y = RandomInt(realBeginY, realEndY);
		if (totalCount >= TempDungeonData->HighLandGridCountMin)
		{
			y = 0;
		}

		x += offsetX;
		y += offsetY;
	}
}

void ACWRandomDungeonGenerator::RandomDungeonItemTile(int32& x, int32& y)
{
	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();

	int32 realBeginX = 0;
	int32 realEndX = TempDungeonData->DungeonWidthExtension - 1;
	int32 realBeginY = 0;
	int32 realEndY = TempDungeonData->DungeonHeightExtension - 1;
	x = RandomInt(realBeginX, realEndX);
	y = RandomInt(realBeginY, realEndY);

	//x += offsetX;
	//y += offsetY;
}

float ACWRandomDungeonGenerator::RandomDungeonItemEuler()
{
	std::vector<float> stdVec;
	stdVec.push_back(0.0f);
	stdVec.push_back(90.0f);
	stdVec.push_back(180.0f);
	stdVec.push_back(270.0f);
	int32 index = rand() % stdVec.size();
	return stdVec[index];
}


bool ACWRandomDungeonGenerator::IsTherePawnStart(int32 ParamTile)
{
	ACWMap* TempMap = GetMap();
	check(TempMap);

	uint8 TempTileAttribute = TempMap->getMapTileAttribute(ParamTile);
	if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
	{
		return true;
	}

	int x = 0;
	int y = 0;
	this->tile2xy(ParamTile, x, y);
	

	int32 LeftX = x - 1;
	int32 LeftY = y - 0;
	if (LeftX >= 0 && LeftX < DungeonWidth &&
		LeftY >= 0 && LeftY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(LeftX, LeftY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 LeftDownX = x - 1;
	int32 LeftDownY = y - 1;
	if (LeftDownX >= 0 && LeftDownX < DungeonWidth &&
		LeftDownY >= 0 && LeftDownY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(LeftDownX, LeftDownY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 LeftUpX = x - 1;
	int32 LeftUpY = y + 1;
	if (LeftUpX >= 0 && LeftUpX < DungeonWidth &&
		LeftUpY >= 0 && LeftUpY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(LeftUpX, LeftUpY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 RightX = x + 1;
	int32 RightY = y + 0;
	if (RightX >= 0 && RightX < DungeonWidth &&
		RightY >= 0 && RightY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(RightX, RightY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 RightUpX = x + 1;
	int32 RightUpY = y + 1;
	if (RightUpX >= 0 && RightUpX < DungeonWidth &&
		RightUpY >= 0 && RightUpY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(RightUpX, RightUpY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 RightDownX = x + 1;
	int32 RightDownY = y - 1;
	if (RightDownX >= 0 && RightDownX < DungeonWidth &&
		RightDownY >= 0 && RightDownY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(RightDownX, RightDownY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 UpX = x + 0;
	int32 UpY = y + 1;
	if (UpX >= 0 && UpX < DungeonWidth &&
		UpY >= 0 && UpY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(UpX, UpY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}


	int32 DownX = x + 0;
	int32 DownY = y - 1;
	if (DownX >= 0 && DownX < DungeonWidth &&
		DownY >= 0 && DownY < DungeonHeight)
	{
		int32 TempTile = this->xy2tile(DownX, DownY);
		if (TempTile != -1)
		{
			uint8 TempTileAttribute = TempMap->getMapTileAttribute(TempTile);
			if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
			{
				return true;
			}
		}
	}

	return false;
}

void ACWRandomDungeonGenerator::PlaceRandomRegionTopography(int32 TempRegionId, ECWDungeonRegionTopography TempRegionTopography, int32 x, int32 y, int32 ParamHighWidth, int32 ParamHighHeight)
{
	FCWRandomDungeonRegionTopography TempDungeonRegionTopography;
	TempDungeonRegionTopography.OriginX = x;
	TempDungeonRegionTopography.OriginY = y;
	TempDungeonRegionTopography.DungeonRegionId = TempRegionId;
	TempDungeonRegionTopography.SizeX = ParamHighWidth;
	TempDungeonRegionTopography.SizeY = ParamHighHeight;
	TempDungeonRegionTopography.RegionTopography = TempRegionTopography;

	bool IsFind = ArrayRandomDungeonRegionTopography.ContainsByPredicate(
		[&TempDungeonRegionTopography](const FCWRandomDungeonRegionTopography& OtherRegionTopography) -> bool
		{
			return TempDungeonRegionTopography == OtherRegionTopography;
		}
	);
	if (!IsFind)
	{
		ArrayRandomDungeonRegionTopography.Add(TempDungeonRegionTopography);

		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::PlaceRandomRegionTopography, OriginX:%d, OriginY:%d, SizeX:%d, SizeY:%d, TempRegionTopography:%d."), TempDungeonRegionTopography.OriginX, TempDungeonRegionTopography.OriginY, TempDungeonRegionTopography.SizeX, TempDungeonRegionTopography.SizeY, (int32)TempRegionTopography);
	}
}

void ACWRandomDungeonGenerator::PlaceRandomRegion(int32 TempRegionId, int32 x, int32 y, int32 ParamHighWidth, int32 ParamHighHeight)
{
	FCWRandomDungeonRegionData TempDungeonRegionData;
	TempDungeonRegionData.OriginX = x; 
	TempDungeonRegionData.OriginY = y;
	TempDungeonRegionData.DungeonRegionId = TempRegionId;
	TempDungeonRegionData.SizeX = ParamHighWidth;
	TempDungeonRegionData.SizeY = ParamHighHeight;

	bool IsFind = ArrayRandomDungeonRegion.ContainsByPredicate(
		[&TempDungeonRegionData](const FCWRandomDungeonRegionData& OtherRegionData) -> bool
	{
		return TempDungeonRegionData == OtherRegionData;
	}
	);
	if (!IsFind)
	{
		ArrayRandomDungeonRegion.Add(TempDungeonRegionData);

		UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::PlaceRandomRegion, OriginX:%d, OriginY:%d, SizeX:%d, SizeY:%d, DungeonRegionId:%d."), TempDungeonRegionData.OriginX, TempDungeonRegionData.OriginY, TempDungeonRegionData.SizeX, TempDungeonRegionData.SizeY, TempDungeonRegionData.DungeonRegionId);
	}
}

bool ACWRandomDungeonGenerator::GetFirstDungeonHasWall(FCWRandomDungeonRegionData& ParamDungeonRegionData)
{
	for (TArray<FCWRandomDungeonRegionData>::TIterator iter = ArrayRandomDungeonRegion.CreateIterator(); iter; ++iter)
	{
		FCWRandomDungeonRegionData& TempDungeonRegionData = *iter;
	}

	return false;
}

int ACWRandomDungeonGenerator::GetRandomDungeonRegionTopography(int32 ParamTile, int32& HighLandCount, int32& LowLandCount)
{
	HighLandCount = 0;
	LowLandCount = 0;

	int x = 0;
	int y = 0;
	this->tile2xy(ParamTile, x, y);
	for (TArray<FCWRandomDungeonRegionTopography>::TIterator iter = ArrayRandomDungeonRegionTopography.CreateIterator(); iter; ++iter)
	{
		FCWRandomDungeonRegionTopography& TempDungeonRegionTopography = *iter;
		int TempX = TempDungeonRegionTopography.OriginX + TempDungeonRegionTopography.SizeX - 1;
		int TempY = TempDungeonRegionTopography.OriginY + TempDungeonRegionTopography.SizeY - 1;
		if (x >= TempDungeonRegionTopography.OriginX && x <= TempX &&
			y >= TempDungeonRegionTopography.OriginY && y <= TempY)
		{
			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::GetRandomDungeonRegionTopography, ParamTile:%d, x:%d, y:%d, DungeonRegionId:%d, TempDungeonRegionData.RegionType:%d."), ParamTile, x, y, TempDungeonRegionData.DungeonRegionId, (int)TempDungeonRegionData.RegionTopography);
			if (TempDungeonRegionTopography.RegionTopography == ECWDungeonRegionTopography::HighLand)
				HighLandCount++;
			else if (TempDungeonRegionTopography.RegionTopography == ECWDungeonRegionTopography::LowLand)
				LowLandCount++;
		}
	}

	if (HighLandCount > LowLandCount)
		return (int)ECWDungeonRegionTopography::HighLand;
	else if (HighLandCount < LowLandCount)
		return (int)ECWDungeonRegionTopography::LowLand;
	else
		return (int)ECWDungeonRegionTopography::FlatLand;
}

void ACWRandomDungeonGenerator::RefreshRandomDungeonRegion(int32 ParamTile)
{
	int x = 0;
	int y = 0;
	this->tile2xy(ParamTile, x, y);
	for (TArray<FCWRandomDungeonRegionData>::TIterator iter = ArrayRandomDungeonRegion.CreateIterator(); iter; ++iter)
	{
		FCWRandomDungeonRegionData& TempDungeonRegionData = *iter;
		int TempX = TempDungeonRegionData.OriginX + TempDungeonRegionData.SizeX - 1;
		int TempY = TempDungeonRegionData.OriginY + TempDungeonRegionData.SizeY - 1;
		if (x >= TempDungeonRegionData.OriginX && x <= TempX &&
			y >= TempDungeonRegionData.OriginY && y <= TempY)
		{
			//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, 1 ParamTile:%d, DungeonRegionId:%d, x:%d, y:%d, OriginX:%d, OriginY:%d, TempX:%d, TempY%d, SizeX:%d, SizeY:%d."), ParamTile, TempDungeonRegionData.DungeonRegionId, x, y, TempDungeonRegionData.OriginX, TempDungeonRegionData.OriginY, TempX, TempY, TempDungeonRegionData.SizeX, TempDungeonRegionData.SizeY);
			ArrayDungeonRegionId[ParamTile] = TempDungeonRegionData.DungeonRegionId;

			FCWDungeonRegionDataStruct* TempDungeonRegionDataStruct = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), TempDungeonRegionData.DungeonRegionId);
			if (TempDungeonRegionDataStruct == nullptr)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, TempDungeonRegionData == nullptr, DungeonRegionId:%d."), TempDungeonRegionData.DungeonRegionId);
				continue;
			}

			std::vector<int32> TempArrayRegionHeightMinMax = FCWDungeonRegionDataUtils::GetArrayRegionHeightMinMaxFromString(TempDungeonRegionDataStruct->ArrayRegionHeightMinMax);
			if (TempArrayRegionHeightMinMax.size() != 2)
			{
				UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, TempArrayRegionHeightMinMax.size() != 2, TempArrayRegionHeightMinMax.size():%d, DungeonRegionId:%d."), TempArrayRegionHeightMinMax.size(), TempDungeonRegionData.DungeonRegionId);
				continue;
			}
			int32 TempHeightMin = TempArrayRegionHeightMinMax[0];
			int32 TempHeightMax = TempArrayRegionHeightMinMax[1];
			int32 CurrZ = ArrayDungeonGrid_Z[ParamTile];
			if (CurrZ >= TempHeightMin && CurrZ <= TempHeightMax)
			{
				//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, 2 ParamTile:%d, DungeonRegionId:%d, CurrZ:%d, TempHeightMin:%d, TempHeightMax:%d, x:%d, y:%d, OriginX:%d, OriginY:%d, SizeX:%d, SizeY:%d."), ParamTile, TempDungeonRegionData.DungeonRegionId, CurrZ, TempHeightMin, TempHeightMax, x, y, TempDungeonRegionData.OriginX, TempDungeonRegionData.OriginY, TempDungeonRegionData.SizeX, TempDungeonRegionData.SizeY);
			}
			else
			{
				if (CurrZ < TempHeightMin)
				{
					ArrayDungeonGrid_Z[ParamTile] = TempHeightMin;

					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, 3 ParamTile:%d, DungeonRegionId:%d, CurrZ:%d, TempHeightMin:%d, x:%d, y:%d, OriginX:%d, OriginY:%d, SizeX:%d, SizeY:%d."), ParamTile, TempDungeonRegionData.DungeonRegionId, CurrZ, TempHeightMin, x, y, TempDungeonRegionData.OriginX, TempDungeonRegionData.OriginY, TempDungeonRegionData.SizeX, TempDungeonRegionData.SizeY);
				}
				
				if (CurrZ > TempHeightMax)
				{
					ArrayDungeonGrid_Z[ParamTile] = TempHeightMax;

					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegion, 4 ParamTile:%d, DungeonRegionId:%d, CurrZ:%d, TempHeightMax:%d, x:%d, y:%d, OriginX:%d, OriginY:%d, SizeX:%d, SizeY:%d."), ParamTile, TempDungeonRegionData.DungeonRegionId, CurrZ, TempHeightMax, x, y, TempDungeonRegionData.OriginX, TempDungeonRegionData.OriginY, TempDungeonRegionData.SizeX, TempDungeonRegionData.SizeY);
				}
			}
				
		}
	}
}

void ACWRandomDungeonGenerator::RefreshRandomDungeonRegionCenterOrBorder(int32 ParamX, int32 ParamY, int32 ParamTile)
{
	if (ArrayDungeonRegionId[ParamTile] == 0)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Center;
		return;
	}

	int32 TempX = -1; 
	int32 TempY = -1;
	int32 TempTile = -1;

	TempX = ParamX - 1;
	TempY = ParamY - 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX - 1;
	TempY = ParamY - 0;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX - 1;
	TempY = ParamY + 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	
	TempX = ParamX - 0;
	TempY = ParamY - 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX - 0;
	TempY = ParamY - 0;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX - 0;
	TempY = ParamY + 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX + 1;
	TempY = ParamY - 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX + 1;
	TempY = ParamY - 0;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	TempX = ParamX + 1;
	TempY = ParamY + 1;
	TempTile = this->xy2tile(TempX, TempY);
	if (TempTile == -1)
	{
		ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}
	else
	{
		if (ArrayDungeonRegionId[TempTile] != ArrayDungeonRegionId[ParamTile])
			ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Border;
	}

	ArrayDungeonRegionSpace[ParamTile] = ECWDungeonRegionSpace::Center;
}

void ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBase(int32 ParamTile, ECWDungeonRegionStyle ParamDungeonStyle)
{
	int TempDungeonRegionId = ArrayDungeonRegionId[ParamTile];
	if (TempDungeonRegionId != 0)
	{
		return;
	}

	if (ArrayDungeonGrid_Z[ParamTile] == 0)
	{
		TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
	}
	else if (ArrayDungeonGrid_Z[ParamTile] > 0)
	{
		TempDungeonRegionId = FindDungeonRegionDataForHighLandBase(ParamDungeonStyle);
	}
	else if (ArrayDungeonGrid_Z[ParamTile] < 0)
	{
		TempDungeonRegionId = FindDungeonRegionDataForLowLandBase(ParamDungeonStyle);
	}

	if (TempDungeonRegionId == -1)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBase, TempDungeonRegionId == -1 ParamTile:%d, ParamDungeonStyle:%d."), ParamTile, (int32)ParamDungeonStyle);
	}

	if (ArrayDungeonRegionId[ParamTile] == 0)
	{
		ArrayDungeonRegionId[ParamTile] = TempDungeonRegionId;
	}
}

void ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart(FCWDungeonDataStruct* ParamDungeonData, int32 ParamTile, ECWDungeonRegionStyle ParamDungeonStyle)
{
	ACWMap* TempMap = GetMap();
	check(TempMap);

	int x;
	int y;
	this->tile2xy(ParamTile, x, y);

	int32 X = x - 0;
	int32 Y = y - 0;
	if (X >= 0 && X < DungeonWidth &&
		Y >= 0 && Y < DungeonHeight)
	{
		uint8 TempTileAttribute = TempMap->getMapTileAttribute(X, Y);
		if ((TempTileAttribute & (uint8)ECWDungeonTileAttribute::PawnStart) > 0)
		{
			int32 TempTile = this->xy2tile(X, Y);
			if (TempTile != -1)
			{
				//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, X:%d, Y:%d."), TempTile, X, Y);
				int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
				ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
				ArrayDungeonGrid_Z[TempTile] = 0;
			}

			int32 LeftX = x - 1;
			int32 LeftY = y - 0;
			if (LeftX >= 0 && LeftX < DungeonWidth &&
				LeftY >= 0 && LeftY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(LeftX, LeftY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, LeftX:%d, LeftY:%d."), TempTile, LeftX, LeftY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 LeftDownX = x - 1;
			int32 LeftDownY = y - 1;
			if (LeftDownX >= 0 && LeftDownX < DungeonWidth &&
				LeftDownY >= 0 && LeftDownY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(LeftDownX, LeftDownY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, LeftDownX:%d, LeftDownY:%d."), TempTile, LeftDownX, LeftDownY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 LeftUpX = x - 1;
			int32 LeftUpY = y + 1;
			if (LeftUpX >= 0 && LeftUpX < DungeonWidth &&
				LeftUpY >= 0 && LeftUpY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(LeftUpX, LeftUpY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, LeftUpX:%d, LeftUpY:%d."), TempTile, LeftUpX, LeftUpY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 RightX = x + 1;
			int32 RightY = y + 0;
			if (RightX >= 0 && RightX < DungeonWidth &&
				RightY >= 0 && RightY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(RightX, RightY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, RightX:%d, RightY:%d."), TempTile, RightX, RightY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 RightUpX = x + 1;
			int32 RightUpY = y + 1;
			if (RightUpX >= 0 && RightUpX < DungeonWidth &&
				RightUpY >= 0 && RightUpY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(RightUpX, RightUpY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, RightUpX:%d, RightUpY:%d."), TempTile, RightUpX, RightUpY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 RightDownX = x + 1;
			int32 RightDownY = y - 1;
			if (RightDownX >= 0 && RightDownX < DungeonWidth &&
				RightDownY >= 0 && RightDownY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(RightDownX, RightDownY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, RightDownX:%d, RightDownY:%d."), TempTile, RightDownX, RightDownY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 UpX = x + 0;
			int32 UpY = y + 1;
			if (UpX >= 0 && UpX < DungeonWidth &&
				UpY >= 0 && UpY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(UpX, UpY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, UpX:%d, UpY:%d."), TempTile, UpX, UpY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}


			int32 DownX = x + 0;
			int32 DownY = y - 1;
			if (DownX >= 0 && DownX < DungeonWidth &&
				DownY >= 0 && DownY < DungeonHeight)
			{
				int32 TempTile = this->xy2tile(DownX, DownY);
				if (TempTile != -1)
				{
					//UE_LOG(LogCWRandomDungeonGenerator, Log, TEXT("ACWRandomDungeonGenerator::RefreshRandomDungeonRegionBaseForPawnStart, TempTile:%d, DownX:%d, DownY:%d."), TempTile, DownX, DownY);
					int32 TempDungeonRegionId = FindDungeonRegionDataForFlatLandBase(ParamDungeonStyle);
					ArrayDungeonRegionId[TempTile] = TempDungeonRegionId;
					ArrayDungeonGrid_Z[TempTile] = 0;
				}
			}
		}
	}
}

int32 ACWRandomDungeonGenerator::FindDungeonRegionDataForFlatLandBase(ECWDungeonRegionStyle ParamDungeonStyle)
{
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));
	//UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForFlatLandBase, GetCSVRowCount, TotalCount:%d."), TotalCount);
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForFlatLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ParamDungeonStyle && TempDungeonRegionData->IsBasicRegion == 1)
		{
			return i;
		}
	}

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForFlatLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ECWDungeonRegionStyle::Common && TempDungeonRegionData->IsBasicRegion == 1)
		{
			return i;
		}
	}

	return -1;
}

int32 ACWRandomDungeonGenerator::FindDungeonRegionDataForHighLandBase(ECWDungeonRegionStyle ParamDungeonStyle)
{
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));
	//UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForHighLandBase, GetCSVRowCount, TotalCount:%d."), TotalCount);
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForHighLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ParamDungeonStyle && TempDungeonRegionData->IsBasicRegion == 3)
		{
			return i;
		}
	}

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForHighLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ECWDungeonRegionStyle::Common && TempDungeonRegionData->IsBasicRegion == 3)
		{
			return i;
		}
	}

	return -1;
}

int32 ACWRandomDungeonGenerator::FindDungeonRegionDataForLowLandBase(ECWDungeonRegionStyle ParamDungeonStyle)
{
	int32 TotalCount = FCWCommonUtil::GetCSVRowCount<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"));
	//UE_LOG(LogCWRandomDungeonGenerator, Warning, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForLowLandBase, GetCSVRowCount, TotalCount:%d."), TotalCount);
	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForLowLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ParamDungeonStyle && TempDungeonRegionData->IsBasicRegion == 2)
		{
			return i;
		}
	}

	for (int i = 1; i <= TotalCount; ++i)
	{
		FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), i);
		if (TempDungeonRegionData == nullptr)
		{
			UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::FindDungeonRegionDataForLowLandBase, TempDungeonRegionData == nullptr i:%d."), i);
			continue;
		}

		ECWDungeonRegionStyle TempRegionStyle = (ECWDungeonRegionStyle)TempDungeonRegionData->Style;
		if (TempRegionStyle == ECWDungeonRegionStyle::Common && TempDungeonRegionData->IsBasicRegion == 2)
		{
			return i;
		}
	}

	return -1;
}

void ACWRandomDungeonGenerator::RandomShuffle(
	std::vector<int32>& ParamArrayDungeonRegionIdForRandom,
	std::vector<std::vector<int32> >& ParamArrayArrayDungeonRegionRandomMinMaxForRandom,
	std::vector<std::vector<int32> >& ParamArrayArrayDungeonRegionSideMinMaxForRandom,
	int ParamShuffleCount)
{
	for (int i = 0; i < ParamShuffleCount; i++)
	{
		int firstIndex = rand() % ParamArrayDungeonRegionIdForRandom.size();
		int secondIndex = rand() % ParamArrayDungeonRegionIdForRandom.size();

		if (firstIndex == secondIndex)
		{
			secondIndex++;     
			if (secondIndex >= ParamArrayDungeonRegionIdForRandom.size())
			{
				secondIndex = 0;
			}
		}

		Swap(ParamArrayDungeonRegionIdForRandom[firstIndex], ParamArrayDungeonRegionIdForRandom[secondIndex]);
		Swap(ParamArrayArrayDungeonRegionRandomMinMaxForRandom[firstIndex], ParamArrayArrayDungeonRegionRandomMinMaxForRandom[secondIndex]);
		Swap(ParamArrayArrayDungeonRegionSideMinMaxForRandom[firstIndex], ParamArrayArrayDungeonRegionSideMinMaxForRandom[secondIndex]);
	}
}

void ACWRandomDungeonGenerator::RandomShuffle(
	std::vector<std::vector<int32> >& ParamArrayDungeonRegionToRandom,
	std::vector<int32>& ParamArrayDungeonRegionIdForRandom,
	int ParamShuffleCount)
{
	for (int i = 0; i < ParamShuffleCount; i++)
	{
		int firstIndex = rand() % ParamArrayDungeonRegionToRandom.size();
		int secondIndex = rand() % ParamArrayDungeonRegionToRandom.size();

		if (firstIndex == secondIndex)
		{
			secondIndex++;
			if (secondIndex >= ParamArrayDungeonRegionToRandom.size())
			{
				secondIndex = 0;
			}
		}

		Swap(ParamArrayDungeonRegionToRandom[firstIndex], ParamArrayDungeonRegionToRandom[secondIndex]);
		Swap(ParamArrayDungeonRegionIdForRandom[firstIndex], ParamArrayDungeonRegionIdForRandom[secondIndex]);
	}
}

void ACWRandomDungeonGenerator::RandomShuffle(std::vector<int32>& ParamArrayDoor, int ParamShuffleCount)
{
	for (int i = 0; i < ParamShuffleCount; i++)
	{
		int firstIndex = rand() % ParamArrayDoor.size();
		int secondIndex = rand() % ParamArrayDoor.size();

		if (firstIndex == secondIndex)
		{
			secondIndex++;
			if (secondIndex >= ParamArrayDoor.size())
			{
				secondIndex = 0;
			}
		}

		Swap(ParamArrayDoor[firstIndex], ParamArrayDoor[secondIndex]);
	}
}

void ACWRandomDungeonGenerator::Swap(std::vector<int32>& lhs, std::vector<int32>& rhs)
{
	std::vector<int32> Temp = lhs;
	lhs = rhs;
	rhs = Temp;
}

void ACWRandomDungeonGenerator::Swap(int32& lhs, int32& rhs)
{
	int32 Temp = lhs;
	lhs = rhs;
	rhs = Temp;
}

FCWDungeonRegionDataStruct* ACWRandomDungeonGenerator::GetDungeonRegionData(int32 ParamDungeonRegionId)
{
	FCWDungeonRegionDataStruct* TempDungeonRegionData = FCWCommonUtil::FindCSVRow<FCWDungeonRegionDataStruct>(TEXT("CWDungeonRegionDataTable"), ParamDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GetDungeonRegionData, TempDungeonRegionData == nullptr, ParamDungeonRegionId:%d."), ParamDungeonRegionId);
		return nullptr;
	}
	return TempDungeonRegionData;

}

FCWDungeonDataStruct* ACWRandomDungeonGenerator::GetDungeonData()
{
	FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), RandomDungeonId);
	if (TempDungeonData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GetDungeonData, TempDungeonData == nullptr, RandomDungeonId:%d."), RandomDungeonId);
		return nullptr;
	}
	return TempDungeonData;
}

FCWDungeonItemDataStruct* ACWRandomDungeonGenerator::GetDungeonItemData(int32 ParamDungeonItemId)
{
	FCWDungeonItemDataStruct* TempDungeonItemData = FCWCommonUtil::FindCSVRow<FCWDungeonItemDataStruct>(TEXT("CWDungeonItemDataTable"), ParamDungeonItemId);
	if (TempDungeonItemData == nullptr)
	{
		UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::GetDungeonItemData, TempDungeonItemData == nullptr, ParamDungeonItemId:%d."), ParamDungeonItemId);
		return nullptr;
	}
	return TempDungeonItemData;
}

bool ACWRandomDungeonGenerator::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWRandomDungeonGenerator::IsMyClientPawn() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWRandomDungeonGenerator::IsOtherClientPawn() const
{
	return Role == ROLE_SimulatedProxy;
}

int32 ACWRandomDungeonGenerator::GetGameId()
{
	for (TActorIterator<ACWGameInfo> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWGameInfo* GameInfo = *Iter;
		check(GameInfo != nullptr);
		return GameInfo->GetGameId();
		break;
	}

	return 0;
}

FCWGameDataStruct* ACWRandomDungeonGenerator::LoadGameData(int32 TempGameId)
{
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	return TempGameData;
}

float ACWRandomDungeonGenerator::GetLowestTileZ()
{
	if (LowestTileZ >= 0.1f)
	{
		for (auto& OffsetZ : ArrayTileOffsetZ)
		{
			if (OffsetZ < LowestTileZ)
			{
				LowestTileZ = OffsetZ;
			}
		}
	}

	return LowestTileZ;
}

void ACWRandomDungeonGenerator::OnLevelSiteRise(const ACWDungeonTile* InTile)
{
	if (!bLevelSiteRiseBegin)
	{
		bLevelSiteRiseBegin = true;
		OnLevelSiteRiseBegin(InTile);
	}
}

void ACWRandomDungeonGenerator::OnLevelSiteRiseBegin(const ACWDungeonTile* InTile)
{
	// 播放声音(中心石头开始上升)
	if (UCWAudioVideoMgr* AV_Mgr = AV_MGR(this))
	{
		AV_Mgr->PlayAudioByCfg(AT_LevelMisc, FPeripherySceneObj::StoneRaise);
	}
}

bool ACWRandomDungeonGenerator::RandomOffsetTileZRange(FVector2D& OutOffsetRange)
{
	OutOffsetRange = FVector2D::ZeroVector;
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("RandomTile_Offset")))
	{
		TArray<FString> ParseArray;
		if (ConstData->Param.ParseIntoArray(ParseArray, TEXT(",")) >= 2)
		{
			OutOffsetRange.X = FSTRING_TO_INT(ParseArray[0]);
			OutOffsetRange.Y = FSTRING_TO_INT(ParseArray[1]);
			return true;
		}
	}
	return false;
}

void ACWRandomDungeonGenerator::OnRep_ArrayTileOffsetZ()
{
	ACWMap* MyMap = GetMap();
	check(MyMap);

	// 格子额外偏移
	float MapTileOffsetZ = GetObjectExtraOffsetZ();

	//~ 重置客户端地块格子位置
	const TArray<ACWMapTile*>& ClientArrayTiles = MyMap->GetArrayTiles();
	CWG_LOG(">> %s::OnRep_ArrayTileOffsetZ, ClientArrayTiles.Num[%d] ArrayTileOffsetZ.Num[%d].", *GetName(), ClientArrayTiles.Num(), ArrayTileOffsetZ.Num());
	for (int32 i = 0; i < ClientArrayTiles.Num(); ++i)
	{
		ACWMapTile* MapTileObj = ClientArrayTiles[i];
		if (IsValid(MapTileObj))
		{
			const int32 MapTileNumber = MapTileObj->GetTile();
			FVector NewLocation = MapTileObj->GetActorLocation();
			float NewOffsetZ = GetLocationZ(MapTileNumber);
			NewLocation.Z = MapTileOffsetZ + NewOffsetZ;
			MapTileObj->SetActorLocation(NewLocation);

			//CWG_LOG(">> OnRep_ArrayTileOffsetZ, i[%d] Tile[%d] NewLocation[%s].", i, MapTileNumber, *NewLocation.ToString());
		}
	}
	//CWG_WARNING(">> OnRep_ArrayTileOffsetZ -> Over, ClientArrayTiles[%d] ArrayTileOffsetZ[%d].", sizeof(ClientArrayTiles), sizeof(ArrayTileOffsetZ));
}

void ACWRandomDungeonGenerator::OnBattleStateChange(const ECWBattleState InOldState, const ECWBattleState InCurState)
{
	if (InCurState == ECWBattleState::Ready)
	{
		RefreshAllLocationInClient();
	}
}

void ACWRandomDungeonGenerator::ResetObjectExtraOffsetZ()
{
	ObjectExtraOffsetZ = 2.f;
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("MapTileOffsetZ")))
	{
		ObjectExtraOffsetZ = FSTRING_TO_FLOAT(ConstData->Param);
	}
}

float ACWRandomDungeonGenerator::GetObjectExtraOffsetZ()
{
	return ObjectExtraOffsetZ;
}

float ACWRandomDungeonGenerator::GetLocationZ(const int32 InTileNumber)
{
	float NewOffsetZ = GetOffsetZ(InTileNumber);
	if (FMath::IsNearlyZero(NewOffsetZ))
	{
		//~ 查找地块绑定高度偏移
		ACWDungeonTile* DungeonTile = GetDungeonTile(InTileNumber);
		if (DungeonTile != nullptr)
		{
			NewOffsetZ = DungeonTile->GetOffsetZ();
		}
	}
	return NewOffsetZ;
}

bool ACWRandomDungeonGenerator::RandomOffsetTileList(TArray<int32>& OutArray)
{
	OutArray.Empty();

	// 获取有效地块格子列表
	TArray<int32> ValidGridArray;
	for (int32 i = 0; i < ArrayDungeonGrid.Num(); ++i)
	{
		if (ArrayDungeonGrid[i] > 0)
		{
			ValidGridArray.Push(i);
		}
	}

	if (ValidGridArray.Num() <= 0)
	{
		return false;
	}
	
	// 获取随机格子列表(有效格子)
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("RandomTile_Percent")))
	{
		TArray<FString> ParseArray;
		const int32 TotalTile = ValidGridArray.Num();
		if (TotalTile > 0 && ConstData->Param.ParseIntoArray(ParseArray, TEXT(",")) >= 2)
		{
			const int32 Min = FSTRING_TO_INT(ParseArray[0]);
			const int32 Max = FSTRING_TO_INT(ParseArray[1]);
			const int32 Rand = FMath::RandRange(Min, Max);
			const int32 RandTotal = FMath::FloorToInt((float)Rand / 100.f * (float)TotalTile);

			// 随机数
			int32 CurTileIdx = 0;
			while (RandTotal > 0 && OutArray.Num() < RandTotal)
			{
				const bool bTrue = FMath::RandBool();
				if (bTrue && (CurTileIdx < TotalTile) && 
					!OutArray.Contains(ValidGridArray[CurTileIdx]))
				{
					OutArray.Push(ValidGridArray[CurTileIdx]);
				}

				CurTileIdx += 2;
				if (CurTileIdx >= TotalTile)
				{
					CurTileIdx = (CurTileIdx % 2 == 0) ? 1 : 0;
				}
			}
			return true;
		}
	}

	return false;
}

ACWMap* ACWRandomDungeonGenerator::GetMap()
{
	return UCWFuncLib::GetActor<ACWMap>(GetWorld());
}

ACWPlayerController* ACWRandomDungeonGenerator::GetLocalPC()
{
	UWorld* MyWorld = GetWorld();
	ACWPlayerController* LocalPC = Cast<ACWPlayerController>(MyWorld->GetFirstPlayerController());
	return LocalPC;
}

// 无效中心点
const FVector InValidSceneCenterPoint = FVector(0.f, 0.f, 10000.f);

FVector ACWRandomDungeonGenerator::GetSceneCenterPoint()
{
	FVector RetValue(InValidSceneCenterPoint);
	if (DungeonWidth > 0 && DungeonHeight > 0)
	{
		int32 x = DungeonWidth / 2 + 1;
		int32 y = DungeonHeight / 2 + 1;
		xy2pos(x, y, RetValue);
	}
	return RetValue;
}

bool ACWRandomDungeonGenerator::IsValidSceneCenterPoint(const FVector& InPoint)
{
	return !InPoint.Equals(InValidSceneCenterPoint);
}

FVector2D ACWRandomDungeonGenerator::GetSingleTileSize()
{
	FVector2D RetValue(-1.f, -1.f);
	if (FCWDungeonDataStruct* DungeonData = GetDungeonData())
	{
		RetValue.Set(DungeonData->DungeonGridWidth, DungeonData->DungeonGridHeight);
	}
	return RetValue;
}

bool ACWRandomDungeonGenerator::GetEdgeDirectionPoint(FVector& OutDownPoint, FVector& OutTopPoint, 
	FVector& OutRightPoint, FVector& OutLeftPoint, const uint32 InExpandOutTileNum)
{
	bool bResult = false;
	FVector2D const GridSize = GetSingleTileSize();
	FVector const CenterPoint = GetSceneCenterPoint();
	if (GridSize.X > 0 && IsValidSceneCenterPoint(CenterPoint))
	{
		bResult = true;
		float const HorizonWidth = DungeonWidth * GridSize.X;
		float const VerticalHeight = DungeonHeight * GridSize.Y;

		float const HorizonOffset = (HorizonWidth / 2.f) + (InExpandOutTileNum * GridSize.X);
		float const VerticalOffset = (VerticalHeight / 2.f) + (InExpandOutTileNum * GridSize.Y);

		OutLeftPoint = FVector(CenterPoint.X - HorizonOffset, CenterPoint.Y, CenterPoint.Z);
		OutRightPoint = FVector(CenterPoint.X + HorizonOffset, CenterPoint.Y, CenterPoint.Z);

		OutDownPoint = FVector(CenterPoint.X, CenterPoint.Y - VerticalOffset, CenterPoint.Z);
		OutTopPoint = FVector(CenterPoint.X, CenterPoint.Y + VerticalOffset, CenterPoint.Z);
	}
	return bResult;
}

bool ACWRandomDungeonGenerator::GetEdgeDiagonalPoint(FVector& OutDownRight, FVector& OutDownLeft, 
	FVector& OutTopRight, FVector& OutTopLeft, const uint32 InExpandOutTileNum)
{
	bool bResult = false;
	FVector2D const GridSize = GetSingleTileSize();
	FVector const CenterPoint = GetSceneCenterPoint();
	if (GridSize.X > 0 && IsValidSceneCenterPoint(CenterPoint))
	{
		bResult = true;
		float const HorizonWidth = DungeonWidth * GridSize.X;
		float const VerticalHeight = DungeonHeight * GridSize.Y;

		float const HorizonOffset = (HorizonWidth / 2.f) + (InExpandOutTileNum * GridSize.X);
		float const VerticalOffset = (VerticalHeight / 2.f) + (InExpandOutTileNum * GridSize.Y);

		OutDownLeft = FVector(CenterPoint.X - HorizonOffset, CenterPoint.Y - VerticalOffset, CenterPoint.Z);
		OutDownRight = FVector(CenterPoint.X + HorizonOffset, CenterPoint.Y - VerticalOffset, CenterPoint.Z);

		OutTopLeft = FVector(CenterPoint.X - HorizonOffset, CenterPoint.Y + VerticalOffset, CenterPoint.Z);
		OutTopRight = FVector(CenterPoint.X + HorizonOffset, CenterPoint.Y + VerticalOffset, CenterPoint.Z);
	}
	return bResult;
}

TArray<ACWPawnStart*>& ACWRandomDungeonGenerator::GetPawnStartList()
{
	return ArrayPawnStart;
}

ACWPawnStart* ACWRandomDungeonGenerator::GetPawnStartByTile(const int32 InTile)
{
	return ArrayPawnStart.IsValidIndex(InTile) ? ArrayPawnStart[InTile] : nullptr;
}

float ACWRandomDungeonGenerator::GetOffsetZ(const int32 InTile)
{
	return ArrayTileOffsetZ.IsValidIndex(InTile) ? ArrayTileOffsetZ[InTile] : 0.f;
}

TArray<ACWDungeonTile*>& ACWRandomDungeonGenerator::GetDungeonTileList()
{
	return ArrayDungeonTile;
}

ACWDungeonItemGroup* ACWRandomDungeonGenerator::GetDungeonItemGroup(int32 ParamTile)
{
	if (ArrayDungeonItemGroup.IsValidIndex(ParamTile))
	{
		return ArrayDungeonItemGroup[ParamTile];
	}
	return nullptr;
}

bool ACWRandomDungeonGenerator::IsAllDungeonItemBeginPlayInClient()
{
	/*if (ArrayDungeonItem.Num() <= 0)
		return false;
	
	for (TArray<ACWDungeonItem*>::TIterator iter = ArrayDungeonItem.CreateIterator(); iter; ++iter)
	{
		ACWDungeonItem* TempItem = *iter;
		if (TempItem != nullptr)
		{
			if (!TempItem->IsBeginPlayInClient())
				return false;
		}
	}

	return true;*/
	
	for (TArray<ACWDungeonItemGroup*>::TIterator iter = ArrayDungeonItemGroup.CreateIterator(); iter; ++iter) 
	{
		ACWDungeonItemGroup* TempItemGroup = *iter;
		if (!TempItemGroup->IsBeginPlayInClient())
			return false;
	}
	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonTileBeginPlayInClient()
{
	if (ArrayDungeonTile.Num() <= 0)
		return false;

	for (TArray<ACWDungeonTile*>::TIterator iter = ArrayDungeonTile.CreateIterator(); iter; ++iter)
	{
		ACWDungeonTile* TempTile = *iter;
		if (TempTile != nullptr)
		{
			if (!TempTile->IsBeginPlayInClient())
				return false;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonItemTickTimeOKInClient()
{
	for (TArray<ACWDungeonItemGroup*>::TIterator iter = ArrayDungeonItemGroup.CreateIterator(); iter; ++iter) 
	{
		ACWDungeonItemGroup* TempItemGroup = *iter;
		if (TempItemGroup == nullptr) 
			continue;

		TArray<ACWDungeonItem*> TempItems;
		TempItemGroup->GetAllArrayItem(TempItems);
		for (TArray<ACWDungeonItem*>::TIterator it = TempItems.CreateIterator(); it; ++it)
		{
			ACWDungeonItem * TempItem = *it;
			if (TempItem == nullptr) 
				continue;

			if (TempItem->GetTickTime() < 0.5f) 
				return false;
		}
	}
	return true; 
}

bool ACWRandomDungeonGenerator::IsAllDungeonTileTickTimeOKInClient()
{
	if (ArrayDungeonTile.Num() <= 0)
		return false;

	for (TArray<ACWDungeonTile*>::TIterator iter = ArrayDungeonTile.CreateIterator(); iter; ++iter)
	{
		ACWDungeonTile* TempTile = *iter;
		if (TempTile != nullptr)
		{
			if (TempTile->GetTickTime() < 1.0f)
				return false;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonTileRiseOKInClient()
{
	if (ArrayDungeonTile.Num() <= 0)
		return false;

	for (TArray<ACWDungeonTile*>::TIterator iter = ArrayDungeonTile.CreateIterator(); iter; ++iter)
	{
		ACWDungeonTile* TempTile = *iter;
		if (TempTile != nullptr)
		{
			if (!TempTile->IsDoRised() || (TempTile->IsDoRised() && !TempTile->IsDoRiseEnd()))
				return false;
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonTileAfterRiseInClient()
{
	if (ArrayDungeonTile.Num() <= 0)
		return false;

	for (TArray<ACWDungeonTile*>::TIterator iter = ArrayDungeonTile.CreateIterator(); iter; ++iter)
	{
		ACWDungeonTile* TempTile = *iter;
		if (TempTile != nullptr)
		{
			if (TempTile->IsBeginPlayInClient())
			{
				if (!TempTile->IsDoRised() || (TempTile->IsDoRised() && !TempTile->IsDoRiseEnd()))
					return false;
			}
			else
			{
				return false;
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonDecorateDoRiseEndInClient()
{
	return true;

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	std::vector<int32> TempArrayDungeonDecorateTag = FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(TempDungeonData->ArrayDungeonDecorateTagMinMax);
	if (TempArrayDungeonDecorateTag.size() != 2)
	{
		return true;
	}
	int32 TempMin = TempArrayDungeonDecorateTag[0];
	int32 TempMax = TempArrayDungeonDecorateTag[1];
	if (TempMin > TempMax)
		TempMin = TempMax;
	for (TActorIterator<AStaticMeshActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AStaticMeshActor* TempActor = *Iter;
		UStaticMeshComponent* SMComp = TempActor ? TempActor->GetStaticMeshComponent() : nullptr;
		if (SMComp != nullptr && SMComp->ComponentTags.Num() > 0)
		{
			for (int32 TempTag = TempMin; TempTag <= TempMax; ++TempTag)
			{
				FString TempFStringTag = FString::FromInt(TempTag);
				FName TempFNameTag = FName(*TempFStringTag);
				if (SMComp->ComponentHasTag(TempFNameTag))
				{
					int32 TempIntTag = FCString::Atoi(*TempFStringTag);
					FCWDungeonDecorateDataStruct* TempDungeonDecorateData = FCWCommonUtil::FindCSVRow<FCWDungeonDecorateDataStruct>(TEXT("CWDungeonDecorateDataTable"), TempTag);
					if (TempDungeonDecorateData != nullptr)
					{
						UCWDungeonDecorateComponent* TempDungeonDecorateComponent = TempActor->FindComponentByClass<UCWDungeonDecorateComponent>();
						if (TempDungeonDecorateComponent == nullptr)
						{
							UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::IsAllDungeonDecorateDoRiseInClient fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
							continue;
						}

						if (!TempDungeonDecorateComponent->IsDoRiseEnd())
							return false;
					}
					else
					{
						UE_LOG(LogCWRandomDungeonGenerator, Error, TEXT("ACWRandomDungeonGenerator::IsAllDungeonDecorateDoRiseInClient fail, TempDungeonDecorateData == nullptr, DungeonDecorateTag:%d."), TempTag);
					}
				}
			}
		}
	}

	return true;
}

bool ACWRandomDungeonGenerator::IsAllDungeonDecorateTileBeginPlayInClient()
{
	if (ArrayDungeonDecorateTile.Num() <= 0)
		return false;

	for (TArray<ACWDungeonDecorateTile*>::TIterator iter = ArrayDungeonDecorateTile.CreateIterator(); iter; ++iter)
	{
		ACWDungeonDecorateTile* TempDecorateTile = *iter;
		if (TempDecorateTile != nullptr)
		{
			if (!TempDecorateTile->IsBeginPlayInClient())
				return false;
		}
	}

	return true;
}

ACWDungeonItem* ACWRandomDungeonGenerator::GetDungeonItem(int32 ParamTile)
{
	return nullptr;
}

TArray<ACWDungeonItem*> ACWRandomDungeonGenerator::GetAllDungeonItem(int32 ParamTile)
{
	TArray<ACWDungeonItem*> TempArrayDungeonItem;
	if (!ArrayDungeonItemGroup.IsValidIndex(ParamTile))
	{
		return TempArrayDungeonItem;
	}

	ArrayDungeonItemGroup[ParamTile]->GetAllArrayItem(TempArrayDungeonItem);
	return TempArrayDungeonItem;
}

TArray<ACWDungeonItem*> ACWRandomDungeonGenerator::GetAllDungeonItemByCanBeAttacked(int32 ParamTile)
{
	TArray<ACWDungeonItem*> TempArrayDungeonItem;
	if (!ArrayDungeonItemGroup.IsValidIndex(ParamTile))
	{
		return TempArrayDungeonItem;
	}

	ArrayDungeonItemGroup[ParamTile]->GetAllDungeonItemByCanBeAttacked(TempArrayDungeonItem);
	return TempArrayDungeonItem;
}

TArray<ACWDungeonItem*>ACWRandomDungeonGenerator::GetAllBuffObjects(int32 ParamTile)
{
	TArray<ACWDungeonItem*> TempArrayDungeonItem;
	if (!ArrayDungeonItemGroup.IsValidIndex(ParamTile))
	{
		return TempArrayDungeonItem;
	}

	if (ArrayDungeonItemGroup[ParamTile] != nullptr)
	{
		ArrayDungeonItemGroup[ParamTile]->GetAllBuffObjects(TempArrayDungeonItem);
	}
	return TempArrayDungeonItem;
}

ACWDungeonTile* ACWRandomDungeonGenerator::GetDungeonTile(int32 ParamTile)
{
	if (ArrayDungeonTile.IsValidIndex(ParamTile))
	{
		return ArrayDungeonTile[ParamTile];
	}
	return nullptr;
}
