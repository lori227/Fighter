#include "CWRandomDungeonRegionData.h"

FCWRandomDungeonRegionData::FCWRandomDungeonRegionData()
{
	Reset();
}

FCWRandomDungeonRegionData::FCWRandomDungeonRegionData(const FCWRandomDungeonRegionData& r)
{
	*this = r;
}

FCWRandomDungeonRegionData& FCWRandomDungeonRegionData::operator = (const FCWRandomDungeonRegionData& r)
{
	if (this == &r)
		return *this;

	this->OriginX = r.OriginX;
	this->OriginY = r.OriginY;
	this->SizeX = r.SizeX;
	this->SizeY = r.SizeY;
	this->DungeonRegionId = r.DungeonRegionId;
	this->DungeonRegionSpace = r.DungeonRegionSpace;
	return *this;
}

bool operator == (const FCWRandomDungeonRegionData& l, const FCWRandomDungeonRegionData& r)
{
	if (l.OriginX == r.OriginX &&
		l.OriginY == r.OriginY &&
		l.SizeX == r.SizeX &&
		l.SizeY == r.SizeY &&
		l.DungeonRegionId == r.DungeonRegionId)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void FCWRandomDungeonRegionData::Reset()
{
	this->OriginX = 0;
	this->OriginY = 0;
	this->SizeX = 0;
	this->SizeY = 0;
	this->DungeonRegionId = 0;
	this->DungeonRegionSpace = ECWDungeonRegionSpace::None;
}