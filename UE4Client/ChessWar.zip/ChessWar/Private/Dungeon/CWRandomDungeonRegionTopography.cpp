#include "CWRandomDungeonRegionTopography.h"

FCWRandomDungeonRegionTopography::FCWRandomDungeonRegionTopography()
{
	Reset();
}

FCWRandomDungeonRegionTopography::FCWRandomDungeonRegionTopography(const FCWRandomDungeonRegionTopography& r)
{
	*this = r;
}

FCWRandomDungeonRegionTopography& FCWRandomDungeonRegionTopography::operator = (const FCWRandomDungeonRegionTopography& r)
{
	if (this == &r)
		return *this;

	this->OriginX = r.OriginX;
	this->OriginY = r.OriginY;
	this->SizeX = r.SizeX;
	this->SizeY = r.SizeY;
	this->DungeonRegionId = r.DungeonRegionId;
	this->RegionTopography = r.RegionTopography;
	return *this;
}

bool operator == (const FCWRandomDungeonRegionTopography& l, const FCWRandomDungeonRegionTopography& r)
{
	if (l.OriginX == r.OriginX &&
		l.OriginY == r.OriginY &&
		l.SizeX == r.SizeX &&
		l.SizeY == r.SizeY &&
		l.DungeonRegionId == r.DungeonRegionId &&
		l.RegionTopography == r.RegionTopography)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void FCWRandomDungeonRegionTopography::Reset()
{
	this->OriginX = 0;
	this->OriginY = 0;
	this->SizeX = 0;
	this->SizeY = 0;
	this->DungeonRegionId = 0;
	this->RegionTopography = ECWDungeonRegionTopography::None;
}