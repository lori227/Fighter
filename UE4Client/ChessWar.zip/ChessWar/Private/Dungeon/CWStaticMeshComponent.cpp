﻿
#include "CWStaticMeshComponent.h"


UCWStaticMeshComponent::UCWStaticMeshComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWStaticMeshComponent::~UCWStaticMeshComponent()
{
}

void UCWStaticMeshComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UCWStaticMeshComponent::BeginDestroy()
{
	Super::BeginDestroy();
}

/*
void UCWStaticMeshComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}*/

bool UCWStaticMeshComponent::SetStaticMesh(class UStaticMesh* InNewMesh)
{
	if (Super::SetStaticMesh(InNewMesh))
	{
		OnStaticMeshChangedDelegate.Broadcast();
		return true;
	}

	return false;
}

