#include "CWDungeonDataStruct.h"

FCWDungeonDataStruct::FCWDungeonDataStruct()
	: DungeonId(0)
	, DungeonGenerateMode(0)
	, DungeonWidth(0)
	, DungeonHeight(0)
	, DungeonWidthExtension(0)
	, DungeonGridWidth(0)
	, DungeonGridHeight(0)
	, DungeonOffsetX(0)
	, DungeonOffsetY(0)
	, ArraySplitLine()
	, NumOfSplitLine()
	, NumOfPathLine()
	, HighLandGridCountMin(0)
	, LowLandGridCountMin(0)
	, HighLandOrLowLandGridOffsetZ(0.f)
	, bIsAvatarTest(false)
	, DungeonHeightExtension(0)
{
	Style = ECWDungeonRegionStyle::None;
}

FCWDungeonDataStruct::~FCWDungeonDataStruct()
{
}
