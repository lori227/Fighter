#include "CWDungeonDataUtils.h"



std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonZoneNumFromString(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonZoneNum;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDungeonZoneNum.push_back(TempAffect);
	}

	return ArrayDungeonZoneNum;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayNumOfSplitLineFromString(const FString& ParamString)
{
	std::vector<int32> ArrayNumOfSplitLine;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayNumOfSplitLine.push_back(TempAffect);
	}

	return ArrayNumOfSplitLine;
}


std::vector<int32> FCWDungeonDataUtils::GetArrayNumOfPathLineFromString(const FString& ParamString)
{
	std::vector<int32> ArrayNumOfPathLine;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayNumOfPathLine.push_back(TempAffect);
	}

	return ArrayNumOfPathLine;
}

std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayElevationHeightIncrementFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayElevationHeightIncrement;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayElevationHeightIncrement.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayElevationHeightIncrement.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayElevationHeightIncrement;
}

std::vector<std::vector<std::vector<int32>>> FCWDungeonDataUtils::GetArrayArrayArraySplitLineFromString(const FString& ParamString)
{
	std::vector<std::vector<std::vector<int32>>> ArrayArrayArraySplitLine;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayArraySplitLine.push_back(std::vector<std::vector<int32>>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			TArray<FString> strArray3;
			TempString2.ParseIntoArray(strArray3, TEXT("#"), false);
			ArrayArrayArraySplitLine.back().push_back(std::vector<int32>());
			for (TArray<FString>::TConstIterator iter3 = strArray3.CreateConstIterator(); iter3; ++iter3)
			{
				FString TempString3 = *iter3;
				int32 TempSplit = FCString::Atoi(*TempString3);
				ArrayArrayArraySplitLine.back().back().push_back(TempSplit);
			}
		}
	}

	return ArrayArrayArraySplitLine;
}


std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegion;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegion.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegion.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonRegion;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonRegionIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonRegionId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDungeonRegionId.push_back(TempAffect);
	}

	return ArrayDungeonRegionId;
}

std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionRandomMinMax(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionRandomMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionRandomMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionRandomMinMax.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonRegionRandomMinMax;
}

std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionWidthMinMax(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionWidthMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionWidthMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionWidthMinMax.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonRegionWidthMinMax;
}

std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionHeightMinMax(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionHeightMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionHeightMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionHeightMinMax.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonRegionHeightMinMax;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonRegionHasWall(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonRegionHasWall;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDungeonRegionHasWall.push_back(TempAffect);
	}

	return ArrayDungeonRegionHasWall;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonRegionWallDoorCountMinMax(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonRegionWallDoorCountMinMax;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDungeonRegionWallDoorCountMinMax.push_back(TempAffect);
	}

	return ArrayDungeonRegionWallDoorCountMinMax;
}


std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonRegionWallDoorWidthMinMax(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonRegionWallDoorWidthMinMax;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDungeonRegionWallDoorWidthMinMax.push_back(TempAffect);
	}

	return ArrayDungeonRegionWallDoorWidthMinMax;
}

std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonItemGenerateInfoFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonItemGenerateInfo;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonItemGenerateInfo.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonItemGenerateInfo.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonItemGenerateInfo;
}


std::vector<int32> FCWDungeonDataUtils::GetArrayDungeonDecorateTagMinMaxFromString(const FString& ParamString)
{
	std::vector<int32> ArrayDungeonDecorateTagMinMax;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempDungeonDecorateTag = FCString::Atoi(*TempString);
		ArrayDungeonDecorateTagMinMax.push_back(TempDungeonDecorateTag);
	}

	return ArrayDungeonDecorateTagMinMax;
}


std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonPawnStartFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonPawnStart;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonPawnStart.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonPawnStart = FCString::Atoi(*TempString2);
			ArrayArrayDungeonPawnStart.back().push_back(TempDungeonPawnStart);
		}
	}

	return ArrayArrayDungeonPawnStart;
}


std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionHeightFixMinMaxFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionHeightFixMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionHeightFixMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonPawnStart = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionHeightFixMinMax.back().push_back(TempDungeonPawnStart);
		}
	}

	return ArrayArrayDungeonRegionHeightFixMinMax;
}


std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionUpperAreaSideMinMaxFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionUpperAreaSideMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionUpperAreaSideMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonPawnStart = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionUpperAreaSideMinMax.back().push_back(TempDungeonPawnStart);
		}
	}

	return ArrayArrayDungeonRegionUpperAreaSideMinMax;
}


std::vector<std::vector<int32> > FCWDungeonDataUtils::GetArrayArrayDungeonRegionLowerAreaSideMinMaxFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonRegionLowerAreaSideMinMax;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonRegionLowerAreaSideMinMax.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonPawnStart = FCString::Atoi(*TempString2);
			ArrayArrayDungeonRegionLowerAreaSideMinMax.back().push_back(TempDungeonPawnStart);
		}
	}

	return ArrayArrayDungeonRegionLowerAreaSideMinMax;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayHeightPreferFromString(const FString& ParamString)
{
	std::vector<int32> ArrayHeightPrefer;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempDungeonDecorateTag = FCString::Atoi(*TempString);
		ArrayHeightPrefer.push_back(TempDungeonDecorateTag);
	}

	return ArrayHeightPrefer;
}

std::vector<int32> FCWDungeonDataUtils::GetArrayHeightLimitFromString(const FString& ParamString)
{
	std::vector<int32> ArrayHeightLimit;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempDungeonDecorateTag = FCString::Atoi(*TempString);
		ArrayHeightLimit.push_back(TempDungeonDecorateTag);
	}

	return ArrayHeightLimit;
}
