#include "CWDungeonDecorateDataStruct.h"

FCWDungeonDecorateDataStruct::FCWDungeonDecorateDataStruct()
	: FallTime(0.f)
{
}

FCWDungeonDecorateDataStruct::~FCWDungeonDecorateDataStruct()
{
}
