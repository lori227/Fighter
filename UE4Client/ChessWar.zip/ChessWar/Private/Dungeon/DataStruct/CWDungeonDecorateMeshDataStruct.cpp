#include "CWDungeonDecorateMeshDataStruct.h"

FCWDungeonDecorateMeshDataStruct::FCWDungeonDecorateMeshDataStruct()
	: Rotator(FRotator::ZeroRotator)
	, Scale(FVector::OneVector)
	, Offset(FVector::OneVector)
	, Adjacent(ECWDecorateAdjacent::None)
	, bIsUsed(false)
{
	Coord = 0xff;
}

FCWDungeonDecorateMeshDataStruct::~FCWDungeonDecorateMeshDataStruct()
{
}
