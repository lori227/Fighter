#include "CWDungeonDecorateMeshDataUtils.h"


std::vector<int32> CWDungeonDecorateMeshDataUtils::GetArrayDecorateMeshGridRange(const FString& ParamString)
{
	std::vector<int32> ArrayDecorateMeshGridRange;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffect = FCString::Atoi(*TempString);
		ArrayDecorateMeshGridRange.push_back(TempAffect);
	}

	return ArrayDecorateMeshGridRange;
}