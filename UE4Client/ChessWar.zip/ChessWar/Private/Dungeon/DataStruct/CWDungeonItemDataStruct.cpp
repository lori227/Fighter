﻿#include "CWDungeonItemDataStruct.h"

FCWDungeonItemDataStruct::FCWDungeonItemDataStruct()
	: HealthValue(1)
	, OwnElemId(0)
	, ItemType(0)
	, BuffId(0)
	, EffectId(0)
	, IsObstacle(0)
	, CanInteractive(0)
	, NoCollision(0)
	, CanAttack(0)
	, LifespanRound(0)
	, LifespanTime(0.f)
	, ObjLayer(ECWDungeonLogicLayer::None)
	, CreationExclusion(false)
	, ExclusionPriority(0)
{
	bPhyBMovedForce = false;
	bPhyBFallenForce = false;
	PhyLateralFDMG = 0;
	PhyLateralFMove = 0;
	PhyLateralFBuff = 0;
	PhyLateralFEvent = 0;
	PhyVerticalFDMG = 0;
	PhyVerticalFMove = 0;
	PhyVerticalFBuff = 0;
	PhyVerticalFEvent = 0;

	Obstacle = "1|1";
}

FCWDungeonItemDataStruct::~FCWDungeonItemDataStruct()
{
}

FString FCWDungeonItemDataStruct::ToString() const
{
	return FString::Printf(TEXT("\n -> Name[%s] IsObstacle[%d] CanInteractive[%d] CanAttack[%d]"),
		*DungeonItemName, IsObstacle, CanInteractive, CanAttack);
}
