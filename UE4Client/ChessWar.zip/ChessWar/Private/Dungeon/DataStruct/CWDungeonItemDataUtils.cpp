#include "CWDungeonItemDataUtils.h"


std::vector<int32> FCWDungeonItemDataUtils::GetArrayObstacleFromString(const FString& ParamString)
{
	std::vector<int32> ArrayObstacle;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TIterator iter = strArray.CreateIterator(); iter; ++iter)
	{
		float TempFloat = FCString::Atoi(*(*iter));
		ArrayObstacle.push_back(TempFloat);
	}

	return ArrayObstacle;
}