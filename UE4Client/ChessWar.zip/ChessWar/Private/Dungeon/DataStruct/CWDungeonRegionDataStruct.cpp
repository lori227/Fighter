﻿#include "CWDungeonRegionDataStruct.h"

FCWDungeonRegionDataStruct::FCWDungeonRegionDataStruct()
	: DungeonRegionId(0)
{
	IsBasicRegion = 0;
	TerrainDefinceFactor = 0.f;
	Style = ECWDungeonRegionStyle::None;

	Elevation = -1;
	ZoneType = -1;
}

FCWDungeonRegionDataStruct::~FCWDungeonRegionDataStruct()
{
}
