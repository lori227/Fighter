#include "CWDungeonRegionDataUtils.h"


std::vector<FString> FCWDungeonRegionDataUtils::GetArrayDungeonRegionCenterResIdFromString(const FString& ParamString)
{
	std::vector<FString> ArrayDungeonRegionCenterResId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		ArrayDungeonRegionCenterResId.push_back(TempString);
	}

	return ArrayDungeonRegionCenterResId;
}

std::vector<FString> FCWDungeonRegionDataUtils::GetArrayDungeonRegionBorderResIdFromString(const FString& ParamString)
{
	std::vector<FString> ArrayDungeonRegionBorderResId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		ArrayDungeonRegionBorderResId.push_back(TempString);
	}

	return ArrayDungeonRegionBorderResId;
}

std::vector<int32> FCWDungeonRegionDataUtils::GetArrayRegionHeightMinMaxFromString(const FString& ParamString)
{
	std::vector<int32> ArrayRegionHeightMinMax;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TIterator iter = strArray.CreateIterator(); iter; ++iter)
	{
		float TempFloat = FCString::Atoi(*(*iter));
		ArrayRegionHeightMinMax.push_back(TempFloat);
	}

	return ArrayRegionHeightMinMax;
}

std::vector<std::vector<int32> > FCWDungeonRegionDataUtils::GetArrayArrayRegionPassableFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayRegionPassable;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayRegionPassable.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayRegionPassable.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayRegionPassable;
}

std::vector<std::vector<int32> > FCWDungeonRegionDataUtils::GetArrayArrayStandardConsumeMoveFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayStandardConsumeMove;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayStandardConsumeMove.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayStandardConsumeMove.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayStandardConsumeMove;
}

std::vector<std::vector<int32> > FCWDungeonRegionDataUtils::GetArrayArrayIncrementConsumeMoveFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayIncrementConsumeMove;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayIncrementConsumeMove.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayIncrementConsumeMove.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayIncrementConsumeMove;
}

std::vector<float> FCWDungeonRegionDataUtils::GetArrayDungeonItemPobabilityFromString(const FString& ParamString)
{
	std::vector<float> ArrayDungeonItemPobability;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TIterator iter = strArray.CreateIterator(); iter; ++iter)
	{
		float TempFloat = FCString::Atof(*(*iter));
		ArrayDungeonItemPobability.push_back(TempFloat);
	}

	return ArrayDungeonItemPobability;
}

std::vector<std::vector<int32> > FCWDungeonRegionDataUtils::GetArrayArrayDungeonItemFromString(const FString& ParamString)
{
	std::vector<std::vector<int32> > ArrayArrayDungeonItem;
	TArray<FString> strArray1;
	ParamString.ParseIntoArray(strArray1, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter1 = strArray1.CreateConstIterator(); iter1; ++iter1)
	{
		FString TempString1 = *iter1;

		TArray<FString> strArray2;
		TempString1.ParseIntoArray(strArray2, TEXT(":"), false);
		ArrayArrayDungeonItem.push_back(std::vector<int32>());
		for (TArray<FString>::TConstIterator iter2 = strArray2.CreateConstIterator(); iter2; ++iter2)
		{
			FString TempString2 = *iter2;

			int32 TempDungeonRegion = FCString::Atoi(*TempString2);
			ArrayArrayDungeonItem.back().push_back(TempDungeonRegion);
		}
	}

	return ArrayArrayDungeonItem;
}