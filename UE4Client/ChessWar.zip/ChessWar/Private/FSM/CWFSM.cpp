﻿
#include "CWFSM.h"

#include "CWComDef.h"

#include "CWFSMState.h"
#include "CWFSMEvent.h"
#include "CWFSMTranstion.h"
#include "CWFSMTranstionKey.h"
#include "CWFSMStartupEvent.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWFSM, All, All);


UCWFSM::UCWFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWFSM::BeginDestroy()
{
	// clear
	StackStates.clear();
	DestroyAllState();
	DestroyAllTranstion();

	Super::BeginDestroy();
}

UCWFSM::~UCWFSM()
{
	/*StackStates.clear();
	DestroyAllState();
	DestroyAllTranstion();*/
}

bool UCWFSM::AddState(FCWFSMState* ParamFSMState)
{
	check(ParamFSMState);

	if (MapStates.find(ParamFSMState->GetStateId()) == MapStates.end())
	{
		//MapStates.insert(std::make_pair<int, FCWFSMState*>(ParamFSMState->GetStateId(), ParamFSMState));
		int StateId = ParamFSMState->GetStateId();
		MapStates.insert({ StateId, ParamFSMState });
		return true;
	}

	return false;
}

bool UCWFSM::AddTranstion(FCWFSMTranstion* ParamTranstion)
{
	check(ParamTranstion);
	FCWFSMTranstionKey Key(ParamTranstion->GetFromStateId(), ParamTranstion->GetToStateId());
	TranstionMap::iterator iter = MapTranstions.find(Key);
	if (iter == MapTranstions.end())
	{
		MapTranstions.insert({ Key, ParamTranstion });
		return true;
	}

	return false;
}

bool UCWFSM::DoEvent(const FCWFSMEvent* ParamEvent)
{
	check(ParamEvent);
	if (StackStates.size() <= 0)
	{
		CWG_LOG(">> %s::DoEvent fail. StackStates.size() <= 0", *CWG_NAME(this));
		return false;
	}

	FCWFSMState* CurState = StackStates.back();
	check(CurState);
	int FromStateId = CurState->GetStateId();
	if (ParamEvent->ToStateId != (int)ECWPawnInputState::None &&
		FromStateId != ParamEvent->ToStateId)
	{
		StateMap::iterator StateMapIter = MapStates.find(ParamEvent->ToStateId);
		if (StateMapIter == MapStates.end())
		{
			CWG_ERROR(">> %s::DoEvent fail. ToStateId:%d", *CWG_NAME(this), ParamEvent->ToStateId);
			return false;
		}
		FCWFSMState* WantToState = StateMapIter->second;
		check(WantToState);
		int WantToStateId = WantToState->GetStateId();

		FCWFSMTranstionKey Key(FromStateId, WantToStateId);
		TranstionMap::iterator MapTranstionsiter = MapTranstions.find(Key);
		if (MapTranstionsiter == MapTranstions.end())
		{
			CWG_ERROR(">> %s::DoEvent fail. MapTranstions not find, Key.FromStateId:%d, Key.WantToStateId:%d", *CWG_NAME(this), FromStateId, WantToStateId);
			return false;
		}
		
		if (!CurState->CanTranstion(ParamEvent))
		{
			return false;
		}

		CurState->OnExit(ParamEvent);
		switch (ParamEvent->StackOp)
		{
		case ECWFSMStackOp::Set:
		{
			StackStates.clear();
			StackStates.push_back(WantToState);
			break;
		}
		case ECWFSMStackOp::Push:
		{
			StackStates.push_back(WantToState);
			break;
		}
		case ECWFSMStackOp::Pop:
		{
			StackStates.pop_back();
			break;
		}
		default:
			CWG_ERROR(">> %s::DoEvent fail. StackOp:%d", *CWG_NAME(this),(int)ParamEvent->StackOp);
			return false;
			break;
		}

		if (StackStates.empty())
		{
			CWG_ERROR(">> %s::DoEvent fail. StackStates.empty()", *CWG_NAME(this));
			return false;
		}

		FCWFSMState* RealToState = StackStates.back();
		check(RealToState);
		RealToState->OnEnter(ParamEvent);

		//CWG_LOG(">> %s::DoEvent success. StateId:%d", *CWG_Name(this), RealToState->GetStateId());
	}
	else
	{
		CurState->DoEvent(ParamEvent);

		//CWG_LOG(">> %s::DoEvent DoEvent. EventId:%d", *CWG_Name(this), ParamEvent->EventId);
	}

	delete ParamEvent;
	return true;
}

bool UCWFSM::DoNetMessage(const UCWNetMessage* ParamNetMessage)
{
	check(ParamNetMessage);
	if (StackStates.size() <= 0)
	{
		CWG_LOG(">> %s::DoNetMessage fail. StackStates.size() <= 0", *CWG_NAME(this));
		return false;
	}

	FCWFSMState* CurState = StackStates.back();
	check(CurState);
	CurState->DoNetMessage(ParamNetMessage);

	return true;
}

void UCWFSM::Tick(float DeltaTime)
{
	if (GetCurrentState() != nullptr)
	{
		GetCurrentState()->Tick(DeltaTime);
	}
}

bool UCWFSM::Startup(int StateId)
{
	check(StackStates.empty());
	//StackStates.clear();

	StateMap::iterator iterFind = MapStates.find(StateId);
	if (iterFind != MapStates.end())
	{
		FCWFSMState* State = iterFind->second;
		check(State);
		State->OnEnter(new FCWFSMStartupEvent((int)(ECWFSMEvent::Startup), StateId, ECWFSMStackOp::Set));
		StackStates.push_back(iterFind->second);

		//CWG_LOG(">> %s::Startup success.", *CWG_Name(this));
		return true;
	}
	else
	{
		CWG_ERROR(">> %s::Startup fail.", *CWG_NAME(this));
		return false;
	}
}

FCWFSMState* UCWFSM::GetCurrentState()
{
	if (StackStates.empty())
	{
		return nullptr;
	}
	return StackStates.back();
}

int UCWFSM::GetCurrentStateId() const
{
	if (StackStates.empty())
	{
		return 0;
	}
	return StackStates.back()->GetStateId();
}

void UCWFSM::DestroyAllState()
{
	StateMap::iterator iter = MapStates.begin();
	for (; iter != MapStates.end(); ++iter)
	{
		delete iter->second;
	}
	MapStates.clear();
}


void UCWFSM::DestroyAllTranstion()
{
	TranstionMap::iterator iter = MapTranstions.begin();
	for (; iter != MapTranstions.end(); ++iter)
	{
		delete iter->second;
	}
	MapTranstions.clear();
}
