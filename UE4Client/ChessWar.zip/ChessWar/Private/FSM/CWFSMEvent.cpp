
#include "CWFSMEvent.h"

#include "CWCommonUtil.h"


FCWFSMEvent::FCWFSMEvent()
:EventId(0)
,ToStateId(0)
,StackOp(ECWFSMStackOp::None)
{

}

FCWFSMEvent::FCWFSMEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
:EventId(ParamEventId)
,ToStateId(ParamToStateId)
,StackOp(ParamStackOp)
{

}

FCWFSMEvent::~FCWFSMEvent()
{

}

FString FCWFSMEvent::ToString() const
{
	return FString::Printf(TEXT("EventId[%d] ToStateId[%d] StackOp[%s]"), EventId, ToStateId, *FCWCommonUtil::EnumToString(TEXT("ECWFSMStackOp"), StackOp));
}
