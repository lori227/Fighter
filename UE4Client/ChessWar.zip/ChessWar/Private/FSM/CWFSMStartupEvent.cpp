#include "CWFSMStartupEvent.h"


FCWFSMStartupEvent::FCWFSMStartupEvent()
:FCWFSMEvent()
{

}


FCWFSMStartupEvent::FCWFSMStartupEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{

}