#include "CWFSMState.h"
#include "CWFSMEvent.h"

//UCWFSMState::UCWFSMState(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

FCWFSMState::FCWFSMState(UCWFSM* ParamParent, int ParamStateId)
:Parent(ParamParent)
,StateId(ParamStateId)
{

}

FCWFSMState::~FCWFSMState()
{

}

void FCWFSMState::SetParent(UCWFSM* ParamParent)
{
	Parent = ParamParent;
}

bool FCWFSMState::CanTranstion(const FCWFSMEvent* Params)
{
	return true;
}

void FCWFSMState::OnEnter(const FCWFSMEvent* Params)
{

}

void FCWFSMState::OnExit(const FCWFSMEvent* Params)
{

}

void FCWFSMState::DoEvent(const FCWFSMEvent* Params)
{

}

void FCWFSMState::DoNetMessage(const UCWNetMessage* ParamNetMessage)
{

}

void FCWFSMState::Tick(float DeltaTime)
{

}

void FCWFSMState::StateProcess(float DeltaTime)
{

}

int FCWFSMState::GetStateId() const
{
	return StateId;
}