#include "CWFSMTranstion.h"

//UCWFSMTranstion::UCWFSMTranstion(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}

FCWFSMTranstion::FCWFSMTranstion(int ParamFromStateId, int ParamToStateId)
	:FromStateId(ParamFromStateId)
	,ToStateId(ParamToStateId)
{

}


FCWFSMTranstion::~FCWFSMTranstion()
{
	
}


int FCWFSMTranstion::GetFromStateId() const
{
	return FromStateId;
}


int FCWFSMTranstion::GetToStateId() const
{
	return ToStateId;
}