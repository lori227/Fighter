﻿
#include "CWCameraBlockVolume.h"

#include "Components/BoxComponent.h"
#include "Components/ShapeComponent.h"


ACWCameraBlockVolume::ACWCameraBlockVolume(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	static FName CollisionProfileName(TEXT("InvisibleWall"));
	BoxComp->SetCollisionProfileName(CollisionProfileName);
	BoxComp->ShapeColor = FColor(255, 0, 0, 255);
}

ACWCameraBlockVolume::~ACWCameraBlockVolume()
{
}
