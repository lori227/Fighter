﻿
#include "CWCameraMoveVolume.h"

#include "Components/BoxComponent.h"
#include "Components/ShapeComponent.h"


ACWCameraMoveVolume::ACWCameraMoveVolume(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	static FName CollisionProfileName(TEXT("PanCamera"));
	BoxComp->SetCollisionProfileName(CollisionProfileName);
}

ACWCameraMoveVolume::~ACWCameraMoveVolume()
{
}
