﻿
#include "CWCameraPawn.h"

#include "Camera/CameraComponent.h"
#include "Components/InputComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"

#include "CWEventMgr.h"
#include "CWComDef.h"

ACWCameraPawn::ACWCameraPawn()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;

	bHidden = true;
	bReplicates = true;
	bBlockInput = false;

	bCanBeDamaged = false;

	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;
	bUseControllerRotationYaw = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	OriginPos = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("OriginPos"));
	OriginPos->SetGenerateOverlapEvents(false);
	OriginPos->CastShadow = false;
	SetRootComponent(OriginPos);

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArmCompent"));
	SpringArm->bEnableCameraRotationLag = true; // 启用摄像机平滑旋转
	SpringArm->bEnableCameraLag = false;		// 禁用摄像机平滑移动
	SpringArm->bDoCollisionTest = false;
	SpringArm->TargetArmLength = 1000.f;
	SpringArm->SetupAttachment(OriginPos);

	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm);
	//Camera->AttachToComponent(SpringArm, FAttachmentTransformRules::KeepRelativeTransform);

}

void ACWCameraPawn::BeginPlay()
{
	Super::BeginPlay();

#if !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer))
	{
		if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
		{
			Evt_Mgr->OnCameraArmLength.Broadcast(SpringArm->TargetArmLength);
		}
	}
#endif
}

void ACWCameraPawn::ZoomIn()
{
	SpringArm->TargetArmLength = FMath::Clamp(SpringArm->TargetArmLength - CameraZoomDelta, CameraZoomLengthMin, CameraZoomLengthMax);

#if !UE_SERVER
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnCameraArmLength.Broadcast(SpringArm->TargetArmLength);
	}
#endif
}

void ACWCameraPawn::ZoomOut()
{
	SpringArm->TargetArmLength = FMath::Clamp(SpringArm->TargetArmLength + CameraZoomDelta, CameraZoomLengthMin, CameraZoomLengthMax);

#if !UE_SERVER
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnCameraArmLength.Broadcast(SpringArm->TargetArmLength);
	}
#endif
}

bool ACWCameraPawn::SwitchNextViewAngle_Implementation()
{
#if !UE_SERVER
	FRotator rotator = SpringArm->GetComponentTransform().Rotator();
	UCWEventMgr* Evt_Mgr = EVT_MGR(this);
	if (Evt_Mgr) {
		if (FMath::RoundToInt(rotator.Pitch) == -70) {
			Evt_Mgr->OnCameraArmAgree90.Broadcast(true);
		}
		else {
			Evt_Mgr->OnCameraArmAgree90.Broadcast(false);
		}
	}
#endif
	return true;
}
