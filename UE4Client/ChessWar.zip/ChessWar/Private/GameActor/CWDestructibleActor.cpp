﻿
#include "CWDestructibleActor.h"

#include "Engine/CollisionProfile.h"
#include "Public/DestructibleMesh.h"
#include "Public/DestructibleComponent.h"

#include "CWCfgUtils.h"
#include "CWCfgManager.h"


ACWDestructibleActor::ACWDestructibleActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	InitialLifeSpan = 10.0f;

	UDestructibleComponent* DestructibleComp = GetDestructibleComponent();
	if (nullptr != DestructibleComp)
	{
		DestructibleComp->SetCollisionProfileName(UCollisionProfile::CustomCollisionProfileName);
		DestructibleComp->SetCollisionEnabled(ECollisionEnabled::Type::PhysicsOnly);
		DestructibleComp->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);
		DestructibleComp->SetCollisionResponseToChannel(ECC_Visibility, ECR_Ignore);
	}
}

ACWDestructibleActor::~ACWDestructibleActor()
{
}

#if WITH_EDITOR
bool ACWDestructibleActor::GetReferencedContentObjects(TArray<UObject*>& Objects) const
{
	Super::GetReferencedContentObjects(Objects);

	TArray<UActorComponent*> Destructibles = GetComponentsByClass(UDestructibleComponent::StaticClass());
	for (int32 i = 0; i < Destructibles.Num(); ++i)
	{
		UDestructibleComponent* DestructibleComp = Cast<UDestructibleComponent>(Destructibles[i]);
		if (nullptr != DestructibleComp && nullptr != DestructibleComp->SkeletalMesh)
		{
			Objects.Add(DestructibleComp->SkeletalMesh);
		}
	}
	return true;
}
#endif

void ACWDestructibleActor::BeginPlay()
{
	Super::BeginPlay();

	// 设置可破碎组件属性
	TArray<UActorComponent*> Destructibles = GetComponentsByClass(UDestructibleComponent::StaticClass());
	for (int32 i = 0; i < Destructibles.Num(); ++i)
	{
		UDestructibleComponent* DestructibleComp = Cast<UDestructibleComponent>(Destructibles[i]);
		if (nullptr != DestructibleComp)
		{
			DestructibleComp->SetCollisionProfileName(UCollisionProfile::CustomCollisionProfileName);
			DestructibleComp->SetCollisionEnabled(ECollisionEnabled::Type::PhysicsOnly);
			DestructibleComp->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);
			DestructibleComp->SetCollisionResponseToChannel(ECC_Visibility, ECR_Ignore);
		}
	}
}

void ACWDestructibleActor::SimpleAllDestructible()
{
	TArray<UActorComponent*> Destructibles = GetComponentsByClass(UDestructibleComponent::StaticClass());
	for (int32 i = 0; i < Destructibles.Num(); ++i)
	{
		UDestructibleComponent* DestructibleComp = Cast<UDestructibleComponent>(Destructibles[i]);
		if (nullptr != DestructibleComp)
		{
			ApplyDamage(DestructibleComp, 1.f);
		}
	}
}

void ACWDestructibleActor::SimpleDestructible()
{
	UDestructibleComponent* DestructibleComp = GetDestructibleComponent();
	if (nullptr != DestructibleComp)
	{
		ApplyDamageDestructible(DestructibleComp, 1.f, GetActorLocation(), GetActorLocation().GetSafeNormal(), 1.f);
	}
}

void ACWDestructibleActor::SimpleDestructibleMesh(UDestructibleComponent* InDestructibleComp)
{
	if (nullptr != InDestructibleComp)
	{
		ApplyDamage(InDestructibleComp, 1.f);
	}
}

void ACWDestructibleActor::SetDestructibleMesh(UDestructibleComponent* InDestructibleComp, const FString& InAssetId)
{
	if (nullptr != InDestructibleComp && !InAssetId.IsEmpty())
	{
		UDestructibleMesh* NewMesh = FCWCfgUtils::GetMeshAssetObject<UDestructibleMesh>(InDestructibleComp, InAssetId);
		InDestructibleComp->SetDestructibleMesh(NewMesh);
	}
}

void ACWDestructibleActor::ApplyDamage(UDestructibleComponent* InDestructibleComp, float DamageAmount)
{
	if (nullptr != InDestructibleComp)
	{
		const FVector& HitLocation = InDestructibleComp->GetComponentLocation();
		const FVector& ImpulseDir = HitLocation.GetSafeNormal();
		float ImpulseStrength = 1.f;

		ApplyDamageDestructible(InDestructibleComp, DamageAmount, HitLocation, ImpulseDir, ImpulseStrength);
	}
}

void ACWDestructibleActor::ApplyDamageDestructible(UDestructibleComponent* InDestructibleComp, float DamageAmount, const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength)
{
	if (nullptr != InDestructibleComp)
	{
		InDestructibleComp->ApplyDamage(DamageAmount, HitLocation, ImpulseDir, ImpulseStrength);

		InDestructibleComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		InDestructibleComp->SetCollisionResponseToAllChannels(ECR_Ignore);
	}
}
