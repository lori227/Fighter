﻿
#include "CWEffectWater.h"

#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"


ACWEffectWater::ACWEffectWater(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	WaterSurface = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WaterSurface"));
	WaterSurface->CastShadow = false;
	SetRootComponent(WaterSurface);

	WaterScaleX = 5.f;
	WaterScaleY = 5.f;
}

void ACWEffectWater::BeginPlay()
{
	Super::BeginPlay();

	InitialWaterCreation();
	UpdateWaterMaterialData();
}

#if WITH_EDITOR

void ACWEffectWater::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	const FName& EventName = PropertyChangedEvent.GetPropertyName();

	InitialWaterCreation();
	UpdateWaterMaterialData();
}

#endif

void ACWEffectWater::SetWaterWaterDepth(const float InHeightValue)
{
	// InHeightValue - InShoreDepth
	//		-140	 - 500
	//		-70		 - 150
	//		0		 - 0
	//		1		 - -1

	float InShoreDepth = 0;
	if (InHeightValue > 0.1f)
	{
		InShoreDepth = -1;
	}else if (InHeightValue == 0.f)
	{
		InShoreDepth = 0;
	}else if (InHeightValue < -0.1f && InHeightValue >= -70.f)
	{
		InShoreDepth = (-InHeightValue / 70.f) * (150.f);
	}else if (InHeightValue < -70.f && InHeightValue >= -140.f)
	{
		InShoreDepth = ((-InHeightValue - 70) / 70.f) * (500.f - 150.f);
	}

	SetWaterShoreDepth(InShoreDepth);
}

void ACWEffectWater::InitialWaterCreation()
{
	WaterSurface->SetRelativeScale3D(FVector(WaterScaleX, WaterScaleY, 1.f));
	WaterMaterial = WaterSurface->CreateDynamicMaterialInstance(0, OceanMaterial);

	// 水高度
	if (nullptr != WaterSurface && nullptr != WaterMaterial)
	{
		const float WorldLocZ = WaterSurface->GetComponentLocation().Z;
		WaterMaterial->SetScalarParameterValue(FName("Water Height"), WorldLocZ);
	}
}

void ACWEffectWater::UpdateWaterMaterialData()
{

}

void ACWEffectWater::SetWaterShoreDepth_Implementation(const float InShoreDepth)
{
}
