﻿
#include "CWEffectWaterImpl.h"

#include "CWComDef.h"


ACWEffectWaterImpl::ACWEffectWaterImpl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

ACWEffectWaterImpl::~ACWEffectWaterImpl()
{
}

void ACWEffectWaterImpl::Destroyed()
{
	Super::Destroyed();
}

#if WITH_EDITOR

void ACWEffectWaterImpl::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif

bool ACWEffectWaterImpl::SetWaterDepth(const float InHeightValue)
{
	FVector NewLoc(GetActorLocation());
	NewLoc.Z = InHeightValue;
	SetActorLocation(NewLoc);
	return true;
}

int32 ACWEffectWaterImpl::SetTileNumber(const int32 InNumber)
{
	TileNumber = InNumber;
	return TileNumber;
}

int32 ACWEffectWaterImpl::GetTileNumber()
{
	return TileNumber;
}

bool ACWEffectWaterImpl::SetWaterSize_Implementation(const FVector2D& InSize)
{
	return true;
}
