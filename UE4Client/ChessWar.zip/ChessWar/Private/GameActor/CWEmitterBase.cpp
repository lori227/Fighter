
#include "CWEmitterBase.h"


ACWEmitterBase::ACWEmitterBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}