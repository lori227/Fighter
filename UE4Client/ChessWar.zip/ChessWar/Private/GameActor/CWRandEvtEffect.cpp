﻿
#include "CWRandEvtEffect.h"

#include "CWDungeonItem.h"


ACWRandEvtEffect::ACWRandEvtEffect(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.bAllowTickOnDedicatedServer = false;

	bReplicates = true;

	// 最大存留时间
	InitialLifeSpan = 15.f;
}

ACWRandEvtEffect::~ACWRandEvtEffect()
{
}

bool ACWRandEvtEffect::InitInServer(const FCWRandomEvtGameData& InRandomEvtData)
{
	return true;
}

void ACWRandEvtEffect::OnToggleDamageEvent(int32 InPhase)
{
	if (!IsNetMode(NM_Client) && !bToggleDamage)
	{
		bToggleDamage = true;
		OnToggleDamage.Broadcast(InPhase);
	}

}
