
#include "CWSimpleActor.h"

#include "Public/TimerManager.h"

#include "CWComDef.h"


ACWSimpleActor::ACWSimpleActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = false;
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bTickEvenWhenPaused = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	RootComponent = CreateDefaultSubobject<USceneComponent>("RootComp");
}

ACWSimpleActor::~ACWSimpleActor()
{
}

void ACWSimpleActor::Destroyed()
{
	// Cleanup
	//GetWorldTimerManager().ClearAllTimersForObject(this);
	FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);

	Super::Destroyed();
}

void ACWSimpleActor::SetSimpleFlag(const FString& InFlag)
{
	SimpleFlag = InFlag;
}

FString ACWSimpleActor::GetSimpleFlag()
{
	return SimpleFlag;
}

bool ACWSimpleActor::StartUpdateLoctionZ(const float InBeginZ, const float InEndZ, const float InSpeed)
{
	//check(InBeginHeight != InEndHeight);

	if (FMath::IsNearlyEqual(InBeginZ, InEndZ))
	{
		FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
		SetActorLocationZ(InBeginZ);
		return true;
	}

	TargetLocZ.X = InBeginZ;
	TargetLocZ.Y = InEndZ;
	TargetLocZSpeed = InSpeed;

	/*FTimerHandle TimerHandle;
	auto UpdateWaterDepth = [this]()
	{
		float NewZ = GetActorLocation().Z;
		const float NewDelta = 10.f * UpdateWaterRate;
		NewZ += (TargetLocZ.X > TargetLocZ.Y) ? -NewDelta : NewDelta;
		bool bIsFinished = (TargetLocZ.X > TargetLocZ.Y && NewZ <= TargetLocZ.Y);
		bIsFinished |= (TargetLocZ.X < TargetLocZ.Y && NewZ >= TargetLocZ.Y);
		if (bIsFinished)
		{
			NewZ = TargetLocZ.Y;
			GetWorldTimerManager().ClearAllTimersForObject(this);
			CWG_WARNING(">> %s::UpdateWaterDepth, Finished. NewZ[%f].", *GetName(), NewZ);
		}
		SetWaterDepth(NewZ);
	};
	GetWorldTimerManager().SetTimer(TimerHandle, UpdateWaterDepth, UpdateWaterRate, true);*/

	/*auto UpdateWaterDepth = [this](float DeltaTime) -> bool
	{
		if (!IsValid(this))
		{
			FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
			return false;
		}

		float NewZValue = GetActorLocation().Z;
		const float NewDelta = TargetLocZSpeed * DeltaTime;
		NewZValue += (TargetLocZ.Y > TargetLocZ.X) ? NewDelta : -NewDelta;
		bool bIsFinished = (TargetLocZ.Y > TargetLocZ.X && NewZValue >= TargetLocZ.Y);
		bIsFinished |= (TargetLocZ.Y < TargetLocZ.X && NewZValue <= TargetLocZ.Y);
		if (bIsFinished)
		{
			NewZValue = TargetLocZ.Y;
			FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
			CWG_WARNING(">> %s::UpdateWaterDepth, Finished. NewZ[%f].", *GetName(), NewZValue);
		}
		SetActorLocationZ(NewZValue);
		return true;
	};*/

	FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
	//FTickerDelegate OnTickDel = FTickerDelegate::CreateLambda(UpdateWaterDepth);
	FTickerDelegate OnTickDel = FTickerDelegate::CreateUObject(this, &ACWSimpleActor::OnUpdateLoctionZ);
	TickDelegateHandle = FTicker::GetCoreTicker().AddTicker(OnTickDel);

	return true;
}

bool ACWSimpleActor::OnUpdateLoctionZ(float DeltaTime)
{
	if (IsPendingKill())
	{
		FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
		return false;
	}

	float NewZValue = GetActorLocation().Z;
	const float NewDelta = TargetLocZSpeed * DeltaTime;
	NewZValue += (TargetLocZ.Y > TargetLocZ.X) ? NewDelta : -NewDelta;
	bool bIsFinished = (TargetLocZ.Y > TargetLocZ.X && NewZValue >= TargetLocZ.Y);
	bIsFinished |= (TargetLocZ.Y < TargetLocZ.X && NewZValue <= TargetLocZ.Y);
	if (bIsFinished)
	{
		NewZValue = TargetLocZ.Y;
		FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);
		CWG_WARNING(">> %s::OnUpdateLoctionZ, Finished. NewZ[%f].", *GetName(), NewZValue);
	}
	SetActorLocationZ(NewZValue);
	return true;
}

void ACWSimpleActor::SetActorLocationZ(const float InZValue)
{
	FVector NewLocation(GetActorLocation());
	NewLocation.Z = InZValue;
	SetActorLocation(NewLocation);
}

float ACWSimpleActor::GetActorLocationZ()
{
	return GetActorLocation().Z;
}

