
#include "CWSkeletalMeshActor.h"

#include "Animation/AnimInstance.h"
#include "Engine/CollisionProfile.h"
#include "Components/SplineComponent.h"
#include "Components/SplineMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"

#include "CWComDef.h"
#include "CWCfgUtils.h"


ACWSkeletalMeshActor::ACWSkeletalMeshActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bTickEvenWhenPaused = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	USkeletalMeshComponent* SKMeshComp = GetSkeletalMeshComponent();
	if (nullptr != SKMeshComp)
	{
		SKMeshComp->SetEnableGravity(false);
		SKMeshComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		SKMeshComp->SetCollisionResponseToAllChannels(ECR_Ignore);
		SKMeshComp->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	}
}

ACWSkeletalMeshActor::~ACWSkeletalMeshActor()
{
}

void ACWSkeletalMeshActor::BeginPlay()
{
	Super::BeginPlay();

	InitRelativePoint = RootComponent->RelativeLocation;
}

void ACWSkeletalMeshActor::Destroyed()
{
	Super::Destroyed();
}

bool ACWSkeletalMeshActor::PlayAnimSequence(const FString& InSMId, const FString& InAnimInstClassId, const FString& InAnimId)
{
	USkeletalMeshComponent* SKMeshComp = GetSkeletalMeshComponent();
	if (nullptr != SKMeshComp && !InSMId.IsEmpty())
	{
		if (CurSMAssetId == InSMId && nullptr != SKMeshComp->SkeletalMesh)
		{
			return true;
		}

		USkeletalMesh* NewSkeletalMesh = FCWCfgUtils::GetPawnAssetObject<USkeletalMesh>(this, InSMId);
		if (nullptr != NewSkeletalMesh)
		{
			CurSMAssetId = InSMId;
			//SKMeshComp->ClearAnimScriptInstance();
			//SKMeshComp->SetSkeletalMesh(nullptr);
			SKMeshComp->SetSkeletalMesh(NewSkeletalMesh);

			// DragonKnight: FVector(150, -60, -230)
			// Knight:		 FVector(80, 0, -200)
			FVector InRelativePoint = GetOverrideRelativePoint(InSMId);
			SetActorRelativeLocation(InRelativePoint);

			// AnimInstClass
			UClass* NewAnimInstClass = FCWCfgUtils::GetPawnAssetClass(this, InAnimInstClassId);
			if (nullptr != NewAnimInstClass)
			{
				SKMeshComp->SetAnimInstanceClass(NewAnimInstClass);
				//SKMeshComp->SetAnimationMode(EAnimationMode::AnimationBlueprint);
			}
			else
			{
				SKMeshComp->SetAnimationMode(EAnimationMode::AnimationSingleNode);
			}

			// Play Anim
			const EAnimationMode::Type PlayMode = SKMeshComp->GetAnimationMode();
			UAnimSequence* NewAnimToPlay = FCWCfgUtils::GetPawnAssetObject<UAnimSequence>(this, InAnimId);
			if (nullptr != NewAnimToPlay)
			{
				if (PlayMode == EAnimationMode::Type::AnimationSingleNode)
				{
					SKMeshComp->PlayAnimation(NewAnimToPlay, true);
					return true;
				}
				else if (PlayMode == EAnimationMode::Type::AnimationBlueprint)
				{
					UAnimInstance* AnimInstance = SKMeshComp->GetAnimInstance();
					if (nullptr != AnimInstance)
					{
						//AnimInstance->PlaySlotAnimationAsDynamicMontage(NewAnimToPlay, TEXT("DefaultSlot"), 0.25f, 0.25f, 1.0f, 1000000/*BIG_NUMBER*/);
						AnimInstance->PlaySlotAnimationAsDynamicMontage(NewAnimToPlay, TEXT("DefaultSlot"), 0.f, 0.f, 1.0f, 1000000/*BIG_NUMBER*/);
						return true;
					}
				}
			}
		}
	}
	CWG_WARNING(">> %s::PlayAnimSequence, Fail! InSMId[%s] InAnimInstClassId[%s] InAnimId[%s].", *GetName(), *InSMId, *InAnimInstClassId, *InAnimId);
	return false;
}

FVector ACWSkeletalMeshActor::GetOverrideRelativePoint(const FString& InSMKey)
{
	FVector OutRelativePoint = InitRelativePoint;
	if (!InSMKey.IsEmpty())
	{
		if (const FVector* FindPoint = RelativePointMap.Find(InSMKey))
		{
			OutRelativePoint = RelativePointMap.FindRef(InSMKey);
		}
	}
	return OutRelativePoint;
}
