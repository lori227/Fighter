
#include "CWSpectatorPawn.h"

#include "Engine/CollisionProfile.h"
#include "Components/InputComponent.h"
#include "Components/SphereComponent.h"
#include "GameFramework/SpectatorPawnMovement.h"

#include "CWCameraComp.h"


ACWSpectatorPawn::ACWSpectatorPawn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<USpectatorPawnMovement>(Super::MovementComponentName))
{
	GetCollisionComponent()->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	bAddDefaultMovementBindings = false;
	CWCameraComp = CreateDefaultSubobject<UCWCameraComp>(TEXT("CWCameraComp"));
}

void ACWSpectatorPawn::OnMouseScrollUp()
{
	CWCameraComp->OnZoomIn();
}

void ACWSpectatorPawn::OnMouseScrollDown()
{
	CWCameraComp->OnZoomOut();
}


void ACWSpectatorPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	check(PlayerInputComponent);
	
	PlayerInputComponent->BindAction("ZoomOut", IE_Pressed, this, &ACWSpectatorPawn::OnMouseScrollUp);
	PlayerInputComponent->BindAction("ZoomIn", IE_Pressed, this, &ACWSpectatorPawn::OnMouseScrollDown);

	PlayerInputComponent->BindAxis("MoveForward", this, &ACWSpectatorPawn::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &ACWSpectatorPawn::MoveRight);
}


void ACWSpectatorPawn::MoveForward(float Val)
{
	CWCameraComp->MoveForward( Val );
}


void ACWSpectatorPawn::MoveRight(float Val)
{
	CWCameraComp->MoveRight( Val );
}

UCWCameraComp* ACWSpectatorPawn::GetCWCameraComp()
{
	check( CWCameraComp != nullptr );
	return CWCameraComp;
}

