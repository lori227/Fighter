
#include "CWSplineActor.h"

#include "Engine/CollisionProfile.h"
#include "Components/SplineComponent.h"
#include "Components/SplineMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Particles/ParticleSystemComponent.h"

#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWAssetDefine.h"
#include "CWClientConstData.h"


ACWSplineActor::ACWSplineActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = false;
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bTickEvenWhenPaused = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	RootComponent = CreateDefaultSubobject<USceneComponent>("RootComp");

	ArriveTangent = FVector::ZeroVector;
	LeaveTangent = FVector(15.f, 0.f, 0.f);

	NewStartScale = NewEndScale = /*FVector2D(0.2f, 0.2f)*/FVector2D(1.f, 1.f);
	NewStartPosition = FVector::ZeroVector;
	NewStartTangent = NewEndPosition = NewEndTangent = FVector(100.f, 0.f, 0.f);
}

ACWSplineActor::~ACWSplineActor()
{
}

void ACWSplineActor::Destroyed()
{
	// Cleanup

	Super::Destroyed();
}

USplineComponent* ACWSplineActor::SetSplineWorldPoints(const int32 InSplineIndex,
	const TArray<FVector>& InPoints, const ECWSplineMeshType InMeshType, const bool bSetTangent)
{
	USplineComponent* RetComp = TryGetSplineComponent(InSplineIndex);
	check(RetComp && TEXT(">> SplineComponent is nullptr!"));

	// Update Points
	RetComp->SetSplineWorldPoints(InPoints);

	// Update Tangent
	if (bSetTangent)
	{
		const int32 SplinePoint = RetComp->GetNumberOfSplinePoints();
		for (int32 i = 0; i < SplinePoint; ++i)
		{
			RetComp->SetTangentsAtSplinePoint(i, ArriveTangent, LeaveTangent, ESplineCoordinateSpace::World);
		}
	}

	// Update Scale
	const FString& SplineMeshScaleKey = FString::Printf(TEXT("SplineMeshScale_%d"), (int32)InMeshType);
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, SplineMeshScaleKey))
	{
		const float ConstScale = FSTRING_TO_FLOAT(ConstData->Param);
		const FVector2D NewScale = FVector2D(ConstScale, ConstScale);
		SetSplineMeshScale(NewScale, NewScale);
	}

	// Update Mesh
	UpdateSplineCompMesh(RetComp, (int32)InMeshType);

	return RetComp;
}

USplineComponent* ACWSplineActor::SetSplineWorldPointsImpl(const int32 InSplineIndex,
	const TArray<FVector>& InPoints, const ECWSplineMeshType InMeshType)
{
	USplineComponent* RetComp = TryGetSplineComponent(InSplineIndex);
	check(RetComp && TEXT(">> SplineComponent is nullptr!"));

	// Optimize Points
	if (InPoints.Num() >= 3)
	{
		TArray<FVector> InNewPoints;
		TArray<FVector> InArriveTangents;
		TArray<FVector> InLeaveTangents;
		const FVector MinTangent = /*FVector::ZeroVector;*/FVector(1.5, 1.5, 1.5f);

		// The Start Point
		InNewPoints.Add(InPoints[0]);
		InArriveTangents.Add(/*ArriveTangent*/MinTangent);
		InLeaveTangents.Add(/*LeaveTangent*/MinTangent);

		const int32 InPointNum = InPoints.Num();
		for (int32 i = 1; i < InPointNum - 1; ++i)
		{
			const FVector PrePoint = InPoints[i - 1];
			const FVector CurPoint = InPoints[i];
			const FVector NextPoint = InPoints[i + 1];
			const float PreToCurDist = FVector::Distance(PrePoint, CurPoint);
			const float CurToNextDist = FVector::Distance(CurPoint, NextPoint);
			const float PreToNextDist = FVector::Distance(PrePoint, NextPoint);
			const float AB = PreToCurDist * PreToCurDist + CurToNextDist * CurToNextDist;
			const float AC = PreToNextDist * PreToNextDist;
			//CWG_WARNING("-> InPrePoint[%s] InCurPoint[%s] InNextPoint[%s] AB[%f]_AC[%f].", *PrePoint.ToString(), *CurPoint.ToString(), *NextPoint.ToString(), AB, AC);

			if (!FMath::IsNearlyEqual(AB, AC, 1.f) || 
				PreToCurDist <= 5.f || CurToNextDist <= 5.f)
			{
				InNewPoints.Add(CurPoint);
				InArriveTangents.Add(/*ArriveTangent*/FVector::ZeroVector);
				InLeaveTangents.Add(/*LeaveTangent*/FVector::ZeroVector);
				continue;
			}
			// First Point
			const float Offset0 = FMath::Min(PreToCurDist, 20.f) / 2;
			const float Tangent0 = Offset0 * 2.f;
			FVector CtPDirUnit = (PrePoint - CurPoint); CtPDirUnit.Normalize();
			const FVector NewPoint0 = CurPoint + CtPDirUnit * Offset0;
			const FVector NewTangent0 = -CtPDirUnit * Tangent0;
			InNewPoints.Add(NewPoint0);
			InArriveTangents.Add(NewTangent0);
			InLeaveTangents.Add(NewTangent0 + CheckNeedOffserXY(CtPDirUnit));
			//CWG_LOG(">> +++ CtPDir[%s] Normalize... NewPoint0[%s] NewTangent0[%s]", *CtPDirUnit.ToString(), *NewPoint0.ToString(), *NewTangent0.ToString());

			// Second Point
			const float Offset1 = FMath::Min(CurToNextDist, 20.f) / 2;
			const float Tangent1 = Offset1 * 2.f;
			FVector CtNDirUnit = (NextPoint - CurPoint); CtNDirUnit.Normalize();
			const FVector NewPoint1 = CurPoint + CtNDirUnit * Offset1;
			const FVector NewTangent1 = CtNDirUnit * Tangent1;
			InNewPoints.Add(NewPoint1);
			InArriveTangents.Add(NewTangent1);
			InLeaveTangents.Add(NewTangent1 + CheckNeedOffserXY(CtNDirUnit));
			//CWG_LOG(">> +++ CtNDir[%s] Normalize... NewPoint1[%s] NewTangent1[%s]", *CtNDirUnit.ToString(), *NewPoint1.ToString(), *NewTangent1.ToString());
		}
		// The End Point
		InNewPoints.Add(InPoints[InPointNum - 1]);
		InArriveTangents.Add(/*ArriveTangent*/MinTangent);
		InLeaveTangents.Add(/*LeaveTangent*/MinTangent);

		// Update Points
		RetComp->SetSplineWorldPoints(InNewPoints);
		const int32 SplinePoint = RetComp->GetNumberOfSplinePoints();
		if (InNewPoints.Num() == SplinePoint && SplinePoint == InArriveTangents.Num() && InLeaveTangents.Num() == InArriveTangents.Num())
		{
			CWG_LOG(">> Log: SplinePoint[%d].", SplinePoint);
			for (int32 i = 0; i < SplinePoint; ++i)
			{
				RetComp->SetTangentsAtSplinePoint(i, InArriveTangents[i], InLeaveTangents[i], ESplineCoordinateSpace::World);
			}
		}
		else
		{
			CWG_ERROR(">> ERROR: InNewPoints[%d] SplinePoint[%d] InArriveTangents[%d] InLeaveTangents[%d].", InNewPoints.Num(), SplinePoint, InArriveTangents.Num(), InLeaveTangents.Num());
		}
	}
	else
	{
		// Update Points
		RetComp->SetSplineWorldPoints(InPoints);
	}

	// Update Scale
	const FString& SplineMeshScaleKey = FString::Printf(TEXT("SplineMeshScale_%d"), (int32)InMeshType);
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, SplineMeshScaleKey))
	{
		const float ConstScale = FSTRING_TO_FLOAT(ConstData->Param);
		const FVector2D NewScale = FVector2D(ConstScale, ConstScale);
		SetSplineMeshScale(NewScale, NewScale);
	}

	// Update Mesh
	UpdateSplineCompMesh(RetComp, (int32)InMeshType);

	return RetComp;
}

void ACWSplineActor::SetSplineMeshScale(const FVector2D& InStartScale, const FVector2D& InEndScale)
{
	NewStartScale = InStartScale;
	NewEndScale = InEndScale;
}

void ACWSplineActor::SetSplineMeshPosTangent(const FVector& InStartPosition, const FVector& InStartTangent, const FVector& InEndPosition, const FVector& InEndTangent)
{
	NewStartPosition = InStartPosition;
	NewStartTangent = InStartTangent;
	NewEndPosition = InEndPosition;
	NewEndTangent = InEndTangent;
}

void ACWSplineActor::ClearSplinePoints(const int32 InSplineIndex)
{
	USplineComponent* MySplineComp = GetSplineComponent(InSplineIndex);
	if (nullptr != MySplineComp)
	{
		MySplineComp->ClearSplinePoints(true);
	}
}

void ACWSplineActor::DestroySplineComponent(const int32 InSplineIndex)
{
	USplineComponent* MySplineComp = GetSplineComponent(InSplineIndex);
	if (SplineComps.IsValidIndex(InSplineIndex))
	{
		SplineComps[InSplineIndex] = nullptr;
	}
	if (nullptr != MySplineComp)
	{
		MySplineComp->DestroyComponent(/*true*/);
	}
}

void ACWSplineActor::DestroyAllComponent()
{
	TArray<USceneComponent*> AllComps;
	GetComponents<USceneComponent>(AllComps, true);
	for (int32 i = 0; i < AllComps.Num(); ++i)
	{
		USceneComponent* MyComponent = AllComps[i];
		if (nullptr != MyComponent && MyComponent != RootComponent)
		{
			MyComponent->DestroyComponent(/*true*/);
		}
	}
	SplineComps.Empty();
	SplineMeshComps.Empty();
	ParticleComps.Empty();
}

USplineComponent* ACWSplineActor::CreateSplineComponent(const int32 InSplineIndex)
{
	USplineComponent* NewSplineComponent = NewObject<USplineComponent>(this);
	check(NewSplineComponent);

	NewSplineComponent->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	NewSplineComponent->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
	NewSplineComponent->Mobility = EComponentMobility::Movable;
	NewSplineComponent->SetGenerateOverlapEvents(false);
	//NewSplineComponent->bAllowDiscontinuousSpline = true;

	AddOwnedComponent(NewSplineComponent);
	NewSplineComponent->RegisterComponent();
	NewSplineComponent->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	SplineComps.Insert_GetRef(NewSplineComponent, InSplineIndex);
	return NewSplineComponent;
}

USplineComponent* ACWSplineActor::GetSplineComponent(const int32 InSplineIndex)
{
	return SplineComps.IsValidIndex(InSplineIndex) ? SplineComps[InSplineIndex] : nullptr;
}

USplineComponent* ACWSplineActor::TryGetSplineComponent(const int32 InSplineIndex)
{
	USplineComponent* RetComp = GetSplineComponent(InSplineIndex);
	if (nullptr == RetComp)
	{
		RetComp = CreateSplineComponent(InSplineIndex);
	}
	return RetComp;
}

USplineMeshComponent* ACWSplineActor::CreateSplineMeshComponent(USplineComponent* InSplineComponent, UStaticMesh* InStaticMesh)
{
	USplineMeshComponent* SplineMeshComp = NewObject<USplineMeshComponent>(InSplineComponent);
	if (nullptr != SplineMeshComp)
	{
		SplineMeshComp->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
		SplineMeshComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
		SplineMeshComp->Mobility = EComponentMobility::Movable;
		SplineMeshComp->SetGenerateOverlapEvents(false);
		SplineMeshComp->bAllowSplineEditingPerInstance = true;
		SplineMeshComp->SetEnableGravity(false);
		SplineMeshComp->SetCastShadow(false);

		//SplineMeshComp->bStationaryEndpoints;
		SplineMeshComp->SetStartPosition(NewStartPosition);
		SplineMeshComp->SetStartTangent(NewStartTangent);
		SplineMeshComp->SetEndPosition(NewEndPosition);
		SplineMeshComp->SetEndTangent(NewEndTangent);
		SplineMeshComp->SetForwardAxis(ESplineMeshAxis::Type::Z);
		SplineMeshComp->SetStartScale(NewStartScale);
		SplineMeshComp->SetEndScale(NewEndScale);

		AddOwnedComponent(SplineMeshComp);
		SplineMeshComp->RegisterComponent();
		SplineMeshComp->AttachToComponent(InSplineComponent, FAttachmentTransformRules(EAttachmentRule::KeepRelative, false/*true*/));
		SplineMeshComp->SetStaticMesh(InStaticMesh);

		SplineMeshComps.AddUnique(SplineMeshComp);
	}

	return SplineMeshComp;
}

FVector ACWSplineActor::CheckNeedOffserXY(const FVector& InVector)
{
	if (/*InVector.IsUnit() && */(InVector.Equals(FVector::UpVector) || InVector.Equals(-FVector::UpVector)))
	{
		return FVector(0.f, 0.1f, 0.f);
	}
	return FVector::ZeroVector;
}

bool ACWSplineActor::IsEqual2(ESplineMeshAxis::Type InType, const FVector& InPointL, const FVector& InPointR)
{
	switch (InType)
	{
	case ESplineMeshAxis::X: return FMath::IsNearlyEqual(InPointL.X, InPointR.X);
	case ESplineMeshAxis::Y: return FMath::IsNearlyEqual(InPointL.Y, InPointR.Y);
	case ESplineMeshAxis::Z: return FMath::IsNearlyEqual(InPointL.Z, InPointR.Z);
	}
	return false;
}

bool ACWSplineActor::IsEqual3(ESplineMeshAxis::Type InType, const FVector& InPrePoint, const FVector& InCurPoint, const FVector& InNextPoint)
{
	switch (InType)
	{
	case ESplineMeshAxis::X: return FMath::IsNearlyEqual(InPrePoint.X, InCurPoint.X) && FMath::IsNearlyEqual(InCurPoint.X, InNextPoint.X);
	case ESplineMeshAxis::Y: return FMath::IsNearlyEqual(InPrePoint.Y, InCurPoint.Y) && FMath::IsNearlyEqual(InCurPoint.Y, InNextPoint.Y);
	case ESplineMeshAxis::Z: return FMath::IsNearlyEqual(InPrePoint.Z, InCurPoint.Z) && FMath::IsNearlyEqual(InCurPoint.Z, InNextPoint.Z);
	}
	return false;
};

bool ACWSplineActor::IsRightAngle(const FVector& InPrePoint, const FVector& InCurPoint, const FVector& InNextPoint)
{
	const float PreToCurDist = FVector::Distance(InPrePoint, InCurPoint);
	const float CurToNextDist = FVector::Distance(InCurPoint, InNextPoint);
	const float PreToNextDist = FVector::Distance(InPrePoint, InNextPoint);
	const float AB = PreToCurDist * PreToCurDist + CurToNextDist * CurToNextDist;
	const float AC = PreToNextDist * PreToNextDist;

	CWG_WARNING("--> InPrePoint[%s] InCurPoint[%s] InNextPoint[%s] AB[%f]_AC[%f].", *InPrePoint.ToString(), *InCurPoint.ToString(), *InNextPoint.ToString(), AB, AC);
	return FMath::IsNearlyEqual(AB, AC, 1.f);
}

bool ACWSplineActor::UpdateParticleTargetLocation_Implementation(UParticleSystemComponent* InParticleComp, const FVector& InTargteLocation)
{
	// TODO:
	return true;
}

void ACWSplineActor::UpdateSplineCompMesh(USplineComponent* InSplineComponent, const int32 InMeshType /*= 0*/)
{
	if (nullptr == InSplineComponent)
	{
		CWG_WARNING(">> CWSplineActor::UpdateSplineCompMesh, InSplineComponent is nullptr! InMeshType[%d].", InMeshType);
		return;
	}

	const FString& SplineMeshKey = FString::Printf(TEXT("SplineMesh_%d"), InMeshType);
	const FString& SplineMaterialKey = FString::Printf(TEXT("SplineMaterial_%d"), InMeshType);
	UStaticMesh* SplineMesh = FCWCfgUtils::GetAssetObject<UStaticMesh>(this, SplineMeshKey);
	UMaterialInterface* SplineMaterial = FCWCfgUtils::GetAssetObject<UMaterialInterface>(this, SplineMaterialKey);
	if (nullptr == SplineMesh)
	{
		CWG_WARNING(">> CWSplineActor::UpdateSplineCompMesh, SplineMesh is nullptr! SplineMeshKey[%s].", *SplineMeshKey);
		return;
	}

	const int32 SplinePointNum = InSplineComponent->GetNumberOfSplinePoints();
	for (int32 i = 0; i < SplinePointNum - 1; ++i)
	{
		USplineMeshComponent* SplineMeshComp = CreateSplineMeshComponent(InSplineComponent, SplineMesh);
		if (nullptr != SplineMeshComp)
		{
			if (nullptr != SplineMaterial)
			{
				//CWG_LOG(">> %s::UpdateSplineCompMesh, override SplineMaterial[%s] Ok~", *GetName(), *CWG_NAME(SplineMaterial));
				//SplineMeshComp->SetMaterial(0, SplineMaterial);
				UMaterialInstanceDynamic* MaterialInstDynamic = SplineMeshComp->CreateDynamicMaterialInstance(0, SplineMaterial);
				if (nullptr != MaterialInstDynamic)
				{
					const float StartValue = InSplineComponent->GetDistanceAlongSplineAtSplinePoint(i);
					const float EndValue = InSplineComponent->GetDistanceAlongSplineAtSplinePoint(i + 1);
					MaterialInstDynamic->SetScalarParameterValue(TEXT("Start"), StartValue);
					MaterialInstDynamic->SetScalarParameterValue(TEXT("End"), EndValue);
				}
			}

			FVector StartPoint, StartTangent, EndPoint, EndTangent;
			InSplineComponent->GetLocationAndTangentAtSplinePoint(i, StartPoint, StartTangent, ESplineCoordinateSpace::Local);
			InSplineComponent->GetLocationAndTangentAtSplinePoint(i + 1, EndPoint, EndTangent, ESplineCoordinateSpace::Local);
			SplineMeshComp->SetStartAndEnd(StartPoint, StartTangent, EndPoint, EndTangent, true);
		}
	}
}

void ACWSplineActor::SetParticleTargetLocations(const TArray<FVector>& InTargetPoints, const uint8 InType)
{
	const int32 ParticleCompNum = ParticleComps.Num();
	const int32 InTargetPointNum = InTargetPoints.Num();
	const int32 MaxCount = FMath::Max(ParticleCompNum, InTargetPointNum);
	for (int32 i = 0; i < MaxCount; ++i)
	{
		UParticleSystemComponent* ParticleComp = ParticleComps.IsValidIndex(i) ? ParticleComps[i] : nullptr;
		if (!InTargetPoints.IsValidIndex(i))
		{
			if (nullptr != ParticleComp)
			{
				ParticleComp->Deactivate();
			}
			continue;
		}

		// Activate Particle System
		if (nullptr == ParticleComp)
		{
			ParticleComp = NewObject<UParticleSystemComponent>(this);
			check(ParticleComp);

			ParticleComp->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
			ParticleComp->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
			ParticleComp->Mobility = EComponentMobility::Movable;
			ParticleComp->SetGenerateOverlapEvents(false);

			AddOwnedComponent(ParticleComp);
			ParticleComp->RegisterComponent();
			ParticleComp->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

			UParticleSystem* NewParticle = FCWCfgUtils::GetAssetObject<UParticleSystem>(this, FCWCommAssetKey::Particle_HitMark);
			if (nullptr != NewParticle)
			{
				ParticleComp->SetTemplate(NewParticle);
			}else
			{
				CWG_ERROR(">> SetParticleTargetLocations, FCWCommAssetKey::Particle_HitMark is not find!!!");
			}
			// Add to Array
			ParticleComps.AddUnique(ParticleComp);
		}
		else
		{
			ParticleComp->ActivateSystem();
		}
		const FVector& InTargetPoint = InTargetPoints[i];
		UpdateParticleTargetLocation(ParticleComp, InTargetPoint);
	}
}

void ACWSplineActor::HideAllParticleComps()
{
	for (int32 i = 0; i < ParticleComps.Num(); ++i)
	{
		UParticleSystemComponent* ParticleComp = ParticleComps[i];
		if (nullptr != ParticleComp)
		{
			ParticleComp->Deactivate();
		}
	}
}

void ACWSplineActor::DestroyAllParticleComps()
{
	TArray<UParticleSystemComponent*> AllComps;
	GetComponents<UParticleSystemComponent>(AllComps, true);
	for (int32 i = 0; i < AllComps.Num(); ++i)
	{
		USceneComponent* MyComponent = AllComps[i];
		if (nullptr != MyComponent && MyComponent != RootComponent)
		{
			MyComponent->DestroyComponent(/*true*/);
		}
	}
	ParticleComps.Empty();
}
