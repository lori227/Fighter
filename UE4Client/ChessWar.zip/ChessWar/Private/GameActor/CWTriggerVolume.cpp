﻿
#include "CWTriggerVolume.h"

#include "Engine.h"
#include "UnrealNetwork.h"
#include "Engine/Texture2D.h"
#include "PhysicsEngine/BodySetup.h"
#include "Components/BoxComponent.h"
#include "Components/ShapeComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/BillboardComponent.h"


ACWTriggerVolume::ACWTriggerVolume(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bHidden = true;
	bReplicates = true;
	bCanBeDamaged = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	static FName CollisionProfileName(TEXT("InvisibleWall"));
	BoxComp = CreateDefaultSubobject<UBoxComponent>("BoxComp");
	BoxComp->SetCollisionProfileName(CollisionProfileName);
	BoxComp->InitBoxExtent(FVector(40.f, 40.f, 10.f));
	BoxComp->ShapeColor = FColor(0, 255, 0, 255);
	BoxComp->SetCanEverAffectNavigation(false);
	BoxComp->SetGenerateOverlapEvents(false);
	BoxComp->SetEnableGravity(false);
	BoxComp->bHiddenInGame = false;
	SetRootComponent(BoxComp);
	//BoxComp->SetupAttachment(RootComponent);

	BoxExtent = BoxComp->GetUnscaledBoxExtent();

#if WITH_EDITORONLY_DATA
	SpriteComponent = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("Sprite"));
	if (SpriteComponent)
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> TriggerTextureObject;
			FName ID_Triggers;
			FText NAME_Triggers;
			FConstructorStatics()
				: TriggerTextureObject(TEXT("/Engine/EditorResources/S_Trigger"))
				, ID_Triggers(TEXT("Triggers"))
				, NAME_Triggers(NSLOCTEXT("SpriteCategory", "Triggers", "Triggers"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		SpriteComponent->Sprite = ConstructorStatics.TriggerTextureObject.Get();
		SpriteComponent->RelativeScale3D = FVector(0.5f, 0.5f, 0.5f);
		SpriteComponent->bHiddenInGame = false;
		SpriteComponent->Sprite = ConstructorStatics.TriggerTextureObject.Get();
		SpriteComponent->SpriteInfo.Category = ConstructorStatics.ID_Triggers;
		SpriteComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_Triggers;
		SpriteComponent->bIsScreenSizeScaled = true;
		SpriteComponent->SetupAttachment(RootComponent);
	}
#endif
}

ACWTriggerVolume::~ACWTriggerVolume()
{
}

void ACWTriggerVolume::BeginPlay()
{
	Super::BeginPlay();

	SetBoxExtent(BoxExtent);
}

void ACWTriggerVolume::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWTriggerVolume, BoxExtent);
}

void ACWTriggerVolume::SetBoxExtent(FVector InBoxExtent, bool bUpdateOverlaps /*= true*/)
{
	check(BoxComp);
	BoxExtent = InBoxExtent;
	BoxComp->SetBoxExtent(InBoxExtent, bUpdateOverlaps);
}

void ACWTriggerVolume::OnRep_BoxExtent()
{
	SetBoxExtent(BoxExtent);
}
