
#include "CWWeatherEffect.h"


ACWWeatherEffect::ACWWeatherEffect(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

ACWWeatherEffect::~ACWWeatherEffect()
{
}

void ACWWeatherEffect::BeginPlay()
{
	Super::BeginPlay();
}
