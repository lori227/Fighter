#include "CWCommonUtil.h"

template<typename T>
T* FCWCommonUtil::GetClassDefaultObject(UClass* InClass)
{
	if (InClass == nullptr || !InClass->IsValidLowLevelFast(false))
	{
		return (T*)(nullptr);
	}
	UObject* obj = InClass->GetDefaultObject();
	return Cast<T>(obj);
}