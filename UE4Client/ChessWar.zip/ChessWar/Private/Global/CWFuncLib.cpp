﻿
#include "CWFuncLib.h"

#if WITH_EDITOR
	#include "Editor/EditorEngine.h"
	#include "Editor/UnrealEdEngine.h"
#endif
#include "Engine/GameEngine.h"

#include "UnrealClient.h"
#include "Engine/LocalPlayer.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/GameViewportClient.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Components/TextRenderComponent.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWGameMode.h"
#include "CWUIManager.h"
#include "AkAudioEvent.h"
#include "CWGameInstance.h"


UCWFuncLib::UCWFuncLib(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCWFuncLib::CWGConsoleCmd(UObject* InWorldContext, const FString& Cmd, class APlayerController* SpecificPlayer)
{
	CWG_LOG(">>> CWGConsoleCmd: Cmd[%s]~", *Cmd);
	if (!IsValidObject(InWorldContext) && !IsValidObject(SpecificPlayer))
	{
		InWorldContext = GEngine ? GEngine->GetWorld() : nullptr;
	}
	UKismetSystemLibrary::ExecuteConsoleCommand(InWorldContext, Cmd, SpecificPlayer);
}

void UCWFuncLib::CWGQuitGame(TEnumAsByte<EQuitPreference::Type> QuitPreference, UObject* InWorldContext, APlayerController* SpecificPlayer)
{
	UKismetSystemLibrary::QuitGame(InWorldContext, SpecificPlayer, QuitPreference, false);
	//CWGConsoleCmd(InWorldContext, TEXT("Quit"), SpecificPlayer);
	//FGenericPlatformMisc::RequestExit();
	//FPlatformMisc::RequestExit();	// 杀进程...
}

void UCWFuncLib::CWGConnectServer(UObject* InWorldContext, const FString& InIp, int32 InPort, int32 InPid, APlayerController* SpecificPlayer)
{
	FString NewCmd = "Open " + InIp + ":" + INT_TO_FSTRING(InPort) + "?Pid=" + INT_TO_FSTRING(InPid);
	CWGConsoleCmd(InWorldContext, NewCmd, SpecificPlayer);
	CWG_LOG(">>> CWGConnectServer: NewCmd[%s]~", *NewCmd);
}

void UCWFuncLib::CWGConnectServerEx(UObject* InWorldContext, const FString& InIp, int32 InPort, const FString& InNetPlayerId, APlayerController* SpecificPlayer)
{
	FString Cmd = "Open " + InIp + ":" + INT_TO_FSTRING(InPort) + "?Pid=" + InNetPlayerId;
	CWGConsoleCmd(InWorldContext, Cmd, SpecificPlayer);
	CWG_LOG(">>> CWGConnectServerEx: Cmd[%s]~", *Cmd);
}

void UCWFuncLib::CWGOpenLevel(UObject* InWorldContext, const FString& LevelName, bool bAbsolute, FString Options)
{
	CWG_LOG("-> CWGOpenLevel: LevelName[%s] Options[%s]~", *LevelName, *Options);
	if (!IsValidObject(InWorldContext))
	{
		InWorldContext = GEngine ? GEngine->GetWorld() : nullptr;
	}
	UGameplayStatics::OpenLevel(InWorldContext, FSTRING_TO_FNAME(LevelName), bAbsolute, Options);
}

void UCWFuncLib::CWGServerTravel(UObject* InWorldContext, const FString& InURL, bool bAbsolute)
{
	CWG_LOG("-> CWGServerTravel: InURL[%s]~", *InURL);
	if (UWorld* const MyWorld = IsValidObject(InWorldContext) ? InWorldContext->GetWorld() : GEngine->GetWorld())
	{
		MyWorld->ServerTravel(InURL, bAbsolute);
	}
}

void UCWFuncLib::CWGResetServer(UObject* InWorldContext)
{
	CWG_LOG("-> CWGResetServer: ");
	if (UWorld* const MyWrold = IsValidObject(InWorldContext) ? InWorldContext->GetWorld() : GEngine->GetWorld())
	{
		if (ACWGameMode* CWGM = Cast<ACWGameMode>(MyWrold->GetAuthGameMode()))
		{
			CWGM->KickAllPlayersToLobby(TEXT(""));
		}
		MyWrold->ServerTravel(ServerResetURL, true);
	}
}

UGameInstance* UCWFuncLib::GetGameInst(const UObject* InWorldContext)
{
	UWorld* MyWorld = IsValidObject(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
	if (IsValidObject(MyWorld))
	{
		return MyWorld->GetGameInstance();
	}

//#if WITH_EDITOR
	/*UUnrealEdEngine* UEEngine = Cast<UUnrealEdEngine>(GEngine);
	MyWorld = (nullptr != UEEngine) ? UEEngine->PlayWorld : nullptr;
	if (IsValidObject(MyWorld))
	{
		return MyWorld->GetGameInstance();
	}*/
//#else
	UGameEngine* GGEngine = Cast<UGameEngine>(GEngine);
	if (nullptr != GGEngine)
	{
		return GGEngine->GameInstance;
	}
//#endif

	MyWorld = GWorld.GetReference();
	if (IsValidObject(MyWorld))
	{
		return MyWorld->GetGameInstance();
	}

	CWG_WARNING(">>> UCWFuncLib::GetGameInst, GameInstance is nullptr.");
	return nullptr;
}

UCWGameInstance* UCWFuncLib::GetCWGameInst(const UObject* InWorldContext)
{
	UGameInstance* GameInstance = GetGameInst(InWorldContext);
	if (nullptr == GameInstance)
	{
		return UCWGameInstance::GetInstance();
	}
	return IsValidObject(GameInstance) ? Cast<UCWGameInstance>(GameInstance) : nullptr;
}

bool UCWFuncLib::IsValidObjectImpl(const UObject* InUObject)
{
	return ::IsValidObject(InUObject);
}

bool UCWFuncLib::IsValidActorImpl(const AActor* InAActor)
{
	return ::IsValidActor(InAActor);
}

bool UCWFuncLib::IsGameWorld(const UObject* InWorldContext)
{
	UWorld* const World = IsValidObject(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
	return World ? World->IsGameWorld() : false;
}

/**
 * Check to see if this executable is running as dedicated server
 * Editor can run as dedicated with -server
 */
bool UCWFuncLib::IsRunningDedicatedServer()
{
	return ::IsRunningDedicatedServer();
}

/**
 * Check to see if this executable is running as "the game"
 * - contains all net code (WITH_SERVER_CODE=1)
 * Editor can run as a game with -game
 */
bool UCWFuncLib::IsRunningGame()
{
	return ::IsRunningGame();
}

/**
 * Check to see if this executable is running as "the client"
 * - removes all net code (WITH_SERVER_CODE=0)
 * Editor can run as a game with -clientonly
 */
bool UCWFuncLib::IsRunningClientOnly()
{
	return ::IsRunningClientOnly();
}

bool UCWFuncLib::IsCanInitCustomData(const UObject* InObj)
{
	return (IsValidObject(InObj) && (!GIsEditor || UCWFuncLib::IsGameWorld(InObj)) && !InObj->IsTemplate());
}

bool UCWFuncLib::IsCanDestroyCustomData(const UObject* InObj)
{
	return nullptr != InObj && !GIsEditor && !InObj->IsTemplate();
}

bool UCWFuncLib::IsPartner(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2)
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() == ParamPawn2->GetCampTag() &&
		ParamPawn1->GetCampControllerIndex() == ParamPawn2->GetCampControllerIndex())
	{
		return true;
	}
	return false;
}

bool UCWFuncLib::IsFriend(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2)
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() == ParamPawn2->GetCampTag() &&
		ParamPawn1->GetCampControllerIndex() != ParamPawn2->GetCampControllerIndex())
	{
		return true;
	}
	return false;
}

bool UCWFuncLib::IsEnemy(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2)
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() != ParamPawn2->GetCampTag())
	{
		return true;
	}
	return false;
}

AActor* UCWFuncLib::GetOneActor(const UObject* InWorldContext, TSubclassOf<AActor> InActorClass)
{
	//UGameplayStatics::GetAllActorsOfClass();

	UWorld* InWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
	// We do nothing if no is class provided, rather than giving ALL actors!
	if (nullptr == InWorld || nullptr == InActorClass)
	{
		return nullptr;
	}
	
	for (TActorIterator<AActor> It(InWorld, InActorClass); It; ++It)
	{
		AActor* TmpActor = *It;
		if (IsValidActorImpl(TmpActor))
		{
			return TmpActor;
		}
	}
	return nullptr;
}

void UCWFuncLib::DestroyActorChildren(AActor* InActor)
{
	if (nullptr != InActor && !InActor->IsPendingKill() 
		/*&& !InActor->IsPendingKillPending()*/
		&& InActor->Children.Num() > 0)
	{
		// 绑定对象
		/*TArray<AActor*> AttachedActors;
		InActor->GetAttachedActors(AttachedActors);
		if (AttachedActors.Num() > 0)
		{
		}*/

		// 删除拥有子对象
		for (int32 i = 0; i < InActor->Children.Num(); ++i)
		{
			AActor* MyChild = InActor->Children[i];
			if (nullptr != MyChild && !MyChild->IsPendingKillPending())
			{
				MyChild->Destroy(/*true*/);
			}
		}
		//InActor->Children.Empty();
	}
}

/*
FTimerManager& UCWFuncLib::GetTimerManager(const UObject* InWorldContext)
{
	InWorldContext = (nullptr == InWorldContext) ? UCWFuncLib::GetGameInst(InWorldContext) : InWorldContext;
	if (UWorld* const MyWorld = InWorldContext ? InWorldContext->GetWorld() : nullptr)
	{
		return MyWorld->GetTimerManager();
	}
	return FTimerManager;
}*/

bool UCWFuncLib::GetHitResult(FHitResult& OutHitResult, const FVector2D& InScreenSpacePosition, const UObject* InWorldContext)
{
	bool bHit = false;
	UGameInstance* const GI = UCWFuncLib::GetGameInst(InWorldContext);
	if (APlayerController* const MyPC = GI ? GI->GetFirstLocalPlayerController() : nullptr)
	{
		FVector2D ScreenPosition = InScreenSpacePosition;
#if PLATFORM_WINDOWS
		ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(MyPC->Player);
		if (LocalPlayer && LocalPlayer->ViewportClient && LocalPlayer->ViewportClient->Viewport && FSlateApplication::Get().IsMouseAttached())
		{
			FIntPoint MousePos;
			LocalPlayer->ViewportClient->Viewport->GetMousePos(MousePos);
			ScreenPosition = FVector2D(MousePos);
		}
		//bHit = MyPC->GetHitResultUnderCursor(MyPC->CurrentClickTraceChannel, true, OutHitResult);
//#elif PLATFORM_ANDROID
#endif
		if (ScreenPosition.X >= 0 && ScreenPosition.Y >= 0)
		{
			bHit = MyPC->GetHitResultAtScreenPosition(ScreenPosition, MyPC->CurrentClickTraceChannel, true, OutHitResult);
		}
	}

	return bHit;
}

TSoftObjectPtr<UObject> UCWFuncLib::ToSoftObjectPtr(const FString& InAssetPath)
{
	TSoftObjectPtr<UObject> SoftObjectPtr;
	if (!InAssetPath.IsEmpty())
	{
		FSoftObjectPath SoftObjectPath(InAssetPath);
		SoftObjectPtr = TSoftObjectPtr<UObject>(SoftObjectPath);
	}

	return SoftObjectPtr;
}

TSoftClassPtr<UClass> UCWFuncLib::ToSoftClassPtr(const FString& InClassPath)
{
	TSoftClassPtr<UClass> SoftClassPtr;
	if (!InClassPath.IsEmpty())
	{
		FSoftObjectPath SoftObjectPath(InClassPath);
		SoftClassPtr = TSoftClassPtr<UClass>(SoftObjectPath);
	}

	return SoftClassPtr;
}

UObject* UCWFuncLib::LoadObject(const TSoftObjectPtr<UObject>& InSoftObjectPtr)
{
	UObject* OutObject = LoadObjectImpl(InSoftObjectPtr);
	return OutObject;
}

UClass* UCWFuncLib::LoadClass(const TSoftClassPtr<UClass>& InSoftClassPtr)
{
	UClass* OutClass = LoadClassImpl(InSoftClassPtr);
	return OutClass;
}

UTextRenderComponent* UCWFuncLib::PrintTxtInfo(AActor* InActor, 
	const FText& InTxt, const FColor& InClolor, const float InSize, const float InOffsetZ)
{
	if (!IsValidActor(InActor))
	{
		CWG_WARNING(">> PrintTxtInfo, InActor is nullptr!");
		return nullptr;
	}

	UActorComponent* ActorComp = InActor->GetComponentByClass(UTextRenderComponent::StaticClass());
	UTextRenderComponent* TextRenderComp = Cast<UTextRenderComponent>(ActorComp);
	if (nullptr == TextRenderComp)
	{
		TextRenderComp = NewObject<UTextRenderComponent>(InActor);
		check(TextRenderComp);
		InActor->AddOwnedComponent(TextRenderComp);
		TextRenderComp->RegisterComponent();
		TextRenderComp->AttachToComponent(InActor->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);

		TextRenderComp->SetWorldRotation(FRotator(90.f, 0.f, 0.f));
		TextRenderComp->SetRelativeLocation(FVector(0.f, 0.f, InOffsetZ));
		TextRenderComp->SetHorizontalAlignment(EHTA_Center);
		TextRenderComp->SetVerticalAlignment(EVRTA_TextCenter);
	}
	TextRenderComp->SetWorldSize(InSize);
	TextRenderComp->SetTextRenderColor(InClolor);
	TextRenderComp->SetText(/*FSTRING_TO_FTEXT*/(InTxt));
	return TextRenderComp;
}

UMaterialInstanceDynamic* UCWFuncLib::GetPostProcessVolumeMaterial(APostProcessVolume* InPostProcessVolume, FName InMaterialName)
{
	if (nullptr == InPostProcessVolume || InPostProcessVolume->Settings.WeightedBlendables.Array.Num() <= 0)
	{
		CWG_WARNING(">> GetPostProcessVolumeMaterialBy, InPostProcessVolume is nullptr// or Num[0].");
		return nullptr;
	}
	
	for (FWeightedBlendable& WeightedBlendable : InPostProcessVolume->Settings.WeightedBlendables.Array)
	{
		UObject* BlendableObject = WeightedBlendable.Object;
		UMaterialInterface* Material = Cast<UMaterialInterface>(BlendableObject);
		if (nullptr != Material && InMaterialName.IsEqual(Material->GetFName()))
		{
			UMaterialInstanceDynamic* DynamicMaterial = Cast<UMaterialInstanceDynamic>(Material);
			if (nullptr == DynamicMaterial)
			{
				DynamicMaterial = UMaterialInstanceDynamic::Create(Material, InPostProcessVolume);
			}

			if (nullptr != DynamicMaterial)
			{
				WeightedBlendable.Object = DynamicMaterial;
			}

			return DynamicMaterial;
		}
	}

	return nullptr;
}

const FString UCWFuncLib::ToString(const ENetMode& NetMode)
{
	switch (NetMode)
	{
	case NM_Standalone:			return TEXT("Standalone");
	case NM_DedicatedServer:	return TEXT("DedicatedServer");
	case NM_ListenServer:		return TEXT("ListenServer");
	case NM_Client:				return TEXT("Client");
	}
	return TEXT("Unknown");
}

void UCWFuncLib::CWControlScreenSaver(const bool bAllowScreenSaver /*= false*/)
{
	UKismetSystemLibrary::ControlScreensaver(bAllowScreenSaver);
}

bool UCWFuncLib::IsPlatform(const EPlatformType InType)
{

#if PLATFORM_WINDOWS
	return EPlatformType::Windows == InType;
#elif PLATFORM_PS4
	return EPlatformType::PS4 == InType;
#elif PLATFORM_XBOXONE
	return EPlatformType::XBoxOne == InType;
#elif PLATFORM_MAC
	return EPlatformType::Mac == InType;
#elif PLATFORM_IOS
	return EPlatformType::IOS == InType;
#elif PLATFORM_ANDROID
	return EPlatformType::Android == InType;
#elif PLATFORM_HTML5
	return EPlatformType::HTML5 == InType;
#elif PLATFORM_LINUX
	return EPlatformType::Linux == InType;
#elif PLATFORM_QUAIL
	return EPlatformType::Quail == InType;
#elif PLATFORM_SWITCH
	return EPlatformType::Switch == InType;
#endif

	CWG_WARNING(">> CWFuncLib::IsPlatform, Unknown Platform. InType[%d].", (int32)InType);
	return false/*EPlatformType::Unknown*/;
}

bool UCWFuncLib::IsDesktopPlatform()
{
#if PLATFORM_DESKTOP
#endif

	return IsPlatform(EPlatformType::Windows) || IsPlatform(EPlatformType::Mac);
}

bool UCWFuncLib::IsMobilePhonePlatform()
{
	return IsPlatform(EPlatformType::Android) || IsPlatform(EPlatformType::IOS);
}

// 遍历文件夹下指定类型文件
// OutFiles 保存遍例到的所有文件
// FilePath 文件夹路径  如 "D:\\MyCodes\\LearnUE4Cpp\\Source\\LearnUE4Cpp\\"
// Extension 扩展名(文件类型) 如 "*.cpp"
void UCWFuncLib::ScanDirectory(TArray<FString>& OutFiles, const FString& InFilePath, const FString& InExtension)
{
	//IFileManager::Get().FindFilesRecursive(FindedFiles, *InFilePath, TEXT("*.uasset"), true, false);
	FindFilesRecursive(OutFiles, *InFilePath, *InExtension, true, false);

	CWG_WARNING("------------------------Start ScanDirectory---------------------------");
	for (int i = 0; i < OutFiles.Num(); ++i)
	{
		CWG_WARNING(">> SearchFile[%s].", *OutFiles[i]);
	}
	CWG_WARNING("------------------------End ScanDirectory---------------------------");
}

void UCWFuncLib::FindFilesRecursive(TArray<FString>& FileNames, const TCHAR* StartDirectory, const TCHAR* Filename, bool Files, bool Directories, bool bClearFileNames /*= true*/)
{
	if (bClearFileNames)
	{
		FileNames.Empty();
	}
	FindFilesRecursiveInternal(FileNames, StartDirectory, Filename, Files, Directories);
}

void UCWFuncLib::FindFilesRecursiveInternal(TArray<FString>& FileNames, const TCHAR* StartDirectory, const TCHAR* Filename, bool Files, bool Directories)
{
	FString CurrentSearch = FString(StartDirectory) / Filename;
	TArray<FString> Result;
	IFileManager::Get().FindFiles(Result, *CurrentSearch, Files, Directories);

	for (int32 i = 0; i < Result.Num(); i++)
	{
		FileNames.Add(/*FString(StartDirectory) / */Result[i]);
	}

	TArray<FString> SubDirs;
	FString RecursiveDirSearch = FString(StartDirectory) / TEXT("*");
	IFileManager::Get().FindFiles(SubDirs, *RecursiveDirSearch, false, true);

	for (int32 SubDirIdx = 0; SubDirIdx < SubDirs.Num(); SubDirIdx++)
	{
		FString SubDir = FString(StartDirectory) / SubDirs[SubDirIdx];
		FindFilesRecursiveInternal(FileNames, *SubDir, Filename, Files, Directories);
	}
}
