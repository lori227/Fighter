#include "CWGameInfo.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWGameInfo, All, All);


ACWGameInfo::ACWGameInfo(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	//SceneComponent->Mobility = EComponentMobility::Movable;
	SceneComponent->SetupAttachment(GetRootComponent());
}

void ACWGameInfo::BeginPlay()
{
	Super::BeginPlay();
}

void ACWGameInfo::BeginDestroy()
{
	Super::BeginDestroy();
}

void ACWGameInfo::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWGameInfo, GameId);
}

void ACWGameInfo::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

int32 ACWGameInfo::GetGameId()
{
	return GameId;
}