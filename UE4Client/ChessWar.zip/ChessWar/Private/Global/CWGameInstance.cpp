﻿
#include "CWGameInstance.h"

#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWManager.h"
#include "CWCfgManager.h"
#include "CWUIManager.h"
#include "CWSluaManager.h"
#include "CWWeatherMgr.h"
#include "CWLocalDataMgr.h"
#include "CWAudioVideoMgr.h"
#include "CWLoginModuleInClient.h"
#include "CWTCPServerClient.h"
#include "CWTCPClient.h"
#include "CWAppId.h"
#include "CWNetPlayerDataManager.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWGameInstance, All, All);

UCWGameInstance* UCWGameInstance::s_this = nullptr;

UCWGameInstance::UCWGameInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, m_bEnableTick(true)
	, RoomId(0)
	, RoomServerId(0)
	, MatchId(0)
{
	s_this = this;
}

UCWGameInstance* UCWGameInstance::GetInstance()
{
	return s_this;
}

void UCWGameInstance::StartGameInstance()
{
	Super::StartGameInstance();
}

void UCWGameInstance::Init()
{
	Super::Init();

	s_this = this;

	//const TCHAR* CommandLine = FCommandLine::Get();
	//FWorldContext* WorldContext = GetWorldContext();
	UE_LOG(LogCWGameInstance, Log, TEXT("UCWGameInstance::Init..."));

	// Manager
	InitCfgMgr();
	InitEventMgr();
	InitWeatherMgr();
	InitLocalDataMgr();
	InitTCPServerClient();
	InitNetPlayerDataMgr();
	
#if !UE_SERVER
	InitTCPClient();
	InitLoginModuleInClient();
	InitUIManager();
	InitAudioVideoMgr();
#endif


#if PLATFORM_ANDROID
	UCWFuncLib::CWControlScreenSaver(false);
#endif

	// t.MaxFPS 锁帧
	//UCWFuncLib::CWGConsoleCmd(this, TEXT("t.MaxFPS 60.0f"));

	// Android 前台/后台
	//FCoreDelegates::ApplicationWillEnterBackgroundDelegate.AddUObject(this, &UCWGameInstance::HandleAppSuspend);
	//FCoreDelegates::ApplicationHasEnteredForegroundDelegate.AddUObject(this, &UCWGameInstance::HandleAppResume);

	//lua最后初始化
	InitSluaManager();
}

void UCWGameInstance::Shutdown()
{
	//lua最先销毁
	DestroySluaManager();

#if PLATFORM_ANDROID
	//UCWFuncLib::CWControlScreenSaver(true);
#endif

#if !UE_SERVER
	DestroyAudioVideoMgr();
	DestroyUIManager();
	DestroyLoginModuleInClient();
	DestroyTCPClient();
#endif

	DestroyNetPlayerDataMgr();
	DestroyTCPServerClient();
	DestroyWeatherMgr();
	DestroyLocalDataMgr();
	DestroyEventMgr();
	DestroyCfgMgr();
	
	Super::Shutdown();
	UE_LOG(LogCWGameInstance, Log, TEXT("UCWGameInstance::Shutdown..."));
}

void UCWGameInstance::Tick(float DeltaTime)
{
	if (nullptr != SluaManager)
	{
		SluaManager->Tick(DeltaTime);
	}

	if (nullptr != TCPClient)
	{
		TCPClient->Tick(DeltaTime);
	}

	if (nullptr != TCPServerClient)
	{
		TCPServerClient->Tick(DeltaTime);
	}
}

inline bool UCWGameInstance::IsTickable(void) const
{
	return m_bEnableTick;
}

inline TStatId UCWGameInstance::GetStatId(void) const
{
	//RETURN_QUICK_DECLARE_CYCLE_STAT(UCWGameInstance, STATGROUP_TaskGraphTasks);
	return m_TStatId;
}

void UCWGameInstance::PreloadContentForURL(FURL InURL)
{
	// Preload game mode and other content if needed here
	CWG_LOG(">> %s::PreloadContentForURL, InURL[%s, %s, %s, %d].", *GetName(), *InURL.Map, *InURL.RedirectURL, *InURL.Portal, InURL.Port);

	UCWEventMgr::OnPreloadContentForURL.Broadcast(InURL);
}

void UCWGameInstance::LoadComplete(const float LoadTime, const FString& MapName)
{
	Super::LoadComplete(LoadTime, MapName);

	UCWEventMgr::OnLevelLoadComplete.Broadcast(LoadTime, MapName);
	CWG_LOG(">> %s::LoadComplete, LoadTime[%f] MapName[%s].", *GetName(), LoadTime, *MapName);
}

void UCWGameInstance::InitCfgMgr()
{
	TSubclassOf<UCWManager>* TemplateManager = ManagerTemplate.Find("CfgManager");
	if (nullptr == CfgMgr && nullptr != TemplateManager)
	{
		//CfgMgr = Cast<UCWCfgManager>(StaticConstructObject_Internal(*TemplateManager));
		CfgMgr = NewObject<UCWCfgManager>(this, *TemplateManager);
		if (nullptr != CfgMgr)
		{
			CfgMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyCfgMgr()
{
	if (nullptr != CfgMgr)
	{
		CfgMgr->Destroy();
		CfgMgr = nullptr;
	}
}

void UCWGameInstance::InitEventMgr()
{
	if (nullptr == EventMgr)
	{
		EventMgr = Cast<UCWEventMgr>(StaticConstructObject_Internal(UCWEventMgr::StaticClass()));
		if (nullptr != EventMgr)
		{
			EventMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyEventMgr()
{
	if (nullptr != EventMgr)
	{
		EventMgr->Destroy();
		EventMgr = nullptr;
	}
}


#if !UE_SERVER
void UCWGameInstance::InitUIManager()
{
	TSubclassOf<UCWManager>* TemplateManager = ManagerTemplate.Find("UIManager");
	if (nullptr == UIManager && nullptr != TemplateManager)
	{
		UIManager = Cast<UCWUIManager>(StaticConstructObject_Internal(*TemplateManager, this));
		if (nullptr != UIManager)
		{
			UIManager->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyUIManager()
{
	if (nullptr != UIManager)
	{
		UIManager->Destroy();
		UIManager = nullptr;
	}
}

void UCWGameInstance::InitAudioVideoMgr()
{
	if (!IsValid(AudioVideoMgr))
	{
		AudioVideoMgr = NewObject<UCWAudioVideoMgr>();
		if (IsValid(AudioVideoMgr))
		{
			AudioVideoMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyAudioVideoMgr()
{
	if (IsValid(AudioVideoMgr))
	{
		AudioVideoMgr->Destroy();
		AudioVideoMgr = nullptr;
	}
}

void UCWGameInstance::InitLoginModuleInClient()
{
	if (nullptr == LoginModule)
	{
		LoginModule = NewObject<UCWLoginModuleInClient>();
		check(LoginModule != nullptr);
		LoginModule->Init(this);
	}
}

void UCWGameInstance::DestroyLoginModuleInClient()
{
	if (nullptr != LoginModule)
	{
		LoginModule->Destroy();
		LoginModule->ConditionalBeginDestroy();
		LoginModule = nullptr;
	}
}

void UCWGameInstance::InitTCPClient()
{
	if (nullptr == TCPClient)
	{
		TCPClient = NewObject<UCWTCPClient>();
		check(TCPClient != nullptr);
		//TCPClient->Init();
	}
}

void UCWGameInstance::DestroyTCPClient()
{
	if (nullptr != TCPClient)
	{
		TCPClient->Destroy();
		TCPClient->ConditionalBeginDestroy();
		TCPClient = nullptr;
	}
}
#endif


void UCWGameInstance::InitSluaManager()
{
	TSubclassOf<UCWManager>* TemplateManager = ManagerTemplate.Find("SluaManager");
	if (nullptr == SluaManager && nullptr != TemplateManager)
	{
		SluaManager = Cast<UCWSluaManager>(StaticConstructObject_Internal(*TemplateManager, this, FName("CWG_SluaMgr")));
		//UIManager = (*TemplateManager)->GetDefaultObject<UCWUIManager>();
		if (nullptr != SluaManager)
		{
			SluaManager->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroySluaManager()
{
	if (nullptr != SluaManager)
	{
		SluaManager->Destroy();
		SluaManager = nullptr;
	}
}

void UCWGameInstance::InitNetPlayerDataMgr()
{
	TSubclassOf<UCWManager>* TemplateManager = ManagerTemplate.Find("NetPlayerDataManager");
	if (nullptr == NetPlayerDataMgr && nullptr != TemplateManager)
	{
		NetPlayerDataMgr = Cast<UCWNetPlayerDataManager>(StaticConstructObject_Internal(*TemplateManager, this, FName("CWG_NetPlayerDataMgr")));
		//UIManager = (*TemplateManager)->GetDefaultObject<UCWUIManager>();
		if (nullptr != NetPlayerDataMgr)
		{
			NetPlayerDataMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyNetPlayerDataMgr()
{
	if (nullptr != NetPlayerDataMgr)
	{
		NetPlayerDataMgr->Destroy();
		NetPlayerDataMgr = nullptr;
	}
}

void UCWGameInstance::InitTCPServerClient()
{
	if (nullptr == TCPServerClient)
	{
		TCPServerClient = NewObject<UCWTCPServerClient>();
		check(TCPServerClient != nullptr);
		TCPServerClient->Init();
	}
}

void UCWGameInstance::DestroyTCPServerClient()
{
	if (nullptr != TCPServerClient)
	{
		TCPServerClient->Destroy();
		TCPServerClient->ConditionalBeginDestroy();
		TCPServerClient = nullptr;
	}
}

void UCWGameInstance::InitWeatherMgr()
{
	if (!IsValid(WeatherMgr))
	{
		WeatherMgr = NewObject<UCWWeatherMgr>();
		if (nullptr != WeatherMgr)
		{
			WeatherMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyWeatherMgr()
{
	if (nullptr != WeatherMgr)
	{
		WeatherMgr->Destroy();
		WeatherMgr = nullptr;
	}
}

void UCWGameInstance::InitLocalDataMgr()
{
	if (!IsValid(LocalDataMgr))
	{
		LocalDataMgr = NewObject<UCWLocalDataMgr>();
		if (IsValid(LocalDataMgr))
		{
			LocalDataMgr->InitMgr(this);
		}
	}
}

void UCWGameInstance::DestroyLocalDataMgr()
{
	if (IsValid(AudioVideoMgr))
	{
		AudioVideoMgr->Destroy();
		AudioVideoMgr = nullptr;
	}
}

UCWCfgManager* UCWGameInstance::GetCfgMgr()
{
	return CfgMgr;
}

#if !UE_SERVER
UCWUIManager* UCWGameInstance::GetUIMgr()
{
	return UIManager;
}

UCWAudioVideoMgr* UCWGameInstance::GetAudioVideoMgr()
{
	return AudioVideoMgr;
}

UCWTCPClient* UCWGameInstance::GetTCPClient()
{
	return TCPClient;
}

UCWLoginModuleInClient* UCWGameInstance::GetLoginModuleInClient()
{
	return LoginModule;
}
#endif

UCWSluaManager* UCWGameInstance::GetSluaMgr()
{
	return SluaManager;
}

UCWEventMgr* UCWGameInstance::GetEventMgr()
{
	return EventMgr;
}

UCWWeatherMgr* UCWGameInstance::GetWeatherMgr()
{
	return WeatherMgr;
}

UCWLocalDataMgr* UCWGameInstance::GetLocalDataMgr()
{
	return LocalDataMgr;
}

UCWNetPlayerDataManager* UCWGameInstance::GetNetPlayerDataMgr()
{
	return NetPlayerDataMgr;
}

UCWTCPServerClient* UCWGameInstance::GetTCPServerClient()
{
	return TCPServerClient;
}
//---------------------------------------------------------------------------------
const FString& UCWGameInstance::GetTargetVersionInClient() const
{
	return TargetVersionInClient;
}

void UCWGameInstance::SetTargetVersionInClient(const FString& ParamTargetVersion)
{
	TargetVersionInClient = ParamTargetVersion;
}

const FString& UCWGameInstance::GetServerAuthTokenInClient() const
{
	return ServerAuthTokenInClient;
}

void UCWGameInstance::SetServerAuthTokenInClient(const FString& ParamServerAuthToken)
{
	ServerAuthTokenInClient = ParamServerAuthToken;
}

uint32 UCWGameInstance::GetAccountIdInClient() const
{
	return AccountId;
}

void UCWGameInstance::SetAccountIdInClient(uint32 ParamAccountId)
{
	AccountId = ParamAccountId;
}

void UCWGameInstance::SetRoomId(uint64 ParamRoomId)
{
	RoomId = ParamRoomId;
}

uint64 UCWGameInstance::GetRoomId() const
{
	return RoomId;
}

void UCWGameInstance::SetRoomServerId(uint64 ParamRoomServerId)
{
	RoomServerId = ParamRoomServerId;
}

uint64 UCWGameInstance::GetRoomServerId() const
{
	return RoomServerId;
}

void UCWGameInstance::SetMatchId(uint32 ParamMatchId)
{
	MatchId = ParamMatchId;
}

uint32 UCWGameInstance::GetMatchId() const
{
	return MatchId;
}
//---------------------------------------------------------------------------------