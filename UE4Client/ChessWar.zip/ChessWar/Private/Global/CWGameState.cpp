﻿
#include "CWGameState.h"
#include "CWPlayerController.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWGameInfo.h"
#include "CWEventMgr.h"
#include "CWUIManager.h"
#include "CWWeatherMgr.h"
#include "CWCommonUtil.h"
#include "CWGameInstance.h"
#include "CWAudioVideoMgr.h"
#include "CWGameDataStruct.h"
#include "CWBattleCalculate.h"
#include "CWClientConstData.h"
#include "CWRandomDungeonGenerator.h"
#include "CWWeatherData.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWGameState, All, All);

ACWGameState::ACWGameState(const FObjectInitializer& ObjectInitializer)
:Super(ObjectInitializer)
{
	CurBattleState = ECWBattleState::None;
	CurRoundIndex = 0;
	CurDungeonTileFallIndex = 0;
	CurCampTag = ECWCampTag::None;
	CurCampControllerIndex = ECWCampControllerIndex::None;
	CurPawnIndex = 0;
	MaxReadyTime = INVALID_TIME_VALUE;
	MaxActionTime = INVALID_TIME_VALUE;
	CurReadyRemainTime = 0.f;
	CurActionRemainTime = 0;
	CurWeatherIdx = OldWeatherIdx = NextWeatherIdx = (int32)ECWWeatherType::Sunshine;
	CampANum = 0;
	CampBNum = 0;
	PawnMoveMode = ECWPawnMoveMode::One;
}

void ACWGameState::BeginPlay()
{
	Super::BeginPlay();

	if (!IsNetMode(NM_Client))
	{
	}
	else
	{
		/*if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			TScriptDelegate<> NewDelegate;
			NewDelegate.BindUFunction(this, FName("OnLandEarlyWarn"));
			EvtMgr->OnLevelDropEarlyWarnClient.Add(NewDelegate);
		}*/
	}
}

void ACWGameState::OnLandEarlyWarn(const bool bStart, const int32 InWarnIdx)
{
	CWG_WARNING(">> OnLandEarlyWarn, bStart[%s] InWarnIdx[%d].", *BOOL_TO_FSTRING(bStart), InWarnIdx);
}

void ACWGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWGameState, CurNetPlayerCount);
	DOREPLIFETIME(ACWGameState, CurBattleState);
	DOREPLIFETIME(ACWGameState, OldBattleState);
	DOREPLIFETIME(ACWGameState, CurRoundIndex);
	DOREPLIFETIME(ACWGameState, CurDungeonTileFallIndex);
	DOREPLIFETIME(ACWGameState, CurCampTag);
	DOREPLIFETIME(ACWGameState, CurCampControllerIndex);
	DOREPLIFETIME(ACWGameState, CurPawnIndex);
	DOREPLIFETIME(ACWGameState, MaxReadyTime);
	DOREPLIFETIME(ACWGameState, MaxActionTime);
	DOREPLIFETIME(ACWGameState, CurReadyRemainTime);
	DOREPLIFETIME(ACWGameState, CurActionRemainTime);
	DOREPLIFETIME(ACWGameState, OldWeatherIdx);
	DOREPLIFETIME(ACWGameState, CurWeatherIdx);
	DOREPLIFETIME(ACWGameState, NextWeatherIdx);
	DOREPLIFETIME(ACWGameState, CampANum);
	DOREPLIFETIME(ACWGameState, CampBNum);
	DOREPLIFETIME(ACWGameState, CampBNum);
	DOREPLIFETIME(ACWGameState, PlayerDataArray);
}

void ACWGameState::ResetWhenNextTurnBeginInServer()
{

}

void ACWGameState::SetCurNetPlayerCount(int32 NetPlayerCount)
{
	CurNetPlayerCount = NetPlayerCount;
}

int32 ACWGameState::GetCurNetPlayerCount() const
{
	return CurNetPlayerCount;
}

void ACWGameState::SetCurBattleState(ECWBattleState BattleState)
{
	OldBattleState = CurBattleState;
	CurBattleState = BattleState;

	UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurBattleState CurBattleState：%d."), (int)CurBattleState);

	if (OldBattleState != CurBattleState)
	{
		OnBattleStateChangedEventInServer.Broadcast(OldBattleState, CurBattleState);
	}
}

ECWBattleState ACWGameState::GetCurBattleState() const
{
	return CurBattleState;
}

void ACWGameState::SetCurReadyRemainTime(float InReadyRemainTime)
{
	CurReadyRemainTime = InReadyRemainTime;

	//UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurReadyRemainTime CurReadyRemainTime：%f."), CurReadyRemainTime);
}

float ACWGameState::GetCurReadyRemainTime() const
{
	return CurReadyRemainTime;
}

void ACWGameState::SetCurRoundIndex(int32 RoundIndex)
{
	CurRoundIndex = RoundIndex;
	UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurRoundIndex CurReadyRemainTime：%d."), CurRoundIndex);

	ExecWeatherCheckInServer();

	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnRoundIndexChangeInServer.Broadcast(CurRoundIndex, 0);
	}
}

int32 ACWGameState::GetCurRoundIndex() const
{
	return CurRoundIndex;
}

void ACWGameState::SetCurDungeonTileFallIndex(int32 ParamCurDungeonTileFallIndex)
{
	CurDungeonTileFallIndex = ParamCurDungeonTileFallIndex;
}

int32 ACWGameState::GetCurDungeonTileFallIndex() const
{
	return CurDungeonTileFallIndex;
}

void ACWGameState::SetCurCampTag(ECWCampTag CampTag)
{
	CurCampTag = CampTag;

	UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurCampTag CurCampTag：%d."), (int)CurCampTag);
}

ECWCampTag ACWGameState::GetCurCampTag() const
{
	return CurCampTag;
}

void ACWGameState::SetCurCampControllerIndex(ECWCampControllerIndex ParamCampControllerIndex)
{
	CurCampControllerIndex = ParamCampControllerIndex;

	UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurCampControllerIndex CurCampControllerIndex：%d."), (int)CurCampControllerIndex);
}

ECWCampControllerIndex ACWGameState::GetCurCampControllerIndex() const
{
	return CurCampControllerIndex;
}

void ACWGameState::SetCurActionRemainTime(float ActionRemainTime)
{
	CurActionRemainTime = ActionRemainTime;

	//UE_LOG(LogCWGameState, Log, TEXT("ACWGameState::SetCurActionRemainTime CurActionRemainTime：%f."), CurActionRemainTime);
}

float ACWGameState::GetCurActionRemainTime() const
{
	return CurActionRemainTime;
}

void ACWGameState::NetMulticastRPCResult_Implementation(ECWCampTag ParamWinCampTag)
{
	if (IsInServer())
		return;
	
	WinCampTag = ParamWinCampTag;

	if (UCWUIManager* UIMgr = UI_MGR(this))
	{
		UIMgr->DestroyUI(FUIKey::UIFight);
		UIMgr->OpenUI(FUIKey::UIResult);
		UIMgr->SetInputMode(EUIInputMode::UIOnly);
	}
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		ECWBattleResult Result = GetLocalPlayerFightResult();
		EvtMgr->OnBattleResult.Broadcast(Result);
	}
}

bool ACWGameState::IsInServer() const
{
	return Role == ROLE_Authority;
}

ECWCampTag ACWGameState::GetWinCamp() const
{
	return WinCampTag;
}

ECWBattleResult ACWGameState::GetLocalPlayerFightResult() const
{
	if (WinCampTag != ECWCampTag::None && WinCampTag != ECWCampTag::Max)
	{
		ACWPlayerController* LocalPC = Cast<ACWPlayerController>(GetWorld()->GetFirstPlayerController());
		bool bWin = nullptr != LocalPC && GetWinCamp() == LocalPC->GetCampTag();
		return bWin ? ECWBattleResult::Win : ECWBattleResult::Lost;
	}
	return ECWBattleResult::Draw;
}

ECWPawnMoveMode ACWGameState::GetPawnMoveMode()
{
	return PawnMoveMode;
}

void ACWGameState::SetPawnMoveMode(ECWPawnMoveMode ParamPawnMoveMode)
{
	PawnMoveMode = ParamPawnMoveMode;
}

bool ACWGameState::IsPauseGame() const
{
	return bPauseGame;
}

int32 ACWGameState::GetWeatherIdx() const
{
	return CurWeatherIdx;
}

int32 ACWGameState::GetOldWeatherIdx() const
{
	return OldWeatherIdx;
}

int32 ACWGameState::GetNextWeatherIdx() const
{
	return NextWeatherIdx;
}

int32 ACWGameState::GetDefaultPawnCnt() const
{
	// 初始化默认出生棋子数
	int32 RetValue = 4;
	if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("DefaultPawnCnt")))
	{
		const int32 NewDefaultPawnCnt = FSTRING_TO_INT(ConstData->Param);
		RetValue = (NewDefaultPawnCnt > 0) ? NewDefaultPawnCnt : RetValue;
	}
	return RetValue;
}

int32 ACWGameState::GetMinStagePawnCnt() const
{
	return 1;
}

int32 ACWGameState::GetMaxStagePawnCnt() const
{
	return 5;
}

void ACWGameState::ExecWeatherCheckInServer()
{
	// random weather idx
	OldWeatherIdx = CurWeatherIdx;
	CurWeatherIdx = NextWeatherIdx;
	int32 NewNextWeatherIdx = UCWWeatherMgr::GenerateWeatherIdx(CurRoundIndex);
	if (UCWWeatherMgr::IsValidWeatherIdx(NewNextWeatherIdx))
	{
		NextWeatherIdx = NewNextWeatherIdx;
	}

	// 不相同执行天气对棋子影响
	if (OldWeatherIdx != CurWeatherIdx)
	{
		// update all pawn property
		UWorld* const MyWorld = GetWorld();
		for (TActorIterator<ACWPawn> Iter(MyWorld); Iter; ++Iter)
		{
			ACWPawn* GPawn = *Iter;
			if (IsValid(GPawn) && GPawn->IsPawnType(ECWPawnType::Character))
			{
				GPawn->ReceiveWeatherAffect();
			}
		}
	}

	// 执行天气元素交互(每回合执行)
	const FCWWeatherData* WeatherData = FCWCfgUtils::GetWeatherData(this, CurWeatherIdx);
	if (nullptr != WeatherData && FElemUtils::IsValidObjElemType(WeatherData->OwnElemType))
	{
		CWG_WARNING(">> %s::ExecWeatherCheckInServer, Exec ElemSysReaction WeatherInfo[%s].", *GetName(), *WeatherData->ToDebugString());

		TArray<ACWPawn*> AllPawns;
		UCWFuncLib::GetAllActors<ACWPawn>(this, AllPawns);
		for (int32 i = 0; i < AllPawns.Num(); ++i)
		{
			ACWPawn* GamePawn = AllPawns[i];
			if (IsValid(GamePawn) && GamePawn->IsPawnType(ECWPawnType::Character))
			{	// 计算元素反应
				UCWBattleCalculate::Get()->CalculateElemReaction(WeatherData->OwnElemType, GamePawn, ECWBuffSouceType::WeatherSys);
			}
		}
	}
}

void ACWGameState::SetMaxReadyTime(const float InValue)
{
	MaxReadyTime = InValue;
}

float ACWGameState::GetMaxReadyTime()
{
	return MaxReadyTime;
}

void ACWGameState::SetMaxActionTime(const float InValue)
{
	MaxActionTime = InValue;
}

float ACWGameState::GetMaxActionTime()
{
	return MaxActionTime;
}

void ACWGameState::SetCampANum(int campANum)
{
	CampANum = campANum;
}

void ACWGameState::SetCampBNum(int campBNum)
{
	CampBNum = campBNum;
}

int32 ACWGameState::GetCampANum()
{
	return CampANum;
}

int32 ACWGameState::GetCampBNum()
{
	return CampBNum;
}

const TArray<FCWPlayerNetData>& ACWGameState::GetPlayerDataArray()
{
	return PlayerDataArray;
}

void ACWGameState::AddPlayerDataToArray(FCWPlayerNetData InPlayerData)
{
	PlayerDataArray.AddUnique(InPlayerData);
}

bool ACWGameState::ServerSetPauseGame_Validate(bool bNewPause)
{
	return true;
}

void ACWGameState::ServerSetPauseGame_Implementation(bool bNewPause)
{
	bPauseGame = bNewPause;
}

void ACWGameState::ServerPlayerReadyStateChange(ACWPlayerController* Player, bool bReadyOk)
{
	if (nullptr != Player)
	{
		if (bReadyOk)
		{
			CurNetPlayerReadyArr.AddUnique(Player);
		}
		else
		{
			CurNetPlayerReadyArr.Remove(Player);
		}
		NetMulticastReadyStateChange(Player->GetPlayerId(), bReadyOk);
	}
}

int32 ACWGameState::GetCurReadyOkPlayerCnt() const
{
	return CurNetPlayerReadyArr.Num();
}

void ACWGameState::NetMulticastReadyStateChange_Implementation(int32 Pid, bool bReadyOk)
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnRoleReadyStateChange.Broadcast(Pid, bReadyOk);
	}
}

void ACWGameState::NetMulticastLevelSiteDrop_Implementation(const bool bStarted, const int32 InFallIdx)
{
	CWG_LOG("[%s] >> %s::NetMulticastLevelSiteDrop, bStarted[%s].", *NETMODE_TO_STRING(GetNetMode()), *GetName(), *BOOL_TO_FSTRING(bStarted));
#if WITH_EDITOR || !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer))
	{
		if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			EvtMgr->OnLevelSiteDrop.Broadcast(bStarted, InFallIdx);
		}
	}
#endif
}

void ACWGameState::OnRep_CurNetPlayerCount()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnNetPlayerCountChange.Broadcast(CurNetPlayerCount);
	}
}

void ACWGameState::OnRep_BattleStateChangedInClient()
{
	if (OldBattleState != CurBattleState)
	{
		OnBattleStateChangedEventInClient.Broadcast(OldBattleState, CurBattleState);
	}
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnBattleStateChange.Broadcast(OldBattleState, CurBattleState);
	}
}

void ACWGameState::OnRep_ClientRoundCamp()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnRoundCampChange.Broadcast(CurCampTag, CurCampControllerIndex);
	}
}

void ACWGameState::OnRep_ClientRoundTime()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnRoundRemainTimeChange.Broadcast(CurActionRemainTime);
	}
}

void ACWGameState::OnRep_ReadyRemainTime()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnReadyRemainTimeChange.Broadcast(CurReadyRemainTime);
	}
}

void ACWGameState::OnRep_RoundIndex()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnRoundIndexChangeInClient.Broadcast(CurRoundIndex, 0);
	}

	if (IsFallWarningInClient())
	{
		FallWarningInClient();
	}
}

int32 ACWGameState::GetGameId()
{
	for (TActorIterator<ACWGameInfo> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWGameInfo* GameInfo = *Iter;
		check(GameInfo != nullptr);
		return GameInfo->GetGameId();
		break;
	}

	return 0;
}

bool ACWGameState::IsFallWarningInClient()
{
	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	if (CurDungeonTileFallIndex >= TempGameData->DungeonTileFallCountMax)
		return false;

	check(TempGameData->FirstDungeonTileFallRoundIndex > 0);
	if (CurRoundIndex+1 == TempGameData->FirstDungeonTileFallRoundIndex)
	{
		return true;
	}
	else if (CurRoundIndex+1 > TempGameData->FirstDungeonTileFallRoundIndex)
	{
		int32 TempIndex = CurRoundIndex + 1 - TempGameData->FirstDungeonTileFallRoundIndex;
		check(TempGameData->DungeonTileFallRoundInterval > 0);
		if (TempIndex % TempGameData->DungeonTileFallRoundInterval == 0)
		{
			return true;
		}
	}

	return false;
}

void ACWGameState::FallWarningInClient()
{
	// 地块预警掉落开始
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnLevelDropEarlyWarnClient.Broadcast(true, CurDungeonTileFallIndex);
	}

	for (TActorIterator<ACWRandomDungeonGenerator> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWRandomDungeonGenerator* DungeonGenerator = *Iter;
		check(DungeonGenerator != nullptr);
		DungeonGenerator->DungeonFallWarningInClient(CurDungeonTileFallIndex);
		break;
	}
}

void ACWGameState::OnRep_DungeonTileFallIndex()
{
	
}

void ACWGameState::OnRep_WeatherIdx(int32 InOldWeatherIdx)
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnWeatherIdxChange.Broadcast((ECWWeatherType)CurWeatherIdx, (ECWWeatherType)InOldWeatherIdx);
	}
}

void ACWGameState::OnRep_NextWeatherIdx()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnNextWeatherIdxChange.Broadcast((ECWWeatherType)NextWeatherIdx);
	}
}

void ACWGameState::OnRep_CampANum()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this)) {
		EvtMgr->OnCampANumChange.Broadcast((int32)CampANum);
	}
}

void ACWGameState::OnRep_CampBNum()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this)) {
		EvtMgr->OnCampBNumChange.Broadcast((int32)CampBNum);
	}
}

void ACWGameState::OnRep_ClientPawnMoveMode()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnGamePlayerRateChange.Broadcast((int32)PawnMoveMode);
	}
}

void ACWGameState::OnRep_PlayerDataArray()
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnPlayerDataArrayChange.Broadcast();
	}
}

