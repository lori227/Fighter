
#include "CWStructDefine.h"

#include "CWComDef.h"
#include "CWCommonUtil.h"


bool FBattlePropertyData::IsValid() const
{
	return PropertyKey != ECWBattleProperty::None && (PropertyValue != 0.f || PropertyFactor != 0.f);
}

FString FBattlePropertyData::ToString() const
{
	FString OutStr;
	if (IsValid())
	{
		if (PropertyFactor != 0.f)
		{
			int32 Value = PropertyFactor * 100;
			FString Symbol = Value > 0 ? TEXT("+") : TEXT("");
			OutStr += Symbol + INT_TO_FSTRING(Value) + TEXT("%");
		}
		if (PropertyValue != 0.f)
		{
			FString Symbol = PropertyValue > 0 ? TEXT("+") : TEXT("");
			OutStr += Symbol + INT_TO_FSTRING(FMath::FloorToInt(PropertyValue));
		}
	}
	return OutStr;
}

FLinearColor FCWFlyWorldsNumber::GetFlyWorldsColor(float InNewAlpha)
{
	FLinearColor RetColor = REDHUDCOLOR;

	ECWFlyWordsType MyFlyWordsType = (ECWFlyWordsType)FlyWorldsType;
	switch (MyFlyWordsType)
	{
	case FMT_ReplyComm:
	case FMT_ReplyHp:
	case FMT_ReplySp:
	case FMT_ReplyBuff:
	{
		RetColor = FLinearColor::Green;
	}break;
	case FMT_DamageComm:
	case FMT_DamageRefrain:
	case FMT_DamageCRI:
	{

	}break;
	case FMT_StateAbnormal:
	{
		RetColor = BLUEHUDCOLOR;
	}break;
	case FMT_StateMiss:
	{
		RetColor = GOLDCOLOR;
	}break;
	}

	RetColor.A = InNewAlpha;
	return RetColor;
}

FString FCWToString::ToString(const ECWBattleProperty InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWBattleProperty"), InEnumType);
}

FString FCWToString::ToString(const ECWBattlePropertyModifyOp InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWBattlePropertyModifyOp"), InEnumType);
}

FString FCWToString::ToString(const ECWPropertyAffectorDataAffectType InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWPropertyAffectorDataAffectType"), InEnumType);
}

FString FCWToString::ToString(const ECWBuffSouceType InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWBuffSouceType"), InEnumType);
}

FString FCWToString::ToString(const ECWPawnActionState InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWPawnActionState"), InEnumType);
}

FString FCWToString::ToString(const ECWSkillSouceType InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWSkillSouceType"), InEnumType);
}

FString FCWToString::ToString(const ECWPawnInputState InEnumType)
{
	return FCWCommonUtil::EnumToString(TEXT("ECWPawnInputState"), InEnumType);
}

bool FCWTerrainPropertyData::IsValid() const
{
	return false;
}

FString FCWTerrainPropertyData::ToString() const
{
	return TEXT("");
}

FIntFringe::FIntFringe()
	: IntParam(INDEX_NONE)
{
}

FIntFringe::FIntFringe(const FIntVector& InBeginPoint, 
	const FIntVector& InEndPoint, const int32 InIntParam, const FString& InStrParam)
	: BeginPoint(InBeginPoint)
	, EndPoint(InEndPoint)
	, StringParam(InStrParam)
	, IntParam(InIntParam)
{
}

FIntFringe::FIntFringe(const FIntFringe& InOther)
{
	operator=(InOther);
}

FIntFringe& FIntFringe::operator=(const FIntFringe& InOther)
{
	if (this != &InOther)
	{
		IntParam = InOther.IntParam;
		StringParam = InOther.StringParam;
		BeginPoint = InOther.BeginPoint;
		EndPoint = InOther.EndPoint;
	}
	return *this;
}

bool FIntFringe::operator==(const FIntFringe& InOther)
{
	return IntParam == InOther.IntParam && StringParam == InOther.StringParam &&
		BeginPoint == InOther.BeginPoint && EndPoint == InOther.EndPoint;
}

bool operator==(const FIntFringe& InLeft, const FIntFringe& InRight)
{
	return InLeft.IntParam == InRight.IntParam && InLeft.StringParam == InRight.StringParam &&
		InLeft.BeginPoint == InRight.BeginPoint && InLeft.EndPoint == InRight.EndPoint;
}

bool FIntFringe::IsValid() const
{
	return IntParam != INDEX_NONE;
}

FString FIntFringe::ToString() const
{
	return FString::Printf(TEXT("BeginPoint[%s] EndPoint[%s] IntParam[%d] StringParam[%s]"), *BeginPoint.ToString(), *EndPoint.ToString(), IntParam, *StringParam);
}

bool FIntFringe::IsNearPointXY(const FIntFringe& InOther, int32 ErrorTolerance) const
{
	const bool bNearX = FMath::Abs<int32>(EndPoint.X - InOther.BeginPoint.X) <= ErrorTolerance;
	const bool bNearY = FMath::Abs<int32>(EndPoint.Y - InOther.BeginPoint.Y) <= ErrorTolerance;
	return bNearX && bNearY;
}
