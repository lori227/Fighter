﻿#include "CWGameDataStruct.h"

FCWGameDataStruct::FCWGameDataStruct()
	: GameId(0)
	, DungeonId(0)
	, FirstDungeonTileFallRoundIndex(0)
	, DungeonTileFallRoundInterval(0)
	, DungeonTileFallCountMax(0)
	, DungeonTileFallInterval(0.f)
	, DungeonTileRiseBeginZ(0.f)
	, DungeonTileRiseBeginSpeed(0.f)
	, DungeonTileRiseDeceleration(0.f)
	, SafeAreaMinX(0)
	, SafeAreaMinY(0)
	, SafeAreaMaxX(0)
	, SafeAreaMaxY(0)
	, EachRoundFallNum(0)
{
}

FCWGameDataStruct::~FCWGameDataStruct()
{
}
