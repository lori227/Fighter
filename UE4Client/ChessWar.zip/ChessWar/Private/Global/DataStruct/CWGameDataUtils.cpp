#include "CWGameDataUtils.h"

std::vector<float> FCWGameDataUtils::GetArrayDungeonTileRiseRandomMinMaxFromString(const FString& ParamString)
{
	std::vector<float> ArrayDungeonTileRiseRandomMinMax;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempRandom = FCString::Atof(*TempString);
		ArrayDungeonTileRiseRandomMinMax.push_back(TempRandom);
	}

	return ArrayDungeonTileRiseRandomMinMax;
}
