﻿
#include "CWGMEmptyServer.h"

#include "GameFramework/GameSession.h"

#include "CWComDef.h"


ACWGMEmptyServer::ACWGMEmptyServer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	// Hard travel into the next game mode, we don't want to seamless travel or any connecting clients might find themselves here
	bUseSeamlessTravel = false;
}

ACWGMEmptyServer::~ACWGMEmptyServer()
{
}

void ACWGMEmptyServer::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	CWG_LOG(">> %s::InitGame, Enter EmptyServer.", *GetName());

	// TODO: Notice world server cur progress is empty

}

void ACWGMEmptyServer::InitGameState()
{
	Super::InitGameState();

	if (GameSession != nullptr && IsDedicatedServer())
	{
		GameSession->RegisterServer();
	}
}