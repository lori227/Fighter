﻿
#include "CWGMLogin.h"


ACWGMLogin::ACWGMLogin(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	GameModeDateBase.GameStage = ECWGameStage::Login;
}

void ACWGMLogin::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);
}
