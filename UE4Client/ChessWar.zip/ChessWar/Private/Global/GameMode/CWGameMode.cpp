﻿
#include "CWGameMode.h"

#include "Engine/World.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWAIPawn.h"
#include "CWCfgUtils.h"
#include "CWGameState.h"
#include "CWCharacter.h"
#include "CWGameInfo.h"
#include "CWBattleFSM.h"
#include "CWPlayerState.h"
#include "CWCfgManager.h"
#include "CWAIPawnPath.h"
#include "CWCommonUtil.h"
#include "CWFSMTranstion.h"
#include "CWAssetDefine.h"
#include "CWGameInstance.h"
#include "CWClientConstData.h"
#include "CWGameDataStruct.h"
#include "CWBattleCalculate.h"
#include "CWBattlePauseState.h"
#include "CWPlayerController.h"
#include "CWBattleReadyState.h"
#include "CWBattleResultEvent.h"
#include "CWBattleFightingFSM.h"
#include "CWDungeonDataStruct.h"
#include "CWCameraMoveVolume.h"
#include "CWCameraBlockVolume.h"
#include "CWBattleGungeonState.h"
#include "CWBattleToReadyEvent.h"
#include "CWBattleFightingState.h" 
#include "CWBattleSettlementState.h" 
#include "CWRandomDungeonGenerator.h"
#include "CWBattleFightingNormalState.h"
#include "CWBattleFightingToNormalEvent.h"
#include "CWBattleFightingNoRunningState.h"
#include "CWBattleFightingWaitingEndState.h"
#include "CWBattleFightingToWaitingEndEvent.h"
#include "CWBattleWaitingLoadingGungeonState.h"
#include "CWBattleFightingWaitingDungeonTileFallState.h"
#include "CWBattleFightingToWaitingDungeonTileFallEvent.h"
#include "ClientMessage.pb.h"
#include "FrameServerMessage.pb.h"
#include "ServerMessage.pb.h"
#include "CWNetMessage.h"
#include "CWUtils.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWGameMode, All, All);

ACWGameMode* ACWGameMode::s_this = nullptr;

ACWGameMode::ACWGameMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, NetPawnUniqueIdxGenerater(0)
{
	PrimaryActorTick.bCanEverTick = true;

	DefaultPawnClass = ACWCharacter::StaticClass();
	PlayerControllerClass = ACWPlayerController::StaticClass();
	PlayerStateClass = ACWPlayerState::StaticClass();
	GameStateClass = ACWGameState::StaticClass();

	NetPlayerUniqueIdGenerater = 0;

	bIsCreated = false;
	GameModeDateBase.GameStage = ECWGameStage::Battle;

	RunningHeartbeatTime = 0.0f;

	s_this = this;
}
void ACWGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	LoadConfig();

	SetupBattleFSM();
	SetupBattleFightingFSM();

	UCWGameInstance::GetInstance()->GetTCPServerClient()->SetReceiveMessageCallbackFn(&ACWGameMode::ProcessReceiveMessage);
}

void ACWGameMode::PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage)
{
	Super::PreLogin(Options, Address, UniqueId, ErrorMessage);
}

APlayerController* ACWGameMode::Login(UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage)
{
	APlayerController* NewPlayerController = Super::Login(NewPlayer, InRemoteRole, Portal, Options, UniqueId, ErrorMessage);
	CWG_LOG(">>Login, Options[%s].", *Options);
	FString InPlayerId = UGameplayStatics::ParseOption(Options, TEXT("Pid"));
	ACWPlayerController* TempPlayerController = (ACWPlayerController*)NewPlayerController;
	TempPlayerController->SetPeripheralNetId(InPlayerId);
	return NewPlayerController;
}

void ACWGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);

	int32 CurNetPlayerCount = GetGameState<ACWGameState>()->GetCurNetPlayerCount();
	CurNetPlayerCount++;
	GetGameState<ACWGameState>()->SetCurNetPlayerCount(CurNetPlayerCount);
	if (CurNetPlayerCount >= NetPlayerCount)
	{
		SetupGameStateParams();

		ACWGameState* MyGameState = GetWorld()->GetGameState<ACWGameState>();
		TScriptDelegate<> MyDelegate;
		MyDelegate.BindUFunction(this, FName("RespondBattleStateChangedEventInServer"));
		MyGameState->OnBattleStateChangedEventInServer.AddUnique(MyDelegate);
		//MyGameState->OnBattleStateChangedEventInServer.__Internal_AddUniqueDynamic(this, &ACWGameMode::RespondBattleStateChangedEventInServer, FName("RespondBattleStateChangedEventInServer"));

		//网络玩家到齐，进入战前准备
		BattleFSM->Startup((int)ECWBattleState::Dungeon);

		// 生成关卡动态对象
		GenerateLevelMsicObj();
	}
}

bool ACWGameMode::ProcessReceiveMessage(UCWNetMessage* ParamNetMsg)
{
	check(s_this);
	s_this->DoNetMessage(ParamNetMsg);
	return true;
}

UClass* ACWGameMode::GetDefaultPawnClassForController_Implementation(AController * InController)
{
	return DefaultPawnClass;
}

AActor* ACWGameMode::ChoosePlayerStart_Implementation(AController * Player)
{
	return nullptr;
}

void ACWGameMode::Logout(AController* Exiting)
{
	int32 CurNetPlayerCount = GetGameState<ACWGameState>()->GetCurNetPlayerCount();
	CurNetPlayerCount--;
	GetGameState<ACWGameState>()->SetCurNetPlayerCount(CurNetPlayerCount);

	if (CurNetPlayerCount <= 0)
	{
		uint64 TempRoomId = UCWGameInstance::GetInstance()->GetRoomId();

		KFMsg::S2SFinishRoomToRoomReq req;
		req.set_roomid(TempRoomId);
		UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_FINISH_ROOM_TO_ROOM_REQ, &req);
		UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::Logout req, msgid:%d."), KFMsg::S2S_FINISH_ROOM_TO_ROOM_REQ);
	}

	Super::Logout(Exiting);
}

void ACWGameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (BattleFSM != nullptr)
	{
		BattleFSM->Tick(DeltaSeconds);
	}

	if (BattleFightingFSM != nullptr)
	{
		BattleFightingFSM->Tick(DeltaSeconds);
	}

	RunningHeartbeatTime += DeltaSeconds;
	if (RunningHeartbeatTime >= 30.0f)
	{
		HearbeatToServer();
		RunningHeartbeatTime = 0.0f;
	}
}

void ACWGameMode::StartPlay()
{
	Super::StartPlay();

	KFMsg::S2SOpenRoomToRoomAck ack;
	ack.set_roomid(UCWGameInstance::GetInstance()->GetRoomId());
	ack.set_result(true);
	UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
	UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::StartPlay, SendToRand msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
}

void ACWGameMode::Destroyed()
{
	// 销毁
	if (nullptr != BattleFSM)
	{
		if (BattleFSM->IsRooted())
		{
			BattleFSM->RemoveFromRoot();
		}
		BattleFSM->ConditionalBeginDestroy();
		BattleFSM = nullptr;
	}
	if (nullptr != BattleFightingFSM)
	{
		if (BattleFightingFSM->IsRooted())
		{
			BattleFightingFSM->RemoveFromRoot();
		}
		BattleFightingFSM->ConditionalBeginDestroy();
		BattleFightingFSM = nullptr;
	}

	if (UCWGameInstance::GetInstance() != nullptr && UCWGameInstance::GetInstance()->GetTCPServerClient() != nullptr)
	{
		UCWGameInstance::GetInstance()->GetTCPServerClient()->SetReceiveMessageCallbackFn(nullptr);
	}

	Super::Destroyed();
}

void ACWGameMode::OnPlayerLoginBegin(APlayerController* NewPlayer, const FString& Options)
{
	ACWPlayerController* NewPC = Cast<ACWPlayerController>(NewPlayer);
	if (nullptr == NewPC)
	{
		return;
	}

	int32 UniqueId = GenerateNetPlayerUniqueId();
	NewPC->SetNetPlayerUniqueId(UniqueId);

	ECWCampTag TempCampTag = ECWCampTag::None;
	ECWCampControllerIndex TempCampControllerIndex = ECWCampControllerIndex::None;
	if (UniqueId == 1)
	{
		TempCampTag = ECWCampTag::A;
		TempCampControllerIndex = ECWCampControllerIndex::One;
	}
	else if (UniqueId == 2)
	{
		TempCampTag = ECWCampTag::B;
		TempCampControllerIndex = ECWCampControllerIndex::One;
	}
	else
	{
		TempCampTag = ECWCampTag::None;
		TempCampControllerIndex = ECWCampControllerIndex::None;
		return;
	}

	ACWPlayerState* PlayerState = Cast<ACWPlayerState>(NewPC->PlayerState);
	check(PlayerState);
	PlayerState->SetCampTag(TempCampTag);
	PlayerState->SetCampControllerIndex(TempCampControllerIndex);

	if (!bIsCreated)
	{
		const FCWGameDataStruct* TempGameData = GetGameDataStruct();
		for (TActorIterator<ACWRandomDungeonGenerator> Iter(GetWorld()); Iter; ++Iter)
		{
			RandomDungeonGenerator = *Iter;
			check(RandomDungeonGenerator != nullptr);
			RandomDungeonGenerator->Init(TempGameData->DungeonId);

			FCWDungeonDataStruct* TempDungeonData = RandomDungeonGenerator->GetDungeonData();
			for (TActorIterator<ACWMap> Iter2(GetWorld()); Iter2; ++Iter2)
			{
				ACWMap* TempMap = *Iter2;
				check(TempMap != nullptr);
				TempMap->init(TempDungeonData->DungeonId);
				TempMap->createMapForServer();
				TempMap->ForceNetUpdate();
				break;
			}

			TScriptDelegate<> MyDelegate1;
			MyDelegate1.BindUFunction(this, FName("RespondDungeonTileFallFinishInServer"));
			RandomDungeonGenerator->OnDungeonTileFallFinishEventInServer.AddUnique(MyDelegate1);
			break;
		}
		bIsCreated = true;
	}

	NewPC->ClientOnPlayerLoginBegin();
	CWG_LOG(">> Login Player [Begin]: Pid[%d], UniqueId[%d].", NewPC->GetPlayerId(), UniqueId);
}

void ACWGameMode::OnPlayerLoginCompleted(APlayerController* NewPlayer)
{
	ACWPlayerController* NewPC = Cast<ACWPlayerController>(NewPlayer);
	if (nullptr == NewPC)
	{
		return;
	}

	NewPC->InitInServer();
	const FCWGameDataStruct* TempGameData = GetGameDataStruct();
	FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), TempGameData->DungeonId);
	NewPC->SetDungeonId(TempDungeonData->DungeonId);

	NewPC->ClientOnPlayerLoginCompleted(GameModeDateBase);
	CWG_LOG(">> Login Player [Complet]: Pid[%d], UniqueId[%d].", NewPC->GetPlayerId(), NewPC->GetUniqueId());
}

UCWGameInstance* ACWGameMode::GetCWGameInstance()
{
	if (GetGameInstance())
	{
		UGameInstance* p = GetGameInstance();
		return Cast<UCWGameInstance>(p);
	}
	return nullptr;
}

void ACWGameMode::LoadConfig()
{
	GConfig->GetInt(TEXT("/Script/CWGameMode"), TEXT("NetPlayerCount"), NetPlayerCount, GGameIni);
	GConfig->GetInt(TEXT("/Script/CWGameMode"), TEXT("CampCount"), CampCount, GGameIni);
	GConfig->GetFloat(TEXT("/Script/CWGameMode"), TEXT("ReadyTime"), ReadyTime, GGameIni);
	GConfig->GetInt(TEXT("/Script/CWGameMode"), TEXT("TotalRoundCount"), TotalRoundCount, GGameIni);
	GConfig->GetFloat(TEXT("/Script/CWGameMode"), TEXT("ActionTime"), ActionTime, GGameIni);

	//---------------------
	//TODO:临时写死2个网络玩家
	NetPlayerCount = 2;
	//暂时写死阵营2个
	CampCount = 2;
	//暂时写死战前准备30秒
	ReadyTime = 1000.0f;
	//暂时写死此局总回合数30
	TotalRoundCount = 30;
	//暂时写死每回合30秒
	ActionTime = 3000.0f;
	//---------------------
}

void ACWGameMode::SetupGameStateParams()
{
	ACWGameState* MyGameState = GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyGameState->SetMaxReadyTime(ReadyTime);
		MyGameState->SetMaxActionTime(ActionTime);
		MyGameState->SetCurNetPlayerCount(NetPlayerCount);
		MyGameState->SetCurReadyRemainTime(ReadyTime);
	}
}

int32 ACWGameMode::GetGameId()
{
	ACWGameInfo* GameInfo = UCWFuncLib::GetActor<ACWGameInfo>(this);
	return IsValid(GameInfo) ? GameInfo->GetGameId() : INDEX_NONE;
}

int32 ACWGameMode::GenerateNetPlayerUniqueId()
{
	return ++NetPlayerUniqueIdGenerater;
}

int32 ACWGameMode::GenerateNetPawnUniqueIdx()
{
	return ++NetPawnUniqueIdxGenerater;
}

void ACWGameMode::GenerateGungeonTileFall()
{
	ACWRandomDungeonGenerator* TempRandomDungeonGenerator = GetRandomDungeonGenerator();
	if (TempRandomDungeonGenerator != nullptr)
	{
		if (TempRandomDungeonGenerator->GenerateDungeonFall())
		{
			int32 TempCurDungeonTileFallIndex = GetGameState<ACWGameState>()->GetCurDungeonTileFallIndex();
			if (TempCurDungeonTileFallIndex == 0)
			{
				//TempRandomDungeonGenerator->NetMulticastRPCDungeonDecorateFall();
			}

			TempCurDungeonTileFallIndex++;
			GetGameState<ACWGameState>()->SetCurDungeonTileFallIndex(TempCurDungeonTileFallIndex);

			OnLevelSiteDropStart();
		}
	}
}

void ACWGameMode::RefreshAllLocation()
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetRandomDungeonGenerator();
	if (TempDungeonGenerator != nullptr)
	{
		TempDungeonGenerator->RefreshAllLocationInServer();
	}
}

void ACWGameMode::SetupBattleFSM()
{
	BattleFSM = NewObject<UCWBattleFSM>();
	check(BattleFSM != nullptr);
	BattleFSM->AddToRoot();
	BattleFSM->Init(this);
	BattleFSM->AddState(new FCWBattleGungeonState(BattleFSM, (int)ECWBattleState::Dungeon));
	BattleFSM->AddState(new FCWBattleReadyState(BattleFSM, (int)ECWBattleState::Ready));
	BattleFSM->AddState(new FCWBattleFightingState(BattleFSM, (int)ECWBattleState::Fighting));
	BattleFSM->AddState(new FCWBattleSettlementState(BattleFSM, (int)ECWBattleState::Settlement));
	BattleFSM->AddState(new FCWBattlePauseState(BattleFSM, (int)ECWBattleState::Pause));
	BattleFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleState::Dungeon, (int)ECWBattleState::Ready));
	BattleFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleState::Ready, (int)ECWBattleState::Fighting));
	BattleFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleState::Fighting, (int)ECWBattleState::Settlement));
	BattleFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleState::Ready, (int)ECWBattleState::Pause));
	BattleFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleState::Fighting, (int)ECWBattleState::Pause));
}

void ACWGameMode::SetupBattleFightingFSM()
{
	BattleFightingFSM = NewObject<UCWBattleFightingFSM>();
	check(BattleFightingFSM != nullptr);
	BattleFightingFSM->AddToRoot();
	BattleFightingFSM->Init(this);
	BattleFightingFSM->AddState(new FCWBattleFightingNoRunningState(BattleFightingFSM, (int)ECWBattleFightingState::NoRunning));
	BattleFightingFSM->AddState(new FCWBattleFightingNormalState(BattleFightingFSM, (int)ECWBattleFightingState::Normal));
	BattleFightingFSM->AddState(new FCWBattleFightingWaitingEndState(BattleFightingFSM, (int)ECWBattleFightingState::WaitingEnd));
	BattleFightingFSM->AddState(new FCWBattleFightingWaitingDungeonTileFallState(BattleFightingFSM, (int)ECWBattleFightingState::WaitingDungeonTileFall));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::NoRunning, (int)ECWBattleFightingState::Normal));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::NoRunning, (int)ECWBattleFightingState::WaitingEnd));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::Normal, (int)ECWBattleFightingState::WaitingEnd));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::Normal, (int)ECWBattleFightingState::NoRunning));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::WaitingEnd, (int)ECWBattleFightingState::Normal));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::WaitingEnd, (int)ECWBattleFightingState::NoRunning));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::Normal, (int)ECWBattleFightingState::WaitingDungeonTileFall));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::WaitingEnd, (int)ECWBattleFightingState::WaitingDungeonTileFall));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::WaitingDungeonTileFall, (int)ECWBattleFightingState::Normal));
	BattleFightingFSM->AddTranstion(new FCWFSMTranstion((int)ECWBattleFightingState::WaitingDungeonTileFall, (int)ECWBattleFightingState::NoRunning));

	BattleFightingFSM->Startup((int)ECWBattleFightingState::NoRunning);
}

void ACWGameMode::SetupMapForServer()
{
	for (TActorIterator<ACWMap> Iter(GetWorld()); Iter; ++Iter)
	{
		BattleMap = *Iter;
		check(BattleMap != nullptr);
		const FCWGameDataStruct* TempGameData = GetGameDataStruct();
		FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), TempGameData->DungeonId);
		BattleMap->init(TempGameData->DungeonId);
		BattleMap->createMapForServer();
		//BattleMap->ForceNetUpdate();
		break;
	}
}

void ACWGameMode::SetupRandomGungeonForServer()
{
	for (TActorIterator<ACWRandomDungeonGenerator> Iter(GetWorld()); Iter; ++Iter)
	{
		RandomDungeonGenerator = *Iter;
		check(RandomDungeonGenerator);
		const FCWGameDataStruct* TempGameData = GetGameDataStruct();
		FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), TempGameData->DungeonId);

		if (TempDungeonData->DungeonGenerateMode == 1)
		{
			RandomDungeonGenerator->GenerateDungeon();
		}
		else if (TempDungeonData->DungeonGenerateMode == 2)
		{
			RandomDungeonGenerator->GenerateDungeon_2();
		}
		break;
	}
}

void ACWGameMode::SetupRandomGungeonForClient()
{
	for (TActorIterator<ACWRandomDungeonGenerator> Iter(GetWorld()); Iter; ++Iter)
	{
		RandomDungeonGenerator = *Iter;
		check(RandomDungeonGenerator != nullptr);
		//RandomDungeonGenerator->Init(GameData->DungeonId);
		//RandomDungeonGenerator->GenerateDungeon();
		break;
	}
}

int32 ACWGameMode::GetCampCount() const
{
	return CampCount;
}

float ACWGameMode::GetReadyTime() const
{
	return ReadyTime;
}

int32 ACWGameMode::GetTotalRoundCount() const
{
	return TotalRoundCount;
}

float ACWGameMode::GetActionTime() const
{
	return ActionTime;
}

ACWPlayerController* ACWGameMode::GetPlayerControllerByCampTagAndControllerIndex(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	for (TActorIterator<ACWPlayerController> iter(GetWorld()); iter; ++iter)
	{
		ACWPlayerController* TempPlayerController = *iter;
		if (TempPlayerController->GetCampTag() == ParamCampTag &&
			TempPlayerController->GetCampControllerIndex() == ParamCampControllerIndex)
		{
			return TempPlayerController;
		}
	}
	return nullptr;
}

void ACWGameMode::SetCampNum()
{
	int CampNum = 0;
	ACWGameState* MyGameState = GetGameState<ACWGameState>();
	for (TActorIterator<ACWPlayerController> iter(GetWorld()); iter; ++iter) 		
	{
		ACWPlayerController* TempPlayerController = *iter;
		TMap<FCWPawnKey, ACWPawn*> TempMapPawn = TempPlayerController->GetPawns();
		CampNum = TempMapPawn.Num();
		if (ECWCampTag:: A== TempPlayerController->GetCampTag())
		{
			MyGameState->SetCampANum(CampNum);
		}
		else if(ECWCampTag::B == TempPlayerController->GetCampTag())
		{
			MyGameState->SetCampBNum(CampNum);
		}
	}
}

void ACWGameMode::SomePlayerControllerForceActionEnd(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	ACWPlayerController* TempCurPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, ParamCampControllerIndex);
	if (TempCurPlayerController != nullptr)
	{
		check(BattleFSM);
		ECWBattleState CurBattleState = (ECWBattleState)(BattleFSM->GetCurrentStateId());
		if (CurBattleState == ECWBattleState::Fighting)
		{
			TempCurPlayerController->ForceActionEndInServer();

			this->ToWaitingEndState();

			//SomePlayerControllerActionEnd(TempCurPlayerController);
		}
		else
		{
			UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::SomePlayerControllerForceActionEnd. ParamCampTag:%d, ParamCampControllerIndex:%d, CurBattleState:%d."), (int)ParamCampTag, (int)ParamCampControllerIndex, (int)CurBattleState);
		}
	}
	else
	{
		UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::SomePlayerControllerForceActionEnd. ParamCampTag:%d, ParamCampControllerIndex:%d."), (int)ParamCampTag, (int)ParamCampControllerIndex);
	}
}

bool ACWGameMode::TryNext(ACWPlayerController* ParamPlayerController)
{
	check(ParamPlayerController);

	//判断相同阵营的所有控制器是否都行为结束
	if (IsSameCampAllControllerActionEnd(ParamPlayerController->GetCampTag()) &&
		IsSameCampAllControllerArrayActionEmpty(ParamPlayerController->GetCampTag()))
	{
		//相同阵营的所有控制器都行为结束
		if (!HandleRoundResult())
		{
			//判断是否所有阵营都行为结束
			if (IsAllCampActionEnd() && IsAllCampArrayActionEmpty())
			{
				//是所有阵营都行为结束
				TurnEnd();

				//开始下一回合
				NextTurn();
			}
			else
			{
				//不是所有阵营都行为结束

				//下一个阵营开始行为
				NextCampAction();
			}

			return true;
		}
		else
		{
			//结束了
			return false;
		}
	}
	else
	{
		//相同阵营的不是所有控制器都行为结束

		//相同阵营的下一个控制器开始行为
		//SameCampNextControllerAction(ParamPlayerController->GetCampTag());
		UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::TryNext. ParamCampTag:%d, ParamCampControllerIndex:%d."), (int)ParamPlayerController->GetCampTag(), (int)ParamPlayerController->GetCampControllerIndex());
		return false;
	}
}

void ACWGameMode::SomePlayerControllerDungeonEnd()
{
	if (IsAllCampDungeonEnd())
	{
		FCWBattleToReadyEvent* ToReadyEvent = new FCWBattleToReadyEvent((int)ECWBattleEvent::ToReady, (int)ECWBattleState::Ready, ECWFSMStackOp::Set);
		BattleFSM->DoEvent(ToReadyEvent);
	}
}


void ACWGameMode::SomePlayerControllerDieEnd(ACWPlayerController* ParamPlayerController)
{
	check(ParamPlayerController);

	//判断相同阵营的所有控制器是否都死结束
	if (IsSameCampAllControllerDieEnd(ParamPlayerController->GetCampTag()))
	{
		ECWCampTag TempWinCampTag = ECWCampTag::None;
		if (ParamPlayerController->GetCampTag() == ECWCampTag::A)
		{
			TempWinCampTag = ECWCampTag::B;
		}
		else if (ParamPlayerController->GetCampTag() == ECWCampTag::B)
		{
			TempWinCampTag = ECWCampTag::A;
		}
		else
		{
			UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::SomePlayerControllerDieEnd. ParamCampTag:%d, ParamCampControllerIndex:%d."), (int)ParamPlayerController->GetCampTag(), (int)ParamPlayerController->GetCampControllerIndex());
		}

		//进入结算
		check(BattleFSM);
		FCWBattleResultEvent* ResultEvent = new FCWBattleResultEvent((int)ECWBattleEvent::Result, (int)ECWBattleState::Settlement, ECWFSMStackOp::Set, TempWinCampTag);
		BattleFSM->DoEvent(ResultEvent);
	}
}

void ACWGameMode::CurWaitingEndPlayerControllerActionEnd()
{
	check(BattleFSM);
	ECWBattleState CurBattleState = (ECWBattleState)(BattleFSM->GetCurrentStateId());
	if (CurBattleState == ECWBattleState::Fighting)
	{
		FCWBattleFightingToNormalEvent* ToToNormalEvent = new FCWBattleFightingToNormalEvent((int)ECWBattleFightingEvent::ToNormal, (int)ECWBattleFightingState::Normal, ECWFSMStackOp::Set);
		BattleFightingFSM->DoEvent(ToToNormalEvent);

		//ACWPlayerController* ParamCurWaitingEndPlayerController = GetPlayerControllerByCampTagAndControllerIndex(CurWaitingEndCampTag, CurWaitingEndCampControllerIndex);
		//if (ParamCurWaitingEndPlayerController != nullptr)
		//{
		//	//SomePlayerControllerActionEnd(ParamCurWaitingEndPlayerController);
		//}
		//else
		//{
		//	UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::CurWaitingEndPlayerControllerActionEnd. CurWaitingEndCampTag:%d, CurWaitingEndCampControllerIndex:%d, CurBattleState:%d."), (int)CurWaitingEndCampTag, (int)CurWaitingEndCampControllerIndex, (int)CurBattleState);
		//}
		//
		//CurWaitingEndCampTag = ECWCampTag::None;
		//CurWaitingEndCampControllerIndex = ECWCampControllerIndex::None;
	}
	else
	{
		UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::CurWaitingEndPlayerControllerActionEnd. CurBattleState != ECWBattleState::Fighting, CurBattleState:%d."), (int)CurBattleState);
	}
	
}

void ACWGameMode::RespondBattleStateChangedEventInServer(const ECWBattleState& ParamOldBattleState, const ECWBattleState& ParamCurBattleState)
{
	UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::RespondBattleStateChangedEventInServer. OldBattleState:%d, CurBattleState:%d."), (int)ParamOldBattleState, (int)ParamCurBattleState);

	if (ParamOldBattleState == ECWBattleState::None && ParamCurBattleState == ECWBattleState::Dungeon)
	{
		//SetupMapForServer();
		SetupRandomGungeonForServer();

		OnBattleAfterSetupMapEventInServer.Broadcast();
	}
	else if (ParamOldBattleState == ECWBattleState::Dungeon && ParamCurBattleState == ECWBattleState::Ready)
	{
		RefreshAllLocation();
	}
}

void ACWGameMode::RespondDungeonTileFallFinishInServer(const int32 ParamCurDungeonTileFallIndex)
{
	GungeonTileFallEndAndNextTurnBegin();
}

void ACWGameMode::OnLevelSiteDropStart_Implementation()
{
#if WITH_EDITOR || UE_SERVER
	if (!IsNetMode(NM_Client))
	{
		if (ACWGameState* GS = GetGameState<ACWGameState>())
		{
			GS->NetMulticastLevelSiteDrop(true, GS->GetCurDungeonTileFallIndex());
		}
	}
#endif
}

void ACWGameMode::GenerateLevelMsicObj_Implementation()
{
	UWorld* MyWorld = GetWorld();
	ACWRandomDungeonGenerator* Generator = GetRandomDungeonGenerator();
	check(MyWorld && Generator);

	// 生成场景中心点
	FVector const SceneCenterPoint = Generator->GetSceneCenterPoint();

	// 生成怪物路径点
	FVector OutDownRight, OutDownLeft, OutTopRight, OutTopLeft;
	const FCWClientConstData* ConstData0 = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("AITargetExtNum"));
	int32 EdgeDiagonalNum = (nullptr != ConstData0) ? FSTRING_TO_INT(ConstData0->Param) : 5;	// 向外扩张格子数
	const bool bSpawnOk = Generator->GetEdgeDiagonalPoint(OutDownRight, OutDownLeft, OutTopRight, OutTopLeft, EdgeDiagonalNum);
	if (UClass* ClassAITarget = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_AITarget))
	{
		// 中心 + 四个对角
		const int32 MaxCnt = 4;
		FVector AITargets[MaxCnt] = { OutDownLeft, OutTopLeft, OutTopRight, OutDownRight };
		for (int32 Idx = INDEX_NONE; Idx < MaxCnt; ++Idx)
		{
			FVector NewLocation = (Idx <= INDEX_NONE) ? SceneCenterPoint : AITargets[Idx];
			if (ACWAIPawnPath* AIPawnPath = MyWorld->SpawnActor<ACWAIPawnPath>(ClassAITarget, NewLocation, FRotator::ZeroRotator))
			{
				AIPawnPath->SetPathIdx(Idx);
			}
		}
	}

	// 生成怪物
	if (UClass* ClassAIPawn = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_AIPawn))
	{
		FVector NewLocation(OutDownLeft.X + 500.f, OutDownLeft.Y - 500.f, OutDownLeft.Z);
		ACWAIPawn* AIPawn = MyWorld->SpawnActor<ACWAIPawn>(ClassAIPawn, NewLocation, FRotator::ZeroRotator);
	}

	// 生成摄像机移动区域
	if (UClass* ClassMoveVolume = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_CameraMoveVolume))
	{
		if (ACWCameraMoveVolume* MoveVolume = MyWorld->SpawnActor<ACWCameraMoveVolume>(ClassMoveVolume, SceneCenterPoint, FRotator::ZeroRotator))
		{
			FVector SizeVector(2500.f, 2500.f, 10.f);
			if (bSpawnOk)
			{
				SizeVector.X = FMath::Abs(OutTopLeft.X - OutDownRight.X);
				SizeVector.Y = FMath::Abs(OutTopLeft.Y - OutDownRight.Y);
			}
			MoveVolume->SetBoxExtent(SizeVector);
		}
	}

	// 生成空气墙
	if (UClass* ClassBlockVolume = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_CameraBlockVolume))
	{
		FVector OutDownPoint, OutTopPoint, OutRightPoint, OutLeftPoint;
		const FCWClientConstData* ConstData1 = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("InvisibleWallExtNum"));
		int32 EdgeDirectionNum = (nullptr != ConstData1) ? FSTRING_TO_INT(ConstData1->Param) : 10;	// 向外扩张格子数
		if (Generator->GetEdgeDirectionPoint(OutDownPoint, OutTopPoint, OutRightPoint, OutLeftPoint, EdgeDirectionNum))
		{
			auto CreateCameraBlockVolume = [MyWorld, ClassBlockVolume](const FVector& InLoc, const FVector& InSize)
			{
				if (ACWCameraBlockVolume* Volume = MyWorld->SpawnActor<ACWCameraBlockVolume>(ClassBlockVolume, InLoc, FRotator::ZeroRotator))
				{
					Volume->SetBoxExtent(InSize);
				}
			};

			const float Width = FMath::Abs(OutRightPoint.X - OutLeftPoint.X) / 2.f;
			const float Height = FMath::Abs(OutDownPoint.Y - OutTopPoint.Y) / 2.f;

			CreateCameraBlockVolume(OutDownPoint, FVector(Width, 10.f, 50.f));
			CreateCameraBlockVolume(OutTopPoint, FVector(Width, 10.f, 50.f));
			CreateCameraBlockVolume(OutRightPoint, FVector(10.f, Height, 50.f));
			CreateCameraBlockVolume(OutLeftPoint, FVector(10.f, Height, 50.f));
		}
	}
}

void ACWGameMode::OnLevelSiteDropComplete_Implementation(const int32 Cycles /*= 1*/, const float ChangeDis /*= -126.0f*/)
{
#if WITH_EDITOR || UE_SERVER
	if (!IsNetMode(NM_Client))
	{
		if (ACWGameState* GS = GetGameState<ACWGameState>())
		{
			GS->NetMulticastLevelSiteDrop(false, GS->GetCurDungeonTileFallIndex());
		}

		auto FindCenterLocaltion = [this](FVector& OutLocation) -> bool
		{
			for (TActorIterator<ACWAIPawnPath> Iter(GetWorld()); Iter; ++Iter)
			{
				ACWAIPawnPath* AIPawnPath = *Iter;
				if (IsValid(AIPawnPath) && AIPawnPath->GetPathIdx() <= INDEX_NONE)
				{
					OutLocation = AIPawnPath->GetActorLocation();
					return true;
				}
			}
			return false;
		};

		FVector CenterLocaltion(0.0f);
		if (FindCenterLocaltion(CenterLocaltion))
		{
			for (TActorIterator<ACWAIPawnPath> Iter(GetWorld()); Iter; ++Iter)
			{
				ACWAIPawnPath* AIPawnPath = *Iter;
				if (IsValid(AIPawnPath) && AIPawnPath->IsValidPath())
				{
					FVector ALocation = AIPawnPath->GetActorLocation();
					FVector DirNormalize = (CenterLocaltion - ALocation).GetSafeNormal();
					//DirVectNormal.Z = 0.0f;
					ALocation -= DirNormalize * Cycles * ChangeDis;
					AIPawnPath->SetActorLocation(ALocation);
					CWG_LOG(">> %s::OnLevelSiteDropComplete, -> AIPawnPath Normalize[%s].", *GetName(), *DirNormalize.ToString());
				}
			}
		}
	}
#endif
}

bool ACWGameMode::DoNetMessage(const UCWNetMessage* Params)
{
	if (Params->NetHead.MsgId == KFMsg::S2S_ROUTE_MESSAGE_TO_CLIENT_ACK)
	{
		KFMsg::S2SRouteMessageToClientAck routeAck;
		routeAck.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		if (routeAck.msgid() == KFMsg::S2S_OPEN_ROOM_TO_BATTLE_REQ)
		{
			KFMsg::S2SOpenRoomToBattleReq req;
			req.ParseFromArray(routeAck.msgdata().c_str(), routeAck.msgdata().length());

			uint64 ReqRoomId = req.roomid();
			uint64 TempRoomId = UCWGameInstance::GetInstance()->GetRoomId();
			UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::DoNetMessage..., MsgId:%d, roomid:%s, matchid:%d, roomserverid:%d, hero_count:%d, TempRoomId:%s."), routeAck.msgid(), *FCWUtils::Uint642FString(ReqRoomId), req.matchid(), req.roomserverid(), req.pbplayer().size(), *FCWUtils::Uint642FString(TempRoomId));
			if (TempRoomId != 0)
			{
				if (TempRoomId != ReqRoomId)
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(ReqRoomId);
					ack.set_result(false);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::DoNetMessage false, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
				else
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(ReqRoomId);
					ack.set_result(true);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::DoNetMessage true, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
			}
		}
		else if (routeAck.msgid() == KFMsg::S2S_FINISH_ROOM_TO_BATTLE_ACK)
		{
			KFMsg::S2SFinishRoomToBattleAck ack;
			ack.ParseFromArray(routeAck.msgdata().c_str(), routeAck.msgdata().length());

			uint64 AckRoomId = ack.roomid();
			uint64 TempRoomId = UCWGameInstance::GetInstance()->GetRoomId();
			UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::DoNetMessage..., MsgId:%d, AckRoomId:%s, TempRoomId:%s."), routeAck.msgid(), *FCWUtils::Uint642FString(AckRoomId), *FCWUtils::Uint642FString(TempRoomId));
			if (TempRoomId != 0)
			{
				if (TempRoomId != AckRoomId)
				{
					KFMsg::S2SFinishRoomToRoomReq req;
					req.set_roomid(TempRoomId);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &req);
					UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::DoNetMessage TempRoomId != AckRoomId, TempRoomId:%s, AckRoomId:%s, msgid:%d."), *FCWUtils::Uint642FString(TempRoomId), *FCWUtils::Uint642FString(AckRoomId), KFMsg::S2S_FINISH_ROOM_TO_ROOM_REQ);
				}
				else
				{
					UCWFuncLib::CWGServerTravel(UCWGameInstance::GetInstance()->GetWorld(), TEXT("/Game/Levels/Server/ServerWaiting?Game=WaitServerGM"));
					UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::DoNetMessage, TempRoomId:%s, AckRoomId:%s, msgid:%d."), *FCWUtils::Uint642FString(TempRoomId), *FCWUtils::Uint642FString(AckRoomId), KFMsg::S2S_FINISH_ROOM_TO_ROOM_REQ);
					UE_LOG(LogCWGameMode, Log, TEXT("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`"));
				}
			}
		}
		else
		{
			if (Params->NetHead.MsgId != 0)
			{
				UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::DoNetMessage..., routeAck.msgid():%d"), routeAck.msgid());
			}
		}
	}
	else
	{
		if (Params->NetHead.MsgId != 0)
		{
			UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::DoNetMessage..., Params->NetHead.MsgId:%d"), Params->NetHead.MsgId);
		}
	}

	return true;
}

bool ACWGameMode::IsSameCampAllControllerActionEnd(ECWCampTag ParamCampTag)
{
	bool bIsSameCampAllControllerActionEnd = true;
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			if (!TempPlayerController->IsAllPawnActionEndInServer())
			{
				bIsSameCampAllControllerActionEnd = false;
				break;
			}
		}
	}

	return bIsSameCampAllControllerActionEnd;
}

bool ACWGameMode::IsSameCampAllControllerDungeonEnd(ECWCampTag ParamCampTag)
{
	bool bIsSameCampAllControllerDungeonEnd = true;
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			if (!TempPlayerController->IsDungeonEndInServer())
			{
				bIsSameCampAllControllerDungeonEnd = false;
				break;
			}
		}
	}

	return bIsSameCampAllControllerDungeonEnd;
}

bool ACWGameMode::IsSameCampAllControllerDieEnd(ECWCampTag ParamCampTag)
{
	bool bIsSameCampAllControllerDieEnd = true;
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			if (!TempPlayerController->IsAllPawnDieEndInServer())
			{
				bIsSameCampAllControllerDieEnd = false;
				break;
			}
		}
	}

	return bIsSameCampAllControllerDieEnd;
}

bool ACWGameMode::IsCampControllerActionEnd(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, ParamCampControllerIndex);
	if (TempPlayerController != nullptr)
	{
		return TempPlayerController->IsAllPawnActionEndInServer();
	}

	return true;
}

void ACWGameMode::SameCampNextControllerAction(ECWCampTag ParamCampTag)
{
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		if (!IsCampControllerActionEnd(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex))
		{
			ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
			if (TempPlayerController != nullptr)
			{
				GetGameState<ACWGameState>()->SetCurCampTag(ParamCampTag);
				GetGameState<ACWGameState>()->SetCurCampControllerIndex((ECWCampControllerIndex)CampControllerIndex);
				GetGameState<ACWGameState>()->SetCurActionRemainTime(this->GetActionTime());
				TempPlayerController->StartActionInServer();
				break;
			}
		}
	}
}

bool ACWGameMode::IsAllCampActionEnd()
{
	bool bIsAllCampActionEnd = true;
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerActionEnd((ECWCampTag)CampIndex))
		{
			bIsAllCampActionEnd = false;
			break;
		}
	}

	return bIsAllCampActionEnd;
}

bool ACWGameMode::IsAllCampDungeonEnd()
{
	bool bIsAllCampDungeonEnd = true;
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerDungeonEnd((ECWCampTag)CampIndex))
		{
			bIsAllCampDungeonEnd = false;
			break;
		}
	}

	return bIsAllCampDungeonEnd;
}

void ACWGameMode::NextTurn()
{
	ResetWhenNextTurnBeginInServer();

	int TempCurRoundIndex = GetGameState<ACWGameState>()->GetCurRoundIndex();
	TempCurRoundIndex++;
	GetGameState<ACWGameState>()->SetCurRoundIndex(TempCurRoundIndex);
	if (TempCurRoundIndex > TotalRoundCount)
	{
		ECWCampTag TempWinCampTag = ECWCampTag::None;

		//进入结算
		check(BattleFSM);
		FCWBattleResultEvent* ResultEvent = new FCWBattleResultEvent((int)ECWBattleEvent::Result, (int)ECWBattleState::Settlement, ECWFSMStackOp::Set, TempWinCampTag);
		BattleFSM->DoEvent(ResultEvent);
	}
	else
	{
		if (IsGungeonTileFallGenerate())
		{
			FCWBattleFightingToWaitingDungeonTileFallEvent* ToWaitingDungeonTileFallEvent = new FCWBattleFightingToWaitingDungeonTileFallEvent((int)ECWBattleFightingEvent::ToWaitingDungeonTileFall, (int)ECWBattleFightingState::WaitingDungeonTileFall, ECWFSMStackOp::Set);
			BattleFightingFSM->DoEvent(ToWaitingDungeonTileFallEvent);
		}
		else
		{
			GetGameState<ACWGameState>()->SetCurActionRemainTime(this->GetActionTime());
			SomeCampControllerFirstAction(ECWCampTag::A, ECWCampControllerIndex::One);
		}
	}
}

void ACWGameMode::GungeonTileFallEndAndNextTurnBegin()
{
	check(BattleFSM);
	ECWBattleState CurBattleState = (ECWBattleState)(BattleFSM->GetCurrentStateId());
	if (CurBattleState == ECWBattleState::Fighting)
	{
		FCWBattleFightingToNormalEvent* ToToNormalEvent = new FCWBattleFightingToNormalEvent((int)ECWBattleFightingEvent::ToNormal, (int)ECWBattleFightingState::Normal, ECWFSMStackOp::Set);
		BattleFightingFSM->DoEvent(ToToNormalEvent);

		GetGameState<ACWGameState>()->SetCurActionRemainTime(this->GetActionTime());
		SomeCampControllerFirstAction(ECWCampTag::A, ECWCampControllerIndex::One);

		OnLevelSiteDropComplete();
	}
	else
	{
		UE_LOG(LogCWGameMode, Error, TEXT("ACWGameMode::GungeonTileFallEndAndNextTurnBegin. CurBattleState:%d."), (int)CurBattleState);
	}
}

void ACWGameMode::TurnEnd()
{
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		SameCampAllControllerTurnEnd((ECWCampTag)CampIndex);
	}
}

UCWBattleFSM* ACWGameMode::GetBattleFSM()
{
	return BattleFSM;
}

UCWBattleFightingFSM* ACWGameMode::GetBattleFightingFSM()
{
	return BattleFightingFSM;
}

void ACWGameMode::ToWaitingEndState()
{
	FCWBattleFightingToWaitingEndEvent* ToWaitingEndEvent = new FCWBattleFightingToWaitingEndEvent((int)ECWBattleFightingEvent::ToWaitingEnd, (int)ECWBattleFightingState::WaitingEnd, ECWFSMStackOp::Set);
	BattleFightingFSM->DoEvent(ToWaitingEndEvent);
}


void ACWGameMode::NextCampAction()
{
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerActionEnd((ECWCampTag)CampIndex))
		{
			SameCampNextControllerAction((ECWCampTag)CampIndex);
			break;
		}
	}
}

void ACWGameMode::SomeCampControllerFirstAction(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex((ECWCampTag)ParamCampTag, (ECWCampControllerIndex)ParamCampControllerIndex);
	if (TempPlayerController != nullptr)
	{
		GetGameState<ACWGameState>()->SetCurCampTag(ParamCampTag);
		GetGameState<ACWGameState>()->SetCurCampControllerIndex((ECWCampControllerIndex)ParamCampControllerIndex);
		TempPlayerController->StartActionInServer();
	}
	else
	{
		UE_LOG(LogCWGameMode, Log, TEXT("ACWGameMode::SomeCampControllerFirstAction. ParamCampTag:%d, ParamCampControllerIndex:%d."), (int)ParamCampTag, (int)ParamCampControllerIndex);
	}
}

bool ACWGameMode::IsGungeonTileFallGenerate()
{
	int32 TempCurRoundIndex = GetGameState<ACWGameState>()->GetCurRoundIndex();
	int32 TempCurDungeonTileFallIndex = GetGameState<ACWGameState>()->GetCurDungeonTileFallIndex();
	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);

	if (TempCurDungeonTileFallIndex >= TempGameData->DungeonTileFallCountMax)
		return false;

	check(TempGameData->FirstDungeonTileFallRoundIndex > 0);
	if (TempCurRoundIndex == TempGameData->FirstDungeonTileFallRoundIndex)
	{
		return true;
	}
	else if (TempCurRoundIndex > TempGameData->FirstDungeonTileFallRoundIndex)
	{
		check(TempGameData->DungeonTileFallRoundInterval > 0);
		int32 TempIndex = TempCurRoundIndex - TempGameData->FirstDungeonTileFallRoundIndex;
		if (TempIndex % TempGameData->DungeonTileFallRoundInterval == 0)
		{
			return true;
		}
	}

	return false;
}

ACWRandomDungeonGenerator* ACWGameMode::GetRandomDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
}

bool ACWGameMode::IsAllCampArrayActionEmpty()
{
	bool bIsAllCampArrayActionEmpty = true;
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerArrayActionEmpty((ECWCampTag)CampIndex))
		{
			bIsAllCampArrayActionEmpty = false;
			break;
		}
	}

	return bIsAllCampArrayActionEmpty;
}

bool ACWGameMode::IsSameCampAllControllerArrayActionEmpty(ECWCampTag ParamCampTag)
{
	bool bIsSameCampAllControllerArrayActionEmpty = true;
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			if (!TempPlayerController->IsAllPawnArrayActionEmptyInServer())
			{
				bIsSameCampAllControllerArrayActionEmpty = false;
				break;
			}
		}
	}

	return bIsSameCampAllControllerArrayActionEmpty;
}

bool ACWGameMode::IsAllCampDieEnd()
{
	bool bIsAllCampDieEnd = true;
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerDieEnd((ECWCampTag)CampIndex))
		{
			bIsAllCampDieEnd = false;
			break;
		}
	}

	return bIsAllCampDieEnd;
}

int32 ACWGameMode::GetCampNoDieCount(ECWCampTag& ParamOutCampTag)
{
	ParamOutCampTag = ECWCampTag::None;
	int32 TempCampNoDieCount = 0;
	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		if (!IsSameCampAllControllerDieEnd((ECWCampTag)CampIndex))
		{
			TempCampNoDieCount++;
			ParamOutCampTag = (ECWCampTag)CampIndex;
		}
	}
	return TempCampNoDieCount;
}

bool ACWGameMode::HandleRoundResult()
{
	ECWCampTag TempCampTag = ECWCampTag::None;
	int32 TempCampNoDieCount = GetCampNoDieCount(TempCampTag);
	if (TempCampNoDieCount <= 0)
	{
		//进入结算
		check(BattleFSM);
		FCWBattleResultEvent* ResultEvent = new FCWBattleResultEvent((int)ECWBattleEvent::Result, (int)ECWBattleState::Settlement, ECWFSMStackOp::Set, TempCampTag);
		BattleFSM->DoEvent(ResultEvent);
		return true;
	}
	else if (TempCampNoDieCount == 1)
	{
		//进入结算
		check(BattleFSM);
		FCWBattleResultEvent* ResultEvent = new FCWBattleResultEvent((int)ECWBattleEvent::Result, (int)ECWBattleState::Settlement, ECWFSMStackOp::Set, TempCampTag);
		BattleFSM->DoEvent(ResultEvent);
		return true;
	}
	else
	{
		return false;
	}
	
}

void ACWGameMode::SameCampAllControllerTurnEnd(ECWCampTag ParamCampTag)
{
	for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
	{
		ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex(ParamCampTag, (ECWCampControllerIndex)CampControllerIndex);
		if (TempPlayerController != nullptr)
		{
			TempPlayerController->TurnEnd();
		}
	}
}

void ACWGameMode::ResetWhenNextTurnBeginInServer()
{
	GetGameState<ACWGameState>()->ResetWhenNextTurnBeginInServer();

	for (int CampIndex = (int)ECWCampTag::None + 1; CampIndex < (int)ECWCampTag::Max; ++CampIndex)
	{
		for (int CampControllerIndex = (int)ECWCampControllerIndex::None + 1; CampControllerIndex < (int)ECWCampControllerIndex::Max; ++CampControllerIndex)
		{
			ACWPlayerController* TempPlayerController = GetPlayerControllerByCampTagAndControllerIndex((ECWCampTag)CampIndex, (ECWCampControllerIndex)CampControllerIndex);
			if (TempPlayerController != nullptr)
			{
				TempPlayerController->ResetWhenNextTurnBeginInServer();
			}
		}
	}
}

FCWGameDataStruct* ACWGameMode::GetGameDataStruct()
{
	int32 TempGameId = GetGameId();
	FCWGameDataStruct* TempGameData = FCWCommonUtil::FindCSVRow<FCWGameDataStruct>(TEXT("CWGameDataTable"), TempGameId);
	check(TempGameData);
	return TempGameData;
}

void ACWGameMode::HearbeatToServer()
{
	KFMsg::S2SHeartBeatToRoomReq req;
	req.set_roomid(UCWGameInstance::GetInstance()->GetRoomId());
	UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToServer(UCWGameInstance::GetInstance()->GetRoomServerId(), KFMsg::S2S_HEART_BEAT_TO_ROOM_REQ, &req);
}
