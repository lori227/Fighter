﻿
#include "CWGameModeBase.h"

#include "Engine/Engine.h"
#include "GameFramework/PlayerState.h"
#include "Kismet/KismetSystemLibrary.h"

#include "CWComDef.h"
#include "CWGameState.h"
#include "CWHUDBase.h"
#include "CWPlayerController.h"
#include "CWPlayerControllerBase.h"


ACWGameModeBase::ACWGameModeBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;

	HUDClass = ACWHUDBase::StaticClass();
	PlayerControllerClass = ACWPlayerControllerBase::StaticClass();

	GameModeDateBase.GameStage = ECWGameStage::None;
}

ACWGameModeBase::~ACWGameModeBase()
{
}

void ACWGameModeBase::PreInitializeComponents()
{
	Super::PreInitializeComponents();
}

void ACWGameModeBase::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);
}

void ACWGameModeBase::PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage)
{
	Super::PreLogin(Options, Address, UniqueId, ErrorMessage);
}

APlayerController* ACWGameModeBase::Login(UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage)
{
	APlayerController* NewPlayerController = Super::Login(NewPlayer, InRemoteRole, Portal, Options, UniqueId, ErrorMessage);
	OnPlayerLoginBegin(NewPlayerController, Options);
	return NewPlayerController;
}

void ACWGameModeBase::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	OnPlayerLoginCompleted(NewPlayer);
}

void ACWGameModeBase::OnPlayerLoginBegin(APlayerController* NewPlayer, const FString& Options)
{
	ACWPlayerControllerBase* NewPC = Cast<ACWPlayerControllerBase>(NewPlayer);
	if (nullptr == NewPC)
	{
		return;
	}
	InitPlayerBaseData(NewPC, Options);
	NewPC->ClientOnPlayerLoginBegin();

	CWG_LOG(">> %s::OnPlayerLoginBegin, Login[Begin] Player: Pid[%d] Options[%s].", *GetName(), NewPC->GetPlayerId(), *Options);
}

void ACWGameModeBase::InitPlayerBaseData(ACWPlayerControllerBase* NewPlayer, const FString& Options)
{
}

void ACWGameModeBase::OnPlayerLoginCompleted(APlayerController* NewPlayer)
{
	ACWPlayerControllerBase* NewPC = Cast<ACWPlayerControllerBase>(NewPlayer);
	if (nullptr == NewPC)
	{
		return;
	}
	InitPlayerExtraData(NewPC);
	NewPC->ClientOnPlayerLoginCompleted(GameModeDateBase);

	CWG_LOG(">> %s::OnPlayerLoginCompleted, Login[Complet] Player: Pid[%d].", *GetName(), NewPC->GetPlayerId());
}

void ACWGameModeBase::InitPlayerExtraData(ACWPlayerControllerBase* NewPlayer)
{
}

void ACWGameModeBase::KickPlayerToLobby(APlayerController* PC, const FString& Reason)
{
	if (ACWPlayerControllerBase* Player = Cast<ACWPlayerControllerBase>(PC))
	{
		Player->ClientReturnToLobby();
	}
}

void ACWGameModeBase::KickAllPlayersToLobby(const FString& Reason)
{
	if (AGameState* GS = GetWorld()->GetGameState<AGameState>())
	{
		for (int32 i = 0; i < GS->PlayerArray.Num(); ++i)
		{
			APlayerController* Player = Cast<APlayerController>(GS->PlayerArray[i]->GetOwner());
			KickPlayerToLobby(Player, Reason);
		}
	}
}

bool ACWGameModeBase::IsServer() const
{
	//return GetNetMode() < NM_Client;
	//return UKismetSystemLibrary::IsServer(this);
	UWorld* World = GEngine->GetWorldFromContextObject(this, EGetWorldErrorMode::LogAndReturnNull);
	return World ? (World->GetNetMode() != NM_Client) : false;
}

bool ACWGameModeBase::IsDedicatedServer() const
{
	//return GetNetMode() == NM_DedicatedServer;
	//return UKismetSystemLibrary::IsDedicatedServer(this);
	UWorld* World = GEngine->GetWorldFromContextObject(this, EGetWorldErrorMode::LogAndReturnNull);
	if (World)
	{
		return (World->GetNetMode() == NM_DedicatedServer);
	}
	return IsRunningDedicatedServer();
}

bool ACWGameModeBase::IsStandalone() const
{
	//return GetNetMode() == NM_Standalone;
	//return UKismetSystemLibrary::IsStandalone(this);
	UWorld* World = GEngine->GetWorldFromContextObject(this, EGetWorldErrorMode::LogAndReturnNull);
	return World ? (World->GetNetMode() == NM_Standalone) : false;
}
