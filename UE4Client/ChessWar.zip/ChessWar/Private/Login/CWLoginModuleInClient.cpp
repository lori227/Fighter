#include "CWLoginModuleInClient.h"
#include "CWLoginFSM.h"
#include "CWLoginCheckVersionState.h"
#include "CWLoginBatchUpdateState.h"
#include "CWLoginLoginState.h"
#include "CWFSMTranstion.h"
#include "CWGameInstance.h"
#include "CWEventMgr.h"
#include "CWLoginToCheckVersionEvent.h"
#include "CWClientVersionDataStruct.h"
#include "CWCommonUtil.h"
#include "CWSluaManager.h"
#include "CWLoginServerAuthState.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWLoginModuleInClient, All, All);

UCWLoginModuleInClient::UCWLoginModuleInClient(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

bool UCWLoginModuleInClient::Init(UCWGameInstance* InGI)
{
	check(InGI);
	GI = InGI;

	//SetupLoginFSM();
	
	UCWEventMgr::OnLevelLoadComplete.AddUObject(this, &UCWLoginModuleInClient::OnLevelLoadComplete);

	ADD_EVT_DELEGATE(UCWGameInstance::GetInstance()->GetEventMgr()->OnPlayerLoginCompleted, this, &UCWLoginModuleInClient::OnPlayerLoginCompleted, FName("OnPlayerLoginCompleted"));
	return true;
}

void UCWLoginModuleInClient::Destroy()
{
	
}

bool UCWLoginModuleInClient::Start()
{
	UE_LOG(LogCWLoginModuleInClient, Log, TEXT("UCWLoginModuleInClient::Start..."));

	UCWGameInstance::GetInstance()->GetSluaMgr()->ClientLuaState()->call("mainClient.StartCheckVersion");

	//if (LoginFSM->GetCurrentState() == nullptr)
	//{
	//	//LoginFSM->Startup((int)ECWLoginState::CheckVersion);
	//}
	//else
	//{
	//	//FCWLoginToCheckVersionEvent* ToCheckVersionEvent = new FCWLoginToCheckVersionEvent((int)ECWLoginEvent::ToCheckVersion, (int)ECWLoginState::CheckVersion, ECWFSMStackOp::Set);
	//	//LoginFSM->DoEvent(ToCheckVersionEvent);
	//}
	return true;
}

void UCWLoginModuleInClient::Finish()
{

}

void UCWLoginModuleInClient::OnLevelLoadComplete(const float LoadTime, const FString& MapName)
{
}

void UCWLoginModuleInClient::OnPlayerLoginCompleted(const FGameModeData GameModeData)
{
	ENetMode NetMode = GI->GetWorld()->GetNetMode();
	if (NetMode == NM_Client || NetMode == NM_Standalone)
	{
		if (GameModeData.GameStage == ECWGameStage::Login)
		{
			GI->GetSluaMgr()->ResetInClient();

			Start();
		}
	}
}

void UCWLoginModuleInClient::SetupLoginFSM()
{
	if (LoginFSM == nullptr)
	{
		LoginFSM = NewObject<UCWLoginFSM>();
		check(LoginFSM != nullptr);
		LoginFSM->Init(GI);
		LoginFSM->AddState(new FCWLoginCheckVersionState(LoginFSM, (int)ECWLoginState::CheckVersion));
		LoginFSM->AddState(new FCWLoginBatchUpdateState(LoginFSM, (int)ECWLoginState::BatchUpdate));
		LoginFSM->AddState(new FCWLoginServerAuthState(LoginFSM, (int)ECWLoginState::ServerAuth));
		LoginFSM->AddState(new FCWLoginLoginState(LoginFSM, (int)ECWLoginState::Login));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::CheckVersion, (int)ECWLoginState::BatchUpdate));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::CheckVersion, (int)ECWLoginState::ServerAuth));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::BatchUpdate, (int)ECWLoginState::ServerAuth));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::BatchUpdate, (int)ECWLoginState::CheckVersion));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::ServerAuth, (int)ECWLoginState::Login));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::ServerAuth, (int)ECWLoginState::CheckVersion));
		LoginFSM->AddTranstion(new FCWFSMTranstion((int)ECWLoginState::Login, (int)ECWLoginState::CheckVersion));
	}

	if (LoginFSM == nullptr)
		return;

}

FCWClientVersionDataStruct* UCWLoginModuleInClient::GetLocalClientVersionData()
{
	FCWClientVersionDataStruct* TempClientVersionData = FCWCommonUtil::FindCSVRow<FCWClientVersionDataStruct>(TEXT("CWClientVersionCfg"), 1);
	if (TempClientVersionData == nullptr)
	{
		UE_LOG(LogCWLoginModuleInClient, Error, TEXT("UCWLoginModuleInClient::GetLocalClientVersionData, TempClientVersionData == nullptr."));
		return nullptr;
	}
	return TempClientVersionData;
}
