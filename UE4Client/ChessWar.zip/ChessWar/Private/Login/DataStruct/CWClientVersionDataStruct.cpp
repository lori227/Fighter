#include "CWClientVersionDataStruct.h"

FCWClientVersionDataStruct::FCWClientVersionDataStruct()
{

}

FCWClientVersionDataStruct::~FCWClientVersionDataStruct()
{

}
