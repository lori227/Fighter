#include "CWServerInfoDataStruct.h"

FCWServerInfoDataStruct::FCWServerInfoDataStruct()
{

}

FCWServerInfoDataStruct::~FCWServerInfoDataStruct()
{

}
