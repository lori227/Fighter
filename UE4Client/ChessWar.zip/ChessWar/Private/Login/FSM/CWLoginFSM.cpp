#include "CWLoginFSM.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWLoginFSM, All, All);


UCWLoginFSM::UCWLoginFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWLoginFSM::Init(UCWGameInstance* InGI)
{
	GI = InGI;
}

UCWGameInstance* UCWLoginFSM::GetCWGameInstance()
{
	return GI;
}
