#include "CWLoginToBatchUpdateEvent.h"


FCWLoginToBatchUpdateEvent::FCWLoginToBatchUpdateEvent()
	:FCWFSMEvent()
{

}


FCWLoginToBatchUpdateEvent::FCWLoginToBatchUpdateEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, const FString& ParamPatchPakFinalUrl, const FString& ParamTargetVersion, const FString& ParamVersionJsonContent)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,PatchPakFinalUrl(ParamPatchPakFinalUrl)
	,TargetVersion(ParamTargetVersion)
	,VersionJsonContent(ParamVersionJsonContent)
{


}