#include "CWLoginToCheckVersionEvent.h"


FCWLoginToCheckVersionEvent::FCWLoginToCheckVersionEvent()
	:FCWFSMEvent()
{

}


FCWLoginToCheckVersionEvent::FCWLoginToCheckVersionEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}