#include "CWLoginToLoginEvent.h"


FCWLoginToLoginEvent::FCWLoginToLoginEvent()
	:FCWFSMEvent()
{

}


FCWLoginToLoginEvent::FCWLoginToLoginEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}