#include "CWLoginToServerAuthEvent.h"


FCWLoginToServerAuthEvent::FCWLoginToServerAuthEvent()
	:FCWFSMEvent()
{

}


FCWLoginToServerAuthEvent::FCWLoginToServerAuthEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}