
#include "CWLoginBatchUpdateState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWLoginFSM.h"
#include "CWLoginToBatchUpdateEvent.h"
#include "CWLoginToLoginEvent.h"
#include "Core/Public/Templates/SharedPointer.h"
#include "Online/HTTP/Public/Interfaces/IHttpResponse.h"
#include "CWClientVersionDataStruct.h"
#include "CWLoginToBatchUpdateEvent.h"
#include "CWCommonUtil.h"
#include "CWGameInstance.h"
#include "PlatformFile.h"
#include "IPlatformFilePak.h"
#include "CWSluaManager.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWLoginBatchUpdateState, All, All);

FCWLoginBatchUpdateState::FCWLoginBatchUpdateState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWLoginBatchUpdateState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWLoginBatchUpdateState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("FCWLoginBatchUpdateState::OnEnter..."));

	FCWLoginToBatchUpdateEvent* ToBatchUpdateEvent = (FCWLoginToBatchUpdateEvent*)Event;
	PatchPakFinalUrl = ToBatchUpdateEvent->PatchPakFinalUrl;
	TargetVersion = ToBatchUpdateEvent->TargetVersion;
	VersionJsonContent = ToBatchUpdateEvent->VersionJsonContent;
	GetPatchPakFromHttp();
}

void FCWLoginBatchUpdateState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWLoginBatchUpdateState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWLoginBatchUpdateState::Tick(float DeltaTime)
{

}

void FCWLoginBatchUpdateState::GetPatchPakFromHttp()
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("URL:%s, HTTP请求..."), *PatchPakFinalUrl);
	TSharedRef<IHttpRequest> HttpReuest = FHttpModule::Get().CreateRequest();
	HttpReuest->SetURL(PatchPakFinalUrl);
	HttpReuest->SetVerb(TEXT("GET"));
	HttpReuest->SetHeader(TEXT("Content-Type"), TEXT("application/x-www-form-urlencoded"));
	HttpReuest->OnProcessRequestComplete().BindRaw(this, &FCWLoginBatchUpdateState::OnRequestComplete);
	HttpReuest->OnRequestProgress().BindRaw(this, &FCWLoginBatchUpdateState::OnRequestProgress);
	HttpReuest->ProcessRequest();
}

void FCWLoginBatchUpdateState::OnRequestComplete(FHttpRequestPtr ParamHttpRequest, FHttpResponsePtr ParamHttpResponse, bool ParamSucceeded)
{
	UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("FCWLoginBatchUpdateState::OnRequestComplete, ParamSucceeded:%d, ParamHttpResponse->GetResponseCode():%d, EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()):%d."), ParamSucceeded, ParamHttpResponse->GetResponseCode(), EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()));

	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	FString TempClientBaseVersion;
	FCWClientVersionDataStruct* TempClientVersionData = GetLocalClientVersionData();
	if (TempClientVersionData != nullptr)
	{
		TempClientBaseVersion = TempClientVersionData->ClientBaseVersion;
	}
	else
	{
		UE_LOG(LogCWLoginBatchUpdateState, Error, TEXT("FCWLoginBatchUpdateState::OnRequestComplete, TempClientVersionData == nullptr"));
	}

	if (!ParamHttpRequest.IsValid() || !ParamHttpResponse.IsValid())
	{
		SetTargetVersionToGameInstanceInClient(TempClientBaseVersion);
		UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("服务器上无对应%s,无需更新..."), *PatchPakFinalUrl);
		FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToServerAuthEvent);
		return;
	}
	else if (ParamSucceeded && EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()))
	{
		//覆盖本地的Pak文件 
		FFileHelper::SaveArrayToFile(ParamHttpResponse->GetContent(), *FString::Printf(TEXT("%s%s"), *FPaths::ProjectContentDir(), TEXT("Paks/Patch_0_P.Pak")));

		//设置客户端的目标版本
		SetTargetVersionToGameInstanceInClient(TargetVersion);

		//覆盖本地的版本文件 
		FFileHelper::SaveStringToFile(VersionJsonContent, *FString::Printf(TEXT("%s%s"), *FPaths::ProjectContentDir(), TEXT("Version.json")));

		UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("下载对应%s, 成功, 目标版本:%s."), *PatchPakFinalUrl, *TargetVersion);

		auto PakPlatformFile = static_cast<FPakPlatformFile*>(FPlatformFileManager::Get().FindPlatformFile(TEXT("PakFile")));
		if (PakPlatformFile == nullptr)
		{
			PakPlatformFile = static_cast<FPakPlatformFile*>(FPlatformFileManager::Get().GetPlatformFile(TEXT("PakFile")));
			if (PakPlatformFile->Initialize(&FPlatformFileManager::Get().GetPlatformFile(), TEXT("")))
			{
				UE_LOG(LogTemp, Log, TEXT("created new FPakPlatformFile"));
				FPlatformFileManager::Get().SetPlatformFile(*PakPlatformFile);
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("cannot initialize patch file!"));
			}
		}

		FString TempPakName = FPaths::ProjectContentDir() + TEXT("Paks/Patch_0_P.Pak");
		PakPlatformFile->Unmount(*TempPakName);
		PakPlatformFile->Mount(*TempPakName, 10000);
		UGameplayStatics::OpenLevel(TempLoginFSM->GetCWGameInstance()->GetWorld(), FName(TEXT("LoginMap")));
	
		return;
	}
	else
	{
		SetTargetVersionToGameInstanceInClient(TempClientBaseVersion);
		UE_LOG(LogCWLoginBatchUpdateState, Error, TEXT("下载对应%s, 失败, %s, error:%d."), *PatchPakFinalUrl, *ParamHttpResponse->GetContentAsString(), ParamHttpResponse->GetResponseCode());
		FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToServerAuthEvent);
		return;
	}
}

void FCWLoginBatchUpdateState::OnRequestProgress(FHttpRequestPtr ParamHttpRequest, int32 ParamBytesSent, int32 ParamBytesReceived)
{
	UE_LOG(LogCWLoginBatchUpdateState, Log, TEXT("FCWLoginBatchUpdateState::OnRequestProgress..., ParamBytesSent:%d, ParamBytesReceived:%d."), ParamBytesSent, ParamBytesReceived);
}

FCWClientVersionDataStruct* FCWLoginBatchUpdateState::GetLocalClientVersionData()
{
	FCWClientVersionDataStruct* TempClientVersionData = FCWCommonUtil::FindCSVRow<FCWClientVersionDataStruct>(TEXT("CWClientVersionCfg"), 1);
	if (TempClientVersionData == nullptr)
	{
		UE_LOG(LogCWLoginBatchUpdateState, Error, TEXT("FCWLoginBatchUpdateState::GetLocalClientVersionData, TempClientVersionData == nullptr."));
		return nullptr;
	}
	return TempClientVersionData;
}

void FCWLoginBatchUpdateState::SetTargetVersionToGameInstanceInClient(const FString& ParamTargetVersion)
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);
	check(TempLoginFSM->GetCWGameInstance());
	TempLoginFSM->GetCWGameInstance()->SetTargetVersionInClient(ParamTargetVersion);
}
