
#include "CWLoginCheckVersionState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWLoginFSM.h"
#include "CWLoginToLoginEvent.h"
#include "Online/HTTP/Public/HttpModule.h"
#include "Core/Public/Templates/SharedPointer.h"
#include "Online/HTTP/Public/Interfaces/IHttpResponse.h"
#include "CWClientVersionDataStruct.h"
#include "CWLoginToBatchUpdateEvent.h"
#include "CWCommonUtil.h"
#include "CWGameInstance.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWLoginCheckVersionState, All, All);

FCWLoginCheckVersionState::FCWLoginCheckVersionState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWLoginCheckVersionState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWLoginCheckVersionState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("FCWLoginCheckVersionState::OnEnter..."));

	GetVersionFileFromHttp();
}

void FCWLoginCheckVersionState::OnExit(const FCWFSMEvent* Event)
{
	
}

void FCWLoginCheckVersionState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWLoginCheckVersionState::Tick(float DeltaTime)
{
	
}

void FCWLoginCheckVersionState::GetVersionFileFromHttp()
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	FString TempVersionJsonUrl;
	FCWClientVersionDataStruct* TempClientVersionData = GetLocalClientVersionDataStruct();
	if (TempClientVersionData != nullptr)
	{
		TempVersionJsonUrl = TempClientVersionData->VersionJsonUrl;
	}
	else
	{
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("FCWLoginCheckVersionState::GetVersionFileFromHttp, TempClientVersionData == nullptr"));
	}

	//FString Url = TEXT("http://localhost:80/AHZQ/Version.json");

	UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("URL:%s, HTTP请求..."), *TempVersionJsonUrl);
	TSharedRef<IHttpRequest> HttpReuest = FHttpModule::Get().CreateRequest();
	HttpReuest->SetURL(TempVersionJsonUrl);
	HttpReuest->SetVerb(TEXT("GET"));
	HttpReuest->SetHeader(TEXT("Content-Type"), TEXT("application/x-www-form-urlencoded"));
	HttpReuest->OnProcessRequestComplete().BindRaw(this, &FCWLoginCheckVersionState::OnRequestComplete);
	HttpReuest->OnRequestProgress().BindRaw(this, &FCWLoginCheckVersionState::OnRequestProgress);
	HttpReuest->ProcessRequest();
}

void FCWLoginCheckVersionState::OnRequestComplete(FHttpRequestPtr ParamHttpRequest, FHttpResponsePtr ParamHttpResponse, bool ParamSucceeded)
{
	//UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("FCWLoginCheckVersionState::OnRequestComplete, ParamSucceeded:%d, ParamHttpResponse->GetResponseCode():%d, EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()):%d."), ParamSucceeded, ParamHttpResponse->GetResponseCode(), EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()));

	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	FString TempLocalClientBaseVersion;
	FCWClientVersionDataStruct* TempClientVersionData = GetLocalClientVersionDataStruct();
	if (TempClientVersionData != nullptr)
	{
		TempLocalClientBaseVersion = TempClientVersionData->ClientBaseVersion;
	}
	else
	{
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("FCWLoginCheckVersionState::OnRequestComplete, TempClientVersionData == nullptr"));
	}

	if (!ParamHttpRequest.IsValid() || !ParamHttpResponse.IsValid())
	{
		SetTargetVersionToGameInstanceInClient(TempLocalClientBaseVersion);
		UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("服务器上没有Version.json文件,无需更新..."));
		FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToServerAuthEvent);
	}
	else if (ParamSucceeded && EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()))
	{
		FString TempServerTargetVersion;
		FString TempServerPatchPakUrl;
		GetVersionFromString(ParamHttpResponse->GetContentAsString(), TempServerTargetVersion, TempServerPatchPakUrl);

		//比较本地基础版本
		if (TempLocalClientBaseVersion == TempServerTargetVersion)
		{
			UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("本地基础版本为:%s, 网络目标版本为:%s, 无需更新..."), *TempLocalClientBaseVersion, *TempServerTargetVersion);
			FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
			TempLoginFSM->DoEvent(ToServerAuthEvent);
			return;
		}

		//比较本地目标版本
		FString TempLocalTargetVersion;
		GetLocalTargetVersionFromLocalVersionJson(TempLocalTargetVersion);
		if (TempLocalTargetVersion == TempServerTargetVersion)
		{
			UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("本地目标版本为:%s, 网络目标版本为:%s, 无需更新..."), *TempLocalTargetVersion, *TempServerTargetVersion);
			FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
			TempLoginFSM->DoEvent(ToServerAuthEvent);
			return;
		}

		//生成最终补丁路径
		FString TempPatchPakFinalUrl = GeneratePatchPakFinalUrl(TempLocalClientBaseVersion, TempServerTargetVersion, TempServerPatchPakUrl);

		UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("本地基础版本为:%s, 本地目标版本为:%s, 网络目标版本为:%s,  需要更新..., TempServerPatchPakUrl:%s, PatchPakFinalUrl:%s."), *TempLocalClientBaseVersion, *TempLocalTargetVersion, *TempServerTargetVersion, *TempServerPatchPakUrl, *TempPatchPakFinalUrl);

		//补丁更新
		FCWLoginToBatchUpdateEvent* ToBatchUpdateEvent = new FCWLoginToBatchUpdateEvent((int)ECWLoginEvent::ToBatchUpdate, (int)ECWLoginState::BatchUpdate, ECWFSMStackOp::Set, TempPatchPakFinalUrl, TempServerTargetVersion, ParamHttpResponse->GetContentAsString());
		TempLoginFSM->DoEvent(ToBatchUpdateEvent);
	}
	else
	{
		SetTargetVersionToGameInstanceInClient(TempLocalClientBaseVersion);
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("下载Version.json文件失败, %s, error:%d."), *ParamHttpResponse->GetContentAsString(), ParamHttpResponse->GetResponseCode());

		FCWLoginToServerAuthEvent* ToServerAuthEvent = new FCWLoginToServerAuthEvent((int)ECWLoginEvent::ToServerAuth, (int)ECWLoginState::ServerAuth, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToServerAuthEvent);
	}
}

void FCWLoginCheckVersionState::OnRequestProgress(FHttpRequestPtr ParamHttpRequest, int32 ParamBytesSent, int32 ParamBytesReceived)
{
	UE_LOG(LogCWLoginCheckVersionState, Log, TEXT("FCWLoginCheckVersionState::OnRequestProgress..., ParamBytesSent:%d, ParamBytesReceived:%d."), ParamBytesSent, ParamBytesReceived);
}

FCWClientVersionDataStruct* FCWLoginCheckVersionState::GetLocalClientVersionDataStruct()
{
	FCWClientVersionDataStruct* TempClientVersionData = FCWCommonUtil::FindCSVRow<FCWClientVersionDataStruct>(TEXT("CWClientVersionCfg"), 1);
	if (TempClientVersionData == nullptr)
	{
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("FCWLoginCheckVersionState::GetLocalClientVersionDataStruct, TempClientVersionData == nullptr."));
		return nullptr;
	}
	return TempClientVersionData;
}

void FCWLoginCheckVersionState::SetTargetVersionToGameInstanceInClient(const FString& ParamTargetVersion)
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);
	check(TempLoginFSM->GetCWGameInstance());
	TempLoginFSM->GetCWGameInstance()->SetTargetVersionInClient(ParamTargetVersion);
}

bool FCWLoginCheckVersionState::GetVersionFromString(const FString& ParamJsonString, FString& ParamTargetVersion, FString& ParamPatchPakUrl)
{
	TSharedPtr<FJsonObject> TempJsonObject;
	TSharedRef<TJsonReader<>> TempReader = TJsonReaderFactory<>::Create(ParamJsonString);
	if (FJsonSerializer::Deserialize(TempReader, TempJsonObject))
	{
		TSharedPtr<FJsonObject> TemoInfoObject = TempJsonObject->GetObjectField("Info");
		if (!TemoInfoObject.IsValid())
		{
			UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("无法解析Version.json里Info数据, Version.json数据可能有误..."));
			return false;
		}
		ParamTargetVersion = TemoInfoObject->GetStringField("TargetVersion");
		ParamPatchPakUrl = TemoInfoObject->GetStringField("PatchPakUrl");
		return true;
	}
	else
	{
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("无法解析Version.json数据, Version.json数据可能有误..."));
		return false;
	}
}

FString FCWLoginCheckVersionState::GeneratePatchPakFinalUrl(const FString& ParamLocalClientBaseVersion, const FString& ParamServerTargetVersion, const FString& ParamServerPatchPakUrl)
{
	FString TempClientBaseVersion = ParamLocalClientBaseVersion;
	TempClientBaseVersion = TempClientBaseVersion.Replace(TEXT("."), TEXT("_"));

	FString TempServerTargetVersion = ParamServerTargetVersion;
	TempServerTargetVersion = TempServerTargetVersion.Replace(TEXT("."), TEXT("_"));

	FString TempServerPatchPakUrl = ParamServerPatchPakUrl;
	TempServerPatchPakUrl += "/" + TempClientBaseVersion + "_" + TempServerTargetVersion + "/Patch_0_P.pak";
	return TempServerPatchPakUrl;
}

FString FCWLoginCheckVersionState::GetMD5(const TArray<uint8>& ParamArray)
{
	FMD5 md5Maker;
	md5Maker.Update(ParamArray.GetData(), ParamArray.Num());
	uint8 digest[16];
	md5Maker.Final(digest);
	FString TempMD5;
	for (int32 i = 0; i < 16; i++)
	{
		TempMD5 += FString::Printf(TEXT("%02x"), digest[i]);
	}
	TempMD5 = TempMD5.ToUpper();
	return TempMD5;
}

bool FCWLoginCheckVersionState::GetLocalTargetVersionFromLocalVersionJson(FString& ParamTargetVersion)
{
	FString TempLocalVersionJson;
	FFileHelper::LoadFileToString(TempLocalVersionJson, *(FPaths::ProjectContentDir() + TEXT("Version.json")));

	TSharedPtr<FJsonObject> TempJsonObject;
	TSharedRef<TJsonReader<>> TempReader = TJsonReaderFactory<>::Create(TempLocalVersionJson);
	if (FJsonSerializer::Deserialize(TempReader, TempJsonObject))
	{
		TSharedPtr<FJsonObject> TemoInfoObject = TempJsonObject->GetObjectField("Info");
		ParamTargetVersion = TemoInfoObject->GetStringField("TargetVersion");
		return true;
	}
	else
	{
		UE_LOG(LogCWLoginCheckVersionState, Error, TEXT("无法解析本地Version.json数据, Version.json数据可能有误..."));
		return false;
	}
}
