
#include "CWLoginLoginState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWLoginFSM.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWLoginLoginState, All, All);

FCWLoginLoginState::FCWLoginLoginState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWLoginLoginState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWLoginLoginState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWLoginLoginState, Log, TEXT("FCWLoginLoginState::OnEnter..."));
}

void FCWLoginLoginState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWLoginLoginState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWLoginLoginState::Tick(float DeltaTime)
{

}
