
#include "CWLoginServerAuthState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWLoginFSM.h"
#include "CWLoginToLoginEvent.h"
#include "Online/HTTP/Public/HttpModule.h"
#include "Core/Public/Templates/SharedPointer.h"
#include "Online/HTTP/Public/Interfaces/IHttpResponse.h"
#include "CWClientVersionDataStruct.h"
#include "CWLoginToBatchUpdateEvent.h"
#include "CWCommonUtil.h"
#include "CWGameInstance.h"
#include "CWNetMessage.h"
#include "Proto/FrameClientMessage.pb.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWLoginServerAuthState, All, All);

FCWLoginServerAuthState::FCWLoginServerAuthState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWLoginServerAuthState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWLoginServerAuthState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWLoginServerAuthState, Log, TEXT("FCWLoginServerAuthState::OnEnter..."));

	GetServerAuthInfoFromHttp();
}

void FCWLoginServerAuthState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWLoginServerAuthState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWLoginServerAuthState::Tick(float DeltaTime)
{

}

void FCWLoginServerAuthState::GetServerAuthInfoFromHttp()
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	FString TempServerAuthUrl;
	FCWServerInfoDataStruct* TempServerInfoData = GetServerAuthDataStruct();
	if (TempServerInfoData != nullptr)
	{
		TempServerAuthUrl = TempServerInfoData->ServerAuthUrl;
	}
	else
	{
		UE_LOG(LogCWLoginServerAuthState, Error, TEXT("FCWLoginServerAuthState::GetServerAuthInfoFromHttp, TempServerInfoData == nullptr"));
	}

	FString JsonString;
	TSharedRef< TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR> > > JsonWriter = TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR> >::Create(&JsonString);
	JsonWriter->WriteObjectStart();
	JsonWriter->WriteValue(TEXT("channel"), TEXT("1"));
	JsonWriter->WriteValue(TEXT("account"), TEXT("none"));
	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	//UE_LOG(LogCWLoginServerAuthState, Log, TEXT("URL:%s, HTTP����..."), *TempServerAuthUrl);
	TSharedRef<IHttpRequest> TempHttpRequest = FHttpModule::Get().CreateRequest();
	TempHttpRequest->SetURL(TempServerAuthUrl);
	TempHttpRequest->SetVerb(TEXT("POST"));
	TempHttpRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	TempHttpRequest->SetContentAsString(JsonString);
	TempHttpRequest->OnProcessRequestComplete().BindRaw(this, &FCWLoginServerAuthState::OnRequestComplete);
	TempHttpRequest->OnRequestProgress().BindRaw(this, &FCWLoginServerAuthState::OnRequestProgress);
	TempHttpRequest->ProcessRequest();
}

void FCWLoginServerAuthState::OnRequestComplete(FHttpRequestPtr ParamHttpRequest, FHttpResponsePtr ParamHttpResponse, bool ParamSucceeded)
{
	//UE_LOG(LogCWLoginServerAuthState, Log, TEXT("FCWLoginServerAuthState::OnRequestComplete, ParamSucceeded:%d, ParamHttpResponse->GetResponseCode():%d, EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()):%d."), ParamSucceeded, ParamHttpResponse->GetResponseCode(), EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()));

	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);

	if (!ParamHttpRequest.IsValid() || !ParamHttpResponse.IsValid())
	{
		UE_LOG(LogCWLoginServerAuthState, Error, TEXT("��������ȨHttp����ʧ��..."));
		FCWLoginToLoginEvent* ToLoginEvent = new FCWLoginToLoginEvent((int)ECWLoginEvent::ToLogin, (int)ECWLoginState::Login, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToLoginEvent);
		return;
	}
	else if (ParamSucceeded && EHttpResponseCodes::IsOk(ParamHttpResponse->GetResponseCode()))
	{
		FString TempJsonString = ParamHttpResponse->GetContentAsString();
		int32 TempRetCode;
		FString TempToken;
		int32 TempAccountId;
		int32 TempZoneId;
		FString TempServerName;
		FString TempServerIP;
		int32 TempServerPort;

		if (!GetRetCodeFromString(
			TempJsonString,
			TempRetCode,
			TempToken,
			TempAccountId,
			TempZoneId,
			TempServerName,
			TempServerIP,
			TempServerPort))
		{
			FCWLoginToLoginEvent* ToLoginEvent = new FCWLoginToLoginEvent((int)ECWLoginEvent::ToLogin, (int)ECWLoginState::Login, ECWFSMStackOp::Set);
			TempLoginFSM->DoEvent(ToLoginEvent);
			return;
		}

		if (TempRetCode != 1)
		{
			UE_LOG(LogCWLoginServerAuthState, Error, TEXT("��������ȨHttp����ʧ��, RetCode:%d."), TempRetCode);
			FCWLoginToLoginEvent* ToLoginEvent = new FCWLoginToLoginEvent((int)ECWLoginEvent::ToLogin, (int)ECWLoginState::Login, ECWFSMStackOp::Set);
			TempLoginFSM->DoEvent(ToLoginEvent);
			return;
		}
		
		SetServerAuthTokenToGameInstanceInClient(TempToken);
		SetAccountIdToGameInstanceInClient(TempAccountId);

		UE_LOG(LogCWLoginServerAuthState, Log, TEXT("��������ȨHttp����ɹ�."));

		//UCWGameInstance::GetInstance()->GetSluaMgr()->ClientLuaState()->call("mainClient.Test");

		/*UCWGameInstance* TempGI = TempLoginFSM->GetCWGameInstance();
		if (!TempGI->GetTCPClient()->Connect(TempServerIP, TempServerPort))
		{
			UE_LOG(LogCWLoginServerAuthState, Error, TEXT("���ӷ�����ʧ��..."));
			return;
		}

		KFMsg::MsgLoginReq r;
		r.set_token(TCHAR_TO_UTF8(*(TempGI->GetServerAuthTokenInClient())));
		r.set_accountid(TempGI->GetAccountIdInClient());
		r.set_version("0.0.0.0");
		const std::string strR = r.SerializeAsString();

		UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
		TempNetMsg->NetHead.MsgId = 100;
		TempNetMsg->CopyData((uint8*)strR.c_str(), strR.length());
		TempGI->GetTCPClient()->Send(TempNetMsg);*/

		FCWLoginToLoginEvent* ToLoginEvent = new FCWLoginToLoginEvent((int)ECWLoginEvent::ToLogin, (int)ECWLoginState::Login, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToLoginEvent);
		return;
	}
	else
	{
		UE_LOG(LogCWLoginServerAuthState, Error, TEXT("��������ȨHttp����ʧ��..., error:%d."), ParamHttpResponse->GetResponseCode());

		FCWLoginToLoginEvent* ToLoginEvent = new FCWLoginToLoginEvent((int)ECWLoginEvent::ToLogin, (int)ECWLoginState::Login, ECWFSMStackOp::Set);
		TempLoginFSM->DoEvent(ToLoginEvent);
	}
}

void FCWLoginServerAuthState::OnRequestProgress(FHttpRequestPtr ParamHttpRequest, int32 ParamBytesSent, int32 ParamBytesReceived)
{
	UE_LOG(LogCWLoginServerAuthState, Log, TEXT("FCWLoginServerAuthState::OnRequestProgress..., ParamBytesSent:%d, ParamBytesReceived:%d."), ParamBytesSent, ParamBytesReceived);
}

FCWServerInfoDataStruct* FCWLoginServerAuthState::GetServerAuthDataStruct()
{
	FCWServerInfoDataStruct* TempServerInfoData = FCWCommonUtil::FindCSVRow<FCWServerInfoDataStruct>(TEXT("CWServerInfoCfg"), 1);
	if (TempServerInfoData == nullptr)
	{
		UE_LOG(LogCWLoginServerAuthState, Error, TEXT("FCWLoginServerAuthState::GetServerAuthDataStruct, TempServerInfoData == nullptr."));
		return nullptr;
	}
	return TempServerInfoData;
}

void FCWLoginServerAuthState::SetServerAuthTokenToGameInstanceInClient(const FString& ParamServerAuthToken)
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);
	check(TempLoginFSM->GetCWGameInstance());
	TempLoginFSM->GetCWGameInstance()->SetServerAuthTokenInClient(ParamServerAuthToken);
}

void FCWLoginServerAuthState::SetAccountIdToGameInstanceInClient(uint32 ParamAccountId)
{
	check(Parent);
	UCWLoginFSM* TempLoginFSM = (UCWLoginFSM*)Parent;
	check(TempLoginFSM);
	check(TempLoginFSM->GetCWGameInstance());
	TempLoginFSM->GetCWGameInstance()->SetAccountIdInClient(ParamAccountId);
}

bool FCWLoginServerAuthState::GetRetCodeFromString(
	const FString& ParamJsonString, 
	int32& ParamRetCode, 
	FString& ParamToken,
	int32& ParamAccountId,
	int32& ParamZoneId,
	FString& ParamServerName,
	FString& ParamServerIP,
	int32& ParamServerPort)
{
	TSharedPtr<FJsonObject> TempJsonObject;
	TSharedRef<TJsonReader<>> TempReader = TJsonReaderFactory<>::Create(ParamJsonString);
	if (FJsonSerializer::Deserialize(TempReader, TempJsonObject))
	{
		ParamRetCode = TempJsonObject->GetIntegerField("retcode");
		ParamToken = TempJsonObject->GetStringField("token");
		ParamAccountId = (uint32)TempJsonObject->GetIntegerField("accountid");

		TSharedPtr<FJsonObject> TemoZoneObject = TempJsonObject->GetObjectField("zone");
		if (!TemoZoneObject.IsValid())
		{
			UE_LOG(LogCWLoginServerAuthState, Error, TEXT("�޷�����ServerAuthJson���zone����, ServerAuthJson���ݿ�������..."));
			return false;
		}
		else
		{
			ParamZoneId = TemoZoneObject->GetIntegerField("zoneid");
			ParamServerName = TemoZoneObject->GetStringField("name");
			ParamServerIP = TemoZoneObject->GetStringField("ip");
			ParamServerPort = TemoZoneObject->GetIntegerField("port");
			return true;
		}
	}
	else
	{
		UE_LOG(LogCWLoginServerAuthState, Error, TEXT("�޷�����ServerAuthJson����, ServerAuthJson���ݿ�������..."));
		return false;
	}
}
