﻿
#include "CWAudioPlayActor.h"

#include "Components/SceneComponent.h"


ACWAudioPlayActor::ACWAudioPlayActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	RootComponent = CreateDefaultSubobject<USceneComponent>("RootComponent");
}

ACWAudioPlayActor::~ACWAudioPlayActor()
{
}

bool ACWAudioPlayActor::Init(const ECWAudioType InType)
{
	AudioType = InType;
	return true;
}

bool ACWAudioPlayActor::IsAudioType(const ECWAudioType InType) const
{
	return InType != AudioType_None && InType == AudioType;
}
