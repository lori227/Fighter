﻿
#include "CWAudioVideoDef.h"

#include "AkComponent.h"

FCWAudioPlayData::FCWAudioPlayData(UAkComponent* InAkComp, const FString& InEvt,
	const bool bInStop, const ECWAudioType Type, const uint32 InPlayingID)
	: AkComp(InAkComp)
	, EventName(InEvt)
	, bStop(bInStop)
	, AudioType(Type)
	, PlayingID(InPlayingID)
{
}

FCWAudioPlayData::FCWAudioPlayData(UAkComponent* InAkComp, const uint32& InEvtId)
	: AkComp(InAkComp)
	, EventId(InEvtId)
{
}

FCWAudioPlayData::FCWAudioPlayData()
{
}

bool FCWAudioPlayData::IsAlwaysPlay() const
{
	return (AudioType == ECWAudioType::AT_UISound);
}

bool FCWAudioPlayData::IsNeedAwaken() const
{
	return (AudioType != ECWAudioType::AT_UISound ||
			AudioType != ECWAudioType::AT_LevelMisc);
}

bool FCWAudioPlayData::IsStop() const
{
	return bStop;
}

bool FCWAudioPlayData::IsDiffer(const FString& InEvt) const
{
	return !InEvt.IsEmpty() && (0 != EventName.Compare(InEvt, ESearchCase::IgnoreCase) || EventName.IsEmpty());
}


// 背景音乐(战斗)
const FString EvtBgMusic::Bank(TEXT("SoundBank_Music"));
const FString EvtBgMusic::Combat(TEXT("combat"));
const FString EvtBgMusic::State::CombatPre(TEXT("pre_combat"));
const FString EvtBgMusic::State::CombatIng(TEXT("in_combat"));
const FString EvtBgMusic::State::CombatWin(TEXT("win"));
const FString EvtBgMusic::State::CombatLose(TEXT("lose"));

// 环境音乐(天气)
const FString EvtAmbient::Bank(TEXT("SoundBank_Amb"));

const FString EvtAmbient::Weather(TEXT("weather"));
const FString EvtAmbient::StateWT::Sunshine(TEXT("Sunshine"));
const FString EvtAmbient::StateWT::Rain(TEXT("rain"));
const FString EvtAmbient::StateWT::Blizzard(TEXT("blizzard"));

// 环境音乐(时间)
const FString EvtAmbient::Environ(TEXT("environment"));
const FString EvtAmbient::StateEV::Morning(TEXT("morning"));
const FString EvtAmbient::StateEV::Afternoon(TEXT("afternoon"));
const FString EvtAmbient::StateEV::Night(TEXT("night"));

// 上升完成声音数据(准备阶段外围物件)
const FString FPeripherySceneObj::StoneRaise(TEXT("opening_stoneRaise_in"));
const FString FPeripherySceneObj::StoneKey(TEXT("rock"));
const FString FPeripherySceneObj::StoneEvt(TEXT("opening_out_stone"));
const FString FPeripherySceneObj::TreeKey(TEXT("tree"));
const FString FPeripherySceneObj::TreeEvt(TEXT("opening_out_tree"));
