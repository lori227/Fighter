﻿
#include "CWAudioVideoMgr.h"

#include "Camera/PlayerCameraManager.h"

#include "Wwise_IDs.h"
#include "AkInclude.h"
#include "AudioDevice.h"
#include "AkAudioBank.h"
#include "AkComponent.h"
#include "AkAudioEvent.h"
#include "AudioDeviceManager.h"
#include "AkExtraGameplayStatics.h"

#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWAudioData.h"
#include "CWEventMgr.h"
#include "CWCfgManager.h"
#include "CWWeatherEffect.h"
#include "CWGameInstance.h"
#include "AkGameplayStatics.h"
#include "CWCommonUtil.h"
#include "CWAudioPlayActor.h"


UCWAudioVideoMgr::UCWAudioVideoMgr(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bEnableAudioPlay(true)
	, AkAudioMainVolume(1.f)
{
}

class UCWAudioVideoMgr* UCWAudioVideoMgr::GetAVMgr(const UObject* InWorldContextObj /*= nullptr*/)
{
#if !UE_SERVER
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetAudioVideoMgr() : nullptr;
#else
	return nullptr;
#endif
}

bool UCWAudioVideoMgr::InitMgr(UCWGameInstance* InGI)
{
	Super::InitMgr(InGI);

	if (UCWFuncLib::IsCanInitCustomData(this))
	{
		if (UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr)
		{
			ADD_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this, &UCWAudioVideoMgr::OnBattleStateChange, FName("OnBattleStateChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnWeatherIdxChange, this, &UCWAudioVideoMgr::OnWeatherIdxChange, FName("OnWeatherIdxChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnTimePhasesChange, this, &UCWAudioVideoMgr::OnTimePhasesChange, FName("OnTimePhasesChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnBattleResult, this, &UCWAudioVideoMgr::OnBattleResult, FName("OnBattleResult"));
			ADD_EVT_DELEGATE(EvtMgr->OnLevelSiteDrop, this, &UCWAudioVideoMgr::OnLevelSiteDrop, FName("OnLevelSiteDrop"));
			ADD_EVT_DELEGATE(EvtMgr->OnCameraArmLength, this, &UCWAudioVideoMgr::OnCameraArmLength, FName("OnCameraArmLength"));
			UCWEventMgr::OnLevelLoadComplete.AddUObject(this, &UCWAudioVideoMgr::OnLevelLoadComplete);
		}
	}
	return true;
}

void UCWAudioVideoMgr::Destroy()
{
	if (UCWFuncLib::IsCanDestroyCustomData(this))
	{
		if (UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr)
		{
			REMOVE_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnWeatherIdxChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnTimePhasesChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnBattleResult, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnLevelSiteDrop, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnCameraArmLength, this);
			UCWEventMgr::OnLevelLoadComplete.RemoveAll(this);
		}

		ClearAllPlayData();
		ClearAllBanks();
	}

	Super::Destroy();
}

FCWAudioPlayData* UCWAudioVideoMgr::GetAudioPlayData(ECWAudioType AudioType)
{
	FCWAudioPlayData* OutData = AudioPlayMap.Find(AudioType);
	return OutData;
}

void UCWAudioVideoMgr::AddAudioPlayData(ECWAudioType AudioType, const FCWAudioPlayData& InPlayData)
{
	//check(InPlayData.AkComp);
	AudioPlayMap.Add(AudioType, InPlayData);
}

void UCWAudioVideoMgr::ClearAllPlayData()
{
	AudioPlayMap.Empty();
	AnimAudioPlayList.Empty();
}

UAkComponent* UCWAudioVideoMgr::GetPlayAkComp(ECWAudioType AudioType)
{
	AActor* PlayActor = GetPlayAkActor(AudioType);
	UAkComponent* PlayComp = GetAkComp(PlayActor);
	return PlayComp;
}

AActor* UCWAudioVideoMgr::GetPlayAkActor(ECWAudioType AudioType)
{
	if (AudioType == AudioType_None || AudioType == AT_Max)
	{
		return nullptr;
	}

	AActor* PlayActor = nullptr;

	// 获取播放对象
	switch (AudioType)
	{
	/*case ECWAudioType::AT_Weather:
	case ECWAudioType::AT_TimePhases:
	{
		PlayActor = GetAmbientPlayActor();
	}break;*/
	case ECWAudioType::AT_BgMusic:
	{
		PlayActor = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	}break;
	case ECWAudioType::AT_UISound:
	{
		PlayActor = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	}break;
	}

	if (IsValid(PlayActor))
	{
		return PlayActor;
	}
	else if(UWorld* MyWorld = GetWorld())
	{	// 查找或者创建播放对象
		auto FindOrCreateActor = [MyWorld, AudioType]() -> AActor*
		{
			for (TActorIterator<ACWAudioPlayActor> Iter(MyWorld); Iter; ++Iter)
			{
				ACWAudioPlayActor* TmpActor = *Iter;
				if (TmpActor->IsAudioType(AudioType))
				{
					return TmpActor;
				}
			}
			ACWAudioPlayActor* TmpActor = Cast<ACWAudioPlayActor>(MyWorld->SpawnActor(ACWAudioPlayActor::StaticClass()));
			TmpActor->SetActorLocation(FVector(430.f, 240.f, 0.f));
			TmpActor->Init(AudioType);
			return TmpActor;
		};
		PlayActor = FindOrCreateActor();
	}

	return PlayActor;
}

UAkComponent* UCWAudioVideoMgr::GetListenerAkComp()
{
	FAkAudioDevice* AkAudioDevice = GetAkAudioDevice();
	return AkAudioDevice ? AkAudioDevice->GetSpatialAudioListener() : nullptr;
}

class FAudioDevice* UCWAudioVideoMgr::GetAudioDevice() const
{
	UWorld* const MyWorld = GetWorld();
	return (MyWorld) ? MyWorld->GetAudioDevice() : nullptr;
}

class FAkAudioDevice* UCWAudioVideoMgr::GetAkAudioDevice() const
{
	return FAkAudioDevice::Get();
}

AActor* UCWAudioVideoMgr::GetAmbientPlayActor()
{
	if (UWorld* MyWorld = GetWorld())
	{
		for (TActorIterator<ACWWeatherEffect> Iter(MyWorld); Iter; ++Iter)
		{
			return (*Iter);
		}
	}
	CWG_WARNING(">> %s::GetAmbientPlayActor, Actor not find!", *GetName());
	return nullptr;
}

AActor* UCWAudioVideoMgr::GetUISoundPlayActor()
{
	if (UWorld* MyWorld = GetWorld())
	{
		for (TActorIterator<AHUD> Iter(MyWorld); Iter; ++Iter)
		{
			return (*Iter);
		}
	}
	CWG_WARNING(">> %s::GetUISoundPlayActor, Actor not find!", *GetName());
	return nullptr;
}

void UCWAudioVideoMgr::PreLoadBank(const FString& LevelName /*= TEXT("")*/)
{
	// TODO: 预加载Back
}

void UCWAudioVideoMgr::OnLevelLoadComplete(const float LoadTime, const FString& MapName)
{
	// 重置所有类型音频声音
	//CollectGarbage(GARBAGE_COLLECTION_KEEPFLAGS);
	//ForceGarbageCollection(true);
}

void UCWAudioVideoMgr::OnBattleStateChange(const ECWBattleState OldState, const ECWBattleState NewState)
{
	if (OldState != NewState)
	{
		LoadBank(EvtBgMusic::Bank);
		PlayAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat);

		switch (NewState)
		{
		case ECWBattleState::Dungeon:
		{
		}break;
		case ECWBattleState::Ready:
		{
			StopAudio(ECWAudioType::AT_LevelMisc);

			SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, EvtBgMusic::State::CombatPre);
			//PlayAudioByCfg(AT_BgMusic, EvtBgMusic::State::CombatPre);

			// 延迟播放(PS: 0.5s)
			OnTimePhasesChange(ECWTimePhases::Morning);
			OnWeatherIdxChange(ECWWeatherType::Sunshine, ECWWeatherType::None);
		}break;
		case ECWBattleState::Fighting:
		{
			SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, EvtBgMusic::State::CombatIng);
			//PlayAudioByCfg(AT_BgMusic, EvtBgMusic::State::CombatIng);
		}break;
		case ECWBattleState::Settlement:
		{
			StopAudio(ECWAudioType::AT_Weather);
			StopAudio(ECWAudioType::AT_TimePhases);
		}break;
		}
	}
}

void UCWAudioVideoMgr::OnWeatherIdxChange(ECWWeatherType NewWeatherIdx, ECWWeatherType InOldType)
{
	LoadBank(EvtAmbient::Bank);
	PlayAudio(ECWAudioType::AT_Weather, EvtAmbient::Weather);

	//auto DelayPlaySound = [=]()
	{
		switch (NewWeatherIdx)
		{
		case ECWWeatherType::Sunshine:
		{
			SwitchAudio(ECWAudioType::AT_Weather, EvtAmbient::Weather, EvtAmbient::StateWT::Sunshine);
			//SwitchAudioById(ECWAudioType::AT_Weather, AK::SWITCHES::WEATHER::GROUP, AK::SWITCHES::WEATHER::SWITCH::SUNSHINE);
		}break;
		case ECWWeatherType::Rain:
		{
			SwitchAudio(ECWAudioType::AT_Weather, EvtAmbient::Weather, EvtAmbient::StateWT::Rain);
			//SwitchAudioById(ECWAudioType::AT_Weather, AK::SWITCHES::WEATHER::GROUP, AK::SWITCHES::WEATHER::SWITCH::RAIN);
		}break;
		case ECWWeatherType::Blizzard:
		{
			SwitchAudio(ECWAudioType::AT_Weather, EvtAmbient::Weather, EvtAmbient::StateWT::Blizzard);
			//SwitchAudioById(ECWAudioType::AT_Weather, AK::SWITCHES::WEATHER::GROUP, AK::SWITCHES::WEATHER::SWITCH::BLIZZARD);
		}break;
		}
	};

	// 延迟播放(PS: 0.3s)
	/*if (UWorld* const MyWorld = GetWorld())
	{
		FTimerHandle TimerHandle;
		FTimerManager& TimerManager = MyWorld->GetTimerManager();
		TimerManager.SetTimer(TimerHandle, DelayPlaySound, 1.0f, false, 0.3f);
	}*/
}

void UCWAudioVideoMgr::OnTimePhasesChange(ECWTimePhases NewTimePhases)
{
	LoadBank(EvtAmbient::Bank);
	PlayAudio(ECWAudioType::AT_TimePhases, EvtAmbient::Environ);

	//auto DelayPlaySound = [=]()
	{
		switch (NewTimePhases)
		{
		case ECWTimePhases::Morning:
		{
			SwitchAudio(ECWAudioType::AT_TimePhases, EvtAmbient::Environ, EvtAmbient::StateEV::Morning);
			//SwitchAudioById(ECWAudioType::AT_TimePhases, AK::SWITCHES::ENVIRONMENT::GROUP, AK::SWITCHES::ENVIRONMENT::SWITCH::MORNING);
		}break;
		case ECWTimePhases::Afternoon:
		{
			SwitchAudio(ECWAudioType::AT_TimePhases, EvtAmbient::Environ, EvtAmbient::StateEV::Afternoon);
			//SwitchAudioById(ECWAudioType::AT_TimePhases, AK::SWITCHES::ENVIRONMENT::GROUP, AK::SWITCHES::ENVIRONMENT::SWITCH::AFTERNOON);
		}break;
		case ECWTimePhases::Night:
		{
			SwitchAudio(ECWAudioType::AT_TimePhases, EvtAmbient::Environ, EvtAmbient::StateEV::Night);
			//SwitchAudioById(ECWAudioType::AT_TimePhases, AK::SWITCHES::ENVIRONMENT::GROUP, AK::SWITCHES::ENVIRONMENT::SWITCH::NIGHT);
		}break;
		}
	};

	// 延迟播放(PS: 0.3s)
	/*if (UWorld* const MyWorld = GetWorld())
	{
		FTimerHandle TimerHandle;
		FTimerManager& TimerManager = MyWorld->GetTimerManager();
		TimerManager.SetTimer(TimerHandle, DelayPlaySound, 1.0f, false, 0.3f);
	}*/
}

void UCWAudioVideoMgr::OnBattleResult(const ECWBattleResult InResult)
{
	switch (InResult)
	{
	case ECWBattleResult::Win:
	{
		SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, EvtBgMusic::State::CombatWin);
		//PlayAudioByCfg(AT_BgMusic, EvtBgMusic::State::CombatWin);
	}break;
	case ECWBattleResult::Lost:
	{
		SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, EvtBgMusic::State::CombatLose);
		//PlayAudioByCfg(AT_BgMusic, EvtBgMusic::State::CombatLose);
	}break;
	default:
	{
		SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, EvtBgMusic::State::CombatLose);
		//PlayAudioByCfg(AT_BgMusic, EvtBgMusic::State::CombatLose);
	}break;
	}
}

void UCWAudioVideoMgr::OnLevelSiteDrop(const bool bStarted, const int32 InFallIdx)
{
	// sound stone
	FString AkEvt = bStarted ? TEXT("Play_stone") : TEXT("Stop_stone");
	PlayAudio(ECWAudioType::AT_LevelMisc, AkEvt);

	// sound Bg music
	FString AkBgEvt = TEXT("battle") + INT_TO_FSTRING(InFallIdx);
	SwitchAudio(ECWAudioType::AT_BgMusic, EvtBgMusic::Combat, AkBgEvt);
	//PlayAudioByCfg(AT_BgMusic, AkBgEvt);
}

void UCWAudioVideoMgr::OnCameraArmLength(const float InLength)
{
	if (UAkComponent* AkWeatherComp = GetPlayAkComp(AT_Weather))
	{
		AkWeatherComp->SetRTPCValue(TEXT("AMB_Distance"), InLength, 1000.f);
	}
	if (UAkComponent* AkEnvironComp = GetPlayAkComp(AT_TimePhases))
	{
		AkEnvironComp->SetRTPCValue(TEXT("AMB_Distance"), InLength, 1000.f);
	}
}

bool UCWAudioVideoMgr::PlayAudioByCfg(ECWAudioType AudioType, const FString& InAudioId)
{
	if (AudioType != AudioType_None && !InAudioId.IsEmpty())
	{
		if (const FCWAudioData* AudioData = FCWCfgUtils::GetAudioData(Global_GI.Get(), InAudioId))
		{
			LoadBank(TEXT(""), AudioData->AkBank);
			if (PlayAudio(AudioType, AudioData->AkEventName, AudioData->AkEvent) &&
				!AudioData->AkGroup.IsEmpty() && !AudioData->AkState.IsEmpty())
			{
				return SwitchAudio(AudioType, AudioData->AkGroup, AudioData->AkState);
			}
		}
	}
	return false;
}

bool UCWAudioVideoMgr::PlayAudio(ECWAudioType AudioType, const FString& AkEventName, const UAkAudioEvent* AkEvent)
{
	const FString& EventName = GET_AK_EVENT_NAME(AkEvent, AkEventName);
	if (AudioType == AudioType_None || EventName.IsEmpty())
	{
		CWG_WARNING(">> %s::PlayAudio, AudioType[%s] EventName is IsEmpty!", *GetName(), *FCWCommonUtil::EnumToString("ECWAudioType", AudioType));
		return false;
	}

	const bool bEnableAkAudio = IsAkAudioEnableInMgr();
	AkPlayingID PlayingID = AK_INVALID_PLAYING_ID;
	FCWAudioPlayData* PlayData = GetAudioPlayData(AudioType);
	if (nullptr != PlayData && PlayData->AkComp.IsValid())
	{
		if (PlayData->IsAlwaysPlay() || PlayData->IsDiffer(EventName) || PlayData->IsStop())
		{
			if (bEnableAkAudio)
			{
				PlayData->bStop = false;
				PlayingID = PlayData->AkComp->PostAkEventByName(EventName);
			}
			PlayData->EventName = EventName;
		}
		else
		{	// 已经在播放中
			return true;
		}
	}
	else if (UAkComponent* AkComp = GetPlayAkComp(AudioType))
	{
		if (bEnableAkAudio)
		{
			PlayingID = AkComp->PostAkEventByName(EventName);
		}
		AddAudioPlayData(AudioType, FCWAudioPlayData(AkComp, EventName, !bEnableAkAudio, AudioType, PlayingID));
	}
	/*if (PlayingID != AK_INVALID_PLAYING_ID)
	{
		PlayData->bStop = false;
		PlayData->PlayingID = PlayingID;
	}*/

	//CWG_LOG(">>> %s::PlayAudio, NetMode[%s] AudioType[%s] EventName[%s] bEnableAkAudio[%s] PlayingID[%d] .", *GetName(), *NETMODE_TO_STRING(GetWorld()->GetNetMode()),
		//*FCWCommonUtil::EnumToString("ECWAudioType", AudioType), *EventName, *BOOL_TO_FSTRING(bEnableAkAudio), uint32(PlayingID));
	return PlayingID != AK_INVALID_PLAYING_ID;
}

bool UCWAudioVideoMgr::SwitchAudio(ECWAudioType AudioType, const FString& InGroup, const FString& InState)
{
	if (AudioType == AudioType_None || InGroup.IsEmpty() || InState.IsEmpty())
	{
		CWG_LOG(">> %s::SwitchAudio, AudioType[%d] InGroup[%s]/InState[%s] is IsEmpty!", *GetName(), AudioType, *InGroup, *InState);
		return false;
	}

	FCWAudioPlayData* PlayData = GetAudioPlayData(AudioType);
	if (nullptr != PlayData && PlayData->AkComp.IsValid())
	{
		PlayData->CurGroup = InGroup;
		PlayData->CurState = InState;
		const bool bEnableAkAudio = IsAkAudioEnableInMgr();
		if (bEnableAkAudio)
		{
			PlayData->AkComp->SetSwitch(InGroup, InState);
		}else
		{
			//StopAudio(AudioType);
		}
		//CWG_LOG(">> %s::SwitchAudio, bEnableAkAudio[%s] InGroup[%s]/InState[%s].", *GetName(), *BOOL_TO_FSTRING(bEnableAkAudio), *InGroup, *InState);
		return bEnableAkAudio;
	}
	CWG_WARNING(">> %s::SwitchAudio, AudioType[%d] PlayData[%d]/AkComp is Null!", *GetName(), AudioType, PlayData);
	return false;
}

bool UCWAudioVideoMgr::StopAudio(ECWAudioType AudioType)
{
	FCWAudioPlayData* PlayData = GetAudioPlayData(AudioType);
	if (nullptr != PlayData && PlayData->AkComp.IsValid())
	{
		//AkAudioDevice->Flush(GetWorld());
		//AkAudioDevice->StopAllSounds();
		//AkAudioDevice->StopGameObject(PlayingID);
		//AkAudioDevice->StopGameObject(AkComp);

		PlayData->bStop = true;
		PlayData->AkComp->Stop();
		return true;
		//~ begin use id
		/*AkGameObjectID gameObj = PlayData->AkComp->GetAkGameObjectID();
		AK::SoundEngine::StopAll(
			gameObj							///< Associated game object ID
			);*/
	}
	return false;
}

bool UCWAudioVideoMgr::PlayAudioByCfg(AActor* InActor, const FString& InAudioId)
{
	if (IsValid(InActor) && !InAudioId.IsEmpty())
	{
		if (const FCWAudioData* AudioData = FCWCfgUtils::GetAudioData(InActor, InAudioId))
		{
			return SimplePlayAudio(InActor, 
				AudioData->AkEvent, AudioData->AkEventName, AudioData->AkGroup, AudioData->AkState, AudioData->AkBank);
		}
	}
	return false;
}

bool UCWAudioVideoMgr::SimplePlayAudio(AActor* InActor, 
	const UAkAudioEvent* InAkEvent, const FString& InAkEventName,
	const FString& InGroup, const FString& InState, 
	const UAkAudioBank* InAkBank, const FString& InAkBankName)
{
	const bool bEnableAkAudio = IsAkAudioEnableInMgr();
	if (bEnableAkAudio && nullptr != InActor)
	{
		const FString& EventName = GET_AK_EVENT_NAME(InAkEvent, InAkEventName);
		if (!EventName.IsEmpty())
		{
			if (UAkComponent* PlayComp = GetAkComp(InActor))
			{
				LoadBank(InAkBankName, InAkBank);
				// 设置音量
				PlayComp->SetOutputBusVolume(AkAudioMainVolume);
				AkPlayingID playingID = PlayComp->PostAkEventByName(EventName);
				if (playingID != AK_INVALID_PLAYING_ID)
				{
					PlayComp->SetSwitch(InGroup, InState);
				}
				SimpleAudioPlayList.AddUnique(PlayComp);

				return playingID != AK_INVALID_PLAYING_ID;
			}
		}
	}
	return false;
}

bool UCWAudioVideoMgr::SimpleStopAudio(AActor* InActor)
{
	if (UAkComponent* PlayComp = IsValid(InActor) ? InActor->FindComponentByClass<UAkComponent>() : nullptr)
	{
		PlayComp->Stop();
		return true;
	}
	return false;
}

void UCWAudioVideoMgr::AddToAnimAudioList(UAkComponent* InAkComp)
{
	if (IsValid(InAkComp) && 
		!AnimAudioPlayList.ContainsByPredicate([InAkComp](const TWeakObjectPtr<UAkComponent>& AkComp)
		{
			return (AkComp.IsValid()) && (AkComp.Get() == InAkComp);
		}))
	{
		// 设置声音
		InAkComp->SetOutputBusVolume(AkAudioMainVolume);
		AnimAudioPlayList.AddUnique(InAkComp);
	}
}

void UCWAudioVideoMgr::RemoveFromAnimAudioList(UAkComponent* InAkComp)
{
	if (IsValid(InAkComp))
	{
		AnimAudioPlayList.RemoveAll([InAkComp](const TWeakObjectPtr<UAkComponent>& AkComp)
		{
			return (!AkComp.IsValid()) || (AkComp.Get() == InAkComp);
		});
	}
}

bool UCWAudioVideoMgr::PlayAudioById(ECWAudioType AudioType, const uint32& EventId)
{
	// https://www.audiokinetic.com/library/edge/?source=SDK&id=soundengine__banks__general.html&tdsourcetag=s_pcqq_aiomsg

	AkPlayingID PlayingID = AK_INVALID_PLAYING_ID;
	FCWAudioPlayData* PlayData = GetAudioPlayData(AudioType);
	if (nullptr != PlayData && PlayData->AkComp.IsValid() && EventId != PlayData->EventId)
	{
		AkGameObjectID GameObjId = PlayData->AkComp->GetAkGameObjectID();
		//PlayingID = AK::SoundEngine::PostEvent(EventId, GameObjId);
	}
	else if (UAkComponent* AkComp = GetPlayAkComp(AudioType))
	{
		AkGameObjectID GameObjId = AkComp->GetAkGameObjectID();
		//PlayingID = AK::SoundEngine::PostEvent(EventId, GameObjId);
	}
	return PlayingID != AK_INVALID_PLAYING_ID;
}

bool UCWAudioVideoMgr::SwitchAudioById(ECWAudioType AudioType, const uint32& GroupId, const uint32& StateId)
{
	FCWAudioPlayData* PlayData = GetAudioPlayData(AudioType);
	if (nullptr != PlayData && PlayData->AkComp.IsValid())
	{
		AkGameObjectID GameObjId = PlayData->AkComp->GetAkGameObjectID();
		//uint16 Result = AK::SoundEngine::SetSwitch(GroupId, StateId, GameObjId);
		/*if (Result != 1)
		{
			CWG_WARNING(">>> %s::SwitchAudioById, SetSwitch Fail! Result[%d] AudioType[%d], GroupId[%d], StateId[%d].",
				*GetName(), (int32)Result, (int32)AudioType, GroupId, StateId);
		}*/
		return true;//Result == 1;
	}
	return false;
}

bool UCWAudioVideoMgr::LoadBank(const FString& InBankName, const UAkAudioBank* InAkBank)
{
	const FString& BankName = GET_AK_EVENT_NAME(InAkBank, InBankName);
	if (BankName.IsEmpty())
	{
		CWG_WARNING(">> %s::LoadBank, AkBank/BankName is Null.", *GetName());
		return false;
	}
	if (!AudioBankList.Contains(BankName))
	{
		UAkGameplayStatics::LoadBankByName(BankName);
		AudioBankList.Push(BankName);
	}
	return true;
}

bool UCWAudioVideoMgr::UnloadBank(const FString& InBankName, const UAkAudioBank* InAkBank /*= nullptr*/)
{
	const FString& BankName = GET_AK_EVENT_NAME(InAkBank, InBankName);
	if (BankName.IsEmpty())
	{
		CWG_WARNING(">> %s::UnloadBank, AkBank/BankName is Null.", *GetName());
		return false;
	}
	if (AudioBankList.Contains(BankName))
	{
		UAkGameplayStatics::UnloadBankByName(BankName);
		AudioBankList.Remove(BankName);
	}
	return true;
}

void UCWAudioVideoMgr::ClearAllBanks()
{
	/*for (const FString& Bank : AudioBankList)
	{
		UAkGameplayStatics::UnloadBankByName(Bank);
	}
	AudioBankList.Empty();*/
	//UAkGameplayStatics::ClearBanks();
}

bool UCWAudioVideoMgr::SetAkAudioVolume(EAudioSetType InAudioType, const float InVolume, const int32 InterpolationTimeMs)
{
	FName RTPCName;
	switch (InAudioType)
	{
	case EAudioSetType::AST_Env:   {	RTPCName = TEXT("AMB"); } break;
	case EAudioSetType::AST_Music: {	RTPCName = TEXT("MUS"); } break;
	case EAudioSetType::AST_Sound: {	RTPCName = TEXT("SE"); } break;
	case EAudioSetType::AST_Voice: {	RTPCName = TEXT("VO"); } break;
	case EAudioSetType::AST_Master:{	RTPCName = TEXT("MASTER"); } break;
	}
	if (RTPCName.IsValid())
	{
		UAkGameplayStatics::SetRTPCValue(RTPCName, InVolume, InterpolationTimeMs, nullptr);
		return true;
	}
	return false;
}

bool UCWAudioVideoMgr::SetAkAudioEnable(const bool bInEnable)
{
	// Test Function
	bEnableAudioPlay = bInEnable;
	if (UWorld* MyWorld = GetWorld())
	{
		const float Involume = bInEnable ? 1.f : 0.f;
		TArray<UAkComponent*> OutArray;
		UCWFuncLib::GetAllObjects<UAkComponent>(MyWorld, OutArray);
		for (UAkComponent* AkComp : OutArray)
		{
			AkComp->SetOutputBusVolume(Involume);
			//CWG_WARNING(">> AkVolume, Owner[%s] Id[%d].", *CWG_NAME(AkComp->GetOwner()), AkComp->GetAkGameObjectID());
		}
	}
	return bInEnable;
}

bool UCWAudioVideoMgr::IsAkAudioEnableInMgr() const
{
	return true;
}

UAkComponent* UCWAudioVideoMgr::GetAkComp(AActor* InActor, float InOcclusionRefreshInterval)
{
	UAkComponent* PlayComp = InActor ? UAkGameplayStatics::GetAkComponent(InActor->GetRootComponent()) : nullptr;
	if (IsValid(PlayComp))
	{	// 避免物体阻塞声音(0.0f)
		PlayComp->OcclusionRefreshInterval = InOcclusionRefreshInterval;
	}
	return PlayComp;
}

UAkComponent* UCWAudioVideoMgr::GetAkComp(ECWAudioType AudioType, float InOcclusionRefreshInterval /*= 0.f*/)
{
	if (AActor* AkActor = GetPlayAkActor(AudioType))
	{
		return GetAkComp(AkActor, InOcclusionRefreshInterval);
	}
	return nullptr;
}

bool UCWAudioVideoMgr::SetAkAudioLanguage(const FString& InLanguageKey)
{
	const FString& CurLanguageKey = GetAkAudioLanguage();
	if (InLanguageKey.IsEmpty() || InLanguageKey.Equals(CurLanguageKey))
	{
		return false;
	}

	if (UAkExtraGameplayStatics::SetAkAudioLanguage(InLanguageKey))
	{
		// 重新加载(AkBank)
		for (const auto& BankName : AudioBankList)
		{
			UAkGameplayStatics::UnloadBankByName(BankName);
		}
		for (const auto& BankName : AudioBankList)
		{
			UAkGameplayStatics::LoadBankByName(BankName);
		}
		return true;
	}
	return false;
}

FString UCWAudioVideoMgr::GetAkAudioLanguage()
{
	return MoveTempIfPossible(UAkExtraGameplayStatics::GetAkAudioLanguage());
}
