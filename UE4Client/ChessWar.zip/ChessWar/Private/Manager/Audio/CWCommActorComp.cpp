﻿
#include "CWCommActorComp.h"

#include "AkAudioEvent.h"
#include "CWAudioVideoMgr.h"


UCWCommActorComp::UCWCommActorComp(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

bool UCWCommActorComp::PlayAudio(const UAkAudioEvent* InAkEvent/* = nullptr*/, const FString& InAkEventName/* = TEXT("")*/)
{
	if (UCWAudioVideoMgr* AV_Mgr = AV_MGR(this))
	{
		const UAkAudioEvent* AkEvent = InAkEvent ? InAkEvent : DefaultAkEvent;
		return AV_Mgr->SimplePlayAudio(GetOwner(), AkEvent, InAkEventName);
	}
	return false;
}
