﻿
#include "CWCfgUtils.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWAudioData.h"
#include "CWCfgManager.h"
#include "CWWeatherMgr.h"
#include "CWWeatherData.h"
#include "CWMainCfgData.h"
#include "CWWeatherData.h"
#include "CWGameInstance.h"
#include "CWUIWidgetData.h"
#include "CWAssetManager.h"
#include "CWLanguageData.h"
#include "CWRandomEvtData.h"
#include "CWBuffDataStruct.h"
#include "CWPawnDataStruct.h"
#include "CWGameDataStruct.h"
#include "CWSkillDataStruct.h"
#include "CWRefrainTypeData.h"
#include "CWEffectDataStruct.h"
#include "CWRefrainFactorData.h"
#include "CWRefrainRelationData.h"
#include "CWProfessionDataStruct.h"
#include "CWDungeonItemDataStruct.h"
#include "CWDungeonRegionDataStruct.h"


FString FCWCfgUtils::Get_Cfg_Path(const FString& Path, const FString& File)
{
	return FString(Path + File + TEXT(".") + File + TEXT("'"));
}

FVector FCWCfgUtils::FString_To_FVector(const FString& InString, const FVector& InDefaultVector, const TCHAR* pchDelim)
{
	if (!InString.IsEmpty())
	{
		TArray<FString> OutArray;
		InString.ParseIntoArray(OutArray, pchDelim/*, false*/);
		if (OutArray.Num() == 1)
		{
			const float NewValue = FSTRING_TO_FLOAT(OutArray[0]);
			return FVector(NewValue, NewValue, NewValue);
		}
		else if (OutArray.Num() >= 3)
		{
			const float NewX = FSTRING_TO_FLOAT(OutArray[0]);
			const float NewY = FSTRING_TO_FLOAT(OutArray[1]);
			const float NewZ = FSTRING_TO_FLOAT(OutArray[2]);
			return FVector(NewX, NewY, NewZ);
		}
	}
	return InDefaultVector;
}

TArray<int32> FCWCfgUtils::FString_To_Array_Int32(const FString& InString, const TCHAR* pchDelim /*= TEXT("|")*/)
{
	TArray<int32> ResultArray;
	if (!InString.IsEmpty())
	{
		TArray<FString> OutArray;
		InString.ParseIntoArray(OutArray, pchDelim/*, false*/);
		for (int32 i = 0; i < OutArray.Num(); ++i)
		{
			const int32 NewValue = FSTRING_TO_INT(OutArray[i]);
			ResultArray.Push(NewValue);
		}
	}
	return ResultArray;
}

TArray<float> FCWCfgUtils::FString_To_Array_Float(const FString& InString, const TCHAR* pchDelim /*= TEXT("|")*/)
{
	TArray<float> RetArray;
	if (!InString.IsEmpty())
	{
		TArray<FString> OutArray;
		InString.ParseIntoArray(OutArray, pchDelim/*, false*/);
		for (int32 i = 0; i < OutArray.Num(); ++i)
		{
			const float NewValue = FSTRING_TO_FLOAT(OutArray[i]);
			RetArray.Push(NewValue);
		}
	}
	return RetArray;
}

TArray<FString> FCWCfgUtils::FString_To_Array_FString(const FString& InString, const TCHAR* pchDelim /*= TEXT("|")*/)
{
	TArray<FString> RetArray;
	if (!InString.IsEmpty())
	{
		InString.ParseIntoArray(RetArray, pchDelim/*, false*/);
	}
	return RetArray;
}

const UCWConfigTable* FCWCfgUtils::GetCfg(const UObject* WorldContext, const FString& InCfgKey)
{
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetConfigTable(InCfgKey) : nullptr);
}

/*const*/ FCWAssetData* FCWCfgUtils::GetAssetData(const UObject* WorldContext /*= nullptr*/, const FString& InAssetId /*= TEXT("")*/)
{
	if (InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetAssetData, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWAssetData>(FCWCfgKey::Asset, InAssetId) : nullptr);
}

/*const*/ FCWClassAssetData* FCWCfgUtils::GetClassAssetData(const UObject* WorldContext, const FString& InAssetId)
{
	if (InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetClassAssetData, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWClassAssetData>(FCWCfgKey::ClassAsset, InAssetId) : nullptr);
}

/*const*/ FCWUIAssetData* FCWCfgUtils::GetUIAssetData(const UObject* WorldContext, const FString& InAssetId)
{
	if (InAssetId.IsEmpty())
	{
		//CWG_WARNING(">>> FCWCfgUtils::GetUIAssetData, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWUIAssetData>(FCWCfgKey::UIAsset, InAssetId) : nullptr);
}

/*const*/ FCWPawnAssetData* FCWCfgUtils::GetPawnAssetData(const UObject* WorldContext, const FString& InAssetId)
{
	if (InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetPawnAssetData, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWPawnAssetData>(FCWCfgKey::PawnAsset, InAssetId) : nullptr);
}

/*const*/ FCWMeshAssetData* FCWCfgUtils::GetMeshAssetData(const UObject* WorldContext, const FString& InAssetId)
{
	if (InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetMeshAssetData, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWMeshAssetData>(FCWCfgKey::MeshAsset, InAssetId) : nullptr);
}

FCWAssetData* FCWCfgUtils::GetAssetDataFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId)
{
	if (InAssetCfg.IsEmpty() || InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetAssetObjectFromCfg, InAssetCfg[%s]/InAssetId[%s] is Empty!", *InAssetCfg, *InAssetId);
		return nullptr;
	}

	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWAssetData>(InAssetCfg, InAssetId) : nullptr);
}

FCWAssetData* FCWCfgUtils::GetClassAssetDataFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId)
{
	if (InAssetCfg.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetAssetClassFromCfg, InAssetCfg is Empty!");
		return nullptr;
	}

	if (InAssetId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetAssetClassFromCfg, InAssetId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWAssetData>(InAssetCfg, InAssetId) : nullptr);
}

TSubclassOf<UUserWidget> FCWCfgUtils::GetUIWidget(const UObject* WorldContext, const FString& InWidget)
{
	const FCWUIWidgetData* WidgetData = FCWCfgUtils::GetUIWidgetData(WorldContext, InWidget);
	if (nullptr != WidgetData)
	{
		return WidgetData->UIWidget;
	}
	return nullptr;
}

const FCWUIWidgetData* FCWCfgUtils::GetUIWidgetData(const UObject* WorldContext, const FString& InWidget)
{
	if (InWidget.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetUIWidgetData, InWidget Is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWUIWidgetData>(FCWCfgKey::UIWidget, InWidget) : nullptr);
}

const FCWWeatherData* FCWCfgUtils::GetWeatherData(const UObject* WorldContext, const int32 InId)
{
	if (!UCWWeatherMgr::IsValidWeatherIdx(InId))
	{
		//CWG_WARNING(">>> FCWCfgUtils::GetWeatherData, InId[%d] is inValid!", InId);
		return nullptr;
	}
	FString InRowName = INT_TO_FSTRING(InId);
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWWeatherData>(FCWCfgKey::Weather, InRowName) : nullptr);
}

const struct FCWAudioData* FCWCfgUtils::GetAudioData(const UObject* WorldContext /*= nullptr*/, const FString& InSoundId /*= TEXT("")*/)
{
	if (InSoundId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetAudioData, InSoundId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWAudioData>(FCWCfgKey::Audio, InSoundId) : nullptr);
}

const FCWPawnDataStruct* FCWCfgUtils::GetPawnData(const UObject* WorldContext, const int32 InPawnId)
{
	if (InPawnId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWPawnDataStruct>(FCWCfgKey::PawnData, INT_TO_FNAME(InPawnId)) : nullptr);
}

const FCWSkillDataStruct* FCWCfgUtils::GetSkillData(const UObject* WorldContext, const int32 InSkillId)
{
	if (InSkillId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWSkillDataStruct>(FCWCfgKey::SkillData, INT_TO_FNAME(InSkillId)) : nullptr);
}

/*const*/ FCWSkillDataStruct* FCWCfgUtils::GetTalentData(const UObject* WorldContext, const int32 InTalentId)
{
	if (InTalentId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWSkillDataStruct>(FCWCfgKey::TalentData, INT_TO_FNAME(InTalentId)) : nullptr);
}

const FCWDungeonItemDataStruct* FCWCfgUtils::GetLevelItemData(const UObject* WorldContext, const int32 InItemId)
{
	if (InItemId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWDungeonItemDataStruct>(FCWCfgKey::LevelItem, INT_TO_FNAME(InItemId)) : nullptr);
}

bool FCWCfgUtils::GetBelongRefrainTypeArray(const UObject* WorldContext, const FString& InId, TArray<FString>& OutList)
{
	OutList.Empty();

	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	if (!InId.IsEmpty() && (nullptr != CfgMgr))
	{
		if (const UCWConfigTable* ConfigTable = CfgMgr->GetConfigTable(FCWCfgKey::RefrainType))
		{
			if (const UDataTable* DataTable = ConfigTable->GetBaseTable())
			{
				auto CheckAddToList = [InId, &OutList](const FName& Key, const FCWRefrainTypeData& Value)
				{
					if (Value.OwnerIds.Contains(InId))
					{
						OutList.AddUnique(FNAME_TO_FSTRING(Key));
					}
				};
				DataTable->ForeachRow<FCWRefrainTypeData>(TEXT(""), CheckAddToList);
				return true;
			}
		}
	}
	return false;
}

FString FCWCfgUtils::GetBelongRefrainTypeString(const UObject* WorldContext, const FString& InId)
{
	FString OutString;
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	if (nullptr != CfgMgr && !InId.IsEmpty())
	{
		if (const UCWConfigTable* ConfigTable = CfgMgr->GetConfigTable(FCWCfgKey::RefrainType))
		{
			if (const UDataTable* DataTable = ConfigTable->GetBaseTable())
			{
				auto CheckAddToList = [InId, &OutString](const FName& Key, const FCWRefrainTypeData& Value)
				{
					if (Value.OwnerIds.Contains(InId))
					{
						OutString += FNAME_TO_FSTRING(Key).Append(TEXT("|"));
					}
				};
				DataTable->ForeachRow<FCWRefrainTypeData>(TEXT(""), CheckAddToList);
			}
		}
	}
	return OutString;
}

const FCWRefrainTypeData* FCWCfgUtils::GetRefrainTypeData(const UObject* WorldContext, const FString& InTypeId)
{
	if (InTypeId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetRefrainTypeData, InTypeId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWRefrainTypeData>(FCWCfgKey::RefrainType, InTypeId) : nullptr);
}

const FCWRefrainFactorData* FCWCfgUtils::GetRefrainFactorData(const UObject* WorldContext, const FString& InFactorId)
{
	if (InFactorId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetRefrainFactorData, InFactorId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWRefrainFactorData>(FCWCfgKey::RefrainFactor, InFactorId) : nullptr);
}

const FCWRefrainRelationData* FCWCfgUtils::GetRefrainRelationData(const UObject* WorldContext, const FString& InRelationId)
{
	if (InRelationId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetRefrainRelationData, InRelationId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWRefrainRelationData>(FCWCfgKey::RefrainRelation, InRelationId) : nullptr);
}

const FCWLanguageData* FCWCfgUtils::GetLanguageData(const UObject* WorldContext, const FString& InId)
{
	if (InId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetLanguageData, InId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWLanguageData>(FCWCfgKey::Language, InId) : nullptr);
}

FString FCWCfgUtils::GetLanguageString(const UObject* WorldContext, const FString& InId)
{
	const FCWLanguageData* LanguageData = FCWCfgUtils::GetLanguageData(WorldContext, InId);
	return LanguageData ? FTEXT_TO_FSTRING(LanguageData->Language) : TEXT("");
}

const FCWClientConstData* FCWCfgUtils::GetConstData(const UObject* WorldContext, const FString& InConstCfg, const FString& InId)
{
	if (InConstCfg.IsEmpty() || InId.IsEmpty())
	{
		CWG_WARNING(">>> FCWCfgUtils::GetConstData, InConstCfg/InId is Empty!");
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWClientConstData>(InConstCfg, InId) : nullptr);
}

const FCWRandomEvtData* FCWCfgUtils::GetRandomEvtData(const UObject* WorldContext, const int32 InId)
{
	if (InId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWRandomEvtData>(FCWCfgKey::RandomEvt, INT_TO_FNAME(InId)) : nullptr);
}

const FCWBuffDataStruct* FCWCfgUtils::GetBuffData(const UObject* WorldContext, const int32 InBuffId)
{
	if (InBuffId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWBuffDataStruct>(FCWCfgKey::BuffCfg, INT_TO_FNAME(InBuffId)) : nullptr);
}

const FCWObjElemInfoData* FCWCfgUtils::GetObjElemInfoData(const UObject* WorldContext, const int32 InObjElemId)
{
	if (InObjElemId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWObjElemInfoData>(FCWCfgKey::ObjElemInfo, INT_TO_FNAME(InObjElemId)) : nullptr);
}

const FCWObjWithElemReactionData* FCWCfgUtils::GetObjWithElemReactionData(const UObject* WorldContext, const int32 InReactionId)
{
	if (InReactionId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(WorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWObjWithElemReactionData>(FCWCfgKey::ObjWithElemReaction, INT_TO_FNAME(InReactionId)) : nullptr);
}

const FCWEffectDataStruct* FCWCfgUtils::GetEffectData(const UObject* InWorldContext, const int32 InEffectId)
{
	if (InEffectId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(InWorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWEffectDataStruct>(FCWCfgKey::EffectCfg, INT_TO_FNAME(InEffectId)) : nullptr);
}

const FCWGameDataStruct* FCWCfgUtils::GetGameData(const UObject* InWorldContext, const int32 InGameId)
{
	if (InGameId <= 0)
	{
		return nullptr;
	}
	UCWCfgManager* CfgMgr = CFG_MGR(InWorldContext);
	return (IsValid(CfgMgr) ? CfgMgr->GetCfgRowData<FCWGameDataStruct>(FCWCfgKey::GameCfg, INT_TO_FNAME(InGameId)) : nullptr);
}

const FCWProfessionDataStruct* FCWCfgUtils::GetProfessionData(const UObject* InWorldContext, const int32 InProfessionId)
{
	UCWCfgManager* CfgMgr = CFG_MGR(InWorldContext);
	if (InProfessionId > 0 && IsValidObject(CfgMgr))
	{
		return CfgMgr->GetCfgRowData<FCWProfessionDataStruct>(FCWCfgKey::ProfessionCfg, INT_TO_FNAME(InProfessionId));
	}
	return nullptr;
}

const FCWDungeonRegionDataStruct* FCWCfgUtils::GetDungeonRegionData(const UObject* InWorldContext, const int32 InRegionId)
{
	UCWCfgManager* CfgMgr = CFG_MGR(InWorldContext);
	if (InRegionId > 0 && IsValidObject(CfgMgr))
	{
		return CfgMgr->GetCfgRowData<FCWDungeonRegionDataStruct>(FCWCfgKey::DungeonRegionCfg, INT_TO_FNAME(InRegionId));
	}
	return nullptr;
}
