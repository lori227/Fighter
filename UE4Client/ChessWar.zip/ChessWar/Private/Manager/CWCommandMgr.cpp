﻿
#include "CWCommandMgr.h"

#include "Engine/World.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWGameInstance.h"
#include "CWClientConstData.h"


CWCommandMgr::CWCommandMgr()
{
}

CWCommandMgr::~CWCommandMgr()
{
}

const FString CWCommandMgr::GetUEServerId()
{
	// PS: "40.0.1"
	FString RetValue;
	const TCHAR* CommandLine = FCommandLine::Get();
	if (FParse::Value(CommandLine, TEXT("UESId="), RetValue))
	{
		return RetValue;
	}

	// Config
	const FCWClientConstData* ConstData = 
		FCWCfgUtils::GetConstData(nullptr, FCWCfgKey::ConstLocal, TEXT("UESId="));
	if (nullptr != ConstData)
	{
		CWG_INFO(">> CWCommandMgr::GetUEServerId, UESId[%s] From Cfg[ConstLocalCfg]! CommandLine[%s].", *ConstData->Param, CommandLine);
		return ConstData->Param;
	}

	CWG_ERROR(">> CWCommandMgr::GetUEServerId, ERROR! CommandLine[%s].", CommandLine);
	return TEXT("");
}

const FString CWCommandMgr::GetUEServerIp()
{
	// PS: "192.168.0.139"
	FString RetValue;
	const TCHAR* CommandLine = FCommandLine::Get();
	if (FParse::Value(CommandLine, TEXT("UESIp="), RetValue))
	{
		return RetValue;
	}

	CWG_ERROR(">> CWCommandMgr::GetUEServerIp, ERROR! CommandLine[%s].", CommandLine);
	return TEXT("");
}

const int32 CWCommandMgr::GetUEServerPort()
{
	// PS: "7777"
	FString RetValue;
	const TCHAR* CommandLine = FCommandLine::Get();
	if (FParse::Value(CommandLine, TEXT("Port="), RetValue))
	{
		int32 Port = FSTRING_TO_INT(RetValue);
		return Port;
	}

	CWG_ERROR(">> CWCommandMgr::GetUEServerPort, ERROR! CommandLine[%s].", CommandLine);
	return INDEX_NONE;
}

const FString CWCommandMgr::GetGateWayIp()
{
	// PS: "192.168.0.139"
	FString RetValue;
	const TCHAR* CommandLine = FCommandLine::Get();
	if (FParse::Value(CommandLine, TEXT("GWIp="), RetValue))
	{
		return RetValue;
	}

	CWG_ERROR(">> CWCommandMgr::GetGateWayIp, ERROR! CommandLine[%s].", CommandLine);
	return TEXT("");
}

const int32 CWCommandMgr::GetGateWayPort()
{
	// PS: "7777"
	FString RetValue;
	const TCHAR* CommandLine = FCommandLine::Get();
	if (FParse::Value(CommandLine, TEXT("GWPort="), RetValue))
	{
		int32 Port = FSTRING_TO_INT(RetValue);
		return Port;
	}

	CWG_ERROR(">> CWCommandMgr::GetGateWayPort, ERROR! CommandLine[%s].", CommandLine);
	return INDEX_NONE;
}
