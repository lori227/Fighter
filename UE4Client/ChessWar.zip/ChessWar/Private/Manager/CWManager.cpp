﻿
#include "CWManager.h"
#include "Engine/World.h"

#include "CWComDef.h"
#include "CWGameInstance.h"

UCWManager::UCWManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWManager::~UCWManager()
{
}

bool UCWManager::InitMgr(UCWGameInstance* InGlobalGI)
{
	AddToRoot();
	Global_GI = InGlobalGI;
	return Global_GI.IsValid();
}

void UCWManager::Tick(float DeltaTime)
{

}

void UCWManager::Destroy()
{
	RemoveFromRoot();
	ConditionalBeginDestroy();
}

UWorld* UCWManager::GetWorld() const
{
	UWorld* MyWorld = Super::GetWorld();
	if (!IsValid(MyWorld) && Global_GI.IsValid())
	{
		MyWorld = Global_GI->GetWorld();
	}
	return MyWorld;
}

void UCWManager::BeginDestroy()
{
	Super::BeginDestroy();
}

bool UCWManager::IsInEditor()
{
	return GIsEditor;
}
