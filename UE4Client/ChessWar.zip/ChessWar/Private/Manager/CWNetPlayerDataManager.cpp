
#include "CWNetPlayerDataManager.h"
#include "CWFuncLib.h"
#include "CWGameInstance.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/Paths.h"
#include "GenericPlatformFile.h"
#include "Engine/Engine.h"
#include "CWEventMgr.h"
#include "CWNetPlayerData.h"
#include "CWNetHeroData.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWNetPlayerDataManager, All, All);

UCWNetPlayerDataManager::UCWNetPlayerDataManager(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

UCWNetPlayerDataManager* UCWNetPlayerDataManager::GetNetPlayerDataMgr(const UObject* InWorldContextObj)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetNetPlayerDataMgr() : nullptr;
}


bool UCWNetPlayerDataManager::InitMgr(UCWGameInstance* InGlobalGI)
{
	Super::InitMgr(InGlobalGI);

	return true;
}

void UCWNetPlayerDataManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void UCWNetPlayerDataManager::Destroy()
{
	RemoveAllNetPlayerData();

	Super::Destroy();
}

UCWNetPlayerData* UCWNetPlayerDataManager::GetNetPlayerData(uint64 ParamUUID)
{
	if (MapNetPlayerData.Contains(ParamUUID))
	{
		UCWNetPlayerData* TempNetPlayerData = MapNetPlayerData[ParamUUID];
		return TempNetPlayerData;
	}

	return nullptr;
}

bool UCWNetPlayerDataManager::AddNetPlayerData(uint64 ParamUUID, UCWNetPlayerData* ParamNetPlayerData)
{
	if (ParamUUID == 0)
	{
		UE_LOG(LogCWNetPlayerDataManager, Error, TEXT("UCWNetPlayerDataManager::AddNetPlayerData..., ParamUUID:%d."), ParamUUID);
		return false;
	}

	if (MapNetPlayerData.Contains(ParamUUID))
	{
		return false;
	}

	check(ParamNetPlayerData);
	MapNetPlayerData.Add(ParamUUID, ParamNetPlayerData);
	return true;
}

void UCWNetPlayerDataManager::RemoveAllNetPlayerData()
{
	for (TMap<uint64, UCWNetPlayerData*>::TIterator iter = MapNetPlayerData.CreateIterator(); iter; ++iter)
	{
		UCWNetPlayerData* TempNetPlayerData = iter->Value;
		check(TempNetPlayerData);
		TempNetPlayerData->RemoveAllNetHeroData();
		TempNetPlayerData->ConditionalBeginDestroy();
		TempNetPlayerData = nullptr;
	}

	MapNetPlayerData.Empty();
};


