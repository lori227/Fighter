
#include "CWSluaManager.h"
#include "CWFuncLib.h"
#include "LuaState.h"
#include "CWGameInstance.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/Paths.h"
#include "GenericPlatformFile.h"
#include "Engine/Engine.h"
#include "CWEventMgr.h"

UCWSluaManager::UCWSluaManager(const FObjectInitializer& ObjectInitializer)
:Super(ObjectInitializer)
{
	m_loadedLevelName = "";
	m_bIsLuaMainServerStarted = false;
	m_bIsLuaMainClientStarted = false;
}

UCWSluaManager* UCWSluaManager::GetSluaMgr(const UObject* InWorldContextObj)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetSluaMgr() : nullptr;
}

// read file content
static uint8* ReadFile(IPlatformFile& PlatformFile, FString path, uint32& len) {
	IFileHandle* FileHandle = PlatformFile.OpenRead(*path);
	if (FileHandle) {
		len = (uint32)FileHandle->Size();
		uint8* buf = new uint8[len];

		FileHandle->Read(buf, len);

		// Close the file again
		delete FileHandle;

		return buf;
	}

	return nullptr;
}

bool UCWSluaManager::InitMgr(UCWGameInstance* InGlobalGI)
{
	Super::InitMgr(InGlobalGI);

	if (!GetWorld()->IsNetMode(NM_DedicatedServer))
	{
		if (!m_clientLuaState.init())
		{
			return false;
		}
	}

	if (GetWorld()->IsNetMode(NM_DedicatedServer))
	{
		if (!m_serverLuaState.init())
		{
			return false;
		}
	}

	ADD_EVT_DELEGATE(UCWGameInstance::GetInstance()->GetEventMgr()->OnPlayerLoginCompleted, this, &UCWSluaManager::OnPlayerLoginCompleted, FName("OnPlayerLoginCompleted"));

	return true;
}

void UCWSluaManager::ResetInClient()
{
	if (!GetWorld()->IsNetMode(NM_DedicatedServer))
	{
		m_clientLuaState.close();
		m_clientLuaState.init();

		auto state = ClientLuaState();
		state->setLoadFileDelegate([](const char* fn, uint32& len, FString& filepath)->uint8*
		{
			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
			FString path = FPaths::ProjectContentDir();
			path += "/Lua/LuaClient/";
			path += UTF8_TO_TCHAR(fn);
			TArray<FString> luaExts = { UTF8_TO_TCHAR(".lua"), UTF8_TO_TCHAR(".luac") };
			for (auto ptr = luaExts.CreateConstIterator(); ptr; ++ptr)
			{
				auto fullPath = path + *ptr;
				auto buf = ReadFile(PlatformFile, fullPath, len);
				if (buf)
				{
					filepath = fullPath;
					return buf;
				}
			}

			return nullptr;
		});

		slua::LuaVar v = state->doFile("mainClient");
		if (!v.isNil())
		{
			ensure(v.getAt(1).asInt() == 1);
			slua::Log::Log("mainClient return value is %d", v.getAt(1).asInt());
		}

		state->call("mainClient.Init");

		m_bIsLuaMainClientStarted = true;
	}
}

void UCWSluaManager::OnPlayerLoginCompleted(const FGameModeData GameModeData)
{

}

void UCWSluaManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (m_bIsLuaMainClientStarted)
	{
		m_clientLuaState.tick(DeltaTime);

		auto state = ClientLuaState();
		slua::LuaVar v = state->call("mainClient.Update", DeltaTime);
		if (!v.isNil())
		{
			ensure(v.getAt(1).asInt() == 2);
			slua::Log::Log("mainClient Tick return value is %d", v.getAt(1).asInt());
		}
	}

	if (m_bIsLuaMainServerStarted)
	{
		m_serverLuaState.tick(DeltaTime);

		auto state = ServerLuaState();
		slua::LuaVar v = state->call("mainServer.Update", DeltaTime);
		if (!v.isNil())
		{
			ensure(v.getAt(1).asInt() == 2);
			slua::Log::Log("mainServer Tick return value is %d", v.getAt(1).asInt());
		}
	}
}

void UCWSluaManager::Destroy()
{
	if (m_bIsLuaMainClientStarted)
	{
		m_clientLuaState.close();
	}

	if (m_bIsLuaMainServerStarted)
	{
		m_serverLuaState.close();
	}
	
	Super::Destroy();
}

slua::LuaState* UCWSluaManager::ClientLuaState()
{
	return &m_clientLuaState; 
}

slua::LuaState* UCWSluaManager::ServerLuaState()
{
	return &m_serverLuaState; 
}
