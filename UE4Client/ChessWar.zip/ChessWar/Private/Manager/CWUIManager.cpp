﻿
#include "CWUIManager.h"

#include "MoviePlayer.h"
#include "Engine/Texture2D.h"
#include "CWPlayerController.h"
#include "WidgetBlueprintLibrary.h"

#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWSluaManager.h"
#include "UICommConfirm.h"
#include "CWPlayerState.h"
#include "CWGameInstance.h"
#include "SLoadingScreen.h"
#include "Public/LuaState.h"


UCWUIManager::UCWUIManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, EnablePawnUIMode(0)
{
}

UCWUIManager* UCWUIManager::GetUIMgr(const UObject* InWorldContextObj)
{
#if !UE_SERVER
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetUIMgr() : nullptr;
#else
	return nullptr;
#endif
}

bool UCWUIManager::InitMgr(UCWGameInstance* InGlobalGI)
{
	Super::InitMgr(InGlobalGI);

	if (UCWFuncLib::IsCanInitCustomData(this))
	{
		FCoreUObjectDelegates::PreLoadMap.AddUObject(this, &UCWUIManager::OnPreLoadMap);
		UCWEventMgr::OnPreloadContentForURL.AddUObject(this, &UCWUIManager::OnPreloadContentForURL);
		FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UCWUIManager::OnPostLoadMapWithWorld);
		UCWEventMgr::OnLevelLoadComplete.AddUObject(this, &UCWUIManager::OnLevelLoadComplete);

		if (UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr)
		{
			ADD_EVT_DELEGATE(EvtMgr->OnKeyPressed, this, &UCWUIManager::OnKeyPressed, FName("OnKeyPressed"));
			ADD_EVT_DELEGATE(EvtMgr->OnPlayerSendMessage, this, &UCWUIManager::OnSendMessage, FName("OnSendMessage"));

			ADD_EVT_DELEGATE(EvtMgr->OnHUDBeginPlayed, this, &UCWUIManager::OnHUDBeginPlayed, FName("OnHUDBeginPlayed"));
			ADD_EVT_DELEGATE(EvtMgr->OnPlayerLoginCompleted, this, &UCWUIManager::OnPlayerLoginCompleted, FName("OnPlayerLoginCompleted"));
		}

		/*FScriptDelegate Delegate;
		Delegate.BindUFunction(this, FName("OnWindowTitleBarCloseClicked"));
		UWidgetBlueprintLibrary::FOnGameWindowCloseButtonClickedDelegate ClickedDelegate(Delegate);
		UWidgetBlueprintLibrary::SetWindowTitleBarOnCloseClickedDelegate(ClickedDelegate);*/
		//UWidgetBlueprintLibrary::SetWindowTitleBarCloseButtonActive(false);
	}

	return true;
}

void UCWUIManager::Destroy()
{
	if (UCWFuncLib::IsCanDestroyCustomData(this))
	{
		FCoreUObjectDelegates::PreLoadMap.RemoveAll(this);
		UCWEventMgr::OnPreloadContentForURL.RemoveAll(this);
		FCoreUObjectDelegates::PostLoadMapWithWorld.RemoveAll(this);
		UCWEventMgr::OnLevelLoadComplete.RemoveAll(this);

		if (UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr)
		{
			REMOVE_EVT_DELEGATE(EvtMgr->OnKeyPressed, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnPlayerSendMessage, this);

			REMOVE_EVT_DELEGATE(EvtMgr->OnHUDBeginPlayed, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnPlayerLoginCompleted, this);
		}

		//UWidgetBlueprintLibrary::SetWindowTitleBarOnCloseClickedDelegate(nullptr);

		ClearUICache();
	}

	Super::Destroy();
}

void UCWUIManager::SetInputMode(EUIInputMode InputMode)
{
	if (APlayerController* LocalPC = GetPlayerController())
	{
		switch (InputMode)
		{
		case EUIInputMode::GameOnly:
		{
			struct FInputModeGameOnly Mode;
			LocalPC->SetInputMode(Mode);
		}break;
		case EUIInputMode::UIOnly:
		{
			struct FInputModeUIOnly Mode;
			Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			LocalPC->SetInputMode(Mode);
		}break;
		case EUIInputMode::GameAndUI:
		{
			struct FInputModeGameAndUI Mode;
			Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock).SetHideCursorDuringCapture(false);
			LocalPC->SetInputMode(Mode);
		}break;
		default:
		{
			CWG_LOG(">> %s::SetInputMode, InputMode is None!", *CWG_NAME(this));
		}break;
		}
	}
}

void UCWUIManager::ShowMouseCursor(bool bShow)
{
	if (APlayerController* LocalPC = GetPlayerController())
	{
		LocalPC->bShowMouseCursor = bShow;
	}
}

void UCWUIManager::LuaOpenUI(const UObject* InWorldContextObj, const FString& InUIKey)
{
	UCWSluaManager* SluaManager = UCWSluaManager::GetSluaMgr(InWorldContextObj);
	if (nullptr != SluaManager)
	{
		slua::LuaState* ClientLuaState = SluaManager->ClientLuaState();
		if (nullptr != ClientLuaState)
		{
			// OPEN_GAMESETTING
			ClientLuaState->call("g_UIManager.OpenUI", "self", InUIKey);
		}
	}
}

void UCWUIManager::LuaCloseUI(const UObject* InWorldContextObj, const FString& InUIKey)
{
	UCWSluaManager* SluaManager = UCWSluaManager::GetSluaMgr(InWorldContextObj);
	if (nullptr != SluaManager)
	{
		slua::LuaState* ClientLuaState = SluaManager->ClientLuaState();
		if (nullptr != ClientLuaState)
		{
			// CLOSE_GAMESETTING
			ClientLuaState->call("g_UIManager.CloseUI", "self", InUIKey);
		}
	}
}

UUserWidget* UCWUIManager::OpenUI(const FString& UIName, const int32 ZOrder)
{
	bool bSuccess = true;
	UCWUserWidget* UIWidget = GetUIWidget(UIName);
	if (!IsValidWidget(UIWidget))
	{
		UCWUserWidget* OpUI = CreateUIWidget(UIName);
		if (IsValidWidget(OpUI))
		{
			OpUI->ShowWidget(true, ZOrder);
			OpUI->AddToViewport();
		}
		else
		{
			bSuccess = false;
		}
		UIWidget = OpUI;
	}
	else if(!UIWidget->IsInViewport())
	{
		UIWidget->ShowWidget(true, ZOrder);
		UIWidget->AddToViewport();
	}
	CWG_LOG(">> %s::OpenUI(%s) -> %s !", *CWG_NAME(this), *UIName, *(bSuccess ? FString("Success") : FString("Fail")));
	return UIWidget;
}

bool UCWUIManager::DestroyUI(const FString& UIName)
{
	UCWUserWidget* OpUI = GetUIWidget(UIName);
	if (IsValidWidget(OpUI))
	{
		OpUI->DestroyWidget();
		//OpUI->RemoveFromViewport();
		//OpUI->ConditionalBeginDestroy();
		//RemoveUICache(UIName);
		return true;
	}
	return false;
}

UUserWidget* UCWUIManager::HideUI(const FString& UIName)
{
	UCWUserWidget* OpUI = GetUIWidget(UIName);
	if (IsValidWidget(OpUI))
	{
		OpUI->ShowWidget(false);
	}
	return OpUI;
}

bool UCWUIManager::IsValidWidget(const UCWUserWidget* Widget)
{
	return IsValidObject(Widget);
}

void UCWUIManager::OnKeyPressed(const FKey InKey)
{
	/*if (InKey == EKeys::Escape)
	{
		//if (GameModeData.GameStage == ECWGameStage::Battle)
		if (UUICommConfirm* CommConfirm = Cast<UUICommConfirm>(GetUIWidget(FUIKey::UICommConfirm)))
		{	// 是否打开确认框
			CommConfirm->OnCancelButtonClick();
		}
		else if (GetUIWidget(FUIKey::UISetting) != nullptr)
		{	// 是否打开设置界面
			DestroyUI(FUIKey::UISetting);
		}
		else
		{
			OpenUI(FUIKey::UISetting);
		}
	}
	else if(InKey == EKeys::Android_Back)
	{
		if (UUICommConfirm* CommConfirm = Cast<UUICommConfirm>(OpenUI(FUIKey::UICommConfirm, 250)))
		{	// 设置为退出确认界面
			CommConfirm->SetCommConfirmMode(1);
		}
	}*/
}

void UCWUIManager::OnWindowTitleBarCloseClicked()
{
	//OpenUI(FUIKey::UICommConfirm);
}

void UCWUIManager::OnHUDBeginPlayed(const bool bBeginPlay)
{
	if (bBeginPlay)
	{
		switch (GameModeData.GameStage)
		{
		case ECWGameStage::Login:
		{
			//OpenUI(FUIKey::UILogin);
			SetInputMode(EUIInputMode::UIOnly);
			ShowMouseCursor(true);
		}break;
		case ECWGameStage::Battle:
		{
			OpenUI(FUIKey::UIFight);
			//SetInputMode(EUIInputMode::UIOnly);
			//ShowMouseCursor(true);
		}break;
		default:
		{
			/*CWG_WARNING(">> %s::OnPlayerLoginCompleted, GameStage[%s].", *GetName(),
				*FCWCommonUtil::EnumToString(TEXT("ECWGameStage"), GameModeData.GameStage));*/
		}break;
		}
	}
}

void UCWUIManager::OnPlayerLoginCompleted(const FGameModeData InGameModeData)
{
	GameModeData = InGameModeData;
}

void UCWUIManager::OnSendMessage(const int32 InMsgId, const FString& InParam)
{
	//OpenUI(FUIKey::UITips);
}

void UCWUIManager::RemoveUICache(const FString& UIName)
{
	if (!UIName.IsEmpty() && UICache.Num() > 0 && UICache.Contains(UIName))
	{
		CWG_LOG("%s::RemoveUICache(UIName: %s) !", *CWG_NAME(this), *UIName)
		UICache.Remove(UIName);
	}
}

void UCWUIManager::ClearUICache()
{
	for (TMap<FString, TWeakObjectPtr<UCWUserWidget>>::TConstIterator iter(UICache); iter; ++iter)
	{
		UCWUserWidget* Widget = (iter->Value).Get();
		if (IsValidWidget(Widget))
		{
			Widget->RemoveFromParent();
			//iter->Value.Get()->RemoveFromViewport();
			//iter->Value.Get()->ConditionalBeginDestroy();
		}
		/*CWG_LOG(">> %s::ClearUICache, Key: %s.", *CWG_Name(this), *iter->Key);
		UICache.Remove(iter->Key);*/
	}
	UICache.Empty();
}

UTexture2D* UCWUIManager::GetTexture2D(const FString& TextName)
{
	FString URL = "Texture2D'/Game/Resource/UI/Texture/" + TextName + "." + TextName + "'";
	UTexture2D* Texture = LoadObject<UTexture2D>(nullptr, *URL);
	return Texture;
}

UCWUserWidget* UCWUIManager::GetUIWidget(const FString& UIName)
{
	if (UICache.Num() > 0 && UICache.Contains(UIName))
	{
		UCWUserWidget* OutWidget = (*UICache.Find(UIName)).Get();
		return OutWidget;
	}
	return nullptr;
}

UCWUserWidget* UCWUIManager::CreateUIWidget(const FString& UIName)
{
	UWorld* const MyWorld = GetWorld();
	TSubclassOf<UCWUserWidget> UITemplate = GetUITemplate(UIName);
	if (nullptr != UITemplate)
	{
		UCWUserWidget* Widget = CreateWidget<UCWUserWidget>(MyWorld, UITemplate);
		check(Widget);
		Widget->InitWidget(FUIWidgetData(UIName));
		UICache.Add(UIName, TWeakObjectPtr<UCWUserWidget>(Widget));
		return Widget;
	}
	CWG_WARNING("%s::CreateUIWidget(%s) Not load!", *CWG_NAME(this), *UIName);
	return nullptr;
}

class ACWPlayerController* UCWUIManager::GetLocalPC()
{
	APlayerController* LocalPC = GetPlayerController();
	return Cast<ACWPlayerController>(LocalPC);
}

class APlayerController* UCWUIManager::GetPlayerController() const
{
	const UWorld* const MyWorld = GetWorld();
	return MyWorld ? MyWorld->GetFirstPlayerController() : nullptr;
}

TSubclassOf<UCWUserWidget> UCWUIManager::GetUITemplate(const FString& UIName)
{
	if (UIWidgets.Num() > 0 && UIWidgets.Contains(UIName))
	{
		return *UIWidgets.Find(UIName); //*UIWidgets[UIName]
	}
	CWG_WARNING("%s::GetUITemplate, UIWidgets not contains %s!", *CWG_NAME(this), *UIName);
	return nullptr;
}

uint8 UCWUIManager::SetEnablePawnUI(uint8 InMode)
{
	EnablePawnUIMode = InMode;
	OnUpdateWolrdPawnUI();
	return EnablePawnUIMode;
}

uint8 UCWUIManager::GetEnablePawnUIMode() const
{
	return EnablePawnUIMode;
}

void UCWUIManager::OnUpdateWolrdPawnUI()
{
	if (UWorld* const MyWorld = GetWorld())
	{
		ACWPlayerController* const LocalPC = GetLocalPC();
		const bool bIsInitPlayerState = (LocalPC && LocalPC->GetPlayerState());
		ACWPawn* SelectPawn = bIsInitPlayerState ? LocalPC->GetCurSelectedPawn() : nullptr;
		ACWPawn* TargetPawn = bIsInitPlayerState ? LocalPC->GetCurTargetSelectedPawn() : nullptr;
		auto IsSamePawn = [](const ACWPawn* InPawn, const ACWPawn* InOtherPawn)
		{
			if (nullptr != InPawn && InPawn == InOtherPawn)
			{
				return true;
			}
			return false;
		};

		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			// 保证当前选中己方和目标显示
			ACWPawn* GPawn = *Iter;
			if (IsValid(GPawn) && GPawn->IsAllowOperate() &&
				!IsSamePawn(GPawn, SelectPawn) && !IsSamePawn(GPawn, TargetPawn))
			{
				const bool bNewVisible = (EnablePawnUIMode < 2) ? (bool)EnablePawnUIMode : !LocalPC->IsEnemy(GPawn);
				GPawn->ShowUserWidget(bNewVisible);
			}
		}
	}
}

void UCWUIManager::PlayCameraShake(TSubclassOf<class UCameraShake> InShake)
{
	if (!IsValid(InShake))
	{
		return;
	}

	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->ClientPlayCameraShake(InShake);
	}
}

void UCWUIManager::StopCameraShake(TSubclassOf<class UCameraShake> InShake)
{
	if (!IsValid(InShake))
	{
		return;
	}

	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->ClientStopCameraShake(InShake);
	}
}

void UCWUIManager::StopAllCameraShake()
{
	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->PlayerCameraManager->StopAllCameraShakes();
	}
}

void UCWUIManager::PlayCameraAnim(class UCameraAnim* AnimToPlay, float Scale /*= 1.f*/, float Rate /*= 1.f*/, 
	float BlendInTime /*= 0.f*/, float BlendOutTime /*= 0.f*/, bool bLoop /*= false*/, bool bRandomStartTime /*= false*/, 
	ECameraAnimPlaySpace::Type Space /*= ECameraAnimPlaySpace::CameraLocal*/, FRotator CustomPlaySpace /*= FRotator::ZeroRotator*/)
{
	if (!IsValid(AnimToPlay))
	{
		return;
	}

	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->ClientPlayCameraAnim(AnimToPlay, Scale, Rate, BlendInTime, BlendOutTime, bLoop, bRandomStartTime, Space, CustomPlaySpace);
	}
}

void UCWUIManager::StopCameraAnim(class UCameraAnim* AnimToStop)
{
	if (!IsValid(AnimToStop))
	{
		return;
	}

	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->ClientStopCameraAnim(AnimToStop);
	}
}

void UCWUIManager::StopAllCameraAnims(bool bImmediate /*= false*/)
{
	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->PlayerCameraManager->StopAllCameraAnims(bImmediate);
	}
}

void UCWUIManager::SetCinematicMode(bool bInCinematicMode, bool bHidePlayer /*= true*/, 
	bool bAffectsHUD /*= false*/, bool bAffectsMovement /*= false*/, bool bAffectsTurning /*= false*/)
{
	APlayerController* PC = GetPlayerController();
	if (nullptr != PC && nullptr != PC->PlayerCameraManager)
	{
		PC->SetCinematicMode(bInCinematicMode, bHidePlayer, bAffectsHUD, bAffectsMovement, bAffectsTurning);
	}
}

void UCWUIManager::OnPreLoadMap(const FString& MapName)
{
	ClearUICache();

#if !UE_SERVER
	const UWorld* MyWorld = Global_GI.IsValid() ? Global_GI->GetWorld() : nullptr;
	if (nullptr != MyWorld && !MyWorld->IsNetMode(NM_DedicatedServer))
	{
		PlayLoadingScreen(true, 1.0f);
	}
#endif
}

void UCWUIManager::OnPreloadContentForURL(FURL InURL)
{
}

void UCWUIManager::OnPostLoadMapWithWorld(UWorld* World)
{
}

void UCWUIManager::OnLevelLoadComplete(const float LoadTime, const FString& MapName)
{
#if !UE_SERVER
	const UWorld* const MyWorld = GetWorld();
	if (nullptr != MyWorld && !MyWorld->IsNetMode(NM_DedicatedServer))
	{
		StopLoadingScreen();
	}
#endif
}

void UCWUIManager::PlayLoadingScreen(bool bPlayUntilStopped, float PlayTime)
{
	ISLoadingScreenModule& LoadingScreenModule = ISLoadingScreenModule::Get();
	LoadingScreenModule.StartInGameLoadingScreen(bPlayUntilStopped, PlayTime);
}

void UCWUIManager::StopLoadingScreen()
{
	ISLoadingScreenModule& LoadingScreenModule = ISLoadingScreenModule::Get();
	LoadingScreenModule.StopInGameLoadingScreen();
}

