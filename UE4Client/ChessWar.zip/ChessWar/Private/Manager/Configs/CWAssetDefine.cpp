﻿
#include "CWAssetDefine.h"


const FString FTileAssetPath::Floor_CursorOver(		TEXT("Floor_CursorOver"));
const FString FTileAssetPath::Floor_AttackRange(	TEXT("Floor_AttackRange"));
const FString FTileAssetPath::Floor_AttackTarget(	TEXT("Floor_AttackTarget"));
const FString FTileAssetPath::Floor_SupportRange(	TEXT("Floor_SupportRange"));
const FString FTileAssetPath::Floor_SupportTarget(	TEXT("Floor_SupportTarget"));
const FString FTileAssetPath::Floor_SwitchInReady(	TEXT("Floor_SwitchInReady"));
const FString FTileAssetPath::Floor_MoveRange(		TEXT("Floor_MoveRange"));
const FString FTileAssetPath::Floor_MoveTarget(		TEXT("Floor_MoveTarget"));
const FString FTileAssetPath::Floor_WarnFall(		TEXT("Floor_WarnFall"));
const FString FTileAssetPath::Floor_WarnRandEvt(	TEXT("Floor_WarnRandEvt"));

const FString FTileAssetPath::Render_Move(			TEXT("Render_Move"));
const FString FTileAssetPath::Render_Attack(		TEXT("Render_Attack"));
const FString FTileAssetPath::Render_SelectNormal(	TEXT("Render_SelectNormal"));
const FString FTileAssetPath::Render_SelectGreen(	TEXT("Render_SelectGreen"));
const FString FTileAssetPath::Render_SelectAttackTarget(TEXT("Render_SelectAttackTarget"));

const FString FTileParticleAssetId::Particle_CursorOver(	TEXT("Particle_CursorOver"));
const FString FTileParticleAssetId::Particle_AttackTarget(	TEXT("Particle_AttackTarget"));
const FString FTileParticleAssetId::Particle_SwitchInReady(	TEXT("Particle_SwitchInReady"));
const FString FTileParticleAssetId::Particle_Support(		TEXT("Particle_Support"));
const FString FTileParticleAssetId::Particle_Selected(		TEXT("Particle_Selected"));
const FString FTileParticleAssetId::Particle_SelectedAttackTarget(TEXT("Particle_SelectedAttackTarget"));
const FString FTileParticleAssetId::Particle_WarnFall(		TEXT("Particle_WarnFall"));
const FString FTileParticleAssetId::Particle_WarnRandEvt(	TEXT("Particle_WarnRandEvt"));


const FString FCWCommClassKey::BP_AITarget(				TEXT("BP_AITarget"));
const FString FCWCommClassKey::BP_AIPawn(				TEXT("BP_AIPawn"));

const FString FCWCommClassKey::BP_CameraMoveVolume(		TEXT("BP_CameraMoveVolume"));
const FString FCWCommClassKey::BP_CameraBlockVolume(	TEXT("BP_CameraBlockVolume"));

const FString FCWCommClassKey::BP_WaterEffect(			TEXT("BP_WaterEffect"));
const FString FCWCommClassKey::BP_CWPawn(				TEXT("BP_CWPawn"));
const FString FCWCommClassKey::BP_CWPawnStart(			TEXT("BP_CWPawnStart"));

const FString FCWCommClassKey::BP_ElemSysCtrl(			TEXT("BP_ElemSysCtrl"));
const FString FCWCommClassKey::BP_PhysicsSysCtrl(		TEXT("BP_PhysicsSysCtrl"));

const FString FCWCommClassKey::BP_ArrowRender(			TEXT("BP_ArrowRender"));
const FString FCWCommClassKey::BP_CWMapTile(			TEXT("BP_CWMapTile"));
const FString FCWCommClassKey::BP_TileRender(			TEXT("BP_TileRender"));
const FString FCWCommClassKey::BP_SplineActor(			TEXT("BP_SplineActor"));
const FString FCWCommClassKey::BP_AimLine(				TEXT("BP_AimLine"));

const FString FCWCommClassKey::BP_GridSwitchEx(			TEXT("BP_GridSwitchEx"));
const FString FCWCommAssetKey::Particle_HitMark(		TEXT("Particle_HitMark"));
