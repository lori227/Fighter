
#include "CWAssetManager.h"

#include "CWFuncLib.h"
#include "CWGameInstance.h"


UCWAssetManager::UCWAssetManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

/*UCWAssetManager* UCWAssetManager::GetAssetMgr(const UObject* WorldContext / *= nullptr* /)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(WorldContext);
	return IsValid(World_CWGI) ? World_CWGI->GetAssetMgr() : nullptr;
}*/

void UCWAssetManager::RequestAsyncLoad(const TArray<FStringAssetReference>& TargetsToStream, FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority)
{
	StreamMgr.RequestAsyncLoad(TargetsToStream, DelegateToCall, Priority);
}

void UCWAssetManager::RequestAsyncLoad(const FStringAssetReference& TargetToStream, FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority)
{
	StreamMgr.RequestAsyncLoad(TargetToStream, DelegateToCall, Priority);

	//UAssetManager::GetStreamableManager().RequestAsyncLoad();
}

void UCWAssetManager::RequestAsyncLoad(const TArray<FStringAssetReference>& TargetsToStream, TFunction<void()>&& Callback, TAsyncLoadPriority Priority)
{
	StreamMgr.RequestAsyncLoad(TargetsToStream, MoveTemp(Callback), Priority);
}

void UCWAssetManager::RequestAsyncLoad(const FStringAssetReference& TargetToStream, TFunction<void()>&& Callback, TAsyncLoadPriority Priority)
{
	StreamMgr.RequestAsyncLoad(TargetToStream, MoveTemp(Callback), Priority);
}
