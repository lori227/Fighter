﻿
#include "CWCfgDefine.h"


const FString FCWCfgKey::Main(			TEXT("ACWMainCfg"));

const FString FCWCfgKey::Asset(			TEXT("CWAssetCfg"));
const FString FCWCfgKey::ClassAsset(	TEXT("CWClassAssetCfg"));
const FString FCWCfgKey::UIAsset(		TEXT("CWUIAssetCfg"));
const FString FCWCfgKey::PawnAsset(		TEXT("CWPawnAssetCfg"));
const FString FCWCfgKey::MeshAsset(		TEXT("CWMeshAssetCfg"));

const FString FCWCfgKey::LevelItemAsset(TEXT("CWLevelItemAssetCfg"));
const FString FCWCfgKey::ParticleAsset( TEXT("CWParticleAssetCfg"));

const FString FCWCfgKey::DecorateAsset(	TEXT("CWDecorateAssetCfg"));

const FString FCWCfgKey::Audio(			TEXT("CWAudioCfg"));
const FString FCWCfgKey::Weather(		TEXT("CWWeatherCfg"));
const FString FCWCfgKey::PawnData(		TEXT("CWPawnDataTable"));
const FString FCWCfgKey::SkillData(		TEXT("CWSkillDataTable"));
const FString FCWCfgKey::TalentData(	TEXT("CWTalentCfg"));

const FString FCWCfgKey::UIWidget(		TEXT("CWUIWidgetCfg"));

const FString FCWCfgKey::LevelItem(		TEXT("CWDungeonItemDataTable"));

const FString FCWCfgKey::Language(		TEXT("CWLanguageCfg"));
const FString FCWCfgKey::CommConst(		TEXT("CWCommConstCfg"));
const FString FCWCfgKey::ConstLocal(	TEXT("ConstLocalCfg"));
const FString FCWCfgKey::BattleConst(	TEXT("CWBattleConstCfg"));

const FString FCWCfgKey::RandomEvt(		TEXT("CWRandomEvtCfg"));
const FString FCWCfgKey::BuffCfg(		TEXT("CWBuffDataTable"));

const FString FCWCfgKey::ObjElemInfo(	TEXT("CWObjElemInfoCfg"));
const FString FCWCfgKey::ObjWithElemReaction(TEXT("CWObjWithElemReactionCfg"));

const FString FCWCfgKey::RefrainType(	TEXT("CWRefrainTypeCfg"));
const FString FCWCfgKey::RefrainFactor(	TEXT("CWRefrainFactorCfg"));
const FString FCWCfgKey::RefrainRelation(TEXT("CWRefrainRelationCfg"));

const FString FCWCfgKey::EffectCfg(		TEXT("CWEffectDataTable"));
const FString FCWCfgKey::GameCfg(		TEXT("CWGameDataTable"));
const FString FCWCfgKey::ProfessionCfg(	TEXT("CWProfessionDataTable"));

const FString FCWCfgKey::DungeonRegionCfg(TEXT("CWDungeonRegionDataTable"));

