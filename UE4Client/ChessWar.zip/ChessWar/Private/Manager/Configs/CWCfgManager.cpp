﻿
#include "CWCfgManager.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWGameInstance.h"
#include "CWMainCfgData.h"


UCWConfigTable::UCWConfigTable(const FObjectInitializer& OI)
	: Super(OI)
{
}

UCWConfigTable::~UCWConfigTable()
{
}

UCWConfigTable* UCWConfigTable::CreateCfgTable(UDataTable* InTable)
{
	if (nullptr != InTable)
	{
		UCWConfigTable* OutConfigTable = NewObject<UCWConfigTable>();
		if (nullptr != OutConfigTable)
		{
			OutConfigTable->CacheCfgTable = InTable;
		}
		return OutConfigTable;
	}
	return nullptr;
}

const UDataTable* UCWConfigTable::GetBaseTable() const
{
	return CacheCfgTable;
}

TArray<FName> UCWConfigTable::GetRowNames() const
{
	return CacheCfgTable->GetRowNames();
}

//////////////////////////////////////////////////////////////////////////////////////////////

UCWCfgManager::UCWCfgManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWCfgManager::~UCWCfgManager()
{
}

class UCWCfgManager* UCWCfgManager::GetCfgMgr(const UObject* InWorldContextObj /*= nullptr*/)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValidObject(World_CWGI) ? World_CWGI->GetCfgMgr() : nullptr;
}

bool UCWCfgManager::InitMgr(UCWGameInstance* InGI)
{
	return Super::InitMgr(InGI);
}

void UCWCfgManager::Destroy()
{
	CacheCfgTableMap.Empty();

	Super::Destroy();
}

UDataTable* UCWCfgManager::CreateTableFromMainCfg(const FString& InCfgKey)
{
	if (const UCWConfigTable* MainConfig = GetConfigTable(FCWCfgKey::Main))
	{
		if (FCWMainCfgData* CfgData = MainConfig->GetRow<FCWMainCfgData>(InCfgKey))
		{
			return CfgData->LoadObject<UDataTable>();
		}
	}
	return nullptr;
}

const UCWConfigTable* UCWCfgManager::GetConfigTable(const FString& InCfgKey)
{
	if (InCfgKey.IsEmpty())
	{
		CWG_LOG(">> %s::GetCfg, InCfgKey[%s] Is Empty.", *GetName(), *InCfgKey);
		return nullptr;
	}

	// 查找
	if (CacheCfgTableMap.Contains(InCfgKey))
	{
		return CacheCfgTableMap[InCfgKey];
	}

	// 创建
	UDataTable* DataTable = nullptr;
	if (InCfgKey == FCWCfgKey::Main)
	{
		DataTable = Cast<UDataTable>(MainCfgTable.LoadSynchronous());
	}
	else
	{
		DataTable = CreateTableFromMainCfg(InCfgKey);
	}

	// 缓存
	if (const UCWConfigTable* OutConfigTable = UCWConfigTable::CreateCfgTable(DataTable))
	{
		CacheCfgTableMap.Add(InCfgKey, OutConfigTable);
		CWG_LOG(">> %s::GetCfg, Create successful. CfgKey[%s].", *GetName(), *InCfgKey);
		return OutConfigTable;
	}

	return nullptr;
}
