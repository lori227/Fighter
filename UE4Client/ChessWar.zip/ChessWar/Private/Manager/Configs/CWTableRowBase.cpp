﻿
#include "CWTableRowBase.h"


FCWTableRowBase::FCWTableRowBase()
{
}

FCWTableRowBase::~FCWTableRowBase()
{
}