﻿
#include "CWElementSystemData.h"

#include "CWComDef.h"
#include "CWCommonUtil.h"


FCWObjWithElemReactionData::FCWObjWithElemReactionData()
	: CastElem(EObjElemType::OET_None)
	, ResObjNature(EObjNatureType::ONT_None)
	, ResObjType(ECWPawnType::DungeonItem)
	, ResObjFinalElem(EObjElemType::OET_None)
	, ResObjExtraBuffId(INDEX_NONE)
{
}

FCWObjWithElemReactionData::~FCWObjWithElemReactionData()
{
}

FCWElemWithElemResultData::FCWElemWithElemResultData()
	: ResultType(EElemWithElemResultType::EWERT_None)
	, OutExtraElemType(EObjElemType::OET_None)
	, OutElemType(EObjElemType::OET_None)
	, OutPawnBuffId(INDEX_NONE)
	, OutItemBuffId(INDEX_NONE)
{
}

FCWElemWithElemResultData::~FCWElemWithElemResultData()
{
}

FCWElemWithObjNatureResultData::FCWElemWithObjNatureResultData()
	: ResultElemType(EObjElemType::OET_None)
	, ResultBuffId(INDEX_NONE)
{
}

FCWElemWithObjNatureResultData::~FCWElemWithObjNatureResultData()
{
}

FCWObjElemInfoData::FCWObjElemInfoData()
	: ObjElemType(EObjElemType::OET_None)
	, ObjNatures(TEXT(""))
{
}

FCWObjElemInfoData::~FCWObjElemInfoData()
{
}

FString FCWElemWithElemResultData::ToDebugString() const
{
	return FString::Printf(TEXT("ResultType[%s] OutElemType[%s] OutExtraElemType[%s] OutPawnBuffId[%d] OutItemBuffId[%]"), 
		*FElemUtils::ToElemElemResultString(ResultType), *FElemUtils::ToOETString(OutElemType), *FElemUtils::ToOETString(OutExtraElemType), OutPawnBuffId, OutItemBuffId);
}

int32 FCWElemWithElemResultData::GetOutBuffId(ECWPawnType InPawnType) const
{
	if (InPawnType != ECWPawnType::None)
	{
		return (InPawnType == ECWPawnType::Character) ? OutPawnBuffId : OutItemBuffId;
	}
	return INDEX_NONE;
}

FString FCWObjElemInfoData::ToDebugString() const
{
	return FString::Printf(TEXT("Desc[%s] ObjElemType[%s] ObjNatures[%s]"), *FTEXT_TO_FSTRING(Desc), *FElemUtils::ToOETString(ObjElemType), *ObjNatures);
}

uint8 FElemUtils::ParseObjNatures(const FString& InObjNatures, const TCHAR* pchDelim)
{
	uint8 OutObjNatures = 0x00;
	if (InObjNatures.IsEmpty())
	{
		return OutObjNatures;
	}

	TArray<FString> OutArray;
	InObjNatures.ParseIntoArray(OutArray, pchDelim/*, false*/);
	if (OutArray.Num() < ((int32)EObjElemType::OET_Max - 1))
	{
		CWG_WARNING(">> FCWObjElemInfoData::ParseObjNatures, ObjNatures[%s].Num < [%d]!!!, return 0x00.", *InObjNatures, ((int32)EObjElemType::OET_Max - 1));
		return OutObjNatures;
	}

	// 解析物体性质集合
	for (int32 i = 0; i < OutArray.Num(); ++i)
	{
		int32 NewNature = FSTRING_TO_INT(OutArray[i]);
		if ((NewNature & 0x01) != 0x00)
		{
			uint8 NewValue = (uint8)FMath::Exp2(i);
			OutObjNatures |= NewValue;
		}
	}
	return OutObjNatures;
}

bool FElemUtils::ObjHasNatureType(uint8 InObjNatureTypes, EObjNatureType InObjNatureType)
{
	if (0x00 == InObjNatureTypes ||
		!(InObjNatureType > EObjNatureType::ONT_None && InObjNatureType < EObjNatureType::ONT_Max))
	{
		return false;
	}
	int32 Exponent = (int32)(InObjNatureType) - 1;
	uint8 NewValue = (uint8)FMath::Exp2(Exponent);
	return (InObjNatureTypes & NewValue) != 0x00;
	//return EnumHasAnyFlags<uint8>(InObjNatureTypes, NewValue);
}

bool FElemUtils::IsValidObjElemType(const EObjElemType InObjElemType)
{
	return (InObjElemType > EObjElemType::OET_None && InObjElemType < EObjElemType::OET_Max);
}

bool FElemUtils::IsObjElemTypeInRange(const EObjElemType InObjElemType)
{
	return (InObjElemType >= EObjElemType::OET_None && InObjElemType <= EObjElemType::OET_Max);
}

bool FElemUtils::IsObjNatureTypeInRange(const EObjNatureType InObjNatureType)
{
	return (InObjNatureType >= EObjNatureType::ONT_None && InObjNatureType <= EObjNatureType::ONT_Max);
}

FString FElemUtils::ToOETString(const EObjElemType InObjElemType)
{
	return FCWCommonUtil::EnumToString(TEXT("EObjElemType"), InObjElemType);
}

FString FElemUtils::ToElemElemResultString(const EElemWithElemResultType InType)
{
	return FCWCommonUtil::EnumToString(TEXT("EElemWithElemResultType"), InType);
}
