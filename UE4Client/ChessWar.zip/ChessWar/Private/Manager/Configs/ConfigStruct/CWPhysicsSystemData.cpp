﻿
#include "CWPhysicsSystemData.h"

#include "CWPawnDataStruct.h"
#include "CWDungeonItemDataStruct.h"


FCWPhysicsSysData::FCWPhysicsSysData()
{
	InitDefault();
}

FCWPhysicsSysData::~FCWPhysicsSysData()
{
}

FCWPhysicsSysData& FCWPhysicsSysData::InitDefault()
{
	bPhyBMovedForce = false;
	bPhyBFallenForce = false;
	PhyLateralFDMG = 0;
	PhyLateralFMove = 0;
	PhyLateralFBuff = 0;
	PhyLateralFEvent = 0;
	PhyVerticalFDMG = 0;
	PhyVerticalFMove = 0;
	PhyVerticalFBuff = 0;
	PhyVerticalFEvent = 0;

	return *this;
}

bool FCWPhysicsSysData::IsValidExecPhysicsSysData()
{
	return bPhyBMovedForce || bPhyBFallenForce;
}

FCWPhysicsSysData& FCWPhysicsSysData::InitByPawnData(const FCWPawnDataStruct* InPawnData)
{
	if (nullptr != InPawnData)
	{
		bPhyBMovedForce = InPawnData->bPhyBMovedForce;
		bPhyBFallenForce = InPawnData->bPhyBFallenForce;
		PhyLateralFDMG = InPawnData->PhyLateralFDMG;
		PhyLateralFMove = InPawnData->PhyLateralFMove;
		PhyLateralFBuff = InPawnData->PhyLateralFBuff;
		PhyLateralFEvent = InPawnData->PhyLateralFEvent;
		PhyVerticalFDMG = InPawnData->PhyVerticalFDMG;
		PhyVerticalFMove = InPawnData->PhyVerticalFMove;
		PhyVerticalFBuff = InPawnData->PhyVerticalFBuff;
		PhyVerticalFEvent = InPawnData->PhyVerticalFEvent;
	}
	else
	{
		InitDefault();
	}
	return *this;
}

FCWPhysicsSysData& FCWPhysicsSysData::InitByItemData(const FCWDungeonItemDataStruct* InItemData)
{
	if (nullptr != InItemData)
	{
		bPhyBMovedForce = InItemData->bPhyBMovedForce;
		bPhyBFallenForce = InItemData->bPhyBFallenForce;
		PhyLateralFDMG = InItemData->PhyLateralFDMG;
		PhyLateralFMove = InItemData->PhyLateralFMove;
		PhyLateralFBuff = InItemData->PhyLateralFBuff;
		PhyLateralFEvent = InItemData->PhyLateralFEvent;
		PhyVerticalFDMG = InItemData->PhyVerticalFDMG;
		PhyVerticalFMove = InItemData->PhyVerticalFMove;
		PhyVerticalFBuff = InItemData->PhyVerticalFBuff;
		PhyVerticalFEvent = InItemData->PhyVerticalFEvent;
	}
	else
	{
		InitDefault();
	}
	return *this;
}

FString FCWPhysicsSysData::ToDebugString() const
{
	const FString& NewHStr = FString::Printf(
		TEXT("bPhyBMovedForce[%d] PhyLateralFDMG[%d] PhyLateralFMove[%d] PhyLateralFBuff[%d] PhyLateralFEvent[%d] "),
		(int32)bPhyBMovedForce, PhyLateralFDMG, PhyLateralFMove, PhyLateralFBuff, PhyLateralFEvent);
	const FString& NewVStr = FString::Printf(
		TEXT("bPhyBFallenForce[%d] PhyVerticalFDMG[%d] PhyVerticalFMove[%d] PhyVerticalFBuff[%d] PhyVerticalFEvent[%d]"),
		(int32)bPhyBFallenForce, PhyVerticalFDMG, PhyVerticalFMove, PhyVerticalFBuff, PhyVerticalFEvent);
	return NewHStr + NewVStr;
}
