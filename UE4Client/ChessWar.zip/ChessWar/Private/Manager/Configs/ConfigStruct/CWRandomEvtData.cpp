﻿
#include "CWRandomEvtData.h"

FCWRandomEvtData::FCWRandomEvtData()
	: bGenerateSingle(true)
	, RangeType(1)
	, RangeSize(1)
{
	Prob = 0;
	ItemId = 0;
	EffectId = 0;
	EvtType = 0;
	BuffId = 0;
	GenerateType = 0;
	GenerateLandType = 0;
	GenerateTargetType = 0;
	GenerateInterval = 0.f;
	CycleValue = 0;
	bNeedWarn = false;
	OwnElemType = EObjElemType::OET_None;
	GenerateWeather = ECWWeatherType::None;
}

FString FCWRandomEvtData::ToDebugString() const
{
	return FString::Printf(TEXT("Name[%s] BuffId[%d] OwnElemType[%d]"), *Name, BuffId, (int32)OwnElemType);
}

FCWRandomEvtHurtData::FCWRandomEvtHurtData()
{
	Value = 0;
	RoundNum = 0;
	ElemType = 0;
	TargetType = 0;
}

FCWRandomEvtHurtData::~FCWRandomEvtHurtData()
{
}

FCWRandomEvtGameData::FCWRandomEvtGameData()
	: TargetTile(INDEX_NONE)
{
	EvtId = 0;
	CoolingValue = 0;
	WaitActiveRound = 0;
	TargetTile = 0;
}
