
#include "CWWeatherData.h"

#include "CWCommonUtil.h"


FCWWeatherAffectData::FCWWeatherAffectData()
{
	AttackValue			= 0.0f;
	DefenceValue		= 0.0f;
	TalentValue			= 0.0f;
	MoveValue			= 0.0f;
}

FCWWeatherAffectData::~FCWWeatherAffectData()
{
}

FCWWeatherAffectData FCWWeatherAffectData::operator+(const FCWWeatherAffectData& InOther)
{
	FCWWeatherAffectData OutData;
	OutData.AttackValue = AttackValue + InOther.AttackValue;
	OutData.DefenceValue = DefenceValue + InOther.DefenceValue;
	OutData.TalentValue = TalentValue + InOther.TalentValue;
	OutData.MoveValue = MoveValue + InOther.MoveValue;
	return OutData;
}

FCWWeatherAffectData FCWWeatherAffectData::operator-(const FCWWeatherAffectData& InOther)
{
	FCWWeatherAffectData OutData;
	OutData.AttackValue = AttackValue - InOther.AttackValue;
	OutData.DefenceValue = DefenceValue - InOther.DefenceValue;
	OutData.TalentValue = TalentValue - InOther.TalentValue;
	OutData.MoveValue = MoveValue - InOther.MoveValue;
	return OutData;
}

FCWWeatherAffectData& FCWWeatherAffectData::operator-=(const FCWWeatherAffectData& InOther)
{
	AttackValue -= InOther.AttackValue;
	DefenceValue -= InOther.DefenceValue;
	TalentValue -= InOther.TalentValue;
	MoveValue -= InOther.MoveValue;
	return *this;
}

bool FCWWeatherAffectData::IsValidValue() const
{
	return !FMath::IsNearlyZero(AttackValue) || !FMath::IsNearlyZero(DefenceValue)
		|| !FMath::IsNearlyZero(TalentValue) || !FMath::IsNearlyZero(MoveValue);
}

FCWWeatherAffectData& FCWWeatherAffectData::operator+=(const FCWWeatherAffectData& InOther)
{
	AttackValue += InOther.AttackValue;
	DefenceValue += InOther.DefenceValue;
	TalentValue += InOther.TalentValue;
	MoveValue += InOther.MoveValue;
	return *this;
}

FCWWeatherData::FCWWeatherData()
	: OwnElemType(EObjElemType::OET_None)
	, WeatherType(ECWWeatherType::None)
{
}

FCWWeatherData::~FCWWeatherData()
{
}

FString FCWWeatherData::ToDebugString() const
{
	return FString::Printf(TEXT("WeatherType[%s] OwnElemType[%s]"), 
		*FCWCommonUtil::EnumToString(TEXT("ECWWeatherType"), WeatherType), *FCWCommonUtil::EnumToString(TEXT("EObjElemType"), OwnElemType));
}
