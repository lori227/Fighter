﻿
#include "CWEventMgr.h"

#include "CWFuncLib.h"
#include "CWGameInstance.h"

FOnOnPreloadContentForURL UCWEventMgr::OnPreloadContentForURL;
FOnLevelLoadComplete UCWEventMgr::OnLevelLoadComplete;


UCWEventMgr::UCWEventMgr(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWEventMgr::~UCWEventMgr()
{
}

UCWEventMgr* UCWEventMgr::GetEventMgr(const UObject* InWorldContextObj)
{
	UCWGameInstance* CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(CWGI) ? CWGI->GetEventMgr() : nullptr;
}

bool UCWEventMgr::InitMgr(UCWGameInstance* InGI)
{
	Super::InitMgr(InGI);

	ClearAllEvents();
	return true;
}

void UCWEventMgr::Destroy()
{
	ClearAllEvents();

	Super::Destroy();
}

void UCWEventMgr::ClearAllEvents()
{
	OnPreloadContentForURL.Clear();
	OnLevelLoadComplete.Clear();

	OnKeyPressed.Clear();
	OnPlayerSendMessage.Clear();

	OnHUDBeginPlayed.Clear();
	OnPlayerLoginCompleted.Clear();
	OnRoleReadyStateChange.Clear();
	OnReadyRemainTimeChange.Clear();

	OnRoundCampChange.Clear();
	OnRoundRemainTimeChange.Clear();
	OnRoundIndexChangeInClient.Clear();
	OnWeatherIdxChange.Clear();
	OnNextWeatherIdxChange.Clear();
	OnTimePhasesChange.Clear();
	OnBattleStateChange.Clear();
	OnBattleResult.Clear();
	OnLevelSiteDrop.Clear();
	OnLevelDropEarlyWarnClient.Clear();

	OnCameraArmLength.Clear();
	OnCameraArmAgree90.Clear();
	OnPlayerPawnActionEndClient.Clear();
	OnPlayerDataArrayChange.Clear();

	OnAddSnowfieldTarget.Clear();
	OnRemoveSnowfieldTarget.Clear();
}
