﻿
#include "CWGameSettingSG.h"

#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/GameUserSettings.h"

#include "CWAudioVideoDef.h"


FAudioSetting::FAudioSetting()
	: AudioSetType(EAudioSetType::AST_Env)
	, bEnableAudio(true)
	, AudioTypeVolume(100.f)
{
}

FAudioSetting::FAudioSetting(EAudioSetType InType, bool bNewEnableAudio, float InVolume)
	: AudioSetType(InType)
	, bEnableAudio(true)
	, AudioTypeVolume(100.f)
{
}

UCWGameSettingSG::UCWGameSettingSG(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, EnablePawnUIMode(0)
{
	bWindowMode = true;
	Resolution = FIntPoint(1280, 720);

	AudioSettings.Add(FAudioSetting(EAudioSetType::AST_Env, true, 100.f));
	AudioSettings.Add(FAudioSetting(EAudioSetType::AST_Master, true, 100.f));
	AudioSettings.Add(FAudioSetting(EAudioSetType::AST_Music, true, 100.f));
	AudioSettings.Add(FAudioSetting(EAudioSetType::AST_Sound, true, 100.f));
	AudioSettings.Add(FAudioSetting(EAudioSetType::AST_Voice, true, 100.f));
}

UCWGameSettingSG::~UCWGameSettingSG()
{
}

UCWGameSettingSG* UCWGameSettingSG::GetClassDefaultObj()
{
	return UCWGameSettingSG::StaticClass()->GetDefaultObject<UCWGameSettingSG>();
}

UCWGameSettingSG* UCWGameSettingSG::NewGameSettingSG(UObject* InOuter)
{
	return NewObject<UCWGameSettingSG>(InOuter);
}

void UCWGameSettingSG::InitResScreenSetting(UCWGameSettingSG* InObject)
{
	if (nullptr != InObject)
	{
		UGameUserSettings* GameUserSetting = UGameUserSettings::GetGameUserSettings();
		if (nullptr != GameUserSetting)
		{
			const EWindowMode::Type WindowMode = GameUserSetting->GetFullscreenMode();
			InObject->bWindowMode = WindowMode != EWindowMode::Fullscreen && WindowMode != EWindowMode::WindowedFullscreen;
			InObject->Resolution = GameUserSetting->GetScreenResolution();
		}
	}
}

void UCWGameSettingSG::SetAudioVolume(UCWGameSettingSG* InObject, EAudioSetType InAudioSetType, float InAudioTypeVolume)
{
	if (nullptr != InObject)
	{
		for (FAudioSetting& Elem : InObject->AudioSettings)
		{
			if (Elem.AudioSetType == InAudioSetType)
			{
				Elem.AudioTypeVolume = InAudioTypeVolume;
			}
		}
	}
}

bool CompareAudioSetting(TArray<FAudioSetting>& InLeft, TArray<FAudioSetting>& InRight)
{
	if (InLeft.Num() != InRight.Num())
	{
		return true;
	}
	for (int32 i = 0 ; i < InLeft.Num(); ++i)
	{
		if (InLeft[i] != InRight[i])
		{
			return true;
		}
	}
	return false;
}

bool UCWGameSettingSG::CompareProperty(UCWGameSettingSG* InLeftObj, UCWGameSettingSG* InRightObj)
{
	if (nullptr == InLeftObj || nullptr == InRightObj)
	{
		return false;
	}
	bool HasCompare = (InLeftObj->EnablePawnUIMode != InRightObj->EnablePawnUIMode);
	HasCompare = HasCompare || (InLeftObj->Resolution != InRightObj->Resolution);
	HasCompare = HasCompare || (InLeftObj->bWindowMode != InRightObj->bWindowMode);
	HasCompare = HasCompare || CompareAudioSetting(InLeftObj->AudioSettings, InRightObj->AudioSettings);
	return HasCompare;
}

UCWGameSettingSG* UCWGameSettingSG::CopyProperty(UCWGameSettingSG* InOpObj, UCWGameSettingSG* InFromObj)
{
	if (nullptr == InOpObj || nullptr == InFromObj)
	{
		return InOpObj;
	}
	InOpObj->EnablePawnUIMode = InFromObj->EnablePawnUIMode;
	InOpObj->Resolution = InFromObj->Resolution;
	InOpObj->bWindowMode = InFromObj->bWindowMode;
	InOpObj->AudioSettings = InFromObj->AudioSettings;
	return InOpObj;
}

void UCWGameSettingSG::ResetDefaultSetting(UCWGameSettingSG* InOpObj, const uint8 InPageIdx)
{
	if (IsValid(InOpObj))
	{
		UCWGameSettingSG* SettingCDO = UCWGameSettingSG::GetClassDefaultObj();
		switch (InPageIdx)
		{
		case 0:
		{
			InOpObj->Resolution = SettingCDO->Resolution;
			InOpObj->bWindowMode = SettingCDO->bWindowMode;
		}break;
		case 1:
		{
			InOpObj->AudioSettings = SettingCDO->AudioSettings;
		}break;
		case 2:
		{
			InOpObj->EnablePawnUIMode = SettingCDO->EnablePawnUIMode;
		}break;
		}
	}
}

UCWGameSettingSG* UCWGameSettingSG::GetGameSetData(const FString& SlotName, const int32 UserIndex)
{
	/*	@see UGameplayStatics::CreateSaveGameObject
	 *	@see UGameplayStatics::SaveGameToSlot
	 *	@see UGameplayStatics::DoesSaveGameExist
	 *	@see UGameplayStatics::LoadGameFromSlot
	 *	@see UGameplayStatics::DeleteGameInSlot
	 */

	UCWGameSettingSG* SGGameSetting = Cast<UCWGameSettingSG>(UGameplayStatics::LoadGameFromSlot(SlotName, UserIndex));
	if (nullptr == SGGameSetting)
	{
		SGGameSetting = Cast<UCWGameSettingSG>(UGameplayStatics::CreateSaveGameObject(UCWGameSettingSG::StaticClass()));
		InitResScreenSetting(SGGameSetting);
		UCWGameSettingSG::SaveGameSetData(SGGameSetting, SlotName, UserIndex);
	}else
	{
		InitResScreenSetting(SGGameSetting);
	}

	return SGGameSetting;
}

bool UCWGameSettingSG::SaveGameSetData(UCWGameSettingSG* InGameSettingSG, const FString& SlotName, const int32 UserIndex)
{
	UWorld* const MyWorld = InGameSettingSG ? InGameSettingSG->GetWorld() : nullptr;
	if (nullptr != InGameSettingSG && nullptr != MyWorld && 
		MyWorld->IsGameWorld() && !MyWorld->IsPlayInEditor())
	{
		return UGameplayStatics::SaveGameToSlot(InGameSettingSG, SlotName, UserIndex);
	}
	return false;
}
