
#include "CWLocalDataMgr.h"

#include "CWFuncLib.h"
#include "CWGameInstance.h"
#include "CWGameSettingSG.h"

UCWLocalDataMgr::UCWLocalDataMgr(class FObjectInitializer const& OI)
	: Super(OI)
{
}

class UCWLocalDataMgr* UCWLocalDataMgr::GetLocalDataMgr(const UObject* InWorldContextObj /*= nullptr*/)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetLocalDataMgr() : nullptr;
}

UCWGameSettingSG* UCWLocalDataMgr::GetGameSettingData()
{
	if (!IsValid(GameSettingData))
	{
		GameSettingData = UCWGameSettingSG::GetGameSetData();
	}
	return GameSettingData;
}
