﻿
#include "CWWeatherMgr.h"
#include "Particles/Emitter.h"
#include "Engine/DirectionalLight.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWEventMgr.h"
#include "CWGameState.h"
#include "CWSimpleActor.h"
#include "CWAssetDefine.h"
#include "CWCommonUtil.h"
#include "CWWeatherData.h"
#include "CWCfgManager.h"
#include "CWDungeonTile.h"
#include "CWGameInstance.h"
#include "CWWeatherEffect.h"
#include "CWClientConstData.h"
#include "CWEffectWaterImpl.h"
#include "CWDungeonDataStruct.h"
#include "CWRandomDungeonGenerator.h"


UCWWeatherMgr::UCWWeatherMgr(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

class UCWWeatherMgr* UCWWeatherMgr::GetWeatherMgr(const UObject* InWorldContextObj /*= nullptr*/)
{
	UCWGameInstance* World_CWGI = UCWFuncLib::GetCWGameInst(InWorldContextObj);
	return IsValid(World_CWGI) ? World_CWGI->GetWeatherMgr() : nullptr;
}

bool UCWWeatherMgr::InitMgr(UCWGameInstance* InGI)
{
	Super::InitMgr(InGI);

	UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr;
	if (IsValid(EvtMgr) && !IsPendingKill() && !IsTemplate())
	{
		ADD_EVT_DELEGATE(EvtMgr->OnRoundIndexChangeInClient, this, &UCWWeatherMgr::OnRoundChange, FName("OnRoundChange"));
		ADD_EVT_DELEGATE(EvtMgr->OnWeatherIdxChange, this, &UCWWeatherMgr::OnWeatherIdxChange, FName("OnWeatherIdxChange"));
	}
	return true;
}

void UCWWeatherMgr::Destroy()
{
	DisEnableTimePhasesTick();

	UCWEventMgr* EvtMgr = Global_GI.IsValid() ? Global_GI->GetEventMgr() : nullptr;
	if (IsValid(EvtMgr) && !IsTemplate())
	{
		EvtMgr->OnRoundIndexChangeInClient.RemoveAll(this);
		EvtMgr->OnWeatherIdxChange.RemoveAll(this);
	}

	Super::Destroy();
}

AEmitter* UCWWeatherMgr::GetEmitterActor()
{
	if (IsValid(EmitterActor.Get()))
	{
		return EmitterActor.Get();
	}

	if (UWorld* MyWorld = GetWorld())
	{
		for (TActorIterator<ACWWeatherEffect> Iter(MyWorld); Iter; ++Iter)
		{
			EmitterActor = *Iter;
			return EmitterActor.Get();
		}
	}
	return nullptr;
}

ADirectionalLight* UCWWeatherMgr::GetLightActor()
{
	if (IsValid(LightActor.Get()))
	{
		return LightActor.Get();
	}

	if (UWorld* MyWorld = GetWorld())
	{
		for (TActorIterator<ADirectionalLight> Iter(MyWorld); Iter; ++Iter)
		{
			LightActor = *Iter;
			return LightActor.Get();
		}
	}
	return nullptr;
}

UParticleSystem* UCWWeatherMgr::GetWeatherEmitter(ECWWeatherType InIdx) const
{
	if (IsValidWeatherIdx((int32)InIdx))
	{
		const FCWWeatherData* WeatherData = FCWCfgUtils::GetWeatherData(this, (int32)InIdx);
		if (nullptr != WeatherData && !WeatherData->EffectId.IsEmpty())
		{
			UParticleSystem* NewTemplate = FCWCfgUtils::GetAssetObjectFromCfg<UParticleSystem>(this, FCWCfgKey::ParticleAsset, WeatherData->EffectId);
			return NewTemplate;
		}
	}

	return nullptr;
}

void UCWWeatherMgr::EnableTimePhasesTick()
{
	DisEnableTimePhasesTick();
	FTickerDelegate OnTickDel = FTickerDelegate::CreateUObject(this, &UCWWeatherMgr::OnTick);
	TickDelegateHandle = FTicker::GetCoreTicker().AddTicker(OnTickDel);

	/*FTimerDelegate TimerCallback;
	TimerCallback.BindLambda([this]()
	{
		OnTick(0.01f);
	});
	GetWorld()->GetTimerManager().SetTimer(TimerHandle, TimerCallback, 0.01f, true);*/
}

void UCWWeatherMgr::DisEnableTimePhasesTick()
{
	FTicker::GetCoreTicker().RemoveTicker(TickDelegateHandle);

	/*GetWorld()->GetTimerManager().ClearTimer(TimerHandle);
	GetWorld()->GetTimerManager().ClearAllTimersForObject(this);*/

	/*FCoreDelegates::OnExit.AddRaw(this, &UCWWeatherMgr::OnExit);
	FCoreDelegates::OnExit.RemoveAll(this);*/
}

void UCWWeatherMgr::CheckDungeonEffectChange(ECWWeatherType InNewType, ECWWeatherType InOldType)
{
	UWorld* MyWorld = GetWorld();
	ACWGameState* GS = MyWorld ? MyWorld->GetGameState<ACWGameState>() : nullptr;
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(MyWorld);
	FCWDungeonDataStruct* DungeonData = Generator ? Generator->GetDungeonData() : nullptr;

	if (nullptr == MyWorld || nullptr == GS || nullptr == Generator || nullptr == DungeonData)
	{
		return;
	}

	// 最低地块位置Z
	float MapTileMinZ = Generator->GetLowestTileZ()/*-140.f*/;

	// 当前时间段(上下晚)
	ECWTimePhases TimePhases = ECWTimePhases(GS->GetCurRoundIndex() % 3);

	// 更新天气效果
	float WaterTargetLocZ = 0.f;
	bool bNeedUpdateWater = false;
	if (InNewType == ECWWeatherType::Rain)
	{	// 雨天
		if (0 == WaterPanelList.Num() && !WaterPanelParent.IsValid())
		{
			// 创建水面效果
			if (UClass* ClassWater = FCWCfgUtils::GetAssetClass(MyWorld, FCWCommClassKey::BP_WaterEffect))
			{
				// 获取地块格子数据
				TArray<ACWDungeonTile*>& TileList = Generator->GetDungeonTileList();
				const TArray<int32>& TileLayerNumList = Generator->GetArrayDungeonGrid_Z();

				// 获取绑定父节点
				ACWSimpleActor* WaterParent = WaterPanelParent.IsValid() ? WaterPanelParent.Get() :
					MyWorld->SpawnActor<ACWSimpleActor>(ACWSimpleActor::StaticClass(), FVector::ZeroVector, FRotator::ZeroRotator);
				WaterPanelParent = WaterParent;

				// 生成水面对象
				FVector WaterStartLoc(0.f);
				FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
				for (int32 Idx = 0; Idx < TileLayerNumList.Num(); ++Idx)
				{
					ACWDungeonTile* MapTile = TileList.IsValidIndex(Idx) ? TileList[Idx] : nullptr;
					// 地块 + 低地势
					if ((IsValid(MapTile)) && TileLayerNumList[Idx] < 0)
					{
						// 设置最低地势高度
						const float TileHeight = TileLayerNumList[Idx] * DungeonData->HighLandOrLowLandGridOffsetZ;
						MapTileMinZ = (TileHeight < MapTileMinZ) ? TileHeight : MapTileMinZ;

						Generator->tile2pos(Idx, WaterStartLoc);
						WaterStartLoc.Z = 0.f;
						if (ACWEffectWaterImpl* NewWater = MyWorld->SpawnActor<ACWEffectWaterImpl>(ClassWater, WaterStartLoc, FRotator::ZeroRotator))
						{
							NewWater->SetTileNumber(Idx);
							//NewWater->SetWaterSize(FVector2D(0.65 * 1, 0.65 * 1));
							WaterPanelList.AddUnique(NewWater);

							// 设置父节点(统一位置移动)
							NewWater->AttachToActor(WaterParent, AttachmentRules);

							// 设置地块销毁回调
							NewWater->SetOwner(MapTile);
							ADD_EVT_DELEGATE(MapTile->OnBeginFallInClient, this, &UCWWeatherMgr::OnTileBeginFallInClient, "OnTileBeginFallInClient");
						}
					}
				}
				// 设置初始位置
				WaterParent->SetActorLocation(FVector(0.f, 0.f, MapTileMinZ));
			}
		}

		WaterTargetLocZ = 0.f;
		bNeedUpdateWater = true;
	}	// 晴天(白天)
	else if(InNewType == ECWWeatherType::Sunshine && 
		TimePhases != ECWTimePhases::Night)
	{
		WaterTargetLocZ = MapTileMinZ;
		bNeedUpdateWater = true;
	}

	// 更新水面效果
	if (bNeedUpdateWater && WaterPanelParent.IsValid())
	{
		const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(MyWorld, FCWCfgKey::CommConst, TEXT("WaterSpeed_TopDown"));
		float WaterSpeed = ConstData ? FSTRING_TO_FLOAT(ConstData->Param) : 20.f;
		const float StartLocZ = WaterPanelParent->GetActorLocationZ();
		WaterPanelParent->StartUpdateLoctionZ(StartLocZ, WaterTargetLocZ, WaterSpeed);
	}
}

void UCWWeatherMgr::OnTileBeginFallInClient(ACWDungeonTile* InTileObj)
{
	if (!IsValid(InTileObj))
	{
		return;
	}

	// 销毁对应水面
	WaterPanelList.RemoveAll([InTileObj](const TWeakObjectPtr<ACWEffectWaterImpl>& InWaterPanel)
	{
		bool bNeedRemove = !InWaterPanel.IsValid();
		if (InWaterPanel.IsValid() && (InTileObj->GetTile() == InWaterPanel->GetTileNumber()))
		{	// 销毁对应水面
			ACWEffectWaterImpl* WaterPanel = InWaterPanel.Get();
			if (IsValid(WaterPanel))
			{
				InWaterPanel->Destroy(true);
			}
			bNeedRemove = true;
		}
		return bNeedRemove;
	});

	// 检测销毁水面父节点
	if (WaterPanelParent.IsValid() && (0 == WaterPanelList.Num()))
	{
		WaterPanelParent->Destroy(true);
		WaterPanelParent = nullptr;
	}
}

bool UCWWeatherMgr::OnTick(float DeltaTime)
{
	if (ADirectionalLight* LightA = GetLightActor())
	{
		FQuat NewQuat = LightA->GetActorQuat();
		FQuat TmpQuat = FMath::Lerp(NewQuat, FinalRotData.LightQuat, DeltaTime * 0.5f);
		LightA->SetActorRotation(TmpQuat);

		float NewIntensity = LightA->GetBrightness();
		if (!FMath::IsNearlyEqual(NewIntensity, FinalRotData.Intensity, 0.1f))
		{
			float TmpIntensity = FMath::Lerp(NewIntensity, FinalRotData.Intensity, DeltaTime);
			LightA->SetBrightness(TmpIntensity);
		}

		// 关闭时间过度效果
		if (FinalRotData.LightQuat.Equals(TmpQuat, 0.01f))
		{
			LightA->SetActorRotation(FinalRotData.LightQuat);
			LightA->SetBrightness(FinalRotData.Intensity);
			DisEnableTimePhasesTick();
		}
	}
	else
	{
		CWG_WARNING(">> %s::OnTick, LightA is nullptr!", *GetName());
		DisEnableTimePhasesTick();
	}

	return true;
}

void UCWWeatherMgr::OnRoundChange(int32 CurRound, int32 MaxRound)
{
	if (ADirectionalLight* LightA = (CurRound > 1 ? GetLightActor() : nullptr))
	{
		// 光源动态变化
		//float RotY = 210.0f;
		//float Intensity = 4.0f;
		ECWTimePhases NewTimePhases = ECWTimePhases(CurRound % 3);
		/*switch (Time)
		{
		case ECWTimePhases::Morning: {
			RotY = 210.0f;
			Intensity = 4.0f;
		}break;
		case ECWTimePhases::Afternoon: {
			RotY = 330.0f;
			Intensity = 4.0f;
		}break;
		case ECWTimePhases::Night: {
			RotY = 90.0f;
			Intensity = 0.0f;
		}break;
		}
		FinalRotData.Intensity = Intensity;
		FRotator Rot = LightA->GetActorRotation(); Rot.Yaw = RotY;
		FinalRotData.LightQuat = FQuat(Rot);
		EnableTimePhasesTick();*/

		// 检测地块效果变化
		if (ACWGameState* GS = LightA->GetWorld()->GetGameState<ACWGameState>())
		{
			CheckDungeonEffectChange((ECWWeatherType)GS->GetWeatherIdx(), (ECWWeatherType)GS->GetOldWeatherIdx());
		}

		if (UCWEventMgr* EvtMgr = EVT_MGR(LightA))
		{
			EvtMgr->OnTimePhasesChange.Broadcast(NewTimePhases);
			CWG_LOG(">> OnTimePhasesChange, TimePhases[%s].", *FCWCommonUtil::EnumToString(TEXT("ECWTimePhases"), NewTimePhases));
		}
	}
}

void UCWWeatherMgr::OnWeatherIdxChange(ECWWeatherType NewWeatherIdx, ECWWeatherType InOldWeatherIdx)
{
	if (AEmitter* EmitterA = GetEmitterActor())
	{
		UParticleSystem* NewTemplate = GetWeatherEmitter(NewWeatherIdx);
		EmitterA->SetTemplate(NewTemplate);
		if (nullptr != NewTemplate)
		{
			EmitterA->Activate();
		}else
		{
			EmitterA->Deactivate();
		}
	}

	// 检测地块效果变化
	CheckDungeonEffectChange(NewWeatherIdx, InOldWeatherIdx);
}

void UCWWeatherMgr::OnExit()
{
}

int32 UCWWeatherMgr::GenerateWeatherIdx(const int32 InCurRound)
{
	int32 NewIdx = -1;
	if ((InCurRound + 1) % 3 == 0)
	{
		NewIdx = FMath::RandRange(1, 3);
	}
	return NewIdx;
}

bool UCWWeatherMgr::IsValidWeatherIdx(const int32 InIdx)
{
	return (InIdx > (int32)ECWWeatherType::None && InIdx < (int32)ECWWeatherType::Max);
}
