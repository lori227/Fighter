#include "CWAttackGrid.h"
#include "Math/Vector.h"
#include "Math/UnrealMathUtility.h"
#include "Map/CWMap.h"


CWAttackGrid::CWAttackGrid()
{
	Tile = -1;
	PawnTile = -1;
	Dir = 0;
	MAD = 0;
}

CWAttackGrid::CWAttackGrid(const CWAttackGrid& rhs)
{
	operator=(rhs);
}

CWAttackGrid& CWAttackGrid::operator=(const CWAttackGrid& rhs)
{
	if (this == &rhs)
		return *this;

	Tile = rhs.Tile;
	PawnTile = rhs.PawnTile;
	Dir = rhs.Dir;
	MAD = rhs.MAD;

	return *this;
}


bool operator==(const CWAttackGrid& lhs, const CWAttackGrid& rhs)
{
	if (lhs.Tile == rhs.Tile &&
		lhs.PawnTile == rhs.PawnTile &&
		lhs.Dir == rhs.Dir &&
		lhs.MAD == rhs.MAD)
	{
		return true;
	}

	return false;
}