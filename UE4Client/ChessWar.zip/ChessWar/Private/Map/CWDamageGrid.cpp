#include "CWDamageGrid.h"
#include "Math/Vector.h"
#include "Math/UnrealMathUtility.h"
#include "Map/CWMap.h"


CWDamageGrid::CWDamageGrid()
{
	Tile = -1;
	PawnTile = -1;
	AttackTile = -1;
	Dir = 0;
	MAD = 0;
}

CWDamageGrid::CWDamageGrid(const CWDamageGrid& rhs)
{
	operator=(rhs);
}

CWDamageGrid& CWDamageGrid::operator=(const CWDamageGrid& rhs)
{
	if (this == &rhs)
		return *this;

	Tile = rhs.Tile;
	PawnTile = rhs.PawnTile;
	AttackTile = rhs.AttackTile;
	Dir = rhs.Dir;
	MAD = rhs.MAD;

	return *this;
}


bool operator==(const CWDamageGrid& lhs, const CWDamageGrid& rhs)
{
	if (lhs.Tile == rhs.Tile &&
		lhs.PawnTile == rhs.PawnTile &&
		lhs.AttackTile == rhs.AttackTile &&
		lhs.Dir == rhs.Dir &&
		lhs.MAD == rhs.MAD)
	{
		return true;
	}

	return false;
}