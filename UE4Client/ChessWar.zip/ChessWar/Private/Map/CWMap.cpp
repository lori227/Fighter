﻿
#include "CWMap.h"

#include <list>
#include <malloc.h>

#include "CWPawn.h"
#include "CWAStar.h"
#include "CWFuncLib.h"
#include "CWPEGrid.h"
#include "CWEventMgr.h"
#include "CWCfgUtils.h"
#include "CWGameMode.h"
#include "CWMapTile.h"
#include "CWAStarNode.h"
#include "CWArrowRender.h"
#include "CWCommonUtil.h"
#include "CWDungeonTile.h"
#include "CWPathExplorer.h"
#include "CWMapTileRender.h"
#include "CWPlayerController.h"
#include "CWDungeonDataStruct.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWDungeonRegionDataUtils.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWMap, All, All);

ACWMap* ACWMap::s_this = nullptr;

ACWMap::ACWMap(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bReplicates = true;
	NetPriority = 5.f;
	//NetUpdateFrequency = 100.0f;

	//m_map;
	m_mapSize = 0;
	m_mapWidth = 0;
	m_mapHeight = 0;
	m_gridWidth = 0;
	m_gridHeight = 0;
	m_as = nullptr;
	m_pe = nullptr;
	ArrowDensity = 2;
	bIsInitInClient = false;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	Spline = CreateDefaultSubobject<USplineComponent>(TEXT("SplineMesh"));
	Spline->SetupAttachment(RootComponent);
}

ACWMap::~ACWMap()
{
}

void ACWMap::init(int ParamDungeonId)
{
	s_this = this;
	m_dungeonId = ParamDungeonId;
}

void ACWMap::uninit()
{
}

void ACWMap::BeginPlay()
{
	Super::BeginPlay();
	
	if (!IsInServer())
	{
		InitInClient();
	}
}

void ACWMap::BeginDestroy()
{
	destroyMap();

	Super::BeginDestroy();
}

void ACWMap::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWMap, m_map);
	DOREPLIFETIME(ACWMap, ArrayPawns);
	DOREPLIFETIME(ACWMap, m_dungeonId);
	DOREPLIFETIME(ACWMap, m_mapSize);
}

bool ACWMap::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWMap::IsInMyClientMap() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWMap::IsInOtherClientMap() const
{
	return Role == ROLE_SimulatedProxy;
}

void ACWMap::GenerateMapTiles()
{
	//float xb = -460.0f;  
	//float yb = -2070.0f;
	float xb = m_offsetX;
	float yb = m_offsetY;
	float width = m_gridWidth;
	float height = m_gridHeight;
	int32 TileIdx = 0;
	
	for (int h = 0; h < m_mapHeight; ++h)
	{
		for (int w = 0; w < m_mapWidth; ++w)
		{
			UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_CWMapTile);
			if (nullptr != TempleteClass)
			{
				const FVector& NewPoint = FVector(xb + w * width, yb + h * height, CLIENT_MAP_TILE_OFFSETZ);
				ACWMapTile* MyMapTile = GetWorld()->SpawnActor<ACWMapTile>(TempleteClass, NewPoint, FRotator::ZeroRotator);
				if (MyMapTile != nullptr)
				{
					MyMapTile->SetParantMap(this);
					MyMapTile->Init();
					MyMapTile->Tile = TileIdx++;
					ArrayTiles.Add(MyMapTile);
				}
			}
		}
	}

	//CWG_WARNING(">> GenerateMapTiles, m_gridWidth[%d] m_gridHeight[%d] TileIdx[%d] ArrayTiles.Num[%d].", m_gridWidth, m_gridHeight, TileIdx, ArrayTiles.Num());
	check(ArrayTiles.Num() == TileIdx);
}

bool ACWMap::MovePawn(ACWPawn* ParamPawn, int ParamOldTile, int ParamCurTile)
{
	check(ParamPawn);
	//if (IsInServer())
	{
		for (int i = 0; i < ArrayPawns.Num(); ++i)
		{
			if (ArrayPawns[i] == ParamPawn)
			{
				ArrayPawns[i] = nullptr;
			}
		}

		if (ParamOldTile >= 0 && ParamOldTile < m_mapSize)
		{
			if (ParamCurTile >= 0 && ParamCurTile < m_mapSize)
			{
				//check(ArrayPawns[ParamOldTile] == ParamPawn);
				//ArrayPawns[ParamOldTile] = nullptr;
				//check(ArrayPawns[ParamCurTile] == nullptr);
				ArrayPawns[ParamCurTile] = ParamPawn;

				//if (ArrayPawns[ParamCurTile]->GetPawnType() == ECWPawnType::Character)
				//{
				//	if (IsInServer())
				//	{
				//		UE_LOG(LogCWMap, Error, TEXT("1 Server ACWMap::MovePawn() ParamCurTile:%d, GetTile():%d."), (int32)ParamCurTile, ParamPawn->GetTile());
				//	}
				//	else
				//	{
				//		UE_LOG(LogCWMap, Error, TEXT("1 Client ACWMap::MovePawn() ParamCurTile:%d, GetTile():%d."), (int32)ParamCurTile, ParamPawn->GetTile());
				//	}
				//}
				return true;
			}
			else
			{
				//check(ArrayPawns[ParamOldTile] == ParamPawn);
				//ArrayPawns[ParamOldTile] = nullptr;
				return true;
			}
		}
		else
		{
			if (ParamCurTile >= 0 && ParamCurTile < m_mapSize)
			{
				//check(ArrayPawns[ParamCurTile] == nullptr);
				ArrayPawns[ParamCurTile] = ParamPawn;

				//if (ArrayPawns[ParamCurTile]->GetPawnType() == ECWPawnType::Character)
				//{
				//	if (IsInServer())
				//	{
				//		UE_LOG(LogCWMap, Error, TEXT("2 Server ACWMap::MovePawn() ParamCurTile:%d, GetTile():%d."), (int32)ParamCurTile, ParamPawn->GetTile());
				//	}
				//	else
				//	{
				//		UE_LOG(LogCWMap, Error, TEXT("2 Client ACWMap::MovePawn() ParamCurTile:%d, GetTile():%d."), (int32)ParamCurTile, ParamPawn->GetTile());
				//	}
				//}
				
				return true;
			}
		}

		int Count = 0;
		for (int i = 0; i < ArrayPawns.Num(); ++i)
		{
			if (ArrayPawns[i] == ParamPawn)
			{
				Count++;
			}
		}
		check(Count == 1);

		return false;
	}
	//else
	//{
	//	//客户端永远是根据服务器的数据，无条件服从和同步
	//	for (int i = 0; i < ArrayPawns.Num(); ++i)
	//	{
	//		if (ArrayPawns[i] == ParamPawn)
	//		{
	//			ArrayPawns[i] = nullptr;
	//		}
	//	}

	//	if (ParamOldTile >= 0 && ParamOldTile < m_mapSize)
	//	{
	//		if (ParamCurTile >= 0 && ParamCurTile < m_mapSize)
	//		{
	//			//check(ArrayPawns[ParamOldTile] == ParamPawn);
	//			ArrayPawns[ParamOldTile] = nullptr;
	//			//check(ArrayPawns[ParamCurTile] == nullptr);
	//			ArrayPawns[ParamCurTile] = ParamPawn;
	//			return true;
	//		}
	//		else
	//		{
	//			//check(ArrayPawns[ParamOldTile] == ParamPawn);
	//			ArrayPawns[ParamOldTile] = nullptr;
	//			return true;
	//		}
	//	}
	//	else
	//	{
	//		if (ParamCurTile >= 0 && ParamCurTile < m_mapSize)
	//		{
	//			//check(ArrayPawns[ParamCurTile] == nullptr);
	//			ArrayPawns[ParamCurTile] = ParamPawn;
	//			return true;
	//		}
	//	}
	//	return false;
	//}
}

bool ACWMap::IsTherePawn(int ParamCurTile)
{
	if (ArrayPawns.IsValidIndex(ParamCurTile))
	{
		if (ArrayPawns[ParamCurTile] != nullptr)
			return true;
		else
			return false;
	}
	
	return false;
}

ACWMapTile* ACWMap::GetTile(int32 ParamTile)
{
	return ArrayTiles.IsValidIndex(ParamTile) ? ArrayTiles[ParamTile] : nullptr;
}

void ACWMap::RemoveTile(int32 ParamTile)
{
	ACWMapTile* TempMapTile = ArrayTiles.IsValidIndex(ParamTile) ? ArrayTiles[ParamTile] : nullptr;
	if (TempMapTile != nullptr)
	{
		TempMapTile->Destroy();
		ArrayTiles[ParamTile] = nullptr;
	}
}

void ACWMap::ResetWhenNextTurnBeginInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	for (int i = 0; i < ArrayPawns.Num(); ++i)
	{
		TWeakObjectPtr<ACWPawn> TempPawn = ArrayPawns[i];
		if (TempPawn.IsValid())
		{
			TempPawn->ResetWhenNextTurnBeginInServer(ParamCampTag, ParamCampControllerIndex);
		}
	}
}

void ACWMap::StartActionInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	for (int i = 0; i < ArrayPawns.Num(); ++i)
	{
		TWeakObjectPtr<ACWPawn> TempPawn = ArrayPawns[i];
		if (TempPawn.IsValid())
		{
			if (TempPawn->GetCampTag() == ParamCampTag && 
				TempPawn->GetCampControllerIndex() == ParamCampControllerIndex)
			{
				TempPawn->StartActionInServer(ParamCampTag, ParamCampControllerIndex);

				UE_LOG(LogCWMap, Error, TEXT("ACWMap::StartActionInServer() ParamCampTag:%d, ParamCampControllerIndex:%d."), (int32)ParamCampTag, (int32)ParamCampControllerIndex);
			}
		}
	}

	/*for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		check(TempPawn);
		if (TempPawn->GetCampTag() == ParamCampTag &&
			TempPawn->GetCampControllerIndex() == ParamCampControllerIndex)
		{
			TempPawn->StartActionInServer(ParamCampTag, ParamCampControllerIndex);
		}
	}*/
}

void ACWMap::AddSplinePoint(FVector pos)
{
	if (!ArrayArrowPos.Contains(pos))
	{
		ArrayArrowPos.Add(pos);
		Spline->AddSplineWorldPoint(pos);
		//UE_LOG(LogCWMap, Log, TEXT("ACWMap::AddSplinePoint() X:%f Y:%f Z:%f;"), pos.X,pos.Y,pos.Z)
	}
	
	if (ArrayArrowPos.Num() <= 0 || ArrowDensity <= 0)
	{
		return;
	}

	float Distance = 0.0f;
	int32 TotalNum = ArrayArrowPos.Num() * ArrowDensity;
	for (int i = 0; i < ArrayArrowPos.Num() * ArrowDensity; i++)
	{
		float DistanceStep = Spline->GetSplineLength() / (float)TotalNum;
		Distance = DistanceStep * i;
		FVector TempPos = Spline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
		FRotator TempRotation = Spline->GetRotationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
		TempRotation.Yaw += 90.0f;
		ACWArrowRender* ArrowRender = GetArrowRenderFromCache();
		check(ArrowRender);
		ArrowRender->SetActorLocation(TempPos);
		ArrowRender->SetActorRotation(TempRotation);

		bool isFind = false;
		for (std::list<ACWArrowRender*>::iterator iter = ListArrowRenderUsed.begin(); iter != ListArrowRenderUsed.end(); ++iter)
		{
			if (ArrowRender == *iter)
			{
				isFind = true;
				break;
			}
		}

		if (!isFind)
		{
			ListArrowRenderUsed.push_back(ArrowRender);
		}
	}
	//UE_LOG(LogCWMap, Log, TEXT("ACWMap::AddSplinePoint() ArrayArrowPos.Num():%d, ArrowDensity:%d, TotalNum:%d."), ArrayArrowPos.Num(), ArrowDensity, TotalNum);
}

ACWArrowRender* ACWMap::GetArrowRenderFromCache()
{
	if (ListArrowRenderCache.empty())
	{
		UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_ArrowRender);
		if (nullptr != TempleteClass)
		{
			ACWArrowRender* MyArrowRender = GetWorld()->SpawnActor<ACWArrowRender>(TempleteClass, FVector(0.0f, 0.0f, 20.0f), FRotator::ZeroRotator);
			if (MyArrowRender != nullptr)
			{
				MyArrowRender->SetParentMap(this);
				return MyArrowRender;
			}
		}
	}
	else
	{
		ACWArrowRender* MyArrowRender = ListArrowRenderCache.front();
		ListArrowRenderCache.pop_front();
		check(MyArrowRender);
		return MyArrowRender;
	}

	return nullptr;
}

void ACWMap::RomoveAllSplinePoint()
{
	for(std::list<ACWArrowRender*>::iterator iter = ListArrowRenderUsed.begin(); iter != ListArrowRenderUsed.end(); ++iter)
	{
		ACWArrowRender* ArrowRender = *iter;
		check(ArrowRender);

		bool isFind = false;
		for (std::list<ACWArrowRender*>::iterator iterSub = ListArrowRenderCache.begin(); iterSub != ListArrowRenderCache.end(); ++iterSub)
		{
			if (ArrowRender == *iterSub)
			{
				isFind = true;
				break;
			}
		}

		if (!isFind)
		{
			ArrowRender->SetActorLocation(FVector(-100000.0f, -100000.0f, 20.0f));
			ListArrowRenderCache.push_back(ArrowRender);
		}
	}
	ListArrowRenderUsed.clear();

	ArrayArrowPos.Empty(0);
	Spline->ClearSplinePoints(true);
}

bool ACWMap::createMapForServer()
{
	m_as = new FCWAStar(this);

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (TempDungeonData == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::createMapForServer fail, TempDungeonData == nullptr, m_dungeonId:%d."), m_dungeonId);
		return false;
	}

	int width = TempDungeonData->DungeonWidthExtension;
	int height = TempDungeonData->DungeonHeightExtension;
	int gridWidth = TempDungeonData->DungeonGridWidth;
	int gridHeight = TempDungeonData->DungeonGridHeight;
	int offsetX = TempDungeonData->DungeonOffsetX;
	int offsetY = TempDungeonData->DungeonOffsetY;
	if (width <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForServer Fail. width <= 0"));
		return false;
	}

	if (height <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForServer Fail. height <= 0"));
		return false;
	}

	m_mapSize = width * height;
	if (m_mapSize <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForServer Fail. m_mapSize <= 0"));
		return false;
	}

	//m_map = (uint32*)malloc(m_mapSize * sizeof(uint32));
	//memset(m_map, 0, m_mapSize * sizeof(uint32));
	m_map.Init(0, m_mapSize);
	ArrayMoveAttackDamage.Init(0, m_mapSize);
	VectorListAttack.resize(m_mapSize);
	VectorListDamage.resize(m_mapSize);
	ArrayPawns.Init(nullptr, m_mapSize);

	m_mapWidth = width;
	m_mapHeight = height;
	m_gridWidth = gridWidth;
	m_gridHeight = gridHeight;
	m_offsetX = offsetX;
	m_offsetY = offsetY;

	check(m_as != nullptr && "ACWMap::createMapForServer");
	m_as->SetColumnNum(m_mapWidth > m_mapHeight ? m_mapWidth : m_mapHeight);

	UE_LOG(LogCWMap, Log, TEXT("UCWAStar::createMapForServer Success. m_mapWidth:%d, m_mapHeight:%d, m_gridWidth:%d, m_gridHeight:%d, m_offsetX:%d, m_offsetY:%d."), m_mapWidth, m_mapHeight, m_gridWidth, m_gridHeight, m_offsetX, m_offsetY);
	return true;
}

bool ACWMap::createMapForClient()
{
	m_as = new FCWAStar(this);

	FCWDungeonDataStruct* TempDungeonData = GetDungeonData();
	if (TempDungeonData == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::createMapForClient fail, TempDungeonData == nullptr, m_dungeonId:%d."), m_dungeonId);
		return false;
	}

	int width = TempDungeonData->DungeonWidthExtension;
	int height = TempDungeonData->DungeonHeightExtension;
	int gridWidth = TempDungeonData->DungeonGridWidth;
	int gridHeight = TempDungeonData->DungeonGridHeight;
	int offsetX = TempDungeonData->DungeonOffsetX;
	int offsetY = TempDungeonData->DungeonOffsetY;
	if (width <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForClient Fail. width <= 0"));
		return false;
	}

	if (height <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForClient Fail. height <= 0"));
		return false;
	}

	m_mapSize = width * height;
	if (m_mapSize <= 0)
	{
		UE_LOG(LogCWMap, Error, TEXT("UCWAStar::createMapForClient Fail. m_mapSize <= 0"));
		return false;
	}

	//m_map = (uint32*)malloc(m_mapSize * sizeof(uint32));
	//memset(m_map, 0, m_mapSize * sizeof(uint32));
	//m_map.Init(0, m_mapSize);
	ArrayMoveAttackDamage.Init(0, m_mapSize);
	VectorListAttack.resize(m_mapSize);
	VectorListDamage.resize(m_mapSize);
	//ArrayPawns.Init(nullptr, m_mapSize);

	m_mapWidth = width;
	m_mapHeight = height;
	m_gridWidth = gridWidth;
	m_gridHeight = gridHeight;
	m_offsetX = offsetX;
	m_offsetY = offsetY;

	check(m_as != nullptr && "ACWMap::createMapForClient");
	m_as->SetColumnNum(m_mapWidth > m_mapHeight ? m_mapWidth : m_mapHeight);

	UE_LOG(LogCWMap, Log, TEXT("UCWAStar::createMapForClient Success. m_mapWidth:%d, m_mapHeight:%d, m_gridWidth:%d, m_gridHeight:%d, m_offsetX:%d, m_offsetY:%d."), m_mapWidth, m_mapHeight, m_gridWidth, m_gridHeight, m_offsetX, m_offsetY);

	OnRep_ClientChangeArrayPawns();

	return true;
}


void ACWMap::destroyMap()
{
	m_map.Empty();
	ArrayMoveAttackDamage.Empty();
	VectorListAttack.clear();
	VectorListDamage.clear();
	ArrayPawns.Empty();

	m_mapSize = 0;
	m_mapWidth = 0;
	m_mapHeight = 0;
	m_gridWidth = 0;
	m_gridHeight = 0;

	if (m_as)
	{
		delete m_as;
		m_as = nullptr;
	}
}


int ACWMap::getWidth() const
{
	return m_mapWidth;
}


int ACWMap::getHeight() const
{
	return m_mapHeight;
}

int ACWMap::getGridWidth() const
{
	return m_gridWidth;
}

int ACWMap::getGridHeight() const
{
	return m_gridHeight;
}

int ACWMap::getOffsetX() const
{
	return m_offsetX;
}

int ACWMap::getOffsetY() const
{
	return m_offsetY;
}

bool ACWMap::pathExplorerFindPathAStar(FCWPathExplorer& pe, const FVector& destPos, int limitStep, ECWCampTag movingCampTag, FCWPawnFindPathInfo ParamFindPathInfo)
{
	m_pe = &pe;
	pe.Reset();

	//是否同一个点
	if ((pe.GetPos() - destPos).IsNearlyZero())
	{
		_fillSameGridToPathExplorer(pe);
		m_pe = nullptr;
		return true;
	}
	int _sx;
	int _sy;
	pos2xy(pe.GetPos(), _sx, _sy);

	int _dx;
	int _dy;
	pos2xy(destPos, _dx, _dy);

	//目标点是否障碍
	int _ndx(_dx);
	int _ndy(_dy);
	FVector _newDestPos(destPos);
	int _newDestTile = pos2tile(destPos);
	pe.SetDestPos(_newDestPos);
	if ((!canPass(destPos) || !CanMove(_newDestTile, ParamFindPathInfo)) &&
		!pe.IsNoObstacle())
	{
		//目标点是障碍点,查找离目标点最近的非障碍点
		bool result = findNoBarrierNearestDest(_dx, _dy, _ndx, _ndy);
		if (!result)
		{
			//目标点是障碍，寻路失败,把目标点设回当前点
			pe.SetDestPos(pe.GetPos());
			m_pe = nullptr;
			return false;
		}

		xy2pos(_ndx, _ndy, _newDestPos);
		pe.SetDestPos(_newDestPos);
	}

	//起点目标点同格子移动
	if (_sx == _ndx && _sy == _ndy)
	{
		_fillSameGridToPathExplorer(pe);
		m_pe = nullptr;
		return true;
	}

	//A*搜索
	if (!pe.IsNoObstacle() && m_as->GeneratePath(_sx, _sy, _ndx, _ndy, limitStep, movingCampTag, ParamFindPathInfo))
	{
		_fillASPathToPathExplorer(pe);
		m_pe = nullptr;
		return true;
	}

	//寻路失败,把目标点设回当前点
	pe.SetDestPos(pe.GetPos());
	m_pe = nullptr;
	return false;
}

bool ACWMap::findNoBarrierNearestDest(int dx, int dy, int& ndx, int& ndy)
{
	if (dx < 0)
		dx = 0;
	if (dx >= m_mapWidth)
		dx = m_mapWidth - 1;

	if (dy < 0)
		dy = 0;
	if (dy >= m_mapHeight)
		dy = m_mapHeight - 1;

	int _step = 1;

	for (;;)
	{
		for (int dir = 0; dir < 8; ++dir)
		{
			switch (dir)
			{
			case 0:
			{
				ndx = dx;
				ndy = dy - _step;

				if (ndy >= 0)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else //ndy < 0
				{
					ndy = 0;
				}
			}
			break;
			case 1:
			{
				ndx = dx + _step;
				ndy = dy - _step;

				if (ndx < m_mapWidth && ndy >= 0)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else
				{
					if (ndx >= m_mapWidth)
						ndx = m_mapWidth - 1;

					if (ndy < 0)
						ndy = 0;
				}
			}
			break;
			case 2:
			{
				ndx = dx + _step;
				ndy = dy;

				if (ndx < m_mapWidth)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else//ndx >= m_mapWidth
				{
					ndx = m_mapWidth - 1;
				}
			}
			break;
			case 3:
			{
				ndx = dx + _step;
				ndy = dy + _step;

				if (ndx < m_mapWidth && ndy < m_mapHeight)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else
				{
					if (ndx >= m_mapWidth)
						ndx = m_mapWidth - 1;

					if (ndy >= m_mapHeight)
						ndy = m_mapHeight - 1;
				}
			}
			break;
			case 4:
			{
				ndx = dx;
				ndy = dy + _step;

				if (ndy < m_mapHeight)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else//ndy >= m_mapHeight
				{
					ndy = m_mapHeight - 1;
				}
			}
			break;
			case 5:
			{
				ndx = dx - _step;
				ndy = dy + _step;

				if (ndx >= 0 && ndy < m_mapHeight)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else
				{
					if (ndx < 0)
						ndx = 0;

					if (ndy >= m_mapHeight)
						ndy = m_mapHeight - 1;
				}
			}
			break;
			case 6:
			{
				ndx = dx - _step;
				ndy = dy;

				if (ndx >= 0)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else //ndx < 0
				{
					ndx = 0;
				}
			}
			break;
			case 7:
			{
				ndx = dx - _step;
				ndy = dy - _step;

				if (ndx >= 0 && ndy >= 0)
				{
					if (canPass(ndx, ndy))
						return true;
				}
				else
				{
					if (ndx < 0)
						ndx = 0;

					if (ndy < 0)
						ndy = 0;
				}
			}
			break;
			default:
				UE_LOG(LogCWMap, Error, TEXT("ACWMap::findNoBarrierNearestDest Fail. dir is invalid, dir:%d"), dir);
				break;
			}
		}

		//向外一圈找
		_step++;

		//char _err[CHAR_LONGLONG_BUFFER_MAX] = { '\0' };
		//_snprintf_s(_err, CHAR_LONGLONG_BUFFER_CONTENT_MAX, "ACWMap::findNoBarrierNearestDest fail. _step = %d, m_mapWidth = %d, m_mapHeight = %d, dx = %d, dy = %d.", _step, m_mapWidth, m_mapHeight, dx, dy);
		//UE_LOG(LogCWMap, Error, TEXT("ACWMap::findNoBarrierNearestDest fail. _step = %d, m_mapWidth = %d, m_mapHeight = %d, dx = %d, dy = %d."), _step, m_mapWidth, m_mapHeight, dx, dy);
		check((_step <= m_mapWidth || _step <= m_mapHeight)/* && _err*/);

		if (_step > m_mapWidth && _step > m_mapHeight)
		{
			UE_LOG(LogCWMap, Error, TEXT("ACWMap::findNoBarrierNearestDest fail. _step = %d, m_mapWidth = %d, m_mapHeight = %d, dx = %d, dy = %d."), _step, m_mapWidth, m_mapHeight, dx, dy);
			return false;
		}
	}
}

bool ACWMap::pathExplorerProgress(FCWPathExplorer& pe, float speed, float deltaTime)
{
	if (pe.GetPath().empty())
		return false;

	float _moveDistance = speed * deltaTime;
	//----------------------------------------------
	float _adjacentDistance = 0.0f;
	float _totalRanLength = 0.0f;
	float _oldTotalRanLength(_totalRanLength);
	//----------------------------------------------
	CWPEGrid _oldGrid(pe.GetPos());
	//取出路径队列第1个点
	CWPEGrid _newGrid(pe.GetPath().front());
	//----------------------------------------------
	FVector _diff = _newGrid.pos - _oldGrid.pos;
	//----------------------------------------------
	//起点与路径队列第1个点重合
	if (FMath::Abs(_diff.X) <= 0.0000001f && FMath::Abs(_diff.Y) <= 0.0000001f)
	{
		if (pe.GetPath().size() <= 1)
		{
			//路径队列里的第1个点就是目标点,到达目的地
			pe.SetArrived(true);
			pe.GetPath().clear();
			return true;
		}
		else //pe.getPath().size() > 1
		{
			//起点与路径队列第1个点重合,取出路径队列第2个点
			//_oldGrid = _newGrid;
			pe.GetPath().pop_front();
			_newGrid = pe.GetPath().front();
			_diff = _newGrid.pos - _oldGrid.pos;
		}
	}
	
	//----------------------------------------------
	//1:起点与路径队列第1个点之间的距离的计算 
	//2:起点与路径队列第2个点之间的距离的计算 
	//3:起点与路径队列第3个点之间的距离的计算 
	_adjacentDistance = _diff.Size();
	_oldTotalRanLength = _totalRanLength;
	_totalRanLength += _adjacentDistance;
	//----------------------------------------------
	if (_totalRanLength < _moveDistance)
	{
		while (pe.GetPath().size() > 1)
		{
			_oldGrid = _newGrid;
			pe.GetPath().pop_front();
			_newGrid = pe.GetPath().front();

			//是否只剩下路径队列倒数第1个点
			//if(pe.getPath().size() <= 1)
			{
				//路径队列倒数第1个点与路径队列倒数第2个点之间的距离的计算
				_diff = _newGrid.pos - _oldGrid.pos;
				_adjacentDistance = _diff.Size();
			}

			_oldTotalRanLength = _totalRanLength;
			_totalRanLength += _adjacentDistance;
			if (_totalRanLength >= _moveDistance)
			{
				break;
			}
		}
	}

	//是否只剩下路径队列倒数第1个点
	if (pe.GetPath().size() <= 1)
	{
		if (_totalRanLength <= _moveDistance)
		{
			//到达目的地
			pe.SetPos(_newGrid.pos);
			pe.SetArrived(true);
			pe.GetPath().clear();
			return true;
		}
		else
		{
			//相同的处理
		}
	}
	else
	{
		//相同的处理
	}
	
	FVector _dir = _newGrid.pos - _oldGrid.pos;
	if (FMath::Abs(_dir.X) <= 0.0000001f && FMath::Abs(_dir.Y) <= 0.0000001f)
	{
		//路径队列倒数第2个点和路径队列倒数第1个点居然重合,不可能的
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::pathExplorerProgress fail, It's impossible!"));
		return false;
	}
	else
	{
		float _realMoveDistance = _moveDistance - _oldTotalRanLength;
		check(_realMoveDistance >= 0.0f && "ACWMap::pathExplorerProgress");

		_dir.Normalize();
		_dir.X = _dir.X * _realMoveDistance;
		_dir.Y = _dir.Y * _realMoveDistance;
		FVector _newCurrPos = _oldGrid.pos + _dir;
		pe.SetPos(_newCurrPos);
		return true;
	}
}

void ACWMap::setMapTileAttribute(int x, int y, uint8 attr)
{
	int _tile = xy2tile(x, y);
	setMapTileAttribute(_tile, attr);
}


uint8 ACWMap::getMapTileAttribute(int x, int y) const
{
	int _tile = xy2tile(x, y);
	return getMapTileAttribute(_tile);
}


void ACWMap::setMapTileAttribute(int tile, uint8 attr)
{
	if (tile < 0 || tile >= m_mapSize)
		return;

	m_map[tile] = attr;
}

uint8 ACWMap::getMapTileAttribute(int tile) const
{
	if (tile < 0 || tile >= m_mapSize)
		return 0xff;

	return m_map[tile];
}


void ACWMap::setMapTileAttribute(const FVector& pos, uint8 attr)
{
	int _tile = pos2tile(pos);
	setMapTileAttribute(_tile, attr);
}


uint8 ACWMap::getMapTileAttribute(const FVector& pos) const
{
	int _tile = pos2tile(pos);
	return getMapTileAttribute(_tile);
}

void ACWMap::ResetArrayMoveAttackDamage()
{
	for (int i = 0; i < ArrayMoveAttackDamage.Num(); ++i)
	{
		ArrayMoveAttackDamage[i] = 0x00;
	}
}

uint8 ACWMap::GetMoveAttackDamage(int ParamTile) const
{
	if (ParamTile < 0 || ParamTile >= m_mapSize)
		return 0x00;

	return ArrayMoveAttackDamage[ParamTile];
}

void ACWMap::SetMoveAttackDamage(int ParamTile, uint8 ParamMoveAttackDamage)
{
	if (ParamTile < 0 || ParamTile >= m_mapSize)
		return;

	ArrayMoveAttackDamage[ParamTile] |= ParamMoveAttackDamage;
}

const TArray<uint8>& ACWMap::GetArrayMoveAttackDamage() const
{
	return ArrayMoveAttackDamage;
}

ECWAffectDirType ACWMap::GetAffectDir(int ParamSourceTile, int ParamTargetTile)
{
	FVector TempSourcePos;
	tile2pos(ParamSourceTile, TempSourcePos);

	FVector TempTargetPos;
	tile2pos(ParamTargetTile, TempTargetPos);

	FVector OffsetPos = TempTargetPos - TempSourcePos;
	if (FMath::Abs(OffsetPos.X) > 0 && FMath::Abs(OffsetPos.Y))
	{
		return ECWAffectDirType::None;
	}

	if (OffsetPos.X > 0)
		return ECWAffectDirType::Right;

	if (OffsetPos.Y > 0)
		return ECWAffectDirType::Up;

	if (OffsetPos.X < 0)
		return ECWAffectDirType::Left;

	if (OffsetPos.Y < 0)
		return ECWAffectDirType::Down;

	return ECWAffectDirType::None;
}

void ACWMap::ResetVectorAttack()
{
	for (int i = 0; i < VectorListAttack.size(); ++i)
	{
		VectorListAttack[i].clear();
	}
}

void ACWMap::SetVectorAttackGrid(int ParamTile, int ParamPawnTile, ECWAffectDirType ParamDir, uint8 ParamMoveAttackDamage)
{
	check(ParamTile < m_mapSize && "ACWMap::SetVectorAttackGrid");
	check(ParamTile >= 0 && "ACWMap::SetVectorAttackGrid");

	CWAttackGrid TempAttackGrid;
	TempAttackGrid.PawnTile = ParamPawnTile;
	TempAttackGrid.Dir = (uint8)ParamDir;
	TempAttackGrid.MAD = ParamMoveAttackDamage;

	std::list<CWAttackGrid>& ListAttackGrid = VectorListAttack[ParamTile];
	for (std::list<CWAttackGrid>::iterator iter = ListAttackGrid.begin(); iter != ListAttackGrid.end(); ++iter)
	{
		CWAttackGrid& TempGrid = *iter;
		if (TempAttackGrid == TempGrid)
		{
			return;
		}
	}

	ListAttackGrid.push_back(TempAttackGrid);
}

void ACWMap::ResetVectorDamage()
{
	for (int i = 0; i < VectorListDamage.size(); ++i)
	{
		VectorListDamage[i].clear();
	}
}

void ACWMap::SetVectorDamageGrid(int ParamTile, int ParamPawnTile, int ParamAttackTile, ECWAffectDirType ParamDir, uint8 ParamMoveAttackDamage)
{
	check(ParamTile < m_mapSize && "ACWMap::SetVectorDamageGrid");
	check(ParamTile >= 0 && "ACWMap::SetVectorDamageGrid");

	CWDamageGrid TempDamageGrid;
	TempDamageGrid.PawnTile = ParamPawnTile;
	TempDamageGrid.AttackTile = ParamAttackTile;
	TempDamageGrid.Dir = (uint8)ParamDir;
	TempDamageGrid.MAD = ParamMoveAttackDamage;
	TempDamageGrid.Tile = ParamTile;

	std::list<CWDamageGrid>& ListDamageGrid = VectorListDamage[ParamTile];
	for (std::list<CWDamageGrid>::iterator iter = ListDamageGrid.begin(); iter != ListDamageGrid.end(); ++iter)
	{
		CWDamageGrid& TempGrid = *iter;
		if (TempDamageGrid == TempGrid)
		{
			return;
		}
	}

	ListDamageGrid.push_back(TempDamageGrid);
}

const std::vector<std::list<CWDamageGrid>>& ACWMap::GetVectorDamageGrid() const
{
	return VectorListDamage;
}

bool ACWMap::ConsumeMove(const std::list<CWPEGrid>& ParamListPEGrid, int ParamMove, FCWPawnFindPathInfo ParamFindPathInfo)
{
	if (ParamListPEGrid.size() <= 1)
	{
		return false;
	}

	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		return false;
	}

	const TArray<int32>& TempArrayDungeonGrid_Z = TempDungeonGenerator->GetArrayDungeonGrid_Z();
	std::list<CWPEGrid>::const_iterator iter1 = ParamListPEGrid.begin();
	CWPEGrid TempGrid1 = *iter1;
	//UE_LOG(LogCWMap, Log, TEXT("ACWMap::ConsumeMove, TempGrid.x:%d, TempGrid.y:%d, TempGrid.tile:%d."), TempGrid1.x, TempGrid1.y, TempGrid1.tile);

	int TempRemainMove = ParamMove;
	for (std::list<CWPEGrid>::const_iterator iter2 = ParamListPEGrid.begin(); iter2 != ParamListPEGrid.end(); ++iter2)
	{
		CWPEGrid TempGrid2 = *iter2;
		if (TempGrid2 == TempGrid1)
			continue;

		if (TempGrid1.tile < 0 || TempGrid1.tile >= TempArrayDungeonGrid_Z.Num())
			return false;

		if (TempGrid2.tile < 0 || TempGrid2.tile >= TempArrayDungeonGrid_Z.Num())
			return false;

		int z1 = TempArrayDungeonGrid_Z[TempGrid1.tile];
		int z2 = TempArrayDungeonGrid_Z[TempGrid2.tile];
		int z = FMath::Abs(z1 - z2);

		int TempStandardConsumeMove = GetStandardConsumeMove(TempGrid2.tile, ParamFindPathInfo);
		int TempIncrementConsumeMove = GetIncrementConsumeMove(TempGrid2.tile, ParamFindPathInfo);
		TempRemainMove = TempRemainMove - (TempStandardConsumeMove + z * TempIncrementConsumeMove);

		TempGrid1 = TempGrid2;
		if (TempRemainMove < 0)
			return false;
	}

	if (TempRemainMove >= 0)
		return true;
	else
		return false;
}


int ACWMap::cost(int px, int py, int cx, int cy, FCWPawnFindPathInfo ParamFindPathInfo)
{
	if ((FMath::Abs(px - cx) == 0 && FMath::Abs(py - cy) == 1) ||
		(FMath::Abs(px - cx) == 1 && FMath::Abs(py - cy) == 0))
	{
		ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
		if (TempDungeonGenerator != nullptr)
		{
			int pt = xy2tile(px, py);
			int ct = xy2tile(cx, cy);
			int z = GetAbsZ(pt, ct);

			if (this->CanMove(ct, ParamFindPathInfo))
			{
				int TempStandardConsumeMove = GetStandardConsumeMove(ct, ParamFindPathInfo);
				int TempIncrementConsumeMove = GetIncrementConsumeMove(ct, ParamFindPathInfo);

				return TempStandardConsumeMove * this->m_gridWidth + z * TempIncrementConsumeMove * this->m_gridWidth;
			}
			else
			{
				return 0x7fffffff;
			}
		}
		else
		{
			return 0x7fffffff;
		}
		
	}
	else if (FMath::Abs(px - cx) == 1 && FMath::Abs(py - cy) == 1)
	{
		ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
		if (TempDungeonGenerator != nullptr)
		{
			int pt = xy2tile(px, py);
			int ct = xy2tile(cx, cy);
			int z = GetAbsZ(pt, ct);
			
			if (this->CanMove(ct, ParamFindPathInfo))
			{
				int TempStandardConsumeMove = GetStandardConsumeMove(ct, ParamFindPathInfo);
				int TempIncrementConsumeMove = GetIncrementConsumeMove(ct, ParamFindPathInfo);

				return 2 * (TempStandardConsumeMove * this->m_gridWidth) + z * TempIncrementConsumeMove * this->m_gridWidth;
			}
			else
			{
				return 0x7fffffff;
			}
		}
		else
		{
			return 0x7fffffff;
		}
	}
	else
	{
		return 0x7fffffff;
	}
}

bool ACWMap::canPass(int x, int y) const
{
	int _tile = xy2tile(x, y);
	return canPass(_tile);
}

bool ACWMap::canPassIncludeEnemy(int x, int y, ECWCampTag movingCampTag) const
{
	int _tile = xy2tile(x, y);
	return canPass(_tile) && !isThereEnemy(_tile, movingCampTag);
}

bool ACWMap::isThereEnemy(int tile, ECWCampTag movingCampTag) const
{
	if (tile < 0 || tile >= m_mapSize)
		return false;

	TWeakObjectPtr<ACWPawn> MyPawn = ArrayPawns[tile];
	if (MyPawn.IsValid() && MyPawn->GetCampTag() != movingCampTag)
	{
		return true;
	}
	return false;
}

bool ACWMap::isTherePartner(int tile, ECWCampTag movingCampTag, ECWCampControllerIndex movingCampControllerIndex) const
{
	if (tile < 0 || tile >= m_mapSize)
		return false;

	TWeakObjectPtr<ACWPawn> MyPawn = ArrayPawns[tile];
	if (MyPawn.IsValid() && 
		MyPawn->GetCampTag() == movingCampTag &&
		MyPawn->GetCampControllerIndex() == movingCampControllerIndex)
	{
		return true;
	}
	return false;
}

bool ACWMap::isTherePawn(int tile) const
{
	if (tile < 0 || tile >= m_mapSize)
		return false;

	TWeakObjectPtr<ACWPawn> MyPawn = ArrayPawns[tile];
	if (MyPawn.IsValid())
	{
		return true;
	}
	return false;
}

bool ACWMap::IsMe(
	ECWCampTag ParamCampTag,
	ECWCampControllerIndex ParamCampControllerIndex,
	int32 ParamControllerPawnIndex,
	int tile) const
{
	if (tile < 0 || tile >= m_mapSize)
		return false;

	TWeakObjectPtr<ACWPawn> MyPawn = ArrayPawns[tile];
	if (MyPawn.IsValid())
	{
		if (MyPawn->GetCampTag() == ParamCampTag &&
			MyPawn->GetCampControllerIndex() == ParamCampControllerIndex &&
			MyPawn->GetControllerPawnIndex() == ParamControllerPawnIndex)
			return true;
	}

	return false;
}

TWeakObjectPtr<ACWPawn> ACWMap::GetPawnByTile(const int32 InTile)
{
	if (ArrayPawns.IsValidIndex(InTile))
	{
		TWeakObjectPtr<ACWPawn> MyPawn = ArrayPawns[InTile];
		if (MyPawn.IsValid() && !MyPawn->IsDieOrDeath())
		{
			return MyPawn;
		}
	}
	return nullptr;
}

TArray<TWeakObjectPtr<ACWPawn>> ACWMap::GetArrayPawns()
{
	return ArrayPawns;
}

FCWDungeonDataStruct* ACWMap::GetDungeonData()
{
	FCWDungeonDataStruct* TempDungeonData = FCWCommonUtil::FindCSVRow<FCWDungeonDataStruct>(TEXT("CWDungeonDataTable"), m_dungeonId);
	check(TempDungeonData);
	return TempDungeonData;
}

ACWRandomDungeonGenerator* ACWMap::GetDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(GetWorld());
}

ACWPawnStart* ACWMap::GetPawnStartByTile(const int32 InTile)
{
	ACWRandomDungeonGenerator* Generator = GetDungeonGenerator();
	ACWPawnStart* OutPawnStart = Generator ? Generator->GetPawnStartByTile(InTile) : nullptr;
	return OutPawnStart;
}

const TArray<ACWMapTile*>& ACWMap::GetArrayTiles()
{
	return ArrayTiles;
}

void ACWMap::OnRep_ClientChangeArrayPawns()
{
	/** 场景对象额外偏移Z */
	//ACWRandomDungeonGenerator* Generator = GetDungeonGenerator();
	//const float ObjectOffsetZ = Generator ? Generator->GetObjectExtraOffsetZ() : 2.0f;

	// 重置地图棋子位置
	for (int i = 0; i < ArrayPawns.Num(); ++i)
	{
		if (ACWPawn* TempPawnPtr = ArrayPawns[i].Get())
		{
			//if (TempPawnPtr->IsMyClientPawn())
			//if (TempPawnPtr->IsPawnType(ECWPawnType::Character))
			{
				FVector NewPos = FVector::ZeroVector;
				ACWMap::tile2pos(i, NewPos);
				NewPos.Z = /*ObjectOffsetZ + */TempPawnPtr->GetDungeonTileZ(i);
				TempPawnPtr->SetActorLocation(NewPos);
			}
		}
	}
}

void ACWMap::OnRep_DungeonId(int32 InOldDungeonId)
{
	InitInClient();
}

bool ACWMap::canPass(int tile) const
{
	//check(nullptr != m_map && "ACWMap::canPass");
	if (tile < 0 || tile >= m_mapSize)
		return false;

	return m_map[tile] & 0x01 ? false : true;
}

bool ACWMap::canPass(int tile, const ACWPawn* ParamMovePawn) const
{
	check(ParamMovePawn);
	if (tile < 0 || tile >= m_mapSize)
		return false;

	if (m_map[tile] & 0x01)
	{
		return false;
	}
	else
	{
		if (ArrayPawns[tile] != nullptr)
		{
			TWeakObjectPtr<ACWPawn> MapPawn = ArrayPawns[tile];
			if (MapPawn.IsValid())
			{
				if (MapPawn->GetCampTag() != ParamMovePawn->GetCampTag())
				{
					return false;
				}
				else
				{
					return true;
				}
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
	}
}


bool ACWMap::canPass(const FVector& pos) const
{
	int _tile = pos2tile(pos);
	return canPass(_tile);
}

void ACWMap::tile2xy(int tile, int& x, int& y)
{
	if (s_this == nullptr || s_this->m_mapWidth == 0)
	{
		x = -1;
		y = -1;
		return;
	}

	x = tile % s_this->m_mapWidth;
	y = tile / s_this->m_mapWidth;
}


void ACWMap::tile2pos(int tile, FVector& pos)
{
	int _x;
	int _y;
	tile2xy(tile, _x, _y);
	xy2pos(_x, _y, pos);
}


int ACWMap::xy2tile(int x, int y)
{
	if (s_this == nullptr || s_this->m_mapWidth == 0)
	{
		return -1;
	}

	return y * s_this->m_mapWidth + x;
}


void ACWMap::xy2pos(int x, int y, FVector& pos)
{
	if (s_this == nullptr || s_this->m_gridWidth == 0 || s_this->m_gridHeight == 0)
	{
		pos = FVector::ZeroVector;
		return;
	}

	//float xb = -460.0f;
	//float yb = -2070.0f;

	//pos.X = x * s_this->m_gridWidth + s_this->m_gridWidth * 0.5f + xb;
	//pos.Y = y * s_this->m_gridHeight + s_this->m_gridHeight * 0.5f + yb;
	pos.X = x * s_this->m_gridWidth + s_this->m_offsetX;
	pos.Y = y * s_this->m_gridHeight + s_this->m_offsetY;
	pos.Z = 0.0f;
}


int ACWMap::pos2tile(const FVector& pos)
{
	int _x;
	int _y;
	pos2xy(pos, _x, _y);
	return xy2tile(_x, _y);
}


void ACWMap::pos2xy(const FVector& pos, int& x, int& y)
{
	if (s_this == nullptr || s_this->m_gridWidth == 0 || s_this->m_gridHeight == 0)
	{
		x = -1;
		y = -1;
		return;
	}

	x = (int)((pos.X - s_this->m_offsetX) / s_this->m_gridWidth);
	y = (int)((pos.Y - s_this->m_offsetY) / s_this->m_gridHeight);
}

bool ACWMap::IsInitInClient() const
{
	return bIsInitInClient;
}

void ACWMap::InitInClient()
{
	if (!IsInitInClient())
	{
		if (m_dungeonId > 0)
		{
			s_this = this;
			createMapForClient();
			GenerateMapTiles();
			bIsInitInClient = true;
			OnAfterMapSetupInClient.Broadcast();
		}
		CWG_LOG(">> %s::InitInClient, m_dungeonId[%d] bIsInitInClient[%s]~", *GetName(), m_dungeonId, *BOOL_TO_FSTRING(bIsInitInClient));
	}
}

bool ACWMap::IsSameZ(int px, int py, int cx, int cy)
{
	int pt = xy2tile(px, py);
	int ct = xy2tile(cx, cy);
	return IsSameZ(pt, ct);
}

bool ACWMap::IsSameZ(int pt, int ct)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::IsSameZ Fail. TempDungeonGenerator == nullptr."));
		return false;
	}

	const TArray<int32>& TempArrayDungeonGrid_Z = TempDungeonGenerator->GetArrayDungeonGrid_Z();
	if (pt < 0 || pt >= TempArrayDungeonGrid_Z.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::IsSameZ Fail. pt < 0 || pt >= TempArrayDungeonGrid_Z.Num(), pt:%d, TempArrayDungeonGrid_Z.Num():%d."), pt, TempArrayDungeonGrid_Z.Num());
		return false;
	}

	if (ct < 0 || ct >= TempArrayDungeonGrid_Z.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::IsSameZ Fail. ct < 0 || ct >= TempArrayDungeonGrid_Z.Num(), ct:%d, TempArrayDungeonGrid_Z.Num():%d."), ct, TempArrayDungeonGrid_Z.Num());
		return false;
	}

	int ptz = TempArrayDungeonGrid_Z[pt];
	int ctz = TempArrayDungeonGrid_Z[ct];
	if (ptz == ctz)
		return true;
	else
		return false;
}

int ACWMap::GetAbsZ(int pt, int ct)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetAbsZ Fail. TempDungeonGenerator == nullptr."));
		return 0;
	}

	const TArray<int32>& TempArrayDungeonGrid_Z = TempDungeonGenerator->GetArrayDungeonGrid_Z();
	if (pt < 0 || pt >= TempArrayDungeonGrid_Z.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetAbsZ Fail. pt < 0 || pt >= TempArrayDungeonGrid_Z.Num(), pt:%d, TempArrayDungeonGrid_Z.Num():%d."), pt, TempArrayDungeonGrid_Z.Num());
		return 0;
	}

	if (ct < 0 || ct >= TempArrayDungeonGrid_Z.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetAbsZ Fail. ct < 0 || ct >= TempArrayDungeonGrid_Z.Num(), ct:%d, TempArrayDungeonGrid_Z.Num():%d."), ct, TempArrayDungeonGrid_Z.Num());
		return 0;
	}

	int ptz = TempArrayDungeonGrid_Z[pt];
	int ctz = TempArrayDungeonGrid_Z[ct];
	
	int z = FMath::Abs(ptz - ctz);
	return z;
}

int ACWMap::GetStandardConsumeMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetStandardConsumeMove Fail. TempDungeonGenerator == nullptr."));
		return 1;
	}

	const TArray<int32>& TempArrayDungeonGrid = TempDungeonGenerator->GetArrayDungeonGrid();
	if (ct < 0 || ct >= TempArrayDungeonGrid.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetStandardConsumeMove Fail. ct < 0 || ct >= TempArrayDungeonGrid.Num(), ct:%d, TempArrayDungeonGrid.Num():%d."), ct, TempArrayDungeonGrid.Num());
		return 1;
	}

	int TempDungeonRegionId = TempArrayDungeonGrid[ct];
	FCWDungeonRegionDataStruct* TempDungeonRegionData = TempDungeonGenerator->GetDungeonRegionData(TempDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetStandardConsumeMove Fail. TempDungeonRegionData == nullptr, TempDungeonRegionId:%d."), TempDungeonRegionId);
		return 1;
	}

	std::vector<std::vector<int32> > ArrayArrayStandardConsumeMove = FCWDungeonRegionDataUtils::GetArrayArrayStandardConsumeMoveFromString(TempDungeonRegionData->ArrayStandardConsumeMove);
	int TempStandardConsumeMove = 1;
	for (int i = 0; i < ArrayArrayStandardConsumeMove.size(); ++i)
	{
		if (ArrayArrayStandardConsumeMove[i].size() != 2)
		{
			UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetStandardConsumeMove Fail. ArrayArrayStandardConsumeMove[i].size != 2, ArrayArrayStandardConsumeMove[i].size():%d, i:%d."), ArrayArrayStandardConsumeMove[i].size(), i);
			return 1;
		}
		int TempMoveType = ArrayArrayStandardConsumeMove[i][0];
		if ((int)ParamFindPathInfo.MoveType == TempMoveType)
		{
			TempStandardConsumeMove = ArrayArrayStandardConsumeMove[i][1];
			break;
		}
	}

	return TempStandardConsumeMove;
}

int ACWMap::GetIncrementConsumeMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetIncrementConsumeMove Fail. TempDungeonGenerator == nullptr."));
		return 1;
	}

	const TArray<int32>& TempArrayDungeonGrid = TempDungeonGenerator->GetArrayDungeonGrid();
	if (ct < 0 || ct >= TempArrayDungeonGrid.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetIncrementConsumeMove Fail. ct < 0 || ct >= TempArrayDungeonGrid.Num(), ct:%d, TempArrayDungeonGrid.Num():%d."), ct, TempArrayDungeonGrid.Num());
		return 1;
	}

	int TempDungeonRegionId = TempArrayDungeonGrid[ct];
	FCWDungeonRegionDataStruct* TempDungeonRegionData = TempDungeonGenerator->GetDungeonRegionData(TempDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetIncrementConsumeMove Fail. TempDungeonRegionData == nullptr, TempDungeonRegionId:%d."), TempDungeonRegionId);
		return 1;
	}

	std::vector<std::vector<int32> > ArrayArrayIncrementConsumeMove = FCWDungeonRegionDataUtils::GetArrayArrayIncrementConsumeMoveFromString(TempDungeonRegionData->ArrayIncrementConsumeMove);
	int TempIncrementConsumeMove = 1;
	for (int i = 0; i < ArrayArrayIncrementConsumeMove.size(); ++i)
	{
		if (ArrayArrayIncrementConsumeMove[i].size() != 2)
		{
			UE_LOG(LogCWMap, Error, TEXT("ACWMap::GetIncrementConsumeMove Fail. ArrayArrayIncrementConsumeMove[i].size != 2, ArrayArrayIncrementConsumeMove[i].size():%d, i:%d."), ArrayArrayIncrementConsumeMove[i].size(), i);
			return 1;
		}
		int TempMoveType = ArrayArrayIncrementConsumeMove[i][0];
		if (ParamFindPathInfo.MoveType == TempMoveType)
		{
			TempIncrementConsumeMove = ArrayArrayIncrementConsumeMove[i][1];
			break;
		}
	}

	return TempIncrementConsumeMove;
}

bool ACWMap::CanMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. TempDungeonGenerator == nullptr."));
		return false;
	}

	const TArray<int32>& TempArrayDungeonRegionId = TempDungeonGenerator->GetArrayDungeonRegionId();
	if (ct < 0 || ct >= TempArrayDungeonRegionId.Num())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. ct < 0 || ct >= TempArrayDungeonRegionId.Num(), ct:%d, TempArrayDungeonRegionId.Num():%d."), ct, TempArrayDungeonRegionId.Num());
		return false;
	}

	int TempDungeonRegionId = TempArrayDungeonRegionId[ct];
	FCWDungeonRegionDataStruct* TempDungeonRegionData = TempDungeonGenerator->GetDungeonRegionData(TempDungeonRegionId);
	if (TempDungeonRegionData == nullptr)
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. TempDungeonRegionData == nullptr, TempDungeonRegionId:%d."), TempDungeonRegionId);
		return false;
	}

	std::vector<std::vector<int32> > TempArrayArrayRegionPassable = FCWDungeonRegionDataUtils::GetArrayArrayRegionPassableFromString(TempDungeonRegionData->ArrayRegionPassable);
	int TempCanMove = 0;
	for (int i = 0; i < TempArrayArrayRegionPassable.size(); ++i)
	{

		if (TempArrayArrayRegionPassable[i].size() != 2)
		{
			UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. TempArrayArrayRegionPassable[i].size != 2, TempArrayArrayRegionPassable[i].size():%d, i:%d."), TempArrayArrayRegionPassable[i].size(), i);
			return false;
		}
		
		int TempMoveType = TempArrayArrayRegionPassable[i][0];
		if (ParamFindPathInfo.MoveType == TempMoveType)
		{
			TempCanMove = TempArrayArrayRegionPassable[i][1];
			//UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. TempCanMove:%d, ct:%d, MoveType:%d, i:%d, TempDungeonRegionId:%d."), TempCanMove, ct, ParamFindPathInfo.MoveType, i, TempDungeonRegionId);
			break;
		}
	}

	if (TempCanMove == 1)
	{
		return true;
	}
	else
	{
		//UE_LOG(LogCWMap, Error, TEXT("ACWMap::CanMove Fail. TempCanMove:%d, ct:%d, MoveType:%d."), TempCanMove, ct, ParamFindPathInfo.MoveType);
		return false;
	}
}

void ACWMap::_fillSameGridToPathExplorer(FCWPathExplorer& pe)
{
	pe.GetPath().push_front(pe.GetDestGrid());
	if (pe.GetPath().empty())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::_fillSameGridToPathExplorer Fail. pe.getPath().empty()"));
	}

	//目标点是否与路径队列倒数第1个点相等
	CWPEGrid _dg = pe.GetPath().back();
	if (_dg != pe.GetDestGrid())
	{
		//不相等,把目标点放到路径队列倒数第1个位置
		pe.GetPath().push_back(pe.GetDestGrid());
	}
}


void ACWMap::_fillASPathToPathExplorer(FCWPathExplorer& pe)
{
	//A*寻路成功,填充路径队列
	//------------------------------------------------------
	CWAStarNode* _node = m_as->GetCurBestNode();
	while (_node)
	{
		pe.GetPath().push_front(CWPEGrid(_node->X, _node->Y));
		_node = _node->Parent;
	}

	if (pe.GetPath().empty())
	{
		UE_LOG(LogCWMap, Error, TEXT("ACWMap::_fillASPathToPathExplorer Fail. pe.getPath().empty()"));
	}

	//目标点是否与路径队列倒数第1个点相等
	CWPEGrid _dg = pe.GetPath().back();
	if (_dg != pe.GetDestGrid())
	{
		//不相等,把目标点放到路径队列倒数第1个位置
		pe.GetPath().push_back(pe.GetDestGrid());
	}
	//------------------------------------------------------
	//视野优化
	//pe.sight();
	//------------------------------------------------------
}

MapTileCompare::MapTileCompare(ACWMap* ParamMyMap, int ParamBeginTile, ECWCampTag ParamCampTag, FCWPawnFindPathInfo ParamFindPathInfo)
{
	check(ParamMyMap);
	MyMap = ParamMyMap;
	BeginTile = ParamBeginTile;
	CampTag = ParamCampTag;
	FindPathInfo = ParamFindPathInfo;
}

bool MapTileCompare::operator()(int lhs, int rhs)
{
	FVector beginPos = FVector::ZeroVector;
	ACWMap::tile2pos(BeginTile, beginPos);

	FCWPathExplorer lhsPE;
	lhsPE.Reset();
	lhsPE.SetPos(beginPos);
	FVector lhsDestPos;
	ACWMap::tile2pos(lhs, lhsDestPos);
	if (!MyMap->pathExplorerFindPathAStar(lhsPE, lhsDestPos, 100000, CampTag, FindPathInfo))
	{
		return false;
	}

	FCWPathExplorer rhsPE;
	rhsPE.Reset();
	rhsPE.SetPos(beginPos);
	FVector rhsDestPos;
	ACWMap::tile2pos(rhs, rhsDestPos);
	if (!MyMap->pathExplorerFindPathAStar(rhsPE, rhsDestPos, 100000, CampTag, FindPathInfo))
	{
		return true;
	}

	if (lhsPE.GetPath().size() < rhsPE.GetPath().size())
	{
		return true;
	}
	//else if (lhsPE.GetPath().size() > rhsPE.GetPath().size())
	//{
	//	return 1;
	//}
	else
	{
		return false;
	}
}