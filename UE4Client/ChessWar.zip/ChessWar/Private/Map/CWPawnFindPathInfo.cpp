#include "CWPawnFindPathInfo.h"

FCWPawnFindPathInfo::FCWPawnFindPathInfo()
{
	Profession = 0;
	MoveType = 0;
}

FCWPawnFindPathInfo::~FCWPawnFindPathInfo()
{
}
