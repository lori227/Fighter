﻿#include "CW2DAStar.h"
#include "Map/CWMap.h"
#include "Map/FindPath/CWAStarNode.h"
#include "Map/FindPath/CWAStarStack.h"
#include <cmath>
#include "Math/UnrealMathUtility.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWAStar2D, All, All);

AStar2D::AStar2D()
	: m_columns(0)
	, m_sx(0)
	, m_sy(0)
	, m_dx(0)
	, m_dy(0)
	, m_did(-1)
	, m_step(0)
	, m_open(NULL)
	, m_closed(NULL)
	, m_curBestNode(NULL)
	, m_stack(NULL)
	, m_isValidFunc(NULL)
	, m_costFunc(NULL)
{
}

///析构
AStar2D::~AStar2D()
{
}

///生成路径
bool AStar2D::generatePath(int sx, int sy, int dx, int dy, int limitStep)
{
	_ready(sx, sy, dx, dy);

	int _ret = 0;
	while (_ret == 0)
	{
		if (m_step >= limitStep)
			return false;

		_ret = _step();
	};

	return (_ret == -1 ? false : true);
}

///设置列数
void AStar2D::setColumnNum(int cn)
{
	m_columns = cn;
}

///获得当前最好节点
ASNode2D* AStar2D::getCurBestNode() const
{
	return m_curBestNode;
}

///获得步数
int AStar2D::getStep() const
{
	return m_step;
}



	///准备工作
void AStar2D::_ready(int sx, int sy, int dx, int dy)
{
	m_step = 0;
	m_curBestNode = NULL;
	_clearOpenList();
	_clearClosedList();
	_clearStack();

	m_sx = sx;
	m_sy = sy;
	m_dx = dx;
	m_dy = dy;
	m_did = _coordinate2ID(dx, dy);

	ASNode2D* _node = new ASNode2D(sx, sy);
	if (_node == NULL)
	{
		UE_LOG(LogCWAStar2D, Error, TEXT("new ASNode2D() fail."));
		return;
	}

	_node->g = 0;
	_node->h = FMath::Abs(dx - sx) + FMath::Abs(dy - sy);
	_node->f = _node->g + _node->h;
	_node->id = _coordinate2ID(sx, sy);

	_addToOpenList(_node);
}

///步进
int AStar2D::_step()
{
	m_step++;

	if ((m_curBestNode = _getBestNodeInOpenList()) == NULL)
		return -1;

	if (m_curBestNode->id == m_did)
		return 1;

	_createChildren(m_curBestNode);
	return 0;
}

///添加节点到Open表
void AStar2D::_addToOpenList(ASNode2D* addNode)
{
	if (m_open == NULL)
	{
		m_open = addNode;
		return;
	}

	ASNode2D* _node = m_open;
	ASNode2D* _prev = NULL;

	while (_node)
	{
		if (addNode->f > _node->f)
		{
			_prev = _node;
			_node = _node->next;
		}
		else
		{
			_prev ? _prev->next = addNode : m_open = addNode;
			addNode->next = _node;
			return;
		}
	}

	_prev->next = addNode;
}

///得到Open表最好的节点,并将其移到closed表
ASNode2D* AStar2D::_getBestNodeInOpenList()
{
	if (m_open == NULL)
		return NULL;

	ASNode2D* _temp1 = m_open;
	ASNode2D* _temp2 = m_closed;
	m_open = _temp1->next;
	m_closed = _temp1;
	m_closed->next = _temp2;
	return _temp1;
}

///查找Open表是否有此ID的节点
ASNode2D* AStar2D::_findNodeInOpenList(int id) const
{
	ASNode2D* _node = m_open;
	while (_node)
	{
		if (_node->id == id)
			return _node;

		_node = _node->next;
	}

	return NULL;
}

	///Open表清除
void AStar2D::_clearOpenList()
{
	ASNode2D* _temp = NULL;
	while (m_open)
	{
		_temp = m_open->next;
		delete m_open;
		m_open = _temp;
	}
}

	///查找Closed表是否有此ID的节点
ASNode2D* AStar2D::_findNodeInClosedList(int id) const
{
	ASNode2D* _node = m_closed;
	while (_node)
	{
		if (_node->id == id)
			return _node;

		_node = _node->next;
	}

	return NULL;
}

///Closed表清除
void AStar2D::_clearClosedList()
{
	ASNode2D* _temp = NULL;
	while (m_closed)
	{
		_temp = m_closed->next;
		delete m_closed;
		m_closed = _temp;
	}
}

	///创建子节点
void AStar2D::_createChildren(ASNode2D* p)
{
	int _cx;
	int _cy;

	for (int i = -1; i < 2; ++i)
	{
		for (int j = -1; j < 2; ++j)
		{
			_cx = p->x + i;
			_cy = p->y + j;
			if ((i == 0 && j == 0) ||					//排除自己
				(!m_isValidFunc(p->x, p->y, _cx, _cy)))	//是否有效
			{
				continue;
			}

			if ((i == -1 && j == -1) ||
				(i == 1 && j == -1) ||
				(i == -1 && j == 1) ||
				(i == 1 && j == 1))
			{
				continue;
			}

			_linkChild(p, _cx, _cy);
		}
	}
}

///链接子节点
void AStar2D::_linkChild(ASNode2D* p, int cx, int cy)
{
	int _cg = p->g + m_costFunc(p->x, p->y, cx, cy);
	int _cid = _coordinate2ID(cx, cy);

	ASNode2D* _checkNode;
	if ((_checkNode = _findNodeInOpenList(_cid)) != NULL)
	{
		p->children[p->numChildren++] = _checkNode;

		if (_cg < _checkNode->g)
		{
			_checkNode->parent = p;
			_checkNode->g = _cg;
			_checkNode->f = _cg + _checkNode->h;
		}
	}
	else if ((_checkNode = _findNodeInClosedList(_cid)) != NULL)
	{
		p->children[p->numChildren++] = _checkNode;

		if (_cg < _checkNode->g)
		{
			_checkNode->parent = p;
			_checkNode->g = _cg;
			_checkNode->f = _cg + _checkNode->h;

			_updateParents(_checkNode);
		}
	}
	else
	{
		ASNode2D* _childNode = new ASNode2D(cx, cy);
		if (_childNode == NULL)
		{
			UE_LOG(LogCWAStar2D, Error, TEXT("new ASNode2D() fail."));
			return;
		}

		_childNode->parent = p;
		_childNode->g = _cg;
		_childNode->h = FMath::Abs(cx - m_dx) + FMath::Abs(cy - m_dy);
		_childNode->f = _cg + _childNode->h;
		_childNode->id = _cid;

		p->children[p->numChildren++] = _childNode;

		_addToOpenList(_childNode);
	}
}

///刷新父节点
void AStar2D::_updateParents(ASNode2D* p)
{
	ASNode2D* _kid = NULL;
	for (int i = 0; i < p->numChildren; ++i)
	{
		_kid = p->children[i];
		if (p->g + 1 < _kid->g)
		{
			_kid->parent = p;
			_kid->g = p->g + 1;
			_kid->f = _kid->g + _kid->h;

			_push(_kid);
		}
	}

	ASNode2D* _parent;
	while (m_stack)
	{
		_parent = _pop();
		for (int i = 0; i < _parent->numChildren; ++i)
		{
			_kid = _parent->children[i];
			if (_parent->g + 1 < _kid->g)
			{
				_kid->parent = _parent;
				_kid->g = _parent->g + m_costFunc(_parent->x, _parent->y, _kid->x, _kid->y);
				_kid->f = _kid->g + _kid->h;

				_push(_kid);
			}
		}
	}
}

///压栈
void AStar2D::_push(ASNode2D* node)
{
	ASStack2D* _temp = new ASStack2D();
	if (_temp == NULL)
	{
		UE_LOG(LogCWAStar2D, Error, TEXT("new ASStack2D() fail."));
		return;
	}

	if (m_stack == NULL)
	{
		m_stack = _temp;
		m_stack->data = node;
		m_stack->next = NULL;
	}
	else
	{
		_temp->data = node;
		_temp->next = m_stack;
		m_stack = _temp;
	}
}

///出栈
inline ASNode2D* AStar2D::_pop()
{
	ASNode2D* _data = m_stack->data;
	ASStack2D* _temp = m_stack;

	m_stack = _temp->next;
	delete _temp;
	return _data;
}

///清空Statck
void AStar2D::_clearStack()
{
	while (m_stack)
	{
		ASStack2D* _temp = m_stack;
		m_stack = _temp->next;
		delete _temp;
	}
}

///坐标转唯一id
int AStar2D::_coordinate2ID(int x, int y)
{
	return x * m_columns + y;
}