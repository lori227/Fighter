#include "CW2DBSHL.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWBSHL2D, All, All);

BSHL2D::BSHL2D()
	: m_sx(0)
	, m_sy(0)
	, m_dx(0)
	, m_dy(0)
	, m_dfx(0)
	, m_dfy(0)
	, m_slope(0.0f)
	, m_step(0)
	, m_open(NULL)
	, m_closed(NULL)
	, m_curBestNode(NULL)
	, m_pyx(0)
	, m_twoDy(0)
	, m_twoDyMinusDx(0)
	, m_pxy(0)
	, m_twoDx(0)
	, m_twoDxMinusDy(0)
	, m_isValidFunc(NULL)
{
}
//--------------------------------------------------------------------------------	
BSHL2D::~BSHL2D()
{
	_clearOpenList();
	_clearClosedList();
}
bool BSHL2D::generatePath(int sx, int sy, int dx, int dy)
{
	_ready(sx, sy, dx, dy);

	int _ret = 0;
	while (_ret == 0)
	{
		_ret = _step();
	};

	return (_ret == -1 ? false : true);
}
//--------------------------------------------------------------------------------
///��õ�ǰ��ýڵ�
BSHLNode2D* BSHL2D::getCurBestNode() const
{
	return m_curBestNode;
}
//--------------------------------------------------------------------------------
int BSHL2D::getStep() const
{
	return m_step;
}
//--------------------------------------------------------------------------------
///׼������
void BSHL2D::_ready(int sx, int sy, int dx, int dy)
{
	m_step = 0;
	_clearOpenList();
	_clearClosedList();

	m_sx = sx;
	m_sy = sy;
	m_dx = dx;
	m_dy = dy;
	m_dfx = FMath::Abs(m_sx - m_dx);
	m_dfy = FMath::Abs(m_sy - m_dy);

	if (m_dx - m_sx != 0)
		m_slope = (float)(m_dy - m_sy) / (float)(m_dx - m_sx);
	else
		m_slope = 0.0f;

	m_pyx = 2 * m_dfy - m_dfx;
	m_twoDy = 2 * m_dfy;
	m_twoDyMinusDx = 2 * (m_dfy - m_dfx);
	m_pxy = 2 * m_dfx - m_dfy;
	m_twoDx = 2 * m_dfx;
	m_twoDxMinusDy = 2 * (m_dfx - m_dfy);

	BSHLNode2D* _node = new BSHLNode2D(sx, sy);
	if (_node == NULL)
	{
		UE_LOG(LogCWBSHL2D, Error, TEXT("BSHL2D::_ready. new CWAStarNode(sx, sy) == nullptr. sx:%d, sy:%d"), sx, sy);
		return;
	}

	_addToOpenList(_node);
}

///����
int BSHL2D::_step()
{
	m_step++;

	if ((m_curBestNode = _getBestNodeInOpenList()) == NULL)
		return -1;

	if (m_curBestNode->x == m_dx && m_curBestNode->y == m_dy)
		return 1;

	_createChildren(m_curBestNode);
	return 0;
}

///���ӽڵ㵽Open��
void BSHL2D::_addToOpenList(BSHLNode2D* addNode)
{
	if (m_open == NULL)
	{
		m_open = addNode;
		return;
	}

	BSHLNode2D* _node = m_open;
	BSHLNode2D* _prev = NULL;

	while (_node)
	{
		_prev = _node;
		_node = _node->next;
	}

	_prev->next = addNode;
}

///�õ�Open����õĽڵ�
BSHLNode2D* BSHL2D::_getBestNodeInOpenList()
{
	if (m_open == NULL)
		return NULL;

	BSHLNode2D* _temp1 = m_open;
	BSHLNode2D* _temp2 = m_closed;
	m_open = _temp1->next;
	m_closed = _temp1;
	m_closed->next = _temp2;
	return _temp1;
}

///Open�����
void BSHL2D::_clearOpenList()
{
	BSHLNode2D* _temp = NULL;
	while (m_open)
	{
		_temp = m_open->next;
		delete m_open;
		m_open = _temp;
	}
}

///Closed�����
void BSHL2D::_clearClosedList()
{
	BSHLNode2D* _temp = NULL;
	while (m_closed)
	{
		_temp = m_closed->next;
		delete m_closed;
		m_closed = _temp;
	}
}

///�����ӽڵ�
void BSHL2D::_createChildren(BSHLNode2D* p)
{
	if (m_dfx == 0 && m_dfy == 0)
		return;

	int _cx = p->x;
	int _cy = p->y;

	if (m_dfx == 0)
	{
		_cy = m_sy < m_dy ? p->y + 1 : p->y - 1;
		if (m_isValidFunc(p->x, p->y, _cx, _cy))
			_linkChild(p, _cx, _cy);
	}
	else if (m_dfy == 0)
	{
		_cx = m_sx < m_dx ? p->x + 1 : p->x - 1;
		if (m_isValidFunc(p->x, p->y, _cx, _cy))
			_linkChild(p, _cx, _cy);
	}
	else if (m_dfx == m_dfy)
	{
		if (m_sx < m_dx)
		{
			_cx = p->x + 1;
			m_sy < m_dy ? _cy = p->y + 1 : _cy = p->y - 1;
		}
		else
		{
			_cx = p->x - 1;
			m_sy < m_dy ? _cy = p->y + 1 : _cy = p->y - 1;
		}

		if (m_isValidFunc(p->x, p->y, _cx, _cy))
			_linkChild(p, _cx, _cy);
	}
	else
	{
		//��1�����°������3�����ϰ���
		if (m_slope > 0.0f && m_slope < 1.0f)
		{
			//��1�����°���
			if (p->x < m_dx)
			{
				_cx = p->x + 1;
				if (m_pyx < 0)
				{
					m_pyx += m_twoDy;
				}
				else
				{
					_cy = p->y + 1;
					m_pyx += m_twoDyMinusDx;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
			//��3�����ϰ���
			else if (p->x > m_dx)
			{
				_cx = p->x - 1;
				if (m_pyx < 0)
				{
					m_pyx += m_twoDy;
				}
				else
				{
					_cy = p->y - 1;
					m_pyx += m_twoDyMinusDx;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
		}
		//��1�����ϰ������3�����°���
		else if (m_slope > 1.0f)
		{
			//��1�����ϰ���
			if (p->y < m_dy)
			{
				_cy = p->y + 1;
				if (m_pxy < 0)
				{
					m_pxy += m_twoDx;
				}
				else
				{
					_cx = p->x + 1;
					m_pxy += m_twoDxMinusDy;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
			//��3�����°���
			else if (p->y > m_dy)
			{
				_cy = p->y - 1;
				if (m_pxy < 0)
				{
					m_pxy += m_twoDx;
				}
				else
				{
					_cx = p->x - 1;
					m_pxy += m_twoDxMinusDy;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
		}
		//��2�����°������4�����ϰ���
		else if (m_slope < 0.0f && m_slope > -1.0f)
		{
			//��4�����ϰ���
			if (p->x < m_dx)
			{
				_cx = p->x + 1;
				if (m_pyx < 0)
				{
					m_pyx += m_twoDy;
				}
				else
				{
					_cy = p->y - 1;
					m_pyx += m_twoDyMinusDx;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
			//��2�����°���
			else if (p->x > m_dx)
			{
				_cx = p->x - 1;
				if (m_pyx < 0)
				{
					m_pyx += m_twoDy;
				}
				else
				{
					_cy = p->y + 1;
					m_pyx += m_twoDyMinusDx;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
		}
		//��2�����ϰ������4�����°���
		else if (m_slope < -1.0f)
		{
			//��2�����ϰ���
			if (p->y < m_dy)
			{
				_cy = p->y + 1;
				if (m_pxy < 0)
				{
					m_pxy += m_twoDx;
				}
				else
				{
					_cx = p->x - 1;
					m_pxy += m_twoDxMinusDy;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
			//��4�����°���
			else if (p->y > m_dy)
			{
				_cy = p->y - 1;
				if (m_pxy < 0)
				{
					m_pxy += m_twoDx;
				}
				else
				{
					_cx = p->x + 1;
					m_pxy += m_twoDxMinusDy;
				}

				if (m_isValidFunc(p->x, p->y, _cx, _cy))
					_linkChild(p, _cx, _cy);
			}
		}
	}
}

///�����ӽڵ�
void BSHL2D::_linkChild(BSHLNode2D* p, int cx, int cy)
{
	BSHLNode2D* _childNode = new BSHLNode2D(cx, cy);
	if (_childNode == NULL)
	{
		UE_LOG(LogCWBSHL2D, Error, TEXT("BSHL2D::_linkChild Fail. new BSHLNode2D(cx, cy) == nullptr. cx:%d, cy:%d"), cx, cy);
		return;
	}

	_childNode->parent = p;

	_addToOpenList(_childNode);
}

