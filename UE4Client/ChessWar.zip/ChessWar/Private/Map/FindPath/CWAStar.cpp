﻿#include "CWAStar.h"
#include "Map/CWMap.h"
#include "Map/FindPath/CWAStarNode.h"
#include "Map/FindPath/CWAStarStack.h"
#include <cmath>
#include "Math/UnrealMathUtility.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWAStar, All, All);

FCWAStar::FCWAStar(ACWMap* map)
	: CWMap(map)
	, Columns(0)
	, StartPosX(0)
	, StartPosY(0)
	, DestinationPosX(0)
	, DestinationPosY(0)
	, DestinationID(-1)
	, StepCount(0)
	, OpenList(nullptr)
	, ClosedList(nullptr)
	, CurBestNode(nullptr)
	, AStarStack(nullptr)
{
}

FCWAStar::~FCWAStar()
{
	CWMap = nullptr;

	CurBestNode = nullptr;
	ClearOpenList();
	ClearClosedList();
	ClearStack();
}

bool FCWAStar::GeneratePath(int sx, int sy, int dx, int dy, int limitStep, ECWCampTag movingCampTag, FCWPawnFindPathInfo ParamFindPathInfo)
{
	CurMovingCampTag = movingCampTag;
	CurFindPathInfo = ParamFindPathInfo;
	if (!Ready(sx, sy, dx, dy))
	{
		return false;
	}

	int _ret = 0;
	while (_ret == 0)
	{
		if (StepCount >= limitStep)
			return false;

		_ret = Step();
	};

	return (_ret == -1 ? false : true);
}

void FCWAStar::SetColumnNum(int cn)
{
	Columns = cn;
}

CWAStarNode* FCWAStar::GetCurBestNode() const
{
	return CurBestNode;
}

int FCWAStar::GetStep() const
{
	return StepCount;
}

bool FCWAStar::Ready(int sx, int sy, int dx, int dy)
{
	StepCount = 0;
	CurBestNode = nullptr;
	ClearOpenList();
	ClearClosedList();
	ClearStack();

	StartPosX = sx;
	StartPosY = sy;
	DestinationPosX = dx;
	DestinationPosY = dy;
	DestinationID = Coordinate2ID(dx, dy);

	CWAStarNode* _node = new CWAStarNode(sx, sy);
	if (_node == nullptr)
	{
		UE_LOG(LogCWAStar, Error, TEXT("UCWAStar::_ready Fail. new CWAStarNode(sx, sy) == nullptr. sx:%d, sy:%d"), sx, sy);
		return false;
	}

	_node->Goal = 0;
	FVector spos = FVector::ZeroVector;
	ACWMap::xy2pos(sx, sy, spos);
	FVector dpos = FVector::ZeroVector;
	ACWMap::xy2pos(dx, dy, dpos);
	//_node->Heuristic = FMath::Abs(dx - sx) + FMath::Abs(dy - sy);
	_node->Heuristic = /*FMath::Abs*/(dpos.X - spos.X) * (dpos.X - spos.X) + /*FMath::Abs*/(dpos.Y - spos.Y) * (dpos.Y - spos.Y);
	_node->Fitness = _node->Goal + _node->Heuristic;
	_node->ID = Coordinate2ID(sx, sy);

	AddToOpenList(_node);
	return true;
}


int FCWAStar::Step()
{
	StepCount++;

	if ((CurBestNode = GetBestNodeInOpenList()) == nullptr)
		return -1;

	if (CurBestNode->ID == DestinationID)
		return 1;

	CreateChildren(CurBestNode);
	return 0;
}

void FCWAStar::AddToOpenList(CWAStarNode* addNode)
{
	if (OpenList == nullptr)
	{
		OpenList = addNode;
		return;
	}

	CWAStarNode* _node = OpenList;
	CWAStarNode* _prev = nullptr;

	while (_node)
	{
		if (addNode->Fitness > _node->Fitness)
		{
			_prev = _node;
			_node = _node->Next;
		}
		else
		{
			_prev ? _prev->Next = addNode : OpenList = addNode;
			addNode->Next = _node;
			return;
		}
	}

	_prev->Next = addNode;
}


CWAStarNode* FCWAStar::GetBestNodeInOpenList()
{
	if (OpenList == nullptr)
		return nullptr;

	CWAStarNode* _temp1 = OpenList;
	CWAStarNode* _temp2 = ClosedList;
	OpenList = _temp1->Next;
	ClosedList = _temp1;
	ClosedList->Next = _temp2;
	return _temp1;
}

CWAStarNode* FCWAStar::FindNodeInOpenList(int id) const
{
	CWAStarNode* _node = OpenList;
	while (_node)
	{
		if (_node->ID == id)
			return _node;

		_node = _node->Next;
	}

	return nullptr;
}

void FCWAStar::ClearOpenList()
{
	CWAStarNode* _temp = nullptr;
	while (OpenList)
	{
		_temp = OpenList->Next;
		delete OpenList;
		OpenList = _temp;
	}
}


CWAStarNode* FCWAStar::FindNodeInClosedList(int id) const
{
	CWAStarNode* _node = ClosedList;
	while (_node)
	{
		if (_node->ID == id)
			return _node;

		_node = _node->Next;
	}

	return nullptr;
}

void FCWAStar::ClearClosedList()
{
	CWAStarNode* _temp = nullptr;
	while (ClosedList)
	{
		_temp = ClosedList->Next;
		delete ClosedList;
		ClosedList = _temp;
	}
}

void FCWAStar::CreateChildren(CWAStarNode* p)
{
	int _cx;
	int _cy;

	for (int i = -1; i < 2; ++i)
	{
		for (int j = -1; j < 2; ++j)
		{
			FVector cpos = FVector::ZeroVector;
			ACWMap::xy2pos(p->X, p->Y, cpos);
			cpos.X += i * CWMap->getGridWidth();
			cpos.Y += j * CWMap->getGridHeight();

			ACWMap::pos2xy(cpos, _cx, _cy);
			//_cx = p->X + i;
			//_cy = p->Y + j;

			if ((i == 0 && j == 0) ||		//排除自己
				!CWMap->canPassIncludeEnemy(_cx, _cy, CurMovingCampTag))	//是否有效
			{
				continue;
			}

			//if ((i == -1 && j == -1) || 
			//	(i == 1 && j == -1) || 
			//	(i == -1 && j == 1) ||
			//	(i == 1 && j == 1))
			//{
			//	continue;
			//}

			if (i == -1 && j == -1)
			{
				int i1 = i;
				int j1 = j + 1;
				FVector pos1 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos1);
				pos1.X += i1 * CWMap->getGridWidth();
				pos1.Y += j1 * CWMap->getGridHeight();
				int _x1;
				int _y1;
				ACWMap::pos2xy(pos1, _x1, _y1);

				int i2 = i + 1;
				int j2 = j;
				FVector pos2 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos2);
				pos2.X += i2 * CWMap->getGridWidth();
				pos2.Y += j2 * CWMap->getGridHeight();
				int _x2;
				int _y2;
				ACWMap::pos2xy(pos2, _x2, _y2);

				if (!CWMap->canPassIncludeEnemy(_x1, _y1, CurMovingCampTag) ||
					!CWMap->canPassIncludeEnemy(_x2, _y2, CurMovingCampTag))
				{
					continue;
				}

				if (!CWMap->IsSameZ(_cx, _cy, _x1, _y1) ||
					!CWMap->IsSameZ(_cx, _cy, _x2, _y2) ||
					!CWMap->IsSameZ(p->X, p->Y, _x1, _y1) ||
					!CWMap->IsSameZ(p->X, p->Y, _x2, _y2))
				{
					continue;
				}
			}

			if (i == 1 && j == -1)
			{
				int i1 = i;
				int j1 = j + 1;
				FVector pos1 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos1);
				pos1.X += i1 * CWMap->getGridWidth();
				pos1.Y += j1 * CWMap->getGridHeight();
				int _x1;
				int _y1;
				ACWMap::pos2xy(pos1, _x1, _y1);

				int i2 = i - 1;
				int j2 = j;
				FVector pos2 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos2);
				pos2.X += i2 * CWMap->getGridWidth();
				pos2.Y += j2 * CWMap->getGridHeight();
				int _x2;
				int _y2;
				ACWMap::pos2xy(pos2, _x2, _y2);

				if (!CWMap->canPassIncludeEnemy(_x1, _y1, CurMovingCampTag) ||
					!CWMap->canPassIncludeEnemy(_x2, _y2, CurMovingCampTag))
				{
					continue;
				}

				if (!CWMap->IsSameZ(_cx, _cy, _x1, _y1) ||
					!CWMap->IsSameZ(_cx, _cy, _x2, _y2) ||
					!CWMap->IsSameZ(p->X, p->Y, _x1, _y1) ||
					!CWMap->IsSameZ(p->X, p->Y, _x2, _y2))
				{
					continue;
				}
			}

			if (i == -1 && j == 1)
			{
				int i1 = i;
				int j1 = j - 1;
				FVector pos1 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos1);
				pos1.X += i1 * CWMap->getGridWidth();
				pos1.Y += j1 * CWMap->getGridHeight();
				int _x1;
				int _y1;
				ACWMap::pos2xy(pos1, _x1, _y1);

				int i2 = i + 1;
				int j2 = j;
				FVector pos2 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos2);
				pos2.X += i2 * CWMap->getGridWidth();
				pos2.Y += j2 * CWMap->getGridHeight();
				int _x2;
				int _y2;
				ACWMap::pos2xy(pos2, _x2, _y2);

				if (!CWMap->canPassIncludeEnemy(_x1, _y1, CurMovingCampTag) ||
					!CWMap->canPassIncludeEnemy(_x2, _y2, CurMovingCampTag))
				{
					continue;
				}

				if (!CWMap->IsSameZ(_cx, _cy, _x1, _y1) ||
					!CWMap->IsSameZ(_cx, _cy, _x2, _y2) ||
					!CWMap->IsSameZ(p->X, p->Y, _x1, _y1) ||
					!CWMap->IsSameZ(p->X, p->Y, _x2, _y2))
				{
					continue;
				}
			}

			if (i == 1 && j == 1)
			{
				int i1 = i;
				int j1 = j - 1;
				FVector pos1 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos1);
				pos1.X += i1 * CWMap->getGridWidth();
				pos1.Y += j1 * CWMap->getGridHeight();
				int _x1;
				int _y1;
				ACWMap::pos2xy(pos1, _x1, _y1);

				int i2 = i - 1;
				int j2 = j;
				FVector pos2 = FVector::ZeroVector;
				ACWMap::xy2pos(p->X, p->Y, pos2);
				pos2.X += i2 * CWMap->getGridWidth();
				pos2.Y += j2 * CWMap->getGridHeight();
				int _x2;
				int _y2;
				ACWMap::pos2xy(pos2, _x2, _y2);

				if (!CWMap->canPassIncludeEnemy(_x1, _y1, CurMovingCampTag) ||
					!CWMap->canPassIncludeEnemy(_x2, _y2, CurMovingCampTag))
				{
					continue;
				}

				if (!CWMap->IsSameZ(_cx, _cy, _x1, _y1) ||
					!CWMap->IsSameZ(_cx, _cy, _x2, _y2) ||
					!CWMap->IsSameZ(p->X, p->Y, _x1, _y1) ||
					!CWMap->IsSameZ(p->X, p->Y, _x2, _y2))
				{
					continue;
				}
			}

			if (_cx < 0)
				continue;

			if (_cx >= CWMap->getWidth())
				continue;

			if (_cy < 0)
				continue;

			if (_cy >= CWMap->getHeight())
				continue;

			int c = CWMap->cost(p->X, p->Y, _cx, _cy, CurFindPathInfo);
			if (c == 0x7fffffff)
				continue;

			LinkChild(p, _cx, _cy);
		}
	}
}

bool FCWAStar::LinkChild(CWAStarNode* p, int cx, int cy)
{
	int c = CWMap->cost(p->X, p->Y, cx, cy, CurFindPathInfo);
	if (c == 0x7fffffff)
		return false;

	int _cg = p->Goal + c;
	int _cid = Coordinate2ID(cx, cy);

	CWAStarNode* _checkNode;
	if ((_checkNode = FindNodeInOpenList(_cid)) != nullptr)
	{
		p->Children[p->ChildrenCount++] = _checkNode;

		if (_cg < _checkNode->Goal)
		{
			_checkNode->Parent = p;
			_checkNode->Goal = _cg;
			_checkNode->Fitness = _cg + _checkNode->Heuristic;
		}
	}
	else if ((_checkNode = FindNodeInClosedList(_cid)) != nullptr)
	{
		p->Children[p->ChildrenCount++] = _checkNode;

		if (_cg < _checkNode->Goal)
		{
			_checkNode->Parent = p;
			_checkNode->Goal = _cg;
			_checkNode->Fitness = _cg + _checkNode->Heuristic;

			UpdateParents(_checkNode);
		}
	}
	else
	{
		int maxWidhtOrHight = FMath::Max(CWMap->getWidth(), CWMap->getHeight());
		check(cx >= 0);
		check(cx < maxWidhtOrHight);
		check(cy >= 0);
		check(cy < maxWidhtOrHight);
		CWAStarNode* _childNode = new CWAStarNode(cx, cy);
		if (_childNode == nullptr)
		{
			UE_LOG(LogCWAStar, Error, TEXT("UCWAStar::LinkChild Fail. new CWAStarNode(sx, sy) == nullptr. px:%d, py:%d, cx:%d, cy:%d"), p->X, p->Y, cx, cy);
			return false;
		}

		_childNode->Parent = p;
		_childNode->Goal = _cg;
		FVector cpos = FVector::ZeroVector;
		ACWMap::xy2pos(cx, cy, cpos);
		FVector dpos = FVector::ZeroVector;
		ACWMap::xy2pos(DestinationPosX, DestinationPosY, dpos);
		_childNode->Heuristic = /*FMath::Abs*/(cpos.X - dpos.X) * (cpos.X - dpos.X) + /*FMath::Abs*/(cpos.Y - dpos.Y) * (cpos.Y - dpos.Y);
		_childNode->Fitness = _cg + _childNode->Heuristic;
		_childNode->ID = _cid;

		p->Children[p->ChildrenCount++] = _childNode;

		AddToOpenList(_childNode);
	}

	return true;
}

void FCWAStar::UpdateParents(CWAStarNode* p)
{
	CWAStarNode* _kid = nullptr;
	for (int i = 0; i < p->ChildrenCount; ++i)
	{
		_kid = p->Children[i];
		if (p->Goal + 1 < _kid->Goal)
		{
			_kid->Parent = p;
			_kid->Goal = p->Goal + 1;
			_kid->Fitness = _kid->Goal + _kid->Heuristic;

			Push(_kid);
		}
	}

	CWAStarNode* _parent;
	while (AStarStack)
	{
		_parent = Pop();
		for (int i = 0; i < _parent->ChildrenCount; ++i)
		{
			_kid = _parent->Children[i];
			if (_parent->Goal + 1 < _kid->Goal)
			{
				_kid->Parent = _parent;
				int c = CWMap->cost(_parent->X, _parent->Y, _kid->X, _kid->Y, CurFindPathInfo);
				if (c != 0x7fffffff)
				{
					_kid->Goal = _parent->Goal + c;
					_kid->Fitness = _kid->Goal + _kid->Heuristic;

					Push(_kid);
				}
			}
		}
	}
}

bool FCWAStar::Push(CWAStarNode* node)
{
	CWAStarStack* _temp = new CWAStarStack();
	if (_temp == nullptr)
	{
		UE_LOG(LogCWAStar, Error, TEXT("UCWAStar::_push Fail. new CWAStarStack() == nullptr. nx:%d, ny:%d"), node->X, node->Y);
		return false;
	}

	if (AStarStack == nullptr)
	{
		AStarStack = _temp;
		AStarStack->data = node;
		AStarStack->next = nullptr;
	}
	else
	{
		_temp->data = node;
		_temp->next = AStarStack;
		AStarStack = _temp;
	}

	return true;
}

CWAStarNode* FCWAStar::Pop()
{
	CWAStarNode* _data = AStarStack->data;
	CWAStarStack* _temp = AStarStack;

	AStarStack = _temp->next;
	delete _temp;
	return _data;
}

void FCWAStar::ClearStack()
{
	while (AStarStack)
	{
		CWAStarStack* _temp = AStarStack;
		AStarStack = _temp->next;
		delete _temp;
	}
}

int FCWAStar::Coordinate2ID(int x, int y)
{
	return x * Columns + y;
}