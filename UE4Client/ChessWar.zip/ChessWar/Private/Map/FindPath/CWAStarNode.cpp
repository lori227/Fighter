﻿#include "CWAStarNode.h"

CWAStarNode::CWAStarNode(int _x, int _y)
: Fitness(0)
, Goal(0)
, Heuristic(0)
, X(_x)
, Y(_y)
, ID(-1)
, Parent(nullptr)
, ChildrenCount(0)
, Next(nullptr)
{
	memset(Children, 0, sizeof(Children));
}