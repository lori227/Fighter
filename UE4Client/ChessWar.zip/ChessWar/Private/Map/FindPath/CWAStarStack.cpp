#include "CWAStarStack.h"

CWAStarStack::CWAStarStack()
:data(nullptr)
,next(nullptr)
{
}