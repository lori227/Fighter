#include "CWPEGrid.h"
#include "Math/Vector.h"
#include "Math/UnrealMathUtility.h"
#include "Map/CWMap.h"


CWPEGrid::CWPEGrid()
:x(-1)
,y(-1)
,pos(0.0f, 0.0f, 0.0f)
{

}

CWPEGrid::CWPEGrid(int _x, int _y)
:x(_x)
,y(_y)
{
	ACWMap::xy2pos(x, y, pos);
	tile = ACWMap::xy2tile(x, y);
}

CWPEGrid::CWPEGrid(int _tile)
:tile(_tile)
{
	ACWMap::tile2xy(tile, x, y);
	ACWMap::xy2pos(x, y, pos);
}

CWPEGrid::CWPEGrid(const FVector& _pos)
:pos(_pos)
{
	ACWMap::pos2xy(pos, x, y);
	tile = ACWMap::xy2tile(x, y);
	pos.Z = 0.0f;
}

CWPEGrid::CWPEGrid(const CWPEGrid& rhs)
{
	operator=(rhs);
}

CWPEGrid& CWPEGrid::operator=(const CWPEGrid& rhs)
{
	if (this == &rhs)
		return *this;

	x = rhs.x;
	y = rhs.y;
	tile = rhs.tile;
	pos = rhs.pos;

	return *this;
}


bool CWPEGrid::operator==(const CWPEGrid& rhs) const
{
	if (tile == rhs.tile && x == rhs.x && y == rhs.y)
	{
		if (FMath::Abs(pos.X - rhs.pos.X) < 0.0000001f && FMath::Abs(pos.Y - rhs.pos.Y) < 0.0000001f)
		{
			return true;
		}
	}

	return false;
}

bool CWPEGrid::operator!=(const CWPEGrid& rhs) const
{
	return !(*this == rhs);
}