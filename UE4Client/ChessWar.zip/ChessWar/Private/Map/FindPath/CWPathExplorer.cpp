﻿#include "CWPathExplorer.h"
#include "CWPEGrid.h"
#include "Math/Vector.h"
#include "Math/UnrealMathUtility.h"

//UCWPathExplorer::UCWPathExplorer(const FObjectInitializer& ObjectInitializer)
//	:Super(ObjectInitializer)
//{
//
//}



FCWPathExplorer::FCWPathExplorer()
	:CurrGrid(FVector((float)UINT_MAX, (float)UINT_MAX, 0.0f))
	,DestGrid(CurrGrid)
	,bNoObstacle(false)
	,bArrived(false)
	,Path()
{
}



FCWPathExplorer::~FCWPathExplorer()
{
	Path.clear();
}


void FCWPathExplorer::Reset()
{
	DestGrid = CurrGrid;
	bArrived = false;
	Path.clear();
}

const FVector& FCWPathExplorer::GetPos() const
{
	return CurrGrid.pos;
}

const CWPEGrid& FCWPathExplorer::GetGrid() const
{
	return CurrGrid;
}

void FCWPathExplorer::SetPos(const FVector& pos)
{
	CurrGrid = CWPEGrid(pos);
}


const FVector& FCWPathExplorer::GetDestPos() const
{
	return DestGrid.pos;
}

const CWPEGrid& FCWPathExplorer::GetDestGrid() const
{
	return DestGrid;
}

void FCWPathExplorer::SetDestPos(const FVector& pos)
{
	DestGrid = CWPEGrid(pos);
}

bool FCWPathExplorer::IsNoObstacle() const
{
	return bNoObstacle;
}

void FCWPathExplorer::SetNoObstacle(bool isNo)
{
	bNoObstacle = isNo;
}

bool FCWPathExplorer::IsArrived() const
{
	return bArrived;
}

void FCWPathExplorer::SetArrived(bool paramIsArrived)
{
	bArrived = paramIsArrived;
}

std::list<CWPEGrid>& FCWPathExplorer::GetPath()
{
	return Path;
}