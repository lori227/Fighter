#include "CWArrowRender.h"
#include "CWMap.h"
#include "Engine.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWArrowRender, All, All);

ACWArrowRender::ACWArrowRender(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = false;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SetRootComponent(SceneComponent);

	StaticMesh = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, "StaticMesh");
	StaticMesh->SetupAttachment(SceneComponent);
	//StaticMesh->SetEnableGravity(false);
}

void ACWArrowRender::SetParentMap(ACWMap* ParamMap)
{
	ParentMap = ParamMap;
}

ACWMap* ACWArrowRender::GetParentMap()
{
	return ParentMap;
}
