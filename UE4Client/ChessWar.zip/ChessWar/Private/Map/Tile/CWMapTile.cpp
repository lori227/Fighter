﻿
#include "CWMapTile.h"

#include "Engine/StaticMesh.h"
#include "Components/BoxComponent.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWFuncLib.h"
#include "CWCfgManager.h"
#include "CWGameState.h"
#include "CWPawnStart.h"
#include "CWGameInstance.h"
#include "CWDungeonItem.h"
#include "CWDungeonTile.h"
#include "CWMapTileRender.h"
#include "CWFSMTranstion.h"
#include "CWMapTileInputFSM.h"
#include "CWPlayerController.h"
#include "CWRandomDungeonGenerator.h"
#include "CWMapTileInputWaitingState.h"
#include "CWMapTileInputSelectedState.h"
#include "CWMapTileInputSelectedEvent.h"
#include "CWMapTileInputCancelSelectedEvent.h"
#include "CWDungeonItemGroup.h"
#include "CWDungeonItemVisibility.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWMapTile, All, All);


ACWMapTile::ACWMapTile(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = false;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	CursorOverMeshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CursorOverMesh"));
	CursorOverMeshComp->SetupAttachment(RootComponent);
	CursorOverMeshComp->SetRelativeLocation(FVector(0.0f, 0.0f, -0.85f));
	//CursorOverMeshComp->SetWorldScale3D(FVector(0.273f, 0.273f, 0.273f));
	CursorOverMeshComp->SetEnableGravity(false);

	WarningMeshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WarningMesh"));
	WarningMeshComp->SetupAttachment(RootComponent);
	WarningMeshComp->SetRelativeLocation(FVector(0.0f, 0.0f, -0.5f));
	//WarningMeshComp->SetWorldScale3D(FVector(0.273f, 0.273f, 0.273f));
	WarningMeshComp->SetEnableGravity(false);

	FloorMeshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FloorMesh"));
	FloorMeshComp->SetupAttachment(RootComponent);
	//FloorMeshComp->SetWorldScale3D(FVector(0.273f, 0.273f, 0.273f));
	FloorMeshComp->SetEnableGravity(false);

	CursorOverParticle = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("CursorOverParticle"));
	CursorOverParticle->SetupAttachment(RootComponent);
	CursorOverParticle->SetRelativeLocation(FVector(0.f, 0.f, 160.f));
	CursorOverParticle->SetWorldScale3D(FVector(3.5f, 3.5f, 3.5f));
	CursorOverParticle->SetEnableGravity(false);

	WarningParticle = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("WarningParticle"));
	WarningParticle->SetupAttachment(RootComponent);
	WarningParticle->SetRelativeLocation(FVector(0.f, 0.f, 160.f));
	WarningParticle->SetWorldScale3D(FVector(3.5f, 3.5f, 3.5f));
	WarningParticle->SetEnableGravity(false);

	FloorParticle = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("FloorParticle"));
	FloorParticle->SetupAttachment(RootComponent);
	FloorParticle->SetRelativeLocation(FVector(0.f, 0.f, 160.f));
	FloorParticle->SetWorldScale3D(FVector(3.5f, 3.5f, 3.5f));
	FloorParticle->SetEnableGravity(false);

	ToggleBoxComp = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxComponent"));
	ToggleBoxComp->SetupAttachment(RootComponent);
	//ToggleBoxComp->SetWorldScale3D(FVector(0.273f, 0.273f, 0.273f));
	ToggleBoxComp->SetEnableGravity(false);
	ToggleBoxComp->bVisible = true;
	ToggleBoxComp->bHiddenInGame = true;
}

void ACWMapTile::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	
	DOREPLIFETIME(ACWMapTile, Tile);
}

void ACWMapTile::NotifyActorBeginCursorOver()
{
	Super::NotifyActorBeginCursorOver();

	//UE_LOG(LogCWMapTile, Log, TEXT("ACWMapTile::NotifyActorBeginCursorOver. Tile:%d."), Tile);

	BeginCursorOver();
}

void ACWMapTile::NotifyActorEndCursorOver()
{
	Super::NotifyActorEndCursorOver();

	//UE_LOG(LogCWMapTile, Log, TEXT("ACWMapTile::NotifyActorEndCursorOver. Tile:%d."), Tile);

	EndCursorOver();
}

void ACWMapTile::BeginCursorOver()
{
	ACWPlayerController* TempPC = Cast<ACWPlayerController>(this->GetWorld()->GetFirstPlayerController());
	if (TempPC != nullptr)
	{
		AActor* TempLastCursorActor = TempPC->GetLastCursorActor();
		if (TempLastCursorActor != nullptr && TempLastCursorActor != this)
		{
			ACWMapTile* TempMapTile = Cast<ACWMapTile>(TempLastCursorActor);
			if (TempMapTile)
			{
				TempMapTile->EndCursorOver();
			}
		}
	}

	// 场景物件移入移出描边
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator != nullptr)
	{
		ACWDungeonItemGroup* TempItemGroup = TempDungeonGenerator->GetDungeonItemGroup(this->Tile);
		if (TempItemGroup != nullptr)
		{
			TArray<ACWDungeonItem*> TempOutArrayItem;
			if (TempItemGroup->GetAllArrayItem(TempOutArrayItem))
			{
				for (int i = 0; i < TempOutArrayItem.Num(); ++i)
				{
					ACWDungeonItem* TempDungeonItem = TempOutArrayItem[i];
					if (TempDungeonItem != nullptr)
					{
						TempDungeonItem->BeginCursorOver();
					}
				}
			}
		}
	
		/*ACWDungeonItem* TempDungeonItem = TempDungeonGenerator->GetDungeonItem(this->Tile);
		if (TempDungeonItem != nullptr)
		{
			TempDungeonItem->BeginCursorOver();
		}*/

		ACWDungeonTile* dungeonTile = TempDungeonGenerator->GetDungeonTile(this->Tile);
		if (nullptr != dungeonTile) {
			dungeonTile->BeginCursorOver();
		}
	}

	// 光标(鼠标)移入
	if (GetBattleState() >= ECWBattleState::Ready)
	{
		ResetStaticMesh(CursorOver, FTileAssetPath::Floor_CursorOver);
		ResetParticleAsset(CursorOver, FTileParticleAssetId::Particle_CursorOver);
	}

	if (TempPC != nullptr)
	{
		TempPC->SetLastCursorActor(this);
	}
}

void ACWMapTile::EndCursorOver()
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator != nullptr)
	{
		ACWDungeonItemGroup* TempItemGroup = TempDungeonGenerator->GetDungeonItemGroup(this->Tile);
		if (TempItemGroup != nullptr)
		{
			TArray<ACWDungeonItem*> TempOutArrayItem;
			if (TempItemGroup->GetAllArrayItem(TempOutArrayItem))
			{
				for (int i = 0; i < TempOutArrayItem.Num(); ++i)
				{
					ACWDungeonItem* TempDungeonItem = TempOutArrayItem[i];
					if (TempDungeonItem != nullptr)
					{
						TempDungeonItem->EndCursorOver();
					}
				}
			}
		}

		/*ACWDungeonItem* TempDungeonItem = TempDungeonGenerator->GetDungeonItem(this->Tile);
		if (TempDungeonItem != nullptr)
		{
			TempDungeonItem->EndCursorOver();
		}*/

		ACWDungeonTile* dungeonTile = TempDungeonGenerator->GetDungeonTile(this->Tile);
		if (nullptr != dungeonTile) {
			dungeonTile->EndCursorOver();
		}
	}
	// 光標移出
	if (GetBattleState() >= ECWBattleState::Ready)
	{
		ResetStaticMesh(CursorOver, STR_Empty);
		ResetParticleAsset(CursorOver, STR_Empty);
	}
}

void ACWMapTile::Destroyed()
{
	// 销毁
	if (nullptr != InputFSM)
	{
		if (InputFSM->IsRooted())
		{
			InputFSM->RemoveFromRoot();
		}
		InputFSM->ConditionalBeginDestroy();
		InputFSM = nullptr;
	}
	if (nullptr != OtherTileRender)
	{
		OtherTileRender->Destroy();
		OtherTileRender = nullptr;
	}
	if (nullptr != MapTileRenderSelectedCache)
	{
		MapTileRenderSelectedCache->Destroy();
		MapTileRenderSelectedCache = nullptr;
	}
	ListTileRenderCache.clear();
	MapMeshCache.Empty();

	Super::Destroyed();
}

bool ACWMapTile::Init()
{
	InputFSM = NewObject<UCWMapTileInputFSM>();
	check(InputFSM);
	InputFSM->AddToRoot();
	InputFSM->Init(this);
	InputFSM->AddState(new FCWMapTileInputWaitingState(InputFSM, (int)ECWMapTileInputState::WaitingInput));
	InputFSM->AddState(new FCWMapTileInputSelectedState(InputFSM, (int)ECWMapTileInputState::Selected));
	InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWMapTileInputState::WaitingInput, (int)ECWMapTileInputState::Selected));//选中
	InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWMapTileInputState::Selected, (int)ECWMapTileInputState::WaitingInput));//取消选中 回到轮到操作了

	InputFSM->Startup((int)ECWMapTileInputState::WaitingInput);
	return true;
}

void ACWMapTile::SetParantMap(ACWMap* ParamMap)
{
	ParantMap = ParamMap;
}

ACWMap* ACWMapTile::GetParantMap()
{
	return ParantMap.Get();
}

bool ACWMapTile::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWMapTile::IsMyClientMapTile() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWMapTile::IsOtherClientMapTile() const
{
	return Role == ROLE_SimulatedProxy;
}

ACWRandomDungeonGenerator* ACWMapTile::GetDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(GetWorld());
}

int32 ACWMapTile::GetTile() const
{
	return Tile;
}

void ACWMapTile::ToggleRandEvtWarn(bool bNewVisibel)
{
	if (bNewVisibel)
	{
		ShowHintTileImpl(ECWTileRenderType::RandEvtWarn);
	}
	else
	{
		ResetStaticMesh(Warn, STR_Empty);
		ResetParticleAsset(Warn, STR_Empty);
	}
}

void ACWMapTile::PrintTxtInfo(const FText& InTxt, const FColor& InClolor, const float InSize)
{
	UActorComponent* ActorComp = GetComponentByClass(UTextRenderComponent::StaticClass());
	UTextRenderComponent* TextRenderComp = Cast<UTextRenderComponent>(ActorComp);
	if (nullptr == TextRenderComp)
	{
		TextRenderComp = NewObject<UTextRenderComponent>(this);
		check(TextRenderComp);
		AddOwnedComponent(TextRenderComp);
		TextRenderComp->RegisterComponent();
		TextRenderComp->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

		TextRenderComp->SetWorldRotation(FRotator(90.f, 0.f, 0.f));
		TextRenderComp->SetRelativeLocation(FVector(0.f, 0.f, 25.f));
		TextRenderComp->SetHorizontalAlignment(EHTA_Center);
		TextRenderComp->SetVerticalAlignment(EVRTA_TextCenter);
	}
	TextRenderComp->SetWorldSize(InSize);
	TextRenderComp->SetTextRenderColor(InClolor);
	TextRenderComp->SetText(/*FSTRING_TO_FTEXT*/(InTxt));
}

UCWMapTileInputFSM* ACWMapTile::GetInputFSM()
{
	return InputFSM;
}

ECWMapTileInputState ACWMapTile::GetCurInputFSMStateId()
{
	check(InputFSM);
	return (ECWMapTileInputState)(InputFSM->GetCurrentStateId());
}

ACWMapTileRender* ACWMapTile::ShowHintTile(ECWTileRenderType ParamTileRenderType, ACWPawn* ParamPawn)
{
	//check(ParamPawn);
	ShowHintTileImpl(ParamTileRenderType, ParamPawn);

	ACWMapTileRender* OutMapTileRender = nullptr;
	if (ListTileRenderCache.empty())
	{
		OutMapTileRender = CreateMapTileRender(ParamTileRenderType, ParamPawn);
	}
	else
	{
		OutMapTileRender = ListTileRenderCache.front();
		ListTileRenderCache.pop_front();
		check(OutMapTileRender);
		OutMapTileRender->SetParentPawn(ParamPawn);
		OutMapTileRender->SetTileRenderType(ParamTileRenderType);
	}

	return OutMapTileRender;
}

void ACWMapTile::HideHintTile(ACWMapTileRender* ParamMapTileRender, ACWPawn* ParamPawn)
{
	check(ParamMapTileRender);
	ParamMapTileRender->SetTileRenderType(ECWTileRenderType::None);
	//ParamMapTileRender->StaticMesh->bHiddenInGame = true;

	bool isFind = false;
	for (std::list<ACWMapTileRender*>::iterator iter = ListTileRenderCache.begin(); iter != ListTileRenderCache.end(); ++iter)
	{
		if (ParamMapTileRender == *iter)
		{
			isFind = true;
			break;
		}
	}
	if (!isFind)
	{
		ListTileRenderCache.push_back(ParamMapTileRender);
	}

	ShowOtherHintTile(ECWTileRenderType::None);
	ShowHintTileImpl(ECWTileRenderType::None);
}

void ACWMapTile::ShowOtherHintTile(const ECWTileRenderType InRenderType, ACWPawn* InOpPawn)
{
	if (InRenderType == ECWTileRenderType::None)
	{
		if (nullptr != OtherTileRender)
		{
			OtherTileRender->SetTileRenderType(ECWTileRenderType::None);
		}
	}
	else if (nullptr != OtherTileRender)
	{
		OtherTileRender->SetParentPawn(InOpPawn);
		OtherTileRender->SetTileRenderType(InRenderType);
	}
	else
	{
		OtherTileRender = CreateMapTileRender(InRenderType, InOpPawn);
	}
}

void ACWMapTile::SelectedInClient(ACWPlayerController* ParamPlayerController)
{
	FCWMapTileInputSelectedEvent* SelectedEvent = new FCWMapTileInputSelectedEvent((int)ECWMapTileInputEvent::Selected, (int)ECWMapTileInputState::Selected, ECWFSMStackOp::Set);
	this->GetInputFSM()->DoEvent(SelectedEvent);

	//--------------------------------------------------
	if (nullptr == MapTileRenderSelectedCache)
	{
		MapTileRenderSelectedCache = CreateMapTileRender(ECWTileRenderType::Selected);
	}
	else
	{
		MapTileRenderSelectedCache->SetTileRenderType(ECWTileRenderType::Selected);
	}

	//--------------------------------------------------
	ShowHintTileImpl(ECWTileRenderType::Selected);
}

void ACWMapTile::FallWarningInClient()
{
	ShowHintTileImpl(ECWTileRenderType::FallWarning);
}

void ACWMapTile::HideFallWarningInClient()
{
	ResetStaticMesh(Warn, STR_Empty);
	ResetParticleAsset(Warn, STR_Empty);
}

void ACWMapTile::CancelSelectedInClient()
{
	FCWMapTileInputCancelSelectedEvent* CancelSelectedEvent = new FCWMapTileInputCancelSelectedEvent((int)ECWMapTileInputEvent::CancelSelected, (int)ECWMapTileInputState::WaitingInput, ECWFSMStackOp::Set);
	this->GetInputFSM()->DoEvent(CancelSelectedEvent);

	//--------------------------------------------------
	if (MapTileRenderSelectedCache != nullptr)
	{
		MapTileRenderSelectedCache->SetTileRenderType(ECWTileRenderType::None);
	}
	//--------------------------------------------------

	ShowOtherHintTile(ECWTileRenderType::None);
	ShowHintTileImpl(ECWTileRenderType::None);
}

bool ACWMapTile::IsThereEnemyInAttackTile(ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	check(ParantMap.Get());
	for (std::list<ACWMapTileRender*>::const_iterator iter = ListTileRenderCache.begin(); iter != ListTileRenderCache.end(); ++iter)
	{
		ACWMapTileRender* MyTileRender = *iter;
		check(MyTileRender);
		if (MyTileRender->GetParentPawn() == ParamPawn && MyTileRender->GetTileRenderType() == ECWTileRenderType::Attack)
		{
			return ParantMap->isThereEnemy(this->Tile, ParamPawn->GetCampTag());
		}
	}

	return false;
}

ECWBattleState ACWMapTile::GetBattleState() const
{
	if (ACWGameState* GameState = Cast<ACWGameState>(GetWorld()->GetGameState()))
	{
		return GameState->GetCurBattleState();
	}
	return ECWBattleState::None;
}

bool ACWMapTile::IsSameCampAndCtrlInReady() const
{
	const ECWBattleState BattleState = GetBattleState();
	if (BattleState != ECWBattleState::Ready)
	{
		return false;
	}

	const ACWPawn* TilePawn = ParantMap.IsValid() ? ParantMap->GetPawnByTile(Tile).Get() : nullptr;
	if (nullptr != TilePawn && TilePawn->IsMyClientPawn())
	{
		return true;
	}

	const ACWPawnStart* PawnStart = ParantMap.IsValid() ? ParantMap->GetPawnStartByTile(Tile) : nullptr;
	if (nullptr != PawnStart && PawnStart->IsLocalPCPawnStart())
	{
		return true;
	}

	return false;
}

void ACWMapTile::ShowHintTileImpl(const ECWTileRenderType& InTileRenderType, ACWPawn* InPawn)
{
	if (IsSameCampAndCtrlInReady())
	{
		ResetStaticMesh(Floor, FTileAssetPath::Floor_SwitchInReady);
		ResetParticleAsset(Floor, FTileParticleAssetId::Particle_SwitchInReady);
		return;
	}

	switch (InTileRenderType)
	{
	case ECWTileRenderType::None:
	{
		ResetStaticMesh(Floor, STR_Empty);
		ResetParticleAsset(Floor, STR_Empty);
	}break;
	case ECWTileRenderType::Foundation:
	{
		ResetStaticMesh(Floor, FTileAssetPath::Floor_MoveRange);
	}break;
	case ECWTileRenderType::Move:
	{
		bool bCanAction = IsValidActor(InPawn) ? InPawn->IsCanAction() : false;
		ResetStaticMesh(Floor, bCanAction ? FTileAssetPath::Floor_MoveTarget : FTileAssetPath::Floor_MoveRange);
		ResetParticleAsset(Floor, STR_Empty);
	}break;
	case ECWTileRenderType::Attack:
	{
		bool bHasEnemy = ParantMap.IsValid() && IsValidActor(InPawn) ? ParantMap->isThereEnemy(Tile, InPawn->GetCampTag()) : false;
		ResetStaticMesh(Floor, bHasEnemy ? FTileAssetPath::Floor_AttackTarget : FTileAssetPath::Floor_AttackRange);
		ResetParticleAsset(Floor, bHasEnemy ? FTileParticleAssetId::Particle_AttackTarget : STR_Empty);
	}break;
	case ECWTileRenderType::Selected:
	{
		ResetStaticMesh(Floor, STR_Empty);
		ResetParticleAsset(Floor, STR_Empty);
	}break;
	case ECWTileRenderType::Support:
	{
		bool bCanSupport = false;
		ResetStaticMesh(Floor, bCanSupport ? FTileAssetPath::Floor_SupportTarget : FTileAssetPath::Floor_SupportRange);
		ResetParticleAsset(Floor, FTileParticleAssetId::Particle_Support);
	}break;
	case ECWTileRenderType::SwitchInReady:
	{
		ResetStaticMesh(Floor, FTileAssetPath::Floor_SwitchInReady);
		ResetParticleAsset(Floor, FTileParticleAssetId::Particle_SwitchInReady);
	}break;
	case ECWTileRenderType::RandEvtWarn:
	{
		ResetStaticMesh(Warn, FTileAssetPath::Floor_WarnRandEvt);
		ResetParticleAsset(Warn, FTileParticleAssetId::Particle_WarnRandEvt);
	}break;
	case ECWTileRenderType::FallWarning:
	{
		ResetStaticMesh(Warn, FTileAssetPath::Floor_WarnFall);
		ResetParticleAsset(Warn, FTileParticleAssetId::Particle_WarnFall);
	}break;
	default:
	{
		CWG_WARNING(">>> %s::ShowHintTile_Internal, InTileRenderType is not find !", *GetName());
	}break;
	}
}

ACWMapTileRender* ACWMapTile::CreateMapTileRender(const ECWTileRenderType& InTileRenderType, ACWPawn* InPawn)
{
	UClass* MapTileRenderClass = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_TileRender);
	if (nullptr != MapTileRenderClass)
	{
		const FVector& NewLoc = GetActorLocation();
		ACWMapTileRender* MyMapTileRender = GetWorld()->SpawnActor<ACWMapTileRender>(
			MapTileRenderClass, FVector(NewLoc.X, NewLoc.Y, NewLoc.Z + 4.0f), FRotator::ZeroRotator);
		if (nullptr != MyMapTileRender)
		{
			MyMapTileRender->Tile = this->Tile;
			MyMapTileRender->SetParantTile(this);
			MyMapTileRender->SetParentPawn(InPawn);
			MyMapTileRender->SetTileRenderType(InTileRenderType);
			MyMapTileRender->StaticMesh->bHiddenInGame = false;
			return MyMapTileRender;
		}
	}
	return nullptr;
}

void ACWMapTile::ResetStaticMesh(ECWTileHierarchy TileHierarchy, const FString& InMeshPath)
{
	UStaticMesh* NewMesh = nullptr;
	if (!InMeshPath.IsEmpty())
	{
		NewMesh = MapMeshCache.FindRef(InMeshPath);
		if (nullptr == NewMesh)
		{
			UStaticMesh* NewCreateMesh = FCWCfgUtils::GetAssetObject<UStaticMesh>(this, InMeshPath);
			if (nullptr != NewCreateMesh)
			{
				NewMesh = NewCreateMesh;
				MapMeshCache.Add(InMeshPath, NewCreateMesh);
			}
		}
	}

	UStaticMeshComponent* OpStaticMeshComp = nullptr;
	switch (TileHierarchy)
	{
	case CursorOver:	{ OpStaticMeshComp = CursorOverMeshComp; } break;
	case Warn:			{ OpStaticMeshComp = WarningMeshComp; } break;
	case Floor:			{ OpStaticMeshComp = FloorMeshComp; } break;
	}
	if (nullptr != OpStaticMeshComp)
	{
		OpStaticMeshComp->SetStaticMesh(NewMesh);
	}
}

void ACWMapTile::ResetParticleAsset(ECWTileHierarchy InTileHierarchy /*= Floor*/, const FString& InAssetId /*= STR_Empty*/)
{
	UParticleSystem* NewParticle = nullptr;
	if (!InAssetId.IsEmpty())
	{
		NewParticle = MapParticleCache.FindRef(InAssetId);
		if (nullptr == NewParticle)
		{
			UParticleSystem* NewCreateParticle = FCWCfgUtils::GetAssetObject<UParticleSystem>(this, InAssetId);
			if (nullptr != NewCreateParticle)
			{
				NewParticle = NewCreateParticle;
				MapParticleCache.Add(InAssetId, NewCreateParticle);
			}
		}
	}

	UParticleSystemComponent* OpParticleComp = nullptr;
	switch (InTileHierarchy)
	{
	case CursorOver:	{ OpParticleComp = CursorOverParticle; } break;
	case Warn:			{ OpParticleComp = WarningParticle; } break;
	case Floor:			{ OpParticleComp = FloorParticle; } break;
	}
	if (nullptr != OpParticleComp)
	{
		OpParticleComp->SetTemplate(NewParticle);
		//OpParticleComp->SetActive((NewParticle != nullptr)/*, true*/);
		if (nullptr != NewParticle)
		{
			OpParticleComp->ActivateSystem(false);
		}
		else
		{
			OpParticleComp->DeactivateSystem();
		}
	}
}
