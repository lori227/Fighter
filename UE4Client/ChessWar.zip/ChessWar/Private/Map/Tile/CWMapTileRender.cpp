﻿
#include "CWMapTileRender.h"

#include "Engine.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWCfgUtils.h"
#include "CWCfgManager.h"
#include "CWAssetDefine.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWMapTileRender, All, All);

ACWMapTileRender::ACWMapTileRender(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = false;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	StaticMesh = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, "StaticMesh");
	StaticMesh->SetupAttachment(RootComponent);

	ParticleComp = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleComp"));
	ParticleComp->SetupAttachment(RootComponent);
	ParticleComp->SetRelativeLocation(FVector(0.f, 0.f, 160.f));
	ParticleComp->SetWorldScale3D(FVector(3.5f, 3.5f, 3.5f));
	ParticleComp->SetEnableGravity(false);
}

void ACWMapTileRender::SetTileRenderType(ECWTileRenderType ParamTileRenderType)
{
	if (TileRenderType != ParamTileRenderType)
	{
		TileRenderType = ParamTileRenderType;
		SetTileRenderTypeImpl(TileRenderType);
	}
}

ECWTileRenderType ACWMapTileRender::GetTileRenderType()
{
	return TileRenderType;
}

void ACWMapTileRender::SetParantTile(ACWMapTile* ParamTile)
{
	ParantTile = ParamTile;
}

ACWMapTile* ACWMapTileRender::GetParantTile()
{
	return ParantTile;
}

void ACWMapTileRender::SetParentPawn(ACWPawn* ParamPawn)
{
	ParentPawn = ParamPawn;
}

ACWPawn* ACWMapTileRender::GetParentPawn()
{
	return ParentPawn;
}

void ACWMapTileRender::SetTileRenderTypeImpl(const ECWTileRenderType& InRenderType)
{
	switch (InRenderType)
	{
	case ECWTileRenderType::None:
	{
		ResetStaticMesh(STR_Empty);
		ResetParticleAsset(STR_Empty);
	}break;
	case ECWTileRenderType::Move:
		//MeshName = FTileAssetPath::Mesh_Move;
		break;
	case ECWTileRenderType::Attack:
		//MeshName = FTileAssetPath::Mesh_Attack;
		break;
	case ECWTileRenderType::Selected:
	{
		ACWMap* MainMap = ParantTile->GetParantMap();
		ACWPawn* OpPawn = ParentPawn;
		ACWPawn* CurTilePawn = (MainMap) ? MainMap->GetPawnByTile(ParantTile->Tile).Get() : nullptr;
		if (nullptr != OpPawn && nullptr != CurTilePawn && OpPawn != CurTilePawn)
		{
			if (UCWFuncLib::IsEnemy(OpPawn, CurTilePawn))
			{
				/*uint8 TempMoveAttackDamage = 0x00;
				TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
				TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
				bool bCanAttack = OpPawn->IsAttackTileFromTile(OpPawn->GetTile(), CurTilePawn->GetTile(), TempMoveAttackDamage);
				ResetStaticMesh(bCanAttack ? FTileAssetPath::Render_Attack : FTileAssetPath::Render_SelectNormal);
				ResetParticleAsset(bCanAttack ? FTileParticleAssetId::Particle_AttackTarget : FTileParticleAssetId::Particle_Selected);*/
				ResetStaticMesh(FTileAssetPath::Render_SelectAttackTarget);
				ResetParticleAsset(FTileParticleAssetId::Particle_SelectedAttackTarget);
			}
			else
			{
				ResetStaticMesh(FTileAssetPath::Render_SelectGreen);
				ResetParticleAsset(FTileParticleAssetId::Particle_Selected);
			}
			break;
		}
		ResetStaticMesh(FTileAssetPath::Render_SelectNormal);
		ResetParticleAsset(FTileParticleAssetId::Particle_Selected);
	}break;
	case ECWTileRenderType::Support:
	{
	}break;
	case ECWTileRenderType::SwitchInReady:
	{
	}break;
	default:
	{
		UE_LOG(LogCWMapTileRender, Warning, TEXT("ACWMapTileRender::SetTileRenderType Fail. ParamTileRenderType:%d"), (int)InRenderType);
	}break;
	}
}

void ACWMapTileRender::ResetStaticMesh(const FString& InMeshPath)
{
	check(StaticMesh);
	UStaticMesh* NewMesh = nullptr;
	if (!InMeshPath.IsEmpty())
	{
		NewMesh = MapMeshCache.FindRef(InMeshPath);
		if (nullptr == NewMesh)
		{
			UStaticMesh* NewCreateMesh = FCWCfgUtils::GetAssetObject<UStaticMesh>(this, InMeshPath);
			if (nullptr != NewCreateMesh)
			{
				NewMesh = NewCreateMesh;
				MapMeshCache.Add(InMeshPath, NewCreateMesh);
			}
		}
	}
	StaticMesh->SetStaticMesh(NewMesh);
}

void ACWMapTileRender::ResetParticleAsset(const FString& InAssetId /*= STR_Empty*/)
{
	check(ParticleComp);
	UParticleSystem* NewParticle = nullptr;
	if (!InAssetId.IsEmpty())
	{
		NewParticle = MapParticleCache.FindRef(InAssetId);
		if (nullptr == NewParticle)
		{
			UParticleSystem* NewCreateParticle = FCWCfgUtils::GetAssetObject<UParticleSystem>(this, InAssetId);
			if (nullptr != NewCreateParticle)
			{
				NewParticle = NewCreateParticle;
				MapParticleCache.Add(InAssetId, NewCreateParticle);
			}
		}
	}

	ParticleComp->SetTemplate(NewParticle);
	//ParticleComp->SetActive((NewParticle != nullptr)/*, true*/);
	if (nullptr != NewParticle)
	{
		ParticleComp->ActivateSystem(false);
	}
	else
	{
		ParticleComp->DeactivateSystem();
	}
}
