#include "CWMapTileInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Map/Tile/CWMapTile.h"




UCWMapTileInputFSM::UCWMapTileInputFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWMapTileInputFSM::Init(ACWMapTile* ParamParant)
{
	Parant = ParamParant;
}

ACWMapTile* UCWMapTileInputFSM::GetParantMapTile()
{
	return Parant;
}

void UCWMapTileInputFSM::BeginDestroy()
{
	Super::BeginDestroy();
}
