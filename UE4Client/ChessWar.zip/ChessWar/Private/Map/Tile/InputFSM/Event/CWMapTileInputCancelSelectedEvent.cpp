#include "CWMapTileInputCancelSelectedEvent.h"


FCWMapTileInputCancelSelectedEvent::FCWMapTileInputCancelSelectedEvent()
	:FCWFSMEvent()
{

}


FCWMapTileInputCancelSelectedEvent::FCWMapTileInputCancelSelectedEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}