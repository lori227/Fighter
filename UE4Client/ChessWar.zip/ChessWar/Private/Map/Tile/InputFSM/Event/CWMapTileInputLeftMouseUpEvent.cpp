#include "CWMapTileInputLeftMouseUpEvent.h"


FCWMapTileInputLeftMouseUpEvent::FCWMapTileInputLeftMouseUpEvent()
	:FCWFSMEvent()
{

}

FCWMapTileInputLeftMouseUpEvent::FCWMapTileInputLeftMouseUpEvent(
	int ParamEventId,
	int ParamToStateId,
	ECWFSMStackOp ParamStackOp,
	ACWMapTile* ParamTile,
	ACWPlayerController* ParamPlayerControllerInClient
)
	: FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, Tile(ParamTile)
	, PlayerControllerInClient(ParamPlayerControllerInClient)
{

}