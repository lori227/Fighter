#include "CWMapTileInputSelectedEvent.h"


FCWMapTileInputSelectedEvent::FCWMapTileInputSelectedEvent()
	:FCWFSMEvent()
{

}


FCWMapTileInputSelectedEvent::FCWMapTileInputSelectedEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{

}
