#include "CWMapTileInputSelectedState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Map/Tile/InputFSM/CWMapTileInputFSM.h"
#include "Map/Tile/CWMapTile.h"
#include "CWMapTileInputLeftMouseUpEvent.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWPlayerController.h"
#include "CWPlayerState.h"
#include "CWMapTileInputFSM.h"
#include "CWMapTileInputCancelSelectedEvent.h"
#include "CWMap.h"
#include "CWPawn.h"
#include "CWSkill.h"

FCWMapTileInputSelectedState::FCWMapTileInputSelectedState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWMapTileInputSelectedState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWMapTileInputEvent)Event->EventId)
	{
	case ECWMapTileInputEvent::CancelSelected:
		if (Event->ToStateId == (int)ECWMapTileInputState::WaitingInput)
			return true;
		break;
	}
	return false;
}

void FCWMapTileInputSelectedState::OnEnter(const FCWFSMEvent* Event)
{

}

void FCWMapTileInputSelectedState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWMapTileInputSelectedState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWMapTileInputEvent)Event->EventId)
	{
	case ECWMapTileInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWMapTileInputSelectedState::Tick(float DeltaTime)
{

}



void FCWMapTileInputSelectedState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWMapTileInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWMapTileInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Tile != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWMapTile* MyMapTile = ((UCWMapTileInputFSM*)Parent)->GetParantMapTile();
		check(MyMapTile);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		ACWMap* MyMap = MyMapTile->GetParantMap();
		if (MyMap != nullptr)
		{
			//判断当前是否有已选中的棋子
			ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
			if (CurSelectedPawn != nullptr)
			{
				//当前是有已选中的棋子

				//判断当前选中的格子是否有棋子
				TWeakObjectPtr<ACWPawn> PawnInTile = MyMap->GetPawnByTile(MyMapTile->Tile);
				if (PawnInTile.IsValid())
				{
					//当前选中的格子是有棋子

					//判断当前选中的格子里棋子和当前已选中的棋子是否同一个
					if (CurSelectedPawn == PawnInTile)
					{
						//当前选中的格子里棋子和当前已选中的棋子是同一个

						//当前已选中的棋子的状态
						ECWPawnInputState CurInputFSMState = CurSelectedPawn->GetCurInputFSMStateId();
						if (CurInputFSMState == ECWPawnInputState::MoveToDest ||
							CurInputFSMState == ECWPawnInputState::MoveToAttack ||
							CurInputFSMState == ECWPawnInputState::MoveToWaitingAttack ||
							CurInputFSMState == ECWPawnInputState::NormalAttack ||
							CurInputFSMState == ECWPawnInputState::CastSkillToTile ||
							CurInputFSMState == ECWPawnInputState::CastSkillToPawn)
						{
							//不处理
						}
						else if (CurInputFSMState == ECWPawnInputState::ReadyToMove)
						{
							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();
						}
						else if (CurInputFSMState == ECWPawnInputState::WaitingAttack)
						{
							//不处理
						}
						else
						{
							UCWSkill* TempSkill = CurSelectedPawn->GetAutoSelectSkillRecord();
							if (TempSkill != nullptr &&
								!TempSkill->IsNormalAttack() &&
								(TempSkill->GetSkillDataStruct()->TargetType > 0 && ((TempSkill->GetSkillDataStruct()->TargetType & (int32)ECWSkillTargetType::Self) > 0)))
							{
								MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, CurSelectedPawn->GetTile());
							}
							else
							{
								// 取消当前选中棋子
								MyPlayerController->CancelCurSelectedPawnInClient();

								// 取消当前选中格子
								MyPlayerController->CancelCurSelectedTileInClient();
							}
						}
					}
					else
					{
						//当前选中的格子里棋子和当前已选中的棋子不是同一个

						//取消当前已选中的格子
						MyPlayerController->CancelCurSelectedTileInClient();

						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();

						//把自己变成选中的格子
						MyPlayerController->SetCurSelectedTileInClient(MyMapTile);

						//选中了这个棋子
						MyPlayerController->SetCurSelectedPawnInClient(PawnInTile.Get());
					}
				}
				else
				{
					//当前选中的格子没有棋子

					//当前已选中的棋子的状态
					ECWPawnInputState CurInputFSMState = CurSelectedPawn->GetCurInputFSMStateId();
					if (CurInputFSMState == ECWPawnInputState::MoveToDest ||
						CurInputFSMState == ECWPawnInputState::MoveToAttack ||
						CurInputFSMState == ECWPawnInputState::MoveToWaitingAttack ||
						CurInputFSMState == ECWPawnInputState::NormalAttack ||
						CurInputFSMState == ECWPawnInputState::CastSkillToTile ||
						CurInputFSMState == ECWPawnInputState::CastSkillToPawn)
					{
						//不处理
					}
					else if (CurInputFSMState == ECWPawnInputState::ReadyToMove)
					{
						int CurMoveBeginTile = CurSelectedPawn->GetMoveBeginTile();
						if (CurMoveBeginTile == MyMapTile->Tile)
						{
							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();
						}
					}
					else if (CurInputFSMState == ECWPawnInputState::WaitingAttack)
					{
						int CurMoveBeginTile = CurSelectedPawn->GetMoveBeginTile();
						if (CurMoveBeginTile == MyMapTile->Tile)
						{
							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//MyPlayerController->CancelWaitingAttackInClient(CurSelectedPawn);
						}
					}
					else
					{
						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();

						//取消当前已选中的格子
						MyPlayerController->CancelCurSelectedTileInClient();
					}
				}
			}
			else
			{
				//当前是没有已选中的棋子

				//判断当前选中的格子是否是已选中的格子
				if (MyPlayerState->GetCurSelectedTile() == MyMapTile->Tile)
				{
					//当前选中的格子是已选中的格子

					//判断此格子是否有棋子
					TWeakObjectPtr<ACWPawn> PawnInTile = MyMap->GetPawnByTile(MyMapTile->Tile);
					if (PawnInTile.IsValid())
					{
						//此格子有棋子

						//取消当前已选中的格子
						MyPlayerController->CancelCurSelectedTileInClient();

						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();
					}
					else
					{
						//此格子没有棋子

						//取消当前已选中的格子
						MyPlayerController->CancelCurSelectedTileInClient();

						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();
					}
				}
				else
				{
					//当前选中的格子不是已选中的格子
					UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWMapTileInputSelectedState::HandleLeftMouseUp MyPlayerState->GetCurSelectedTile() != MyMapTile->Tile. MyPlayerState->GetCurSelectedTile():%d, MyMapTile->Tile:%d"), MyPlayerState->GetCurSelectedTile(), MyMapTile->Tile);
				}
			}
		}
	}
}