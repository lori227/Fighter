﻿#include "CWMapTileInputWaitingState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Map/Tile/InputFSM/CWMapTileInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWMapTileInputLeftMouseUpEvent.h"
#include "CWPlayerController.h"
#include "CWPlayerState.h"
#include "CWMapTileInputFSM.h"
#include "CWMap.h"
#include "CWMapTile.h"
#include "Pawn/CWPawn.h"

FCWMapTileInputWaitingState::FCWMapTileInputWaitingState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWMapTileInputWaitingState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWMapTileInputEvent)Event->EventId)
	{
	case ECWMapTileInputEvent::Selected:
		if (Event->ToStateId == (int)ECWMapTileInputState::Selected)
			return true;
		break;
	}
	return false;
}

void FCWMapTileInputWaitingState::OnEnter(const FCWFSMEvent* Event)
{
}

void FCWMapTileInputWaitingState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWMapTileInputWaitingState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWMapTileInputEvent)Event->EventId)
	{
	case ECWMapTileInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWMapTileInputWaitingState::Tick(float DeltaTime)
{

}

void FCWMapTileInputWaitingState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWMapTileInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWMapTileInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Tile != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWMapTile* MyMapTile = ((UCWMapTileInputFSM*)Parent)->GetParantMapTile();
		check(MyMapTile);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		ACWMap* MyMap = MyMapTile->GetParantMap();
		ACWPawn* PawnInTile = MyMap->GetPawnByTile(MyMapTile->Tile).Get();
		if (MyMap != nullptr)
		{
			//判断当前是否有已选中的棋子
			ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
			if (CurSelectedPawn != nullptr)
			{
				//当前已有选中的棋子

				//判断是否自己的控制的棋子
				if (MyPlayerController->IsPartner(CurSelectedPawn))
				{
					if (MyPlayerController->IsMyTurn(CurSelectedPawn) &&
						CurSelectedPawn->CanInstructsByCurInstructs())
					{

						//判断是否选中棋子的移动范围里的格子
						uint8 TempMoveAttackDamage = 0x00;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
						if (CurSelectedPawn->IsMoveTile(MyMapTile->Tile))
						{
							//是选中棋子的移动范围里的格子

							//判断移动范围里的格子是否有棋子
							TWeakObjectPtr<ACWPawn> PawnInMoveTile = MyMap->GetPawnByTile(MyMapTile->Tile);
							if (PawnInMoveTile.IsValid())
							{
								if (CurSelectedPawn == PawnInMoveTile)
								{
									ECWPawnActionState CurActionStateId = CurSelectedPawn->GetCurActionStateId();
									if (CurActionStateId == ECWPawnActionState::WaitingAttack)
									{
										CurSelectedPawn->ActionEndInClient(MyPlayerController);
									}
									else
									{
										if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove ||
											CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected ||
											CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::SelectedAndWantAttack ||
											CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMoveAndWantAttack)
										{
											//取消已经选中的目标棋子
											MyPlayerController->CancelCurTargetSelectedPawnInClient();

											//自己变成目标棋子
											MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInMoveTile.Get());
										}
										else
										{
											//不处理
										}
									}
								}
							}
							else
							{
								//移动范围里的格子没有棋子

								ECWPawnInputState SelectedPawnCurInputStateId = CurSelectedPawn->GetCurInputFSMStateId();
								if (SelectedPawnCurInputStateId == ECWPawnInputState::ReadyToMove)
								{
									//判断此次选中棋子的移动范围里的格子 是否是已准备移动到目标点格子
									if (CurSelectedPawn->GetReadyToDestTile() == MyMapTile->Tile)
									{
										//此次选中棋子的移动范围里的格子 是已准备移动到目标点格子


										//if (CurSelectedPawn->CheckEnemyInAttackRange(MyMapTile->Tile))
										//{
										//	//角色移动
										//	MyPlayerController->MoveToWaitingAttackInClient(
										//		CurSelectedPawn,
										//		MyMapTile->Tile);
										//}
										//else
										{
											//角色移动
											MyPlayerController->MoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
										}
									}
									else
									{
										//此次选中棋子的移动范围里的格子 不是已准备移动到目标点格子

										//角色调整准备移动的目标格子
										MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
									}
								}
								else if (SelectedPawnCurInputStateId == ECWPawnInputState::Selected)
								{
									if (CurSelectedPawn->IsLongDown())
									{
										CurSelectedPawn->SetLongDown(false);
										//if (CurSelectedPawn->CheckEnemyInAttackRange(MyMapTile->Tile))
										//{
										//	//角色移动
										//	MyPlayerController->MoveToWaitingAttackInClient(
										//		CurSelectedPawn,
										//		MyMapTile->Tile);
										//}
										//else
										{
											//角色移动
											MyPlayerController->MoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
										}
									}
									else
									{
										//角色调整准备移动的目标格子
										MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
									}
								}
								else if (SelectedPawnCurInputStateId == ECWPawnInputState::SelectedAndWantAttack)
								{
									ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();
									if (CurTargetSelectedPawn != nullptr)
									{
										if (CurSelectedPawn->IsAttackTileFromTile(MyMapTile->Tile, CurTargetSelectedPawn->GetTile(), TempMoveAttackDamage))
										{
											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MyMapTile->Tile, CurTargetSelectedPawn);
										}
										else
										{
											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
										}
									}
									else
									{
										//角色调整准备移动的目标格子
										MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
									}
								}
								else if (SelectedPawnCurInputStateId == ECWPawnInputState::ReadyToMoveAndWantAttack)
								{
									ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();
									if (CurTargetSelectedPawn != nullptr)
									{
										if (CurSelectedPawn->IsAttackTileFromTile(MyMapTile->Tile, CurTargetSelectedPawn->GetTile(), TempMoveAttackDamage))
										{
											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MyMapTile->Tile, CurTargetSelectedPawn);
										}
										else
										{
											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
										}
									}
									else
									{
										//角色调整准备移动的目标格子
										MyPlayerController->ReadyMoveToDestTileInClient(CurSelectedPawn, MyMapTile->Tile);
									}
								}
								else
								{
									//不处理
								}
							}
						}
						//判断是否选中棋子的攻击范围里的格子
						else if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyMapTile->Tile, TempMoveAttackDamage))
						{
							//判断攻击范围里的格子是否有棋子
							TWeakObjectPtr<ACWPawn> PawnInAttackTile = MyMap->GetPawnByTile(MyMapTile->Tile);
							if (PawnInAttackTile.IsValid())
							{
								//攻击范围里的格子有棋子

								//判断攻击范围里的格子里的棋子是否敌人
								if (MyPlayerController->IsEnemy(PawnInAttackTile.Get()))
								{
									//获得当前选中的目标棋子
									ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

									//判断当前选中的目标棋子是否存在
									if (CurTargetSelectedPawn != nullptr)
									{
										//当前选中的目标棋子是存在

										//判断当前选中的目标棋子是否攻击范围里格子里的棋子
										if (CurTargetSelectedPawn == PawnInAttackTile)
										{
											//当前选中的目标棋子是攻击范围里格子里的棋子

											//当前选中的目标棋子就是自己
											if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
											{
												//判断自己是不是在此棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//自己是在此棋子的攻击范围里
													MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
												}
												else
												{
													//自己不是在此棋子的攻击范围里
													//不处理
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::SelectedAndWantAttack)
											{
												//判断自己是不是在此棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//自己是在此棋子的攻击范围里
													MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
												}
												else
												{
													//自己不是在此棋子的攻击范围里
													UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMoveAndWantAttack)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													ACWPawn* OldTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (MoveTile != CurSelectedPawn->GetTile())
														{
															if (OldTargetSelectedPawn == PawnInAttackTile.Get())
															{
																int ReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
																int RealMoveTile = ReadyToDestTile != -1 ? ReadyToDestTile : MoveTile;
																//角色移动攻击
																MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																	CurSelectedPawn,
																	PawnInAttackTile.Get()->GetTile(),
																	RealMoveTile);
															}
															else
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
														}
														else
														{
															if (OldTargetSelectedPawn == PawnInAttackTile.Get())
															{
																int ReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
																if (ReadyToDestTile != CurSelectedPawn->GetTile())
																{
																	int RealMoveTile = ReadyToDestTile != -1 ? ReadyToDestTile : MoveTile;
																	//角色移动攻击
																	MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																		CurSelectedPawn,
																		PawnInAttackTile.Get()->GetTile(),
																		RealMoveTile);
																}
																else
																{
																	MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
																}
															}
															else
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (CurSelectedPawn->IsLongDown())
														{
															CurSelectedPawn->SetLongDown(false);

															//角色移动攻击
															MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																CurSelectedPawn,
																PawnInAttackTile.Get()->GetTile(),
																MoveTile);
														}
														else
														{
															if (MoveTile != CurSelectedPawn->GetTile())
															{
																//uint8 TempMoveAttackDamage = 0x00;
																//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
																//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
																if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile.Get());
																}
																else
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
																}
															}
															else
															{
																int TempReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
																if (TempReadyToDestTile == CurSelectedPawn->GetTile())
																{
																	//角色进入等待攻击状态
																	MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
																}
																else
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
																}
															}
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
												else
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (CurSelectedPawn->IsLongDown())
														{
															CurSelectedPawn->SetLongDown(false);

															//uint8 TempMoveAttackDamage = 0x00;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
															int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
															RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, PawnInAttackTile->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
															if (RealMoveTile != CurSelectedPawn->GetTile())
															{
																//角色移动攻击
																MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																	CurSelectedPawn,
																	PawnInAttackTile.Get()->GetTile(),
																	RealMoveTile);
															}
															else
															{
																MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
															}
														}
														else
														{
															if (MoveTile != CurSelectedPawn->GetTile())
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
															else
															{
																//角色进入等待攻击状态
																MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
															}
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
												else
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
												}
											}
											else
											{
												//不处理
											}
										}
										else
										{
											//当前选中的目标棋子不是攻击范围里格子里的棋子

											if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (CurSelectedPawn->IsLongDown())
														{
															CurSelectedPawn->SetLongDown(false);

															//角色移动攻击
															MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																CurSelectedPawn,
																PawnInAttackTile.Get()->GetTile(),
																MoveTile);
														}
														else
														{
															if (MoveTile != CurSelectedPawn->GetTile())
															{
																//uint8 TempMoveAttackDamage = 0x00;
																//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
																//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
																if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile.Get());
																}
																else
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
																}
															}
															else
															{
																//角色进入等待攻击状态
																MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
															}
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
												else
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (CurSelectedPawn->IsLongDown())
														{
															CurSelectedPawn->SetLongDown(false);

															//uint8 TempMoveAttackDamage = 0x00;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
															int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
															RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, PawnInAttackTile->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
															if (RealMoveTile != CurSelectedPawn->GetTile())
															{
																//角色移动攻击
																MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																	CurSelectedPawn,
																	PawnInAttackTile.Get()->GetTile(),
																	RealMoveTile);
															}
															else
															{
																MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
															}
														}
														else
														{
															if (MoveTile != CurSelectedPawn->GetTile())
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
															else
															{
																//角色进入等待攻击状态
																MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
															}
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
												else
												{
													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::SelectedAndWantAttack)
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

												//敌人头顶的Icon设置
												CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

												int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
												if (MoveTile != -1)
												{
													if (MoveTile != CurSelectedPawn->GetTile())
													{
														//判断此次选中棋子的移动范围里的格子 是否是已准备移动到目标点格子
														if (CurSelectedPawn->GetReadyToDestTile() == MoveTile)
														{
															//此次选中棋子的移动范围里的格子 是已准备移动到目标点格子

															//角色移动
															MyPlayerController->MoveToDestTileInClient(CurSelectedPawn, MoveTile);
														}
														else
														{
															//此次选中棋子的移动范围里的格子 不是已准备移动到目标点格子

															//角色调整准备移动的目标格子
															MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
														}
													}
													else
													{
														//角色进入等待攻击状态
														MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
													}
												}
												else
												{
													UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
												}
											}
											else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMoveAndWantAttack)
											{
												//判断自己是否是在当前选中棋子的攻击范围里
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
												{
													ACWPawn* OldTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

													//取消已经选中的目标棋子
													MyPlayerController->CancelCurTargetSelectedPawnInClient();

													//自己变成目标棋子
													MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

													//敌人头顶的Icon设置
													CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

													int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
													if (MoveTile != -1)
													{
														if (MoveTile != CurSelectedPawn->GetTile())
														{
															if (OldTargetSelectedPawn == PawnInAttackTile.Get())
															{
																//角色移动攻击
																MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																	CurSelectedPawn,
																	PawnInAttackTile.Get()->GetTile(),
																	MoveTile);
															}
															else
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
														}
														else
														{
															//角色进入等待攻击状态
															MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
														}
													}
													else
													{
														UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
													}
												}
											}
											else
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
											}
										}
									}
									else
									{
										//当前选中的目标棋子不存在


										if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
										{
											//取消已经选中的目标棋子
											MyPlayerController->CancelCurTargetSelectedPawnInClient();

											//自己变成目标棋子
											MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
										}
										else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
										{
											//判断自己是否是在当前选中棋子的攻击范围里
											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

												//敌人头顶的Icon设置
												CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

												int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
												if (MoveTile != -1)
												{
													if (CurSelectedPawn->IsLongDown())
													{
														CurSelectedPawn->SetLongDown(false);

														//角色移动攻击
														MyPlayerController->AutoSelectSkillMoveToAttackInClient(
															CurSelectedPawn,
															PawnInAttackTile.Get()->GetTile(),
															MoveTile);
													}
													else
													{
														if (MoveTile != CurSelectedPawn->GetTile())
														{
															//uint8 TempMoveAttackDamage = 0x00;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
															//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
															if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile.Get());
															}
															else
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
															}
														}
														else
														{
															if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
															{
																//角色调整准备移动的目标格子
																MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), PawnInAttackTile.Get());
															}
															else
															{
																int TempReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
																if (TempReadyToDestTile == CurSelectedPawn->GetTile())
																{
																	//角色进入等待攻击状态
																	MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
																}
																else
																{
																	//角色调整准备移动的目标格子
																	MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
																}
															}
														}
													}
												}
												else
												{
													UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
												}
											}
											else
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
											}
										}
										else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
										{
											//判断自己是否是在当前选中棋子的攻击范围里
											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), TempMoveAttackDamage))
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());

												//敌人头顶的Icon设置
												CurSelectedPawn->SetEnemyHeadIconInAttackSingle(PawnInAttackTile.Get());

												int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), PawnInAttackTile->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
												if (MoveTile != -1)
												{
													if (CurSelectedPawn->IsLongDown())
													{
														CurSelectedPawn->SetLongDown(false);

														//uint8 TempMoveAttackDamage = 0x00;
														//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
														//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
														int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
														RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, PawnInAttackTile->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
														if (RealMoveTile != CurSelectedPawn->GetTile())
														{
															//角色移动攻击
															MyPlayerController->AutoSelectSkillMoveToAttackInClient(
																CurSelectedPawn,
																PawnInAttackTile.Get()->GetTile(),
																RealMoveTile);
														}
														else
														{
															MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, PawnInAttackTile.Get()->GetTile());
														}
													}
													else
													{
														if (MoveTile != CurSelectedPawn->GetTile())
														{
															//角色调整准备移动的目标格子
															MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, PawnInAttackTile.Get());
														}
														else
														{
															//角色进入等待攻击状态
															MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, PawnInAttackTile.Get());
														}
													}
												}
												else
												{
													UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
												}
											}
											else
											{
												//取消已经选中的目标棋子
												MyPlayerController->CancelCurTargetSelectedPawnInClient();

												//自己变成目标棋子
												MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
											}
										}
										else
										{
											//取消已经选中的目标棋子
											MyPlayerController->CancelCurTargetSelectedPawnInClient();

											//自己变成目标棋子
											MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInAttackTile.Get());
										}
									}
								}
								else
								{
									//不是敌人
									UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWMapTileInputWaitingState::HandleLeftMouseUp impossible"));
								}
							}
							else
							{
								//攻击范围里的格子没有棋子
								
								if (CurSelectedPawn->IsLongDown())
								{
									CurSelectedPawn->SetLongDown(false);

									//取消当前已选中的格子
									MyPlayerController->CancelCurSelectedTileInClient();

									//取消已经选中的棋子
									MyPlayerController->CancelCurSelectedPawnInClient();

									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();
								}
							}
						}
						else
						{
							//选中棋子的既不是移动范围里的格子，也不是攻击范围里的格子

							//判断此格子是否有棋子
							if (nullptr != PawnInTile)
							{
								//此格子有棋子

								//判断是否当前选中的棋子
								if (PawnInTile == CurSelectedPawn)
								{
									//取消当前已选中的格子
									MyPlayerController->CancelCurSelectedTileInClient();

									//取消已经选中的棋子
									MyPlayerController->CancelCurSelectedPawnInClient();
								}
								//判断是否自己的同伴
								else if (MyPlayerController->IsPartner(PawnInTile))
								{
									//判断当前选中的棋子是否处于等待攻击状态
									if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
									{
										//不处理
									}
									else
									{
										//取消当前已选中的格子
										MyPlayerController->CancelCurSelectedTileInClient();

										//取消已经选中的棋子
										MyPlayerController->CancelCurSelectedPawnInClient();

										//取消已经选中的目标棋子
										MyPlayerController->CancelCurTargetSelectedPawnInClient();

										//把自己变成选中的格子
										MyPlayerController->SetCurSelectedTileInClient(MyMapTile);

										//自己变成选中的棋子
										MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);
									}
								}
								//判断是否自己的友方
								else if (MyPlayerController->IsFriend(PawnInTile))
								{
									//判断当前选中的棋子是否处于等待攻击状态
									if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
									{
										//不处理
									}
									else
									{
										//取消已经选中的目标棋子
										MyPlayerController->CancelCurTargetSelectedPawnInClient();

										//把此格子里的棋子变成目标棋子
										MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInTile);
									}
								}
								//判断是否自己的敌方
								else if (MyPlayerController->IsEnemy(PawnInTile))
								{
									//判断当前选中的棋子是否处于等待攻击状态
									if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
									{
										//不处理
									}
									else
									{
										// 取消已经选中的目标棋子
										//MyPlayerController->CancelCurTargetSelectedPawnInClient();
										// 把此格子里的棋子变成目标棋子
										//MyPlayerController->SetCurTargetSelectedPawnInClient(PawnInTile);

										// 取消当前已选中的格子
										MyPlayerController->CancelCurSelectedTileInClient();
										// 取消已经选中的棋子
										MyPlayerController->CancelCurSelectedPawnInClient();
										// 取消已经选中的目标棋子
										MyPlayerController->CancelCurTargetSelectedPawnInClient();
										// 把自己变成选中的格子
										MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
										// 自己变成选中的棋子
										MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);
									}
								}
								else
								{
									UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWMapTileInputWaitingState::HandleLeftMouseUp impossible"));
								}
							}
							else
							{
								//此格子没有棋子

								//判断当前选中的棋子是否处于等待攻击状态
								ECWPawnInputState CurInputState = CurSelectedPawn->GetCurInputFSMStateId();
								if (CurInputState == ECWPawnInputState::MoveToDest ||
									CurInputState == ECWPawnInputState::MoveToAttack ||
									CurInputState == ECWPawnInputState::MoveToWaitingAttack ||
									CurInputState == ECWPawnInputState::NormalAttack ||
									CurInputState == ECWPawnInputState::CastSkillToTile ||
									CurInputState == ECWPawnInputState::CastSkillToPawn)
								{
									//不处理
								}
								else if (CurInputState == ECWPawnInputState::WaitingAttack)
								{
									//MyPlayerController->CancelWaitingAttackInClient(CurSelectedPawn);
								}
								else if (CurInputState == ECWPawnInputState::Selected)
								{
									if (CurSelectedPawn->IsLongDown())
									{
										CurSelectedPawn->SetLongDown(false);

										//取消当前已选中的格子
										MyPlayerController->CancelCurSelectedTileInClient();

										//取消已经选中的棋子
										MyPlayerController->CancelCurSelectedPawnInClient();

										//取消已经选中的目标棋子
										MyPlayerController->CancelCurTargetSelectedPawnInClient();
									}
									else
									{
										//取消当前已选中的格子
										MyPlayerController->CancelCurSelectedTileInClient();

										//取消已经选中的棋子
										MyPlayerController->CancelCurSelectedPawnInClient();

										//取消已经选中的目标棋子
										MyPlayerController->CancelCurTargetSelectedPawnInClient();

										//把自己变成选中的格子
										MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
									}
								}
								else
								{
									//取消当前已选中的格子
									MyPlayerController->CancelCurSelectedTileInClient();

									//取消已经选中的棋子
									MyPlayerController->CancelCurSelectedPawnInClient();

									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//把自己变成选中的格子
									MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
								}
							}
						}
					}
					else
					{
						//不是轮到此棋子行动

						//判断此格子是否有棋子
						if (nullptr != PawnInTile)
						{
							//此格子有棋子

							//如果是自己
							if (PawnInTile == CurSelectedPawn)
							{
								//则取消选中自己
								MyPlayerController->CancelCurSelectedPawnInClient();

								//取消选中地形格子
								MyPlayerController->CancelCurSelectedTileInClient();
							}
							//当前选中的棋子是同伴
							else if (MyPlayerController->IsPartner(PawnInTile, CurSelectedPawn))
							{
								//取消已经选中的棋子
								MyPlayerController->CancelCurSelectedPawnInClient();

								//取消选中地形格子
								MyPlayerController->CancelCurSelectedTileInClient();

								//自己变成选中的棋子
								MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);

								//把棋子所在格子变成选中的格子
								MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
							}
							//当前选中的棋子是友方的棋子（暂无友方，暂不实现）
							else if (MyPlayerController->IsFriend(PawnInTile, CurSelectedPawn))
							{

							}
							//当前选中的棋子是敌方的棋子
							else if (MyPlayerController->IsEnemy(PawnInTile, CurSelectedPawn))
							{
								//取消已经选中的棋子
								MyPlayerController->CancelCurSelectedPawnInClient();

								//取消选中地形格子
								MyPlayerController->CancelCurSelectedTileInClient();

								//自己变成选中的棋子
								MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);

								//把棋子所在格子变成选中的格子
								MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
							}
							else
							{
							}
						}
						else
						{
							//此格子没有棋子

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//取消选中地形格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//把棋子所在格子变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
						}
					}
				}
				//判断是否友方的棋子
				else if (MyPlayerController->IsFriend(CurSelectedPawn))
				{
					//判断此格子是否就是选中友方的格子
					if (nullptr != PawnInTile)
					{
						if (PawnInTile == CurSelectedPawn)
						{
							//此格子就是选中友方的格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();
						}
						else
						{
							//此格子不是选中友方的格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);

							//选中了这个棋子
							MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);
						}
					}
					else
					{
						//判断是否在友方的移动范围格子或攻击范围格子
						uint8 TempMoveAttackDamage = 0x00;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
						if (CurSelectedPawn->IsMoveTile(MyMapTile->Tile) || CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), MyMapTile->Tile, TempMoveAttackDamage))
						{
							//是在友方的移动范围格子或攻击范围格子

							//不处理
						}
						else
						{
							//不是在友方的移动范围格子或攻击范围格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
						}
					}
				}
				//判断是否敌方的棋子
				else if (MyPlayerController->IsEnemy(CurSelectedPawn))
				{
					//判断此格子是否就是选中敌人的格子
					if (nullptr != PawnInTile)
					{
						//此格子有棋子

						//判断棋子是否就是当前选中的棋子
						if (PawnInTile == CurSelectedPawn)
						{
							//此格子就是选中敌人的格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();
						}
						else
						{
							//此格子不是选中敌人的格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);

							//选中了这个棋子
							MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);
						}
					}
					else
					{
						//此格子上没有棋子

						//判断是否在敌人的移动范围格子或攻击范围格子
						uint8 TempMoveAttackDamage = 0x00;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
						if (CurSelectedPawn->IsMoveTile(MyMapTile->Tile) || CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), MyMapTile->Tile, TempMoveAttackDamage))
						{
							//是在敌人的移动范围格子或攻击范围格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
						}
						else
						{
							//不是在敌人的移动范围格子或攻击范围格子

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
						}
					}
				}
				else
				{
					UE_LOG(LogCWMapTileInputFSM, Error, TEXT("FCWMapTileInputWaitingState::HandleLeftMouseUp impossible"));
				}
			}
			else
			{
				//当前没有已选中的棋子

				//判断此格子是否有棋子
				if (nullptr != PawnInTile)
				{
					//此格子有棋子

					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消当前已选中的格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//把自己变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyMapTile);

					//选中了这个棋子
					MyPlayerController->SetCurSelectedPawnInClient(PawnInTile);
				}
				else
				{
					//此格子没有棋子

					//判断当前是否有已选中的格子
					ACWMapTile* CurSelectedTile = MyPlayerController->GetCurSelectedTile();
					if (CurSelectedTile != nullptr)
					{
						//当前已有选中的格子

						//当前已选中的格子是否就是自己
						if (CurSelectedTile->Tile == MyMapTile->Tile)
						{
							//是自己

							//则取消选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();
						}
						else
						{
							//不是自己

							//取消已经选中的棋子
							MyPlayerController->CancelCurSelectedPawnInClient();

							//取消当前已选中的格子
							MyPlayerController->CancelCurSelectedTileInClient();

							//把自己变成选中的格子
							MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
						}
					}
					else
					{
						//当前没有已选中的格子

						//把自己变成选中的格子
						MyPlayerController->SetCurSelectedTileInClient(MyMapTile);
					}
				}
			}
		}
	}
}