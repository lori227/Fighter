#include "ToLuaPaths.h"

#include "lua/lua.hpp"
#include "LuaObject.h"
#include "LuaCppBinding.h"
#include "Log.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/Package.h"
#include "Blueprint/UserWidget.h"
#include "Misc/AssertionMacros.h"
#include "LuaVar.h"
#include "LuaCppBindingPost.h"
#include "Paths.h"

namespace slua
{
	class FToLuaPaths
	{
		LuaClassBody()
	public:

		static LuaOwnedPtr<FToLuaPaths> create()
		{
			return new FToLuaPaths();
		}

		static FString ProjectContentDir()
		{
			return FPaths::ProjectContentDir();
		}
	};

	DefLuaClass(FToLuaPaths)
		DefLuaMethod(ProjectContentDir, &FToLuaPaths::ProjectContentDir)
	EndDef(FToLuaPaths, &FToLuaPaths::create)
}