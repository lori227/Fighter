#include "ToLuaGameInstance.h"

#include "lua/lua.hpp"
#include "LuaObject.h"
#include "LuaCppBinding.h"
#include "Log.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/Package.h"
#include "Blueprint/UserWidget.h"
#include "Misc/AssertionMacros.h"
#include "LuaVar.h"
#include "LuaCppBindingPost.h"
#include "CWGameInstance.h"
#include "CWTCPClient.h"
#include "CWNetMessage.h"
#include "CWFuncLib.h"
#include "CWUtils.h"
#include "CWCommandMgr.h"

// read file content
static uint8* ReadFileHelp(IPlatformFile& PlatformFile, FString path, uint32& len) {
	IFileHandle* FileHandle = PlatformFile.OpenRead(*path);
	if (FileHandle) {
		len = (uint32)FileHandle->Size();
		uint8* buf = new uint8[len];

		FileHandle->Read(buf, len);

		// Close the file again
		delete FileHandle;

		return buf;
	}

	return nullptr;
}

namespace slua
{
	class FToLuaGameInstance
	{
		LuaClassBody()
	public:

		static LuaOwnedPtr<FToLuaGameInstance> create()
		{
			return new FToLuaGameInstance();
		}

		static UWorld* GetWorld()
		{
			check(UCWGameInstance::GetInstance());
			return UCWGameInstance::GetInstance()->GetWorld();
		}

#if !UE_SERVER

		static bool ConnectPVPServer(const FString& ParamIp, uint32 ParamPort, const FString& ParamNetPlayerId)
		{
			//FString TempIp(ParamIp.c_str());
			//FString TempNetPlayerId(ParamNetPlayerId.c_str());
			UCWFuncLib::CWGConnectServerEx(UCWGameInstance::GetInstance()->GetWorld(), ParamIp, ParamPort, ParamNetPlayerId, nullptr);
			return true;
		}

#endif
		static FString ReadFileEx(const FString& ParamPathFile)
		{
			uint32 len = 0;
			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
			uint8* buf = ReadFileHelp(PlatformFile, ParamPathFile, len);
			if (buf)
			{
				FString str = FString(reinterpret_cast<const char*>(buf));
				str += '\0';
				return str;
			}

			return "";
		}


		static bool CopyFromStdString(UCWNetMessage* ParamNetMsg, const char* ParamData, uint32 ParamDataSize)
		{
			check(ParamNetMsg);
			return ParamNetMsg->CopyData((uint8*)ParamData, ParamDataSize);
			return true;
		}

		static uint64 GetUEServerId()
		{
			FString TempUE4ServerId = CWCommandMgr::GetUEServerId();
			if (TempUE4ServerId == "")
			{
				return 0;
			}
			else
			{
				return FCWUtils::FStringAppId2Uint64Id(TempUE4ServerId);
			}
		}

		static FString GetLoginId()
		{
			return FPlatformMisc::GetLoginId();
		}

		static const FString& GetTargetVersionInClient()
		{
			return UCWGameInstance::GetInstance()->GetTargetVersionInClient();
		}
		static void SetTargetVersionInClient(const FString& ParamTargetVersion)
		{
			UCWGameInstance::GetInstance()->SetTargetVersionInClient(ParamTargetVersion);
		}

		static const FString& GetServerAuthTokenInClient()
		{
			return UCWGameInstance::GetInstance()->GetServerAuthTokenInClient();
		}

		static void SetServerAuthTokenInClient(const FString& ParamServerAuthToken)
		{
			UCWGameInstance::GetInstance()->SetServerAuthTokenInClient(ParamServerAuthToken);
		}

		static uint32 GetAccountIdInClient()
		{
			return UCWGameInstance::GetInstance()->GetAccountIdInClient();
		}

		static void SetAccountIdInClient(uint32 ParamAccountId)
		{
			UCWGameInstance::GetInstance()->SetAccountIdInClient(ParamAccountId);
		}
	};

	DefLuaClass(FToLuaGameInstance)
		DefLuaMethod(GetWorld, &FToLuaGameInstance::GetWorld)
#if !UE_SERVER
		DefLuaMethod(ConnectPVPServer, &FToLuaGameInstance::ConnectPVPServer)
#endif
		DefLuaMethod(ReadFileEx, &FToLuaGameInstance::ReadFileEx)
		DefLuaMethod(CopyFromStdString, &FToLuaGameInstance::CopyFromStdString)
		DefLuaMethod(GetUEServerId, &FToLuaGameInstance::GetUEServerId)
		DefLuaMethod(GetLoginId, &FToLuaGameInstance::GetLoginId)
		DefLuaMethod(GetTargetVersionInClient, &FToLuaGameInstance::GetTargetVersionInClient)
		DefLuaMethod(SetTargetVersionInClient, &FToLuaGameInstance::SetTargetVersionInClient)
		DefLuaMethod(GetServerAuthTokenInClient, &FToLuaGameInstance::GetServerAuthTokenInClient)
		DefLuaMethod(SetServerAuthTokenInClient, &FToLuaGameInstance::SetServerAuthTokenInClient)
		DefLuaMethod(GetAccountIdInClient, &FToLuaGameInstance::GetAccountIdInClient)
		DefLuaMethod(SetAccountIdInClient, &FToLuaGameInstance::SetAccountIdInClient)
	EndDef(FToLuaGameInstance, &FToLuaGameInstance::create)

	DefEnumClass(ESlateVisibility, ESlateVisibility::Visible, ESlateVisibility::Collapsed, ESlateVisibility::Hidden, ESlateVisibility::HitTestInvisible, ESlateVisibility::SelfHitTestInvisible);

}