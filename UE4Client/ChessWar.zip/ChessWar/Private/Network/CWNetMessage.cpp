#include "CWNetMessage.h"

UCWNetMessage::UCWNetMessage(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	NetHead.MsgId = 0;
	NetHead.DataLength = 0;
	NetHead.Child = 0;

	NetHead.Route.ServerId = 0;
	NetHead.Route.SendId = 0;
	NetHead.Route.RecvId = 0;

	Data = nullptr;
}

UCWNetMessage::~UCWNetMessage()
{
	FreeData();
}


bool UCWNetMessage::CopyData(const uint8* ParamData, uint32 ParamDataLength)
{
	check(ParamData);
	if (ParamDataLength <= 0)
		return false;

	if (Data == nullptr)
	{
		MallocData(ParamDataLength);
	}
	check(Data);
	check(NetHead.DataLength == ParamDataLength);
	memcpy(Data, ParamData, NetHead.DataLength);
	return true;
}

UCWNetMessage* UCWNetMessage::Create()
{
	UCWNetMessage* TempNetMsg = NewObject<UCWNetMessage>();
	return TempNetMsg;
}


void UCWNetMessage::CopyFrom(UCWNetMessage* ParamNetMsg)
{
	check(ParamNetMsg);
	NetHead.Route.ServerId = ParamNetMsg->NetHead.Route.ServerId;
	NetHead.Route.SendId = ParamNetMsg->NetHead.Route.SendId;
	NetHead.Route.RecvId = ParamNetMsg->NetHead.Route.RecvId;

	NetHead.MsgId = ParamNetMsg->NetHead.MsgId;
	NetHead.DataLength = ParamNetMsg->NetHead.DataLength;
	NetHead.Child = ParamNetMsg->NetHead.Child;

	if (ParamNetMsg->NetHead.DataLength > 0)
	{
		CopyData(ParamNetMsg->Data, ParamNetMsg->NetHead.DataLength);
	}
}

bool UCWNetMessage::CopyDataFromStdString(const std::string& ParamStdString)
{
	return CopyData((uint8*)ParamStdString.c_str(), ParamStdString.length());
}

void UCWNetMessage::SetNetHeadMsgId(int32 ParamMsgId)
{
	NetHead.MsgId = ParamMsgId;
}

int32 UCWNetMessage::GetNetHeadMsgId()
{
	return NetHead.MsgId;
}

void UCWNetMessage::MallocData(uint32 ParamDataLength)
{
	if (ParamDataLength > 0)
	{
		FreeData();

		NetHead.DataLength = ParamDataLength;
		Data = (uint8*)malloc(NetHead.DataLength);
		memset(Data, 0, NetHead.DataLength);
	}
}

void UCWNetMessage::FreeData()
{
	if (Data != nullptr)
	{
		free(Data);
		Data = nullptr;
	}

	NetHead.DataLength = 0;
}


