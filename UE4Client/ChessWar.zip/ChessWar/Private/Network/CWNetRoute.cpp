#pragma once

#include "CWNetRoute.h"


FCWNetRoute::FCWNetRoute()
: ServerId(0u)
, SendId(0u)
, RecvId(0u)
{

}
	
FCWNetRoute::FCWNetRoute(uint64 ParamServerId, uint64 ParamSendId, uint64 ParamRecvId)
: ServerId(ParamServerId)
, SendId(ParamSendId)
, RecvId(ParamRecvId)
{

}
