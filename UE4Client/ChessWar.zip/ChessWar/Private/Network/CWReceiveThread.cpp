﻿#include "CWReceiveThread.h"
#include "Sockets.h"
#include "CWNetMessage.h"


DECLARE_LOG_CATEGORY_CLASS( LogCWReceiveThread, All, All );

UCWReceiveThread::UCWReceiveThread( const FObjectInitializer& ObjectInitializer )
    : Super( ObjectInitializer )
    , ClientSocket( nullptr )
    , MessageHeadLength( 0 )
    , CurReceiveBuffLength( 0 )
{
    memset( ReceiveBuff, 0, sizeof( ReceiveBuff ) );
}

UCWReceiveThread::~UCWReceiveThread()
{

}

bool UCWReceiveThread::IsFinished()
{
    return false;
}

int32 UCWReceiveThread::ThreadBody()
{
    if ( ClientSocket == nullptr )
    {
        return 0;
    }

    //接收数据包
    if ( ClientSocket->GetConnectionState() != SCS_Connected )
    {
        // Socket断开连接
        Stop();
    }
    else
    {
        uint32 TempSize = 0;
        if ( ClientSocket->HasPendingData( TempSize ) )
        {
            TArray<uint8> TempReceiveData;
            TempReceiveData.Init( 0, FMath::Min( TempSize, ( uint32 )ECWNetDefine::MaxReceiveBuffLength ) );

            int32 TempBytesRead = 0;
            ClientSocket->Recv( TempReceiveData.GetData(), TempReceiveData.Num(), TempBytesRead );

            if ( TempBytesRead > 0 )
            {
                if ( CurReceiveBuffLength + TempBytesRead > ECWNetDefine::MaxReceiveBuffLength )
                {
                    //UE_LOG(LogCWReceiveThread, Error, TEXT("FCWReceiveThreadForClient::Run, ClientSocket->Recv Fail, CurReceiveBuffLength:%d, TempBytesRead:%d, MaxReceiveBuffLength:%d."), CurReceiveBuffLength, TempBytesRead, ECWNetDefine::MaxReceiveBuffLength);
                    CurReceiveBuffLength = 0;
                }

                memcpy( ( uint8* )ReceiveBuff + CurReceiveBuffLength, TempReceiveData.GetData(), TempBytesRead );
                CurReceiveBuffLength += TempBytesRead;

                // 处理消息
                ParseReceiveBuffToMessage();
            }
        }
    }

    FPlatformProcess::Sleep( 0.01f );
    return 1;
}

void UCWReceiveThread::SetClientSocket( FSocket* ParamClientSocket )
{
    check( ParamClientSocket );
    ClientSocket = ParamClientSocket;
}

void UCWReceiveThread::SetMessageHeadLength( uint32 ParamMessageHeadLength )
{
    MessageHeadLength = ParamMessageHeadLength;
}

void UCWReceiveThread::ParseReceiveBuffToMessage()
{
    // 长度不足一个消息头
    uint32 TempCurPosition = 0;
    FCWNetHead* TempNetHead = CheckReciveBuffValid( TempCurPosition );
    if ( TempNetHead == nullptr )
    {
        return;
    }

    while ( CurReceiveBuffLength >= ( TempCurPosition + MessageHeadLength + TempNetHead->DataLength ) )
    {
        UCWNetMessage* TempRecvNetMsg = UCWNetMessage::Create();
        check( TempRecvNetMsg );
        memcpy( &TempRecvNetMsg->NetHead, TempNetHead, MessageHeadLength );

        TempCurPosition += MessageHeadLength;
        if ( TempNetHead->DataLength > 0 )
        {
            TempRecvNetMsg->CopyData( ( uint8* )ReceiveBuff + TempCurPosition, TempNetHead->DataLength );
            TempCurPosition += TempNetHead->DataLength;
        }

        AddReceiveMessage( TempRecvNetMsg );

        // 检查消息的有效性
        TempNetHead = CheckReciveBuffValid( TempCurPosition );
        if ( TempNetHead == nullptr )
        {
            break;
        }
    }

    // 设置长度
    CurReceiveBuffLength -= FMath::Min( CurReceiveBuffLength, TempCurPosition );

    // 移动消息buff
    if ( CurReceiveBuffLength > 0 && TempCurPosition > 0 )
    {
        memmove( ReceiveBuff, ( uint8* )ReceiveBuff + TempCurPosition, CurReceiveBuffLength );
    }
}


FCWNetHead* UCWReceiveThread::CheckReciveBuffValid( uint32 ParamPosition )
{
    if ( CurReceiveBuffLength < ( ParamPosition + MessageHeadLength ) )
    {
        return nullptr;
    }

    auto TempNetHead = reinterpret_cast<FCWNetHead*>( ReceiveBuff + ParamPosition );

    // 收到的消息长度有错误
    if ( TempNetHead->DataLength > ECWNetDefine::MaxNetDataLength )
    {
        //UE_LOG(LogCWReceiveThread, Error, TEXT("FCWReceiveThread::CheckReciveBuffValid, CheckReciveBuffValid Fail, MsgId:%d, DataLength:%d, MaxNetDataLength:%d, ParamPosition:%d."), TempNetHead->MsgId, TempNetHead->DataLength, ECWNetDefine::MaxNetDataLength, ParamPosition);
        CurReceiveBuffLength = 0;
        return nullptr;
    }

    return TempNetHead;
}

bool UCWReceiveThread::AddReceiveMessage( UCWNetMessage* ParamMsg )
{
    check( ParamMsg );

    {
        FScopeLock Lock( &CriticalSection );
        ArrayNetMsg.Insert( ParamMsg, 0 );
    }

    return true;
}

bool UCWReceiveThread::IsThereReceiveMessage()
{
    FScopeLock Lock( &CriticalSection );
    bool r = ArrayNetMsg.Num() > 0;
    return r;
}

UCWNetMessage* UCWReceiveThread::TopMessage()
{
    FScopeLock Lock( &CriticalSection );
    UCWNetMessage* TempMessage = ArrayNetMsg.Top();
    switch ( TempMessage->NetHead.MsgId )
    {
    case ECWNetDefine::CUT_MSGCHILDBEGIN:	// 子消息头
    {
        UCWNetMessage* RetMessage = NewObject<UCWNetMessage>();
        uint16 TempChildCount = TempMessage->NetHead.Child;
        uint32 TempArraySize = ( uint32 )ArrayNetMsg.Num();
        if ( TempArraySize >= ( TempChildCount + 1u ) )
        {
            FCWServerNetHead* TempChildMsgServerNetHead = reinterpret_cast<FCWServerNetHead*>( TempMessage->Data );
            RetMessage->MallocData( TempChildMsgServerNetHead->DataLength );

            check( sizeof( FCWServerNetHead ) == TempMessage->NetHead.DataLength );
            RetMessage->NetHead = *TempChildMsgServerNetHead;
            ArrayNetMsg.Pop();

            // 合并子消息
            uint32 TempCopyLength = 0u;
            uint32 TempLeftLength = TempChildMsgServerNetHead->DataLength;

            for ( uint32 i = 0u; i < TempChildCount; ++i )
            {
                UCWNetMessage* TempChildMessage = ArrayNetMsg.Top();

                // 不是子消息, 直接返回null
                if ( TempChildMessage == nullptr || TempChildMessage->NetHead.MsgId != ECWNetDefine::CUT_MSGCHILD )
                {
                    return nullptr;
                }

                // 长度不足, 返回null
                if ( TempLeftLength < TempChildMessage->NetHead.DataLength )
                {
                    ArrayNetMsg.Pop();
                    return nullptr;
                }

                memcpy( RetMessage->Data + TempCopyLength, TempChildMessage->Data, TempChildMessage->NetHead.DataLength );
                TempCopyLength += TempChildMessage->NetHead.DataLength;
                TempLeftLength -= TempChildMessage->NetHead.DataLength;

                ArrayNetMsg.Pop();
            }
        }
        else
        {
            // 如果超出了最大的队列长度
            //if (TempChildCount >= ArrayNetMsg.Num())
            //{
            //	ArrayNetMsg.Pop();
            //}
            return nullptr;
        }

        return RetMessage;
    }
    break;
    case ECWNetDefine::CUT_MSGCHILD:		// 如果取到的是子消息, 直接丢掉
    {
        ArrayNetMsg.Pop();
        return nullptr;
    }
    break;
    }

    return TempMessage;
}

void UCWReceiveThread::PopMessage()
{
    FScopeLock Lock( &CriticalSection );
    if ( ArrayNetMsg.Num() > 0 )
    {
        ArrayNetMsg.Pop();
    }
}