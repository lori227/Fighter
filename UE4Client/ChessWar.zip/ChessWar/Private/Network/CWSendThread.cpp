#include "CWSendThread.h"
#include "Sockets.h"
#include "CWNetMessage.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWSendThread, All, All);

UCWSendThread::UCWSendThread(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ClientSocket(nullptr)
	, MessageHeadLength(0)
	, CurSendBuffLength(0)
	, bIsSending(false)
{
	memset(ReqSendBuffer, 0, sizeof(ReqSendBuffer));
}

UCWSendThread::~UCWSendThread()
{

}

bool UCWSendThread::IsFinished()
{
	return false;
}

int32 UCWSendThread::ThreadBody()
{
	if (ClientSocket == nullptr)
	{
		return 0;
	}

	//�������ݰ�
	if (ClientSocket->GetConnectionState() != SCS_Connected)
	{
		// Socket�Ͽ�����
		Stop();
	}
	else
	{
		if (CurSendBuffLength == 0)
		{
			do
			{
				// ��Ϣ����Ϊ��
				if (ArrayNetMsg.Num() <= 0)
				{
					break;
				}

				FScopeLock Lock(&CriticalSection);
				if (ArrayNetMsg.Num() <= 0)
				{
					break;
				}

				UCWNetMessage* TempMsg = ArrayNetMsg.Top();
				if (TempMsg == nullptr)
				{
					break;
				}

				// ������󳤶�
				if (!CheckBufferLength(CurSendBuffLength, TempMsg->NetHead.DataLength))
				{
					break;
				}

				memcpy(ReqSendBuffer + CurSendBuffLength, &TempMsg->NetHead, MessageHeadLength);
				CurSendBuffLength += MessageHeadLength;

				if (TempMsg->NetHead.DataLength > 0)
				{
					memcpy(ReqSendBuffer + CurSendBuffLength, TempMsg->Data, TempMsg->NetHead.DataLength);
					CurSendBuffLength += TempMsg->NetHead.DataLength;
				}

				// �ͷ��ڴ�
				ArrayNetMsg.Pop();
				//TempMsg->ConditionalBeginDestroy();
				TempMsg = nullptr;
			} while (true);
		}

		if (CurSendBuffLength > 0)
		{
			SocketSend(ReqSendBuffer, CurSendBuffLength);
		}
	}

	FPlatformProcess::Sleep(0.01f);
	return 1;
}

void UCWSendThread::SetClientSocket(FSocket* ParamClientSocket)
{
	check(ParamClientSocket);
	ClientSocket = ParamClientSocket;
}

void UCWSendThread::SetMessageHeadLength(uint32 ParamMessageHeadLength)
{
	MessageHeadLength = ParamMessageHeadLength;
}

bool UCWSendThread::AddSendMessage(UCWNetMessage* ParamNetMsg)
{
	{
		FScopeLock Lock(&CriticalSection);
		ArrayNetMsg.Push(ParamNetMsg);
	}
	return true;
}

void UCWSendThread::OnSendOK()
{
	CurSendBuffLength = 0;
	bIsSending = false;
}

void UCWSendThread::OnSendFail()
{
	CurSendBuffLength = 0;
	bIsSending = false;
}

void UCWSendThread::SocketSend(uint8* ParamBuffer, int32 ParamLength)
{
	check(ParamBuffer);
	if (ParamLength <= 0)
	{
		return;
	}
	
	bIsSending = true;

	check(ClientSocket);
	int32 TempRemainLength = ParamLength;
	int32 TempCurBytesSend = 0;
	int32 TempBytesSend = 0;
	check(TempCurBytesSend < ParamLength);
	while (ClientSocket->Send((uint8*)ParamBuffer + TempCurBytesSend, TempRemainLength, TempBytesSend))
	{
		TempCurBytesSend += TempBytesSend;
		TempRemainLength -= TempBytesSend;
		if (TempRemainLength <= 0)
		{
			OnSendOK();
			break;
		}
	}
	
	if (TempRemainLength > 0)
	{
		//UE_LOG(LogCWSendThread, Error, TEXT("FCWSendThread::SocketSend Failed."));
		OnSendFail();
	}
}

bool UCWSendThread::CheckBufferLength(uint32 ParamCurSendBuffLength, uint32 ParamDataLength)
{
	if (ParamCurSendBuffLength + MessageHeadLength + ParamDataLength <= ECWNetDefine::MaxReqBuffLength)
	{
		return true;
	}

	return false;
}