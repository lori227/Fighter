#include "CWTCPClient.h"
#include "CWGameInstance.h"
#include "CWSendThread.h"
#include "CWReceiveThread.h"
#include "CWClientNetHead.h"
#include "CWSluaManager.h"
#include "LuaState.h"
#include "Proto/FrameClientMessage.pb.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWTCPClient, All, All);

UCWTCPClient::UCWTCPClient(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

bool UCWTCPClient::Init()
{
	GI = UCWGameInstance::GetInstance();
	check(GI);

	//�����ͻ���socket
	ClientSocket = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateSocket(NAME_Stream, TEXT("default"), false);

	if (ClientSocket == nullptr)
	{
		//����Socketʧ��
		UE_LOG(LogCWTCPClient, Error, TEXT("UCWTCPClient::Init, CreateSocket Fail."));
		return false;
	}

	if (CreateReceiveThread() == false)
	{
		return false;
	}

	if (CreateSendThread() == false)
	{
		return false;
	}

	UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::Init Success, %16X."), ClientSocket);
	return true;
}

void UCWTCPClient::Destroy()
{
	ReceiveThreadEnd();
	SendThreadEnd();
}

void UCWTCPClient::Tick(float ParamDeltaTime)
{
	ProcessReceiveMessage(ParamDeltaTime);
}

void UCWTCPClient::ProcessReceiveMessage(float ParamDeltaTime)
{
	if (ReceiveThread != nullptr)
	{
		if (ReceiveThread->IsThereReceiveMessage())
		{
			UCWNetMessage* TempNetMessage = ReceiveThread->TopMessage();
			if (TempNetMessage != nullptr)
			{
				UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::ProcessReceiveMessage, MsgId:%d."), TempNetMessage->NetHead.MsgId);

				if (TempNetMessage->NetHead.MsgId == 101)
				{
					KFMsg::MsgLoginAck LoginAck;
					LoginAck.ParseFromArray(TempNetMessage->Data, TempNetMessage->NetHead.DataLength);
					UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::ProcessReceiveMessage, MsgId:%d, Playerid:%I64u."), TempNetMessage->NetHead.MsgId, LoginAck.playerid());
				}

				if (TempNetMessage->NetHead.MsgId == 1)
				{
					KFMsg::MsgResultDisplay Result;
					Result.ParseFromArray(TempNetMessage->Data, TempNetMessage->NetHead.DataLength);
					UE_LOG(LogCWTCPClient, Warning, TEXT("UCWTCPClient::ProcessReceiveMessage, MsgId:%d, result:%d."), TempNetMessage->NetHead.MsgId, Result.result());
				}

				check(GI);
				check(GI->GetSluaMgr());
				check(GI->GetSluaMgr()->ClientLuaState());
				auto state = GI->GetSluaMgr()->ClientLuaState();
				slua::LuaVar v = state->call("mainClient.ProcessReceiveMessage", TempNetMessage->NetHead.MsgId, (const char*)(TempNetMessage->Data), TempNetMessage->NetHead.DataLength);
				if (!v.isNil())
				{
					slua::Log::Log("mainClient ProcessReceiveMessage return value is %d", v.getAt(1).asInt());
				}
			}

			ReceiveThread->PopMessage();
		}
	}
}

bool UCWTCPClient::Connect(const FString& ParamIP, int32 ParamPort)
{
	//�������ParamIPתΪIPv4��ַ
	FIPv4Address::Parse(ParamIP, IPv4Address);    

	//����addr���IPv4��ַ�Ͷ˿�
	InternetAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
	if (!InternetAddr.IsValid())
	{
		//����addrʧ��
		UE_LOG(LogCWTCPClient, Error, TEXT("UCWTCPClient::Connect, CreateInternetAddr Fail, IP:%s, Port:%d."), *ParamIP, ParamPort);
		return false;
	}
	check(InternetAddr);
	InternetAddr->SetIp(IPv4Address.Value);
	InternetAddr->SetPort(ParamPort);

	check(ClientSocket);
	if (ClientSocket->Connect(*InternetAddr))
	{
		check(ReceiveThread);
		ReceiveThread->CreateThread(FString(TEXT("ReceiveThread")));

		check(SendThread);
		SendThread->CreateThread(FString(TEXT("SendThread")));

		//���ӳɹ�
		UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::Connect, Connect Succeed, IP:%s, Port:%d."), *ParamIP, ParamPort);
		return true;
	}
	else
	{
		//����ʧ��
		UE_LOG(LogCWTCPClient, Error, TEXT("UCWTCPClient::Connect, Connect Failed, IP:%s, Port:%d."), *ParamIP, ParamPort);
		return false;
	}
}

bool UCWTCPClient::Send(UCWNetMessage* ParamNetMsg)
{
	check(SendThread);
	return SendThread->AddSendMessage(ParamNetMsg);
}

bool UCWTCPClient::CreateReceiveThread()
{
	ReceiveThread = NewObject<UCWReceiveThread>();
	if (ReceiveThread == nullptr)
	{
		UE_LOG(LogCWTCPClient, Error, TEXT("UCWTCPClient::CreateReceiveThread, Create Thread Failed."));
		return false;
	}

	ReceiveThread->SetClientSocket(ClientSocket);
	uint32 TempHeadLength = sizeof(FCWClientNetHead);
	ReceiveThread->SetMessageHeadLength(TempHeadLength);
	UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::CreateReceiveThread, Create Thread Success."));
	return true;
}

bool UCWTCPClient::CreateSendThread()
{
	SendThread = NewObject<UCWSendThread>();
	if (SendThread == nullptr)
	{
		UE_LOG(LogCWTCPClient, Error, TEXT("UCWTCPClient::CreateSendThread, Create Thread Failed."));
		return false;
	}

	SendThread->SetClientSocket(ClientSocket);
	uint32 TempHeadLength = sizeof(FCWClientNetHead);
	SendThread->SetMessageHeadLength(TempHeadLength);
	UE_LOG(LogCWTCPClient, Log, TEXT("UCWTCPClient::CreateSendThread, Create Thread Success."));
	return true;
}

bool UCWTCPClient::ReceiveThreadEnd()
{
	if (ReceiveThread != nullptr)
	{
		ReceiveThread->Stop();
		ReceiveThread->ConditionalBeginDestroy();
		ReceiveThread = nullptr;
	}
	return true;
}

bool UCWTCPClient::SendThreadEnd()
{
	if (SendThread != nullptr)
	{
		SendThread->Stop();
		SendThread->ConditionalBeginDestroy();
		SendThread = nullptr;
	}
	return true;
}

FString UCWTCPClient::StringFromBinaryArray(const TArray<uint8>& BinaryArray)
{
	return FString(ANSI_TO_TCHAR(reinterpret_cast<const char*>(BinaryArray.GetData())));
}