﻿#include "CWTCPServerClient.h"
#include "CWGameInstance.h"
#include "CWSendThread.h"
#include "CWReceiveThread.h"
#include "CWServerNetHead.h"
#include "Proto/FrameClientMessage.pb.h"
#include "Proto/FrameMessage.pb.h"
#include "CWCommandMgr.h"
#include "CWUtils.h"

DECLARE_LOG_CATEGORY_CLASS( LogCWTCPServerClient, All, All );

UCWTCPServerClient::UCWTCPServerClient( const FObjectInitializer& ObjectInitializer )
    : Super( ObjectInitializer )
{
    ReceiveMessageCallbackFn = nullptr;
}

bool UCWTCPServerClient::Init()
{
    GI = UCWGameInstance::GetInstance();
    check( GI );

    //创建客户端socket
    ClientSocket = ISocketSubsystem::Get( PLATFORM_SOCKETSUBSYSTEM )->CreateSocket( NAME_Stream, TEXT( "default" ), false );

    if ( ClientSocket == nullptr )
    {
        //创建Socket失败
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::Init, CreateSocket Fail." ) );
        return false;
    }

    if ( CreateReceiveThread() == false )
    {
        return false;
    }

    if ( CreateSendThread() == false )
    {
        return false;
    }

    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::Init Success." ) );
    return true;
}

void UCWTCPServerClient::Destroy()
{
    ReceiveThreadEnd();
    SendThreadEnd();
}

void UCWTCPServerClient::Tick( float ParamDeltaTime )
{
    ProcessReceiveMessage( ParamDeltaTime );
}

void UCWTCPServerClient::ProcessReceiveMessage( float ParamDeltaTime )
{
    if ( ReceiveThread != nullptr )
    {
        if ( ReceiveThread->IsThereReceiveMessage() )
        {
            UCWNetMessage* TempNetMessage = ReceiveThread->TopMessage();
            if ( TempNetMessage != nullptr )
            {
                UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::ProcessReceiveMessage, MsgId:%d." ), TempNetMessage->NetHead.MsgId );

                if ( TempNetMessage->NetHead.MsgId == 1 )
                {
                    KFMsg::MsgResultDisplay Result;
                    Result.ParseFromArray( TempNetMessage->Data, TempNetMessage->NetHead.DataLength );
                    UE_LOG( LogCWTCPServerClient, Warning, TEXT( "UCWTCPServerClient::ProcessReceiveMessage, MsgId:%d, result:%d." ), TempNetMessage->NetHead.MsgId, Result.result() );
                }

                if ( ReceiveMessageCallbackFn != nullptr )
                {
                    ReceiveMessageCallbackFn( TempNetMessage );
                }

                if ( ReceiveThread != nullptr )
                {
                    ReceiveThread->PopMessage();
                }
            }
        }
    }
}

bool UCWTCPServerClient::Connect( const FString& ParamIP, int32 ParamPort )
{
    //将传入的ParamIP转为IPv4地址
    FIPv4Address::Parse( ParamIP, IPv4Address );

    //创建addr存放IPv4地址和端口
    InternetAddr = ISocketSubsystem::Get( PLATFORM_SOCKETSUBSYSTEM )->CreateInternetAddr();
    if ( !InternetAddr.IsValid() )
    {
        //创建addr失败
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::Connect, CreateInternetAddr Fail, IP:%s, Port:%d." ), *ParamIP, ParamPort );
        return false;
    }
    check( InternetAddr );
    InternetAddr->SetIp( IPv4Address.Value );
    InternetAddr->SetPort( ParamPort );

    check( ClientSocket );
    if ( ClientSocket->Connect( *InternetAddr ) )
    {
        check( ReceiveThread );
        ReceiveThread->CreateThread( FString( TEXT( "ReceiveThread" ) ) );

        check( SendThread );
        SendThread->CreateThread( FString( TEXT( "SendThread" ) ) );

        //连接成功
        UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::Connect, Connect Succeed, IP:%s, Port:%d." ), *ParamIP, ParamPort );
        return true;
    }
    else
    {
        //连接失败
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::Connect, Connect Failed, IP:%s, Port:%d." ), *ParamIP, ParamPort );
        return false;
    }
}

bool UCWTCPServerClient::Disconnect()
{
    ReceiveThreadEnd();
    SendThreadEnd();

    if ( ClientSocket != nullptr )
    {
        ClientSocket->Close();
        ClientSocket = nullptr;
    }

    //创建客户端socket
    ClientSocket = ISocketSubsystem::Get( PLATFORM_SOCKETSUBSYSTEM )->CreateSocket( NAME_Stream, TEXT( "default" ), false );

    if ( ClientSocket == nullptr )
    {
        //创建Socket失败
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::Disconnect, CreateSocket Fail." ) );
        return false;
    }

    if ( CreateReceiveThread() == false )
    {
        return false;
    }

    if ( CreateSendThread() == false )
    {
        return false;
    }

    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::Disconnect Success." ) );
    return true;
}

bool UCWTCPServerClient::Send( UCWNetMessage* ParamNetMsg )
{
    check( SendThread );
    return SendThread->AddSendMessage( ParamNetMsg );
}


ESocketConnectionState UCWTCPServerClient::GetConnectionState()
{
	if (ClientSocket == nullptr)
	{
		return ESocketConnectionState::SCS_NotConnected;
	}

	return ClientSocket->GetConnectionState();
}

bool UCWTCPServerClient::CreateReceiveThread()
{
    ReceiveThread = NewObject<UCWReceiveThread>();
    if ( ReceiveThread == nullptr )
    {
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::CreateReceiveThread, Create Thread Failed." ) );
        return false;
    }

    ReceiveThread->SetClientSocket( ClientSocket );
    uint32 TempHeadLength = sizeof( FCWServerNetHead );
    ReceiveThread->SetMessageHeadLength( TempHeadLength );
    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::CreateReceiveThread, Create Thread Success." ) );
    return true;
}

bool UCWTCPServerClient::CreateSendThread()
{
    SendThread = NewObject<UCWSendThread>();
    if ( SendThread == nullptr )
    {
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::CreateSendThread, Create Thread Failed." ) );
        return false;
    }

    SendThread->SetClientSocket( ClientSocket );
    uint32 TempHeadLength = sizeof( FCWServerNetHead );
    SendThread->SetMessageHeadLength( TempHeadLength );
    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::CreateSendThread, Create Thread Success." ) );
    return true;
}

bool UCWTCPServerClient::ReceiveThreadEnd()
{
    if ( ReceiveThread != nullptr )
    {
        ReceiveThread->Stop();
        ReceiveThread->ConditionalBeginDestroy();
        ReceiveThread = nullptr;
    }
    return true;
}

bool UCWTCPServerClient::SendThreadEnd()
{
    if ( SendThread != nullptr )
    {
        SendThread->Stop();
        SendThread->ConditionalBeginDestroy();
        SendThread = nullptr;
    }
    return true;
}

FString UCWTCPServerClient::StringFromBinaryArray( const TArray<uint8>& BinaryArray )
{
    return FString( ANSI_TO_TCHAR( reinterpret_cast<const char*>( BinaryArray.GetData() ) ) );
}

void UCWTCPServerClient::SetReceiveMessageCallbackFn( ReceiveMessageCBFn ParamReceiveMessageCBFn )
{
    ReceiveMessageCallbackFn = ParamReceiveMessageCBFn;
}

bool UCWTCPServerClient::SendToRand( const std::string& name, uint32 msgid, ::google::protobuf::Message* message )
{
    return SendToRand( 0u, name, msgid, message );
}

bool UCWTCPServerClient::SendToRand( uint64 sendid, const std::string& name, uint32 msgid, ::google::protobuf::Message* message )
{
    FString TempUEServerId = CWCommandMgr::GetUEServerId();
    if ( TempUEServerId == "" )
    {
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::SendToRand, TempUEServerId == \"\"." ) );
        return false;
    }

    KFMsg::S2SRouteMessageToNameRandReq req;

    auto pbroute = req.mutable_pbroute();
    pbroute->set_sendid( sendid );
    pbroute->set_serverid( FCWUtils::FStringAppId2Uint64Id( TempUEServerId ) );

    std::string strR = message->SerializeAsString();
    req.set_name( name );
    req.set_msgid( msgid );
    req.set_msgdata( strR );

    const std::string strR_route = req.SerializeAsString();
    UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
    TempNetMsg->NetHead.MsgId = KFMsg::S2S_ROUTE_MESSAGE_TO_NAME_RAND_REQ;
    TempNetMsg->CopyData( ( uint8* )strR_route.c_str(), strR_route.length() );
    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::SendToRand, TempUEServerId:%s." ), *TempUEServerId );
    return this->Send( TempNetMsg );
}

bool UCWTCPServerClient::SendToServer( uint64 serverid, uint32 msgid, ::google::protobuf::Message* message )
{
    return SendToServer( 0u, serverid, msgid, message );
}

bool UCWTCPServerClient::SendToServer( uint64 sendid, uint64 serverid, uint32 msgid, ::google::protobuf::Message* message )
{
    FString TempUEServerId = CWCommandMgr::GetUEServerId();
    if ( TempUEServerId == "" )
    {
        UE_LOG( LogCWTCPServerClient, Error, TEXT( "UCWTCPServerClient::SendToServer, TempUEServerId == \"\"." ) );
        return false;
    }

    KFMsg::S2SRouteMessageToServerReq req;

    auto pbroute = req.mutable_pbroute();
    pbroute->set_sendid( sendid );
    pbroute->set_recvid( serverid );
    pbroute->set_serverid( FCWUtils::FStringAppId2Uint64Id( TempUEServerId ) );

    std::string strR = message->SerializeAsString();
    req.set_msgid( msgid );
    req.set_msgdata( strR );

    const std::string strR_server = req.SerializeAsString();
    UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
    TempNetMsg->NetHead.MsgId = KFMsg::S2S_ROUTE_MESSAGE_TO_SERVER_REQ;
    TempNetMsg->CopyData( ( uint8* )strR_server.c_str(), strR_server.length() );
    UE_LOG( LogCWTCPServerClient, Log, TEXT( "UCWTCPServerClient::SendToServer, TempUEServerId:%s." ), *TempUEServerId );
    return this->Send( TempNetMsg );
}