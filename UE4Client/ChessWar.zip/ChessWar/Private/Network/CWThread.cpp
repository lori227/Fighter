#include "CWThread.h"
#include "Sockets.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWThread, All, All);

UCWThread::UCWThread(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Thread(nullptr)
	, StopTaskCounter(0)
	, ThreadSuspendedEvent(nullptr)
	, Status(EThreadStatus::New)
{
	ThreadSuspendedEvent = FPlatformProcess::GetSynchEventFromPool();
}

UCWThread::~UCWThread()
{
	if (Thread != nullptr)
	{
		delete Thread;
		Thread = nullptr;
	}

	if (ThreadSuspendedEvent != nullptr)
	{
		FPlatformProcess::ReturnSynchEventToPool(ThreadSuspendedEvent);
		ThreadSuspendedEvent = nullptr;
	}
}

bool UCWThread::Init()
{
	//UE_LOG(LogCWThread, Log, TEXT("UCWThread::Init, ThreadName:%s."), *ThreadName);
	Status = EThreadStatus::New;

	return true;
}

uint32 UCWThread::Run()
{
	FPlatformProcess::Sleep(0.03f);
	Status = EThreadStatus::Runnable;

	do
	{
		ThreadBody();
	} while (StopTaskCounter.GetValue() == 0 && !IsFinished());

	Stop();
	return 1;
}

void UCWThread::Stop()
{
	if (Status != EThreadStatus::Terminated)
	{
		StopTaskCounter.Increment();
		Status = EThreadStatus::Terminated;
		//UE_LOG(LogCWThread, Log, TEXT("FCWThread::Stop. ThreadName:%s."), *ThreadName);
	}
}

void UCWThread::Exit()
{
	if (Status != EThreadStatus::Terminated)
	{
		StopTaskCounter.Increment();
		Status = EThreadStatus::Terminated;
		//UE_LOG(LogCWThread, Log, TEXT("FCWThread::Exit. ThreadName:%s."), *ThreadName);
	}
}

//bool UCWThread::IsFinished_Implementation()
bool UCWThread::IsFinished()
{
	return false;
}

//int32 UCWThread::ThreadBody_Implementation()
int32 UCWThread::ThreadBody()
{
	return 0;
}

EThreadStatus UCWThread::GetThreadStatus()
{
	return Status;
}

void UCWThread::EnsureCompletion()
{
	if (Thread != nullptr)
	{
		Thread->Kill(true);
		Stop();
		Thread->WaitForCompletion();
	}
}

void UCWThread::Suspend()
{
	check(ThreadSuspendedEvent);
	ThreadSuspendedEvent->Wait();
	Status = EThreadStatus::Waiting;
}

void UCWThread::Resume()
{
	check(ThreadSuspendedEvent);
	ThreadSuspendedEvent->Trigger();
	Status = EThreadStatus::Runnable;
}

void UCWThread::TaskSleep(float ParamSeconds)
{
	FPlatformProcess::Sleep(ParamSeconds);
}

void UCWThread::CreateThread(const FString& ParamThreadName)
{
	ThreadName = ParamThreadName;
	Thread = FRunnableThread::Create(this, *ThreadName);
}