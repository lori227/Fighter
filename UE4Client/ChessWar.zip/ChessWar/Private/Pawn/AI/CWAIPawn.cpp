﻿
#include "CWAIPawn.h"
#include "Engine.h"
#include "CWAIPawnPath.h"
#include "Kismet/KismetMathLibrary.h"
#include "UnrealNetwork.h"
#include "CWComDef.h"
#include "CWCommonUtil.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWAIPawn, All, All);

ACWAIPawn::ACWAIPawn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;
}

void ACWAIPawn::BeginPlay()
{
	Super::BeginPlay();
}

void ACWAIPawn::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (IsPendingKill() || !HasAuthority())
		return;
}

bool ACWAIPawn::NetMulticastRPCDoFall_Validate(FVector location, FRotator rotation)
{
	return true;
}

void ACWAIPawn::NetMulticastRPCDoFall_Implementation(FVector location, FRotator rotation)
{
	OnDoFallInClient.Broadcast(this, location, rotation);
}

//bool ACWAIPawn::NetMulticastRPCDoFallWarn_Validate(FVector location, FRotator rotation)
//{
//	return true;
//}
//
//void ACWAIPawn::NetMulticastRPCDoFallWarn_Implementation(FVector location, FRotator rotation)
//{
//	OnDoFallWarnInClient.Broadcast(this, location, rotation);
//}
//
//bool ACWAIPawn::NetMulticastRPCDoHideWarn_Validate(FVector location, FRotator rotation)
//{
//	return true;
//}
//
//void ACWAIPawn::NetMulticastRPCDoHideWarn_Implementation(FVector location, FRotator rotation)
//{
//	OnDoHideWarnInClient.Broadcast(this, location, rotation);
//}
