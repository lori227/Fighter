
#include "CWAIPawnPath.h"

#include "UnrealNetwork.h"
#include "Components/SphereComponent.h"


ACWAIPawnPath::ACWAIPawnPath(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PathIdx(INDEX_NONE)
{
	bHidden = true;
	bReplicates = true;
	bCanBeDamaged = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	SphereComp = CreateDefaultSubobject<USphereComponent>("SphereComp");
	SphereComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SphereComp->SetCollisionResponseToAllChannels(ECR_Ignore);
	SphereComp->ShapeColor = FColor(0, 255, 0, 255);
	SphereComp->SetCanEverAffectNavigation(false);
	SphereComp->SetGenerateOverlapEvents(false);
	SphereComp->SetEnableGravity(false);
	SphereComp->bHiddenInGame = false;
	SphereComp->InitSphereRadius(10.f);
	SetRootComponent(SphereComp);
}

ACWAIPawnPath::~ACWAIPawnPath()
{
}

void ACWAIPawnPath::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWAIPawnPath, PathIdx);
}

int32 ACWAIPawnPath::GetPathIdx() const
{
	return PathIdx;
}

bool ACWAIPawnPath::IsValidPath() const
{
	return PathIdx != INDEX_NONE && PathIdx >= 0;
}

int32 ACWAIPawnPath::SetPathIdx(const int32 InPathIdx)
{
	PathIdx = InPathIdx;
	return PathIdx;
}
