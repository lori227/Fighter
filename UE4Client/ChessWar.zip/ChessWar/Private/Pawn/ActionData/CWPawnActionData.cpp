#include "CWPawnActionData.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionData, All, All);

UCWPawnActionData::UCWPawnActionData(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ActionId = ECWPawnActionState::None;
}

UCWPawnActionData::~UCWPawnActionData()
{

}