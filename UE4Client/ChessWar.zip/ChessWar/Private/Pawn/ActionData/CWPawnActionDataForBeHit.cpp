#include "CWPawnActionDataForBeHit.h"


UCWPawnActionDataForBeHit::UCWPawnActionDataForBeHit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PawnCampTag = ECWCampTag::None;
	PawnCampControllerIndex = ECWCampControllerIndex::None;
	PawnControllerPawnIndex = -1;
	PawnSkillId = -1;
	bIsCounterAttack = false;
}

UCWPawnActionDataForBeHit::~UCWPawnActionDataForBeHit()
{

}
#pragma once
