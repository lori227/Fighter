#include "CWPawnActionDataForCastSkill.h"


UCWPawnActionDataForCastSkill::UCWPawnActionDataForCastSkill(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SkillId = -1;
	TargetTile = -1;
}

UCWPawnActionDataForCastSkill::~UCWPawnActionDataForCastSkill()
{

}
