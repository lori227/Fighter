#include "CWPawnActionDataForCounterAttack.h"


UCWPawnActionDataForCounterAttack::UCWPawnActionDataForCounterAttack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	TargetTile = -1;
}

UCWPawnActionDataForCounterAttack::~UCWPawnActionDataForCounterAttack()
{

}
