#include "CWPawnActionDataForDeath.h"


UCWPawnActionDataForDeath::UCWPawnActionDataForDeath(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

UCWPawnActionDataForDeath::~UCWPawnActionDataForDeath()
{

}
