#include "CWPawnActionDataForDie.h"


UCWPawnActionDataForDie::UCWPawnActionDataForDie(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

UCWPawnActionDataForDie::~UCWPawnActionDataForDie()
{

}
