#include "CWPawnActionDataForDizziness.h"


UCWPawnActionDataForDizziness::UCWPawnActionDataForDizziness(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

UCWPawnActionDataForDizziness::~UCWPawnActionDataForDizziness()
{

}
