#include "CWPawnActionDataForEnd.h"


UCWPawnActionDataForEnd::UCWPawnActionDataForEnd(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	OldActionState = ECWPawnActionState::None;
	bIsTriggerEvent = false;
	bIsForceToEnd = false;
}

UCWPawnActionDataForEnd::~UCWPawnActionDataForEnd()
{

}
