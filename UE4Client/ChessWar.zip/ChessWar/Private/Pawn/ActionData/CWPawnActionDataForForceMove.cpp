#include "CWPawnActionDataForForceMove.h"


UCWPawnActionDataForForceMove::UCWPawnActionDataForForceMove(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	CasterTile = -1;
	ForceMoveTileArray;
}

UCWPawnActionDataForForceMove::~UCWPawnActionDataForForceMove()
{

}
