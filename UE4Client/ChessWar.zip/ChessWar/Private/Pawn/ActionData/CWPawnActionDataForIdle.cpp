#include "CWPawnActionDataForIdle.h"


UCWPawnActionDataForIdle::UCWPawnActionDataForIdle(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

UCWPawnActionDataForIdle::~UCWPawnActionDataForIdle()
{

}
