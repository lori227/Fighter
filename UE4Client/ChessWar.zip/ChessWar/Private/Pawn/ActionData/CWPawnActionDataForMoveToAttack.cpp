#include "CWPawnActionDataForMoveToAttack.h"


UCWPawnActionDataForMoveToAttack::UCWPawnActionDataForMoveToAttack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	AttackModeType = ECWAttackModeType::None;
	SkillId = -1;
	TargetTile = -1;
	MoveDestTile = -1;
}

UCWPawnActionDataForMoveToAttack::~UCWPawnActionDataForMoveToAttack()
{

}
