#include "CWPawnActionDataForMoveToDest.h"


UCWPawnActionDataForMoveToDest::UCWPawnActionDataForMoveToDest(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	DestTile = -1;
}

UCWPawnActionDataForMoveToDest::~UCWPawnActionDataForMoveToDest()
{

}
