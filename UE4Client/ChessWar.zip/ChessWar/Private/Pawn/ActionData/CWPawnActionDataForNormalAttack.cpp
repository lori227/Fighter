#include "CWPawnActionDataForNormalAttack.h"


UCWPawnActionDataForNormalAttack::UCWPawnActionDataForNormalAttack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	TargetTile = -1;
}

UCWPawnActionDataForNormalAttack::~UCWPawnActionDataForNormalAttack()
{

}
