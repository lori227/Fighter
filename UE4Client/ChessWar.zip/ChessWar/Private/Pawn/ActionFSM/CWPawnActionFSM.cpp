#include "CWPawnActionFSM.h"
#include "Pawn/CWPawn.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionFSM, All, All);

UCWPawnActionFSM::UCWPawnActionFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	Parent = nullptr;
	PreState = ECWPawnActionState::None;
	CurState = ECWPawnActionState::None;
	NextState = ECWPawnActionState::None;
	NextActionData = nullptr;
}

void UCWPawnActionFSM::Init(ACWPawn* ParamParent)
{
	Parent = ParamParent;
}

ACWPawn* UCWPawnActionFSM::GetParentPawn()
{
	return Parent;
}

void UCWPawnActionFSM::BeginDestroy()
{
	Super::BeginDestroy();
}

bool UCWPawnActionFSM::DoEvent(const FCWFSMEvent* ParamEvent)
{
	return true;
}

void UCWPawnActionFSM::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	StateProcess(DeltaTime);
}

bool UCWPawnActionFSM::Startup(int StateId)
{
	if (Super::Startup(StateId))
	{
		CurState = (ECWPawnActionState)StateId;
		return true;
	}

	return false;
}

ECWPawnActionState UCWPawnActionFSM::GetPreState()
{
	return PreState;
}

ECWPawnActionState UCWPawnActionFSM::GetCurState()
{
	return CurState;
}

ECWPawnActionState UCWPawnActionFSM::GetNextState()
{
	return NextState;
}

UCWPawnActionStateBase*	UCWPawnActionFSM::GetCurStateInstance()
{
	StateMap::iterator StateMapIter = MapStates.find((int)CurState);
	if (StateMapIter == MapStates.end())
	{
		UE_LOG(LogCWPawnActionFSM, Error, TEXT("UCWPawnActionFSM::GetCurStateInstance fail. CurState:%d."), (int32)CurState);
		return nullptr;
	}

	UCWPawnActionStateBase* TempCurStateInstance = (UCWPawnActionStateBase*)(StateMapIter->second);
	check(TempCurStateInstance);
	return TempCurStateInstance;
}

void UCWPawnActionFSM::OnAnimFinish(int32 RoundIndex)
{
	UCWPawnActionStateBase* TempCurActionState = GetCurStateInstance();
	check(TempCurActionState);
	TempCurActionState->OnAnimFinish(RoundIndex);
}

void UCWPawnActionFSM::StateProcess(float DeltaTime)
{
	UCWPawnActionStateBase* TempCurActionState = GetCurStateInstance();
	check(TempCurActionState);
	ECWPawnActionStateProcess TempStateProcessResult = TempCurActionState->OnProcess(DeltaTime);
	if (TempStateProcessResult == ECWPawnActionStateProcess::HOLD)
		return;

	bool bCommitStateChange = false;
	if (TempStateProcessResult == ECWPawnActionStateProcess::END)
	{
		if (GetNextState() == ECWPawnActionState::None)
		{
			NextState = ECWPawnActionState::Idle;
		}

		bCommitStateChange = true;
	}
	else if (TempStateProcessResult == ECWPawnActionStateProcess::SUSPEND)
	{
		if (GetNextState() != ECWPawnActionState::None)
			bCommitStateChange = true;
	}
	else
	{
		UE_LOG(LogCWPawnActionFSM, Error, TEXT("UCWPawnActionFSM::StateProcess. TempStateProcessResult:%d."), (int)TempStateProcessResult);
		return;
	}


	if (bCommitStateChange)
	{
		ECWPawnActionStateChange TempCommitResult = CommitChangeState();
		if (TempCommitResult == ECWPawnActionStateChange::FAILED)
		{
			NextState = ECWPawnActionState::Idle;
			ECWPawnActionStateChange rt = CommitChangeState();
			check(rt == ECWPawnActionStateChange::SUCCESS);
		}
	}
}

ECWPawnActionStateChange UCWPawnActionFSM::CommitChangeState()
{
	UCWPawnActionStateBase* TempCurState = GetCurStateInstance();
	check(TempCurState);

	TempCurState->OnEnd();
	PreState = CurState;
	CurState = NextState;
	NextState = ECWPawnActionState::None;

	UCWPawnActionStateBase* TempNewState = GetCurStateInstance();
	check(TempNewState);

	ECWPawnActionStateChange TempStartResult = TempNewState->OnStart(NextActionData);
	return TempStartResult;
}

bool UCWPawnActionFSM::SetNextState(ECWPawnActionState ParamNextState, UCWPawnActionData* ParamNextActionData)
{
	check((int)ParamNextState != (int)ECWPawnActionState::None);
	check((int)ParamNextState < (int)ECWPawnActionState::Max);

	UCWPawnActionStateBase* TempCurState = GetCurStateInstance();
	check(TempCurState);

	if (TempCurState->CanTranstion(ParamNextActionData) == false)
	{
		return false;
	}
	
	NextState = ParamNextState;
	NextActionData = ParamNextActionData;
	return true;
}
