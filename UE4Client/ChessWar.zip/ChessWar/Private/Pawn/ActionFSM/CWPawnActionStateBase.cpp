#include "CWPawnActionStateBase.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWPawnActionForceToEndEvent.h"
#include "CWPawnActionToEndEvent.h"
#include "CWMap.h"
#include "CWGameState.h"

UCWPawnActionStateBase::UCWPawnActionStateBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	Parent = nullptr;
	ActionId = ECWPawnActionState::None;
	bIsAnimFinish = false;
}

UCWPawnActionStateBase::~UCWPawnActionStateBase()
{

}

bool UCWPawnActionStateBase::Init(UCWPawnActionComponent* ParamParent, ECWPawnActionState ParamActionId)
{
	Parent = ParamParent;
	ActionId = ParamActionId;
	return true;
}

ECWPawnActionStateChange UCWPawnActionStateBase::OnStart(UCWPawnActionData* ParamNextActionData)
{
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionStateBase::OnProcess(float DeltaTime)
{
	return ECWPawnActionStateProcess::END;
}

ECWPawnActionStateChange UCWPawnActionStateBase::OnEnd()
{
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionStateBase::OnAnimFinish(int32 RoundIndex)
{

}

bool UCWPawnActionStateBase::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	return true;
}

ECWPawnActionState UCWPawnActionStateBase::GetActionId()
{
	return ActionId;
}