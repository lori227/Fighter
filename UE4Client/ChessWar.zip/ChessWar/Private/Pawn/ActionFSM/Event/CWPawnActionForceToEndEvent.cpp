#include "CWPawnActionForceToEndEvent.h"


FCWPawnActionForceToEndEvent::FCWPawnActionForceToEndEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ECWPawnActionState ParamOldActionState)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,OldActionState(ParamOldActionState)
{


}