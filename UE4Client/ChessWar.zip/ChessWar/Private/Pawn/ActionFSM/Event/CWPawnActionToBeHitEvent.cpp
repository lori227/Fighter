#include "CWPawnActionToBeHitEvent.h"


FCWPawnActionToBeHitEvent::FCWPawnActionToBeHitEvent(
	int ParamEventId, 
	int ParamToStateId, 
	ECWFSMStackOp ParamStackOp,
	ECWCampTag ParamPawnCampTag,
	ECWCampControllerIndex ParamPawnCampControllerIndex,
	int32 ParamPawnControllerPawnIndex,
	int32 ParamSkillId)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{
	PawnCampTag = ParamPawnCampTag;
	PawnCampControllerIndex = ParamPawnCampControllerIndex;
	PawnControllerPawnIndex = ParamPawnControllerPawnIndex;
	PawnSkillId = ParamSkillId;
}