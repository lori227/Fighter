#include "CWPawnActionToCastSkillToPawnEvent.h"



FCWPawnActionToCastSkillToPawnEvent::FCWPawnActionToCastSkillToPawnEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamSkillId, ACWPawn* ParamTargetPawn)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,SkillId(ParamSkillId)
	,TargetPawn(ParamTargetPawn)
{


}