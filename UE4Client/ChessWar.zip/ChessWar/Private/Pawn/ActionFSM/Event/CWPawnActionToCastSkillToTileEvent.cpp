#include "CWPawnActionToCastSkillToTileEvent.h"



FCWPawnActionToCastSkillToTileEvent::FCWPawnActionToCastSkillToTileEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamSkillId, int ParamTargetTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,SkillId(ParamSkillId)
	,TargetTile(ParamTargetTile)
{


}