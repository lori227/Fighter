#include "CWPawnActionToDeathEvent.h"



FCWPawnActionToDeathEvent::FCWPawnActionToDeathEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}