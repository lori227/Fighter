#include "CWPawnActionToDieEvent.h"



FCWPawnActionToDieEvent::FCWPawnActionToDieEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}