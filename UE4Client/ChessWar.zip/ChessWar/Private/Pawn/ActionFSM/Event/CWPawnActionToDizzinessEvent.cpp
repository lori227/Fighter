
#include "CWPawnActionToDizzinessEvent.h"


FCWPawnActionToDizzinessEvent::FCWPawnActionToDizzinessEvent(int32 InEventId, int32 InToStateId, ECWFSMStackOp InStackOp)
	: FCWFSMEvent(InEventId, InToStateId, InStackOp)
{
}

FCWPawnActionToDizzinessEvent::~FCWPawnActionToDizzinessEvent()
{
}
