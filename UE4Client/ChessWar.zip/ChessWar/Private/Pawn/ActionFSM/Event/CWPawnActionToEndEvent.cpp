#include "CWPawnActionToEndEvent.h"


FCWPawnActionToEndEvent::FCWPawnActionToEndEvent(
	int ParamEventId, 
	int ParamToStateId, 
	ECWFSMStackOp ParamStackOp,
	ECWPawnActionState ParamOldActionState, 
	bool ParamIsTriggerEvent,
	bool ParamIsForceToEnd)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,OldActionState(ParamOldActionState)
	,bIsTriggerEvent(ParamIsTriggerEvent)
	,bIsForceToEnd(ParamIsForceToEnd)
{


}