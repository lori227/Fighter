
#include "CWPawnActionToForceMoveEvent.h"


FCWPawnActionToForceMoveEvent::~FCWPawnActionToForceMoveEvent()
{
}

FCWPawnActionToForceMoveEvent::FCWPawnActionToForceMoveEvent(
	int32 InEventId, int32 InToStateId, 
	ECWFSMStackOp InStackOp, 
	const int32 InCasterTile,
	TArray<FIntVector/*int32*/> InForceMoveTileArray)
	: FCWFSMEvent(InEventId, InToStateId, InStackOp)
{
	CasterTile = InCasterTile;
	ForceMoveTileArray = InForceMoveTileArray;
}

int32 FCWPawnActionToForceMoveEvent::GetCasterTile()
{
	return CasterTile;
}

const TArray<FIntVector>& FCWPawnActionToForceMoveEvent::GetForceMoveTileArray()
{
	return ForceMoveTileArray;
}
