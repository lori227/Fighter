#include "CWPawnActionToIdleEvent.h"


FCWPawnActionToIdleEvent::FCWPawnActionToIdleEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}