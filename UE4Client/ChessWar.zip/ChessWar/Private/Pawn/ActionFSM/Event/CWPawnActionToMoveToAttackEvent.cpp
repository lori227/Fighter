#include "CWPawnActionToMoveToAttackEvent.h"


FCWPawnActionToMoveToAttackEvent::FCWPawnActionToMoveToAttackEvent(
	int ParamEventId,
	int ParamToStateId,
	ECWFSMStackOp ParamStackOp,
	ECWAttackModeType ParamAttackModeType,
	ECWAttackTargetType ParamAttackTargetType,
	ACWPawn* ParamTargetPawn,
	int ParamTargetTile,
	int ParamMoveDestTile
)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,AttackModeType(ParamAttackModeType)
	,AttackTargetType(ParamAttackTargetType)
	,TargetPawn(ParamTargetPawn)
	,TargetTile(ParamTargetTile)
	,MoveDestTile(ParamMoveDestTile)
{

}