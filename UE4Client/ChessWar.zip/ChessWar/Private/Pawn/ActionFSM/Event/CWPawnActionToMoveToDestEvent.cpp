#include "CWPawnActionToMoveToDestEvent.h"


FCWPawnActionToMoveToDestEvent::FCWPawnActionToMoveToDestEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamDestTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,DestTile(ParamDestTile)
{

}