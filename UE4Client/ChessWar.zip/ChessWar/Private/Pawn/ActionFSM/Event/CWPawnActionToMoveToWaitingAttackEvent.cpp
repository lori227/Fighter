#include "CWPawnActionToMoveToWaitingAttackEvent.h"


FCWPawnActionToMoveToWaitingAttackEvent::FCWPawnActionToMoveToWaitingAttackEvent(
	int ParamEventId,
	int ParamToStateId,
	ECWFSMStackOp ParamStackOp,
	int ParamMoveDestTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,MoveDestTile(ParamMoveDestTile)
{

}