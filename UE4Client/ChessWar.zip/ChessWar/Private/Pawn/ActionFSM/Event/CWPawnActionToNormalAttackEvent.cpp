#include "CWPawnActionToNormalAttackEvent.h"


FCWPawnActionToNormalAttackEvent::FCWPawnActionToNormalAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ACWPawn* ParamTargetPawn)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,TargetPawn(ParamTargetPawn)
{
}