#include "CWPawnActionToWaitingAttackEvent.h"

FCWPawnActionToWaitingAttackEvent::FCWPawnActionToWaitingAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}