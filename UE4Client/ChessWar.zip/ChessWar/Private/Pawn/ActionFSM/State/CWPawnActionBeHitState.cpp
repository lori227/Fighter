#include "CWPawnActionBeHitState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWGameState.h"
#include "CWPawnActionToBeHitEvent.h"
#include "CWSkillDataStruct.h"
#include "CWCommonUtil.h"
#include "CWSkillDataUtils.h"
#include "CWEffectDataStruct.h"
#include "CWEffectDataUtils.h"
#include "CWPawnActionComponent.h"
#include "CWPawnActionDataForBeHit.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionBeHitState, All, All);


UCWPawnActionBeHitState::UCWPawnActionBeHitState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	LimitTime = PAWN_ANIM_TIME_MAX;
	RunningTime = 0.0f;
}

UCWPawnActionBeHitState::~UCWPawnActionBeHitState()
{
}

void UCWPawnActionBeHitState::HandleBeHit(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForBeHit* TempActionDataForBeHit = (UCWPawnActionDataForBeHit*)(ParamNextActionData);
	check(TempActionDataForBeHit);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereAnimSequence(ECWPawnAnim::BeHit01))
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	
	/*ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}*/

	//服务器和客户端都要播放
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		MyPawn->PlayAnimSequence(ECWPawnAnim::BeHit01, 0.0f, 0.0f, 1.0f, 1);
	}

	if (!MyPawn->IsInServer())
	{
		FCWSkillDataStruct* TempSkillData = FCWCommonUtil::FindCSVRow<FCWSkillDataStruct>(TEXT("CWSkillDataTable"), TempActionDataForBeHit->PawnSkillId);
		if (TempSkillData == nullptr)
		{
			UE_LOG(LogCWPawnActionBeHitState, Error, TEXT("UCWPawnActionBeHitState::HandleBeHit fail, TempSkillData == nullptr, PawnSkillId:%d."), TempActionDataForBeHit->PawnSkillId);
			return;
		}
		std::vector<int32> TempArrayBeAttackedEffectId = FCWSkillDataUtils::GetArrayAttackEffectIdFromString(TempSkillData->ArrayBeAttackedEffectId);
		for (int i = 0; i < TempArrayBeAttackedEffectId.size(); ++i)
		{
			int32 TempEffectId = TempArrayBeAttackedEffectId[i];
			MyPawn->AddBeAttackedEffect(TempEffectId);
		}
	}
}

ECWPawnActionStateChange UCWPawnActionBeHitState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForBeHit* TempActionDataForBeHit = (UCWPawnActionDataForBeHit*)(ParamNextActionData);
	check(TempActionDataForBeHit);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereAnimSequence(ECWPawnAnim::BeHit01))
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	//服务器和客户端都要播放
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		MyPawn->PlayAnimSequence(ECWPawnAnim::BeHit01, 0.0f, 0.0f, 1.0f, 1);
	}

	if (!MyPawn->IsInServer())
	{
		FCWSkillDataStruct* TempSkillData = FCWCommonUtil::FindCSVRow<FCWSkillDataStruct>(TEXT("CWSkillDataTable"), TempActionDataForBeHit->PawnSkillId);
		if (TempSkillData == nullptr)
		{
			UE_LOG(LogCWPawnActionBeHitState, Error, TEXT("UCWPawnActionBeHitState::OnStart fail, TempSkillData == nullptr, PawnSkillId:%d."), TempActionDataForBeHit->PawnSkillId);
			return ECWPawnActionStateChange::FAILED;
		}
		std::vector<int32> TempArrayBeAttackedEffectId = FCWSkillDataUtils::GetArrayAttackEffectIdFromString(TempSkillData->ArrayBeAttackedEffectId);
		for (int i = 0; i < TempArrayBeAttackedEffectId.size(); ++i)
		{
			int32 TempEffectId = TempArrayBeAttackedEffectId[i];
			MyPawn->AddBeAttackedEffect(TempEffectId);
		}
	}

	ACWPawn* TargetPawn = nullptr;
	for (TActorIterator<ACWPawn> Iter(MyPawn->GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr &&
			TempPawn->GetCampTag() == TempActionDataForBeHit->PawnCampTag &&
			TempPawn->GetCampControllerIndex() == TempActionDataForBeHit->PawnCampControllerIndex &&
			TempPawn->GetControllerPawnIndex() == TempActionDataForBeHit->PawnControllerPawnIndex)
		{
			TargetPawn = TempPawn;
			break;
		}
	}

	//反击
	if (MyPawn->IsInServer())
	{
		if (!TempActionDataForBeHit->bIsCounterAttack)
		{
			if (MyPawn->GetPawnType() == ECWPawnType::Character)
			{
				if (TargetPawn != nullptr && TargetPawn->GetPawnType() == ECWPawnType::Character)
				{
					uint8 TempMoveAttackDamage = 0x00;
					TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
					TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
					if (MyPawn->IsAttackTileFromTileForNormalAttack(MyPawn->GetTile(), TargetPawn->GetTile(), TempMoveAttackDamage))
					{
						MyPawn->CounterAttackToTileInServer(TargetPawn->GetTile());
					}
				}
			}
		}
	}

	UE_LOG(LogCWPawnActionBeHitState, Log, TEXT("UCWPawnActionBeHitState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionBeHitState::OnProcess(float DeltaTime)
{
	RunningTime += DeltaTime;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	if (bIsAnimFinish || RunningTime > LimitTime)
	{
		if (MyPawn->ProcessNextAction())
		{ 
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionBeHitState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	UE_LOG(LogCWPawnActionBeHitState, Log, TEXT("UCWPawnActionBeHitState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionBeHitState::OnAnimFinish(int32 RoundIndex)
{
	bIsAnimFinish = true;
}

bool UCWPawnActionBeHitState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CounterAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;
			
		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}