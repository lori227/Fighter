#include "CWPawnActionCastSkillToPawnState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWGameState.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWPawnActionToCastSkillToPawnEvent.h"
#include "CWSkill.h"
#include "CWPawnActionDataForCastSkill.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionCastSkillToPawnState, All, All);


UCWPawnActionCastSkillToPawnState::UCWPawnActionCastSkillToPawnState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	LimitTime = PAWN_ANIM_TIME_MAX;
	RunningTime = 0.0f;
}

UCWPawnActionCastSkillToPawnState::~UCWPawnActionCastSkillToPawnState()
{
}

ECWPawnActionStateChange UCWPawnActionCastSkillToPawnState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForCastSkill* TempActionDataForCastSkill = (UCWPawnActionDataForCastSkill*)ParamNextActionData;
	check(TempActionDataForCastSkill);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereAnimSequence(TempActionDataForCastSkill->SkillId))
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyGameState->GetCurRoundIndex());
	}

	bool Result = MyPawn->CastSkillToTile(TempActionDataForCastSkill->SkillId, TempActionDataForCastSkill->TargetTile);
	if (Result)
	{
		UE_LOG(LogCWPawnActionCastSkillToPawnState, Log, TEXT("UCWPawnActionCastSkillToPawnState::OnStart CastSkillToTile Success, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, SkillId:%d, TargetTile:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex(), TempActionDataForCastSkill->SkillId, TempActionDataForCastSkill->TargetTile);
	}
	else
	{
		UE_LOG(LogCWPawnActionCastSkillToPawnState, Error, TEXT("UCWPawnActionCastSkillToPawnState::OnStart CastSkillToPawn fail, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, SkillId:%d, TargetTile:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex(), TempActionDataForCastSkill->SkillId, TempActionDataForCastSkill->TargetTile);
	}
	//------------------------------------------------------------------------
	//关键时间点触发 技能开始
	MyPawn->OnKeyTimeInServer(ECWKeyTimeType::InitiativeSkillBegin);
	//------------------------------------------------------------------------

	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionCastSkillToPawnState::OnProcess(float DeltaTime)
{
	RunningTime += DeltaTime;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	if (bIsAnimFinish || RunningTime > LimitTime)
	{
		if (MyPawn->ProcessNextAction())
		{
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionCastSkillToPawnState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	//------------------------------------------------------------------------
	//关键时间点触发 技能结束
	MyPawn->OnKeyTimeInServer(ECWKeyTimeType::InitiativeSkillEnd);
	//------------------------------------------------------------------------

	// 清理当前移动攻击移动步数
	UCWStatisticsSystemCtrl* StatisticsSys = MyPawn->GetStatisticsSysCtrl();
	if (IsValidCompnent(StatisticsSys))
	{
		StatisticsSys->SetStatisticsData(ECWStatisticsType::RoundMoveAttackStep, 0);
	}

	MyPawn->RemoveAttackEffect();

	UE_LOG(LogCWPawnActionCastSkillToPawnState, Log, TEXT("UCWPawnActionCastSkillToPawnState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionCastSkillToPawnState::OnAnimFinish(int32 RoundIndex)
{
	bIsAnimFinish = true;
}

bool UCWPawnActionCastSkillToPawnState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}