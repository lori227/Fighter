
#include "CWPawnActionCounterAttackState.h"

#include "CWFSM.h"
#include "CWPawn.h"
#include "CWSkill.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWGameState.h"
#include "CWPawnActionFSM.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWPawnActionDataForCounterAttack.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionCounterAttackState, All, All);

UCWPawnActionCounterAttackState::UCWPawnActionCounterAttackState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	LimitTime = PAWN_ANIM_TIME_MAX;
	RunningTime = 0.0f;
}

UCWPawnActionCounterAttackState::~UCWPawnActionCounterAttackState()
{
}


ECWPawnActionStateChange UCWPawnActionCounterAttackState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForCounterAttack* TempActionDataForCounterAttack = (UCWPawnActionDataForCounterAttack*)ParamNextActionData;
	check(TempActionDataForCounterAttack);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereCounterAttackAnimSequence())
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyGameState->GetCurRoundIndex());
	}

	bool Result = MyPawn->CounterAttackToTile(TempActionDataForCounterAttack->TargetTile);
	if (Result)
	{
		UE_LOG(LogCWPawnActionCounterAttackState, Log, TEXT("UCWPawnActionCounterAttackState::OnStart Success, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	}
	else
	{
		UE_LOG(LogCWPawnActionCounterAttackState, Error, TEXT("UCWPawnActionCounterAttackState::OnStart fail, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	}
	//------------------------------------------------------------------------
	//�ؼ�ʱ��㴥�� ��ͨ������ʼ
	//MyPawn->OnKeyTimeInServer(ECWKeyTimeType::NormalAttackBegin);
	//------------------------------------------------------------------------

	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionCounterAttackState::OnProcess(float DeltaTime)
{
	RunningTime += DeltaTime;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	if (bIsAnimFinish || RunningTime > LimitTime)
	{
		if (MyPawn->ProcessNextAction())
		{
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionCounterAttackState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	//------------------------------------------------------------------------
	//�ؼ�ʱ��㴥�� ��ͨ��������
	//MyPawn->OnKeyTimeInServer(ECWKeyTimeType::NormalAttackEnd);
	//------------------------------------------------------------------------

	UE_LOG(LogCWPawnActionCounterAttackState, Log, TEXT("UCWPawnActionCounterAttackState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionCounterAttackState::OnAnimFinish(int32 RoundIndex)
{
	bIsAnimFinish = true;
}

bool UCWPawnActionCounterAttackState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//�ͻ�����Զ�Ǹ��ݷ�������״̬��ת���ģ����������Ӻ�ת��
		return true;
	}
}