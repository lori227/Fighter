#include "CWPawnActionDeathState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWGameState.h"
#include "CWPlayerController.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionDeathState, All, All);

UCWPawnActionDeathState::UCWPawnActionDeathState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionDeathState::~UCWPawnActionDeathState()
{
}

ECWPawnActionStateChange UCWPawnActionDeathState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	MyPawn->SetCurInstructs((uint8)ECWInstructType::Await);


	if (MyPawn->IsInServer())
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(MyPawn->GetParantController());
		if (MyPlayerController != nullptr)
		{
			MyPlayerController->PawnDeathInServer(MyPawn);
		}
	}

	if (!MyPawn->IsInServer())
	{
		MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
	}

	UE_LOG(LogCWPawnActionDeathState, Log, TEXT("UCWPawnActionDeathState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionDeathState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	
	MyPawn->ProcessNextAction();
	return ECWPawnActionStateProcess::SUSPEND;
}

ECWPawnActionStateChange UCWPawnActionDeathState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	UE_LOG(LogCWPawnActionDeathState, Log, TEXT("UCWPawnActionDeathState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionDeathState::OnAnimFinish(int32 RoundIndex)
{
	
}

bool UCWPawnActionDeathState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}