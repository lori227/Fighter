#include "CWPawnActionDieState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWGameState.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionDieState, All, All);

UCWPawnActionDieState::UCWPawnActionDieState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	LimitTime = PAWN_ANIM_TIME_MAX;
	RunningTime = 0.0f;
}

UCWPawnActionDieState::~UCWPawnActionDieState()
{
}

ECWPawnActionStateChange UCWPawnActionDieState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereAnimSequence(ECWPawnAnim::Die01))
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	MyPawn->SetCurInstructs((uint8)ECWInstructType::Await);

	if (!MyPawn->IsInServer())
	{
		MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
	}

	//服务器和客户端都要播放
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereAnimSequence(ECWPawnAnim::Die01))
		{
			MyPawn->PlayAnimSequence(ECWPawnAnim::Die01, 0.25f, 0.0f, 1.0f, 1);
		}
		else
		{
			if (MyPawn->IsInServer())
			{
				MyPawn->DieEndInServer();
				MyPawn->Destroy();
			}
		}
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		if (MyPawn->IsInServer())
		{
			MyPawn->DieEndInServer();
			MyPawn->Destroy();
		}
	}

	UE_LOG(LogCWPawnActionDieState, Log, TEXT("UCWPawnActionDieState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionDieState::OnProcess(float DeltaTime)
{
	RunningTime += DeltaTime;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	if (bIsAnimFinish || RunningTime > LimitTime)
	{
		//UCWPawnActionDataForDeath* TempDeathData = (UCWPawnActionDataForDeath*)NewObject<UCWPawnActionDataForDeath>();
		//TempDeathData->ActionId = ECWPawnActionState::Death;
		//MyPawn->PutAction(TempDeathData);
		/*if (MyPawn->ProcessNextAction())
		{
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}*/

		if (MyPawn->IsInServer())
		{
			MyPawn->DieEndInServer();
			MyPawn->Destroy();
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionDieState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		MyPawn->DieEndInServer();
	}

	//MyPawn->SetActorLocation(FVector(-100000.0f, -100000.0f, -0.0f));

	UE_LOG(LogCWPawnActionDieState, Log, TEXT("UCWPawnActionDieState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionDieState::OnAnimFinish(int32 RoundIndex)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	bIsAnimFinish = true;

	UCWPawnActionDataForDeath* TempDeathData = (UCWPawnActionDataForDeath*)NewObject<UCWPawnActionDataForDeath>();
	TempDeathData->ActionId = ECWPawnActionState::Death;
	MyPawn->PutAction(TempDeathData);
}

bool UCWPawnActionDieState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		/*if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;*/

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}