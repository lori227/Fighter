
#include "CWPawnActionDizzinessState.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFSMEvent.h"
#include "CWPawnActionFSM.h"
#include "CWPlayerController.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionDizzinessState, All, All);

UCWPawnActionDizzinessState::UCWPawnActionDizzinessState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionDizzinessState::~UCWPawnActionDizzinessState()
{
}

const ENetMode UCWPawnActionDizzinessState::GetNetMode()
{
	ACWPawn* OwnerPawn = Parent->GetParentPawn();
	return IsValidActor(OwnerPawn) ? OwnerPawn->GetNetMode() : ENetMode::NM_MAX;
}


void UCWPawnActionDizzinessState::HandleBeDizziness(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* OwnerPawn = Parent->GetParentPawn();
	check(OwnerPawn);

	//OwnerPawn->SetCurInstructs((uint8)ECWInstructType::Await);

	// TODO: Add Effect?(Buff) & Show Depth Stencil
	if (!OwnerPawn->IsInServer())
	{
		ACWPlayerController* LocalPC = OwnerPawn->GetLocalPC();
		const int32 NewStencilValue = IsValidActor(LocalPC) && LocalPC->IsEnemy(OwnerPawn) ? 102 : 0;
		OwnerPawn->SetCustomDepthStencilValue(NewStencilValue);

		//OwnerPawn->AddEffect(4);
	}

	// 播放眩晕动画
	if (OwnerPawn->IsPawnType(ECWPawnType::Character))
	{
		OwnerPawn->PlayAnimSequence(ECWPawnAnim::Dizziness, 0.25f, 0.f, 1.f, 1000000);
	}
	else if (OwnerPawn->IsPawnType(ECWPawnType::DungeonItem))
	{
		CWG_ERROR(">> CWPawnActionDizzinessState::HandleBeDizziness, DungeonItem has Dizziness State?");
	}
}

ECWPawnActionStateChange UCWPawnActionDizzinessState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	CWG_LOG(">> ActionDizzinessState::OnStart, NetMode[%s] Go!", *NETMODE_TO_STRING(GetNetMode()));

	HandleBeDizziness(ParamNextActionData);

	UE_LOG(LogCWPawnActionDizzinessState, Log, TEXT("UCWPawnActionDizzinessState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionDizzinessState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	MyPawn->ProcessNextAction();
	return ECWPawnActionStateProcess::SUSPEND;
}

ECWPawnActionStateChange UCWPawnActionDizzinessState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	CWG_WARNING(">> ActionDizzinessState::OnEnd, NetMode[%s] No!", *NETMODE_TO_STRING(GetNetMode()));
	UE_LOG(LogCWPawnActionDizzinessState, Log, TEXT("UCWPawnActionDizzinessState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionDizzinessState::OnAnimFinish(int32 RoundIndex)
{
	
}
bool UCWPawnActionDizzinessState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* OwnerPawn = Parent->GetParentPawn();
	check(OwnerPawn);

	if (OwnerPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::ForceMove)
			return true;
		
		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}

