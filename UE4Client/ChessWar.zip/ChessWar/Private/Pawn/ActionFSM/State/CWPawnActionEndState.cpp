#include "CWPawnActionEndState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWPawnActionToEndEvent.h"
#include "CWGameState.h"
#include "CWPawnActionForceToEndEvent.h"
#include "CWPlayerController.h"
#include "CWPawnInputActionFinishEvent.h"
#include "CWPawnInputFSM.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionEndState, All, All);

UCWPawnActionEndState::UCWPawnActionEndState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionEndState::~UCWPawnActionEndState()
{
}


void UCWPawnActionEndState::HandleForceToEnd(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForEnd* TempActionDataForEnd = (UCWPawnActionDataForEnd*)(ParamNextActionData);
	check(TempActionDataForEnd);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	MyPawn->SetCurInstructs((uint8)ECWInstructType::Await);


	if (!MyPawn->IsMovedByCurInstructs() &&
		!MyPawn->IsNormalAttackByCurInstructs() &&
		!MyPawn->IsCastSkillByCurInstructs())
	{
		MyPawn->SetCurInstructs((uint8)ECWInstructType::Defence);

		if (!MyPawn->IsInServer())
		{
			if (TempActionDataForEnd->OldActionState != ECWPawnActionState::Die ||
				TempActionDataForEnd->OldActionState != ECWPawnActionState::Death)
			{
				if (!MyPawn->IsDieOrDeath())
				{
					MyPawn->PlayAnimSequence(ECWPawnAnim::Defence01, 0.25f, 0.25f, 1.0f, 1000000);
				}
			}
		}
	}
	else
	{
		if (!MyPawn->IsInServer())
		{
			if (TempActionDataForEnd->OldActionState != ECWPawnActionState::Die ||
				TempActionDataForEnd->OldActionState != ECWPawnActionState::Death)
			{
				if (!MyPawn->IsDieOrDeath())
				{
					MyPawn->PlayAnimSequence(ECWPawnAnim::IdleNoAction01, 0.25f, 0.25f, 1.0f, 1000000);
				}
			}
		}
	}

	if (!MyPawn->IsInServer() && MyPawn->IsMyClientPawn())
	{
		if (MyPawn->GetInputFSM())
		{
			FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
			MyPawn->GetInputFSM()->DoEvent(ActionFinishEvent);
		}
	}
}

ECWPawnActionStateChange UCWPawnActionEndState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForEnd* TempActionDataForEnd = (UCWPawnActionDataForEnd*)(ParamNextActionData);
	check(TempActionDataForEnd);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	MyPawn->SetCurInstructs((uint8)ECWInstructType::Await);


	if (!MyPawn->IsMovedByCurInstructs() &&
		!MyPawn->IsNormalAttackByCurInstructs() &&
		!MyPawn->IsCastSkillByCurInstructs())
	{
		MyPawn->SetCurInstructs((uint8)ECWInstructType::Defence);

		if (!MyPawn->IsInServer())
		{
			if (TempActionDataForEnd->OldActionState != ECWPawnActionState::Die ||
				TempActionDataForEnd->OldActionState != ECWPawnActionState::Death)
			{
				if (!MyPawn->IsDieOrDeath())
				{
					MyPawn->PlayAnimSequence(ECWPawnAnim::Defence01, 0.25f, 0.25f, 1.0f, 1000000);
				}
			}
		}
	}
	else
	{
		if (!MyPawn->IsInServer())
		{
			if (TempActionDataForEnd->OldActionState != ECWPawnActionState::Die ||
				TempActionDataForEnd->OldActionState != ECWPawnActionState::Death)
			{
				if (!MyPawn->IsDieOrDeath() &&
					MyPawn->GetPawnType() != ECWPawnType::DungeonItem)
				{
					MyPawn->PlayAnimSequence(ECWPawnAnim::IdleNoAction01, 0.25f, 0.25f, 1.0f, 1000000);
				}
			}
		}
	}

	if (!MyPawn->IsInServer() && MyPawn->IsMyClientPawn())
	{
		if (MyPawn->GetInputFSM())
		{
			FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
			MyPawn->GetInputFSM()->DoEvent(ActionFinishEvent);
		}
	}

	if (MyPawn->IsInServer())
	{
		ACWPlayerController* MyPlayerController = (ACWPlayerController*)(MyPawn->GetParantController());
		if (MyPlayerController != nullptr &&
			MyPlayerController->IsMyTurn(MyPawn) &&
			!MyPawn->IsActionEnd()// &&
			//(TempActionDataForEnd->bIsTriggerEvent || TempActionDataForEnd->bIsForceToEnd)
			)
		{
			MyPawn->OnKeyTimeInServer(ECWKeyTimeType::PawnActionEnd);
		}

		if (MyPlayerController != nullptr &&
			MyPlayerController->IsMyTurn(MyPawn) &&
			!MyPawn->IsActionEnd() &&
			TempActionDataForEnd->bIsTriggerEvent
			)
		{
			MyPawn->CurTurnActionEndInServer();
		}
	}

	MyPawn->SetIsActionEnd(true);

	UE_LOG(LogCWPawnActionEndState, Log, TEXT("UCWPawnActionEndState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionEndState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	MyPawn->ProcessNextAction();
	return ECWPawnActionStateProcess::SUSPEND;
}

ECWPawnActionStateChange UCWPawnActionEndState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	UE_LOG(LogCWPawnActionEndState, Log, TEXT("UCWPawnActionEndState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionEndState::OnAnimFinish(int32 RoundIndex)
{

}

bool UCWPawnActionEndState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::ForceMove)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CounterAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}