
#include "CWPawnActionForceMoveState.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFSMEvent.h"
#include "CWDungeonItem.h"
#include "CWDungeonTile.h"
#include "CWPawnActionFSM.h"
#include "CWBattleCalculate.h"
#include "CWPhysicsSystemCtrl.h"
#include "CWRandomDungeonGenerator.h"
#include "CWPawnActionToForceMoveEvent.h"
#include "CWPawnActionDataForForceMove.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionForceMoveState, All, All);

UCWPawnActionForceMoveState::UCWPawnActionForceMoveState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionForceMoveState::~UCWPawnActionForceMoveState()
{
}

void UCWPawnActionForceMoveState::HandleBeForceMove(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* OwnerPawn = Parent->GetParentPawn();
	UCWPawnActionDataForForceMove* ActionToForceMove = (UCWPawnActionDataForForceMove*)(ParamNextActionData);
	check(ParamNextActionData && OwnerPawn && ActionToForceMove && TEXT("PawnActionForceMoveState::OnEnter, ParamNextActionData/OwnerPawn is invalid!"));

	ACWMap* MyMap = UCWFuncLib::GetActor<ACWMap>(OwnerPawn);
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(OwnerPawn);
	check(MyMap && Generator && IsValidActor(OwnerPawn) && TEXT("HandleBeForceMove: Exec Obj is invalid!!!"));

	//ACWPawn* Caster = Cast<ACWPawn>(ActionToForceMove->GetCaster());
	const int32 OwnerTileNumber = OwnerPawn->GetTile();
	int32 OwnerX = INDEX_NONE, OwnerY = INDEX_NONE;
	MyMap->tile2xy(OwnerTileNumber, OwnerX, OwnerY);

	// 客户端播放
	OwnerPawn->NetMulticastBeForceMovePresentation();

	if (OwnerPawn->IsInServer())
	{
		// TODO: Force Move By Tile
		// X:是否需要位移点 Y:是否有障碍或棋子 Z:TileNumber
		TArray<FIntVector> OwnerFinalMoveArray;
		const TArray<FIntVector>& ForceMoveTileArray = ActionToForceMove->ForceMoveTileArray;
		const int32 ReceiverLayer = Generator->GetGridLayerByTile(OwnerTileNumber);
		for (int32 i = 0; i < ForceMoveTileArray.Num(); ++i)
		{
			const FIntVector& NewXY = ForceMoveTileArray[i];
			const int32 NewTileNumber = MyMap->xy2tile(NewXY.X, NewXY.Y);
			const ACWDungeonTile* NewTileObj = Generator->GetDungeonTile(NewTileNumber);
			CWG_LOG(">> CWPawnActionForceMoveState::HandleBeForceMove, Out: ForceMoveTileArray, i[%d] X[%d] Y[%d] TileNumber[%d] NewTileObj[%s].", i, NewXY.X, NewXY.Y, NewTileNumber, *CWG_NAME(NewTileObj));

			if (IsValidActor(NewTileObj))
			{	// 有有效地块
				const int32 NewTileLayer = Generator->GetGridLayerByTile(NewTileNumber);
				//if (NewTileLayer > ReceiverLayer)
				if (NewTileLayer != ReceiverLayer)	// Temp Code: 改为高低地势都为阻挡
				{	// 高地势
					// 冲击伤害 = 该技能造成的最终伤害 * 冲击系数		// 0≤冲击系数＜1

					// 最终强制位置
					{
						const FIntVector& FinalXY = (i > 0) ? ForceMoveTileArray[i - 1] : FIntVector(OwnerX, OwnerY, 0);
						const int32 FinalForceToTile = (i > 0) ? ACWMap::xy2tile(FinalXY.X, FinalXY.Y) : OwnerTileNumber;
						OwnerFinalMoveArray.Add(/*NewXY*/FIntVector(1, 1, NewTileNumber));
						OwnerFinalMoveArray.Add(/*FinalXY*/FIntVector(1, 0, FinalForceToTile));
						//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
					}
					break;
				}
				/*else if (NewTileLayer < ReceiverLayer)
				{	// 低地势	// 移动->下落->修正
					// 掉下伤害 = 掉下最低伤害 * 地势差 ^ (修正值)
					// y = 2 * x ^ 0.4 (0＜修正值＜1)
					const float NeedLayer = NewTileLayer - ReceiverLayer;
					const int32 NewHurt = 2 * powf(NeedLayer, 0.4);
					if (UCWBattleCalculate::Get()->ExecHealthCalculate(nullptr, OwnerPawn, NewHurt))
					{
						// TODO: Play Behit Animation...
					}

					// 是否有单位
					bool bHasUnitInTile = false;
					if (ACWPawn* TilePawn = MyMap->GetPawnByTile(NewTileNumber).Get())
					{	// 场景棋子
						if (UCWPhysicsSystemCtrl* TilePawnPhysicsSys = TilePawn->GetPhysicsSysCtrl())
						{	// 其他单位接收垂直交互
							TilePawnPhysicsSys->ExecVerticalForce(OwnerPawn);
						}
						bHasUnitInTile = IsValidActor(TilePawn);		// 有可能接收垂直交互时销毁
					}
					else if (ACWDungeonItem* TileItem = Generator->GetDungeonItem(NewTileNumber))
					{	// 场景物件
						if (UCWPhysicsSystemCtrl* TileItemPhysicsSys = TileItem->GetPhysicsSysCtrl())
						{	// 其他单位接收垂直交互
							TileItemPhysicsSys->ExecVerticalForce(OwnerPawn);
						}
						bHasUnitInTile = IsValidActor(TilePawn);		// 有可能接收垂直交互时销毁
					}

					if (!bHasUnitInTile)
					{	// 无单位则移动到该位置
						// 最终强制位置
						{
							const int32 FinalForceToTile = NewTileNumber;
							OwnerFinalMoveArray.Add(/ *NewXY* /FIntVector(1, 0, NewTileNumber));
							//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
						}
					}
					else
					{	// 有单位则移动其他位置
						// 最终强制位置
						{
							const int32 FinalForceToTile = UCWPhysicsSystemCtrl::GetTargetNearOptimumTile(OwnerPawn, NewTileNumber, OwnerTileNumber);
							FIntVector FinalXY;
							ACWMap::tile2xy(FinalForceToTile, FinalXY.X, FinalXY.Y);
							OwnerFinalMoveArray.Add(/ *NewXY* /FIntVector(1, 1, NewTileNumber));
							OwnerFinalMoveArray.Add(/ *FinalXY* /FIntVector(1, 0, FinalForceToTile));
							//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
						}
					}
					break;
				}*/
				else
				{	// 平地势
					bool bHasObstacle = false;
					if (ACWPawn* TilePawn = MyMap->GetPawnByTile(NewTileNumber).Get())
					{	// 场景棋子
						bHasObstacle = true;
						if (UCWPhysicsSystemCtrl* TilePawnPhysicsSys = TilePawn->GetPhysicsSysCtrl())
						{
							TilePawnPhysicsSys->ExecHorizontalForce(OwnerPawn);
						}
					}
					else
					{	// 场景物件
						bHasObstacle = (MyMap->getMapTileAttribute(NewTileNumber) & (uint8)ECWDungeonTileAttribute::Obstacle) > 0;
						if (bHasObstacle)
						{
							const TArray<ACWDungeonItem*>& DungeonItems = Generator->GetAllDungeonItemByCanBeAttacked(NewTileNumber);
							for (int32 i = 0; i < DungeonItems.Num(); ++i)
							{
								ACWDungeonItem* DungeonItem = DungeonItems[i];
								UCWPhysicsSystemCtrl* TileItemPhysicsSys = DungeonItem ? DungeonItem->GetPhysicsSysCtrl() : nullptr;
								if (nullptr != TileItemPhysicsSys && !DungeonItem->IsBuffObject())
								{
									TileItemPhysicsSys->ExecHorizontalForce(OwnerPawn);
								}
							}
						}
					}

					if (bHasObstacle)
					{	// 有阻挡单位
						// 最终强制位置
						{
							const FIntVector& FinalXY = (i > 0) ? ForceMoveTileArray[i - 1] : FIntVector(OwnerX, OwnerY, 0);
							const int32 FinalForceToTile = (i > 0) ? ACWMap::xy2tile(FinalXY.X, FinalXY.Y) : OwnerTileNumber;
							OwnerFinalMoveArray.Add(/*NewXY*/FIntVector(1, 1, NewTileNumber));
							OwnerFinalMoveArray.Add(/*FinalXY*/FIntVector(1, 0, FinalForceToTile));
							//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
						}
						break;
					}
					else if (i == (ForceMoveTileArray.Num() - 1))
					{	// 最后一个点
						// 最终强制位置
						{
							const int32 FinalForceToTile = NewTileNumber;
							OwnerFinalMoveArray.Add(/*FinalXY*/FIntVector(1, 0, FinalForceToTile));
							//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
						}
						break;
					}
				}
			}
			else
			{	// 无有效地块		// 移动->下落->死亡
				// 最终强制位置
				{
					const int32 FinalForceToTile = NewTileNumber;
					OwnerFinalMoveArray.Add(/*NewXY*/FIntVector(1, 1, FinalForceToTile));
					//OwnerPawn->BeForceMoveInServer(InCaster, OwnerFinalMoveArray);
				}
				break;
			}
		}

		//~ 直接设置到目标点(Test)
		const int32 FinalMoveTileNum = OwnerFinalMoveArray.Num();
		if (FinalMoveTileNum > 0)
		{
			/*FIntVector MovePintData;
			auto TimerCallable = [MovePintData, MyMap, Generator, OwnerPawn]()
			{
				if (!IsValidActor(MyMap) || !IsValidActor(Generator) ||
					!IsValidActor(OwnerPawn) || OwnerPawn->IsDieOrDeath())
				{
					return;
				}

				const int32 FinalTileNumber = MovePintData.Z;
				const bool bHasObstacle = MovePintData.Y == 1;
				const ACWDungeonTile* TargetDungeonTile = Generator->GetDungeonTile(FinalTileNumber);
				if (IsValidActor(TargetDungeonTile) && !bHasObstacle)
				{
					OwnerPawn->SetTile(FinalTileNumber);
				}
				else
				{	// 无地块则通过计算位置并更改
					FVector NewLocation;
					MyMap->tile2pos(FinalTileNumber, NewLocation);
					NewLocation.Z = OwnerPawn->GetActorLocation().Z;
					OwnerPawn->SetActorLocation(NewLocation);
				}

				// 无地块调用死亡事件
				if (OwnerPawn->IsInServer() && !IsValidActor(TargetDungeonTile))
				{
					OwnerPawn->DoFallInServer();
					OwnerPawn->DieInServer();
				}
			};

			float DelayTime = 0.f;
			FTimerHandle TimerHandle;
			FTimerManager& TimerManager = OwnerPawn->GetWorldTimerManager();
			for (int i = 0; i < FinalMoveTileNum; ++i)
			{
				MovePintData = OwnerFinalMoveArray[i];
				if (MovePintData.X == 1)
				{	// 需要位移的点
					const bool bHasObstacle = MovePintData.Y == 1;
					const int32 NewTileNumber = MovePintData.Z;
					TimerManager.SetTimer(TimerHandle, TimerCallable, DelayTime, false);

					DelayTime += 0.5f;
				}
			}*/

			const int32 FinalTileNumber = OwnerFinalMoveArray[FinalMoveTileNum - 1].Z;
			const ACWDungeonTile* TargetDungeonTile = Generator->GetDungeonTile(FinalTileNumber);
			if (IsValidActor(TargetDungeonTile))
			{
				OwnerPawn->SetTile(FinalTileNumber);
			}
			else
			{	// 无地块则通过计算位置并更改
				FVector NewLocation;
				MyMap->tile2pos(FinalTileNumber, NewLocation);
				NewLocation.Z = OwnerPawn->GetActorLocation().Z;
				OwnerPawn->SetActorLocation(NewLocation);
			}
			OwnerPawn->ResetLocationAndRotation();

			// 无地块调用死亡事件
			if (OwnerPawn->IsInServer() && !IsValidActor(TargetDungeonTile))
			{
				OwnerPawn->DoFallInServer();
				OwnerPawn->DieInServer();
			}
			//OwnerPawn->SetReplicateMovement(true);
			//OwnerPawn->GetMovementComponent();
		}

		// 反击
		if (OwnerPawn->GetPawnType() == ECWPawnType::Character)
		{
			//if (TargetPawn != nullptr && TargetPawn->GetPawnType() == ECWPawnType::Character)
			const ACWDungeonTile* TargetDungeonTile = Generator->GetDungeonTile(ActionToForceMove->CasterTile);
			if (IsValidActor(TargetDungeonTile))
			{
				uint8 TempMoveAttackDamage = 0x00;
				TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
				TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
				if (OwnerPawn->IsAttackTileFromTileForNormalAttack(OwnerPawn->GetTile(), ActionToForceMove->CasterTile, TempMoveAttackDamage))
				{
					OwnerPawn->CounterAttackToTileInServer(ActionToForceMove->CasterTile);
				}
			}
		}
	}

	// 调用广播事件必须限定为Server!!!
	if (IsValidActor(OwnerPawn) && OwnerPawn->IsInServer())
	{
		OwnerPawn->NetMulticastBeForceMoveExit();

		// 检测是否可拾取BUFF
		OwnerPawn->CheckOverlapPickupBuff();
	}
}

ECWPawnActionStateChange UCWPawnActionForceMoveState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	HandleBeForceMove(ParamNextActionData);

	UE_LOG(LogCWPawnActionForceMoveState, Log, TEXT("UCWPawnActionForceMoveState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, SkillId:%d, TargetTile:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionForceMoveState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//if (m_dwCurTime >= m_dwlifeTime)
	{
		MyPawn->ProcessNextAction();
		return ECWPawnActionStateProcess::END;
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionForceMoveState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	UE_LOG(LogCWPawnActionForceMoveState, Log, TEXT("UCWPawnActionForceMoveState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, SkillId:%d, TargetTile:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionForceMoveState::OnAnimFinish(int32 RoundIndex)
{

}

bool UCWPawnActionForceMoveState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* OwnerPawn = Parent->GetParentPawn();
	check(ParamNextActionData && OwnerPawn && TEXT("PawnActionForceMoveState::CanTranstion, ParamNextActionData/OwnerPawn is invalid!"));

	if (OwnerPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Dizziness)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CounterAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}