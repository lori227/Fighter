#include "CWPawnActionIdleState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWPawnActionForceToEndEvent.h"
#include "CWPawnActionToEndEvent.h"
#include "CWPlayerController.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionIdleState, All, All);

UCWPawnActionIdleState::UCWPawnActionIdleState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionIdleState::~UCWPawnActionIdleState()
{
}


ECWPawnActionStateChange UCWPawnActionIdleState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (!MyPawn->IsInServer())
	{
		MyPawn->PlayAnimSequence(ECWPawnAnim::Idle01, 0.25f, 0.25f, 1.0f, 1000000);
	}

	UE_LOG(LogCWPawnActionIdleState, Log, TEXT("UCWPawnActionIdleState::OnStart..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionIdleState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	MyPawn->ProcessNextAction();
	return ECWPawnActionStateProcess::SUSPEND;
}

ECWPawnActionStateChange UCWPawnActionIdleState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	UE_LOG(LogCWPawnActionIdleState, Log, TEXT("UCWPawnActionIdleState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionIdleState::OnAnimFinish(int32 RoundIndex)
{

}

bool UCWPawnActionIdleState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::MoveToDest)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::MoveToAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::MoveToWaitingAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::WaitingAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::NormalAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CastSkillToPawn)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CastSkillToTile)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::ForceMove)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Dizziness)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CounterAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}