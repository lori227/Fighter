﻿#include "CWPawnActionMoveToDestState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "CWPawnActionFSM.h"
#include "CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawn.h"
#include "CWPawnActionToMoveToDestEvent.h"
#include "CWPlayerController.h"
#include "CWMap.h"
#include "CWPawnActionToIdleEvent.h"
#include "CWPawnInputWaitingEvent.h"
#include "CWPawnInputWaitingAttackEvent.h"
#include "CWPawnInputActionFinishEvent.h"
#include "CWPawnActionToEndEvent.h"
#include <list>
#include "CWMapTileRender.h"
#include "CWMapTile.h"
#include "CWPawnActionToWaitingAttackEvent.h"
#include "Components/SkeletalMeshComponent.h"
#include "CWGameState.h"
#include "CWDungeonTile.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionMoveToDestState, All, All);

UCWPawnActionMoveToDestState::UCWPawnActionMoveToDestState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWPawnActionMoveToDestState::~UCWPawnActionMoveToDestState()
{
}


void UCWPawnActionMoveToDestState::TickMoving(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	ACWMap* MyMap = MyPawn->GetMap();
	if (MyMap != nullptr)
	{
		FVector OldPos = MyPawn->GetPathExplorer().GetPos();
		MyMap->pathExplorerProgress(MyPawn->GetPathExplorer(), MyPawn->GetMoveSpeed(), DeltaTime);
		FVector CurPos = MyPawn->GetPathExplorer().GetPos();
		MyPawn->SetActorLocation(CurPos);
		FVector CurDir = CurPos - OldPos;
		if (FMath::Abs(CurDir.SizeSquared()) > 0.0001f)
		{
			FRotator CurRotation = CurDir.Rotation();
			CurRotation.Yaw -= 90.0f;
			MyPawn->SetActorRotation(CurRotation);
		}
	}
}

bool UCWPawnActionMoveToDestState::CheckMoveToDest()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	return MyPawn->GetPathExplorer().IsArrived();
}


ECWPawnActionStateChange UCWPawnActionMoveToDestState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForMoveToDest* TempMoveToDestData = (UCWPawnActionDataForMoveToDest*)ParamNextActionData;
	DestTile = TempMoveToDestData->DestTile;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyPawn->GetWorld()->GetGameState<ACWGameState>()->GetCurRoundIndex());
	}

	MyPawn->SetCurInstructs((uint8)ECWInstructType::Move);
	MyPawn->SetCurInstructs((uint8)ECWInstructType::Await);

	ACWMap* MyMap = MyPawn->GetMap();
	if (MyMap != nullptr)
	{
		FVector CurPos = FVector::ZeroVector;
		ACWMap::tile2pos(MyPawn->GetTile(), CurPos);
		MyPawn->GetPathExplorer().Reset();
		MyPawn->GetPathExplorer().SetPos(CurPos);
		MyPawn->SetMoveBeginTile(MyPawn->GetTile());
		MyPawn->SetMoveBeginPos(MyPawn->GetActorLocation());
		MyPawn->SetMoveBeginRotator(MyPawn->GetActorRotation());

		FVector DestPos;
		ACWMap::tile2pos(DestTile, DestPos);
		MyMap->pathExplorerFindPathAStar(MyPawn->GetPathExplorer(), DestPos, 1000000, MyPawn->GetCampTag(), MyPawn->GetFindPathInfo());
	}

	if (!MyPawn->IsInServer())
	{
		MyPawn->PlayAnimSequence(ECWPawnAnim::Move01, 0.1f, 0.25f, MyPawn->GetMoveAnimSpeedRate(), 1000000);
	}

	UE_LOG(LogCWPawnActionMoveToDestState, Log, TEXT("UCWPawnActionMoveToDestState::OnStart MoveToDest Success, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, DestTile:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex(), DestTile);
	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionMoveToDestState::OnProcess(float DeltaTime)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	TickMoving(DeltaTime);

	FVector curLoc = MyPawn->GetActorLocation();
	int tile = ACWMap::pos2tile(curLoc);
	float z = MyPawn->GetDungeonTileZ(tile);
	MyPawn->SetActorLocation(FVector(curLoc.X, curLoc.Y, z));

	if (CheckMoveToDest())
	{
		if (MyPawn->ProcessNextAction())
		{
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionMoveToDestState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	FVector TempDestPos = MyPawn->GetPathExplorer().GetDestPos();
	int TempDestTile = ACWMap::pos2tile(TempDestPos);
	MyPawn->SetTile(TempDestTile);
	float z = MyPawn->GetDungeonTileZ(TempDestTile);
	MyPawn->SetActorLocation(FVector(TempDestPos.X, TempDestPos.Y, z));

	if (!MyPawn->IsInServer())
	{
		MyPawn->PlayAnimSequence(ECWPawnAnim::Idle01, 0.25f, 0.25f, 1.0f, 1000000);
		MyPawn->HideWantMovePathArrow();
		MyPawn->ShowShadowVisible(false);
	}

	DestTile = -1;


	if (!MyPawn->IsInServer() && MyPawn->IsMyClientPawn())
	{
		FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		MyPawn->GetInputFSM()->DoEvent(ActionFinishEvent);
	}

	UE_LOG(LogCWPawnActionMoveToDestState, Log, TEXT("UCWPawnActionMoveToDestState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionMoveToDestState::OnAnimFinish(int32 RoundIndex)
{

}

bool UCWPawnActionMoveToDestState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::NormalAttack)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CastSkillToPawn)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::CastSkillToTile)
			return true;
	
		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}