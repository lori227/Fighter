
#include "CWPawnActionNormalAttackState.h"

#include "CWFSM.h"
#include "CWPawn.h"
#include "CWSkill.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWGameState.h"
#include "CWPawnActionFSM.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWPawnActionToNormalAttackEvent.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionNormalAttackState, All, All);

UCWPawnActionNormalAttackState::UCWPawnActionNormalAttackState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	LimitTime = PAWN_ANIM_TIME_MAX;
	RunningTime = 0.0f;
}

UCWPawnActionNormalAttackState::~UCWPawnActionNormalAttackState()
{
}


ECWPawnActionStateChange UCWPawnActionNormalAttackState::OnStart(UCWPawnActionData* ParamNextActionData)
{
	UCWPawnActionDataForNormalAttack* TempActionDataForNormalAttack = (UCWPawnActionDataForNormalAttack*)ParamNextActionData;
	check(TempActionDataForNormalAttack);

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	//------------------------
	if (MyPawn->GetPawnType() == ECWPawnType::Character)
	{
		if (MyPawn->IsThereNormalAttackAnimSequence())
			bIsAnimFinish = false;
		else
			bIsAnimFinish = true;
	}
	else if (MyPawn->GetPawnType() == ECWPawnType::DungeonItem)
	{
		bIsAnimFinish = true;
	}
	RunningTime = 0.0f;
	//------------------------

	ACWGameState* MyGameState = MyPawn->GetWorld()->GetGameState<ACWGameState>();
	if (MyGameState != nullptr)
	{
		MyPawn->SetRoundIndexWhenAction(MyGameState->GetCurRoundIndex());
	}

	bool Result = MyPawn->NormalAttackToTile(TempActionDataForNormalAttack->TargetTile);
	if (Result)
	{
		UE_LOG(LogCWPawnActionNormalAttackState, Log, TEXT("UCWPawnActionNormalAttackState::OnStart NormalAttack Success, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	}
	else
	{
		UE_LOG(LogCWPawnActionNormalAttackState, Error, TEXT("UCWPawnActionNormalAttackState::OnStart NormalAttack fail, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	}
	//------------------------------------------------------------------------
	//关键时间点触发 普通攻击开始
	MyPawn->OnKeyTimeInServer(ECWKeyTimeType::NormalAttackBegin);
	//------------------------------------------------------------------------

	return ECWPawnActionStateChange::SUCCESS;
}

ECWPawnActionStateProcess UCWPawnActionNormalAttackState::OnProcess(float DeltaTime)
{
	RunningTime += DeltaTime;

	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);
	if (bIsAnimFinish || RunningTime > LimitTime)
	{
		if (MyPawn->ProcessNextAction())
		{
			return ECWPawnActionStateProcess::SUSPEND;
		}
		else
		{
			return ECWPawnActionStateProcess::END;
		}
	}

	return ECWPawnActionStateProcess::HOLD;
}

ECWPawnActionStateChange UCWPawnActionNormalAttackState::OnEnd()
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	//------------------------------------------------------------------------
	//关键时间点触发 普通攻击结束
	MyPawn->OnKeyTimeInServer(ECWKeyTimeType::NormalAttackEnd);
	//------------------------------------------------------------------------

	// 清理当前移动攻击移动步数
	UCWStatisticsSystemCtrl* StatisticsSys = MyPawn->GetStatisticsSysCtrl();
	if (IsValidCompnent(StatisticsSys))
	{
		StatisticsSys->SetStatisticsData(ECWStatisticsType::RoundMoveAttackStep, 0);
	}

	UE_LOG(LogCWPawnActionNormalAttackState, Log, TEXT("UCWPawnActionNormalAttackState::OnEnd..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), (int)MyPawn->GetCampTag(), (int)MyPawn->GetCampControllerIndex(), (int)MyPawn->GetControllerPawnIndex());
	return ECWPawnActionStateChange::SUCCESS;
}

void UCWPawnActionNormalAttackState::OnAnimFinish(int32 RoundIndex)
{
	bIsAnimFinish = true;
}

bool UCWPawnActionNormalAttackState::CanTranstion(const UCWPawnActionData* ParamNextActionData)
{
	ACWPawn* MyPawn = Parent->GetParentPawn();
	check(MyPawn);

	if (MyPawn->IsInServer())
	{
		if (ParamNextActionData->ActionId == ECWPawnActionState::Idle)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::BeHit)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Die)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::Death)
			return true;

		if (ParamNextActionData->ActionId == ECWPawnActionState::End)
			return true;

		return false;
	}
	else
	{
		//客户端永远是根据服务器的状态，转换的，无条件服从和转换
		return true;
	}
}