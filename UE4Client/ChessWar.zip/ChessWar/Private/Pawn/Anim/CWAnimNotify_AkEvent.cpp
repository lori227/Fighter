
#include "CWAnimNotify_AkEvent.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "AkComponent.h"
#include "AkAudioEvent.h"
#include "CWCommonUtil.h"
#include "CWAudioVideoMgr.h"
#include "AkGameplayStatics.h"


UCWAnimNotify_AkEvent::UCWAnimNotify_AkEvent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bFollow(true)
	, AttachName(TEXT("HoverAttachPoint"))
	, OcclusionCollisionChannel(ECC_Destructible)
	, OcclusionRefreshInterval(0.f)
{
}

FString UCWAnimNotify_AkEvent::GetNotifyName_Implementation() const
{
	//return Super::GetNotifyName_Implementation();
	return (TEXT("Ak_") + GET_AK_EVENT_NAME(Event, EventName));
}

void UCWAnimNotify_AkEvent::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

//#if WITH_EDITOR || !UE_SERVER
	if (IsAllowPlayAudio())
	{
		if (UAkComponent* AkPlayComp = GetAkComp(MeshComp))
		{
			if (bFollow)
			{
				// Occlusion
				UpdateAkOcclusion(AkPlayComp);

				// Switch
				if (AkSoundType == AkSET_Foot)
				{
					FString SwitchState = GetSwitchState(MeshComp, TEXT("Surfaces"));
					if (!SwitchState.IsEmpty())
					{
						//CWG_WARNING(">> %s::Notify, SwitchState[%s].", *GetName(), *SwitchState);
						AkPlayComp->SetSwitch(TEXT("Surfaces"), SwitchState);
					}
				}

				// Ak event
				FOnAkPostEventCallback PostEventCallback;
				AkPlayComp->PostAkEvent(Event, 0, PostEventCallback, EventName);
			}
			else
			{
				UAkGameplayStatics::PostEventAtLocation(Event, MeshComp->GetComponentLocation(), FRotator(0.0f), EventName, this);
			}
		}
	}
//#endif
}

UAkComponent* UCWAnimNotify_AkEvent::GetAkComp(USkeletalMeshComponent* MeshComp)
{
	UAkComponent* AkPlayComp = UAkGameplayStatics::GetAkComponent(MeshComp, FSTRING_TO_FNAME(AttachName));
	if (IsValid(AkPlayComp))
	{
		if (UCWAudioVideoMgr* AVMgr = AV_MGR(this))
		{
			AVMgr->AddToAnimAudioList(AkPlayComp);
		}
	}
	return AkPlayComp;
}

void UCWAnimNotify_AkEvent::UpdateAkOcclusion(UAkComponent* InAkComp)
{
	if (!IsValid(InAkComp))
	{
		return;
	}
	InAkComp->OcclusionCollisionChannel = OcclusionCollisionChannel;
	//InAkComp->OcclusionRefreshInterval = OcclusionRefreshInterval;
	//InAkComp->UpdateOcclusionObstruction();
}

FString UCWAnimNotify_AkEvent::GetSwitchState(USkeletalMeshComponent* MeshComp, const FString& InGroup)
{
	AActor* OwnerParent = IsValid(MeshComp) ? MeshComp->GetOwner() : nullptr;
	if (IsValid(OwnerParent))
	{
		if (InGroup.Equals(TEXT("Surfaces")))
		{
			const FVector StartPoint(OwnerParent->GetActorLocation());
			const FVector EndPoint(StartPoint.X, StartPoint.Y, StartPoint.Z - 150.f);
			FHitResult HitResult; 
			TArray<AActor*> IgnoreActors;
			if (UKismetSystemLibrary::LineTraceSingle(OwnerParent, 
				StartPoint, EndPoint, UEngineTypes::ConvertToTraceType(ECC_Visibility), true,
				IgnoreActors, EDrawDebugTrace::None, HitResult, true))
			{
				return FCWCommonUtil::EnumToString(TEXT("EPhysicalSurface"), UGameplayStatics::GetSurfaceType(HitResult));
			}
		}
	}
	return TEXT("");
}

bool UCWAnimNotify_AkEvent::IsAllowPlayAudio() const
{
	if (UCWAudioVideoMgr* AVMgr = AV_MGR(this))
	{
		return AVMgr->IsAkAudioEnableInMgr();
	}
	return true;
}
