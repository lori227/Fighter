#include "CWPawnAnimInstance.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnAnimInstance, All, All);

UCWPawnAnimInstance::UCWPawnAnimInstance(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

