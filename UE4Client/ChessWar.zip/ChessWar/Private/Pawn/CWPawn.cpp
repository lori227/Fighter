﻿
#include "CWPawn.h"

#include <random>
#include <ctime>
#include <functional>
#include <string>
#include <sstream>

#include "Engine.h"
#include "ConstructorHelpers.h"
#include "Engine/SkeletalMesh.h"
#include "Kismet/GameplayStatics.h"
#include "Components/ActorComponent.h"
#include "Components/CanvasPanel.h"

#include "CWMap.h"
#include "CWBuff.h"
#include "CWPEGrid.h"
#include "CWHUDBase.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWCfgUtils.h"
#include "CWGameMode.h"
#include "CWPawnStart.h"
#include "CWGameState.h"
#include "CWUIManager.h"
#include "CWCfgManager.h"
#include "AkComponent.h"
#include "AkAudioEvent.h"
#include "CWDungeonItem.h"
#include "CWWeatherData.h"
#include "CWDungeonTile.h"
#include "CWWidgetComp.h"
#include "CWCommonUtil.h"
#include "CWCfgManager.h"
#include "AkAudioDevice.h"
#include "CWFSMTranstion.h"
#include "CWPathExplorer.h"
#include "CWPawnInputFSM.h"
#include "CWMapTileRender.h"
#include "CWPawnActionFSM.h"
#include "CWAudioVideoMgr.h"
#include "CWUIPawnWidget.h"
#include "CWPawnDataUtils.h"
#include "CWSkeletalMeshActor.h"
#include "AkGameplayStatics.h"
#include "CWDungeonItemGroup.h"
#include "CWEffectDataUtils.h"
#include "CWClientConstData.h"
#include "CWSkillDataUtils.h"
#include "CWSkillDataStruct.h"
#include "CWCastSkillContext.h"
#include "CWEffectDataStruct.h"
#include "CWPlayerController.h"
#include "CWElementSystemCtrl.h"
#include "CWPawnActionEndState.h"
#include "CWPawnActionDieState.h"
#include "CWPawnActionIdleState.h"
#include "CWPawnActionBeHitState.h"
#include "CWPawnActionToDieEvent.h"
#include "CWRandomDungeonGenerator.h"
#include "CWBattlePropertyModifier.h"
#include "CWPawnActionToIdleEvent.h"
#include "CWPawnInputWaitingEvent.h"
#include "CWPawnActionDizzinessState.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWPawnInputSelectedEvent.h"
#include "CWPawnActionToBeHitEvent.h"
#include "CWPawnActionForceMoveState.h"
#include "CWPawnActionToForceMoveEvent.h"
#include "CWPawnInputWaitingTurnEvent.h"
#include "CWPawnActionMoveToDestState.h"
#include "CWPawnActionToDizzinessEvent.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWPawnActionNormalAttackState.h"
#include "CWPawnActionToMoveToDestEvent.h"
#include "CWPawnActionToNormalAttackEvent.h"
#include "CWPawnActionToWaitingAttackEvent.h"
#include "CWPawnInputMoveToWaitingAttackEvent.h"
#include "CWPawnInputMoveToWaitingAttackState.h"
#include "CWPawnActionToMoveToWaitingAttackEvent.h"

#include "CWSkill.h"
#include "CWDungeonTile.h"
#include "CWCommonUtil.h"
#include "CWBuffManager.h"
#include "CWSkillManager.h"
#include "CWPawnDataStruct.h"
#include "CWBattleCalculate.h"
#include "CWAvatarComponent.h"
#include "MovementActorComp.h"
#include "CWCastSkillContext.h"
#include "CWTalentSystemCtrl.h"
#include "CWPhysicsSystemCtrl.h"
#include "CWBattlePropertySet.h"
#include "CWStatisticsSystemCtrl.h"
#include "CWPawnActionToEndEvent.h"
#include "CWBattlePropertySetRef.h"
#include "CWPawnActionToEndEvent.h"
#include "CWPawnActionDeathState.h"
#include "CWPawnActionToDeathEvent.h"
#include "CWPawnActionToBeHitEvent.h"
#include "CWPawnActionToBeHitEvent.h"
#include "CWRandomDungeonGenerator.h"
#include "CWPawnActionForceToEndEvent.h"
#include "CWPawnInputActionFinishEvent.h"
#include "CWPawnInputMoveToAttackState.h"
#include "CWPawnInputMoveToAttackEvent.h"
#include "CWPawnActionToMoveToAttackEvent.h"
#include "CWPawnActionCastSkillToPawnState.h"
#include "CWPawnInputNoCtrlInReadyState.h"
#include "CWPawnInputWaitInReadyState.h"
#include "CWPawnInputNoControlState.h"
#include "CWPawnInputWaitingTurnState.h"
#include "CWPawnInputWaitingState.h"
#include "CWPawnInputSelectedState.h"
#include "CWPawnInputFinishState.h"
#include "CWPawnInputStartTurnEvent.h"
#include "CWPawnInputReadyToMoveState.h"
#include "CWPawnInputMoveToDestState.h"
#include "CWPawnInputReadyToMoveEvent.h"
#include "CWPawnInputMoveToDestEvent.h"
#include "CWPawnInputWaitingAttackState.h"
#include "CWPawnInputNormalAttackState.h"
#include "CWPawnInputNormalAttackEvent.h"
#include "CWPawnInputWaitingAttackEvent.h"
#include "CWPawnInputNormalAttackEvent.h"
#include "CWPawnInputSelectedInReadyState.h"
#include "CWPawnInputCastSkillToPawnState.h"
#include "CWPawnInputCastSkillToTileState.h"
#include "CWPawnInputCastSkillToPawnEvent.h"
#include "CWPawnActionToCastSkillToPawnEvent.h"
#include "CWPawnInputSelectedAndWantAttackState.h"
#include "CWPawnInputSelectedAndWantAttackEvent.h"
#include "CWPawnInputReadyToMoveAndWantAttackEvent.h"
#include "CWPawnInputReadyToMoveAndWantAttackState.h"
#include "CWGameInstance.h"
#include "CWEventMgr.h"
#include "CWNetPlayerDataManager.h"
#include "CWNetPlayerData.h"
#include "CWPawnNetData.h"
#include "CWProfessionDataStruct.h"
#include "CWDungeonItemVisibility.h"
#include "CWProfessionDataUtils.h"
#include "CWPawnActionDataForMoveToDest.h"
#include "CWPawnActionComponent.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawn, All, All);

ACWPawn::ACWPawn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = true;

	PawnType = ECWPawnType::Character;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	SkeletalMeshComponent = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMeshComponent"));
	SkeletalMeshComponent->SetupAttachment(RootComponent);

	Avatar = CreateDefaultSubobject<UCWAvatarComponent>(TEXT("AvatarComponent"));
	Avatar->SetupAttachment(RootComponent);
	Avatar->SetMasterSkeletalMeshComponent(SkeletalMeshComponent);
	//SkeletalMeshComponent->SetWorldScale3D(FVector(1.5f, 1.5f, 1.5f));

	BattleProperty = CreateDefaultSubobject<UCWPawnBattlePropertyComponent>(TEXT("BattlePropertyComponent"));
	//BattleProperty->SetIsReplicated(true);

	ActionComponent = CreateDefaultSubobject<UCWPawnActionComponent>(TEXT("ActionComponent"));

	WidgetComp = CreateDefaultSubobject<UCWWidgetComp>(TEXT("WidgetComp"));
	WidgetComp->SetupAttachment(RootComponent);
#if !UE_SERVER
	static ConstructorHelpers::FClassFinder<UCWUIPawnWidget> WidgetClass(TEXT("/Game/Blueprints/UI/Widget/Pawn/WB_UIPawnWidget"));
	WidgetComp->SetWidgetSpace(EWidgetSpace::Screen);
	WidgetComp->SetWidgetClass(WidgetClass.Class);
	WidgetComp->SetRelativeLocation(FVector(0.f, 0.f, 100.f));
#endif // !UE_SERVER

	this->AutoPossessAI = EAutoPossessAI::Disabled;
	this->AutoPossessPlayer = EAutoReceiveInput::Type::Disabled;

	MoveBeginTile = -1;
	ReadyToDestTile = -1;
	MoveSpeed = 400.0f;
	MoveAnimSpeedRate = 1.0f;

	OldTile = -1;
	QEuler = 0.0f;
	Tile = -1;
	MoveToDestTile = -1;
	ArrayInstructs.Empty();
	ArrayInstructs.Add(FCWPawnInstructs());

	InputFSM = nullptr;
	ParantController = nullptr;

	SkillManager = nullptr;
	BuffManager = nullptr;

	RoundIndexWhenAction = -1;
	SkillIdWhenCastSkill = -1;
	bIsCounterAttackWhenCastSkill = false;
	DamageIndexWhenCastSkill = -1;
	TargetCampTag = ECWCampTag::None;
	TargetCampControllerIndex = ECWCampControllerIndex::None;
	TargetControllerPawnIndex = 0;
	TargetTile = -1;
	bIsActionEnd = false;
	bIsLongDown = false;
	AutoSelectSkillRecord = nullptr;

	DizzinessFlag = 0;
	NetPawnUniqueIdx = INDEX_NONE;
	CurSelectSkillIdx = INDEX_NONE;
	BuffEffectIdGenerator = 0;

	bIsDoFall = false;

	CurFallSpeed = 0.0f;
	TotalFallTime = 0.0f;
}

void ACWPawn::BeginPlay()
{
	Super::BeginPlay();

	if (!IsInServer())
	{
		if (PawnType == ECWPawnType::Character)
		{
			ACWPlayerController* TempPlayerController = GetLocalPC();
			if (TempPlayerController != nullptr)
			{
				if (TempPlayerController->IsInitInClient())
				{
					TempPlayerController->RegisterPawnInClient(this);
				}
				else
				{
					TScriptDelegate<> MyDelegate1;
					MyDelegate1.BindUFunction(this, FName("RespondAfterPlayerControllerSetupInClient"));
					TempPlayerController->OnAfterPlayerControllerSetupInClient.AddUnique(MyDelegate1);
				}
				OnRep_ClientChangeCamp();
			}

			ACWMap* TempMap = GetMap();
			if (TempMap != nullptr)
			{
				if (TempMap->IsInitInClient())
				{
					//TempMap->MovePawn(this, -1, GetTile());
				}
				else
				{
					TScriptDelegate<> MyDelegate1;
					MyDelegate1.BindUFunction(this, FName("RespondAfterMapSetupInClient"));
					TempMap->OnAfterMapSetupInClient.AddUnique(MyDelegate1);
				}
			}

		}
#if !UE_SERVER
		// 更新战斗属性集绑定数据
		NotifyUpdatePropertyData();
		// Head UI
		ShowUserWidget(IsEnablePawnUI());

		UCWEventMgr* EvtMgr = EVT_MGR(this);
		if (nullptr != EvtMgr)
		{
			ADD_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this, &ACWPawn::OnBattleStateChange, TEXT("OnBattleStateChange"));
		}
#endif // !UE_SERVER
	}
}

void ACWPawn::Destroyed()
{
	FTimerManager& TimerManager = GetWorldTimerManager();
	TimerManager.ClearTimer(DelayHideHandle);

#if !UE_SERVER
	UCWEventMgr* EvtMgr = EVT_MGR(this);
	if (nullptr != EvtMgr)
	{
		// 移除雪地目标
		if (IsPawnType(ECWPawnType::Character))
		{
			EvtMgr->OnRemoveSnowfieldTarget.Broadcast(this);
		}

		REMOVE_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this);
	}
#endif // !UE_SERVER

	Super::Destroyed();

	if (IsInServer()) 
	{
		UpdateCompOrEnermyNum();
	}
}

void ACWPawn::UpdateCompOrEnermyNum()
{
	ACWGameState* GameState = GetGameState();

	int CampNum = 0;
	if (ECWCampTag::A == GetCampTag())
	{
		CampNum = GameState->GetCampANum();
		if (CampNum <= 0)
			return;
		CampNum--;
		GameState->SetCampANum(CampNum);
	}
	else if (ECWCampTag::B == GetCampTag())
	{
		CampNum = GameState->GetCampANum();
		if (CampNum <= 0)
			return;
		CampNum--;
		GameState->SetCampBNum(CampNum);
	}
}

void ACWPawn::RespondAfterPlayerControllerSetupInClient()
{
	ACWPlayerController* TempPlayerController = GetLocalPC();
	if (TempPlayerController != nullptr)
	{
		if (TempPlayerController->IsInitInClient())
		{
			TempPlayerController->RegisterPawnInClient(this);
		}
	}
}

void ACWPawn::RespondAfterMapSetupInClient()
{
	ACWMap* TempMap = GetMap();
	if (TempMap != nullptr)
	{
		if (TempMap->IsInitInClient())
		{
			//TempMap->MovePawn(this, -1, GetTile());
		}
	}
}

ACWPlayerController* ACWPawn::GetMyClientPlayerController()
{
	ACWPlayerController* TempPlayerController = nullptr;
	for (TActorIterator<ACWPlayerController> Iter(GetWorld()); Iter; ++Iter)
	{
		TempPlayerController = *Iter;
		if (TempPlayerController != nullptr &&
			TempPlayerController->IsMyClientPlayerController())
		{
			return TempPlayerController;
			break;
		}
	}

	return nullptr;
}

void ACWPawn::NotifyActorBeginOverlap(AActor* OtherActor)
{
	Super::NotifyActorBeginOverlap(OtherActor);

	OnBeginOverlap(OtherActor);
}

void ACWPawn::NotifyActorEndOverlap(AActor* OtherActor)
{
	Super::NotifyActorEndOverlap(OtherActor);

	OnEndOverlap(OtherActor);
}

void ACWPawn::NotifyActorBeginCursorOver()
{
	Super::NotifyActorBeginCursorOver();

	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NotifyActorBeginCursorOver. Tile:%d."), Tile);

	ACWPlayerController* TempPC = Cast<ACWPlayerController>(this->GetWorld()->GetFirstPlayerController());
	if (TempPC != nullptr)
	{
		AActor* TempLastCursorActor = TempPC->GetLastCursorActor();
		if (TempLastCursorActor != nullptr && TempLastCursorActor != this)
		{
			ACWMapTile* TempMapTile = Cast<ACWMapTile>(TempLastCursorActor);
			if (TempMapTile)
			{
				TempMapTile->EndCursorOver();
			}
		}
	}

	if (!IsValidToCursorOver())
	{
		return;
	}

	ACWPlayerController* LocalPC = GetLocalPC();
	if (IsValid(LocalPC))
	{
		LocalPC->NotifyPawnBeginCursorOver(this);
	}

	if (TempPC != nullptr)
	{
		TempPC->SetLastCursorActor(this);
	}
	//CWG_WARNING(">>>>> %s::OnBeginCursorOver, ...", *GetName());
}

void ACWPawn::NotifyActorEndCursorOver()
{
	Super::NotifyActorEndCursorOver();

	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NotifyActorEndCursorOver. Tile:%d."), Tile);

	if (!IsValidToCursorOver())
	{
		return;
	}

	ACWPlayerController* LocalPC = GetLocalPC();
	if (IsValid(LocalPC))
	{
		LocalPC->NotifyPawnEndCursorOver(this);
	}
	//CWG_WARNING(">>>>> %s::OnEndCursorOver, ...", *GetName());
}

void ACWPawn::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	
	DOREPLIFETIME(ACWPawn, PawnNetData);
	DOREPLIFETIME(ACWPawn, CampTag);
	DOREPLIFETIME(ACWPawn, ControllerIndex);
	DOREPLIFETIME(ACWPawn, PawnIndex);
	DOREPLIFETIME(ACWPawn, PawnId);
	DOREPLIFETIME(ACWPawn, PeripheralNetId);
	DOREPLIFETIME(ACWPawn, CombinationName);
	DOREPLIFETIME(ACWPawn, OwnElemId);
	DOREPLIFETIME(ACWPawn, Tile);
	DOREPLIFETIME(ACWPawn, QEuler);
	DOREPLIFETIME(ACWPawn, DizzinessFlag);
	DOREPLIFETIME(ACWPawn, ParantControllerType); 
	DOREPLIFETIME(ACWPawn, ArrayInstructs);
	DOREPLIFETIME(ACWPawn, NetPawnUniqueIdx);
	DOREPLIFETIME(ACWPawn, ElemSysCtrl);
}

void ACWPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (InputFSM != nullptr)
	{
		InputFSM->Tick(DeltaTime);
	}

	if (ActionComponent != nullptr)
	{
		ActionComponent->StateProcess(DeltaTime);
	}

	if (IsInServer())
	{
		if (bIsDoFall)
		{
			FallingInServer(DeltaTime);
		}
	}
	else
	{
		if (bIsDoFall)
		{
			FallingInClient(DeltaTime);
		}
	}
}

void ACWPawn::SetActorHiddenInGame(bool bNewHidden)
{
#if !UE_SERVER
	ShowUserWidget(!bNewHidden && IsEnablePawnUI());
#endif // !UE_SERVER

	Super::SetActorHiddenInGame(bNewHidden);
}

bool ACWPawn::InitPawnInServer(ACWPlayerController* InPc, ACWPawnStart* InPawnStart, const FString& InPawnPeripheralNetId, const int32 InExtPawnId, const float InExtPosZ)
{
	const int32 NewNetPawnUniqueIdx = GenerateNetPawnUniqueIdx();
	SetPawnUniqueIdx(NewNetPawnUniqueIdx);

	SetParantControllerType(ECWControllerType::NetPlayer);
	SetParantController(InPc);
	SetCampTag(InPawnStart->CampTag);
	SetCampControllerIndex(InPawnStart->CampControllerIndex);
	SetControllerPawnIndex(InPawnStart->PawnIndex);

	const int32 NewPawnId = (InExtPawnId > 0) ? InExtPawnId : InPawnStart->PawnId;
	SetPawnId(NewPawnId);
	SetPeripheralNetId(InPawnPeripheralNetId);
	//LoadPawnDataByPawnId(NewPawnId);
	LoadProfessionDataByProfession();
	//LoadSkeletalMesh();
	LoadSkeletalMeshByPeripheralNetId();
	//LoadSkeletalMeshShadow();
	LoadSkeletalMeshShadowByPeripheralNetId();
	//LoadAnimInstance();
	LoadAnimInstanceByPeripheralNetId();
	//LoadAnims();
	LoadAnimsByPeripheralNetId();

	SetupBuffManager();
	/** 初始化天赋系统数据 */
	InitTalentSysData();
	SetupSkillManager();
	//SetupBattleProperty();

	/** 初始化元素系统数据 */
	InitElemSysData();

	/** 初始化物理系统数据 */
	InitPhysicsSysData();

	/** 初始化统计系统数据 */
	InitStatisticsSysData();

	/** 初始化位置旋转(PS:设置位置会更新重叠事件) */
	FRotator NewRotator = InPawnStart->GetActorRotation();
	FVector NewLocation = InPawnStart->GetActorLocation();
	NewLocation.Z = InExtPosZ;
	SetActorRotation(NewRotator);
	SetActorLocation(NewLocation);

	return true;
}


void ACWPawn::SetupInputFSM()
{
	if (!IsInServer())
	{
		InputFSM = NewObject<UCWPawnInputFSM>(this, TEXT("CWPawn.InputFSM"));
		check(InputFSM);
		InputFSM->Init(this);
		InputFSM->AddState(new FCWPawnInputWaitInReadyState(InputFSM, (int)ECWPawnInputState::WaitInReady));
		InputFSM->AddState(new FCWPawnInputSelectedInReadyState(InputFSM, (int)ECWPawnInputState::SelectInReady));
		InputFSM->AddState(new FCWPawnInputNoCtrlInReadyState(InputFSM, (int)ECWPawnInputState::NoCtrlInReady));
		InputFSM->AddState(new FCWPawnInputNoControlState(InputFSM, (int)ECWPawnInputState::NoControl));
		InputFSM->AddState(new FCWPawnInputWaitingTurnState(InputFSM, (int)ECWPawnInputState::TurnWaitingAction));
		InputFSM->AddState(new FCWPawnInputWaitingState(InputFSM, (int)ECWPawnInputState::WaitingInput));
		InputFSM->AddState(new FCWPawnInputSelectedState(InputFSM, (int)ECWPawnInputState::Selected));
		InputFSM->AddState(new FCWPawnInputSelectedAndWantAttackState(InputFSM, (int)ECWPawnInputState::SelectedAndWantAttack));
		InputFSM->AddState(new FCWPawnInputReadyToMoveState(InputFSM, (int)ECWPawnInputState::ReadyToMove));
		InputFSM->AddState(new FCWPawnInputReadyToMoveAndWantAttackState(InputFSM, (int)ECWPawnInputState::ReadyToMoveAndWantAttack));
		InputFSM->AddState(new FCWPawnInputMoveToDestState(InputFSM, (int)ECWPawnInputState::MoveToDest));
		InputFSM->AddState(new FCWPawnInputMoveToAttackState(InputFSM, (int)ECWPawnInputState::MoveToAttack));
		InputFSM->AddState(new FCWPawnInputMoveToWaitingAttackState(InputFSM, (int)ECWPawnInputState::MoveToWaitingAttack));
		InputFSM->AddState(new FCWPawnInputWaitingAttackState(InputFSM, (int)ECWPawnInputState::WaitingAttack));
		InputFSM->AddState(new FCWPawnInputNormalAttackState(InputFSM, (int)ECWPawnInputState::NormalAttack));
		InputFSM->AddState(new FCWPawnInputCastSkillToPawnState(InputFSM, (int)ECWPawnInputState::CastSkillToPawn));
		InputFSM->AddState(new FCWPawnInputCastSkillToTileState(InputFSM, (int)ECWPawnInputState::CastSkillToTile));
		InputFSM->AddState(new FCWPawnInputFinishState(InputFSM, (int)ECWPawnInputState::TurnInputFinish));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitInReady, (int)ECWPawnInputState::TurnWaitingAction));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitInReady, (int)ECWPawnInputState::SelectInReady));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitInReady, (int)ECWPawnInputState::TurnInputFinish));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectInReady, (int)ECWPawnInputState::WaitInReady));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectInReady, (int)ECWPawnInputState::TurnWaitingAction));
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoCtrlInReady, (int)ECWPawnInputState::WaitInReady));
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoCtrlInReady, (int)ECWPawnInputState::SelectInReady));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoCtrlInReady, (int)ECWPawnInputState::NoControl));
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoCtrlInReady, (int)ECWPawnInputState::WaitingInput));
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoControl, (int)ECWPawnInputState::TurnWaitingAction));//等操作(莫名其妙的需要)
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoControl, (int)ECWPawnInputState::WaitingInput));//轮到操作了(莫名其妙的需要)
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoControl, (int)ECWPawnInputState::Selected));//敌方棋子（其实不能转换，没有用，但避免输出error）
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoControl, (int)ECWPawnInputState::NormalAttack));//敌方棋子（其实不能转换，没有用，但避免输出error）
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NoControl, (int)ECWPawnInputState::TurnInputFinish));//敌方棋子（其实不能转换，没有用，但避免输出error）
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::TurnWaitingAction, (int)ECWPawnInputState::WaitingInput));//轮到操作了
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::TurnWaitingAction, (int)ECWPawnInputState::TurnInputFinish));//在等待中，被打死
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingInput, (int)ECWPawnInputState::Selected));//选中
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingInput, (int)ECWPawnInputState::TurnWaitingAction));//待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingInput, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		//InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::WaitInReady));
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::WaitingInput));//取消选中 回到轮到操作了
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::SelectedAndWantAttack));//选中并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::ReadyToMove));//选择了移动目标格子
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::ReadyToMoveAndWantAttack));//准备移动并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::MoveToDest));//选择了移动目标格子
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::MoveToAttack));//选择了移动攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::MoveToWaitingAttack));//选择了移动等待攻击(拖动时)
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::NormalAttack));//选择攻击目标，普通攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::CastSkillToTile));//选择攻击目标，施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::CastSkillToPawn));//选择攻击目标，施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::TurnWaitingAction));//待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::Selected, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::WaitingInput));//取消选中并且想要攻击目标 回到轮到操作了
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::ReadyToMove));//准备移动
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::ReadyToMoveAndWantAttack));//准备移动并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::NormalAttack));//普通攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::CastSkillToTile));//施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::CastSkillToPawn));//施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::SelectedAndWantAttack, (int)ECWPawnInputState::TurnInputFinish));//取消攻击，直接待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::WaitingInput));//取消准备移动，回到轮到操作了
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::SelectedAndWantAttack));//准备移动到选中并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::ReadyToMoveAndWantAttack));//准备移动到准备移动并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::MoveToDest));//准备移动到移动到目的地
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::MoveToAttack));//移动攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::MoveToWaitingAttack));//移动等待攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::TurnWaitingAction));//待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMove, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::WaitingInput));//取消准备移动并且想要攻击目标 回到轮到操作了
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::SelectedAndWantAttack));//选中并且想要攻击目标
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::ReadyToMove));//准备移动
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::MoveToAttack));//移动攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::TurnInputFinish));//取消攻击，直接待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToDest, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToDest, (int)ECWPawnInputState::WaitingInput));//客户端修正
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToDest, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::NormalAttack));//移动攻击 普通攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::CastSkillToTile));//移动攻击 施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::CastSkillToPawn));//移动攻击 施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::WaitingInput));//客户端修正
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToAttack, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToWaitingAttack, (int)ECWPawnInputState::WaitingInput));//取消选择
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToWaitingAttack, (int)ECWPawnInputState::WaitingAttack));//等待攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToWaitingAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::MoveToWaitingAttack, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::WaitingInput));//取消选择
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::NormalAttack));//选择攻击目标，普通攻击
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::CastSkillToTile));//选择攻击目标，施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::CastSkillToPawn));//选择攻击目标，施法
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::WaitingAttack, (int)ECWPawnInputState::TurnInputFinish));//取消攻击，直接待机
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NormalAttack, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NormalAttack, (int)ECWPawnInputState::WaitingInput));//技能,Buff,被动技能
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::NormalAttack, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToTile, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToTile, (int)ECWPawnInputState::WaitingInput));//技能,Buff,被动技能
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToTile, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToPawn, (int)ECWPawnInputState::TurnWaitingAction));//服务器更快
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToPawn, (int)ECWPawnInputState::WaitingInput));//技能,Buff,被动技能
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::CastSkillToPawn, (int)ECWPawnInputState::TurnInputFinish));//行动结束
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::TurnInputFinish, (int)ECWPawnInputState::TurnWaitingAction));//所有棋子操作完（或待机），等待轮到父亲操作
		InputFSM->AddTranstion(new FCWFSMTranstion((int)ECWPawnInputState::TurnInputFinish, (int)ECWPawnInputState::WaitingInput));//技能,Buff,被动技能
	}
}

void ACWPawn::SetupAction()
{
	check(ActionComponent);
	ActionComponent->SetupAction();
}

bool ACWPawn::LoadPawnDataByPawnId(int32 ParamPawnId)
{
	FCWPawnDataStruct* TempPawnData = FCWCommonUtil::FindCSVRow<FCWPawnDataStruct>(TEXT("CWPawnDataTable"), ParamPawnId);
	if (TempPawnData == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadPawnDataByPawnId fail, PawnData == nullptr, ParamPawnId:%d."), ParamPawnId);
		return false;
	}

	this->MoveSpeed = TempPawnData->MoveSpeed;
	this->MoveAnimSpeedRate = TempPawnData->MoveAnimSpeedRate;

	std::vector<float> TempArrayMeshScale = FCWPawnDataUtils::GetArrayMeshScaleFromString(TempPawnData->ArrayMeshScale);
	if (TempArrayMeshScale.size() != 3)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadPawnDataByPawnId fail, TempArrayMeshScale.size() != 3, ParamPawnId:%d."), ParamPawnId);
		return false;
	}

	this->MeshScale.X = TempArrayMeshScale[0];
	this->MeshScale.Y = TempArrayMeshScale[1];
	this->MeshScale.Z = TempArrayMeshScale[2];

	SkeletalMeshComponent->SetWorldScale3D(MeshScale);
	return true;
}

bool ACWPawn::LoadProfessionDataByProfession()
{
	FCWProfessionDataStruct* TempProfessionData = FCWCommonUtil::FindCSVRow<FCWProfessionDataStruct>(TEXT("CWProfessionDataTable"), PawnNetData.Profession);
	if (TempProfessionData == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadProfessionDataByProfession fail, TempProfessionData == nullptr, Profession:%d."), PawnNetData.Profession);
		return false;
	}

	this->MoveSpeed = TempProfessionData->MoveSpeed;
	this->MoveAnimSpeedRate = TempProfessionData->MoveAnimSpeedRate;
	
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Move, TempProfessionData->MoveValue);

	float TempHealth = GetNetDataPropertyByPropertyId(TempProfessionData->HealthSource) * TempProfessionData->HealthAddition;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Health, TempHealth);
	float TempEnergy = TempProfessionData->EnergyValue;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Energy, TempEnergy);
	float TempAttack = GetNetDataPropertyByPropertyId(TempProfessionData->AttackSource) * TempProfessionData->AttackAddition;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Attack, TempAttack);
	float TempTalent = GetNetDataPropertyByPropertyId(TempProfessionData->TalentSource) * TempProfessionData->TalentAddition;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::Talent, TempTalent);
	float TempPhysicalDefence = GetNetDataPropertyByPropertyId(TempProfessionData->PhysicalDefenceSource) * TempProfessionData->PhysicalDefenceAddition;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::PhysicalDefence, TempPhysicalDefence);
	float TempMagicDefence = GetNetDataPropertyByPropertyId(TempProfessionData->MagicDefenceSource) * TempProfessionData->MagicDefenceAddition;
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::MagicDefence, TempMagicDefence);
	BattleProperty->GetPropertySetBase().SetProperty<float>(ECWBattleProperty::FinalDamageFactor, 1.0f);
	//------------------------------------------------------------------------------------------------------------------
	BattleProperty->GetPropertySetBase().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetUniqueIdForLogic());
	BattleProperty->GetPropertySetBase().SetProperty<int32>(ECWBattleProperty::Profession, PawnNetData.Profession);
	BattleProperty->GetPropertySetBase().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

	BattleProperty->GetCurPropertySet().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetUniqueIdForLogic());
	BattleProperty->GetCurPropertySet().SetProperty<int32>(ECWBattleProperty::Profession, PawnNetData.Profession);
	BattleProperty->GetCurPropertySet().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

	BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetUniqueIdForLogic());
	BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<int32>(ECWBattleProperty::Profession, PawnNetData.Profession);
	BattleProperty->GetCurMaxTheoreticalPropertySet().SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

	BattleProperty->RecalculateCurMaxTheoreticalPropertySet();
	BattleProperty->GetCurPropertySet() = BattleProperty->GetCurMaxTheoreticalPropertySet();
	//------------------------------------------------------------------------------------------------------------------
	std::vector<float> TempArrayMeshScale = FCWProfessionDataUtils::GetArrayMeshScaleFromString(TempProfessionData->ArrayMeshScale);
	if (TempArrayMeshScale.size() != 3)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadProfessionDataByProfession fail, TempArrayMeshScale.size() != 3, Profession:%d."), PawnNetData.Profession);
		return false;
	}

	this->MeshScale.X = TempArrayMeshScale[0];
	this->MeshScale.Y = TempArrayMeshScale[1];
	this->MeshScale.Z = TempArrayMeshScale[2];

	SkeletalMeshComponent->SetWorldScale3D(MeshScale);
	return true;
}

float ACWPawn::GetNetDataPropertyByPropertyId(int32 ParamPropertyId)
{
	switch (ParamPropertyId)
	{
	case 1:
		return (float)PawnNetData.Str;
		break;
	case 2:
		return (float)PawnNetData.Dex;
		break;
	case 3:
		return (float)PawnNetData.Int;
		break;
	case 4:
		return (float)PawnNetData.Con;
		break;
	}
	
	return 1;
}

void ACWPawn::SetupBattleProperty()
{

}

void ACWPawn::SetupSkillManager()
{
	if (nullptr != SkillManager)
	{
		SkillManager->ConditionalBeginDestroy();
		SkillManager = nullptr;
	}

	SkillManager = NewObject<UCWSkillManager>(this);
	if (SkillManager != nullptr)
	{
		if (!SkillManager->Init(this))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetupSkillManager fail, SkillManager->Init fail, PawnId:%d."), PawnId);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetupSkillManager fail, SkillManager == nullptr, PawnId:%d."), PawnId);
	}
}

void ACWPawn::SetupBuffManager()
{
	if (nullptr != BuffManager)
	{
		BuffManager->ConditionalBeginDestroy();
		BuffManager = nullptr;
	}

	BuffManager = NewObject<UCWBuffManager>(this);
	if (BuffManager != nullptr)
	{
		if (!BuffManager->Init(this))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetupBuffManager fail, BuffManager->Init fail, PawnId:%d."), PawnId);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetupBuffManager fail, BuffManager == nullptr, PawnId:%d."), PawnId);
	}
}

void ACWPawn::SetupEffectInClient()
{
	if (IsInServer())
		return;

	/*const FCWPawnDataStruct* TempPawnData = this->GetPawnDataStruct();
	if (TempPawnData == nullptr)
	{
		return;
	}

	std::vector<int32> TempArrayEffectId = FCWSkillDataUtils::GetArrayAttackEffectIdFromString(TempPawnData->ArrayEffectId);
	for (int i = 0; i < TempArrayEffectId.size(); ++i)
	{
		int32 TempEffectId = TempArrayEffectId[i];
		AddEffect(TempEffectId);
	}*/
}

bool ACWPawn::InitInClient(ACWPlayerController* InPc)
{
	SetParantController(InPc);
	SetParantControllerType(ECWControllerType::NetPlayer);

	FVector CurPos = FVector::ZeroVector;
	ACWMap::tile2pos(GetTile(), CurPos);
	GetPathExplorer().SetPos(CurPos);

	//ACWMap* MyMap = GetMap();
	//check(MyMap != nullptr);
	//MyMap->MovePawn(this, -1, GetTile());

	//LoadPawnDataByPawnId(GetPawnId());
	LoadProfessionDataByProfession();
	//LoadSkeletalMesh();
	LoadSkeletalMeshByPeripheralNetId();
	//LoadSkeletalMeshShadow();
	LoadSkeletalMeshShadowByPeripheralNetId();
	//LoadAnimInstance();
	LoadAnimInstanceByPeripheralNetId();
	//LoadAnims();
	LoadAnimsByPeripheralNetId();

	SetupBuffManager();
	SetupSkillManager();

	SetupEffectInClient();

	SetupAction();
	SetupInputFSM();

	ECWCampTag InPcCamp = InPc->GetCampTag();
	ECWCampControllerIndex InPcCampIdx = InPc->GetCampControllerIndex();
	if (GetCampTag() == InPcCamp)
	{
		if (GetCampControllerIndex() == InPcCampIdx)
		{
			GetInputFSM()->Startup((int)ECWPawnInputState::WaitInReady);
		}
		else
		{
			//设置不是我自己的棋子为不可控制状态
			GetInputFSM()->Startup((int)ECWPawnInputState::NoCtrlInReady);
		}
	}
	else
	{
		//设置不是我自己的棋子为不可控制状态
		GetInputFSM()->Startup((int)ECWPawnInputState::NoCtrlInReady);
	}

	CWG_LOG(">> %s::InitInClient, NetPawnUniqueIdx:%d, CampTag:%d, ControllerIndex:%d, PawnIndex:%d", 
		*GetName(), NetPawnUniqueIdx, (int32)CampTag, (int32)ControllerIndex, (int32)PawnIndex);

	return true;
}

void ACWPawn::DungeonToReady()
{
	// 初始化(准备状态)
	//if (GetBattleState() <= ECWBattleState::Ready)
	{
		// 准备模型边缘色
		const int32 DepthValue = IsMyClientPawn() ? 100 : 102;
		SkeletalMeshComponent->SetCustomDepthStencilValue(DepthValue);
	}
}


bool ACWPawn::LoadSkeletalMeshByPeripheralNetId()
{
	FString strRace = FString::FromInt(PawnNetData.Race);
	FString strSex = FString::FromInt(PawnNetData.Sex);
	FString strProfession = FString::FromInt(PawnNetData.Profession);
	FString TempName = "SM_" + strRace + "_" + strSex + "_" + strProfession;
	USkeletalMesh* SkeletalMeshAsset = FCWCfgUtils::GetPawnAssetObject<USkeletalMesh>(this, TempName);
	if (SkeletalMeshAsset != nullptr)
	{
		SkeletalMeshComponent->SetSkeletalMesh(SkeletalMeshAsset);
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadSkeletalMeshByPeripheralNetId Fail. (%s)"), *TempName);
		return false;
	}
	return true;
}

bool ACWPawn::LoadSkeletalMeshShadowByPeripheralNetId()
{
	FString strRace = FString::FromInt(PawnNetData.Race);
	FString strSex = FString::FromInt(PawnNetData.Sex);
	FString strProfession = FString::FromInt(PawnNetData.Profession);
	FString TempName = "SM_" + strRace + "_" + strSex + "_" + strProfession;
	USkeletalMesh* ShadowSkeletalMeshAsset = FCWCfgUtils::GetPawnAssetObject<USkeletalMesh>(this, TempName);
	if (ShadowSkeletalMeshAsset != nullptr)
	{
		if (nullptr == ShadowSkeletalMeshComponent)
		{	// 初始化影子模型组件
			ShadowSkeletalMeshComponent = NewObject<USkeletalMeshComponent>(this, TEXT("ShadowSKComp"));
			AddOwnedComponent(ShadowSkeletalMeshComponent);
			ShadowSkeletalMeshComponent->RegisterComponent();
			ShadowSkeletalMeshComponent->SetCollisionEnabled(ECollisionEnabled::Type::NoCollision);
			ShadowSkeletalMeshComponent->SetCollisionResponseToAllChannels(ECR_Ignore);
			ShadowSkeletalMeshComponent->SetGenerateOverlapEvents(false);
		}
		ShadowSkeletalMeshComponent->SetWorldScale3D(MeshScale);
		ShadowSkeletalMeshComponent->SetVisibility(false);
		ShadowSkeletalMeshComponent->SetSkeletalMesh(ShadowSkeletalMeshAsset);
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadSkeletalMeshShadowByPeripheralNetId Fail. (%s)"), *TempName);
		return false;
	}

	return true;
}


bool ACWPawn::LoadAnimInstanceByPeripheralNetId()
{
	FString strRace = FString::FromInt(PawnNetData.Race);
	FString strSex = FString::FromInt(PawnNetData.Sex);
	FString strProfession = FString::FromInt(PawnNetData.Profession);
	FString TempName = "BP_AnimInst_" + strRace + "_" + strSex + "_" + strProfession;
	UClass* AnimInstClass = FCWCfgUtils::GetPawnAssetClass(this, TempName);
	if (AnimInstClass != nullptr)
	{
		SkeletalMeshComponent->SetAnimInstanceClass(AnimInstClass);
		if (nullptr != ShadowSkeletalMeshComponent)
		{
			ShadowSkeletalMeshComponent->SetAnimInstanceClass(AnimInstClass);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::LoadAnimInstanceByPeripheralNetId Fail. (%s)"), *TempName);
		return false;
	}

	//if (PawnId == 1006 || PawnId == 1007)
	//{
	//	if (TempPawnData->bIsAvatarChangePart)
	//	{
	//		check(Avatar);
	//		Avatar->ChangePart(ECWAvatarPart::UpperBody, TempPawnData->AvatarPart, TempPawnData->AvatarPartMaterial, TempPawnData->bIsChangeAvatarAnimInstance, TempPawnData->AvatarAnimInstance);
	//	}

	//	if (TempPawnData->bIsPlayOtherAnimForTestAvarta)
	//	{
	//		if (IsValidAnimPath(TempPawnData->OhterAnimForTestAvarta))
	//		{
	//			//UAnimSequence* AnimAsset = LoadObject<UAnimSequence>(nullptr, *AnimName);
	//			UAnimSequence* AnimAsset = FCWCfgUtils::GetPawnAssetObject<UAnimSequence>(this, TempPawnData->OhterAnimForTestAvarta);
	//			if (nullptr != AnimAsset)
	//			{
	//				PlayAnimSequence(AnimAsset, 0.25f, 0.25f, 1.0f, 1000000);
	//			}
	//		}
	//	}
	//}

	return true;
}


bool ACWPawn::LoadAnimsByPeripheralNetId()
{
	FString strRace = FString::FromInt(PawnNetData.Race);
	FString strSex = FString::FromInt(PawnNetData.Sex);
	FString strProfession = FString::FromInt(PawnNetData.Profession);
	FString strWeapon = FString::FromInt(PawnNetData.Weapon);

	FString TempName = "AS_" + strRace + "_" + strSex + "_" + strProfession + "_" + strWeapon;
	CombinationName = TempName;

	MapAnims.Empty();

	// Idle
	FString IdleAnimName = TempName + "_Idle";
	if (!AddAnimSequence(ECWPawnAnim::Idle01, IdleAnimName))
	{
		return false;
	}

	// Move
	FString RunAnimName = TempName + "_Run";
	if (!AddAnimSequence(ECWPawnAnim::Move01, RunAnimName))
	{
		return false;
	}

	// BeHit
	FString BeHitAnimName = TempName + "_BeHit";
	if (!AddAnimSequence(ECWPawnAnim::BeHit01, BeHitAnimName))
	{
		return false;
	}

	// Die
	FString DieAnimName = TempName + "_Die";
	if (!AddAnimSequence(ECWPawnAnim::Die01, DieAnimName))
	{
		return false;
	}

	// Death
	FString DeathAnimName = TempName + "_Death";
	if (!AddAnimSequence(ECWPawnAnim::Death01, DeathAnimName))
	{
		return false;
	}

	// IdleNoAction
	FString IdleNoActionAnimName = TempName + "_IdleNoAction";
	if (!AddAnimSequence(ECWPawnAnim::IdleNoAction01, IdleNoActionAnimName))
	{
		return false;
	}

	// Defence
	FString DefenceAnimName = TempName + "_Defence";
	if (!AddAnimSequence(ECWPawnAnim::Defence01, DefenceAnimName))
	{
		return false;
	}

	// SpawnAction
	FString SpawnAnimName = TempName + "_Spawn";
	if (!AddAnimSequence(ECWPawnAnim::SpawnAction01, SpawnAnimName))
	{
		return false;
	}

	// ForceMoveAction
	FString ForceMoveAnimName = TempName + "_ForceMove";
	if (!AddAnimSequence(ECWPawnAnim::ForceMove, ForceMoveAnimName))
	{
		return false;
	}

	// Dizziness Action
	FString DizzinessAnimName = TempName + "_Dizziness";
	if (!AddAnimSequence(ECWPawnAnim::Dizziness, DizzinessAnimName))
	{
		return false;
	}

	return true;
}

void ACWPawn::AddAnim(ECWPawnAnim AnimType, UAnimSequence* AnimSequence)
{
	check(AnimSequence);
	MapAnims.Add(AnimType, AnimSequence);
}

bool ACWPawn::AddAnimSequence(ECWPawnAnim AnimType, const FString& AnimName)
{
	if (IsValidAnimPath(AnimName))
	{
		//UAnimSequence* AnimAsset = LoadObject<UAnimSequence>(nullptr, *AnimName);
		UAnimSequence* AnimAsset = FCWCfgUtils::GetPawnAssetObject<UAnimSequence>(this, AnimName);
		if (nullptr != AnimAsset)
		{
			AddAnim(AnimType, AnimAsset);
			return true;
		}
	}
	CWG_WARNING(">>> %s::AddAnimSequence Fail. AnimType[%s] AnimName[%s] PawnId[%d].", 
		*GetName(), *FCWCommonUtil::EnumToString(TEXT("ECWPawnAnim"), AnimType), *AnimName, PawnId);
	return false;
}

bool ACWPawn::IsValidAnimPath(const FString& AnimName) const
{
	return !(AnimName.IsEmpty() || AnimName.Equals(TEXT("None")));
}

bool ACWPawn::IsThereAnimSequence(ECWPawnAnim AnimType)
{
	if (!MapAnims.Contains(AnimType))
	{
		return false;
	}

	return true;
}
bool ACWPawn::IsThereAnimSequence(int32 ParamSkillId)
{
	UCWSkill* TempSkill = SkillManager->GetSkill(ParamSkillId);
	if (TempSkill != nullptr)
	{
		return TempSkill->IsThereAnimSequence();
	}

	return false;
}

bool ACWPawn::IsThereNormalAttackAnimSequence()
{
	UCWSkill* TempNormalAttack = SkillManager->GetNormalAttack();
	if (TempNormalAttack != nullptr)
	{
		return TempNormalAttack->IsThereAnimSequence();
	}

	return false;
}

bool ACWPawn::IsThereCounterAttackAnimSequence()
{
	UCWSkill* TempGetCounterAttack = SkillManager->GetCounterAttack();
	if (TempGetCounterAttack != nullptr)
	{
		return TempGetCounterAttack->IsThereAnimSequence();
	}

	return false;
}

void ACWPawn::PlayAnimSequence(ECWPawnAnim AnimType, float ParamBlendInTime, float ParamBlendOutTime, float ParamPlayRate, int ParamLoopCount)
{
	if (!MapAnims.Contains(AnimType))
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::PlayAnimSequence Fail. !MapAnims.Contains(AnimType), AnimType:%s, CombinationName:%s."), *FCWCommonUtil::EnumToString(TEXT("ECWPawnAnim"), AnimType), *CombinationName);
		return;
	}

	UAnimSequence* AnimSequence = MapAnims[AnimType];
	if (AnimSequence == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::PlayAnimSequence Fail. AnimSequence == nullptr, AnimType::(%s), CombinationName:%s."), *FCWCommonUtil::EnumToString(TEXT("ECWPawnAnim"), AnimType), *CombinationName);
		return;
	}

	CurPlayAnimType = AnimType;
	PlayAnimSequence(AnimSequence, ParamBlendInTime, ParamBlendOutTime, ParamPlayRate, ParamLoopCount);
}

void ACWPawn::PlayAnimSequence(UAnimSequence* ParamAnimSequence, float ParamBlendInTime, float ParamBlendOutTime, float ParamPlayRate, int ParamLoopCount)
{
	check(ParamAnimSequence);
	UAnimInstance* AnimInstance = SkeletalMeshComponent->GetAnimInstance();
	if (AnimInstance != nullptr)
	{
		UAnimMontage* TempAnimMontage = AnimInstance->PlaySlotAnimationAsDynamicMontage(ParamAnimSequence, TEXT("DefaultSlot"), ParamBlendInTime, ParamBlendOutTime, ParamPlayRate, ParamLoopCount);
		if (TempAnimMontage == nullptr)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::PlayAnimSequence Fail.  TempAnimMontage == nullptr, ParamAnimSequence::(%X)"), ParamAnimSequence);
		}
		else if(!IsNetMode(NM_DedicatedServer) &&
				CurPlayAnimType != ECWPawnAnim::Idle01 &&
				CurPlayAnimType != ECWPawnAnim::Idle02 &&
				CurPlayAnimType != ECWPawnAnim::Move01 &&
				CurPlayAnimType != ECWPawnAnim::Move02)
		{
			// Play Anim Sound
			PlayAnimSound(GET_AK_EVENT_NAME(ParamAnimSequence, TEXT("")), ParamBlendInTime, ParamBlendOutTime, ParamPlayRate);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::PlayAnimSequence Fail.  ParamAnimSequence::(%X)"), ParamAnimSequence);
	}
}

bool ACWPawn::PlayAnimSound(const FString& InAnimSoundKey, float InBlendInTime, float InBlendOutTime, float InPlayRate)
{
	if (InAnimSoundKey.IsEmpty())
	{
		CWG_WARNING(">> %s::PlayAnimSound, InAnimSoundKey IsEmpty!!!", *CWG_NAME(this));
		return false;
	}

	if (!IsValidCompnent(AkAnimPlayComp))
	{
		//const FName AttachName = TEXT("DefaultSlot");
		AkAnimPlayComp = UAkGameplayStatics::GetAkComponent(SkeletalMeshComponent/*, AttachName*/);
		if (nullptr != AkAnimPlayComp)
		{
			AkAnimPlayComp->OcclusionCollisionChannel = ECC_Destructible;
		}
		//check(AkAnimPlayComp);
	}

	int32 NewAkPlayingID = AK_INVALID_PLAYING_ID;
	if (IsValidCompnent(AkAnimPlayComp))
	{
		NewAkPlayingID = AkAnimPlayComp->PostAkEventByName(InAnimSoundKey);
		if (AK_INVALID_PLAYING_ID == NewAkPlayingID)
		{
			AkAnimPlayComp->Stop();
			CWG_WARNING(">> %s::PlayAnimSound, NewAkPlayingID Is invalid(Force Stop)! InAnimSoundKey[%s].", *CWG_NAME(this), *InAnimSoundKey);
		}
	}

	return AK_INVALID_PLAYING_ID != NewAkPlayingID;
}

void ACWPawn::OnAnimDamage(int32 RoundIndex)
{
	if (IsInServer())
	{
		UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::OnAnimDamage, TargetTile:%d, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), TargetTile, (int)this->GetCampTag(), (int)this->GetCampControllerIndex(), (int)this->GetControllerPawnIndex());

		ACWPawn* TargetPawn = nullptr;
		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWPawn* TempPawn = *Iter;
			//if (TempPawn != nullptr)
			//{
			//	bool TempIsItem = TempPawn->IsPawnType(ECWPawnType::DungeonItem);
			//
			//	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::OnAnimDamage, TempPawn->GetTile():%d, TempIsItem:%d."), TempPawn->GetTile(), TempIsItem);
			//}

			if (TempPawn != nullptr &&
				TempPawn->GetTile() == TargetTile &&
				((TempPawn->IsPawnType(ECWPawnType::Character)) || 
				(TempPawn->IsPawnType(ECWPawnType::DungeonItem) && ((ACWDungeonItem*)TempPawn)->IsCanAttack())))
			{
				TargetPawn = TempPawn;
				break;
			}
		}

		if (TargetPawn != nullptr)
		{
			UCWPawnBattlePropertyComponent* TargetPawnBattlePropertComponent = TargetPawn->GetBattleProperty();
			check(TargetPawnBattlePropertComponent);

			ACWPlayerController* MyParantController = Cast<ACWPlayerController>(ParantController);
			check(MyParantController);

			UCWPawnBattlePropertyComponent* MyPawnBattlePropertComponent = this->GetBattleProperty();
			check(MyPawnBattlePropertComponent);

			const FCWProfessionDataStruct* TempProfessionData = this->GetProfessionData();
			//------------------------------------------------------------------------
			//获得当前的释放技能
			UCWSkill* TempSkill = nullptr;
			if (SkillIdWhenCastSkill == -1)
			{
				if (!IsCounterAttackWhenCastSkill())
				{
					TempSkill = this->GetSkillManager()->GetNormalAttack();
				}
				else
				{
					TempSkill = this->GetSkillManager()->GetCounterAttack();
				}
			}
			else
			{
				TempSkill = this->GetSkillManager()->GetSkill(SkillIdWhenCastSkill);
			}
			if (TempSkill == nullptr)
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::OnAnimDamage Fail, TempSkill == nullptr, SkillIdWhenCastSkill:%d."), SkillIdWhenCastSkill);
				return;
			}
			//------------------------------------------------------------------------
			//生成释放技能上下文的数据
			FCWBattlePropertySet TempSkillPropertySet;
			TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::UniqueId, this->GetPawnUniqueIdx());
			TempSkillPropertySet.SetProperty<int32>(ECWBattleProperty::Profession, this->GetProfession());
			TempSkillPropertySet.SetProperty<ECWBattleAttackType>(ECWBattleProperty::AttackType, ECWBattleAttackType::Physical);

			TSharedPtr<UCWCastSkillContext> TempCastSkillContextPtr = TSharedPtr<UCWCastSkillContext>(new UCWCastSkillContext());
			TempCastSkillContextPtr->PawnWeakPtr = this;
			TempCastSkillContextPtr->PawnCampTag = this->GetCampTag();
			TempCastSkillContextPtr->PawnCampControllerIndex = this->GetCampControllerIndex();
			TempCastSkillContextPtr->PawnControllerPawnIndex = this->GetControllerPawnIndex();
			TempCastSkillContextPtr->bIsCounterAttack = this->IsCounterAttackWhenCastSkill();
			TempCastSkillContextPtr->PawnPos = this->GetActorLocation();
			TempCastSkillContextPtr->PawnRotator = this->GetActorRotation();
			TempCastSkillContextPtr->ArrayDamageTile = GenerateDamageTileBySkill(this, TargetPawn, TempSkill);
			TempCastSkillContextPtr->ProjectileTargetPawnWeakPtr = TargetPawn;
			TempCastSkillContextPtr->PlayerControllerWeakPtr = MyParantController;
			TempCastSkillContextPtr->CastSkillPropertySet = TempSkillPropertySet;
			TempCastSkillContextPtr->CastSkillDataStruct = TempSkill->GetSkillDataStruct();
			TempCastSkillContextPtr->PawnPropertySetBase = MyPawnBattlePropertComponent->GetPropertySetBase();
			TempCastSkillContextPtr->CopyMapStatisticsData(this->GetStatisticsSysMapData());
			TempCastSkillContextPtr->CopyArrayAffectorData(MyPawnBattlePropertComponent->GetArrayPropertyAffectorData());
			TempCastSkillContextPtr->PawnCurMaxTheoreticalPropertySet = MyPawnBattlePropertComponent->GetCurMaxTheoreticalPropertySet();
			TempCastSkillContextPtr->PawnCurPropertySet = MyPawnBattlePropertComponent->GetCurPropertySet();
			//------------------------------------------------------------------------
			if (TempSkill->GetSkillDataStruct()->IsGenerateProjectile == 1)
			{
				//产生飞行器
				TempSkill->GenerateProjectileToPawn(TargetPawn, TempCastSkillContextPtr);
			}
			else
			{
				//技能产生伤害
				if (TempCastSkillContextPtr->CastSkillDataStruct->DamageCount > 0)
				{
					const bool bIsDamage = UCWBattleCalculate::Get()->CalculateDamageBySkill(TempCastSkillContextPtr, TargetPawn, DamageIndexWhenCastSkill++);
					//------------------------------------------------------------------------
					//目标当前血量 血量检测
					if (IsValid(TargetPawn))
					{
						float CurTargetHealth = TargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
						if (CurTargetHealth <= 0.0f)
						{
							TargetPawn->DieInServer();
						}
					}
					//------------------------------------------------------------------------
				}
				//------------------------------------------------------------------------
				//计算关键时间点
				ECWKeyTimeType TempKeyTimeType = ECWKeyTimeType::None;
				if (GetDamageIndexWhenCastSkill() == 1 || GetDamageIndexWhenCastSkill() == 0)
				{
					TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage01 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage01 : ECWKeyTimeType::InitiativeSkillDamage01;
				}
				else if (GetDamageIndexWhenCastSkill() == 2)
				{
					TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage02 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage02 : ECWKeyTimeType::InitiativeSkillDamage02;
				}
				else if (GetDamageIndexWhenCastSkill() == 3)
				{
					TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage03 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage03 : ECWKeyTimeType::InitiativeSkillDamage03;
				}
				//------------------------------------------------------------------------
				//关键时间点触发 产生伤害
				this->OnKeyTimeInServer(TempKeyTimeType);
				//------------------------------------------------------------------------
				//技能产生Buff
				//if (!TempSkill->IsNormalAttack())
				{
					if (GenerateBuffByCastSkillContext(TempCastSkillContextPtr, TargetPawn, TargetPawnBattlePropertComponent, TempSkill, TempKeyTimeType))
					{
						TempSkill->IncreaseTriggerBuffCountForRound();
					}
					else
					{
						//UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::OnAnimDamage InServer, GenerateBuffByCastSkillContext fail."));
					}
				}
				//------------------------------------------------------------------------
				//目标当前血量 血量检测
				if (IsValid(TargetPawn))
				{
					float CurTargetHealth = TargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
					if (CurTargetHealth <= 0.0f)
					{
						TargetPawn->DieInServer();
					}
				}
				//------------------------------------------------------------------------
				TargetPawn->BeHitInServer(
					this->GetCampTag(),
					this->GetCampControllerIndex(),
					this->GetControllerPawnIndex(),
					TempSkill->GetSkillId(),
					IsCounterAttackWhenCastSkill());
				//------------------------------------------------------------------------
			}
		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::OnAnimDamage InServer, TargetPawn == nullptr, TargetTile:%d, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), TargetTile, (int)this->GetCampTag(), (int)this->GetCampControllerIndex(), (int)this->GetControllerPawnIndex());
		}
	}
}

bool ACWPawn::GenerateBuffByCastSkillContext(
	TSharedPtr<UCWCastSkillContext> ParamCastSkillContext,
	ACWPawn* ParamTargetPawn,
	const UCWPawnBattlePropertyComponent* ParamTargetPawnBattlePropertyComponent,
	const UCWSkill* ParamSkill,
	ECWKeyTimeType ParamKeyTimeType)
{
	check(ParamCastSkillContext);
	check(ParamTargetPawn);
	check(ParamTargetPawnBattlePropertyComponent);
	check(ParamSkill);

	const FCWSkillDataStruct* CasterSkillData = ParamCastSkillContext->CastSkillDataStruct;
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionType = FCWSkillDataUtils::GetArrayArrayBuffTriggerConditionType(CasterSkillData->ArrayArrayBuffTriggerConditionType);
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConditionLogicOp = FCWSkillDataUtils::GetArrayArrayBuffTriggerConditionLogicOp(CasterSkillData->ArrayArrayBuffTriggerConditionLogicOp);
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerConcretenessCondition = FCWSkillDataUtils::GetArrayArrayBuffTriggerConcretenessCondition(CasterSkillData->ArrayArrayBuffTriggerConcretenessCondition);
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOp = FCWSkillDataUtils::GetArrayArrayBuffTriggerCompareRelatioinOp(CasterSkillData->ArrayArrayBuffTriggerCompareRelatioinOp);
	std::vector<std::vector<int32> > ArrayArrayBuffTriggerCompareRelatioinOpValueType = FCWSkillDataUtils::GetArrayArrayBuffTriggerCompareRelatioinOpValueType(CasterSkillData->ArrayArrayBuffTriggerCompareRelatioinOpValueType);
	std::vector<std::vector<float> > ArrayArrayBuffTriggerConcretenessParams = FCWSkillDataUtils::GetArrayArrayBuffTriggerConcretenessParams(CasterSkillData->ArrayArrayBuffTriggerConcretenessParams);
	std::vector<int32> ArrayBuffId = FCWSkillDataUtils::GetArrayBuffIdFromString(CasterSkillData->ArrayBuffId);

	bool OneMoreSuccess = false;
	// 直接跳过条件&生成对应BUFF
	if (ArrayArrayBuffTriggerConditionType.size() == 0 &&
		ArrayArrayBuffTriggerConditionLogicOp.size() == 0 &&
		ArrayArrayBuffTriggerConcretenessCondition.size() == 0 &&
		ArrayArrayBuffTriggerCompareRelatioinOp.size() == 0 &&
		ArrayArrayBuffTriggerCompareRelatioinOpValueType.size() == 0 &&
		ArrayArrayBuffTriggerConcretenessParams.size() == 0)
	{
		const int32 NewBuffNum = ArrayBuffId.size();
		if (CasterSkillData->BuffNum != NewBuffNum)
		{
			CWG_ERROR(">> %s::GenerateBuffByCastSkillContext, CasterSkillData->BuffNum[%d] != NewBuffNum[%d] SkillId[%d].", 
				*GetName(), CasterSkillData->BuffNum, NewBuffNum, CasterSkillData->SkillId);
			return false;
		}
		for (int i = 0; i < NewBuffNum; ++i)
		{
			const int32 NewBuffId = ArrayBuffId[i];
			UCWBuff* NewBuffObj = ParamTargetPawn->GenerateBuff(NewBuffId, ECWBuffSouceType::Skill);
			if (nullptr != NewBuffObj)
			{
				OneMoreSuccess = true;
			}
		}

		return OneMoreSuccess;
	}

	// 检测条件&生成对应BUFF
	for (int i = 0; i < ParamCastSkillContext->CastSkillDataStruct->BuffNum; ++i)
	{
		if (ArrayArrayBuffTriggerConditionType.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerConditionType.size() <= i, ArrayArrayBuffTriggerConditionType.size():%d, i:%d."), ArrayArrayBuffTriggerConditionType.size(), i);
			return false;
		}

		if (ArrayArrayBuffTriggerConditionLogicOp.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerConditionLogicOp.size() <= i, ArrayArrayBuffTriggerConditionLogicOp.size():%d, i:%d."), ArrayArrayBuffTriggerConditionLogicOp.size(), i);
			return false;
		}

		if (ArrayArrayBuffTriggerConcretenessCondition.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerConcretenessCondition.size() <= i, ArrayArrayBuffTriggerConcretenessCondition.size():%d, i:%d."), ArrayArrayBuffTriggerConcretenessCondition.size(), i);
			return false;
		}

		if (ArrayArrayBuffTriggerCompareRelatioinOp.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerCompareRelatioinOp.size() <= i, ArrayArrayBuffTriggerCompareRelatioinOp.size():%d, i:%d."), ArrayArrayBuffTriggerCompareRelatioinOp.size(), i);
			return false;
		}

		if (ArrayArrayBuffTriggerCompareRelatioinOpValueType.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerCompareRelatioinOpValueType.size() <= i, ArrayArrayBuffTriggerCompareRelatioinOpValueType.size():%d, i:%d."), ArrayArrayBuffTriggerCompareRelatioinOpValueType.size(), i);
			return false;
		}

		if (ArrayArrayBuffTriggerConcretenessParams.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayArrayBuffTriggerConcretenessParams.size() <= i, ArrayArrayBuffTriggerConcretenessParams.size():%d, i:%d."), ArrayArrayBuffTriggerConcretenessParams.size(), i);
			return false;
		}

		if (ArrayBuffId.size() <= i)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffId.size() <= i, ArrayBuffId.size():%d, i:%d."), ArrayBuffId.size(), i);
			return false;
		}

		std::vector<int32> ArrayBuffTriggerConditionType = ArrayArrayBuffTriggerConditionType[i];
		std::vector<int32> ArrayBuffTriggerConditionLogicOp = ArrayArrayBuffTriggerConditionLogicOp[i];
		std::vector<int32> ArrayBuffTriggerConcretenessCondition = ArrayArrayBuffTriggerConcretenessCondition[i];
		std::vector<int32> ArrayBuffTriggerCompareRelatioinOp = ArrayArrayBuffTriggerCompareRelatioinOp[i];
		std::vector<int32> ArrayBuffTriggerCompareRelatioinOpValueType = ArrayArrayBuffTriggerCompareRelatioinOpValueType[i];
		std::vector<float> ArrayBuffTriggerConcretenessParams = ArrayArrayBuffTriggerConcretenessParams[i];

		std::vector<bool> ArrayConditionResult;
		for (int j = 0; j < ArrayBuffTriggerConditionType.size(); ++j)
		{
			ECWTriggerConditionType TriggerConditionType = (ECWTriggerConditionType)ArrayBuffTriggerConditionType[j];

			/*if (TriggerConditionType == ECWTriggerConditionType::None)
			{
				ArrayConditionResult.push_back(true);
			}*/

			if (TriggerConditionType == ECWTriggerConditionType::KeyTime)
			{
				if (ArrayBuffTriggerConcretenessCondition.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerConcretenessCondition.size() <= j, ArrayBuffTriggerConcretenessCondition.size():%d, j:%d."), ArrayBuffTriggerConcretenessCondition.size(), j);
					return false;
				}

				ECWKeyTimeType TempKeyTimeType = (ECWKeyTimeType)ArrayBuffTriggerConcretenessCondition[j];
				if (IsSameKeyTime(TempKeyTimeType, ParamKeyTimeType))
				{
					ArrayConditionResult.push_back(true);
				}
				else
				{
					ArrayConditionResult.push_back(false);
				}
			}
			
			if (TriggerConditionType == ECWTriggerConditionType::Probability)
			{
				if (ArrayBuffTriggerConcretenessParams.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerConcretenessParams.size() <= j, ArrayBuffTriggerConcretenessParams.size():%d, j:%d."), ArrayBuffTriggerConcretenessParams.size(), j);
					return false;
				}

				float TempProbability = ArrayBuffTriggerConcretenessParams[j];
				float TempRandom = RandomFloat(0.0f, 1.0f);
				if (TempRandom <= TempProbability)
				{
					ArrayConditionResult.push_back(true);
				}
				else
				{
					ArrayConditionResult.push_back(false);

					UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, SkillId:%d Generate Buff fail. Because TempRandom:%f, TempProbability:%f,  BuffId:%d, Add to Pawn, PawnCampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d."), ParamCastSkillContext->CastSkillDataStruct->SkillId, TempRandom, TempProbability, ArrayBuffId[i], (int)ParamTargetPawn->GetCampTag(), (int)ParamTargetPawn->GetCampControllerIndex(), (int)ParamTargetPawn->GetControllerPawnIndex());
				}
			}

			if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty ||
				TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
			{
				if (ArrayBuffTriggerConcretenessCondition.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerConcretenessCondition.size() <= j, ArrayBuffTriggerConcretenessCondition.size():%d, j:%d."), ArrayBuffTriggerConcretenessCondition.size(), j);
					return false;
				}

				if (ArrayBuffTriggerCompareRelatioinOp.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerCompareRelatioinOp.size() <= j, ArrayBuffTriggerCompareRelatioinOp.size():%d, j:%d."), ArrayBuffTriggerCompareRelatioinOp.size(), j);
					return false;
				}

				if (ArrayBuffTriggerCompareRelatioinOpValueType.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerCompareRelatioinOpValueType.size() <= j, ArrayBuffTriggerCompareRelatioinOpValueType.size():%d, j:%d."), ArrayBuffTriggerCompareRelatioinOpValueType.size(), j);
					return false;
				}

				if (ArrayBuffTriggerConcretenessParams.size() <= j)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayBuffTriggerConcretenessParams.size() <= j, ArrayBuffTriggerConcretenessParams.size():%d, j:%d."), ArrayBuffTriggerConcretenessParams.size(), j);
					return false;
				}

				ECWBattleProperty TempBattlePropertyType = (ECWBattleProperty)ArrayBuffTriggerConcretenessCondition[j];
				ECWTriggerConditionTypeRelationOp TempRelationOp = (ECWTriggerConditionTypeRelationOp)ArrayBuffTriggerCompareRelatioinOp[j];
				ECWTriggerConditionTypeRelationOpValueType TempRelationOpValueType = (ECWTriggerConditionTypeRelationOpValueType)ArrayBuffTriggerCompareRelatioinOpValueType[j];
				float TempBattlePropertyValue = 0.0f;
				if (TempRelationOpValueType == ECWTriggerConditionTypeRelationOpValueType::Value)
				{
					if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty)
						TempBattlePropertyValue = ParamCastSkillContext->PawnCurPropertySet.GetPropertyByFloat(TempBattlePropertyType);
					if (TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
						TempBattlePropertyValue = ParamTargetPawnBattlePropertyComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
				}
				else if(TempRelationOpValueType == ECWTriggerConditionTypeRelationOpValueType::CurPercentMax)
				{
					if (TriggerConditionType == ECWTriggerConditionType::CastSkillBattleProperty)
					{
						float TempCurValue = ParamCastSkillContext->PawnCurPropertySet.GetPropertyByFloat(TempBattlePropertyType);
						float TempCurMaxTheoreticalValue = ParamCastSkillContext->PawnCurMaxTheoreticalPropertySet.GetPropertyByFloat(TempBattlePropertyType);
						if (FMath::Abs(TempCurMaxTheoreticalValue) > 0.0001f)
						{
							TempBattlePropertyValue = TempCurValue / TempCurMaxTheoreticalValue;
						}
						else
						{
							TempBattlePropertyValue = 0.0f;
						}
					}
					if (TriggerConditionType == ECWTriggerConditionType::TargetBattleProperty)
					{
						float TempCurValue = ParamTargetPawnBattlePropertyComponent->GetCurPropertySet().GetPropertyByFloat(TempBattlePropertyType);
						float TempCurMaxTheoreticalValue = ParamTargetPawnBattlePropertyComponent->GetCurMaxTheoreticalPropertySet().GetPropertyByFloat(TempBattlePropertyType);
						if (FMath::Abs(TempCurMaxTheoreticalValue) > 0.0001f)
						{
							TempBattlePropertyValue = TempCurValue / TempCurMaxTheoreticalValue;
						}
						else
						{
							TempBattlePropertyValue = 0.0f;
						}
					}
				}
				
				float TempParam = ArrayBuffTriggerConcretenessParams[j];
				if (TempRelationOp == ECWTriggerConditionTypeRelationOp::Equal)
				{
					if (FMath::Abs(TempBattlePropertyValue - TempParam) <= 0.0000001f)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::NoEqual)
				{
					if (FMath::Abs(TempBattlePropertyValue - TempParam) > 0.0000001f)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::LessThan)
				{
					if (TempBattlePropertyValue < TempParam)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::EqualOrLessThan)
				{
					if (TempBattlePropertyValue <= TempParam)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::GreaterThan)
				{
					if (TempBattlePropertyValue > TempParam)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else if (TempRelationOp == ECWTriggerConditionTypeRelationOp::GreaterOrLessThan)
				{
					if (TempBattlePropertyValue >= TempParam)
					{
						ArrayConditionResult.push_back(true);
					}
					else
					{
						ArrayConditionResult.push_back(false);
					}
				}
				else
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, TempRelationOp is invalid value, TempRelationOp:%d."), (int)TempRelationOp);
					return false;
				}
			}

			if (TriggerConditionType == ECWTriggerConditionType::RoundTriggerCount)
			{
				float TempParam = ArrayBuffTriggerConcretenessParams[j];
				if (ParamSkill->GetTriggerBuffCountForRound() < TempParam)
				{
					ArrayConditionResult.push_back(true);
				}
				else
				{
					ArrayConditionResult.push_back(false);
				}
			}
		}


		if (ArrayConditionResult.size() == 0)
		{
			//return true;
		}
		else if (ArrayConditionResult.size() == 1)
		{
			bool TempResult = ArrayConditionResult[0];
			if (!TempResult)
				continue;
		}
		else
		{
			if (ArrayConditionResult.size() - 1 != ArrayBuffTriggerConditionLogicOp.size())
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, ArrayConditionResult.size() - 1 != ArrayBuffTriggerConditionLogicOp.size(), ArrayConditionResult.size():%d, ArrayBuffTriggerConditionLogicOp.size():%d."), ArrayConditionResult.size(), ArrayBuffTriggerConditionLogicOp.size());
				return false;
			}

			bool TempFinalResult = true;
			for (int m = 1; m < ArrayConditionResult.size(); ++m)
			{
				bool TempResult1 = ArrayConditionResult[m - 1];
				bool TempResult2 = ArrayConditionResult[m];
				ECWTriggerConditionTypeLogicOp TempLogicOp = (ECWTriggerConditionTypeLogicOp)ArrayBuffTriggerConditionLogicOp[m - 1];
				if (TempLogicOp == ECWTriggerConditionTypeLogicOp::And)
				{
					if (TempResult1 && TempResult2)
					{
					}
					else
					{
						TempFinalResult = false;
					}
				}
				else if (TempLogicOp == ECWTriggerConditionTypeLogicOp::Or)
				{
					if (TempResult1 || TempResult2)
					{
					}
					else
					{
						TempFinalResult = false;
					}
				}
			}

			//这个Buff最终是否触发
			if (!TempFinalResult)
				continue;
		}

		int32 TempBuffId = ArrayBuffId[i];
		UCWBuff* TempBuff = new UCWBuff();
		if (TempBuff != nullptr)
		{
			TempBuff->SetSouceType(ECWBuffSouceType::Skill);
			int32 TempBuffUniqueId = ParamTargetPawn->GetBuffManager()->GenerateBuffUniqueId();
			if (TempBuff->InitInServer(ParamTargetPawn->GetBuffManager(), TempBuffUniqueId, TempBuffId, ParamCastSkillContext))
			{
				if (ParamTargetPawn->GetBuffManager()->AddBuffInServer(TempBuff))
				{
					OneMoreSuccess = true;
				}
				else
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer fail. ParamTargetPawn->GetBuffManager()->AddBuff fail, TempBuffId:%d."), TempBuffId);
					delete TempBuff;
					continue;
				}
			}
			else
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer fail. TempBuffId->Init fail, TempBuffId:%d."), TempBuffId);
				delete TempBuff;
				continue;
			}
		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateBuffByCastSkillContext InServer, TempBuff == nullptr, TempBuffId:%d."), TempBuffId);
			return false;
		}
	}

	if (OneMoreSuccess)
		return true;
	else
		return false;
}

UCWBuff* ACWPawn::GenerateBuff(const int32 InBuffId, const ECWBuffSouceType InSouceType)
{
	if (IsPendingKillPending() || !IsValidObject(BuffManager) || (InBuffId <= 0))
	{
		CWG_WARNING(">>> %s::GenerateBuff, Fail! InBuffId[%d] InSouceType[%s].", *GetName(), InBuffId, *FCWToString::ToString(InSouceType));
		return nullptr;
	}

	if (const FCWBuffDataStruct* BuffData = FCWCfgUtils::GetBuffData(this, InBuffId))
	{
		if (UCWBuff* NewBuffObj = new UCWBuff())
		{
			NewBuffObj->SetSouceType(InSouceType);
			int32 BuffUniqueId = BuffManager->GenerateBuffUniqueId();
			if (NewBuffObj->InitInServer(BuffManager, BuffUniqueId, InBuffId, nullptr))
			{
				if (BuffManager->AddBuffInServer(NewBuffObj))
				{
					CWG_LOG(">> %s::GenerateBuff, Successful! NetPawnUniqueIdx[%d] InBuffId[%d] BuffUniqueId[%d] InSouceType[%s].", 
						*GetName(), NetPawnUniqueIdx, InBuffId, BuffUniqueId, *FCWToString::ToString(InSouceType));
					return NewBuffObj;
				}
			}

			delete NewBuffObj;
		}
	}

	return nullptr;
}

bool ACWPawn::CheckAndExecDieInServer()
{
	if (nullptr != BattleProperty)
	{
		float CurHealth = BattleProperty->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
		if (CurHealth <= 0.0f)
		{
			DieInServer();
			return true;
		}
	}
	return false;
}

ACWPawn* ACWPawn::GetCurTargetPawn()
{
	ACWPawn* TargetPawn = nullptr;
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr &&
			TempPawn->GetCampTag() == TargetCampTag &&
			TempPawn->GetCampControllerIndex() == TargetCampControllerIndex &&
			TempPawn->GetControllerPawnIndex() == TargetControllerPawnIndex)
		{
			TargetPawn = TempPawn;
			break;
		}
	}

	return TargetPawn;
}

float ACWPawn::RandomFloat(float min, float max)
{
	std::default_random_engine Generator(time(nullptr));
	std::uniform_real_distribution<float> Distribution(min, max);
	auto dice = std::bind(Distribution, Generator);
	return dice();
}

void ACWPawn::OnAnimFinish(int32 RoundIndex)
{
	if (IsInServer())
	{
		check(ActionComponent);
		ActionComponent->OnAnimFinish(RoundIndex);
	}
	else
	{
		check(ActionComponent);
		ActionComponent->OnAnimFinish(RoundIndex);
	}
	return;

	//if (IsInServer())
	//{
	//	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::OnAnimFinish InServer, RoundIndex:%d."), RoundIndex);
	//	ACWPlayerController* MyPlayerController = (ACWPlayerController*)ParantController;
	//	check(MyPlayerController);
	//	ACWGameState* GameState = GetWorld()->GetAuthGameMode()->GetGameState<ACWGameState>();
	//	check(GameState);
	//	bool bIsTrigger = false;
	//	if (RoundIndexWhenAction == GameState->GetCurRoundIndex() &&
	//		(GameState->GetCurCampTag() == this->GetCampTag() && GameState->GetCurCampControllerIndex() == this->GetCampControllerIndex()))
	//	{
	//		ECWPawnActionState CurActionFSMStateId = this->GetCurActionFSMStateId();
	//		if (CurActionFSMStateId == ECWPawnActionState::NormalAttack ||
	//			CurActionFSMStateId == ECWPawnActionState::CastSkillToPawn ||
	//			CurActionFSMStateId == ECWPawnActionState::CastSkillToTile)
	//		{
	//			if (MyPlayerController->IsMyTurn(this) &&
	//				CanInstructsByCurInstructs())
	//			{
	//				FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
	//				ActionFSM->DoEvent(ToIdleEvent);
	//				AutoSelectSkill();
	//			}
	//			else
	//			{
	//				ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	//				FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, true, false);
	//				ActionFSM->DoEvent(ToEndEvent);
	//			}
	//		}
	//		else
	//		{
	//			if (CurActionFSMStateId == ECWPawnActionState::Die)
	//			{
	//				FCWPawnActionToDeathEvent* ToDeathEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	//				ActionFSM->DoEvent(ToDeathEvent);
	//			}
	//			else
	//			{
	//				if (MyPlayerController->IsMyTurn(this) &&
	//					this->CanInstructsByCurInstructs())
	//				{
	//					FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
	//					ActionFSM->DoEvent(ToIdleEvent);
	//					AutoSelectSkill();
	//				}
	//				else if (CurActionFSMStateId == ECWPawnActionState::BeHit && IsDizzinessFlag())
	//				{
	//					BeDizziness();
	//				}
	//				else
	//				{
	//					ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	//					bool TempIsTriggerEvent = true;
	//					if (TempCurActionState == ECWPawnActionState::BeHit)
	//					{
	//						TempIsTriggerEvent = false;
	//					}
	//					FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, TempIsTriggerEvent, false);
	//					ActionFSM->DoEvent(ToEndEvent);
	//				}

	//				UCWPawnBattlePropertyComponent* MyPawnBattlePropertComponent = this->GetBattleProperty();
	//				check(MyPawnBattlePropertComponent);
	//				float CurHealth = MyPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
	//				if (CurHealth <= 0.0f)
	//				{
	//					FCWPawnActionToDeathEvent* ToDeathEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	//					ActionFSM->DoEvent(ToDeathEvent);
	//				}
	//			}
	//		}
	//	}
	//	else
	//	{
	//		ECWPawnActionState CurActionFSMStateId = this->GetCurActionFSMStateId();
	//		if (CurActionFSMStateId == ECWPawnActionState::Die)
	//		{
	//			FCWPawnActionToDeathEvent* ToDeathEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	//			ActionFSM->DoEvent(ToDeathEvent);
	//		}
	//		else
	//		{
	//			if (MyPlayerController->IsMyTurn(this) &&
	//				this->CanInstructsByCurInstructs())
	//			{
	//				FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
	//				ActionFSM->DoEvent(ToIdleEvent);
	//				AutoSelectSkill();
	//			}
	//			else if (CurActionFSMStateId == ECWPawnActionState::BeHit && IsDizzinessFlag())
	//			{
	//				BeDizziness();
	//			}
	//			else
	//			{
	//				ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	//				bool TempIsTriggerEvent = true;
	//				if (TempCurActionState == ECWPawnActionState::BeHit)
	//				{
	//					TempIsTriggerEvent = false;
	//				}
	//				FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, TempIsTriggerEvent, false);
	//				ActionFSM->DoEvent(ToEndEvent);
	//			}

	//			UCWPawnBattlePropertyComponent* MyPawnBattlePropertComponent = this->GetBattleProperty();
	//			check(MyPawnBattlePropertComponent);
	//			float CurHealth = MyPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
	//			if (CurHealth <= 0.0f)
	//			{
	//				FCWPawnActionToDeathEvent* ToDeathEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	//				ActionFSM->DoEvent(ToDeathEvent);
	//			}
	//		}
	//	}
	//}
	//else
	//{
	//	ACWPlayerController* MyPlayerController = (ACWPlayerController*)ParantController;
	//	check(MyPlayerController);
	//	ECWPawnActionState CurActionFSMStateId = this->GetCurActionFSMStateId();
	//	if (CurActionFSMStateId == ECWPawnActionState::NormalAttack ||
	//		CurActionFSMStateId == ECWPawnActionState::CastSkillToPawn ||
	//		CurActionFSMStateId == ECWPawnActionState::CastSkillToTile)
	//	{
	//		if (MyPlayerController->IsMyTurn(this) &&
	//			CanInstructsByCurInstructs())
	//		{
	//			FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
	//			ActionFSM->DoEvent(ToIdleEvent);
	//			AutoSelectSkill();
	//			
	//			if (IsMyClientPawn())
	//			{
	//				FCWPawnInputWaitingEvent* WaitingInputEvent = new FCWPawnInputWaitingEvent((int)ECWPawnInputEvent::TurnStartAction, (int)ECWPawnInputState::WaitingInput, ECWFSMStackOp::Set);
	//				InputFSM->DoEvent(WaitingInputEvent);
	//			}
	//		}
	//		else
	//		{
	//			ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	//			FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, false, false);
	//			ActionFSM->DoEvent(ToEndEvent);
	//		}
	//	}
	//	else
	//	{
	//		if (CurActionFSMStateId == ECWPawnActionState::Die)
	//		{
	//			FCWPawnActionToDeathEvent* ToDeathEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	//			ActionFSM->DoEvent(ToDeathEvent);
	//		}
	//		else if (CurActionFSMStateId == ECWPawnActionState::ForceMove)
	//		{
	//			// TODO: None
	//		}
	//		else
	//		{
	//			if (MyPlayerController->IsMyTurn(this) &&
	//				this->CanInstructsByCurInstructs())
	//			{
	//				FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
	//				ActionFSM->DoEvent(ToIdleEvent);
	//				AutoSelectSkill();

	//				if (IsMyClientPawn())
	//				{
	//					FCWPawnInputWaitingEvent* WaitingInputEvent = new FCWPawnInputWaitingEvent((int)ECWPawnInputEvent::TurnStartAction, (int)ECWPawnInputState::WaitingInput, ECWFSMStackOp::Set);
	//					InputFSM->DoEvent(WaitingInputEvent);
	//				}
	//			}
	//			else if (CurActionFSMStateId == ECWPawnActionState::BeHit && IsDizzinessFlag())
	//			{
	//				BeDizziness();
	//			}
	//			else
	//			{
	//				ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	//				FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, false, false);
	//				ActionFSM->DoEvent(ToEndEvent);
	//			}
	//		}
	//	}
	//}
}

void ACWPawn::SetPawnNetData(const FCWPawnNetData& ParamPawnNetData)
{
	PawnNetData = ParamPawnNetData;
}

FCWPawnNetData& ACWPawn::GetPawnNetData()
{
	return PawnNetData;
}

const FCWPawnNetData& ACWPawn::GetPawnNetData()const
{
	return PawnNetData;
}

void ACWPawn::SetCampTag(ECWCampTag ParamCampTag)
{
	CampTag = ParamCampTag;
}

ECWCampTag ACWPawn::GetCampTag() const
{
	return CampTag;
}

void ACWPawn::SetCampControllerIndex(ECWCampControllerIndex ParamControllerIndex)
{
	ControllerIndex = ParamControllerIndex;
}

ECWCampControllerIndex ACWPawn::GetCampControllerIndex() const
{
	return ControllerIndex;
}

void ACWPawn::SetControllerPawnIndex(int32 ParamPawnIndex)
{
	PawnIndex = ParamPawnIndex;
}

int32 ACWPawn::GetControllerPawnIndex() const
{
	return PawnIndex;
}

void ACWPawn::SetPawnId(int32 ParamPawnId)
{
	PawnId = ParamPawnId;
}

int32 ACWPawn::GetPawnId() const
{
	return PawnId;
}

void ACWPawn::SetPeripheralNetId(const FString& ParamPeripheralNetId)
{
	PeripheralNetId = ParamPeripheralNetId;

	ACWPlayerController* TempPlayerController = (ACWPlayerController*)this->ParantController;
	check(TempPlayerController);
	FString strPlayerPeripheralNetId = TempPlayerController->GetPeripheralNetId();
	uint64 uint64PlayerPeripheralNetId = FCWUtils::FString2Uint64(strPlayerPeripheralNetId);
	UCWNetPlayerData* TempPlayerNetData = UCWGameInstance::GetInstance()->GetNetPlayerDataMgr()->GetNetPlayerData(uint64PlayerPeripheralNetId);
	if (TempPlayerNetData != nullptr)
	{
		uint64 uint64PawnPeripheralNetId = FCWUtils::FString2Uint64(PeripheralNetId);
		UCWNetHeroData* TempHeroNetData = TempPlayerNetData->GetNetHeroData(uint64PawnPeripheralNetId);
		if (TempHeroNetData != nullptr)
		{
			PawnNetData.Rand = (int32)TempHeroNetData->Rand;
			PawnNetData.UUID = FCWUtils::Uint642FString(TempHeroNetData->UUID);
			PawnNetData.Race = (int32)TempHeroNetData->Race;
			PawnNetData.Profession = (int32)TempHeroNetData->Profession;
			PawnNetData.Name = TempHeroNetData->Name;
			PawnNetData.Sex = (int32)TempHeroNetData->Sex;
			PawnNetData.Identity = (int32)TempHeroNetData->Identity;
			PawnNetData.Birthday = FCWUtils::Uint642FString(TempHeroNetData->Birthday);
			PawnNetData.Age = (int32)TempHeroNetData->Age;
			PawnNetData.Quality = (int32)TempHeroNetData->Quality;
			PawnNetData.Level = (int32)TempHeroNetData->Level;
			PawnNetData.Weapon = (int32)TempHeroNetData->Weapon;
			
			PawnNetData.Str = (int32)TempHeroNetData->Str;
			PawnNetData.Dex = (int32)TempHeroNetData->Dex;
			PawnNetData.Con = (int32)TempHeroNetData->Con;
			PawnNetData.Int = (int32)TempHeroNetData->Int;

			PawnNetData.ActiveSkillId.Empty();
			for (TArray<int32>::TConstIterator iter = TempHeroNetData->ActiveSkillId.CreateConstIterator(); iter; ++iter)
			{
				PawnNetData.ActiveSkillId.Add((int32)*iter);
			}

			PawnNetData.PassivitySkillId.Empty();
			for (TArray<int32>::TConstIterator iter = TempHeroNetData->PassivitySkillId.CreateConstIterator(); iter; ++iter)
			{
				PawnNetData.PassivitySkillId.Add((int32)*iter);
			}

			PawnNetData.InnateSkillId.Empty();
			for (TArray<int32>::TConstIterator iter = TempHeroNetData->InnateSkillId.CreateConstIterator(); iter; ++iter)
			{
				PawnNetData.InnateSkillId.Add((int32)*iter);
			}

		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetPeripheralNetId. GetNetHeroData fail, PeripheralNetId:%s."), *PeripheralNetId);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetPeripheralNetId. GetNetPlayerData fail, strPlayerPeripheralNetId:%s."), *strPlayerPeripheralNetId);
	}
}

const FString& ACWPawn::GetPeripheralNetId() const
{
	return PeripheralNetId;
}


void ACWPawn::SetCombinationName(const FString& ParamCombinationName)
{
	CombinationName = ParamCombinationName;
}

const FString& ACWPawn::GetCombinationName() const
{
	return CombinationName;
}

void ACWPawn::SetParantController(AController* ParamParantController)
{
	ParantController = ParamParantController;
}

AController* ACWPawn::GetParantController()
{
	return ParantController;
}

const AController* ACWPawn::GetParantController() const
{
	return ParantController;
}

void ACWPawn::SetParantControllerType(ECWControllerType ParamParantControllerType)
{
	ParantControllerType = ParamParantControllerType;
}

ECWControllerType ACWPawn::GetParantControllerType()
{
	return ParantControllerType;
}

void ACWPawn::SetMoveBeginTile(int ParamTile)
{
	MoveBeginTile = ParamTile;
}

int ACWPawn::GetMoveBeginTile() const
{
	return MoveBeginTile;
}

void ACWPawn::SetMoveBeginPos(const FVector& ParamPos)
{
	MoveBeginPos = ParamPos;
}

const FVector& ACWPawn::GetMoveBeginPos() const
{
	return MoveBeginPos;
}

void ACWPawn::SetMoveBeginRotator(const FRotator& ParamRotator)
{
	MoveBeginRotator = ParamRotator;
}

const FRotator& ACWPawn::GetMoveBeginRotator() const
{
	return MoveBeginRotator;
}

void ACWPawn::SetTile(int32 ParamTile)
{
	if (ParamTile != Tile)
	{
		OldTile = Tile;
	}
	
	Tile = ParamTile;

	FVector CurPos = FVector::ZeroVector;
	ACWMap::tile2pos(Tile, CurPos);
	PathExplorer.Reset();
	PathExplorer.SetPos(CurPos);

	float RealZ = this->GetActorLocation().Z;
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	if (Generator != nullptr)
	{
		ACWDungeonTile* TempDungeonTile = Generator->GetDungeonTile(ParamTile);
		if (TempDungeonTile != nullptr)
		{
			RealZ = TempDungeonTile->GetActorLocation().Z;
		}
	}
	CurPos.Z = RealZ;
	this->SetActorLocation(CurPos);

	if (IsInServer())
	{
		ACWMap* MyMap = GetMap();
		if (MyMap != nullptr)
		{
			MyMap->MovePawn(this, OldTile, Tile);
		}
	}
}

void ACWPawn::SetTile(int32 ParamOldTile, int32 ParamTile)
{
	OldTile = ParamOldTile;
	Tile = ParamTile;

	FVector CurPos = FVector::ZeroVector;
	ACWMap::tile2pos(Tile, CurPos);
	PathExplorer.Reset();
	PathExplorer.SetPos(CurPos);

	if (IsInServer())
	{
		ACWMap* MyMap = GetMap();
		if (MyMap != nullptr)
		{
			MyMap->MovePawn(this, OldTile, Tile);
		}
	}
}

int ACWPawn::GetTile() const
{
	return Tile;
}

ACWMap* ACWPawn::GetMap()
{
	return UCWFuncLib::GetActor<ACWMap>(this);
}

UCWPawnInputFSM* ACWPawn::GetInputFSM()
{
	return InputFSM;
}

ECWPawnInputState ACWPawn::GetCurInputFSMStateId()
{
	//if (IsInServer())
	//	return ECWPawnInputState::None;

	if (InputFSM == nullptr)
		return ECWPawnInputState::None;

	check(InputFSM);
	return (ECWPawnInputState)(InputFSM->GetCurrentStateId());
}

UCWPawnActionComponent* ACWPawn::GetActionComponent()
{
	return ActionComponent;
}

ECWPawnActionState ACWPawn::GetCurActionStateId() const
{
	//if (IsInServer())
	//	return ECWPawnActionState::None;

	if (ActionComponent == nullptr)
		return ECWPawnActionState::None;

	check(ActionComponent);
	return ActionComponent->GetCurState();
}

const std::list<ACWMapTileRender*>& ACWPawn::GetListMapTileRender() const
{
	return ListMapTileRender;
}

void ACWPawn::LongDownInClient(ACWPlayerController* ParamPlayerController)
{
	ECWPawnInputState TempCurInputState = (ECWPawnInputState)(InputFSM->GetCurrentStateId());
	if (IsMyClientPawn() &&
		this->CanInstructsByCurInstructs() &&
		(TempCurInputState == ECWPawnInputState::WaitingInput))
	{
		FCWPawnInputSelectedEvent* SelectedEvent = new FCWPawnInputSelectedEvent((int)ECWPawnInputEvent::Selected, (int)ECWPawnInputState::Selected, ECWFSMStackOp::Set);
		this->GetInputFSM()->DoEvent(SelectedEvent);

		ShowHintTile(ParamPlayerController);
	}
}

void ACWPawn::SelectedInClient(ACWPlayerController* ParamPlayerController, bool ParamIsLongDown)
{
	// 棋子进入选定状态
	ECWPawnInputState TempCurInputState = (ECWPawnInputState)(InputFSM->GetCurrentStateId());
	if (IsMyClientPawn() &&
		this->IsThinkActionNoEndByCurInstructs() &&
		(TempCurInputState == ECWPawnInputState::WaitingInput))
	{
		FCWPawnInputSelectedEvent* SelectedEvent = new FCWPawnInputSelectedEvent((int)ECWPawnInputEvent::Selected, (int)ECWPawnInputState::Selected, ECWFSMStackOp::Set);
		this->GetInputFSM()->DoEvent(SelectedEvent);
		bIsLongDown = ParamIsLongDown;
	}
	
	// 显示提示格子
	ShowHintTile(ParamPlayerController);

	if (PawnType == ECWPawnType::Character)
	{
		SetCustomDepthStencilValue(101);
	}

	// 播放选中声音
	PlayClickAudio();
}

void ACWPawn::SelectedInReady(ACWPlayerController* ParamPc)
{
	if (IsMyClientPawn() && IsPawnType(ECWPawnType::Character))
	{
		FCWPawnInputSelectedEvent* SelectedEvent = new FCWPawnInputSelectedEvent(
			(int)ECWPawnInputEvent::Selected, (int)ECWPawnInputState::SelectInReady, ECWFSMStackOp::Set);
		GetInputFSM()->DoEvent(SelectedEvent);

		ShowHintTile(ParamPc);
	}

	PlayClickAudio();
}

void ACWPawn::CancelSelectedInReady(bool bNeedJumpState)
{
	if (IsMyClientPawn() && IsPawnType(ECWPawnType::Character))
	{
		if (bNeedJumpState)
		{
			FCWPawnInputWaitingEvent* WaitingEvent = new FCWPawnInputWaitingEvent(
				(int)ECWPawnInputEvent::TurnWaitingAction, (int)ECWPawnInputState::WaitInReady, ECWFSMStackOp::Set);
			GetInputFSM()->DoEvent(WaitingEvent);

			// 准备阶段己方棋子边缘
			SetCustomDepthStencilValue(100);
		}
	}

	HideHintTile();
	//OnBecomeSelectedTarget(false);
	//HideWantMovePathArrow();
	ShowShadowVisible(false);
}

bool ACWPawn::IsShadowVisible() const
{
	return ShadowSkeletalMeshComponent ? ShadowSkeletalMeshComponent->IsVisible() : false;
}

void ACWPawn::ShowShadowVisible(bool bNewVisible, bool bResetRotToSelf)
{
	if (nullptr != ShadowSkeletalMeshComponent)
	{
		ShadowSkeletalMeshComponent->SetVisibility(bNewVisible);
		if (bNewVisible && bResetRotToSelf)
		{
			UpdateShadowRotation(GetActorRotation());
		}
	}
}

void ACWPawn::UpdateShadowPosition(const FVector& NewPosition)
{
	if (nullptr != ShadowSkeletalMeshComponent)
	{
		ShadowSkeletalMeshComponent->SetWorldLocation(NewPosition);
	}
}

void ACWPawn::UpdateShadowRotation(const FRotator& NewRotation)
{
	if (nullptr != ShadowSkeletalMeshComponent)
	{
		ShadowSkeletalMeshComponent->SetWorldRotation(NewRotation);
	}
}

void ACWPawn::OnBeginOverlap(AActor* OtherActor)
{
}

void ACWPawn::OnEndOverlap(AActor* OtherActor)
{
}

bool ACWPawn::IsValidToCursorOver() const
{
	return !bHidden;
}

int32 ACWPawn::DefaultSkillIdx()
{
	return INDEX_NONE;
}

bool ACWPawn::IsOpPCHasTarget() const
{
	if (ACWPlayerController* OpPC = ParantController ? Cast<ACWPlayerController>(ParantController) : GetLocalPC())
	{
		return (nullptr != OpPC->GetCurTargetSelectedPawn());
	}
	return false;
}

bool ACWPawn::ClientSetSelectSkillIdx(int32 Idx)
{
	if (IsMyClientPawn())
	{
		CurSelectSkillIdx = Idx;
		AutoSelectSkill();
		ServerSetSelectSkillIdx(Idx);

		ACWPlayerController* LocalPC = GetLocalPC();
		if (nullptr != LocalPC)
		{
			if (IsOpPCHasTarget())
			{	// 有目标则清理输入数据
				LocalPC->CancelPlayerInputData();
			}
			else
			{
				ShowHintTile(LocalPC);
			}
		}
		return true;
	}
	return false;
}

bool ACWPawn::ServerSetSelectSkillIdx_Validate(int32 Idx)
{
	return true;
}

void ACWPawn::ServerSetSelectSkillIdx_Implementation(int32 Idx)
{
	CurSelectSkillIdx = Idx;

	AutoSelectSkill();
}

int32 ACWPawn::GetSelectSkillIdx() const
{
	return CurSelectSkillIdx;
}

UCWSkill* ACWPawn::GetSkillByIdx(int32 Idx)
{
	return SkillManager ? SkillManager->GetSkillByIndex(Idx) : nullptr;
}

const UCWSkill* ACWPawn::GetSkillByIdx(int32 Idx) const
{
	return SkillManager ? SkillManager->GetSkillByIndex(Idx) : nullptr;
}

void ACWPawn::RecalcSelectSkillIdx()
{
	int32 TmpIdx = CurSelectSkillIdx;
	if (TmpIdx == INDEX_NONE)
	{
		if (!SkillManager->CanNormalAttack())
		{
			TmpIdx = INDEX_NONE - 1;
		}
	}else if (!IsSkillCanUse(CurSelectSkillIdx))
	{
		TmpIdx = DefaultSkillIdx();
	}

	if (TmpIdx != CurSelectSkillIdx)
	{
		ClientSetSelectSkillIdx(TmpIdx);
	}
}

FCWSkillDataStruct ACWPawn::GetSkillCfgData(int32 Idx)
{
	if (const UCWSkill* MySkill = GetSkillByIdx(Idx))
	{
		if (const FCWSkillDataStruct* SkillData = MySkill->GetSkillDataStruct())
		{
			check(SkillData);
			return *SkillData;
		}
	}
	return FCWSkillDataStruct();
}

bool ACWPawn::IsSkillCanUse(int32 Idx)
{
	// 能量足够 + 非被动技能
	//bool bCanUse = (Idx > 0 && Idx < 3);
	const UCWSkill* MySkill = GetSkillByIdx(Idx);
	return (nullptr != MySkill && MySkill->IsEnoughEnergy() && !MySkill->IsPassivitySkill());
}

ACWPlayerController* ACWPawn::GetLocalPC() const
{
	ACWPlayerController* LocalPC = Cast<ACWPlayerController>(ParantController);
	if (nullptr == LocalPC)
	{
		APlayerController* FirstLocalPC = GetGameInstance()->GetFirstLocalPlayerController();
		LocalPC = Cast<ACWPlayerController>(FirstLocalPC);
	}
	return LocalPC;
}

ECWBattleState ACWPawn::GetBattleState() const
{
	if (ACWGameState* GS = GetGameState<ACWGameState>())
	{
		return GS->GetCurBattleState();
	}
	return ECWBattleState::None;
}

TArray<int32> ACWPawn::GenerateDamageTileBySkill(ACWPawn* ParamCurPawn, ACWPawn* ParamTargetPawn, UCWSkill* ParamSkill)
{
	check(ParamCurPawn);
	check(ParamTargetPawn);
	check(ParamSkill);

	TArray<int32> TempArrayDamageTile;
	uint8 TempMoveAttackDamage = 0x00;
	TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
	TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
	if (!IsAttackTileFromTile(ParamCurPawn->GetTile(), ParamTargetPawn->GetTile(), TempMoveAttackDamage))
	{
		return TempArrayDamageTile;
	}

	ACWMap* TempMap = GetMap();
	if (TempMap == nullptr)
	{
		return TempArrayDamageTile;
	}
	
	if (ParamSkill->GetSkillDataStruct()->IsAOE == 1)
	{
		CWDamageGrid TempTargetDamageGrid;
		int TempTargetTile = ParamTargetPawn->GetTile();
		const std::vector<std::list<CWDamageGrid>>& TempVectorListDamage = TempMap->GetVectorDamageGrid();
		if (TempTargetTile >= 0 && TempTargetTile < TempVectorListDamage.size())
		{
			const std::list<CWDamageGrid>& TempListDamageGrid = TempVectorListDamage[TempTargetTile];
			if (TempListDamageGrid.size() > 0)
			{
				TempTargetDamageGrid = TempListDamageGrid.front();

				if ((TempTargetDamageGrid.MAD & (uint8)ECWMapTileMoveAttackDamageType::Attack) > 0 ||
					(TempTargetDamageGrid.MAD & (uint8)ECWMapTileMoveAttackDamageType::Damage) > 0)
				{
					TempArrayDamageTile.Add(TempTargetDamageGrid.Tile);
				}
			}
		}

		for (int i = 0; i < TempVectorListDamage.size(); ++i)
		{
			const std::list<CWDamageGrid>& TempListDamageGrid = TempVectorListDamage[i];
			for (std::list<CWDamageGrid>::const_iterator iter = TempListDamageGrid.begin(); iter != TempListDamageGrid.end(); ++iter)
			{
				const CWDamageGrid& TempDamageGrid = *iter;
				if (TempTargetDamageGrid.PawnTile == TempDamageGrid.PawnTile &&
					TempTargetDamageGrid.AttackTile == TempDamageGrid.AttackTile &&
					TempTargetDamageGrid.Dir == TempDamageGrid.Dir &&
					TempTargetDamageGrid.Tile != TempDamageGrid.Tile)
				{
					if ((TempDamageGrid.MAD & (uint8)ECWMapTileMoveAttackDamageType::Attack) > 0 ||
						(TempDamageGrid.MAD & (uint8)ECWMapTileMoveAttackDamageType::Damage) > 0)
					{
						TempArrayDamageTile.Add(TempDamageGrid.Tile);
					}
				}
			}
		}

		return TempArrayDamageTile;
	}
	else
	{
		return TempArrayDamageTile;
	}
}

FCWPawnFindPathInfo ACWPawn::GetFindPathInfo()
{
	const FCWProfessionDataStruct* TempProfessionData = GetProfessionData();
	if (TempProfessionData == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetFindPathInfo. TempProfessionData == null, Profession:%d."), PawnNetData.Profession);
		return FCWPawnFindPathInfo();
	}

	FCWPawnFindPathInfo TempFindPathInfo;
	TempFindPathInfo.Profession = TempProfessionData->ProfessionId;
	TempFindPathInfo.MoveType = TempProfessionData->MoveType;

	return TempFindPathInfo;
}

void ACWPawn::OnBecomeSelectedTarget(bool bSelected, ACWPawn* InOpPawn)
{
	ACWMapTile* MapTile = GetMapTileByTile(Tile);
	if (nullptr != MapTile)
	{
		MapTile->ShowOtherHintTile(bSelected ? ECWTileRenderType::Selected : ECWTileRenderType::None, InOpPawn);
	}
}

void ACWPawn::ClearPawnTileRender()
{
	ACWMapTile* MapTile = GetMap() ? GetMap()->GetTile(Tile) : nullptr;
	if (nullptr != MapTile)
	{
		MapTile->CancelSelectedInClient();
	}
}

void ACWPawn::PlayClickAudio()
{
	if (!IsMyClientPawn())
	{	// 不是自己不播放
		return;
	}

	if (UCWAudioVideoMgr* AV_Mgr = AV_MGR(this))
	{	// 点击音效
		const FCWProfessionDataStruct* ProfessionData = GetProfessionData();
		if (nullptr != ProfessionData && !ProfessionData->ClickAudioId.IsEmpty())
		{
			AV_Mgr->PlayAudioByCfg(this, ProfessionData->ClickAudioId);
		}
	}
}

void ACWPawn::CancelLongDownInClient()
{
	HideHintTile();
	HideWantMovePathArrow();
	RestoreEnemyHeadIconInAttackRange();
	RestorePartnerHeadIconInSupportRange();

	ShowShadowVisible(false);
}

void ACWPawn::CancelSelectedInClient()
{
	check(InputFSM);
	ECWPawnInputState TempCurInputState = (ECWPawnInputState)(InputFSM->GetCurrentStateId());
	if (IsMyClientPawn() &&
		this->IsThinkActionNoEndByCurInstructs() &&
		(TempCurInputState == ECWPawnInputState::Selected || 
			TempCurInputState == ECWPawnInputState::ReadyToMove ||
			TempCurInputState == ECWPawnInputState::SelectedAndWantAttack ||
			TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack ||
			TempCurInputState == ECWPawnInputState::WaitingAttack))
	{
		FCWPawnInputWaitingEvent* WaitingEvent = new FCWPawnInputWaitingEvent((int)ECWPawnInputEvent::CancelToWaitingInput, (int)ECWPawnInputState::WaitingInput, ECWFSMStackOp::Set);
		this->GetInputFSM()->DoEvent(WaitingEvent);
	}
	
	HideHintTile();
	HideWantMovePathArrow();
	RestoreEnemyHeadIconInAttackRange();
	RestorePartnerHeadIconInSupportRange();

	ShowShadowVisible(false);

	if (PawnType == ECWPawnType::Character)
	{
		ACWPlayerController* MyPlayerController = (ACWPlayerController*)ParantController;
		if (MyPlayerController != nullptr)
		{
			if (MyPlayerController->IsEnemy(this))
			{
				SetCustomDepthStencilValue(102);
			}
			else
			{
				if (IsMyClientPawn() && IsPawnTurn() &&
					this->IsThinkActionNoEndByCurInstructs() &&
					(TempCurInputState == ECWPawnInputState::Selected ||
						TempCurInputState == ECWPawnInputState::ReadyToMove ||
						TempCurInputState == ECWPawnInputState::SelectedAndWantAttack ||
						TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack ||
						TempCurInputState == ECWPawnInputState::WaitingAttack))
				{
					SetCustomDepthStencilValue(100);
				}
				else
				{
					SetCustomDepthStencilValue(0);
				}
			}
		}
	}
}

void ACWPawn::CancelSelectedNoEventInClient()
{
	HideHintTile();
	HideWantMovePathArrow();
	RestoreEnemyHeadIconInAttackRange();
	RestorePartnerHeadIconInSupportRange();

	ShowShadowVisible(false);
}

bool ACWPawn::FindPathAndShowWantMovePathArrow(int ParamDestTile)
{
	this->HideWantMovePathArrow();

	FVector ActorLocation = GetActorLocation();
	PathExplorer.Reset();
	PathExplorer.SetPos(ActorLocation);

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	check(MyPlayerController);
	ACWMap* MyMap = MyPlayerController->GetMap();
	check(MyMap);
	FVector destPos = FVector::ZeroVector;
	ACWMap::tile2pos(ParamDestTile, destPos);
	if (!MyMap->pathExplorerFindPathAStar(PathExplorer, destPos, 1000000, this->GetCampTag(), this->GetFindPathInfo()))
	{
		return false;
	}

	this->ShowWantMovePathArrow();
	return true;
}

void ACWPawn::SetReadyToDestTile(int ParamDestTile)
{
	ReadyToDestTile = ParamDestTile;
}

int ACWPawn::GetReadyToDestTile() const
{
	return ReadyToDestTile;
}

float ACWPawn::GetMoveSpeed() const
{
	return MoveSpeed;
}

float ACWPawn::GetMoveAnimSpeedRate() const
{
	return MoveAnimSpeedRate;
}

void ACWPawn::SelectedAndWantAttackToPawnInClient(ACWPlayerController* ParamPlayerController, ACWPawn* ParamTargetPawn)
{
	if (IsMyClientPawn())
	{
		FCWPawnInputSelectedAndWantAttackEvent* SelectedAndWantAttackEvent = new FCWPawnInputSelectedAndWantAttackEvent((int)ECWPawnInputEvent::SelectedAndWantAttack, (int)ECWPawnInputState::SelectedAndWantAttack, ECWFSMStackOp::Set, ParamTargetPawn);
		this->GetInputFSM()->DoEvent(SelectedAndWantAttackEvent);
	}
}

void ACWPawn::ReadyMoveToDestTileAndWantAttackInClient(ACWPlayerController* ParamPlayerController, int ParamDestTile, ACWPawn* ParamTargetPawn)
{
	if (IsMyClientPawn())
	{
		FCWPawnInputReadyToMoveAndWantAttackEvent* ReadyToMoveAndWantAttackEvent = new FCWPawnInputReadyToMoveAndWantAttackEvent((int)ECWPawnInputEvent::ReadyToMoveAndWantAttack, (int)ECWPawnInputState::ReadyToMoveAndWantAttack, ECWFSMStackOp::Set, ParamDestTile, ParamTargetPawn);
		this->GetInputFSM()->DoEvent(ReadyToMoveAndWantAttackEvent);
	}

	FVector ActorLocation = GetActorLocation();
	PathExplorer.Reset();
	PathExplorer.SetPos(ActorLocation);

	ACWMap* MyMap = ParamPlayerController->GetMap();
	check(MyMap);
	FVector destPos = FVector::ZeroVector;
	ACWMap::tile2pos(ParamDestTile, destPos);
	MyMap->pathExplorerFindPathAStar(PathExplorer, destPos, 1000000, this->GetCampTag(), this->GetFindPathInfo());
	this->ShowWantMovePathArrow();
	float z = this->GetDungeonTileZ(ParamDestTile);
	//this->RestoreEnemyHeadIconInAttackRange();	//不能隐藏头顶Icon
	//this->RestorePartnerHeadIconInSupportRange();	//不能隐藏头顶Icon

	UpdateShadowSKCompTransform(FVector(destPos.X, destPos.Y, z));
}

void ACWPawn::ReadyMoveToDestTileInClient(ACWPlayerController* ParamPlayerController, int ParamDestTile)
{
	if (IsMyClientPawn())
	{
		FCWPawnInputReadyToMoveEvent* ReadyToMoveEvent = new FCWPawnInputReadyToMoveEvent((int)ECWPawnInputEvent::ReadyToMove, (int)ECWPawnInputState::ReadyToMove, ECWFSMStackOp::Set, ParamDestTile);
		this->GetInputFSM()->DoEvent(ReadyToMoveEvent);
	}

	FVector ActorLocation = GetActorLocation();
	PathExplorer.Reset();
	PathExplorer.SetPos(ActorLocation);

	ACWMap* MyMap = ParamPlayerController->GetMap();
	check(MyMap);
	FVector destPos = FVector::ZeroVector;
	ACWMap::tile2pos(ParamDestTile, destPos);
	MyMap->pathExplorerFindPathAStar(PathExplorer, destPos, 1000000, this->GetCampTag(), this->GetFindPathInfo());
	this->ShowWantMovePathArrow();
	float z = this->GetDungeonTileZ(ParamDestTile);
	//this->RestoreEnemyHeadIconInAttackRange();   //不能隐藏头顶Icon
	//this->RestorePartnerHeadIconInSupportRange();//不能隐藏头顶Icon

	UpdateShadowSKCompTransform(FVector(destPos.X, destPos.Y, z));
}

void ACWPawn::MoveToDestTileInClient(ACWPlayerController* ParamPlayerController, int ParamDestTile)
{
	MoveToDestTile = ParamDestTile;

	if (IsMyClientPawn())
	{
		FCWPawnInputMoveToDestEvent* MoveToDestEvent = new FCWPawnInputMoveToDestEvent((int)ECWPawnInputEvent::MoveToDest, (int)ECWPawnInputState::MoveToDest, ECWFSMStackOp::Set, ParamDestTile);
		this->GetInputFSM()->DoEvent(MoveToDestEvent);
	}

	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::MoveToDestTileInClient. ParamDestTile:%d."), ParamDestTile);

	this->ServerRPCMoveToDestTile(MoveToDestTile);
}

UCWSkill* ACWPawn::GetAutoSelectSkillRecord()
{
	if (AutoSelectSkillRecord == nullptr)
	{
		AutoSelectSkillRecord = AutoSelectSkill();
	}

	if (AutoSelectSkillRecord != nullptr)
	{
		if (!AutoSelectSkillRecord->IsEnoughEnergy())
		{
			AutoSelectSkillRecord = GetNormalAttack();
		}
	}

	return AutoSelectSkillRecord;
}

UCWSkill* ACWPawn::AutoSelectSkill()
{
	check(SkillManager);

	AutoSelectSkillRecord = nullptr;
	if (CurSelectSkillIdx == -2)
	{
		UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::AutoSelectSkill. CurSelectSkillIdx == -2."));
	}
	else if (CurSelectSkillIdx == -1)
	{
		AutoSelectSkillRecord = GetNormalAttack();
	}
	else
	{
		if (!this->CanCastSkillByCurInstructs())
		{
			AutoSelectSkillRecord = GetNormalAttack();
		}
		else
		{
			AutoSelectSkillRecord = GetSkillByIdx(CurSelectSkillIdx);
			if (AutoSelectSkillRecord != nullptr)
			{
				if (!AutoSelectSkillRecord->IsEnoughEnergy())
				{
					AutoSelectSkillRecord = GetNormalAttack();
				}
			}
		}
	}

	if (AutoSelectSkillRecord == nullptr)
		return nullptr;

	return AutoSelectSkillRecord;
}

void ACWPawn::AutoSelectSkillMoveToAttackInClient(int32 ParamTargetTile, int32 ParamMoveDestTile)
{
	check(InputFSM);
	check(SkillManager);
	if (!IsValidTile(ParamTargetTile))
		return;

	if (!IsValidTile(ParamMoveDestTile))
		return;

	UCWSkill* TempSkill = GetAutoSelectSkillRecord();
	if (TempSkill != nullptr)
	{
		int TempRealSkillId = TempSkill->GetSkillId();
		ECWPawnInputState TempCurInputState = (ECWPawnInputState)(InputFSM->GetCurrentStateId());
		if (IsMyClientPawn() &&
			this->IsThinkActionNoEndByCurInstructs() &&
			(TempCurInputState == ECWPawnInputState::WaitingAttack || TempCurInputState == ECWPawnInputState::MoveToAttack || TempCurInputState == ECWPawnInputState::SelectedAndWantAttack || TempCurInputState == ECWPawnInputState::Selected || TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack))
		{
			FCWPawnInputMoveToAttackEvent* MoveToAttackEvent = new FCWPawnInputMoveToAttackEvent(
				(int)ECWPawnInputEvent::MoveToAttack,
				(int)ECWPawnInputState::MoveToAttack,
				ECWFSMStackOp::Set,
				TempRealSkillId,
				ParamTargetTile,
				ParamMoveDestTile);
			this->GetInputFSM()->DoEvent(MoveToAttackEvent);


			this->ServerRPCMoveToAttack(
				TempRealSkillId,
				ParamTargetTile,
				ParamMoveDestTile);

			UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::AutoSelectSkillMoveToAttackInClient. TempRealSkillId:%d, ParamTargetTile:%d, ParamMoveDestTile:%d."), TempRealSkillId, ParamTargetTile, ParamMoveDestTile);
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::AutoSelectSkillMoveToAttackInClient. GetAutoSelectSkillRecord fail."));
	}
}

void ACWPawn::AutoSelectSkillAttackInClient(int32 ParamTargetTile)
{
	check(InputFSM);
	check(SkillManager);

	if (!IsValidTile(ParamTargetTile))
		return;

	UCWSkill* TempSkill = GetAutoSelectSkillRecord();
	if (TempSkill != nullptr)
	{
		int TempRealSkillId = TempSkill->GetSkillId();
		ECWPawnInputState TempCurInputState = (ECWPawnInputState)(InputFSM->GetCurrentStateId());
		if (IsMyClientPawn() &&
			this->IsThinkActionNoEndByCurInstructs() &&
			(TempCurInputState == ECWPawnInputState::WaitingAttack || TempCurInputState == ECWPawnInputState::MoveToAttack || TempCurInputState == ECWPawnInputState::SelectedAndWantAttack || TempCurInputState == ECWPawnInputState::Selected || TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack))
		{
			if (TempSkill->IsNormalAttack())
			{
				FCWPawnInputNormalAttackEvent* NormalAttackEvent = new FCWPawnInputNormalAttackEvent((int)ECWPawnInputEvent::NormalAttack, (int)ECWPawnInputState::NormalAttack, ECWFSMStackOp::Set, ParamTargetTile);
				this->GetInputFSM()->DoEvent(NormalAttackEvent);

				ServerRPCNormalAttackToTile(ParamTargetTile);
			}
			else
			{
				FCWPawnInputCastSkillToPawnEvent* CastSkillToPawnEvent = new FCWPawnInputCastSkillToPawnEvent((int)ECWPawnInputEvent::CastSkillToPawn, (int)ECWPawnInputState::CastSkillToPawn, ECWFSMStackOp::Set, ParamTargetTile);
				this->GetInputFSM()->DoEvent(CastSkillToPawnEvent);

				ServerRPCCastSkillToTile(
					TempRealSkillId,
					ParamTargetTile);
			}
		}
	}
	else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::AutoSelectSkillAttackInClient. GetAutoSelectSkillRecord fail."));
	}
}

void ACWPawn::ActionEndInClient(ACWPlayerController* ParamPlayerController)
{
	UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ActionEndInClient."));

	if (IsMyClientPawn())
	{
		FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		this->GetInputFSM()->DoEvent(ActionFinishEvent);
	}

	ServerRPCActionEnd();
}

const UCWSkill* ACWPawn::GetNormalAttack() const
{
	check(SkillManager);
	return SkillManager->GetNormalAttack();
}

UCWSkill* ACWPawn::GetNormalAttack()
{
	check(SkillManager);
	return SkillManager->GetNormalAttack();
}


const UCWSkill* ACWPawn::GetSkill(int ParamSkillId) const
{
	check(SkillManager);
	return SkillManager->GetSkill(ParamSkillId);
}

UCWSkill* ACWPawn::GetSkill(int ParamSkillId)
{
	check(SkillManager);
	return SkillManager->GetSkill(ParamSkillId);
}

void ACWPawn::BeHitInServer(
	ECWCampTag ParamPawnCampTag,
	ECWCampControllerIndex ParamPawnCampControllerIndex,
	int32 ParamPawnControllerPawnIndex,
	int32 ParamSkillId,
	bool ParamIsCounterAttack)
{
	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
	if (TempCurActionState != ECWPawnActionState::Die && TempCurActionState != ECWPawnActionState::Death)
	{
		/*FCWPawnActionToBeHitEvent* BeHitEvent = new FCWPawnActionToBeHitEvent(
			(int)ECWPawnActionEvent::ToBeHit, 
			(int)ECWPawnActionState::BeHit, 
			ECWFSMStackOp::Set, 
			ParamPawnCampTag,
			ParamPawnCampControllerIndex,
			ParamPawnControllerPawnIndex,
			ParamSkillId);
		this->GetActionFSM()->DoEvent(BeHitEvent);*/

		UCWPawnActionDataForBeHit* TempBeHitData = (UCWPawnActionDataForBeHit*)NewObject<UCWPawnActionDataForBeHit>();
		TempBeHitData->ActionId = ECWPawnActionState::BeHit;
		TempBeHitData->PawnCampTag = ParamPawnCampTag;
		TempBeHitData->PawnCampControllerIndex = ParamPawnCampControllerIndex;
		TempBeHitData->PawnControllerPawnIndex = ParamPawnControllerPawnIndex;
		TempBeHitData->PawnSkillId = ParamSkillId;
		TempBeHitData->bIsCounterAttack = ParamIsCounterAttack;
		this->PutAction(TempBeHitData);
	}

	NetMulticastRPCPawnBeHit(ParamPawnCampTag, ParamPawnCampControllerIndex, ParamPawnControllerPawnIndex, ParamSkillId, ParamIsCounterAttack);
}

void ACWPawn::BeHitInClient(
	ECWCampTag ParamPawnCampTag,
	ECWCampControllerIndex ParamPawnCampControllerIndex,
	int32 ParamPawnControllerPawnIndex,
	int32 ParamSkillId,
	bool ParamIsCounterAttack)
{
	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
	if (TempCurActionState != ECWPawnActionState::Die && TempCurActionState != ECWPawnActionState::Death)
	{
		/*FCWPawnActionToBeHitEvent* BeHitEvent = new FCWPawnActionToBeHitEvent(
			(int)ECWPawnActionEvent::ToBeHit,
			(int)ECWPawnActionState::BeHit,
			ECWFSMStackOp::Set,
			ParamPawnCampTag,
			ParamPawnCampControllerIndex,
			ParamPawnControllerPawnIndex,
			ParamSkillId);
		this->GetActionFSM()->DoEvent(BeHitEvent);*/
		UCWPawnActionDataForBeHit* TempBeHitData = (UCWPawnActionDataForBeHit*)NewObject<UCWPawnActionDataForBeHit>();
		TempBeHitData->ActionId = ECWPawnActionState::BeHit;
		TempBeHitData->PawnCampTag = ParamPawnCampTag;
		TempBeHitData->PawnCampControllerIndex = ParamPawnCampControllerIndex;
		TempBeHitData->PawnControllerPawnIndex = ParamPawnControllerPawnIndex;
		TempBeHitData->PawnSkillId = ParamSkillId;
		TempBeHitData->bIsCounterAttack = ParamIsCounterAttack;
		this->PutAction(TempBeHitData);
	}
}

void ACWPawn::NetMulticastAddDeadBody_Implementation()
{
	if (IsNetMode(NM_DedicatedServer) || !IsPawnType(ECWPawnType::Character) || IsValidActor(NewDeadBody))
	{
		return;
	}

	UWorld* MyWorld = GetWorld();
	const int32 TileNumber = GetTile();
	ACWRandomDungeonGenerator* Generator = GetDungeonGenerator();
	ACWDungeonTile* DungeonTile = Generator ? Generator->GetDungeonTile(TileNumber) : nullptr;
	if (nullptr == DungeonTile || nullptr == MyWorld)
	{
		CWG_WARNING(">> AddDeadBody, DungeonTile is nullptr. TileNumber[%d].", TileNumber);
		return;
	}

	NewDeadBody = MyWorld->SpawnActor<ACWSkeletalMeshActor>();
	if (nullptr != NewDeadBody)
	{
		NewDeadBody->Tags.Add(FName("__DeadBody__"));	// Tags

		FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
		NewDeadBody->AttachToActor(DungeonTile, AttachmentRules);
		NewDeadBody->SetOwner(DungeonTile);

		FRotator NewRotator = GetActorRotation();
		FVector NewLocation = GetActorLocation();
		FVector NewScale3D = SkeletalMeshComponent->GetComponentScale();
		NewDeadBody->SetActorRotation(NewRotator);
		NewDeadBody->SetActorLocation(NewLocation);
		NewDeadBody->SetActorScale3D(NewScale3D);

		const FString& NewSMAssetId = GetDisplayModelAssetId();
		const FString& NewAnimAssetId = GetDeadBodyAnimId();
		const FString& NewAnimAnimClassId = GetDisplayModelAnimInstClassId();
		if (!NewSMAssetId.IsEmpty() && !NewAnimAssetId.IsEmpty())
		{
			NewDeadBody->PlayAnimSequence(NewSMAssetId, NewAnimAnimClassId, NewAnimAssetId);
		}
	}
}

void ACWPawn::BeForceMove(const int32 InCasterTile, const TArray<FIntVector>& InForceMoveArray)
{
	if (!IsDieOrDeath() && ActionComponent != nullptr)
	{
		/*FCWPawnActionToForceMoveEvent* ToNewEvent = new FCWPawnActionToForceMoveEvent(
			(int32)ECWPawnActionEvent::ToForceMove, (int32)ECWPawnActionState::ForceMove, ECWFSMStackOp::Push, InCasterTile, InForceMoveArray);
		ActionFSM->DoEvent(ToNewEvent);*/
		UCWPawnActionDataForForceMove* TempForceMoveData = (UCWPawnActionDataForForceMove*)NewObject<UCWPawnActionDataForForceMove>();
		TempForceMoveData->ActionId = ECWPawnActionState::ForceMove;
		TempForceMoveData->CasterTile = InCasterTile;
		TempForceMoveData->ForceMoveTileArray = InForceMoveArray;
		this->PutAction(TempForceMoveData);
		 
	}
}

void ACWPawn::BeForceMovePresentation(const int32 InEffectId /*= 4*/)
{
	if (!IsInServer())
	{
		if (IsPawnType(ECWPawnType::Character))
		{
			PlayAnimSequence(ECWPawnAnim::ForceMove, 0.0f, 0.0f, 1.0f, 1);
		}
		AddBeAttackedEffect(InEffectId);
	}
}

void ACWPawn::NetMulticastBeForceMovePresentation_Implementation(const int32 InEffectId /*= 4*/)
{
	BeForceMovePresentation();
}

void ACWPawn::NetMulticastBeForceMove_Implementation(const int32 InCasterTile, const TArray<FIntVector>& InForceMoveArray)
{
	BeForceMove(InCasterTile, InForceMoveArray);
}

void ACWPawn::BeForceMoveExit()
{
	const ECWPawnActionState CurActionFSMStateId = GetCurActionStateId();
	if (CurActionFSMStateId != ECWPawnActionState::ForceMove)
	{
		CWG_WARNING(">> %s::BeForceMoveExit, NetMode[%s] CurActionFSMStateId[%s] is not ForceMove state!", 
			*GetName(), *NETMODE_TO_STRING(GetNetMode()), *FCWCommonUtil::EnumToString(TEXT("ECWPawnActionState"), CurActionFSMStateId));
		return;
	}

	if (!IsDieOrDeath())
	{
		/*FCWPawnActionToIdleEvent* ToNewEvent = new FCWPawnActionToIdleEvent(
			(int32)ECWPawnActionEvent::ToIdle, (int32)ECWPawnActionState::Idle, ECWFSMStackOp::Pop);
		ActionFSM->DoEvent(ToNewEvent);*/
		//AddNextStateToIdleOrEnd();
	}
}

void ACWPawn::NetMulticastBeForceMoveExit_Implementation()
{
	BeForceMoveExit();
}

void ACWPawn::BeDizziness()
{
	if (!IsDieOrDeath())
	{
		CWG_WARNING(">> %s::BeDizziness, Begin Enter dizziness state!! \n -> PawnInfo[%s].", *GetName(), *ToDebugString());
		/*FCWPawnActionToDizzinessEvent* ToNewEvent = new FCWPawnActionToDizzinessEvent(
			(int32)ECWPawnActionEvent::ToDizziness, (int32)ECWPawnActionState::Dizziness, ECWFSMStackOp::Set);
		ActionFSM->DoEvent(ToNewEvent);*/
		UCWPawnActionDataForDizziness* TempDizzinessData = (UCWPawnActionDataForDizziness*)NewObject<UCWPawnActionDataForDizziness>();
		TempDizzinessData->ActionId = ECWPawnActionState::Dizziness;
		this->PutAction(TempDizzinessData);
	}
}

void ACWPawn::NetMulticastBeDizziness_Implementation()
{
	BeDizziness();
}

void ACWPawn::BeDizzinessExit()
{
	if (!IsDieOrDeath())
	{
		if (const bool bIsDizziness = CheckDizzinessResult())
		{
			//AddNextStateToIdleOrEnd();
		}
	}
}

void ACWPawn::NetMulticastBeDizzinessExit_Implementation()
{
	BeDizzinessExit();
}

void ACWPawn::ResetLocationAndRotation()
{
	FVector Location = GetActorLocation();
	FRotator Rotator = GetActorRotation();
	NetMulticastSetLocationAndRotation(Location, Rotator);
}

void ACWPawn::NetMulticastSetLocationAndRotation_Implementation(FVector InNewLocation, FRotator InNewRotator)
{
	if (IsNetMode(NM_DedicatedServer))
	{
		return;
	}

	SetActorLocationAndRotation(InNewLocation, InNewRotator);
}

void ACWPawn::SetCustomDepthStencilValue(const int32 InValue)
{
	check(SkeletalMeshComponent);
	SkeletalMeshComponent->SetCustomDepthStencilValue(InValue);
}

void ACWPawn::DieInServer()
{
	/*check(ActionFSM);
	FCWPawnActionToDieEvent* DieEvent = new FCWPawnActionToDieEvent((int)ECWPawnActionEvent::ToDie, (int)ECWPawnActionState::Die, ECWFSMStackOp::Set);
	ActionFSM->DoEvent(DieEvent); */
	UCWPawnActionDataForDie* TempDieData = (UCWPawnActionDataForDie*)NewObject<UCWPawnActionDataForDie>();
	TempDieData->ActionId = ECWPawnActionState::Die;
	this->PutAction(TempDieData);

	NetMulticastRPCPawnDie();
}

void ACWPawn::DieInClient()
{
	/*check(ActionFSM);
	FCWPawnActionToDieEvent* DieEvent = new FCWPawnActionToDieEvent((int)ECWPawnActionEvent::ToDie, (int)ECWPawnActionState::Die, ECWFSMStackOp::Set);
	ActionFSM->DoEvent(DieEvent);*/
	UCWPawnActionDataForDie* TempDieData = (UCWPawnActionDataForDie*)NewObject<UCWPawnActionDataForDie>();
	TempDieData->ActionId = ECWPawnActionState::Die;
	this->PutAction(TempDieData);

	if (IsMyClientPawn())
	{
		check(InputFSM);
		FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		InputFSM->DoEvent(ActionFinishEvent);
	}

	HideHintTile();
	HideWantMovePathArrow();
	RestoreEnemyHeadIconInAttackRange();
	RestorePartnerHeadIconInSupportRange();

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	if (MyPlayerController != nullptr)
	{
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			if (this->GetCampTag() == CurSelectedPawn->GetCampTag() &&
				this->GetCampControllerIndex() == CurSelectedPawn->GetCampControllerIndex() &&
				this->GetControllerPawnIndex() == CurSelectedPawn->GetControllerPawnIndex())
			{
				MyPlayerController->CancelCurSelectedPawnNoEventInClient();
			}
		}

		ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();
		if (CurTargetSelectedPawn != nullptr)
		{
			if (this->GetCampTag() == CurTargetSelectedPawn->GetCampTag() &&
				this->GetCampControllerIndex() == CurTargetSelectedPawn->GetCampControllerIndex() &&
				this->GetControllerPawnIndex() == CurTargetSelectedPawn->GetControllerPawnIndex())
			{
				MyPlayerController->CancelCurTargetSelectedPawnInClient();
			}
		}

		ACWMapTile* MapTile = MyPlayerController->GetCurSelectedTile();
		if (MapTile != nullptr)
		{
			if (this->MoveBeginTile == MapTile->Tile)
			{
				MyPlayerController->CancelCurSelectedTileInClient();
			}
		}
	}
}

void ACWPawn::DeathInServer()
{
	SetActorLocation(FVector(-100000.0f, -100000.0f, -0.0f));

	/*check(ActionFSM);
	FCWPawnActionToDeathEvent* DieEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	ActionFSM->DoEvent(DieEvent);*/
	/*UCWPawnActionDataForDeath* TempDeathData = (UCWPawnActionDataForDeath*)NewObject<UCWPawnActionDataForDeath>();
	TempDeathData->ActionId = ECWPawnActionState::Death;
	this->PutAction(TempDeathData);*/

	if (BuffManager != nullptr)
	{
		BuffManager->DestoryAll();
		BuffManager->ConditionalBeginDestroy();
		BuffManager = nullptr;
	}

	NetMulticastRPCPawnDeath();
}

void ACWPawn::DeathInClient()
{
	NetMulticastAddDeadBody();

	SetActorLocation(FVector(-100000.0f, -100000.0f, -0.0f));

	/*check(ActionFSM);
	FCWPawnActionToDeathEvent* DieEvent = new FCWPawnActionToDeathEvent((int)ECWPawnActionEvent::ToDeath, (int)ECWPawnActionState::Death, ECWFSMStackOp::Set);
	ActionFSM->DoEvent(DieEvent);*/
	/*UCWPawnActionDataForDeath* TempDeathData = (UCWPawnActionDataForDeath*)NewObject<UCWPawnActionDataForDeath>();
	TempDeathData->ActionId = ECWPawnActionState::Death;
	this->PutAction(TempDeathData);*/

	if (IsMyClientPawn())
	{
		check(InputFSM);
		FCWPawnInputActionFinishEvent* ActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		InputFSM->DoEvent(ActionFinishEvent);
	}

	HideHintTile();
	HideWantMovePathArrow();
	RestoreEnemyHeadIconInAttackRange();
	RestorePartnerHeadIconInSupportRange();

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	if (MyPlayerController != nullptr)
	{
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			if (this->GetCampTag() ==  CurSelectedPawn->GetCampTag() &&
				this->GetCampControllerIndex() == CurSelectedPawn->GetCampControllerIndex() &&
				this->GetControllerPawnIndex() == CurSelectedPawn->GetControllerPawnIndex())
			{
				MyPlayerController->CancelCurSelectedPawnNoEventInClient();
			}
		}
		
		ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();
		if (CurTargetSelectedPawn != nullptr)
		{
			if (this->GetCampTag() == CurTargetSelectedPawn->GetCampTag() &&
				this->GetCampControllerIndex() == CurTargetSelectedPawn->GetCampControllerIndex() &&
				this->GetControllerPawnIndex() == CurTargetSelectedPawn->GetControllerPawnIndex())
			{
				MyPlayerController->CancelCurTargetSelectedPawnInClient();
			}
		}

		ACWMapTile* MapTile = MyPlayerController->GetCurSelectedTile();
		if (MapTile != nullptr)
		{
			if (this->MoveBeginTile == MapTile->Tile)
			{
				MyPlayerController->CancelCurSelectedTileInClient();
			}
		}
	}

	if (BuffManager != nullptr)
	{
		BuffManager->DestoryAll();
		BuffManager = nullptr;
	}
}

bool ACWPawn::IsValidTile(int32 ParamTile)
{
	check(GetDungeonGenerator());
	ACWDungeonTile* TempTile = GetDungeonGenerator()->GetDungeonTile(ParamTile);
	if (TempTile == nullptr)
	{
		return false;
	}

	return true;
}

int ACWPawn::GetMoveTileFromNormalAttackTargetTile(int ParamCurTile, int ParamTargetTile, ECWCampTag ParamCampTag, FCWPawnFindPathInfo ParamFindPathInfo)
{
	if (this->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->GetParantController());
		if (MyPlayerController != nullptr)
		{
			ACWMap* MyMap = this->GetMap();
			if (MyMap == nullptr)
				return -1;

			if (!RefreshMoveAttackDamageTile(ParamCurTile, false))
			{
				return -1;
			}

			const TArray<uint8>& ArrayMoveAttackDamage = MyMap->GetArrayMoveAttackDamage();
			UCWSkill* TempSkill = GetAutoSelectSkillRecord();

			if (TempSkill == nullptr)
				return -1;

			std::list<CWAttackGrid> listAttackGrid;
			std::list<int> listMoveTile;
			std::vector<int32> AttackRangeParams = FCWSkillDataUtils::GetArrayAttackRangeParamsFromString(TempSkill->GetSkillDataStruct()->AttackRangeParams);
			if (TempSkill->GetSkillDataStruct()->AttackRangeType == 1 && AttackRangeParams.size() == 2)
			{
				int from = AttackRangeParams[0];
				int to = AttackRangeParams[1];
				for (int i = 0; i < ArrayMoveAttackDamage.Num(); ++i)
				{
					uint8 TempMoveAttackDamage = ArrayMoveAttackDamage[i];
					if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Move) > 0)
					{
						int MyCurTile = i;
						int cx = -1;
						int cy = -1;
						ACWMap::tile2xy(MyCurTile, cx, cy);
						if (cx != -1 && cy != -1)
						{
							int beginX = cx - to < 0 ? 0 : cx - to;
							int endX = cx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + to;
							int beginY = cy - to < 0 ? 0 : cy - to;
							int endY = cy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + to;
							for (int y = beginY; y <= endY; ++y)
							{
								for (int x = beginX; x <= endX; ++x)
								{
									if (x == cx && y == cy)
										continue;

									if (FMath::Abs(x - cx) + FMath::Abs(y - cy) < from)
										continue;

									if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > to)
										continue;

									int TempTile = ACWMap::xy2tile(x, y);
									bool bIsThereEnemy = false;
									bIsThereEnemy = MyMap->isThereEnemy(TempTile, this->GetCampTag());
									if (bIsThereEnemy && ParamTargetTile == TempTile)
									{
										int MyAttackTile = ACWMap::xy2tile(cx, cy);
										listMoveTile.push_back(MyAttackTile);
										//return MyAttackTile;
									}
								}
							}
						}
					}
				}
			}
			else if (TempSkill->GetSkillDataStruct()->AttackRangeType == 2 && AttackRangeParams.size() == 2)
			{
				int from = AttackRangeParams[0];
				int to = AttackRangeParams[1];
				for (int i = 0; i < ArrayMoveAttackDamage.Num(); ++i)
				{
					uint8 TempMoveAttackDamage = ArrayMoveAttackDamage[i];
					if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Move) > 0)
					{
						int MyCurTile = i;
						int cx = -1;
						int cy = -1;
						ACWMap::tile2xy(MyCurTile, cx, cy);
						if (cx != -1 && cy != -1)
						{
							int beginX = cx - to < 0 ? 0 : cx - to;
							int endX = cx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + to;
							int beginY = cy - to < 0 ? 0 : cy - to;
							int endY = cy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + to;
							for (int y = beginY; y <= endY; ++y)
							{
								for (int x = beginX; x <= endX; ++x)
								{
									if (x == cx && y == cy)
										continue;

									if (FMath::Abs(x - cx) > to)
										continue;

									if (FMath::Abs(y - cy) > to)
										continue;

									if (!((FMath::Abs(x - cx) + FMath::Abs(y - cy) >= from) && (FMath::Abs(x - cx) >= from || FMath::Abs(y - cy) >= from)))
										continue;

									int TempTile = ACWMap::xy2tile(x, y);
									bool bIsThereEnemy = false;
									bIsThereEnemy = MyMap->isThereEnemy(TempTile, this->GetCampTag());
									if (bIsThereEnemy && ParamTargetTile == TempTile)
									{
										int MyAttackTile = ACWMap::xy2tile(cx, cy);
										listMoveTile.push_back(MyAttackTile);
										//return MyAttackTile;
									}
								}
							}
						}
					}
				}
			}
			else if (TempSkill->GetSkillDataStruct()->AttackRangeType == 3 && AttackRangeParams.size() == 2)
			{
				int from = AttackRangeParams[0];
				int to = AttackRangeParams[1];
				for (int i = 0; i < ArrayMoveAttackDamage.Num(); ++i)
				{
					uint8 TempMoveAttackDamage = ArrayMoveAttackDamage[i];
					if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Move) > 0)
					{
						int MyCurTile = i;
						int cx = -1;
						int cy = -1;
						ACWMap::tile2xy(MyCurTile, cx, cy);
						if (cx != -1 && cy != -1)
						{
							int beginX = cx - to < 0 ? 0 : cx - to;
							int endX = cx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + to;
							int beginY = cy - to < 0 ? 0 : cy - to;
							int endY = cy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + to;
							for (int y = beginY; y <= endY; ++y)
							{
								for (int x = beginX; x <= endX; ++x)
								{
									if (x == cx && y == cy)
										continue;

									if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > to)
										continue;

									if (FMath::Abs(x - cx) + FMath::Abs(y - cy) < from)
										continue;

									if (!((FMath::Abs(x - cx) >= from && FMath::Abs(y - cy) == 0) || (FMath::Abs(x - cx) == 0 && FMath::Abs(y - cy) >= from)))
										continue;

									int WantAttackTile = ACWMap::xy2tile(x, y);
									//bool bIsThereEnemy = false;
									//bIsThereEnemy = MyMap->isThereEnemy(TempTile, this->GetCampTag());
									//if (bIsThereEnemy && ParamTargetTile == TempTile)
									//{
									//	int MyAttackTile = ACWMap::xy2tile(cx, cy);
									//	listMoveTile.push_back(MyAttackTile);
									//	//return MyAttackTile;
									//}
									ECWAffectDirType TempDir = MyMap->GetAffectDir(MyCurTile, WantAttackTile);
									if (TempDir != ECWAffectDirType::None)
									{
										MyMap->SetVectorAttackGrid(WantAttackTile, MyCurTile, TempDir, (uint8)ECWMapTileMoveAttackDamageType::Attack);

										CWAttackGrid TempAttackGrid;
										TempAttackGrid.Tile = WantAttackTile;
										TempAttackGrid.PawnTile = MyCurTile;
										TempAttackGrid.Dir = (uint8)TempDir;
										TempAttackGrid.MAD = (uint8)ECWMapTileMoveAttackDamageType::Attack;

										bool TempIsFindInListAttackGrid = false;
										for (std::list<CWAttackGrid>::iterator iter2 = listAttackGrid.begin(); iter2 != listAttackGrid.end(); ++iter2)
										{
											CWAttackGrid& TempGrid = *iter2;
											if (TempAttackGrid == TempGrid)
											{
												TempIsFindInListAttackGrid = true;
												break;
											}
										}

										if (!TempIsFindInListAttackGrid)
										{
											listAttackGrid.push_back(TempAttackGrid);
										}
									}
									else
									{
										UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetMoveTileFromNormalAttackTargetTile, TempDir == ECWAffectDirType::None, MyCurTile:%d, WantAttackTile:%d."), MyCurTile, WantAttackTile);
									}
								}
							}
						}
					}
				}
			}
			else
			{

			}

			for (std::list<CWAttackGrid>::iterator iter = listAttackGrid.begin(); iter != listAttackGrid.end(); ++iter)
			{
				CWAttackGrid TempAttackGrid = *iter;

				if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Right)
				{
					std::vector<std::vector<int32> > TempDamageRangeRight = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeRight);
					std::vector<int32> TempDamageCenterRight = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterRight);
					if (TempDamageCenterRight.size() != 2)
					{
						UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetMoveTileFromNormalAttackTargetTile, TempDamageCenterRight.size() != 2, TempDamageCenterRight.size():%d."), TempDamageCenterRight.size());
						return false;
					}
					int32 TempBaseX_Right = TempDamageCenterRight[0];
					int32 TempBaseY_Right = TempDamageCenterRight[1];
					FVector attack_pos = FVector::ZeroVector;
					ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
					for (int y = 0; y < TempDamageRangeRight.size(); ++y)
					{
						for (int x = 0; x < TempDamageRangeRight[y].size(); ++x)
						{
							int32 TempDamage = TempDamageRangeRight[y][x];
							if (TempDamage == 0)
								continue;

							int ox = x - TempBaseX_Right;
							int oy = y - TempBaseY_Right;

							float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
							float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

							int real_x = -1;
							int real_y = -1;
							FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
							ACWMap::pos2xy(real_pos, real_x, real_y);

							if (real_x < 0 || real_x >= MyMap->getWidth())
								continue;

							if (real_y < 0 || real_y >= MyMap->getHeight())
								continue;

							int real_tile = ACWMap::xy2tile(real_x, real_y);
							//MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
							//MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);

							bool bIsThereEnemy = false;
							bIsThereEnemy = MyMap->isThereEnemy(real_tile, this->GetCampTag());
							if (bIsThereEnemy && ParamTargetTile == real_tile)
							{
								//int MyAttackTile = ACWMap::xy2tile(cx, cy);
								listMoveTile.push_back(TempAttackGrid.PawnTile);
								//return MyAttackTile;
							}
						}
					}
				}
				else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Up)
				{
					std::vector<std::vector<int32> > TempDamageRangeUp = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeUp);
					std::vector<int32> TempDamageCenterUp = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterUp);
					if (TempDamageCenterUp.size() != 2)
					{
						UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetMoveTileFromNormalAttackTargetTile, TempDamageCenterUp.size() != 2, TempDamageCenterUp.size():%d."), TempDamageCenterUp.size());
						return false;
					}
					int32 TempBaseX_Up = TempDamageCenterUp[0];
					int32 TempBaseY_Up = TempDamageCenterUp[1];
					FVector attack_pos = FVector::ZeroVector;
					ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
					for (int y = 0; y < TempDamageRangeUp.size(); ++y)
					{
						for (int x = 0; x < TempDamageRangeUp[y].size(); ++x)
						{
							int32 TempDamage = TempDamageRangeUp[y][x];
							if (TempDamage == 0)
								continue;

							int ox = x - TempBaseX_Up;
							int oy = y - TempBaseY_Up;

							float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
							float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

							int real_x = -1;
							int real_y = -1;
							FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
							ACWMap::pos2xy(real_pos, real_x, real_y);

							if (real_x < 0 || real_x >= MyMap->getWidth())
								continue;

							if (real_y < 0 || real_y >= MyMap->getHeight())
								continue;

							int real_tile = ACWMap::xy2tile(real_x, real_y);
							//MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
							//MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						
							bool bIsThereEnemy = false;
							bIsThereEnemy = MyMap->isThereEnemy(real_tile, this->GetCampTag());
							if (bIsThereEnemy && ParamTargetTile == real_tile)
							{
								//int MyAttackTile = ACWMap::xy2tile(cx, cy);
								listMoveTile.push_back(TempAttackGrid.PawnTile);
								//return MyAttackTile;
							}
						}
					}
				}
				else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Left)
				{
					std::vector<std::vector<int32> > TempDamageRangeLeft = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeLeft);
					std::vector<int32> TempDamageCenterLeft = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterLeft);
					if (TempDamageCenterLeft.size() != 2)
					{
						UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetMoveTileFromNormalAttackTargetTile, TempDamageCenterLeft.size() != 2, TempDamageCenterLeft.size():%d."), TempDamageCenterLeft.size());
						return false;
					}
					int32 TempBaseX_Left = TempDamageCenterLeft[0];
					int32 TempBaseY_Left = TempDamageCenterLeft[1];
					FVector attack_pos = FVector::ZeroVector;
					ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
					for (int y = 0; y < TempDamageRangeLeft.size(); ++y)
					{
						for (int x = 0; x < TempDamageRangeLeft[y].size(); ++x)
						{
							int32 TempDamage = TempDamageRangeLeft[y][x];
							if (TempDamage == 0)
								continue;

							int ox = x - TempBaseX_Left;
							int oy = y - TempBaseY_Left;

							float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
							float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

							int real_x = -1;
							int real_y = -1;
							FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
							ACWMap::pos2xy(real_pos, real_x, real_y);

							if (real_x < 0 || real_x >= MyMap->getWidth())
								continue;

							if (real_y < 0 || real_y >= MyMap->getHeight())
								continue;

							int real_tile = ACWMap::xy2tile(real_x, real_y);
							//MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
							//MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						
							bool bIsThereEnemy = false;
							bIsThereEnemy = MyMap->isThereEnemy(real_tile, this->GetCampTag());
							if (bIsThereEnemy && ParamTargetTile == real_tile)
							{
								//int MyAttackTile = ACWMap::xy2tile(cx, cy);
								listMoveTile.push_back(TempAttackGrid.PawnTile);
								//return MyAttackTile;
							}
						}
					}
				}
				else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Down)
				{
					std::vector<std::vector<int32> > TempDamageRangeDown = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeDown);
					std::vector<int32> TempDamageCenterDown = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterDown);
					if (TempDamageCenterDown.size() != 2)
					{
						UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GetMoveTileFromNormalAttackTargetTile, TempDamageCenterDown.size() != 2, TempDamageCenterDown.size():%d."), TempDamageCenterDown.size());
						return false;
					}
					int32 TempBaseX_Down = TempDamageCenterDown[0];
					int32 TempBaseY_Down = TempDamageCenterDown[1];
					FVector attack_pos = FVector::ZeroVector;
					ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
					for (int y = 0; y < TempDamageRangeDown.size(); ++y)
					{
						for (int x = 0; x < TempDamageRangeDown[y].size(); ++x)
						{
							int32 TempDamage = TempDamageRangeDown[y][x];
							if (TempDamage == 0)
								continue;

							int ox = x - TempBaseX_Down;
							int oy = y - TempBaseY_Down;

							float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
							float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

							int real_x = -1;
							int real_y = -1;
							FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
							ACWMap::pos2xy(real_pos, real_x, real_y);

							if (real_x < 0 || real_x >= MyMap->getWidth())
								continue;

							if (real_y < 0 || real_y >= MyMap->getHeight())
								continue;

							int real_tile = ACWMap::xy2tile(real_x, real_y);

							//MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
							//MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						
							bool bIsThereEnemy = false;
							bIsThereEnemy = MyMap->isThereEnemy(real_tile, this->GetCampTag());
							if (bIsThereEnemy && ParamTargetTile == real_tile)
							{
								//int MyAttackTile = ACWMap::xy2tile(cx, cy);
								listMoveTile.push_back(TempAttackGrid.PawnTile);
								//return MyAttackTile;
							}
						}
					}
				}
			}

			if (listMoveTile.empty())
				return -1;

			for (std::list<int>::iterator iter = listMoveTile.begin(); iter != listMoveTile.end(); ++iter)
			{
				int TempMoveTile = *iter;
				if (ParamCurTile == TempMoveTile)
				{
					return ParamCurTile;
				}
			}

			MapTileCompare TempMapTileCompare(this->GetMap(), ParamCurTile, ParamCampTag, ParamFindPathInfo);
			listMoveTile.sort(TempMapTileCompare);

			return listMoveTile.front();
		}
	}

	return -1;
}


bool ACWPawn::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWPawn::IsMyClientPawn() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWPawn::IsOtherClientPawn() const
{
	return Role == ROLE_SimulatedProxy;
}

bool ACWPawn::IsPawnTurn() const
{
	if (ACWGameState* GameState = GetGameState())
	{
		if (GetCampTag() == GameState->GetCurCampTag() &&
			GetCampControllerIndex() == GameState->GetCurCampControllerIndex())
		{
			return true;
		}
	}
	return false;
}

bool ACWPawn::IsCanAction() const
{
	return IsPawnTurn() && IsMyClientPawn() && CanInstructsByCurInstructs();
}

void ACWPawn::AddEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0 && IsPawnType(ECWPawnType::Character))
	{
		FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, SkeletalMeshComponent);
	}
}

void ACWPawn::AddAttackEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0 && IsPawnType(ECWPawnType::Character))
	{
		RemoveAttackEffect();
		FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, SkeletalMeshComponent, 
		[this](UParticleSystemComponent* InPSC, UParticleSystem* InPS)
		{
			if (!IsPendingKillPending() && nullptr != InPSC)
			{
				ArrayAttackEffect.AddUnique(InPSC);
			}
		});
	}
}

void ACWPawn::RemoveAttackEffect()
{
	for (TArray<TWeakObjectPtr<UParticleSystemComponent>>::TIterator iter = ArrayAttackEffect.CreateIterator(); iter; ++iter)
	{
		TWeakObjectPtr<UParticleSystemComponent> ParticleSystemComponentPtr = *iter;
		if (ParticleSystemComponentPtr.IsValid())
		{
			ParticleSystemComponentPtr->DestroyComponent();
			ParticleSystemComponentPtr = nullptr;
		}
	}

	ArrayAttackEffect.Empty();
}

void ACWPawn::AddBeAttackedEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0/* && IsPawnType(ECWPawnType::Character)*/)
	{
		FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, SkeletalMeshComponent);
	}
}

int32 ACWPawn::AddBuffEffect(const int32 InEffectId)
{
	if (!IsInServer() && InEffectId > 0 && IsPawnType(ECWPawnType::Character))
	{
		if (const FCWEffectDataStruct* EffectData = FCWCfgUtils::GetEffectData(this, InEffectId))
		{
			++BuffEffectIdGenerator;

			FCWEffectDataStruct::SpawnEmitterAttached(InEffectId, SkeletalMeshComponent,
			[this](UParticleSystemComponent* InPSC, UParticleSystem* InPS)
			{
				if (!IsPendingKillPending() && nullptr != InPSC)
				{
					MapBuffEffect.Add(BuffEffectIdGenerator, InPSC);
				}
			});

			return BuffEffectIdGenerator;
		}

		CWG_WARNING(">> CWPawn::AddBuffEffect, InEffectId[%d] is invalid.", InEffectId);
	}

	return INDEX_NONE;
}

void ACWPawn::RemoveBuffEffect(int32 ParamBuffEffectId)
{
	TWeakObjectPtr<UParticleSystemComponent> MyPSCRef = MapBuffEffect.FindRef(ParamBuffEffectId);
	if (UParticleSystemComponent* MyPSC = MyPSCRef.Get())
	{
		MyPSC->DestroyComponent();
	}
	MapBuffEffect.Remove(ParamBuffEffectId);
}

const FCWPawnDataStruct* ACWPawn::GetPawnDataStruct() const
{
	return nullptr;
}

const FCWProfessionDataStruct* ACWPawn::GetProfessionData() const
{
	const FCWProfessionDataStruct* RetValue = FCWCfgUtils::GetProfessionData(this, PawnNetData.Profession);
	return RetValue;
}

int32 ACWPawn::GetProfession() const
{
	const FCWProfessionDataStruct* TempProfessionData = GetProfessionData();
	if (TempProfessionData != nullptr)
	{
		return TempProfessionData->ProfessionId;
	}

	return 0;
}

void ACWPawn::ShowUserWidget(bool bNewVisible, bool bAffectRoot)
{
#if !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer) && IsValid(WidgetComp))
	{
		if (IsPawnType(ECWPawnType::DungeonItem))
		{
			WidgetComp->SetVisibility(bNewVisible);
		}
		else if (IsPawnType(ECWPawnType::Character))
		{
			// 是否影响整个控件组件
			if (bAffectRoot)
			{
				WidgetComp->SetVisibility(bNewVisible);
			}

			// 设置棋子RootUI
			if (UCWUIPawnWidget* UIPawnWidget = GetUserWidget())
			{
				UIPawnWidget->SetTrsMainNode(bNewVisible);
				if (bNewVisible)
				{
					UIPawnWidget->UpdateBuffList(this);
				}
			}
		}
	}
#endif // !UE_SERVER
}

FString ACWPawn::GetDisplayName() const
{
	if (const FCWProfessionDataStruct* ProfessionData = FCWCfgUtils::GetProfessionData(this, PawnNetData.Profession))
	{
		return ProfessionData->ProfessionName;
	}
	return TEXT("");
}

void ACWPawn::ShowHeadIcon(EUIHeadIconType IconType)
{
	if (UCWUIPawnWidget* UIPawnWidget = GetUserWidget())
	{
		UIPawnWidget->ShowHeadIcon(IconType);
	}
}

bool ACWPawn::IsEnablePawnUI(const ACWPlayerController* InLocalPC) const
{
	if (bAlwaysEnablePawnUI)
	{
		return true;
	}

	const UCWUIManager* UIMgr = UI_MGR(this);
	const ACWPlayerController* LocalPC = InLocalPC ? InLocalPC : GetLocalPC();
	const uint8 EnablePawnUIMode = UIMgr ? UIMgr->GetEnablePawnUIMode() : 0;
	const bool bNewVisible = (EnablePawnUIMode < 2) ? (bool)EnablePawnUIMode : !LocalPC->IsEnemy(this);
	return bNewVisible;
}

void ACWPawn::NotifyShowPreviewInfo(bool bNewVisible)
{
	if (UCWUIPawnWidget* UIPawnWidget = GetUserWidget())
	{
		UIPawnWidget->ShowPreviewInfo(bNewVisible);
		if (!bNewVisible)
		{	// 重置血量显示
			const FCWBattlePropertySet& CurVProperty = BattleProperty->GetCurPropertySet();
			const FCWBattlePropertySet& MaxVProperty = BattleProperty->GetCurMaxTheoreticalPropertySet();
			float CurHp = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
			float MaxHp = MaxVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
			UIPawnWidget->SetHPText((int32)CurHp, (int32)MaxHp);
		}
	}
}

void ACWPawn::NotifyUpdatePreviewInfo(ACWPawn* InOtherPawn, FFightPreviewData& InOtherData, FFightPreviewData& InMyData)
{
	if (UCWUIPawnWidget* UIPawnWidget = GetUserWidget())
	{
		UIPawnWidget->UpdatePreviewInfo(InOtherPawn, InOtherData, InMyData);
	}
}

void ACWPawn::ShowMiniAvatar(bool bIsShow)
{
	UCWUIPawnWidget* UIPawnWidget = GetUserWidget();
	if (nullptr != UIPawnWidget)
	{
		UIPawnWidget->ShowMiniAvatar(bIsShow);
	}
}

void ACWPawn::NetMulticastFlyWordsEffect_Implementation(const int32 InType, const float InValue, const FString& InParam /*= TEXT("")*/)
{
	if (!IsNetMode(NM_DedicatedServer))
	{
		FlyWordsEffectImpl(InType, InValue, InParam);
	}
}

void ACWPawn::FlyWordsEffectImpl(const int32 InType, const float InValue, const FString& InParam /*= TEXT("")*/)
{
	/*UCWUIPawnWidget* UIPawnWidget = GetUserWidget();
	if (nullptr != UIPawnWidget)
	{
		UIPawnWidget->FlyWordsEffectImpl(InType, InValue, InParam);
	}*/

	ACWPlayerController* LocalPC = GetLocalPC();
	ACWHUDBase* MyHUD = LocalPC ? Cast<ACWHUDBase>(LocalPC->GetHUD()) : nullptr;
	if (nullptr != MyHUD)
	{
		MyHUD->FlyWordsEffectImpl(this, InType, InValue, InParam);
	}
}

void ACWPawn::OnRep_ClientChangeCamp()
{
	UCWUIPawnWidget* UIPawnWidget = GetUserWidget();
	if (nullptr != UIPawnWidget)
	{
		UIPawnWidget->SetHPColor(IsMyClientPawn());
	}
}

void ACWPawn::OnRep_ClientChangePawnIdx()
{
}

void ACWPawn::OnPropertySetCurInClient(const FCWBattlePropertySet OldPropertySet)
{
	NotifyUpdatePropertyData();

	const ECWBattleState BattleState = GetBattleState();
	if (nullptr != BattleProperty && BattleState == ECWBattleState::Fighting)
	{
		const FCWBattlePropertySet& CurVProperty = BattleProperty->GetCurPropertySet();
		const int32 OldHp = OldPropertySet.GetPropertyByFloat(ECWBattleProperty::Health);
		const int32 CurHp = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		if (OldHp != CurHp)
		{
			NotifyForceShowPawnUI();
		}
	}
}

void ACWPawn::OnPropertySetMaxInClient(const FCWBattlePropertySet OldPropertySet)
{
	NotifyUpdatePropertyData();
}

void ACWPawn::NotifyUpdatePropertyData()
{
	//CWG_LOG(">>> %s::OnPropertySetChangeInClient Camp[%d] CtrlIdx[%d] Idx[%d]...", 
		//*GetName(), (int32)CampTag, (int32)ControllerIndex, (int32)PawnIndex);
	UCWUIPawnWidget* UIPawnWidget = GetUserWidget();
	if (nullptr != UIPawnWidget && nullptr != BattleProperty)
	{
		const FCWBattlePropertySet& CurVProperty = BattleProperty->GetCurPropertySet();
		const FCWBattlePropertySet& MaxVProperty = BattleProperty->GetCurMaxTheoreticalPropertySet();

		ECWBattleAttackType AtkType = CurVProperty.GetPropertyForAttackType(ECWBattleProperty::AttackType);
		UIPawnWidget->SetAtkAttrText(AtkType);

		float CurHp = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		float MaxHp = MaxVProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		UIPawnWidget->SetHPText((int32)CurHp, (int32)MaxHp);

		float CurSp = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Energy);
		float MaxSp = MaxVProperty.GetPropertyByFloat(ECWBattleProperty::Energy);
		UIPawnWidget->SetSPText((int32)CurSp, (int32)MaxSp);

		UIPawnWidget->UpdateImgWeapon(GetWeaponId());

		//CWG_WARNING(">> %s::OnPropertySetChangeInClient 0, PawnInfo[%s].", *GetName(), *ToDebugString());
		//CWG_WARNING(">> %s::OnPropertySetChangeInClient 1, CurHp[%d] MaxHp[%d] CurSp[%d] MaxSp[%d].", *GetName(), CurHp,MaxHp,CurSp,MaxSp);
	}
}

void ACWPawn::NotifyForceShowPawnUI(const float InKeepTime /*= 2.5f*/)
{
	bAlwaysEnablePawnUI = true;
	ShowUserWidget(true);

	// 延时关闭UI
	auto DelayCallable = [this]()
	{
		bAlwaysEnablePawnUI = false;
		ShowUserWidget(IsEnablePawnUI());
	};
	FTimerManager& TimerManager = GetWorldTimerManager();
	TimerManager.SetTimer(DelayHideHandle, DelayCallable, InKeepTime, false);
}

void ACWPawn::ResetWhenNextTurnBeginInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (PawnType == ECWPawnType::Character)
	{
		const bool bIsDizziness = CheckDizzinessResult();
		uint8 NewInstructs = bIsDizziness ? Instruct_InValid : 0x00;
		ArrayInstructs.Empty();
		FCWPawnInstructs PawnInstructs;
		PawnInstructs.Instructs = NewInstructs;
		ArrayInstructs.Add(PawnInstructs);

		MoveToDestTile = -1;

		TargetCampTag = ECWCampTag::None;
		TargetCampControllerIndex = ECWCampControllerIndex::None;
		TargetControllerPawnIndex = 0;
		//TargetTile = -1;
		bIsActionEnd = false;

		check(BuffManager);
		BuffManager->ResetForRound();

		if (SkillManager != nullptr)
		{
			SkillManager->ResetForRound();
		}

		NetMulticastRPCResetWhenNextTurnBegin(ParamCampTag, ParamCampControllerIndex);
	}
}

void ACWPawn::ResetWhenNextTurnBeginInClient(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (PawnType == ECWPawnType::Character)
	{
		const bool bIsDizziness = CheckDizzinessResult();
		uint8 NewInstructs = bIsDizziness ? Instruct_InValid : 0x00;
		ArrayInstructs.Empty();
		FCWPawnInstructs PawnInstructs;
		PawnInstructs.Instructs = NewInstructs;
		ArrayInstructs.Add(PawnInstructs);

		MoveToDestTile = -1;
		ReadyToDestTile = -1;
		MoveBeginTile = -1;

		TargetCampTag = ECWCampTag::None;
		TargetCampControllerIndex = ECWCampControllerIndex::None;
		TargetControllerPawnIndex = 0;
		//TargetTile = -1;
		bIsActionEnd = false;

		CancelSelectedNoEventInClient();

		if (this->GetCampTag() == ParamCampTag &&
			this->GetCampControllerIndex() == ParamCampControllerIndex &&
			IsMyClientPawn())
		{
			if (!bIsDizziness)
			{
				FCWPawnInputWaitingTurnEvent* InputWaitingTurnEvent = new FCWPawnInputWaitingTurnEvent((int)ECWPawnInputEvent::TurnWaitingAction, (int)ECWPawnInputState::TurnWaitingAction, ECWFSMStackOp::Set);
				InputFSM->DoEvent(InputWaitingTurnEvent);
			}
			else
			{
				// 直接到输入动作完成状态
				FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
					(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
				InputFSM->DoEvent(ToNewEvent);
			}
		}

		ACWPlayerController* MyPlayerController = (ACWPlayerController*)ParantController;
		if (MyPlayerController != nullptr)
		{
			if (MyPlayerController->IsEnemy(this))
			{
				SetCustomDepthStencilValue(102);
			}
			else if (!IsCanAction())
			{
				SetCustomDepthStencilValue(0);
			}
		}
	}
}

void ACWPawn::StartActionInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (PawnType == ECWPawnType::Character)
	{
		const bool bIsDizziness = CheckDizzinessResult();
		if (!bIsDizziness)
		{
			/*FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
			ActionFSM->DoEvent(ToIdleEvent);*/
			UCWPawnActionDataForIdle* TempIdleData = (UCWPawnActionDataForIdle*)NewObject<UCWPawnActionDataForIdle>();
			TempIdleData->ActionId = ECWPawnActionState::Idle;
			this->PutAction(TempIdleData);

			if (this->GetCampTag() == ParamCampTag &&
				this->GetCampControllerIndex() == ParamCampControllerIndex)
			{
				ArrayInstructs.Empty();
				FCWPawnInstructs PawnInstructs;
				PawnInstructs.Instructs = 0x00;
				ArrayInstructs.Add(PawnInstructs);
			}
		}
		else
		{	// 当前是眩晕状态
			if (this->GetCampTag() == ParamCampTag &&
				this->GetCampControllerIndex() == ParamCampControllerIndex)
			{
				// 操作指令(无法行动)
				ArrayInstructs.Empty();
				FCWPawnInstructs PawnInstructs;
				PawnInstructs.Instructs = Instruct_InValid;
				ArrayInstructs.Add(PawnInstructs);
			}
		}

		NetMulticastRPCStartAction(ParamCampTag, ParamCampControllerIndex);
	}
}

void ACWPawn::StartActionInClient(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (PawnType == ECWPawnType::Character)
	{
		const bool bIsDizziness = CheckDizzinessResult();
		if (!bIsDizziness)
		{
			/*FCWPawnActionToIdleEvent* ToIdleEvent = new FCWPawnActionToIdleEvent((int)ECWPawnActionEvent::ToIdle, (int)ECWPawnActionState::Idle, ECWFSMStackOp::Set);
			ActionFSM->DoEvent(ToIdleEvent);*/
			UCWPawnActionDataForIdle* TempIdleData = (UCWPawnActionDataForIdle*)NewObject<UCWPawnActionDataForIdle>();
			TempIdleData->ActionId = ECWPawnActionState::Idle;
			this->PutAction(TempIdleData);

			if (this->GetCampTag() == ParamCampTag &&
				this->GetCampControllerIndex() == ParamCampControllerIndex &&
				IsMyClientPawn())
			{
				ArrayInstructs.Empty();
				FCWPawnInstructs PawnInstructs;
				PawnInstructs.Instructs = 0x00;
				ArrayInstructs.Add(PawnInstructs);

				FCWPawnInputWaitingEvent* WaitingInputEvent = new FCWPawnInputWaitingEvent((int)ECWPawnInputEvent::TurnStartAction, (int)ECWPawnInputState::WaitingInput, ECWFSMStackOp::Set);
				InputFSM->DoEvent(WaitingInputEvent);

				AutoSelectSkill();
			}
		}
		else
		{	// 当前是眩晕状态
			if (this->GetCampTag() == ParamCampTag &&
				this->GetCampControllerIndex() == ParamCampControllerIndex &&
				IsMyClientPawn())
			{
				// 操作指令(无法行动)
				ArrayInstructs.Empty();
				FCWPawnInstructs PawnInstructs;
				PawnInstructs.Instructs = Instruct_InValid;
				ArrayInstructs.Add(PawnInstructs);

				// 直接到输入动作完成状态
				FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
					(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
				InputFSM->DoEvent(ToNewEvent);
			}
		}

		ACWPlayerController* MyPlayerController = (ACWPlayerController*)ParantController;
		if (MyPlayerController != nullptr)
		{
			if (MyPlayerController->IsEnemy(this))
			{
				SetCustomDepthStencilValue(102);
			}
			/*else if (!IsCanAction())
			{
				SetCustomDepthStencilValue(0);
			}*/
		}
	}
}

void ACWPawn::SetMoveModeInServer(ECWPawnMoveMode ParamMoveMode)
{
	if (PawnType == ECWPawnType::Character)
	{
		FCWPawnDataStruct* TempPawnData = FCWCommonUtil::FindCSVRow<FCWPawnDataStruct>(TEXT("CWPawnDataTable"), GetPawnId());
		if (TempPawnData == nullptr)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetMoveModeInServer fail, TempPawnData == nullptr, PawnId:%d."), GetPawnId());
			return;
		}

		if (ParamMoveMode == ECWPawnMoveMode::Two)
		{
			this->MoveSpeed = TempPawnData->MoveSpeed2;
			this->MoveAnimSpeedRate = TempPawnData->MoveAnimSpeedRate2;
		}
		else
		{
			this->MoveSpeed = TempPawnData->MoveSpeed;
			this->MoveAnimSpeedRate = TempPawnData->MoveAnimSpeedRate;
		}

		NetMulticastRPCSetMoveMode(ParamMoveMode);
	}
}

void ACWPawn::SetMoveModeInClient(ECWPawnMoveMode ParamMoveMode)
{
	if (PawnType == ECWPawnType::Character)
	{
		FCWPawnDataStruct* TempPawnData = FCWCommonUtil::FindCSVRow<FCWPawnDataStruct>(TEXT("CWPawnDataTable"), GetPawnId());
		if (TempPawnData == nullptr)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::SetMoveModeInClient fail, TempPawnData == nullptr, PawnId:%d."), GetPawnId());
			return;
		}

		if (ParamMoveMode == ECWPawnMoveMode::Two)
		{
			this->MoveSpeed = TempPawnData->MoveSpeed2;
			this->MoveAnimSpeedRate = TempPawnData->MoveAnimSpeedRate2;
		}
		else
		{
			this->MoveSpeed = TempPawnData->MoveSpeed;
			this->MoveAnimSpeedRate = TempPawnData->MoveAnimSpeedRate;
		}
	}
}


void ACWPawn::CurTurnActionEndInServer()
{
	OnPawnnActionEndEventInServer.Broadcast(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex());
}

void ACWPawn::DieEndInServer()
{
	NetMulticastAddDeadBody();

	OnPawnnDieEndEventInServer.Broadcast(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex());
}

void ACWPawn::OnRep_PawnTileChangedInClient()
{
	if (OldTile != Tile)
	{
		OnPawnTileChangedEventInClient.Broadcast(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex(), OldTile, Tile);
	}
}

void ACWPawn::OnRep_PawnIdChangedInClient()
{
	OnPawnIdChangedEventInClient.Broadcast(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex(), PawnId);

	UCWUIPawnWidget* UIPawnWidget = GetUserWidget();
	if (nullptr != UIPawnWidget)
	{
		UIPawnWidget->SetNameText(GetDisplayName());
	}
}

void ACWPawn::OnBattleStateChange(const ECWBattleState InOldState, const ECWBattleState InCurState)
{
	if (InCurState == ECWBattleState::Ready)
	{
		NotifyUpdatePropertyData();

#if !UE_SERVER
		if (IsPawnType(ECWPawnType::Character))
		{
			UCWEventMgr* EvtMgr = EVT_MGR(this);
			if (nullptr != EvtMgr)
			{
				// 增加雪地目标
				EvtMgr->OnAddSnowfieldTarget.Broadcast(this);
			}
		}
#endif //!UE_SERVER
	}
}

void ACWPawn::NetMulticastUpdateBuff_Implementation(const int32 InBuffUniqueId, const int32 InBuffId, const int32 InRemain)
{
	if (!IsInServer() && IsValidObject(BuffManager))
	{
		BuffManager->OnUpdateBuffInClient(InBuffUniqueId, InBuffId, InRemain);
	}
}

void ACWPawn::NetMulticastRPCAddBuff_Implementation(int32 ParamBuffUniqueId, int32 ParamBuffId, ECWBuffSouceType InSouceType)
{
	if (IsInServer())
		return;

	UCWBuff* TempBuff = new UCWBuff();
	if (TempBuff != nullptr)
	{
		TempBuff->SetSouceType(InSouceType);
		if (TempBuff->InitInClient(BuffManager, ParamBuffUniqueId, ParamBuffId))
		{
			if (BuffManager->AddBuffInClient(TempBuff))
			{
			}
		}
	}
}

void ACWPawn::NetMulticastRPCRemoveBuff_Implementation(int32 ParamBuffUniqueId, int32 ParamBuffId)
{
	if (IsInServer())
		return;

	BuffManager->RemoveBuffInClient(ParamBuffUniqueId, ParamBuffId);
}

void ACWPawn::NetMulticastRemovePassivityBuff_Implementation(const int32 InBuffUniqueId, const int32 InBuffId)
{
	if (!IsInServer() && IsValidObject(BuffManager))
	{
		BuffManager->RemovePassivityBuffInClient(InBuffUniqueId, InBuffId);
	}
}

void ACWPawn::NetMulticastRPCResetWhenNextTurnBegin_Implementation(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (IsInServer())
		return;

	ResetWhenNextTurnBeginInClient(ParamCampTag, ParamCampControllerIndex);
}

void ACWPawn::NetMulticastRPCStartAction_Implementation(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex)
{
	if (IsInServer())
		return;

	StartActionInClient(ParamCampTag, ParamCampControllerIndex);
}

void ACWPawn::NetMulticastRPCSetMoveMode_Implementation(ECWPawnMoveMode ParamMoveMode)
{
	if (IsInServer())
		return;

	SetMoveModeInClient(ParamMoveMode);
}

void ACWPawn::ServerRPCMoveToDestTile_Implementation(int ParamDestTile)
{
	if (IsInServer())
	{
		ACWMap* MyMap = this->GetMap();
		if (MyMap == nullptr)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToDestTile_Implementation Fail. MyMap == nullptr."));
			NetMulticastRPCResetPawnInputState();
			return;
		}
	
		if (MyMap->canPass(ParamDestTile) && 
			((!MyMap->isTherePawn(ParamDestTile)) || (MyMap->isTherePawn(ParamDestTile) && MyMap->IsMe(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex(), ParamDestTile))))
		{
			MoveToDestTile = ParamDestTile;

			//check(ActionFSM);
			//FCWPawnActionToMoveToDestEvent* ToMoveToDestEvent = new FCWPawnActionToMoveToDestEvent((int)ECWPawnActionEvent::ToMoveToDest, (int)ECWPawnActionState::MoveToDest, ECWFSMStackOp::Set, MoveToDestTile);
			//ActionFSM->DoEvent(ToMoveToDestEvent);
			UCWPawnActionDataForMoveToDest* TempMoveToDestData = (UCWPawnActionDataForMoveToDest*)NewObject<UCWPawnActionDataForMoveToDest>();
			TempMoveToDestData->ActionId = ECWPawnActionState::MoveToDest;
			TempMoveToDestData->DestTile = MoveToDestTile;
			this->PutAction(TempMoveToDestData);

			UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::ServerRPCMoveToDestTile_Implementation. ParamDestTile:%d."), ParamDestTile);

			NetMulticastRPCMoveToDestTile(MoveToDestTile);
		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToDestTile_Implementation Fail. ParamDestTile:%d."), ParamDestTile);
			NetMulticastRPCResetPawnInputState();
		}
	}
}

bool ACWPawn::ServerRPCMoveToDestTile_Validate(int ParamDestTile)
{
	return true;
}

void ACWPawn::NetMulticastRPCMoveToDestTile_Implementation(int ParamDestTile)
{
	if (IsInServer())
		return;

	MoveToDestTile = ParamDestTile;

	//check(ActionFSM);
	//FCWPawnActionToMoveToDestEvent* ToMoveToDestEvent = new FCWPawnActionToMoveToDestEvent((int)ECWPawnActionEvent::ToMoveToDest, (int)ECWPawnActionState::MoveToDest, ECWFSMStackOp::Set, MoveToDestTile);
	//ActionFSM->DoEvent(ToMoveToDestEvent);
	UCWPawnActionDataForMoveToDest* TempMoveToDestData = (UCWPawnActionDataForMoveToDest*)NewObject<UCWPawnActionDataForMoveToDest>();
	TempMoveToDestData->ActionId = ECWPawnActionState::MoveToDest;
	TempMoveToDestData->DestTile = MoveToDestTile;
	this->PutAction(TempMoveToDestData);

	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NetMulticastRPCMoveToDestTile_Implementation. ParamDestTile:%d."), ParamDestTile);
}


void ACWPawn::ServerRPCMoveToAttack_Implementation(
	int32 ParamSkillId,
	int ParamTargetTile,
	int ParamMoveDestTile)
{
	if (IsInServer())
	{
		ACWMap* MyMap = this->GetMap();
		if (MyMap == nullptr)
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToAttack_Implementation Fail. MyMap == nullptr."));
			NetMulticastRPCResetPawnInputState();
			return;
		}

		if (!IsValidTile(ParamTargetTile))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToAttack_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
			NetMulticastRPCResetPawnInputState();
			return;
		}

		if (MyMap->canPass(ParamMoveDestTile) &&
			((!MyMap->isTherePawn(ParamMoveDestTile)) || (MyMap->isTherePawn(ParamMoveDestTile) && MyMap->IsMe(this->GetCampTag(), this->GetCampControllerIndex(), this->GetControllerPawnIndex(), ParamMoveDestTile))))
		{
			MoveToDestTile = ParamMoveDestTile;
			TargetTile = ParamTargetTile;

			UCWPawnActionDataForMoveToDest* TempMoveToDestData = (UCWPawnActionDataForMoveToDest*)NewObject<UCWPawnActionDataForMoveToDest>();
			TempMoveToDestData->ActionId = ECWPawnActionState::MoveToDest;
			TempMoveToDestData->DestTile = MoveToDestTile;
			this->PutAction(TempMoveToDestData);

			/*ACWPawn* TargetPawn = nullptr;
			for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
			{
				ACWPawn* TempPawn = *Iter;
				if (TempPawn != nullptr &&
					TempPawn->GetTile() == TargetTile)
				{
					TargetPawn = TempPawn;
					break;
				}
			}*/

			//if (TargetPawn != nullptr)
			{
				/*check(ActionFSM);
				FCWPawnActionToMoveToAttackEvent* ToMoveToAttackEvent = new FCWPawnActionToMoveToAttackEvent(
					(int)ECWPawnActionEvent::ToMoveToAttack,
					(int)ECWPawnActionState::MoveToAttack,
					ECWFSMStackOp::Set,
					ParamAttackModeType,
					ParamAttackTargetType,
					TargetPawn,
					ParamTargetTile,
					ParamMoveDestTile);
				ActionFSM->DoEvent(ToMoveToAttackEvent);*/
				UCWSkill* TempSkill = this->SkillManager->GetSkill(ParamSkillId);
				if (TempSkill == nullptr)
				{
					TempSkill = this->SkillManager->GetNormalAttack();
				}

				if (TempSkill != nullptr)
				{
					if (TempSkill->IsNormalAttack())
					{
						UCWPawnActionDataForNormalAttack* TempNormalAttackData = (UCWPawnActionDataForNormalAttack*)NewObject<UCWPawnActionDataForNormalAttack>();
						TempNormalAttackData->ActionId = ECWPawnActionState::NormalAttack;
						TempNormalAttackData->TargetTile = TargetTile;
						this->PutAction(TempNormalAttackData);
					}
					else
					{
						UCWPawnActionDataForCastSkill* TempCastSkillData = (UCWPawnActionDataForCastSkill*)NewObject<UCWPawnActionDataForCastSkill>();
						TempCastSkillData->ActionId = ECWPawnActionState::CastSkillToPawn;
						TempCastSkillData->TargetTile = TargetTile;
						TempCastSkillData->SkillId = ParamSkillId;
						this->PutAction(TempCastSkillData);
					}
				}

				UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::ServerRPCMoveToAttack_Implementation, ParamTargetTile:%d, ParamMoveDestTile:%d, ParamSkillId:%d."), ParamTargetTile, ParamMoveDestTile, ParamSkillId);

				NetMulticastRPCMoveToAttack(
					ParamSkillId,
					ParamTargetTile,
					ParamMoveDestTile);
			}
			/*else
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToAttack_Implementation Fail. TargetPawn == nullptr, ParamTargetTile:%d, ParamMoveDestTile:%d, ParamSkillId:%d."), ParamTargetTile, ParamMoveDestTile, ParamSkillId);
			}*/
		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCMoveToAttack_Implementation Fail. ParamMoveDestTile:%d, ParamSkillId:%d."), ParamMoveDestTile, ParamSkillId);
			NetMulticastRPCResetPawnInputState();
		}
	}
}

bool ACWPawn::ServerRPCMoveToAttack_Validate(
	int32 ParamSkillId,
	int ParamTargetTile,
	int ParamMoveDestTile)
{
	return true;
}

void ACWPawn::NetMulticastRPCMoveToAttack_Implementation(
	int32 ParamSkillId,
	int ParamTargetTile,
	int ParamMoveDestTile)
{
	if (IsInServer())
		return;

	if (!IsValidTile(ParamTargetTile))
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCMoveToAttack_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
		ResetInputStateInClient();
		return;
	}

	TargetTile = ParamTargetTile;
	MoveToDestTile = ParamMoveDestTile;
	
	/*ACWPawn* TargetPawn = nullptr;
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr &&
			TempPawn->GetTile() == ParamTargetTile)
		{
			TargetPawn = TempPawn;
			break;
		}
	}*/

	//if (TargetPawn != nullptr)
	{
		/*check(ActionFSM);
		FCWPawnActionToMoveToAttackEvent* ToMoveToAttackEvent = new FCWPawnActionToMoveToAttackEvent(
			(int)ECWPawnActionEvent::ToMoveToAttack,
			(int)ECWPawnActionState::MoveToAttack,
			ECWFSMStackOp::Set,
			ParamAttackModeType,
			ParamAttackTargetType,
			TargetPawn,
			ParamTargetTile,
			ParamMoveDestTile);
		ActionFSM->DoEvent(ToMoveToAttackEvent);*/

		UCWPawnActionDataForMoveToDest* TempMoveToDestData = (UCWPawnActionDataForMoveToDest*)NewObject<UCWPawnActionDataForMoveToDest>();
		TempMoveToDestData->ActionId = ECWPawnActionState::MoveToDest;
		TempMoveToDestData->DestTile = MoveToDestTile;
		this->PutAction(TempMoveToDestData);

		UCWSkill* TempSkill = this->SkillManager->GetSkill(ParamSkillId);
		if (TempSkill == nullptr)
		{
			TempSkill = this->SkillManager->GetNormalAttack();
		}

		if (TempSkill != nullptr)
		{
			if (TempSkill->IsNormalAttack())
			{
				UCWPawnActionDataForNormalAttack* TempNormalAttackData = (UCWPawnActionDataForNormalAttack*)NewObject<UCWPawnActionDataForNormalAttack>();
				TempNormalAttackData->ActionId = ECWPawnActionState::NormalAttack;
				TempNormalAttackData->TargetTile = TargetTile;
				this->PutAction(TempNormalAttackData);
			}
			else
			{
				UCWPawnActionDataForCastSkill* TempCastSkillData = (UCWPawnActionDataForCastSkill*)NewObject<UCWPawnActionDataForCastSkill>();
				TempCastSkillData->ActionId = ECWPawnActionState::CastSkillToPawn;
				TempCastSkillData->TargetTile = TargetTile;
				TempCastSkillData->SkillId = ParamSkillId;
				this->PutAction(TempCastSkillData);
			}

			UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NetMulticastRPCMoveToAttack_Implementation, TargetTile:%d, MoveToDestTile:%d, ParamSkillId:%d."), TargetTile, MoveToDestTile, ParamSkillId);


			/** 强制显示UI */
			ACWPawn* TargetPawn = nullptr;
			for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
			{
				ACWPawn* TempPawn = *Iter;
				if (TempPawn != nullptr &&
					TempPawn->GetTile() == ParamTargetTile)
				{
					TargetPawn = TempPawn;
					break;
				}
			}

			if (TargetPawn != nullptr)
			{
				TargetPawn->NotifyForceShowPawnUI();
			}
		}
		else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCMoveToAttack_Implementation Fail. TempSkill == nullptr, TargetTile:%d, MoveToDestTile:%d, ParamSkillId:%d."), TargetTile, MoveToDestTile, ParamSkillId);
			ResetInputStateInClient();
		}
	}
	/*else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCMoveToAttack_Implementation Fail. TargetPawn == nullptr, TargetTile:%d, MoveToDestTile:%d, ParamSkillId:%d."), TargetTile, MoveToDestTile, ParamSkillId);
	}*/
}

void ACWPawn::ServerRPCNormalAttackToTile_Implementation(int32 ParamTargetTile)
{
	if (IsInServer())
	{
		if (!IsValidTile(ParamTargetTile))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCNormalAttackToTile_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
			NetMulticastRPCResetPawnInputState();
			return;
		}

		TargetTile = ParamTargetTile;

		/*ACWPawn* TargetPawn = nullptr;
		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWPawn* TempPawn = *Iter;
			if (TempPawn != nullptr &&
				TempPawn->GetTile() == TargetTile)
			{
				TargetPawn = TempPawn;
				break;
			}
		}*/

		//if (TargetPawn != nullptr)
		{
			//TODO:需要判断攻击范围
			/*check(ActionFSM);
			FCWPawnActionToNormalAttackEvent* ToNormalAttackEvent = new FCWPawnActionToNormalAttackEvent((int)ECWPawnActionEvent::ToNormalAttack, (int)ECWPawnActionState::NormalAttack, ECWFSMStackOp::Set, TargetPawn);
			ActionFSM->DoEvent(ToNormalAttackEvent);*/
			UCWPawnActionDataForNormalAttack* TempNormalAttackData = (UCWPawnActionDataForNormalAttack*)NewObject<UCWPawnActionDataForNormalAttack>();
			TempNormalAttackData->ActionId = ECWPawnActionState::NormalAttack;
			TempNormalAttackData->TargetTile = TargetTile;
			this->PutAction(TempNormalAttackData);

			UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::ServerRPCNormalAttackToTile_Implementation, TargetTile:%d."), TargetTile);

			NetMulticastRPCNormalAttackToTile(TargetTile);
		}
		/*else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCNormalAttackToTile_Implementation Fail. TargetPawn == nullptr, TargetTile:%d."), TargetTile);
		}*/
	}
}

bool ACWPawn::ServerRPCNormalAttackToTile_Validate(
	int32 ParamTargetTile)
{
	return true;
}

void ACWPawn::NetMulticastRPCNormalAttackToTile_Implementation(int32 ParamTargetTile)
{
	if (IsInServer())
		return;

	if (!IsValidTile(ParamTargetTile))
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCNormalAttackToTile_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
		ResetInputStateInClient();
		return;
	}

	TargetTile = ParamTargetTile;

	/*ACWPawn* TargetPawn = nullptr;
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr &&
			TempPawn->GetTile() == ParamTargetTile)
		{
			TargetPawn = TempPawn;
			break;
		}
	}*/

	//if (TargetPawn != nullptr)
	{
		/*check(ActionFSM);
		FCWPawnActionToNormalAttackEvent* ToNormalAttackEvent = new FCWPawnActionToNormalAttackEvent((int)ECWPawnActionEvent::ToNormalAttack, (int)ECWPawnActionState::NormalAttack, ECWFSMStackOp::Set, TargetPawn);
		ActionFSM->DoEvent(ToNormalAttackEvent);*/
		UCWPawnActionDataForNormalAttack* TempNormalAttackData = (UCWPawnActionDataForNormalAttack*)NewObject<UCWPawnActionDataForNormalAttack>();
		TempNormalAttackData->ActionId = ECWPawnActionState::NormalAttack;
		TempNormalAttackData->TargetTile = TargetTile;
		this->PutAction(TempNormalAttackData);

		UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NetMulticastRPCNormalAttackToTile_Implementation, TargetTile:%d."), TargetTile);

		/** 强制显示UI */
		ACWPawn* TargetPawn = nullptr;
		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWPawn* TempPawn = *Iter;
			if (TempPawn != nullptr &&
				TempPawn->GetTile() == ParamTargetTile)
			{
				TargetPawn = TempPawn;
				break;
			}
		}

		if (TargetPawn != nullptr)
		{
			TargetPawn->NotifyForceShowPawnUI();
		}
	}
	/*else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCNormalAttackToTile_Implementation Fail. TargetPawn == nullptr, TargetTile:%d."), TargetTile);
	}*/
}

void ACWPawn::CounterAttackToTileInServer(int32 ParamTargetTile)
{
	if (IsInServer())
	{
		if (!IsValidTile(ParamTargetTile))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::CounterAttackToTileInServer Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
			//NetMulticastRPCResetPawnInputState();
			return;
		}

		TargetTile = ParamTargetTile;

		UCWPawnActionDataForCounterAttack* TempCounterAttackData = (UCWPawnActionDataForCounterAttack*)NewObject<UCWPawnActionDataForCounterAttack>();
		TempCounterAttackData->ActionId = ECWPawnActionState::CounterAttack;
		TempCounterAttackData->TargetTile = TargetTile;
		this->PutAction(TempCounterAttackData);

		UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::CounterAttackToTileInServer, TargetTile:%d."), TargetTile);

		NetMulticastRPCCounterAttackToTile(TargetTile);
	}
}

void ACWPawn::NetMulticastRPCCounterAttackToTile_Implementation(int32 ParamTargetTile)
{
	if (IsInServer())
		return;

	if (!IsValidTile(ParamTargetTile))
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCCounterAttackToTile_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
		ResetInputStateInClient();
		return;
	}

	TargetTile = ParamTargetTile;

	UCWPawnActionDataForCounterAttack* TempCounterAttackData = (UCWPawnActionDataForCounterAttack*)NewObject<UCWPawnActionDataForCounterAttack>();
	TempCounterAttackData->ActionId = ECWPawnActionState::CounterAttack;
	TempCounterAttackData->TargetTile = TargetTile;
	this->PutAction(TempCounterAttackData);

	UE_LOG(LogCWPawn, Log, TEXT("ACWPawn::NetMulticastRPCCounterAttackToTile_Implementation, TargetTile:%d."), TargetTile);
}


void ACWPawn::ServerRPCCastSkillToTile_Implementation(
	int ParamSkillId,
	int32 ParamTargetTile)
{
	if (IsInServer())
	{
		if (!IsValidTile(ParamTargetTile))
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCCastSkillToTile_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
			NetMulticastRPCResetPawnInputState();
			return;
		}

		TargetTile = ParamTargetTile;

		/*ACWPawn* TargetPawn = nullptr;
		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWPawn* TempPawn = *Iter;
			if (TempPawn != nullptr &&
				TempPawn->GetTile() == ParamTile)
			{
				TargetPawn = TempPawn;
				break;
			}
		}*/

		//if (TargetPawn != nullptr)
		{
			//TODO:需要判断攻击范围
			/*check(ActionFSM);
			FCWPawnActionToCastSkillToPawnEvent* ToCastSkillToPawnEvent = new FCWPawnActionToCastSkillToPawnEvent((int)ECWPawnActionEvent::ToCastSkillToPawn, (int)ECWPawnActionState::CastSkillToPawn, ECWFSMStackOp::Set, ParamSkillId, TargetPawn);
			ActionFSM->DoEvent(ToCastSkillToPawnEvent);*/
			UCWPawnActionDataForCastSkill* TempCastSkillData = (UCWPawnActionDataForCastSkill*)NewObject<UCWPawnActionDataForCastSkill>();
			TempCastSkillData->ActionId = ECWPawnActionState::CastSkillToPawn;
			TempCastSkillData->TargetTile = TargetTile;
			TempCastSkillData->SkillId = ParamSkillId;
			this->PutAction(TempCastSkillData);

			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCCastSkillToTile_Implementation, TargetTile:%d."), TargetTile);

			NetMulticastRPCCastSkillToTile(ParamSkillId, TargetTile);
		}
		/*else
		{
			UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::ServerRPCCastSkillToTile_Implementation Fail. TargetPawn == nullptr, TargetTile:%d."), TargetTile);
		}*/
	}
}

bool ACWPawn::ServerRPCCastSkillToTile_Validate(
	int ParamSkillId,
	int32 ParamTile)
{
	return true;
}

void ACWPawn::NetMulticastRPCCastSkillToTile_Implementation(
	int ParamSkillId,
	int32 ParamTargetTile)
{
	if (IsInServer())
		return;

	if (!IsValidTile(ParamTargetTile))
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCCastSkillToTile_Implementation Fail. ParamTargetTile is not Valid, ParamTargetTile:%d."), ParamTargetTile);
		ResetInputStateInClient();
		return;
	}

	TargetTile = ParamTargetTile;

	/*ACWPawn* TargetPawn = nullptr;
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		if (TempPawn != nullptr &&
			TempPawn->GetTile() == TargetTile)
		{
			TargetPawn = TempPawn;
			break;
		}
	}*/

	//if (TargetPawn != nullptr)
	{
		/*check(ActionFSM);
		FCWPawnActionToCastSkillToPawnEvent* ToCastSkillToPawnEvent = new FCWPawnActionToCastSkillToPawnEvent((int)ECWPawnActionEvent::ToCastSkillToPawn, (int)ECWPawnActionState::CastSkillToPawn, ECWFSMStackOp::Set, ParamSkillId, TargetPawn);
		ActionFSM->DoEvent(ToCastSkillToPawnEvent);*/
		UCWPawnActionDataForCastSkill* TempCastSkillData = (UCWPawnActionDataForCastSkill*)NewObject<UCWPawnActionDataForCastSkill>();
		TempCastSkillData->ActionId = ECWPawnActionState::CastSkillToPawn;
		TempCastSkillData->TargetTile = TargetTile;
		TempCastSkillData->SkillId = ParamSkillId;
		this->PutAction(TempCastSkillData);

		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCCastSkillToTile_Implementation, TargetTile:%d."), TargetTile);

		/** 强制显示UI */
		ACWPawn* TargetPawn = nullptr;
		for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWPawn* TempPawn = *Iter;
			if (TempPawn != nullptr &&
				TempPawn->GetTile() == TargetTile)
			{
				TargetPawn = TempPawn;
				break;
			}
		}

		if (TargetPawn != nullptr)
		{
			TargetPawn->NotifyForceShowPawnUI();
		}
	}
	/*else
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::NetMulticastRPCCastSkillToTile_Implementation Fail. TargetPawn == nullptr, TargetTile:%d."), TargetTile);
	}*/
}

void ACWPawn::NetMulticastRPCResetPawnInputState_Implementation()
{
	if (IsInServer())
		return;

	ResetInputStateInClient();
}

void ACWPawn::ServerRPCActionEnd_Implementation()
{
	if (IsInServer())
	{
		/*check(ActionFSM);
		ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
		FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, true, false);
		ActionFSM->DoEvent(ToEndEvent);*/

		ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
		UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
		TempEndData->ActionId = ECWPawnActionState::End;
		TempEndData->OldActionState = TempCurActionState;
		TempEndData->bIsTriggerEvent = true;
		TempEndData->bIsForceToEnd = false;
		this->PutAction(TempEndData);

		NetMulticastRPCActionEnd();
	}
}

bool ACWPawn::ServerRPCActionEnd_Validate()
{
	return true;
}


void ACWPawn::NetMulticastRPCActionEnd_Implementation()
{
	if (IsInServer())
		return;

	/*check(ActionFSM);
	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionFSM()->GetCurrentStateId());
	FCWPawnActionToEndEvent* ToEndEvent = new FCWPawnActionToEndEvent((int)ECWPawnActionEvent::ToEnd, (int)ECWPawnActionState::End, ECWFSMStackOp::Set, TempCurActionState, false, false);
	ActionFSM->DoEvent(ToEndEvent);*/
	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
	UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
	TempEndData->ActionId = ECWPawnActionState::End;
	TempEndData->OldActionState = TempCurActionState;
	TempEndData->bIsTriggerEvent = false;
	TempEndData->bIsForceToEnd = false;
	this->PutAction(TempEndData);

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	check(MyPlayerController);
	MyPlayerController->CancelCurSelectedPawnInClient();

	if (IsMyClientPawn())
	{
		FCWPawnInputActionFinishEvent* InputActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		this->InputFSM->DoEvent(InputActionFinishEvent);
	}
}

void ACWPawn::ForceActionEndInServer()
{
	/*ECWPawnActionState CurStateId = (ECWPawnActionState)(this->ActionFSM->GetCurrentStateId());
	FCWPawnActionForceToEndEvent* ActionForceToEndEvent = new FCWPawnActionForceToEndEvent((int)ECWPawnActionEvent::ForceToEnd, (int)CurStateId, ECWFSMStackOp::Set, CurStateId);
	this->ActionFSM->DoEvent(ActionForceToEndEvent);*/

	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
	UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
	TempEndData->ActionId = ECWPawnActionState::End;
	TempEndData->OldActionState = TempCurActionState;
	TempEndData->bIsTriggerEvent = true;
	TempEndData->bIsForceToEnd = true;
	this->PutAction(TempEndData);

	NetMulticastRPCForceActionEnd();
}

void ACWPawn::NetMulticastRPCForceActionEnd_Implementation()
{
	if (IsInServer())
		return;

	/*ECWPawnActionState CurStateId = (ECWPawnActionState)(this->ActionFSM->GetCurrentStateId());
	FCWPawnActionForceToEndEvent* ActionForceToEndEvent = new FCWPawnActionForceToEndEvent((int)ECWPawnActionEvent::ForceToEnd, (int)CurStateId, ECWFSMStackOp::Set, CurStateId);
	this->ActionFSM->DoEvent(ActionForceToEndEvent);*/

	ECWPawnActionState TempCurActionState = (ECWPawnActionState)(this->GetActionComponent()->GetCurState());
	UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
	TempEndData->ActionId = ECWPawnActionState::End;
	TempEndData->OldActionState = TempCurActionState;
	TempEndData->bIsTriggerEvent = false;
	TempEndData->bIsForceToEnd = false;
	this->PutAction(TempEndData);

	if (IsMyClientPawn())
	{
		FCWPawnInputActionFinishEvent* InputActionFinishEvent = new FCWPawnInputActionFinishEvent((int)ECWPawnInputEvent::TurnActionFinish, (int)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		this->InputFSM->DoEvent(InputActionFinishEvent);
	}

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	check(MyPlayerController);
	MyPlayerController->ForceActionEndInClient();
}

void ACWPawn::NetMulticastRPCPawnBeHit_Implementation(
	ECWCampTag ParamPawnCampTag,
	ECWCampControllerIndex ParamPawnCampControllerIndex,
	int32 ParamPawnControllerPawnIndex,
	int32 ParamSkillId,
	bool ParamIsCounterAttack)
{
	if (IsInServer())
		return;

	this->BeHitInClient(ParamPawnCampTag, ParamPawnCampControllerIndex, ParamPawnControllerPawnIndex, ParamSkillId, ParamIsCounterAttack);
}

void ACWPawn::NetMulticastRPCPawnDie_Implementation()
{
	if (IsInServer())
		return;

	this->DieInClient();
}

void ACWPawn::NetMulticastRPCPawnDeath_Implementation()
{
	if (IsInServer())
		return;

	this->DeathInClient();
}

ACWMapTile* ACWPawn::GetMapTileByTile(int ParamTile)
{
	for (TActorIterator<ACWMapTile> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWMapTile* MyMapTile = *Iter;
		check(MyMapTile);
		if (MyMapTile->Tile == ParamTile)
		{
			return MyMapTile;
		}
	}

	return nullptr;
}

FCWPathExplorer& ACWPawn::GetPathExplorer()
{
	return PathExplorer;
}

ACWRandomDungeonGenerator* ACWPawn::GetDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(GetWorld());
}

ACWDungeonTile* ACWPawn::GetDungeonTile(int ParamTile)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator != nullptr)
	{
		ACWDungeonTile* TempDungeonTile = TempDungeonGenerator->GetDungeonTile(ParamTile);
		if (TempDungeonTile != nullptr)
		{
			return TempDungeonTile;
		}
	}

	return nullptr;
}

float ACWPawn::GetDungeonTileZ(int32 ParamTile)
{
	ACWRandomDungeonGenerator* TempDungeonGenerator = GetDungeonGenerator();
	if (TempDungeonGenerator != nullptr)
	{
		ACWDungeonTile* TempDungeonTile = TempDungeonGenerator->GetDungeonTile(ParamTile);
		if (TempDungeonTile != nullptr)
		{
			return TempDungeonTile->GetActorLocation().Z;
		}
	}
	//UE_LOG(LogCWPawn, Warning, TEXT("attention：ACWPawn::GetDungeonTileZ, TempDungeonTile == nullptr, ParamTile:%d."), ParamTile);
	return 10000.0f;
}

void ACWPawn::OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType)
{
	if (!IsInServer())
		return;

	if (ECWKeyTimeType::PawnActionEnd == ParamKeyTimeType)
	{	// 行为结束,检测拾取Buff
		CheckOverlapPickupBuff();
	}

	check(BuffManager);
	BuffManager->OnKeyTimeInServer(ParamKeyTimeType);

	check(BattleProperty);
	float CurMyHealth = BattleProperty->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
	if (CurMyHealth <= 0.0f)
	{
		this->DieInServer();
	}
}

bool ACWPawn::IsSameKeyTime(ECWKeyTimeType ParamKeyTimeType1, ECWKeyTimeType ParamKeyTimeType2)
{
	if (ParamKeyTimeType1 == ParamKeyTimeType2)
	{
		return true;
	}
	else
	{
		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackBegin)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackBegin ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillBegin)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackEnd)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackEnd ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillEnd)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage01)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage02)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackDamage03)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeAttackAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackAllDamage ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillAllDamage)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::NormalAttackAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::NormalAttackAllDamage)
			{
				return true;
			}
		}

		if (ParamKeyTimeType1 == ECWKeyTimeType::InitiativeSkillAllDamage)
		{
			if (ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage01 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage02 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillDamage03 ||
				ParamKeyTimeType2 == ECWKeyTimeType::InitiativeSkillAllDamage)
			{
				return true;
			}
		}

		return false;
	}
}

UCWPawnBattlePropertyComponent* ACWPawn::GetBattleProperty() const
{
	return BattleProperty;
}

UCWSkillManager* ACWPawn::GetSkillManager()
{
	return SkillManager;
}

UCWBuffManager* ACWPawn::GetBuffManager()
{
	return BuffManager;
}

TArray<FUIBuffNodeData> ACWPawn::GetBuffListInfo()
{
	TArray<FUIBuffNodeData> OutList;
	if (IsValid(BuffManager))
	{
		BuffManager->GetBuffInfoList(OutList);
	}
	return OutList;
}

void ACWPawn::CheckOverlapPickupBuff()
{
	if (!IsPawnType(ECWPawnType::Character))
	{
		return;
	}

	ACWRandomDungeonGenerator* DungeonGenerator = GetDungeonGenerator();
	if (nullptr != DungeonGenerator)
	{
		const int32 MyTile = GetTile();
		const TArray<ACWDungeonItem*>& BuffObjects = DungeonGenerator->GetAllBuffObjects(MyTile);
		for (int32 i = 0; i < BuffObjects.Num(); ++i)
		{
			ACWDungeonItem* DungeonItem = BuffObjects[i];
			if (nullptr != DungeonItem && DungeonItem->IsBuffObject())
			{
				DungeonItem->CheckOverlapPickup(this);
			}
		}
	}
}

void ACWPawn::SetLongDown(bool ParamIsLongDown)
{
	bIsLongDown = ParamIsLongDown;
}

bool ACWPawn::IsLongDown() const
{
	return bIsLongDown;
}

bool ACWPawn::NormalAttackToPawn(ACWPawn* ParamTargetPawn)
{
	check(SkillManager);
	return SkillManager->NormalAttackToPawn(ParamTargetPawn);
}

bool ACWPawn::NormalAttackToTile(int32 ParamTile)
{
	check(SkillManager);
	return SkillManager->NormalAttackToTile(ParamTile);
}

bool ACWPawn::CounterAttackToTile(int32 ParamTile)
{
	check(SkillManager);
	return SkillManager->CounterAttackToTile(ParamTile);
}

bool ACWPawn::CastSkillToPawn(int32 ParamSkillId, ACWPawn* ParamTargetPawn)
{
	check(SkillManager);
	return SkillManager->CastSkillToPawn(ParamSkillId, ParamTargetPawn);
}

bool ACWPawn::CastSkillToTile(int32 ParamSkillId, int ParamTile)
{
	check(SkillManager);
	return SkillManager->CastSkillToTile(ParamSkillId, ParamTile);
}

void ACWPawn::SetRoundIndexWhenAction(int ParamRoundIndexWhenCastSkill)
{
	RoundIndexWhenAction = ParamRoundIndexWhenCastSkill;
}

int ACWPawn::GetRoundIndexWhenAction() const
{
	return RoundIndexWhenAction;
}

void ACWPawn::SetSkillIdWhenCastSkill(int ParamSkillIdWhenCastSkill)
{
	SkillIdWhenCastSkill = ParamSkillIdWhenCastSkill;
}

int ACWPawn::GetSkillIdWhenCastSkill() const
{
	return SkillIdWhenCastSkill;
}

void ACWPawn::SetIsCounterAttackWhenCastSkill(int ParamIsCounterAttackWhenCastSkill)
{
	bIsCounterAttackWhenCastSkill = ParamIsCounterAttackWhenCastSkill;
}
int ACWPawn::IsCounterAttackWhenCastSkill() const
{
	return bIsCounterAttackWhenCastSkill;
}

void ACWPawn::SetDamageIndexWhenCastSkill(int ParamDamageIndexWhenCastSkill)
{
	DamageIndexWhenCastSkill = ParamDamageIndexWhenCastSkill;
}

int ACWPawn::GetDamageIndexWhenCastSkill() const
{
	return DamageIndexWhenCastSkill;
}

ECWPawnType ACWPawn::GetPawnType() const
{
	return PawnType;
}

bool ACWPawn::IsPawnType(const ECWPawnType InType) const
{
	return InType == PawnType;
}

int8 ACWPawn::GetBattleDistType() const
{
	if (IsPawnType(ECWPawnType::Character))
	{
		if (const FCWProfessionDataStruct* ProfessionData = GetProfessionData())
		{
			return ProfessionData->BattleDistType;
		}
	}
	return INDEX_NONE;
}

void ACWPawn::ReceiveWeatherAffect()
{
	if (!IsPawnType(ECWPawnType::Character))
	{
		return;
	}

	ACWGameState* MyGS = GetGameState<ACWGameState>();
	UCWPawnBattlePropertyComponent* PawnPropertyComp = GetBattleProperty();
	if (nullptr == PawnPropertyComp || IsNetMode(NM_Client) || !IsInServer() ||
		nullptr == MyGS || MyGS->GetWeatherIdx() < 0)
	{
		CWG_WARNING(">>> %s::ReceiveWeatherAffect, weather idx[%d] is invalid!", *GetName(), MyGS->GetWeatherIdx());
		return;
	}

	int32 WeatherIdx = MyGS->GetWeatherIdx();
	int32 OldWeatherIdx = MyGS->GetOldWeatherIdx();
	const int8 BattleDistType = GetBattleDistType();
	if (WeatherIdx != OldWeatherIdx && BattleDistType > INDEX_NONE)
	{
		const FCWWeatherData* CurWeatherData = FCWCfgUtils::GetWeatherData(this, WeatherIdx);
		const FCWWeatherData* OldWeatherData = FCWCfgUtils::GetWeatherData(this, OldWeatherIdx);

		FCWWeatherAffectData EmptyData, Affect;
		if (BattleDistType == 0)
		{
			Affect += CurWeatherData ? CurWeatherData->MeleeAffect : EmptyData;
			Affect -= OldWeatherData ? OldWeatherData->MeleeAffect : EmptyData;
		}
		if (BattleDistType == 1)
		{
			Affect += CurWeatherData ? CurWeatherData->RangedAffect : EmptyData;
			Affect -= OldWeatherData ? OldWeatherData->RangedAffect : EmptyData;
		}

		// 修改战斗基础属性
		auto ModifyBaseProperty = [PawnPropertyComp](const ECWBattleProperty InType, const float InModifyValue)
		{
			if (nullptr != PawnPropertyComp && InModifyValue != 0.0f)
			{
				FCWBattlePropertyModifier Modifier(InType, ECWBattlePropertyModifyOp::Add_Param1, InModifyValue, 0.0f, 10000.0f);
				PawnPropertyComp->GetCurPropertySet().ModifyProperty(Modifier);
			}
		};
		ModifyBaseProperty(ECWBattleProperty::Attack, Affect.AttackValue);
		ModifyBaseProperty(ECWBattleProperty::PhysicalDefence, Affect.DefenceValue);
		ModifyBaseProperty(ECWBattleProperty::MagicDefence, Affect.DefenceValue);
		ModifyBaseProperty(ECWBattleProperty::Talent, Affect.TalentValue);
		ModifyBaseProperty(ECWBattleProperty::Move, Affect.MoveValue);
	}
}

int ACWPawn::GetUniqueIdForLogic() const
{
	return (int)CampTag * 1000000 + (int)ControllerIndex * 1000 + (int)PawnIndex;
}

void ACWPawn::DoFallInServer()
{
	if (!IsInServer())
		return;

	bIsDoFall = true;

	DieInServer();

	NetMulticastRPCDoFall();
}

void ACWPawn::NetMulticastRPCDoFall_Implementation()
{
	if (IsInServer())
		return;

	bIsDoFall = true;
}

void ACWPawn::FallingInServer(float DeltaTime)
{
	if (!IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
	TotalFallTime += DeltaTime;

	if (TotalFallTime >= FALL_TIME)
	{
		ACWPlayerController* TempPlayerController = Cast<ACWPlayerController>(this->GetParantController());
		if (TempPlayerController != nullptr)
		{
			//TempPlayerController->Die
		}
	}
}

void ACWPawn::FallingInClient(float DeltaTime)
{
	if (IsInServer())
		return;

	CurFallSpeed = CurFallSpeed + 9.8f * DeltaTime;
	FVector TempLocation = GetActorLocation();
	TempLocation = FVector(TempLocation.X, TempLocation.Y, TempLocation.Z - CurFallSpeed);
	SetActorLocation(TempLocation);
}

bool ACWPawn::IsDieOrDeath() const
{
	ECWPawnActionState CurActionFSMStateId = this->GetCurActionStateId();
	if (CurActionFSMStateId == ECWPawnActionState::Die ||
		CurActionFSMStateId == ECWPawnActionState::Death)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPawn::IsMoveTile(int ParamTile)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return false;

	if (!RefreshMoveAttackDamageTile(this->GetTile(), false))
	{
		return false;
	}

	uint8 TempMoveAttackDamage = MyMap->GetMoveAttackDamage(ParamTile);
	if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Move) > 0)
	{
		return true;
	}

	return false;
}

bool ACWPawn::IsAttackTileFromTile(int ParamCurTile, int ParamAttackTile, uint8 ParamMoveAttackDamage)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return false;

	if (!RefreshAttackDamageTile(ParamCurTile))
	{
		return false;
	}

	uint8 TempMoveAttackDamage = MyMap->GetMoveAttackDamage(ParamAttackTile);
	if ((TempMoveAttackDamage & ParamMoveAttackDamage) > 0)
	{
		return true;
	}
	
	return false;
}

bool ACWPawn::RefreshAttackDamageTile(int ParamCurTile)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return false;

	if (ParamCurTile == -1)
		return false;

	UCWSkill* TempSkill = GetAutoSelectSkillRecord();

	if (TempSkill == nullptr)
		return false;

	//数据重置
	MyMap->ResetArrayMoveAttackDamage();

	CWPEGrid TempMoveGrid(ParamCurTile);
	MyMap->SetMoveAttackDamage(ParamCurTile, (uint8)ECWMapTileMoveAttackDamageType::Move);

	std::vector<int32> AttackRangeParams = FCWSkillDataUtils::GetArrayAttackRangeParamsFromString(TempSkill->GetSkillDataStruct()->AttackRangeParams);
	if (TempSkill->GetSkillDataStruct()->AttackRangeType == 1 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		std::list<int> listAttactGrid;
		CWPEGrid MyGrid = TempMoveGrid;
		int ccx = -1;
		int ccy = -1;
		ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
		int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
		int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
		int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
		int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
		for (int y = beginMoveY; y <= endMoveY; ++y)
		{
			for (int x = beginMoveX; x <= endMoveX; ++x)
			{
				if (x == ccx && y == ccy)
					continue;

				if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) > to)
					continue;

				if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) < from)
					continue;

				bool isTherePawn = false;
				bool isEnemy = false;
				bool isPartner = false;
				int WantAttackTile = ACWMap::xy2tile(x, y);
				if (MyMap->isTherePawn(WantAttackTile))
				{
					isTherePawn = true;
					if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
					{
						isEnemy = true;
					}
					if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
					{
						isPartner = true;
					}
				}

				//if (isTherePawn && !isEnemy)
				//	continue;

				bool isMoveTile = false;
				//for (std::list<CWPEGrid>::iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
				{
					if (TempMoveGrid.tile == WantAttackTile)
					{
						isMoveTile = true;
						//break;
					}
				}

				//if (!isTherePawn && isMoveTile)
				//	continue;

				//if (isTherePawn && !isEnemy && isMoveTile)
				//	continue;

				if (isTherePawn && isPartner)
				{
					//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
				}
				else if (isTherePawn && !isEnemy)
				{

				}
				else
				{
					MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);
				}
			}
		}

		return true;
	}
	if (TempSkill->GetSkillDataStruct()->AttackRangeType == 2 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		std::list<int> listAttactGrid;
		CWPEGrid MyGrid = TempMoveGrid;
		int ccx = -1;
		int ccy = -1;
		ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
		int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
		int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
		int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
		int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
		for (int y = beginMoveY; y <= endMoveY; ++y)
		{
			for (int x = beginMoveX; x <= endMoveX; ++x)
			{
				if (x == ccx && y == ccy)
					continue;

				if (FMath::Abs(x - ccx) > to)
					continue;

				if (FMath::Abs(y - ccy) > to)
					continue;

				if (!((FMath::Abs(x - ccx) + FMath::Abs(y - ccy) >= from) && (FMath::Abs(x - ccx) >= from || FMath::Abs(y - ccy) >= from)))
					continue;

				bool isTherePawn = false;
				bool isEnemy = false;
				bool isPartner = false;
				int WantAttackTile = ACWMap::xy2tile(x, y);
				if (MyMap->isTherePawn(WantAttackTile))
				{
					isTherePawn = true;
					if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
					{
						isEnemy = true;
					}
					if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
					{
						isPartner = true;
					}
				}

				//if (isTherePawn && !isEnemy)
				//	continue;

				bool isMoveTile = false;
				//for (std::list<CWPEGrid>::iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
				{
					if (TempMoveGrid.tile == WantAttackTile)
					{
						isMoveTile = true;
						//break;
					}
				}

				//if (!isTherePawn && isMoveTile)
				//	continue;

				//if (isTherePawn && !isEnemy && isMoveTile)
				//	continue;

				if (isTherePawn && isPartner)
				{
					//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
				}
				else if (isTherePawn && !isEnemy)
				{

				}
				else
				{
					MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);
				}
			}
		}

		return true;
	}
	else if (TempSkill->GetSkillDataStruct()->AttackRangeType == 3 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		std::list<CWAttackGrid> listAttackGrid;
		std::list<int> listAttactGrid;
		CWPEGrid MyGrid = TempMoveGrid;
		int ccx = -1;
		int ccy = -1;
		ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
		int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
		int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
		int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
		int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
		for (int y = beginMoveY; y <= endMoveY; ++y)
		{
			for (int x = beginMoveX; x <= endMoveX; ++x)
			{
				if (x == ccx && y == ccy)
					continue;

				if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) > to)
					continue;

				if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) < from)
					continue;

				if (!((FMath::Abs(x - ccx) >= from && FMath::Abs(y - ccy) == 0) || (FMath::Abs(x - ccx) == 0 && FMath::Abs(y - ccy) >= from)))
					continue;

				bool isTherePawn = false;
				bool isEnemy = false;
				bool isPartner = false;
				int WantAttackTile = ACWMap::xy2tile(x, y);
				if (MyMap->isTherePawn(WantAttackTile))
				{
					isTherePawn = true;
					if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
					{
						isEnemy = true;
					}
					if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
					{
						isPartner = true;
					}
				}

				//if (isTherePawn && !isEnemy)
				//	continue;

				bool isMoveTile = false;
				//for (std::list<CWPEGrid>::iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
				{
					if (TempMoveGrid.tile == WantAttackTile)
					{
						isMoveTile = true;
						//break;
					}
				}

				//if (!isTherePawn && isMoveTile)
				//	continue;

				//if (isTherePawn && !isEnemy && isMoveTile)
				//	continue;

				//if (isTherePawn && isPartner)
				//{
				//	//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
				//}
				//else if (isTherePawn && !isEnemy)
				//{

				//}
				//else
				{
					MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);

					ECWAffectDirType TempDir = MyMap->GetAffectDir(MyGrid.tile, WantAttackTile);
					if (TempDir != ECWAffectDirType::None)
					{
						MyMap->SetVectorAttackGrid(WantAttackTile, MyGrid.tile, TempDir, (uint8)ECWMapTileMoveAttackDamageType::Attack);

						CWAttackGrid TempAttackGrid;
						TempAttackGrid.Tile = WantAttackTile;
						TempAttackGrid.PawnTile = MyGrid.tile;
						TempAttackGrid.Dir = (uint8)TempDir;
						TempAttackGrid.MAD = (uint8)ECWMapTileMoveAttackDamageType::Attack;

						bool TempIsFindInListAttackGrid = false;
						for (std::list<CWAttackGrid>::iterator iter2 = listAttackGrid.begin(); iter2 != listAttackGrid.end(); ++iter2)
						{
							CWAttackGrid& TempGrid = *iter2;
							if (TempAttackGrid == TempGrid)
							{
								TempIsFindInListAttackGrid = true;
								break;
							}
						}

						if (!TempIsFindInListAttackGrid)
						{
							listAttackGrid.push_back(TempAttackGrid);
						}
					}
					else
					{
						UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshMoveAttackDamageTile, TempDir == ECWAffectDirType::None, MyGrid.tile:%d, WantAttackTile:%d."), MyGrid.tile, WantAttackTile);
					}
				}
			}
		}

		for (std::list<CWAttackGrid>::iterator iter = listAttackGrid.begin(); iter != listAttackGrid.end(); ++iter)
		{
			CWAttackGrid TempAttackGrid = *iter;

			if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Right)
			{
				std::vector<std::vector<int32> > TempDamageRangeRight = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeRight);
				std::vector<int32> TempDamageCenterRight = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterRight);
				if (TempDamageCenterRight.size() != 2)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshMoveAttackDamageTile, TempDamageCenterRight.size() != 2, TempDamageCenterRight.size():%d."), TempDamageCenterRight.size());
					return false;
				}
				int32 TempBaseX_Right = TempDamageCenterRight[0];
				int32 TempBaseY_Right = TempDamageCenterRight[1];
				FVector attack_pos = FVector::ZeroVector;
				ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
				for (int y = 0; y < TempDamageRangeRight.size(); ++y)
				{
					for (int x = 0; x < TempDamageRangeRight[y].size(); ++x)
					{
						int32 TempDamage = TempDamageRangeRight[y][x];
						if (TempDamage == 0)
							continue;

						int ox = x - TempBaseX_Right;
						int oy = y - TempBaseY_Right;

						float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
						float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

						int real_x = -1;
						int real_y = -1;
						FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
						ACWMap::pos2xy(real_pos, real_x, real_y);

						if (real_x < 0 || real_x >= MyMap->getWidth())
							continue;

						if (real_y < 0 || real_y >= MyMap->getHeight())
							continue;

						int real_tile = ACWMap::xy2tile(real_x, real_y);
						MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					}
				}
			}
			else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Up)
			{
				std::vector<std::vector<int32> > TempDamageRangeUp = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeUp);
				std::vector<int32> TempDamageCenterUp = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterUp);
				if (TempDamageCenterUp.size() != 2)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshMoveAttackDamageTile, TempDamageCenterUp.size() != 2, TempDamageCenterUp.size():%d."), TempDamageCenterUp.size());
					return false;
				}
				int32 TempBaseX_Up = TempDamageCenterUp[0];
				int32 TempBaseY_Up = TempDamageCenterUp[1];
				FVector attack_pos = FVector::ZeroVector;
				ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
				for (int y = 0; y < TempDamageRangeUp.size(); ++y)
				{
					for (int x = 0; x < TempDamageRangeUp[y].size(); ++x)
					{
						int32 TempDamage = TempDamageRangeUp[y][x];
						if (TempDamage == 0)
							continue;

						int ox = x - TempBaseX_Up;
						int oy = y - TempBaseY_Up;

						float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
						float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

						int real_x = -1;
						int real_y = -1;
						FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
						ACWMap::pos2xy(real_pos, real_x, real_y);

						if (real_x < 0 || real_x >= MyMap->getWidth())
							continue;

						if (real_y < 0 || real_y >= MyMap->getHeight())
							continue;

						int real_tile = ACWMap::xy2tile(real_x, real_y);
						MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					}
				}
			}
			else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Left)
			{
				std::vector<std::vector<int32> > TempDamageRangeLeft = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeLeft);
				std::vector<int32> TempDamageCenterLeft = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterLeft);
				if (TempDamageCenterLeft.size() != 2)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshMoveAttackDamageTile, TempDamageCenterLeft.size() != 2, TempDamageCenterLeft.size():%d."), TempDamageCenterLeft.size());
					return false;
				}
				int32 TempBaseX_Left = TempDamageCenterLeft[0];
				int32 TempBaseY_Left = TempDamageCenterLeft[1];
				FVector attack_pos = FVector::ZeroVector;
				ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
				for (int y = 0; y < TempDamageRangeLeft.size(); ++y)
				{
					for (int x = 0; x < TempDamageRangeLeft[y].size(); ++x)
					{
						int32 TempDamage = TempDamageRangeLeft[y][x];
						if (TempDamage == 0)
							continue;

						int ox = x - TempBaseX_Left;
						int oy = y - TempBaseY_Left;

						float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
						float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

						int real_x = -1;
						int real_y = -1;
						FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
						ACWMap::pos2xy(real_pos, real_x, real_y);

						if (real_x < 0 || real_x >= MyMap->getWidth())
							continue;

						if (real_y < 0 || real_y >= MyMap->getHeight())
							continue;

						int real_tile = ACWMap::xy2tile(real_x, real_y);
						MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					}
				}
			}
			else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Down)
			{
				std::vector<std::vector<int32> > TempDamageRangeDown = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeDown);
				std::vector<int32> TempDamageCenterDown = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterDown);
				if (TempDamageCenterDown.size() != 2)
				{
					UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshMoveAttackDamageTile, TempDamageCenterDown.size() != 2, TempDamageCenterDown.size():%d."), TempDamageCenterDown.size());
					return false;
				}
				int32 TempBaseX_Down = TempDamageCenterDown[0];
				int32 TempBaseY_Down = TempDamageCenterDown[1];
				FVector attack_pos = FVector::ZeroVector;
				ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
				for (int y = 0; y < TempDamageRangeDown.size(); ++y)
				{
					for (int x = 0; x < TempDamageRangeDown[y].size(); ++x)
					{
						int32 TempDamage = TempDamageRangeDown[y][x];
						if (TempDamage == 0)
							continue;

						int ox = x - TempBaseX_Down;
						int oy = y - TempBaseY_Down;

						float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
						float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

						int real_x = -1;
						int real_y = -1;
						FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
						ACWMap::pos2xy(real_pos, real_x, real_y);

						if (real_x < 0 || real_x >= MyMap->getWidth())
							continue;

						if (real_y < 0 || real_y >= MyMap->getHeight())
							continue;

						int real_tile = ACWMap::xy2tile(real_x, real_y);
						MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
						MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					}
				}
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPawn::IsMoveAttackTileFromTile(int ParamCurTile, int ParamAttackTile, uint8 ParamMoveAttackDamage)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return false;

	if (!RefreshMoveAttackDamageTile(ParamCurTile, false))
	{
		return false;
	}

	uint8 TempMoveAttackDamage = MyMap->GetMoveAttackDamage(ParamAttackTile);
	if ((TempMoveAttackDamage & ParamMoveAttackDamage) > 0)
	{
		return true;
	}

	return false;
}

bool ACWPawn::IsAttackTileFromTileForNormalAttack(int ParamCurTile, int ParamAttackTile, uint8 ParamMoveAttackDamage)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return false;

	if (!RefreshAttackDamageTile(ParamCurTile, true))
	{
		return false;
	}

	uint8 TempMoveAttackDamage = MyMap->GetMoveAttackDamage(ParamAttackTile);
	if ((TempMoveAttackDamage & ParamMoveAttackDamage) > 0)
	{
		return true;
	}

	return false;
}

bool ACWPawn::RefreshMoveAttackDamageTile(int ParamCurTile, bool ParamIsNormalAttack)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. ParamCurTile == -1."));
		return false;
	}

	if (ParamCurTile == -1)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. ParamCurTile == -1."));
		return false;
	}

	UCWSkill* TempSkill = nullptr;
	if (ParamIsNormalAttack)
	{
		TempSkill = SkillManager->GetNormalAttack();
	}
	else
	{
		TempSkill = GetAutoSelectSkillRecord();
	}

	if (TempSkill == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. TempSkill == nullptr."));
		return false;
	}

	//数据重置
	MyMap->ResetArrayMoveAttackDamage();
	MyMap->ResetVectorAttack();
	MyMap->ResetVectorDamage();

	std::list<CWPEGrid> listMoveGrid;
	GenerateMoveTile(ParamCurTile, listMoveGrid);

	std::list<CWAttackGrid> listAttackGrid;
	GenerateAttackTile(TempSkill, listMoveGrid, listAttackGrid);

	GenerateDamageTile(TempSkill, listAttackGrid);

	return true;
}

bool ACWPawn::GenerateMoveTile(int ParamCurTile, std::list<CWPEGrid>& listMoveGrid)
{
	listMoveGrid.clear();

	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateMoveTile. MyMap == nullptr."));
		return false;
	}

	//数据重置
	MyMap->ResetArrayMoveAttackDamage();

	const FCWBattlePropertySet& CurVProperty = BattleProperty->GetCurPropertySet();
	float MoveValue = CurVProperty.GetPropertyByFloat(ECWBattleProperty::Move);
	int move = (int)MoveValue;
	int cx = 0;
	int cy = 0;
	ACWMap::tile2xy(ParamCurTile, cx, cy);
	FVector curPos;
	ACWMap::xy2pos(cx, cy, curPos);
	int beginX = cx - move < 0 ? 0 : cx - move;
	int endX = cx + move >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + move;
	int beginY = cy - move < 0 ? 0 : cy - move;
	int endY = cy + move >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + move;
	for (int y = beginY; y <= endY; ++y)
	{
		for (int x = beginX; x <= endX; ++x)
		{
			if (x == cx && y == cy)
			{
				//格子的棋子是自己
				int dt = ACWMap::xy2tile(x, y);
				CWPEGrid tg(dt);
				listMoveGrid.push_back(tg);

				MyMap->SetMoveAttackDamage(tg.tile, (uint8)ECWMapTileMoveAttackDamageType::Move);
				continue;
			}

			if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > move)
				continue;

			int destTile = ACWMap::xy2tile(x, y);
			if (MyMap->isTherePawn(destTile))
				continue;

			if (MyMap->canPass(destTile, this) && MyMap->CanMove(destTile, this->GetFindPathInfo()))
			{
				FCWPathExplorer PE;
				PE.Reset();
				PE.SetPos(curPos);
				FVector destPos;
				ACWMap::tile2pos(destTile, destPos);
				if (MyMap->pathExplorerFindPathAStar(PE, destPos, 100000, this->GetCampTag(), this->GetFindPathInfo()))
				{
					if (PE.GetPath().size() > move + 1)
						continue;

					if (!MyMap->ConsumeMove(PE.GetPath(), move, this->GetFindPathInfo()))
						continue;

					for (std::list<CWPEGrid>::iterator iter = PE.GetPath().begin(); iter != PE.GetPath().end(); ++iter)
					{
						bool isFind = false;
						for (std::list<CWPEGrid>::iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
						{
							if ((*subIter).tile == (*iter).tile)
							{
								isFind = true;
								break;
							}
						}

						if (!isFind)
						{
							if (MyMap->isTherePawn((*iter).tile))
							{
								//格子的棋子是否自己
								if (MyMap->GetPawnByTile((*iter).tile) == this)
								{
									//格子的棋子是自己
									listMoveGrid.push_back(*iter);

									MyMap->SetMoveAttackDamage((*iter).tile, (uint8)ECWMapTileMoveAttackDamageType::Move);
								}
								else
								{
									//格子的棋子不是自己
									//不显示可移动

									if (MyMap->isThereEnemy((*iter).tile, this->GetCampTag()))
									{
										
									}
									if (MyMap->isTherePartner((*iter).tile, this->GetCampTag(), this->GetCampControllerIndex()))
									{
										MyMap->SetMoveAttackDamage((*iter).tile, (uint8)ECWMapTileMoveAttackDamageType::MoveEx);
									}
								}
							}
							else
							{
								listMoveGrid.push_back(*iter);

								MyMap->SetMoveAttackDamage((*iter).tile, (uint8)ECWMapTileMoveAttackDamageType::Move);
							}
						}
					}
				}
			}
		}
	}

	return true;
}

bool ACWPawn::GenerateAttackTile(UCWSkill* TempSkill, const std::list<CWPEGrid>& listMoveGrid, std::list<CWAttackGrid>& listAttackGrid)
{
	listAttackGrid.clear();

	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateAttackTile. MyMap == nullptr."));
		return false;
	}

	//数据重置
	MyMap->ResetVectorAttack();

	std::vector<int32> AttackRangeParams = FCWSkillDataUtils::GetArrayAttackRangeParamsFromString(TempSkill->GetSkillDataStruct()->AttackRangeParams);
	if (TempSkill->GetSkillDataStruct()->AttackRangeType == 1 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		for (std::list<CWPEGrid>::const_iterator iter = listMoveGrid.begin(); iter != listMoveGrid.end(); ++iter)
		{
			CWPEGrid MyGrid = *iter;
			int ccx = -1;
			int ccy = -1;
			ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
			int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
			int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
			int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
			int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
			for (int y = beginMoveY; y <= endMoveY; ++y)
			{
				for (int x = beginMoveX; x <= endMoveX; ++x)
				{
					if (x == ccx && y == ccy)
						continue;

					if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) > to)
						continue;

					if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) < from)
						continue;

					bool isTherePawn = false;
					bool isEnemy = false;
					bool isPartner = false;
					int WantAttackTile = ACWMap::xy2tile(x, y);
					if (MyMap->isTherePawn(WantAttackTile))
					{
						isTherePawn = true;
						if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
						{
							isEnemy = true;
						}
						if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
						{
							isPartner = true;
						}
					}

					//if (isTherePawn && !isEnemy)
					//	continue;

					bool isMoveTile = false;
					for (std::list<CWPEGrid>::const_iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
					{
						if ((*subIter).tile == WantAttackTile)
						{
							isMoveTile = true;
							break;
						}
					}

					//if (!isTherePawn && isMoveTile)
					//	continue;

					//if (isTherePawn && !isEnemy && isMoveTile)
					//	continue;

					if (isTherePawn && isPartner)
					{
						//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
					}
					else if (isTherePawn && !isEnemy)
					{

					}
					else
					{
						MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);
					}
				}
			}
		}

		return true;
	}
	else if (TempSkill->GetSkillDataStruct()->AttackRangeType == 2 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		for (std::list<CWPEGrid>::const_iterator iter = listMoveGrid.begin(); iter != listMoveGrid.end(); ++iter)
		{
			CWPEGrid MyGrid = *iter;
			int ccx = -1;
			int ccy = -1;
			ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
			int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
			int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
			int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
			int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
			for (int y = beginMoveY; y <= endMoveY; ++y)
			{
				for (int x = beginMoveX; x <= endMoveX; ++x)
				{
					if (x == ccx && y == ccy)
						continue;

					if (FMath::Abs(x - ccx) > to)
						continue;

					if (FMath::Abs(y - ccy) > to)
						continue;

					if (!((FMath::Abs(x - ccx) + FMath::Abs(y - ccy) >= from) && (FMath::Abs(x - ccx) >= from || FMath::Abs(y - ccy) >= from)))
						continue;

					bool isTherePawn = false;
					bool isEnemy = false;
					bool isPartner = false;
					int WantAttackTile = ACWMap::xy2tile(x, y);
					if (MyMap->isTherePawn(WantAttackTile))
					{
						isTherePawn = true;
						if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
						{
							isEnemy = true;
						}
						if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
						{
							isPartner = true;
						}
					}

					//if (isTherePawn && !isEnemy)
					//	continue;

					bool isMoveTile = false;
					for (std::list<CWPEGrid>::const_iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
					{
						if ((*subIter).tile == WantAttackTile)
						{
							isMoveTile = true;
							break;
						}
					}

					//if (!isTherePawn && isMoveTile)
					//	continue;

					//if (isTherePawn && !isEnemy && isMoveTile)
					//	continue;

					if (isTherePawn && isPartner)
					{
						//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
					}
					else if (isTherePawn && !isEnemy)
					{

					}
					else
					{
						MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);
					}
				}
			}
		}

		return true;
	}
	else if (TempSkill->GetSkillDataStruct()->AttackRangeType == 3 && AttackRangeParams.size() == 2)
	{
		int from = AttackRangeParams[0];
		int to = AttackRangeParams[1];

		for (std::list<CWPEGrid>::const_iterator iter = listMoveGrid.begin(); iter != listMoveGrid.end(); ++iter)
		{
			CWPEGrid MyGrid = *iter;
			int ccx = -1;
			int ccy = -1;
			ACWMap::tile2xy(MyGrid.tile, ccx, ccy);
			int beginMoveX = ccx - to < 0 ? 0 : ccx - to;
			int endMoveX = ccx + to >= MyMap->getWidth() ? MyMap->getWidth() - 1 : ccx + to;
			int beginMoveY = ccy - to < 0 ? 0 : ccy - to;
			int endMoveY = ccy + to >= MyMap->getHeight() ? MyMap->getHeight() - 1 : ccy + to;
			for (int y = beginMoveY; y <= endMoveY; ++y)
			{
				for (int x = beginMoveX; x <= endMoveX; ++x)
				{
					if (x == ccx && y == ccy)
						continue;

					if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) > to)
						continue;

					if (FMath::Abs(x - ccx) + FMath::Abs(y - ccy) < from)
						continue;

					if (!((FMath::Abs(x - ccx) >= from && FMath::Abs(y - ccy) == 0) || (FMath::Abs(x - ccx) == 0 && FMath::Abs(y - ccy) >= from)))
						continue;

					bool isTherePawn = false;
					bool isEnemy = false;
					bool isPartner = false;
					int WantAttackTile = ACWMap::xy2tile(x, y);
					if (MyMap->isTherePawn(WantAttackTile))
					{
						isTherePawn = true;
						if (MyMap->isThereEnemy(WantAttackTile, this->GetCampTag()))
						{
							isEnemy = true;
						}
						if (MyMap->isTherePartner(WantAttackTile, this->GetCampTag(), this->GetCampControllerIndex()))
						{
							isPartner = true;
						}
					}

					//if (isTherePawn && !isEnemy)
					//	continue;

					bool isMoveTile = false;
					for (std::list<CWPEGrid>::const_iterator subIter = listMoveGrid.begin(); subIter != listMoveGrid.end(); ++subIter)
					{
						if ((*subIter).tile == WantAttackTile)
						{
							isMoveTile = true;
							break;
						}
					}

					//if (!isTherePawn && isMoveTile)
					//	continue;

					//if (isTherePawn && !isEnemy && isMoveTile)
					//	continue;

					if (isTherePawn && isPartner)
					{
						//MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Support);
					}
					else if (isTherePawn && !isEnemy)
					{

					}
					else
					{
						MyMap->SetMoveAttackDamage(WantAttackTile, (uint8)ECWMapTileMoveAttackDamageType::Attack);
						ECWAffectDirType TempDir = MyMap->GetAffectDir(MyGrid.tile, WantAttackTile);
						if (TempDir != ECWAffectDirType::None)
						{
							MyMap->SetVectorAttackGrid(WantAttackTile, MyGrid.tile, TempDir, (uint8)ECWMapTileMoveAttackDamageType::Attack);

							CWAttackGrid TempAttackGrid;
							TempAttackGrid.Tile = WantAttackTile;
							TempAttackGrid.PawnTile = MyGrid.tile;
							TempAttackGrid.Dir = (uint8)TempDir;
							TempAttackGrid.MAD = (uint8)ECWMapTileMoveAttackDamageType::Attack;

							bool TempIsFindInListAttackGrid = false;
							for (std::list<CWAttackGrid>::iterator iter2 = listAttackGrid.begin(); iter2 != listAttackGrid.end(); ++iter2)
							{
								CWAttackGrid& TempGrid = *iter2;
								if (TempAttackGrid == TempGrid)
								{
									TempIsFindInListAttackGrid = true;
									break;
								}
							}

							if (!TempIsFindInListAttackGrid)
							{
								listAttackGrid.push_back(TempAttackGrid);
							}
						}
						else
						{
							UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateAttackTile, TempDir == ECWAffectDirType::None, MyGrid.tile:%d, WantAttackTile:%d."), MyGrid.tile, WantAttackTile);
						}
					}
				}
			}
		}

		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPawn::GenerateDamageTile(UCWSkill* TempSkill, const std::list<CWAttackGrid>& listAttackGrid)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateDamageTile. MyMap == nullptr."));
		return false;
	}

	//数据重置
	MyMap->ResetVectorDamage();

	for (std::list<CWAttackGrid>::const_iterator iter = listAttackGrid.begin(); iter != listAttackGrid.end(); ++iter)
	{
		CWAttackGrid TempAttackGrid = *iter;

		if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Right)
		{
			std::vector<std::vector<int32> > TempDamageRangeRight = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeRight);
			std::vector<int32> TempDamageCenterRight = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterRight);
			if (TempDamageCenterRight.size() != 2)
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateDamageTile, TempDamageCenterRight.size() != 2, TempDamageCenterRight.size():%d."), TempDamageCenterRight.size());
				return false;
			}
			int32 TempBaseX_Right = TempDamageCenterRight[0];
			int32 TempBaseY_Right = TempDamageCenterRight[1];
			FVector attack_pos = FVector::ZeroVector;
			ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
			for (int y = 0; y < TempDamageRangeRight.size(); ++y)
			{
				for (int x = 0; x < TempDamageRangeRight[y].size(); ++x)
				{
					int32 TempDamage = TempDamageRangeRight[y][x];
					if (TempDamage == 0)
						continue;

					int ox = x - TempBaseX_Right;
					int oy = y - TempBaseY_Right;

					float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
					float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

					int real_x = -1;
					int real_y = -1;
					FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
					ACWMap::pos2xy(real_pos, real_x, real_y);

					if (real_x < 0 || real_x >= MyMap->getWidth())
						continue;

					if (real_y < 0 || real_y >= MyMap->getHeight())
						continue;

					int real_tile = ACWMap::xy2tile(real_x, real_y);
					MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
				}
			}
		}
		else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Up)
		{
			std::vector<std::vector<int32> > TempDamageRangeUp = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeUp);
			std::vector<int32> TempDamageCenterUp = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterUp);
			if (TempDamageCenterUp.size() != 2)
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateDamageTile, TempDamageCenterUp.size() != 2, TempDamageCenterUp.size():%d."), TempDamageCenterUp.size());
				return false;
			}
			int32 TempBaseX_Up = TempDamageCenterUp[0];
			int32 TempBaseY_Up = TempDamageCenterUp[1];
			FVector attack_pos = FVector::ZeroVector;
			ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
			for (int y = 0; y < TempDamageRangeUp.size(); ++y)
			{
				for (int x = 0; x < TempDamageRangeUp[y].size(); ++x)
				{
					int32 TempDamage = TempDamageRangeUp[y][x];
					if (TempDamage == 0)
						continue;

					int ox = x - TempBaseX_Up;
					int oy = y - TempBaseY_Up;

					float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
					float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

					int real_x = -1;
					int real_y = -1;
					FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
					ACWMap::pos2xy(real_pos, real_x, real_y);

					if (real_x < 0 || real_x >= MyMap->getWidth())
						continue;

					if (real_y < 0 || real_y >= MyMap->getHeight())
						continue;

					int real_tile = ACWMap::xy2tile(real_x, real_y);
					MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
				}
			}
		}
		else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Left)
		{
			std::vector<std::vector<int32> > TempDamageRangeLeft = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeLeft);
			std::vector<int32> TempDamageCenterLeft = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterLeft);
			if (TempDamageCenterLeft.size() != 2)
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateDamageTile, TempDamageCenterLeft.size() != 2, TempDamageCenterLeft.size():%d."), TempDamageCenterLeft.size());
				return false;
			}
			int32 TempBaseX_Left = TempDamageCenterLeft[0];
			int32 TempBaseY_Left = TempDamageCenterLeft[1];
			FVector attack_pos = FVector::ZeroVector;
			ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
			for (int y = 0; y < TempDamageRangeLeft.size(); ++y)
			{
				for (int x = 0; x < TempDamageRangeLeft[y].size(); ++x)
				{
					int32 TempDamage = TempDamageRangeLeft[y][x];
					if (TempDamage == 0)
						continue;

					int ox = x - TempBaseX_Left;
					int oy = y - TempBaseY_Left;

					float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
					float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

					int real_x = -1;
					int real_y = -1;
					FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
					ACWMap::pos2xy(real_pos, real_x, real_y);

					if (real_x < 0 || real_x >= MyMap->getWidth())
						continue;

					if (real_y < 0 || real_y >= MyMap->getHeight())
						continue;

					int real_tile = ACWMap::xy2tile(real_x, real_y);
					MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
				}
			}
		}
		else if (TempAttackGrid.Dir == (uint8)ECWAffectDirType::Down)
		{
			std::vector<std::vector<int32> > TempDamageRangeDown = FCWSkillDataUtils::GetAffectRangeFromString(TempSkill->GetSkillDataStruct()->AffectRangeDown);
			std::vector<int32> TempDamageCenterDown = FCWSkillDataUtils::GetAffectCenterFromString(TempSkill->GetSkillDataStruct()->AffectCenterDown);
			if (TempDamageCenterDown.size() != 2)
			{
				UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::GenerateDamageTile, TempDamageCenterDown.size() != 2, TempDamageCenterDown.size():%d."), TempDamageCenterDown.size());
				return false;
			}
			int32 TempBaseX_Down = TempDamageCenterDown[0];
			int32 TempBaseY_Down = TempDamageCenterDown[1];
			FVector attack_pos = FVector::ZeroVector;
			ACWMap::tile2pos(TempAttackGrid.Tile, attack_pos);
			for (int y = 0; y < TempDamageRangeDown.size(); ++y)
			{
				for (int x = 0; x < TempDamageRangeDown[y].size(); ++x)
				{
					int32 TempDamage = TempDamageRangeDown[y][x];
					if (TempDamage == 0)
						continue;

					int ox = x - TempBaseX_Down;
					int oy = y - TempBaseY_Down;

					float real_pos_x = attack_pos.X + ox * MyMap->getGridWidth();
					float real_pos_y = attack_pos.Y + oy * MyMap->getGridHeight();

					int real_x = -1;
					int real_y = -1;
					FVector real_pos = FVector(real_pos_x, real_pos_y, 0.0f);
					ACWMap::pos2xy(real_pos, real_x, real_y);

					if (real_x < 0 || real_x >= MyMap->getWidth())
						continue;

					if (real_y < 0 || real_y >= MyMap->getHeight())
						continue;

					int real_tile = ACWMap::xy2tile(real_x, real_y);

					MyMap->SetMoveAttackDamage(real_tile, (uint8)ECWMapTileMoveAttackDamageType::Damage);
					MyMap->SetVectorDamageGrid(real_tile, TempAttackGrid.PawnTile, TempAttackGrid.Tile, (ECWAffectDirType)TempAttackGrid.Dir, (uint8)ECWMapTileMoveAttackDamageType::Damage);
				}
			}
		}
	}

	return true;
}

bool ACWPawn::RefreshAttackDamageTile(int ParamCurTile, bool ParamIsNormalAttack)
{
	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. MyMap == nullptr."));
		return false;
	}

	if (ParamCurTile == -1)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. ParamCurTile == -1."));
		return false;
	}

	UCWSkill* TempSkill = nullptr;
	if (ParamIsNormalAttack)
	{
		TempSkill = SkillManager->GetNormalAttack();
	}
	else
	{
		TempSkill = GetAutoSelectSkillRecord();
	}

	if (TempSkill == nullptr)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::RefreshAttackDamageTile. TempSkill == nullptr."));
		return false;
	}

	//数据重置
	MyMap->ResetArrayMoveAttackDamage();
	MyMap->ResetVectorAttack();
	MyMap->ResetVectorDamage();


	std::list<CWPEGrid> listMoveGrid;
	int cx = 0;
	int cy = 0;
	ACWMap::tile2xy(ParamCurTile, cx, cy);
	FVector curPos;
	ACWMap::xy2pos(cx, cy, curPos);
	//格子的棋子是自己
	int dt = ACWMap::xy2tile(cx, cy);
	CWPEGrid tg(dt);
	listMoveGrid.push_back(tg);
	MyMap->SetMoveAttackDamage(tg.tile, (uint8)ECWMapTileMoveAttackDamageType::Move);


	std::list<CWAttackGrid> listAttackGrid;
	GenerateAttackTile(TempSkill, listMoveGrid, listAttackGrid);

	GenerateDamageTile(TempSkill, listAttackGrid);

	return true;
}

FString ACWPawn::GetWeaponId() const
{
	FString WeaponId = (PawnNetData.Weapon > 0) ? FString::Printf(TEXT("W%d"), PawnNetData.Weapon) : TEXT("");
	return WeaponId;
}

FString ACWPawn::GetActingId() const
{
	const int32 MyProfession = PawnNetData.Profession;
	if (const FCWProfessionDataStruct* ProfessionData = FCWCfgUtils::GetProfessionData(this, PawnNetData.Profession))
	{
		FString ActingId = (ProfessionData->MoveType > 0) ? FString::Printf(TEXT("A%d"), ProfessionData->MoveType) : TEXT("");
		return ActingId;
	}
	return TEXT("");
}

FString ACWPawn::GetRaceId() const
{
	FString RaceId = (PawnNetData.Race > 0) ? FString::Printf(TEXT("R%d"), PawnNetData.Race) : TEXT("");
	return RaceId;
}

void ACWPawn::ShowHintTile(ACWPlayerController* ParamPlayerController)
{
	HideHintTile();

	ACWMap* MyMap = this->GetMap();
	if (MyMap == nullptr)
		return;

	if (!RefreshMoveAttackDamageTile(this->GetTile(), false))
	{
		return;
	}

	// 预览移动攻击提示格子
	TArray<ACWMapTile*> NewMoveTiles, NewAttackTiles;

	const TArray<uint8>& TempArrayMoveAttackDamage = MyMap->GetArrayMoveAttackDamage();
	for (int tile = 0; tile < TempArrayMoveAttackDamage.Num(); ++tile)
	{
		uint8 TempMoveAttackDamage = TempArrayMoveAttackDamage[tile];
		if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Move) > 0)
		{
			ACWMapTile* MyMapTile = GetMapTileByTile(tile);
			if (MyMapTile != nullptr)
			{
				NewMoveTiles.AddUnique(MyMapTile);
				ACWMapTileRender* MapTileRender = MyMapTile->ShowHintTile(ECWTileRenderType::Move, this);
				if (MapTileRender != nullptr)
				{
					ListMapTileRender.push_back(MapTileRender);
				}
			}
		}
		else if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::MoveEx) > 0)
		{
			ACWMapTile* MyMapTile = GetMapTileByTile(tile);
			if (MyMapTile != nullptr)
			{
				NewMoveTiles.AddUnique(MyMapTile);
			}
		}
		else if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Attack) > 0)
		{
			ACWMapTile* MyMapTile = GetMapTileByTile(tile);
			if (MyMapTile != nullptr)
			{
				NewAttackTiles.AddUnique(MyMapTile);
				ACWMapTileRender* MapTileRender = MyMapTile->ShowHintTile(ECWTileRenderType::Attack, this);
				if (MapTileRender != nullptr)
				{
					ListMapTileRender.push_back(MapTileRender);
				}
			}
		}
		else if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Support) > 0)
		{
			ACWMapTile* MyMapTile = GetMapTileByTile(tile);
			if (MyMapTile != nullptr)
			{
				ACWMapTileRender* MapTileRender = MyMapTile->ShowHintTile(ECWTileRenderType::Support, this);
				if (MapTileRender != nullptr)
				{
					ListMapTileRender.push_back(MapTileRender);
				}
			}
		}
		else if ((TempMoveAttackDamage & (uint8)ECWMapTileMoveAttackDamageType::Damage) > 0)
		{
			ACWMapTile* MyMapTile = GetMapTileByTile(tile);
			if (MyMapTile != nullptr)
			{
				ACWMapTileRender* MapTileRender = MyMapTile->ShowHintTile(ECWTileRenderType::Attack, this);
				if (MapTileRender != nullptr)
				{
					ListMapTileRender.push_back(MapTileRender);
				}
			}
		}
	}

#if !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer))
	{
		ACWPlayerController* LocalPC = GetLocalPC();
		if (nullptr != LocalPC)
		{
			LocalPC->ShowMoveAttackSpline(NewMoveTiles, NewAttackTiles);
		}
	}
#endif
}

void ACWPawn::HideHintTile()
{
	for (std::list<ACWMapTileRender*>::iterator iter = ListMapTileRender.begin(); iter != ListMapTileRender.end(); ++iter)
	{
		ACWMapTileRender* MyMapTileRender = *iter;
		check(MyMapTileRender);
		ACWMapTile* MyMapTile = MyMapTileRender->GetParantTile();
		if (MyMapTile != nullptr)
		{
			MyMapTile->HideHintTile(MyMapTileRender, this);
		}
	}

	ListMapTileRender.clear();

#if !UE_SERVER
	if (!IsNetMode(NM_DedicatedServer))
	{
		ACWPlayerController* LocalPC = GetLocalPC();
		if (nullptr != LocalPC)
		{
			LocalPC->HideMoveAttackSpline();
		}
	}
#endif
}

void ACWPawn::ShowWantMovePathArrow()
{
	/*if (this->PathExplorer.GetPath().empty())
		return;

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->ParantController);
	check(MyPlayerController);

	ACWMap* MyMap = MyPlayerController->GetMap();
	check(MyMap);

	MyMap->RomoveAllSplinePoint();

	int32 Idx = 0;
	std::list<CWPEGrid>::iterator oldIter = PathExplorer.GetPath().end();
	for (std::list<CWPEGrid>::iterator iter = PathExplorer.GetPath().begin(); iter != PathExplorer.GetPath().end(); ++iter)
	{
		CWPEGrid TempGrid = *iter;
		if (oldIter != PathExplorer.GetPath().end() && oldIter != iter)
		{
			CWPEGrid TempOldGrid = *oldIter;
			float nz = this->GetDungeonTileZ(TempGrid.tile);
			float oz = this->GetDungeonTileZ(TempOldGrid.tile);
			if (FMath::Abs(nz - oz) >= 0.001f)
			{
				if (nz > oz)
				{
					if (TempOldGrid.x == TempGrid.x)
					{
						if (TempOldGrid.y < TempGrid.y)
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f - SPLINE_EX_Z, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f - SPLINE_EX_Z, nz + SPLINE_Z));
						}
						else
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f + SPLINE_EX_Z, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f + SPLINE_EX_Z, nz + SPLINE_Z));
						}
					}
					else
					{
						if (TempOldGrid.x < TempGrid.x)
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f - SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f - SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, nz + SPLINE_Z));
						}
						else
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f + SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f + SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, nz + SPLINE_Z));
						}
					}
				}
				else
				{
					if (TempOldGrid.x == TempGrid.x)
					{
						if (TempOldGrid.y < TempGrid.y)
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f + SPLINE_EX_Z, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f + SPLINE_EX_Z, nz + SPLINE_Z));
						}
						else
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f - SPLINE_EX_Z, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f - SPLINE_EX_Z, nz + SPLINE_Z));
						}
					}
					else
					{
						if (TempOldGrid.x < TempGrid.x)
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f + SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f + SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, nz + SPLINE_Z));
						}
						else
						{
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f - SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, oz + SPLINE_Z));
							MyMap->AddSplinePoint(FVector((TempOldGrid.pos.X + TempGrid.pos.X) / 2.0f - SPLINE_EX_Z, (TempOldGrid.pos.Y + TempGrid.pos.Y) / 2.0f, nz + SPLINE_Z));
						}
					}
				}
			}
		}
		float z = this->GetDungeonTileZ(TempGrid.tile);
		MyMap->AddSplinePoint(FVector(TempGrid.pos.X, TempGrid.pos.Y, z + SPLINE_Z));

		CWG_WARNING(">> ShowWantMovePathArrow, Idx[%d] tile[%d].", Idx, TempGrid.tile);
		ACWMapTile* MapTile = MyMap->GetTile(TempGrid.tile);
		UCWFuncLib::PrintTxtInfo(MapTile, FSTRING_TO_FTEXT(FString::Printf(TEXT("%d_%d"), Idx++, TempGrid.tile)), FColor::Red, 200, 150);

		oldIter = iter;
	}*/


	if (IsNetMode(NM_DedicatedServer))
	{
		return;
	}

	// 获取需要绘制点
	int32 OldTileNumber = INDEX_NONE;
	TArray<FVector> NewDrawPathPoint;
	FVector OldTileLocation = FVector::ZeroVector;
	std::list<CWPEGrid>::iterator Iter = PathExplorer.GetPath().begin();
	for (; Iter != PathExplorer.GetPath().end(); ++Iter)
	{
		CWPEGrid TempGrid = *Iter;
		ACWDungeonTile* DungeonTile = GetDungeonTile(TempGrid.tile);
		if (nullptr == DungeonTile || OldTileNumber == TempGrid.tile)
		{
			CWG_WARNING(">> ShowWantMovePathArrow, OldTileNumber[%d] tile[%d] DungeonTile[%s].", OldTileNumber, TempGrid.tile, *CWG_NAME(DungeonTile));
			continue;
		}

		FVector NewVector = DungeonTile->GetActorLocation(); NewVector.Z += SPLINE_Z;
		if (0 == NewDrawPathPoint.Num())
		{
			NewDrawPathPoint.AddUnique(NewVector);
		}else
		{
			const FVector CenterPoint = OldTileLocation + (NewVector - OldTileLocation) / 2;
			if (FMath::IsNearlyEqual(OldTileLocation.Z, CenterPoint.Z, 1.f))
			{
				//NewDrawPathPoint.AddUnique(CenterPoint);
				NewDrawPathPoint.AddUnique(NewVector);
			}
			else
			{
				NewDrawPathPoint.AddUnique(FVector(CenterPoint.X, CenterPoint.Y, OldTileLocation.Z));
				NewDrawPathPoint.AddUnique(FVector(CenterPoint.X, CenterPoint.Y, NewVector.Z));
				NewDrawPathPoint.AddUnique(NewVector);
			}
		}

		//CWG_WARNING(">> ShowWantMovePathArrow, OldTileNumber[%d] tile[%d].", OldTileNumber, TempGrid.tile);
		//UCWFuncLib::PrintTxtInfo(DungeonTile, FSTRING_TO_FTEXT(FString::Printf(TEXT("%d->%d"), OldTileNumber, TempGrid.tile)), FColor::Green, 180, 150);
		OldTileNumber = TempGrid.tile;
		OldTileLocation = NewVector;
	}

	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->ShowMovePathSpline(NewDrawPathPoint);
	}
}

void ACWPawn::HideWantMovePathArrow()
{
	/*ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->ParantController);
	check(MyPlayerController);

	ACWMap* MyMap = MyPlayerController->GetMap();
	check(MyMap);

	MyMap->RomoveAllSplinePoint();*/
	
	if (IsNetMode(NM_DedicatedServer))
	{
		return;
	}

	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->HideMovePathSpline();
	}
}

bool ACWPawn::CheckEnemyInAttackRange(int ParamTile)
{
	if (this->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->GetParantController());
		if (MyPlayerController != nullptr)
		{
			ACWMap* MyMap = MyPlayerController->GetMap();
			check(MyMap);

			int attackDis = 1;
			int MyCurTile = ParamTile;
			int cx = -1;
			int cy = -1;
			ACWMap::tile2xy(MyCurTile, cx, cy);
			if (cx != -1 && cy != -1)
			{
				int beginX = cx - attackDis < 0 ? 0 : cx - attackDis;
				int endX = cx + attackDis >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + attackDis;
				int beginY = cy - attackDis < 0 ? 0 : cy - attackDis;
				int endY = cy + attackDis >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + attackDis;
				for (int y = beginY; y <= endY; ++y)
				{
					for (int x = beginX; x <= endX; ++x)
					{
						if (x == cx && y == cy)
							continue;

						if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > attackDis)
							continue;

						int TempTile = ACWMap::xy2tile(x, y);
						bool bIsThereEnemy = false;
						bIsThereEnemy= MyMap->isThereEnemy(TempTile, this->GetCampTag());
						if (bIsThereEnemy)
							return true;
					}
				}
			}
		}
	}

	return false;
}

void ACWPawn::SetEnemyHeadIconInAttackRange()
{
	RestoreEnemyHeadIconInAttackRange();

	if (this->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->GetParantController());
		if (MyPlayerController != nullptr)
		{
			ACWMap* MyMap = MyPlayerController->GetMap();
			check(MyMap);

			int attackDis = 1;
			int MyCurTile = this->GetTile();
			int cx = -1;
			int cy = -1;
			ACWMap::tile2xy(MyCurTile, cx, cy);
			if (cx != -1 && cy != -1)
			{
				int beginX = cx - attackDis < 0 ? 0 : cx - attackDis;
				int endX = cx + attackDis >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + attackDis;
				int beginY = cy - attackDis < 0 ? 0 : cy - attackDis;
				int endY = cy + attackDis >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + attackDis;
				for (int y = beginY; y <= endY; ++y)
				{
					for (int x = beginX; x <= endX; ++x)
					{
						if (x == cx && y == cy)
							continue;

						if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > attackDis)
							continue;

						int TempTile = ACWMap::xy2tile(x, y);
						bool bIsThereEnemy = false;
						bIsThereEnemy = MyMap->isThereEnemy(TempTile, this->GetCampTag());
						if (bIsThereEnemy)
						{
							TWeakObjectPtr<ACWPawn> EnemyPawn = MyMap->GetPawnByTile(TempTile);
							if (EnemyPawn.IsValid())
							{
								EnemyPawn->ShowHeadIcon(EUIHeadIconType::Attack);
								ListHeadIconForEnemyPawnCache.AddUnique(EnemyPawn);
							}
						}
					}
				}
			}
		}
	}
}

void ACWPawn::SetEnemyHeadIconInAttackSingle(ACWPawn* ParamEnemgyPawn)
{
	RestoreEnemyHeadIconInAttackRange();

	check(ParamEnemgyPawn);
	ParamEnemgyPawn->ShowHeadIcon(EUIHeadIconType::Attack);
	ListHeadIconForEnemyPawnCache.AddUnique(ParamEnemgyPawn);
}

void ACWPawn::RestoreEnemyHeadIconInAttackRange()
{
	for (auto iter : ListHeadIconForEnemyPawnCache)
	{
		TWeakObjectPtr<ACWPawn> WeakObj = iter;
		if (WeakObj.IsValid())
		{
			WeakObj->ShowHeadIcon(EUIHeadIconType::None);
		}
	}

	ListHeadIconForEnemyPawnCache.Empty();
}

void ACWPawn::SetPartnerHeadIconInSupportRange()
{
	RestorePartnerHeadIconInSupportRange();

	if (this->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(this->GetParantController());
		if (MyPlayerController != nullptr)
		{
			ACWMap* MyMap = MyPlayerController->GetMap();
			check(MyMap);

			int attackDis = 1;
			int MyCurTile = this->GetTile();
			int cx = -1;
			int cy = -1;
			ACWMap::tile2xy(MyCurTile, cx, cy);
			if (cx != -1 && cy != -1)
			{
				int beginX = cx - attackDis < 0 ? 0 : cx - attackDis;
				int endX = cx + attackDis >= MyMap->getWidth() ? MyMap->getWidth() - 1 : cx + attackDis;
				int beginY = cy - attackDis < 0 ? 0 : cy - attackDis;
				int endY = cy + attackDis >= MyMap->getHeight() ? MyMap->getHeight() - 1 : cy + attackDis;
				for (int y = beginY; y <= endY; ++y)
				{
					for (int x = beginX; x <= endX; ++x)
					{
						if (x == cx && y == cy)
							continue;

						if (FMath::Abs(x - cx) + FMath::Abs(y - cy) > attackDis)
							continue;

						int TempTile = ACWMap::xy2tile(x, y);
						bool bIsThereEnemy = false;
						bIsThereEnemy = MyMap->isTherePartner(TempTile, this->GetCampTag(), this->GetCampControllerIndex());
						if (bIsThereEnemy)
						{
							TWeakObjectPtr<ACWPawn> PartnerPawn = MyMap->GetPawnByTile(TempTile);
							if (PartnerPawn.IsValid())
							{
								PartnerPawn->ShowHeadIcon(EUIHeadIconType::Support);
								ListHeadIconForPartnerPawnCache.AddUnique(PartnerPawn);
							}
						}
					}
				}
			}
		}
	}
}

void ACWPawn::RestorePartnerHeadIconInSupportRange()
{
	for (auto iter : ListHeadIconForPartnerPawnCache)
	{
		TWeakObjectPtr<ACWPawn> WeakObj = iter;
		if (WeakObj.IsValid())
		{
			WeakObj->ShowHeadIcon(EUIHeadIconType::None);
		}
	}

	ListHeadIconForPartnerPawnCache.Empty();
}

void ACWPawn::ForceActionEndInClient()
{

}

bool ACWPawn::CanMoveByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if ((TempCurInstructs.Instructs & (uint8)ECWInstructType::Await) > 0 ||
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::Move) > 0)
	{
		return false;
	}

	return true;
}

bool ACWPawn::CanNormalAttackByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if ((TempCurInstructs.Instructs & (uint8)ECWInstructType::Await) > 0 ||
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::NormalAttack) > 0)
	{
		return false;
	}

	return true;
}

bool ACWPawn::CanCastSkillByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if ((TempCurInstructs.Instructs & (uint8)ECWInstructType::Await) > 0 ||
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::CastSkill) > 0)
	{
		return false;
	}

	return true;
}

bool ACWPawn::IsThinkActionNoEndByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if (TempCurInstructs.Instructs == 0xff || 
		TempCurInstructs.Instructs == 0 ||
		(TempCurInstructs.Instructs > 0 && (TempCurInstructs.Instructs & (uint8)ECWInstructType::Await) == 0))
	{
		return true;
	}

	return false;
}

bool ACWPawn::CanInstructsByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if (TempCurInstructs.Instructs == 0 ||
		(TempCurInstructs.Instructs > 0 && (TempCurInstructs.Instructs & (uint8)ECWInstructType::Await) == 0))
	{
		return true;
	}

	return false;
}

bool ACWPawn::IsMovedByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
		return false;

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];

	if (TempCurInstructs.Instructs == 0)
		return false;

	if (TempCurInstructs.Instructs > 0 && 
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::Move) > 0)
		return true;
	else
		return false;
}

bool ACWPawn::IsNormalAttackByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
		return false;

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];

	if (TempCurInstructs.Instructs == 0)
		return false;

	if (TempCurInstructs.Instructs > 0 && 
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::NormalAttack) > 0)
		return true;
	else
		return false;
}

bool ACWPawn::IsCastSkillByCurInstructs() const
{
	if (ArrayInstructs.Num() <= 0)
		return false;

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];

	if (TempCurInstructs.Instructs == 0)
		return false;

	if (TempCurInstructs.Instructs > 0 && 
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::CastSkill) > 0)
		return true;
	else
		return false;
}

bool ACWPawn::IsInDefincePosture() const
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	FCWPawnInstructs TempCurInstructs = ArrayInstructs[ArrayInstructs.Num() - 1];
	if (TempCurInstructs.Instructs > 0 &&
		(TempCurInstructs.Instructs & (uint8)ECWInstructType::Defence) > 0)
	{
		return true;
	}

	return false;
}

bool ACWPawn::SetCurInstructs(uint8 ParamInstructs)
{
	if (ArrayInstructs.Num() <= 0)
	{
		return false;
	}

	//uint8 OldInstructs = ArrayInstructs[ArrayInstructs.Num() - 1].Instructs;
	//uint8 CurInstructs = OldInstructs | ParamInstructs;
	//CWG_WARNING(">> CWPawn::SetCurInstructs, OldInstructs[%d] CurInstructs[%d].", (int32)OldInstructs, (int32)CurInstructs);

	ArrayInstructs[ArrayInstructs.Num() - 1].Instructs |= ParamInstructs;
	return true;
}

uint8 ACWPawn::GetCurInstructs() const
{
	const int32 InstructsNum = ArrayInstructs.Num();
	return (InstructsNum > 0) ? ArrayInstructs[InstructsNum - 1].Instructs : (uint8)0xff;
}

bool ACWPawn::AddInstructs(
	uint8 Instructs,
	bool bIsOriginal,
	int32 SourcePawnCampTag,
	int32 SourcePawnCampControllerIndex,
	int32 SourcePawnControllerPawnIndex,
	int32 SourceSkillId,
	int32 SourceBuffId,
	int32 SourceBuffUniqueId,
	int32 SourceAffectorId)
{
	if (ArrayInstructs.Num() > 0)
	{
		ArrayInstructs[ArrayInstructs.Num() - 1].Instructs |= (uint8)ECWInstructType::Await;
	}

	//uint8 OldInstructs = ArrayInstructs[ArrayInstructs.Num() - 1].Instructs;
	//uint8 CurInstructs = Instructs;
	//CWG_WARNING(">> CWPawn::AddInstructs, OldInstructs[%d] CurInstructs[%d].", (int32)OldInstructs, (int32)CurInstructs);

	FCWPawnInstructs NewPawnInstructs;
	NewPawnInstructs.Instructs = Instructs;
	NewPawnInstructs.bIsOriginal = bIsOriginal;
	NewPawnInstructs.SourcePawnCampTag = SourcePawnCampTag;
	NewPawnInstructs.SourcePawnCampControllerIndex = SourcePawnCampControllerIndex;
	NewPawnInstructs.SourcePawnControllerPawnIndex = SourcePawnControllerPawnIndex;
	NewPawnInstructs.SourceSkillId = SourceSkillId;
	NewPawnInstructs.SourceBuffId = SourceBuffId;
	NewPawnInstructs.SourceBuffUniqueId = SourceBuffUniqueId;
	NewPawnInstructs.SourceAffectorId = SourceAffectorId;
	ArrayInstructs.Add(NewPawnInstructs);

	return true;
}

int32 ACWPawn::GetPawnUniqueIdx() const
{
	return NetPawnUniqueIdx;
}

void ACWPawn::SetPawnUniqueIdx(int32 InUniqueIdx)
{
	NetPawnUniqueIdx = InUniqueIdx;
}

bool ACWPawn::IsDizzinessFlag() const
{
	// 是否有眩晕标志
	return DizzinessFlag != 0x00;
}

uint8 ACWPawn::GetDizzinessFlag() const
{
	return DizzinessFlag;
}

void ACWPawn::SetDizzinessFlag(uint8 InNewFlag)
{
	DizzinessFlag = InNewFlag;
}

bool ACWPawn::CheckDizzinessResult() const
{
	const ECWPawnActionState CurActionState = GetCurActionStateId();
	const bool bIsDizzinessState = (CurActionState == ECWPawnActionState::Dizziness);
	const bool bIsDizzinesFlag = IsDizzinessFlag();
	if (bIsDizzinessState != bIsDizzinesFlag)
	{
		CWG_WARNING(">> %s::CheckDizzinessResult, NetMode[%s] CurActionState[%s] bIsDizzinessState[%d] bIsDizzinesFlag[%d].", 
			*GetName(), *NETMODE_TO_STRING(GetNetMode()), *FCWCommonUtil::EnumToString(TEXT("ECWPawnActionState"), CurActionState), bIsDizzinessState, bIsDizzinesFlag);
	}

	return /*bIsDizzinessState && */bIsDizzinesFlag;
}

bool ACWPawn::IsAllowOperate() const
{
	return true;
}

int ACWPawn::PutAction(UCWPawnActionData* ParamPawnActionData)
{
	ArrayActions.Insert(ParamPawnActionData, 0);
	if (ArrayActions.Num() > 150)
	{
		UE_LOG(LogCWPawn, Error, TEXT("ACWPawn::PutAction. ArrayActions.Num() > 150, ArrayActions.Num():%d."), ArrayActions.Num());
	}

	UE_LOG(LogCWPawn, Log, TEXT("UCWPawnActionEndState::PutAction..., CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, ActionId:%d."), (int)this->GetCampTag(), (int)this->GetCampControllerIndex(), (int)this->GetControllerPawnIndex(), (int)ParamPawnActionData->ActionId);
	return ArrayActions.Num();
}

bool ACWPawn::ProcessNextAction()
{
	if (GetActionQueueCount())
	{
		UCWPawnActionData* TempActionData = ArrayActions.Top();
		check(TempActionData);
		ArrayActions.Pop();

		if (DoNextAction(TempActionData))
		{
			return true;
		}
	}

	return false;
}

int ACWPawn::GetActionQueueCount()
{
	return ArrayActions.Num();
}

bool ACWPawn::DoNextAction(UCWPawnActionData* ParamPawnActionData)
{
	check(ParamPawnActionData);
	check(ActionComponent);
	return ActionComponent->SetNextState(ParamPawnActionData->ActionId, ParamPawnActionData);
}

UCWPawnActionData* ACWPawn::GetIdleOrEndStateForNextState(ECWPawnActionState& ParamOutActionState)
{
	if (CanInstructsByCurInstructs())
	{
		UCWPawnActionDataForIdle* TempIdleData = (UCWPawnActionDataForIdle*)(NewObject<UCWPawnActionDataForIdle>());
		TempIdleData->ActionId = ECWPawnActionState::Idle;
		ParamOutActionState = ECWPawnActionState::Idle;
		return TempIdleData;
	}
	else
	{
		ECWPawnActionState TempCurState = ActionComponent->GetCurState();
		UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
		TempEndData->ActionId = ECWPawnActionState::End;
		TempEndData->OldActionState = TempCurState;
		TempEndData->bIsTriggerEvent = true;
		TempEndData->bIsForceToEnd = false;
		ParamOutActionState = ECWPawnActionState::End;
		return TempEndData;
	}
}

void ACWPawn::AddNextStateToIdleOrEnd()
{
	if (CanInstructsByCurInstructs())
	{
		UCWPawnActionDataForIdle* TempIdleData = (UCWPawnActionDataForIdle*)NewObject<UCWPawnActionDataForIdle>();
		TempIdleData->ActionId = ECWPawnActionState::Idle;
		this->PutAction(TempIdleData);
	}
	else
	{
		ECWPawnActionState TempCurState = ActionComponent->GetCurState();
		UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)NewObject<UCWPawnActionDataForEnd>();
		TempEndData->ActionId = ECWPawnActionState::End;
		TempEndData->OldActionState = TempCurState;
		TempEndData->bIsTriggerEvent = false;
		TempEndData->bIsForceToEnd = false;
		this->PutAction(TempEndData);
	}
}

void ACWPawn::ResetInputStateInClient()
{
	if (IsInServer())
		return;

	if (IsDieOrDeath())
		return;

	if (IsMyClientPawn())
	{
		ACWPlayerController* LocalPC = GetLocalPC();
		if (LocalPC != nullptr && LocalPC->IsMyTurn())
		{
			if (CanInstructsByCurInstructs())
			{
				if (!CheckDizzinessResult())
				{
					FCWPawnInputWaitingEvent* WaitingEvent = new FCWPawnInputWaitingEvent((int)ECWPawnInputEvent::TurnStartAction, (int)ECWPawnInputState::WaitingInput, ECWFSMStackOp::Set);
					this->GetInputFSM()->DoEvent(WaitingEvent);
				}
				else
				{
					// 直接到输入动作完成状态
					FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
						(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
					InputFSM->DoEvent(ToNewEvent);
				}
			}
			else
			{
				// 直接到输入动作完成状态
				FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
					(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
				InputFSM->DoEvent(ToNewEvent);
			}
		}
		else
		{
			// 直接到输入动作完成状态
			FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
				(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
			InputFSM->DoEvent(ToNewEvent);
		}
		
	}
	else
	{
		// 直接到输入动作完成状态
		FCWPawnInputActionFinishEvent* ToNewEvent = new FCWPawnInputActionFinishEvent(
			(int32)ECWPawnInputEvent::TurnActionFinish, (int32)ECWPawnInputState::TurnInputFinish, ECWFSMStackOp::Set);
		InputFSM->DoEvent(ToNewEvent);
	}
}

void ACWPawn::SetIsActionEnd(bool ParamIsActionEnd)
{
	bIsActionEnd = ParamIsActionEnd;
}

bool ACWPawn::IsActionEnd() const
{
	return bIsActionEnd;
}

void ACWPawn::CancelOwnerInputData()
{
	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(ParantController);
	if (nullptr != MyPlayerController)
	{
		MyPlayerController->CancelPlayerInputData();
	}
}

int32 ACWPawn::GetPreMoveTargetPoint()
{
	std::list<CWPEGrid> PathNodes = PathExplorer.GetPath();
	if (PathNodes.size() >= 2)
	{
		return PathNodes.back().tile;
	}
	return INDEX_NONE;
}

int32 ACWPawn::GetLandformLayer()
{
	return 10;
}

float ACWPawn::GetAttackWeatherExtValue()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		ACWGameState* MyGS = GetGameState<ACWGameState>();
		const int32 WeatherIdx = MyGS ? MyGS->GetWeatherIdx() : 0;
		if (const FCWWeatherData* CurWeatherData = FCWCfgUtils::GetWeatherData(this, WeatherIdx))
		{
			const int8 BattleDistType = GetBattleDistType();
			if (BattleDistType > INDEX_NONE)
			{
				float OutAttack = BattleDistType == 0 ? CurWeatherData->MeleeAffect.AttackValue : 0.f;
				OutAttack += BattleDistType == 1 ? CurWeatherData->RangedAffect.AttackValue : 0.f;
				return OutAttack;
			}
		}
	}
	return 0.f;
}

float ACWPawn::GetDefinceWeatherExtValue()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		ACWGameState* MyGS = GetGameState<ACWGameState>();
		const int32 WeatherIdx = MyGS ? MyGS->GetWeatherIdx() : 0;
		if (const FCWWeatherData* CurWeatherData = FCWCfgUtils::GetWeatherData(this, WeatherIdx))
		{
			const int8 BattleDistType = GetBattleDistType();
			if (BattleDistType > INDEX_NONE)
			{
				float OutDefence = BattleDistType == 0 ? CurWeatherData->MeleeAffect.DefenceValue : 0.f;
				OutDefence += BattleDistType == 1 ? CurWeatherData->RangedAffect.DefenceValue : 0.f;
				return OutDefence;
			}
		}
	}
	return 0.f;
}

float ACWPawn::GetDefinceTerrainExtFactor()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		int32 CurTileNumber = GetTile();
		if (!IsNetMode(NM_DedicatedServer))
		{	// 攻击预览对象预移动目标格子
			ACWPlayerController* LocalPC = GetLocalPC();
			if (nullptr != LocalPC && LocalPC->IsMeCurSelectedPawn(this))
			{
				const int32 PreMoveTile = GetPreMoveTargetPoint();
				CurTileNumber = (PreMoveTile > INDEX_NONE) ? PreMoveTile : CurTileNumber;
			}
		}
		ACWDungeonTile* TerrainTile = GetDungeonTile(CurTileNumber);
		const int32 RegionId = TerrainTile ? TerrainTile->RegionId : INDEX_NONE;
		const FCWDungeonRegionDataStruct* DungeonRegionData = FCWCfgUtils::GetDungeonRegionData(this, RegionId);
		return DungeonRegionData ? DungeonRegionData->TerrainDefinceFactor : 0.f;
	}
	return 0.f;
}

float ACWPawn::GetAttackWavedLandformExtFactor(const int32 InOtherTile)
{
	if (InOtherTile > INDEX_NONE && IsPawnType(ECWPawnType::Character))
	{
		int32 PreTargetTile = GetPreMoveTargetPoint();
		if (PreTargetTile > INDEX_NONE)
		{
			// TODO: 比较地势差 (通过格子对应 地势层)
			if (false)
			{
				const FString& WavedLandformKey = false ? TEXT("WavedLand_Adv") : TEXT("WavedLand_DisAdv");
				if (const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, WavedLandformKey))
				{
					return FSTRING_TO_FLOAT(ConstData->Param);
				}
			}
		}
	}
	return 0.f;
}

void ACWPawn::EnableMoveToTargetComp(const FVector& InTargetPoint)
{
	if (nullptr == MovementActorComp)
	{
		MovementActorComp = NewObject<UMovementActorComp>(this, UMovementActorComp::StaticClass());
		check(MovementActorComp);

		AddOwnedComponent(MovementActorComp);
		MovementActorComp->RegisterComponent();
		MovementActorComp->SetIsReplicated(true);
	}
	MovementActorComp->SimpleMoveToTarget(InTargetPoint);
}

int32 ACWPawn::GenerateNetPawnUniqueIdx()
{
	ACWGameMode* MyGameMode = GetGameMode();
	check(MyGameMode);
	return MyGameMode->GenerateNetPawnUniqueIdx();
}

FString ACWPawn::ToDebugString() const
{
	const FString& DisPlayName = GetDisplayName();
	const FString& ElemInfo = IsValid(ElemSysCtrl) ? ElemSysCtrl->ToDebugString() : TEXT("None");
	const FString& PhysicsInfo = IsValid(PhysicsSysCtrl) ? PhysicsSysCtrl->ToDebugString() : TEXT("None");
	const FString& NetPawnData = CombinationName + TEXT(": ") + PawnNetData.ToDebugString();
	return FString::Printf(TEXT("[%s] Name[%s] PawnId[%d] UniqueIdx[%d] Tile[%d] ElemInfo[%s] PhysicsInfo[%s] \n\t\t\t >> NetPawnData[%s]."), 
		*NETMODE_TO_STRING(GetNetMode()), *DisPlayName, PawnId, NetPawnUniqueIdx, Tile, *ElemInfo, *PhysicsInfo, *NetPawnData);
}

float ACWPawn::GetHitMarkOverrideZ() const
{
	const FCWProfessionDataStruct* ProfessionData = GetProfessionData();
	return ProfessionData ? ProfessionData->HitMarkHeight : 200.f;
}

FString ACWPawn::GetDisplayModelAssetId()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		FString StrRace = INT_TO_FSTRING(PawnNetData.Race);
		FString StrSex = INT_TO_FSTRING(PawnNetData.Sex);
		FString StrProfession = INT_TO_FSTRING(PawnNetData.Profession);
		FString RetAssetId = "SM_" + StrRace + "_" + StrSex + "_" + StrProfession;
		return RetAssetId;
	}
	return TEXT("");
}

FString ACWPawn::GetDisplayModelAnimInstClassId()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		FString StrRace = INT_TO_FSTRING(PawnNetData.Race);
		FString StrSex = INT_TO_FSTRING(PawnNetData.Sex);
		FString StrProfession = INT_TO_FSTRING(PawnNetData.Profession);
		FString RetAssetId = "BP_AnimInst_" + StrRace + "_" + StrSex + "_" + StrProfession;
		return RetAssetId;
	}
	return TEXT("");
}

FString ACWPawn::GetDisplayModelAnimId()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		FString StrRace = INT_TO_FSTRING(PawnNetData.Race);
		FString StrSex = INT_TO_FSTRING(PawnNetData.Sex);
		FString StrProfession = INT_TO_FSTRING(PawnNetData.Profession);
		FString StrWeapon = INT_TO_FSTRING(PawnNetData.Weapon);
		FString CombinationName = "AS_" + StrRace + "_" + StrSex + "_" + StrProfession + "_" + StrWeapon;
		FString RetAssetId = CombinationName + "_Idle";
		return RetAssetId;
	}
	return TEXT("");
}

FString ACWPawn::GetDeadBodyAnimId()
{
	if (IsPawnType(ECWPawnType::Character))
	{
		FString StrRace = INT_TO_FSTRING(PawnNetData.Race);
		FString StrSex = INT_TO_FSTRING(PawnNetData.Sex);
		FString StrProfession = INT_TO_FSTRING(PawnNetData.Profession);
		FString StrWeapon = INT_TO_FSTRING(PawnNetData.Weapon);
		FString CombinationName = "AS_" + StrRace + "_" + StrSex + "_" + StrProfession + "_" + StrWeapon;
		FString RetAssetId = CombinationName + "_Death";
		return RetAssetId;
	}
	return TEXT("");
}

UCWElementSystemCtrl* ACWPawn::GetElemSysCtrl()
{
	return ElemSysCtrl;
}

bool ACWPawn::InitElemSysData()
{
	// Close Elem Sys
	//return true;

	if (IsValidCompnent(ElemSysCtrl))
	{
		CWG_WARNING(">> %s::InitElemSysData, Fail!!! ElemSysCtrl[%s] already init.", *GetName(), *ElemSysCtrl->GetName());
		return false;
	}

	const int32 NewOwnElemId = GetOwnElemIdByCfg();
	if (NewOwnElemId <= 0)
	{
		return false;
	}

	const FCWObjElemInfoData* ElemInfo = FCWCfgUtils::GetObjElemInfoData(this, NewOwnElemId);
	UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_ElemSysCtrl);
	if (nullptr == ElemInfo || nullptr == TempleteClass)
	{
		CWG_WARNING(">> %s::InitElemSysData, Fail!!! NewOwnElemId[%d]/BP_ElementSystemCtrl is invalid!!!", *GetName(), NewOwnElemId);
		return false;
	}

	OwnElemId = NewOwnElemId;
	ElemSysCtrl = NewObject<UCWElementSystemCtrl>(this, TempleteClass);
	check(ElemSysCtrl);

	AddOwnedComponent(ElemSysCtrl);
	ElemSysCtrl->RegisterComponent();
	ElemSysCtrl->SetIsReplicated(true);
	ElemSysCtrl->InitInServer(OwnElemId);

	return true;
}

int32 ACWPawn::GetOwnElemIdByCfg()
{
	const FCWPawnDataStruct* PawnData = FCWCfgUtils::GetPawnData(this, PawnId);
	return PawnData ? PawnData->OwnElemId : INDEX_NONE;
}

UCWPhysicsSystemCtrl* ACWPawn::GetPhysicsSysCtrl()
{
	return PhysicsSysCtrl;
}

FCWPhysicsSysData ACWPawn::GetPhysicsSysData()
{
	FCWPhysicsSysData OutData;
	if (const FCWPawnDataStruct* PawnData = FCWCfgUtils::GetPawnData(this, PawnId))
	{
		OutData.InitByPawnData(PawnData);
	}
	return OutData;
}

bool ACWPawn::InitPhysicsSysData()
{
	// Close Physics Sys
	//return true;

	FCWPhysicsSysData NewPhysicsSysData = GetPhysicsSysData();
	if (!NewPhysicsSysData.IsValidExecPhysicsSysData() || IsValidCompnent(PhysicsSysCtrl))
	{
		//CWG_WARNING(">> %s::InitPhysicsSysData, Fail! PhysicsSysCtrl[%s] already init. NewPhysicsSysData[%s].", 
			//*GetName(), *CWG_NAME(PhysicsSysCtrl), *NewPhysicsSysData.ToDebugString());
		return false;
	}

	UClass* TempleteClass = FCWCfgUtils::GetAssetClass<UClass>(this, FCWCommClassKey::BP_PhysicsSysCtrl);
	if (nullptr == TempleteClass)
	{
		CWG_WARNING(">> %s::InitPhysicsSysData, Fail! BP_PhysicsSysCtrl is invalid!!!", *GetName());
		return false;
	}

	PhysicsSysCtrl = NewObject<UCWPhysicsSystemCtrl>(this, TempleteClass);
	check(PhysicsSysCtrl);

	AddOwnedComponent(PhysicsSysCtrl);
	PhysicsSysCtrl->RegisterComponent();
	PhysicsSysCtrl->SetIsReplicated(true);
	PhysicsSysCtrl->InitInServer(NewPhysicsSysData);

	return true;
}

UCWTalentSystemCtrl* ACWPawn::GetTalentSysCtrl()
{
	return TalentSysCtrl;
}

bool ACWPawn::InitTalentSysData()
{
	// Close Talent Sys
	return true;

	if (!IsPawnType(ECWPawnType::Character) || IsValidCompnent(TalentSysCtrl))
	{
		//CWG_WARNING(">> %s::InitTalentSysData, Fail! TalentSysCtrl[%s] already init.", *GetName(), *CWG_NAME(TalentSysCtrl));
		return false;
	}

	TalentSysCtrl = NewObject<UCWTalentSystemCtrl>(this/*, TempleteClass*/);
	check(TalentSysCtrl);

	AddOwnedComponent(TalentSysCtrl);
	TalentSysCtrl->RegisterComponent();
	TalentSysCtrl->SetIsReplicated(true);
	TalentSysCtrl->InitInServer(1008611);

	return true;
}

UCWStatisticsSystemCtrl* ACWPawn::GetStatisticsSysCtrl()
{
	return StatisticsSysCtrl;
}

const TMap<ECWStatisticsType, int32> ACWPawn::GetStatisticsSysMapData()
{
	return IsValidCompnent(StatisticsSysCtrl) ? StatisticsSysCtrl->GetMapStatisticsData() : TMap<ECWStatisticsType, int32>();
}

bool ACWPawn::InitStatisticsSysData()
{
	// Close Statistics Sys
	//return true;

	if (!IsPawnType(ECWPawnType::Character) || IsValidCompnent(StatisticsSysCtrl))
	{
		//CWG_WARNING(">> %s::InitStatisticsSysData, Fail! StatisticsSysCtrl[%s] already init.", *GetName(), *CWG_NAME(StatisticsSysCtrl));
		return false;
	}

	StatisticsSysCtrl = NewObject<UCWStatisticsSystemCtrl>(this/*, TempleteClass*/);
	check(StatisticsSysCtrl);

	AddOwnedComponent(StatisticsSysCtrl);
	StatisticsSysCtrl->RegisterComponent();
	StatisticsSysCtrl->SetIsReplicated(true);
	StatisticsSysCtrl->InitInServer();

	return true;
}

void ACWPawn::UpdateShadowSKCompTransform(const FVector InWorldLocation)
{
	if (nullptr != ShadowSkeletalMeshComponent)
	{
		std::list<CWPEGrid> PathNodes = PathExplorer.GetPath();
		if (PathNodes.size() >= 2)
		{
			//FVector CurDir = PathNodes.back().pos - PathNodes[PathNodes.size() - 2].pos;
			FVector a = PathNodes.back().pos;
			PathNodes.pop_back();
			FVector b = PathNodes.back().pos;
			FVector CurDir = a - b;
			if (FMath::Abs(CurDir.SizeSquared()) > 0.0001f)
			{
				FRotator CurRotation = CurDir.Rotation();
				CurRotation.Yaw -= 90.0f;
				ShadowSkeletalMeshComponent->SetVisibility(true);
				ShadowSkeletalMeshComponent->SetWorldLocation(InWorldLocation);
				ShadowSkeletalMeshComponent->SetWorldRotation(CurRotation);
			}
		}
		else
		{
			ShowShadowVisible(false);
		}
	}
}
