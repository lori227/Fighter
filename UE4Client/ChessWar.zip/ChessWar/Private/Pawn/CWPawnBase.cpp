﻿
#include "CWPawnBase.h"


ACWPawnBase::ACWPawnBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}