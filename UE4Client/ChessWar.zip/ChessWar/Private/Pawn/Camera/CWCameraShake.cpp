
#include "CWCameraShake.h"


UCWCameraShake::UCWCameraShake(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWCameraShake::~UCWCameraShake()
{
}