#include "CWAvatarComponent.h"
#include "CWCfgManager.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWAvatarComponent, All, All);


UCWAvatarComponent::UCWAvatarComponent(const FObjectInitializer& objectInitializer)
	: Super(objectInitializer)
{
	MasterMeshComponent = nullptr;
}


void UCWAvatarComponent::BeginPlay()
{
	Super::BeginPlay();
}


void UCWAvatarComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

bool UCWAvatarComponent::SetMasterSkeletalMeshComponent(USkeletalMeshComponent* ParamMasterMeshComponent)
{
	MasterMeshComponent = ParamMasterMeshComponent;
	return true;
}


USkeletalMeshComponent* UCWAvatarComponent::GetMasterSkeletalMeshComponent()
{
	return MasterMeshComponent;
}

USkeletalMeshComponent* UCWAvatarComponent::GetPartMesh(ECWAvatarPart ParamPart)
{
	USkeletalMeshComponent** TempValue = SubMeshes.Find(ParamPart);
	if (TempValue != nullptr && (*TempValue) != nullptr)
	{
		return *TempValue;
	}
	
	AActor* TempOwner = GetOwner();
	FString strPart = FString::FromInt((int32)ParamPart);
	USkeletalMeshComponent* SubMesh = NewObject<USkeletalMeshComponent>(TempOwner, FName(*strPart));
	SubMesh->AlwaysLoadOnClient = true;
	SubMesh->AlwaysLoadOnServer = true;
	SubMesh->bOwnerNoSee = false;
	SubMesh->SetupAttachment(this);
	SubMesh->RegisterComponent();

	SubMeshes.Add(ParamPart, SubMesh);
	return SubMesh;
}

bool UCWAvatarComponent::ChangePart(ECWAvatarPart ParamPart, FString ParamStrAvatarPart, FString ParamStrAvatarPartMaterial, bool ParamIsChangeAnimInstance, FString ParamStrAnimInstance)
{
	USkeletalMeshComponent* PartMesh = GetPartMesh(ParamPart);
	if (PartMesh == nullptr)
	{
		UE_LOG(LogCWAvatarComponent, Error, TEXT("GetPartMesh fail, ParamPart:%d."), (int32)ParamPart);
		return false;
	}

	FString strSubMesh = ParamStrAvatarPart;
	USkeletalMesh* subMesh = LoadObject<USkeletalMesh>(nullptr, *strSubMesh, nullptr);
	if (subMesh == nullptr)
	{
		UE_LOG(LogCWAvatarComponent, Error, TEXT("LoadObject fail, subMesh:%s"), *strSubMesh);
		return false;
	}

	PartMesh->SetSkeletalMesh(subMesh);


	//FString strMaterial = TEXT("MaterialInstanceConstant'/Game/character_customizer/apparel/male/upperbody_tshirt/tshirt_white_main.tshirt_white_main'");
	FString strMaterial = ParamStrAvatarPartMaterial;
	UMaterialInterface* subMaterial = LoadObject<UMaterialInstanceConstant>(nullptr, *strMaterial, nullptr);
	//UMaterialInstanceDynamic::Create(, this);
	if (subMaterial == nullptr)
	{
		UE_LOG(LogCWAvatarComponent, Error, TEXT("LoadObject fail, material:%s"), *strMaterial);
		return false;
	}
	PartMesh->SetMaterial(0, subMaterial);

	PartMesh->AttachToComponent(MasterMeshComponent, FAttachmentTransformRules::KeepRelativeTransform);
	PartMesh->SetMasterPoseComponent(MasterMeshComponent, true);

	if (ParamIsChangeAnimInstance)
	{
		FString strAnimInstance = ParamStrAnimInstance;
		UClass* AnimInstClass = LoadClass<UAnimInstance>(nullptr, *strAnimInstance);
		//UClass* AnimInstClass = FCWCfgUtils::GetPawnAssetClass(this, ParamStrAnimInstance);
		if (AnimInstClass != nullptr)
		{
			PartMesh->SetAnimInstanceClass(AnimInstClass);
		}
		else
		{
			UE_LOG(LogCWAvatarComponent, Error, TEXT("GetPartMesh fail, ParamPart:%d, ParamStrAnimInstance:%s."), (int32)ParamPart, *ParamStrAnimInstance);
			return false;
		}
	}

	return true;
}
