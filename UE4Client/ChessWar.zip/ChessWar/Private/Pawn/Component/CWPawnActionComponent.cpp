#include "CWPawnActionComponent.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyAffectorDataRef.h"
#include "CWComDef.h"
#include "CWPawn.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnActionComponent, All, All);

UCWPawnActionComponent::UCWPawnActionComponent(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bReplicates = true;
}

void UCWPawnActionComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	//DOREPLIFETIME(UCWPawnActionComponent, PreState);
	//DOREPLIFETIME(UCWPawnActionComponent, CurState);
	//DOREPLIFETIME(UCWPawnActionComponent, NextState);
	//DOREPLIFETIME(UCWPawnActionComponent, NextActionData);
}

void UCWPawnActionComponent::SetupAction()
{
	ArrayActions.Reserve((int)ECWPawnActionState::Max);
	for (int i = 0; i < (int)ECWPawnActionState::Max; ++i)
	{
		ArrayActions.Add(nullptr);
	}
	ArrayActions[(int)ECWPawnActionState::Idle] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionIdleState>());
	ArrayActions[(int)ECWPawnActionState::BeHit] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionBeHitState>());
	ArrayActions[(int)ECWPawnActionState::ForceMove] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionForceMoveState>());
	ArrayActions[(int)ECWPawnActionState::Dizziness] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionDizzinessState>());
	ArrayActions[(int)ECWPawnActionState::Die] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionDieState>());
	ArrayActions[(int)ECWPawnActionState::Death] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionDeathState>());
	ArrayActions[(int)ECWPawnActionState::MoveToDest] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionMoveToDestState>());
	ArrayActions[(int)ECWPawnActionState::NormalAttack] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionNormalAttackState>());
	ArrayActions[(int)ECWPawnActionState::CastSkillToPawn] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionCastSkillToPawnState>());
	ArrayActions[(int)ECWPawnActionState::CounterAttack] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionCounterAttackState>());
	ArrayActions[(int)ECWPawnActionState::End] = (UCWPawnActionStateBase*)(NewObject<UCWPawnActionEndState>());

	ArrayActions[(int)ECWPawnActionState::Idle]->Init(this, ECWPawnActionState::Idle);
	ArrayActions[(int)ECWPawnActionState::BeHit]->Init(this, ECWPawnActionState::BeHit);
	ArrayActions[(int)ECWPawnActionState::ForceMove]->Init(this, ECWPawnActionState::ForceMove);
	ArrayActions[(int)ECWPawnActionState::Dizziness]->Init(this, ECWPawnActionState::Dizziness);
	ArrayActions[(int)ECWPawnActionState::Die]->Init(this, ECWPawnActionState::Die);
	ArrayActions[(int)ECWPawnActionState::Death]->Init(this, ECWPawnActionState::Death);
	ArrayActions[(int)ECWPawnActionState::MoveToDest]->Init(this, ECWPawnActionState::MoveToDest);
	ArrayActions[(int)ECWPawnActionState::NormalAttack]->Init(this, ECWPawnActionState::NormalAttack);
	ArrayActions[(int)ECWPawnActionState::CastSkillToPawn]->Init(this, ECWPawnActionState::CastSkillToPawn);
	ArrayActions[(int)ECWPawnActionState::CounterAttack]->Init(this, ECWPawnActionState::CounterAttack);
	ArrayActions[(int)ECWPawnActionState::End]->Init(this, ECWPawnActionState::End);

	
	UCWPawnActionDataForEnd* TempEndData = (UCWPawnActionDataForEnd*)(NewObject<UCWPawnActionDataForEnd>());
	TempEndData->ActionId = ECWPawnActionState::End;
	TempEndData->OldActionState = ECWPawnActionState::None;
	TempEndData->bIsTriggerEvent = false;
	TempEndData->bIsForceToEnd = false;
	InitActionState(ECWPawnActionState::End, TempEndData);
}

void UCWPawnActionComponent::InitActionState(ECWPawnActionState ParamActionState, UCWPawnActionData* ParamActionData)
{
	CurState = ParamActionState;
	NextState = ECWPawnActionState::None;
	PreState = ECWPawnActionState::None;

	ECWPawnActionStateChange TempStartResult = GetCurStateInstance()->OnStart(ParamActionData);
	check(TempStartResult == ECWPawnActionStateChange::SUCCESS);
}

ECWPawnActionState UCWPawnActionComponent::GetPreState()
{
	return PreState;
}

ECWPawnActionState UCWPawnActionComponent::GetCurState()
{
	return CurState;
}

ECWPawnActionState UCWPawnActionComponent::GetNextState()
{
	return NextState;
}

UCWPawnActionStateBase*	UCWPawnActionComponent::GetCurStateInstance()
{
	if (!ArrayActions.IsValidIndex((int)CurState))
	{
		//UE_LOG(LogCWPawnActionComponent, Error, TEXT("UCWPawnActionComponent::GetCurStateInstance fail. CurState:%d."), (int32)CurState);
		return nullptr;
	}

	UCWPawnActionStateBase* TempCurStateInstance = ArrayActions[(int)CurState];
	if (TempCurStateInstance == nullptr)
	{
		UE_LOG(LogCWPawnActionComponent, Error, TEXT("UCWPawnActionComponent::GetCurStateInstance, TempCurStateInstance == nullptr. CurState:%d."), (int32)CurState);
		return nullptr;
	}

	return TempCurStateInstance;
}

void UCWPawnActionComponent::OnAnimFinish(int32 RoundIndex)
{
	UCWPawnActionStateBase* TempCurActionState = GetCurStateInstance();
	check(TempCurActionState);
	TempCurActionState->OnAnimFinish(RoundIndex);
}

ACWPawn* UCWPawnActionComponent::GetParentPawn()
{
	ACWPawn* TempOwnerPawn = Cast<ACWPawn>(GetOwner());
	check(TempOwnerPawn);
	return TempOwnerPawn;
}

void UCWPawnActionComponent::StateProcess(float DeltaTime)
{
	UCWPawnActionStateBase* TempCurActionState = GetCurStateInstance();
	if (TempCurActionState == nullptr)
		return;

	check(TempCurActionState);
	ECWPawnActionStateProcess TempStateProcessResult = TempCurActionState->OnProcess(DeltaTime);
	if (TempStateProcessResult == ECWPawnActionStateProcess::HOLD)
		return;

	bool bCommitStateChange = false;
	if (TempStateProcessResult == ECWPawnActionStateProcess::END)
	{
		if (GetNextState() == ECWPawnActionState::None)
		{
			NextActionData = GetParentPawn()->GetIdleOrEndStateForNextState(NextState);
		}

		bCommitStateChange = true;
	}
	else if (TempStateProcessResult == ECWPawnActionStateProcess::SUSPEND)
	{
		if (GetNextState() != ECWPawnActionState::None && NextActionData != nullptr)
			bCommitStateChange = true;
	}
	else
	{
		UE_LOG(LogCWPawnActionComponent, Error, TEXT("UCWPawnActionComponent::StateProcess. TempStateProcessResult:%d."), (int)TempStateProcessResult);
		return;
	}


	if (bCommitStateChange)
	{
		ECWPawnActionStateChange TempCommitResult = CommitChangeState();
		if (TempCommitResult == ECWPawnActionStateChange::FAILED)
		{
			NextActionData = GetParentPawn()->GetIdleOrEndStateForNextState(NextState);
			ECWPawnActionStateChange rt = CommitChangeState();
			check(rt == ECWPawnActionStateChange::SUCCESS);
		}
	}
}

ECWPawnActionStateChange UCWPawnActionComponent::CommitChangeState()
{
	UCWPawnActionStateBase* TempCurState = GetCurStateInstance();
	check(TempCurState);

	if (NextActionData != nullptr && TempCurState->CanTranstion(NextActionData) == false)
	{
		UE_LOG(LogCWPawnActionComponent, Error, TEXT("UCWPawnActionComponent::CommitChangeState, false, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, CurState->GetActionId:%d, NextState:%d."), (int)GetParentPawn()->GetCampTag(), (int)GetParentPawn()->GetCampControllerIndex(), (int)GetParentPawn()->GetControllerPawnIndex(), (int)TempCurState->GetActionId(), (int)NextState);
		return ECWPawnActionStateChange::NONE;
	}

	TempCurState->OnEnd();
	PreState = CurState;
	CurState = NextState;
	NextState = ECWPawnActionState::None;

	UCWPawnActionStateBase* TempNewState = GetCurStateInstance();
	check(TempNewState);

	ECWPawnActionStateChange TempStartResult = TempNewState->OnStart(NextActionData);
	NextActionData = nullptr;
	return TempStartResult;
}

bool UCWPawnActionComponent::SetNextState(ECWPawnActionState ParamNextState, UCWPawnActionData* ParamNextActionData)
{
	check((int)ParamNextState != (int)ECWPawnActionState::None);
	check((int)ParamNextState < (int)ECWPawnActionState::Max);

	UCWPawnActionStateBase* TempCurState = GetCurStateInstance();
	check(TempCurState);

	if (TempCurState->CanTranstion(ParamNextActionData) == false)
	{
		UE_LOG(LogCWPawnActionComponent, Error, TEXT("UCWPawnActionComponent::StateProcess, false, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, CurState->GetActionId:%d, NextState:%d."), (int)GetParentPawn()->GetCampTag(), (int)GetParentPawn()->GetCampControllerIndex(), (int)GetParentPawn()->GetControllerPawnIndex(), (int)TempCurState->GetActionId(), (int)ParamNextState);
		return false;
	}

	NextState = ParamNextState;
	NextActionData = ParamNextActionData;
	UE_LOG(LogCWPawnActionComponent, Log, TEXT("UCWPawnActionComponent::StateProcess, true, CampTag:%d, CampControllerIndex:%d, ControllerPawnIndex:%d, CurState->GetActionId:%d, NextState:%d."), (int)GetParentPawn()->GetCampTag(), (int)GetParentPawn()->GetCampControllerIndex(), (int)GetParentPawn()->GetControllerPawnIndex(), (int)TempCurState->GetActionId(), (int)ParamNextState);
	return true;
}




