﻿#include "CWPawnBattlePropertyComponent.h"
#include "CWBattlePropertySetRef.h"
#include "CWBattlePropertyAffectorDataRef.h"
#include "CWComDef.h"
#include "CWPawn.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPawnBattlePropertyComponent, All, All);

UCWPawnBattlePropertyComponent::UCWPawnBattlePropertyComponent(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bReplicates = true;
}

void UCWPawnBattlePropertyComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UCWPawnBattlePropertyComponent, CurMaxTheoreticalPropertySet);
	DOREPLIFETIME(UCWPawnBattlePropertyComponent, CurPropertySet);
	DOREPLIFETIME(UCWPawnBattlePropertyComponent, PropertySetBase);
	DOREPLIFETIME(UCWPawnBattlePropertyComponent, ArrayPropertyAffectorData);
}

bool UCWPawnBattlePropertyComponent::IsInServer() const
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn || !Pawn->GetWorld())
	{
		return false;
	}

	if (Pawn->Role == ROLE_Authority)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool UCWPawnBattlePropertyComponent::IsMyClientBattleProperty() const
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn || !Pawn->GetWorld())
	{
		return false;
	}

	if (Pawn->Role == ROLE_AutonomousProxy)
	{
		return true;
	}
	else
	{
		return false;
	}
}


bool UCWPawnBattlePropertyComponent::IsOtherClientBattleProperty() const
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn || !Pawn->GetWorld())
	{
		return false;
	}

	if (Pawn->Role == ROLE_SimulatedProxy)
	{
		return true;
	}
	else
	{
		return false;
	}
}

const FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetPropertySetBase() const
{
	return PropertySetBase;
}

FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetPropertySetBase()
{
	return PropertySetBase;
}

const FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetCurMaxTheoreticalPropertySet() const
{
	return CurMaxTheoreticalPropertySet;
}

FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetCurMaxTheoreticalPropertySet()
{
	return CurMaxTheoreticalPropertySet;
}

const FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetCurPropertySet() const
{
	return CurPropertySet;
}

FCWBattlePropertySet& UCWPawnBattlePropertyComponent::GetCurPropertySet()
{
	return CurPropertySet;
}

const TArray<FCWBattlePropertyAffectorData>& UCWPawnBattlePropertyComponent::GetArrayPropertyAffectorData() const
{
	return ArrayPropertyAffectorData;
}


TArray<FCWBattlePropertyAffectorData>& UCWPawnBattlePropertyComponent::GetArrayPropertyAffectorData()
{
	return ArrayPropertyAffectorData;
}

bool UCWPawnBattlePropertyComponent::RecalculateCurMaxTheoreticalPropertySet()
{
	if (!IsInServer())
	{
		return false;
	}

	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Attack);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::PhysicalDefence);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::MagicDefence);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Health);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Energy);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Talent);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Move);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::CriticalDamageFactor);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::CriticalHitRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::AttackSpeed);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::Speed);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::HitRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::AvoidanceRate);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::BlockRate);

	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::DefincePosture);
	RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty::FinalDamage);

	return true;
}

bool UCWPawnBattlePropertyComponent::RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty ParamBattleProperty)
{
	if (!IsInServer())
	{
		return false;
	}

	//计算基础属性
	float PropertyValueBase = PropertySetBase.GetPropertyByFloat(ParamBattleProperty);

	//Buff加成属性
	float PropertyBuffValue = 0.0f;
	for (int32 i = 0; i < ArrayPropertyAffectorData.Num(); ++i)
	{
		FCWBattlePropertyAffectorData& TempAffectorData = ArrayPropertyAffectorData[i];
		if (TempAffectorData.AffectBattlePropertyType == ParamBattleProperty &&
			TempAffectorData.AffectType == ECWPropertyAffectorDataAffectType::Persistent)
		{
			PropertyBuffValue += TempAffectorData.GetResultValue(PropertyValueBase);
		}
	}

	float CurMaxTheoreticalProperty = PropertyValueBase + PropertyBuffValue;
	CurMaxTheoreticalPropertySet.SetProperty<float>(ParamBattleProperty, CurMaxTheoreticalProperty);
	return true;
}

void UCWPawnBattlePropertyComponent::OnRep_ChangePropertySetBase(const FCWBattlePropertySet OldPropertySet)
{
	//CWG_ERROR(">>> %s::OnRep_ChangePropertySetBase, << PropertySetBase >> (%s)", *GetName(), *GetOwner()->GetName());
}

void UCWPawnBattlePropertyComponent::OnRep_ChangePropertySetCur(const FCWBattlePropertySet OldPropertySet)
{
	ACWPawn* OwnerP = Cast<ACWPawn>(GetOwner());
	if (nullptr != OwnerP)
	{
		OwnerP->OnPropertySetCurInClient(OldPropertySet);
	}
}

void UCWPawnBattlePropertyComponent::OnRep_ChangePropertySetMax(const FCWBattlePropertySet OldPropertySet)
{
	ACWPawn* OwnerP = Cast<ACWPawn>(GetOwner());
	if (nullptr != OwnerP)
	{
		OwnerP->OnPropertySetMaxInClient(OldPropertySet);
	}
}
