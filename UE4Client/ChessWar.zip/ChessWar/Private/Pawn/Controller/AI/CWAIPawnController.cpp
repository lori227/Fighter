#include "CWAIPawnController.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWAIPawnController, All, All);

ACWAIPawnController::ACWAIPawnController(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}