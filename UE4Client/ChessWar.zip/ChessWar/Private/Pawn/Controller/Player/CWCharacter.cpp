#include "CWCharacter.h"
#include "ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

ACWCharacter::ACWCharacter(const FObjectInitializer& ObjectInitializer) 
	:Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	bReplicates = true;
	bBlockInput = false;
	
	//UStaticMeshComponent* StaticMesComponenth = this->FindComponentByClass<UStaticMeshComponent>();
	/*if (GetMesh())
		GetMesh()->SetEnableGravity(false);
	if (GetCapsuleComponent())
		GetCapsuleComponent()->SetEnableGravity(false);
	if (GetCharacterMovement())
		GetCharacterMovement()->bApplyGravityWhileJumping = false;*/

	SpringArm = ObjectInitializer.CreateDefaultSubobject<USpringArmComponent>(this, TEXT("SpringArmCompent"));
	SpringArm->SetupAttachment(GetRootComponent());
	//SpringArm->SetWorldLocationAndRotation(FVector(1395.0f, -1010.0f, 830.0f), FRotator(-45.0f, 180.0f, 0.0f));
	//SpringArm->SetWorldLocationAndRotation(FVector(0.0f, 0.0f, 0.0f), FRotator(-45.0f, 180.0f, 0.0f));
	//SpringArm->TargetArmLength = 300.0f; 
	//SpringArm->bEnableCameraLag = false;
	//SpringArm->bDoCollisionTest = false;

	Camera = ObjectInitializer.CreateDefaultSubobject<UCameraComponent>(this, TEXT("Camera"));
	Camera->SetupAttachment(SpringArm);
}


void ACWCharacter::BeginPlay()
{
	Super::BeginPlay();
}


void ACWCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}