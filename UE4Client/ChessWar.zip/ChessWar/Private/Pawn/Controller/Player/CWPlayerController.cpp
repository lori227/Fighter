﻿
#include "CWPlayerController.h"

#include "Engine/Player.h"
#include "Templates/SharedPointer.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "GameFramework/SpringArmComponent.h"
#include <string>
#include <sstream>

#include "CWMap.h"
#include "CWPawn.h"
#include "CWUIUtil.h"
#include "CWMapTile.h"
#include "CWFuncLib.h"
#include "CWFSMState.h"
#include "CWGameMode.h"
#include "CWCfgUtils.h"
#include "CWUIManager.h"
#include "CWBattleFSM.h"
#include "CWPawnStart.h"
#include "CWGameState.h"
#include "CWCameraPawn.h"
#include "CWSimpleActor.h"
#include "CWDungeonTile.h"
#include "CWSplineActor.h"
#include "CWPlayerState.h"
#include "CWDungeonItem.h"
#include "CWPawnInputFSM.h"
#include "CWPawnActionFSM.h"
#include "CWClientConstData.h"
#include "CWUIFightWindow.h"
#include "CWMapTileInputFSM.h"
#include "CWBattleCalculate.h"
#include "CWBattleFightingFSM.h"
#include "CWPawnActionToIdleEvent.h"
#include "CWPawnInputWaitingEvent.h"
#include "CWRandomDungeonGenerator.h"
#include "CWPawnInputSelectedEvent.h"
#include "CWPawnInputLeftMouseEvent.h"
#include "CWPawnInputLeftMouseUpEvent.h"
#include "CWPawnInputReadyToMoveEvent.h"
#include "CWMapTileInputLeftMouseUpEvent.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWUIPawnWidget.h"
#include "CWNetPlayerDataManager.h"
#include "CWNetPlayerData.h"
#include "CWUtils.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWPlayerController, All, All);

ACWPlayerController::ACWPlayerController(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	bReplicates = true;
	bBlockInput = false;

	IsCanMoveCamera = false;
	IsCanYawCamera = false;

	OldDownPawn = nullptr;
	DownPawn = nullptr;
	LongDownTime = 0.0f;
	OldDownTile = nullptr;
	DownTile = nullptr;
	PressTile = nullptr;
	OldPressTile = nullptr;
	PressReadyToDestTile = -1;

	bIsInitInClient = false;
	bIsDungeonEndInServer = false;

	LastCursorActor = nullptr;
}

void ACWPlayerController::BeginPlay()
{
	Super::BeginPlay();
	
	if (IsInServer())
	{
		if (ACWGameMode* const CWGM = Cast<ACWGameMode>(GetWorld()->GetAuthGameMode()))
		{
			TScriptDelegate<> MyDelegate;
			MyDelegate.BindUFunction(this, FName("RespondBattleAfterMapSetupEventInServer"));
			CWGM->OnBattleAfterSetupMapEventInServer.AddUnique(MyDelegate);
		}
	}
	else
	{
		if (IsMyClientPlayerController())
		{
			ACWGameState* MyGameState = GetGameState<ACWGameState>();
			check(MyGameState);
			TScriptDelegate<> MyDelegate;
			MyDelegate.BindUFunction(this, FName("RespondBattleStateChangedEventInClient"));
			MyGameState->OnBattleStateChangedEventInClient.AddUnique(MyDelegate);
		}
	}
}

void ACWPlayerController::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWPlayerController, bReadyFinished);
	DOREPLIFETIME(ACWPlayerController, PlayerNetData);
	DOREPLIFETIME(ACWPlayerController, NetPlayerUniqueId);
	DOREPLIFETIME(ACWPlayerController, PeripheralNetId);
	DOREPLIFETIME(ACWPlayerController, DungeonId);
	DOREPLIFETIME(ACWPlayerController, ExtraPawnDatas);
}

void ACWPlayerController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (IsMyClientPlayerController())
	{
		ACWGameState* GameState = GetGameState<ACWGameState>();
		if (GameState != nullptr)
		{
			switch (GameState->GetCurBattleState())
			{
			case ECWBattleState::Ready:
				OnTickLeftMousePressInReady(DeltaTime);
				break;
			case ECWBattleState::Fighting:
				OnTickLeftMousePressInFighting(DeltaTime);
				break;
			}
		}
	}

	if (IsLocalPlayerController())
	{
		TickLeftMousePressEvt(DeltaTime);
	}
}

void ACWPlayerController::OnRep_PlayerState()
{
	Super::OnRep_PlayerState();

	UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::OnRep_PlayerState..................................."));

	//InitInClient();

	bIsInitInClient = true;

	OnAfterPlayerControllerSetupInClient.Broadcast();
}

void ACWPlayerController::InitInClient()
{
	if (IsInServer())
		return;
}

void ACWPlayerController::MoveForward(float AxisValue)
{
	MovementInput.Y = FMath::Clamp<float>(AxisValue, -1.0f, 1.0f);

#if PLATFORM_ANDROID
	CWG_LOG(">> CWPC::MoveForward, AxisValue[%f].", AxisValue);
	//GEngine->AddOnScreenDebugMessage(INDEX_NONE, 0.0f, FColor::Green,
			//FString::Printf(TEXT(">> CWPC::MoveForward, AxisValue[%f]."), AxisValue), false);
#endif

	// 滑动更新
	//OnSwipeUpdate(GetMousePoint());
}

void ACWPlayerController::MoveRight(float AxisValue)
{
	MovementInput.X = FMath::Clamp<float>(AxisValue, -1.0f, 1.0f);

#if PLATFORM_ANDROID
	CWG_LOG(">> CWPC::MoveRight, AxisValue[%f].", AxisValue);
	//GEngine->AddOnScreenDebugMessage(INDEX_NONE, 0.0f, FColor::Green,
		//FString::Printf(TEXT(">> CWPC::MoveRight, AxisValue[%f]."), AxisValue), false);
#endif

	// 滑动更新
	//OnSwipeUpdate(GetMousePoint());
}

void ACWPlayerController::YawCamera(float AxisValue)
{
	CameraInput.X = AxisValue;
}

void ACWPlayerController::ProcessPlayerInput(const float DeltaTime, const bool bGamePaused)
{
	// 滑动更新
	OnSwipeUpdate(GetMousePoint());

	// 摄像机旋转更新
	OnCameraRotationUpdate(DeltaTime);

	Super::ProcessPlayerInput(DeltaTime, bGamePaused);
}

void ACWPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	// Mouse
	InputComponent->BindAction("LeftMouse", IE_Pressed, this, &ACWPlayerController::OnLeftMouseDown);
	InputComponent->BindAction("LeftMouse", IE_Released, this, &ACWPlayerController::OnLeftMouseUp);
	InputComponent->BindAction("LeftMouse", IE_Repeat, this, &ACWPlayerController::OnLeftMouseRepeat);
	InputComponent->BindAction("LeftMouse", IE_DoubleClick, this, &ACWPlayerController::OnLeftMouseDoubleClick);
	InputComponent->BindAction("LeftMouse", IE_Axis, this, &ACWPlayerController::OnLeftMouseAxis);

	InputComponent->BindAction("RightMouse", IE_Pressed, this, &ACWPlayerController::OnRightMouseDown);
	InputComponent->BindAction("RightMouse", IE_Released, this, &ACWPlayerController::OnRightMouseUp);

	// Camera
	InputComponent->BindAction("CameraZoomIn", IE_Pressed, this, &ACWPlayerController::CameraZoomIn);
	InputComponent->BindAction("CameraZoomOut", IE_Pressed, this, &ACWPlayerController::CameraZoomOut);

	// Camera
	InputComponent->BindAxis("MoveForward", this, &ACWPlayerController::MoveForward);
	InputComponent->BindAxis("MoveRight", this, &ACWPlayerController::MoveRight);
	InputComponent->BindAxis("YawCamera", this, &ACWPlayerController::YawCamera);
}

void ACWPlayerController::CameraZoomIn()
{
	if (ACWCameraPawn* CamerPawn = GetCameraPawn())
	{
		CamerPawn->ZoomIn();
	}
}

void ACWPlayerController::CameraZoomOut()
{
	if (ACWCameraPawn* CamerPawn = GetCameraPawn())
	{
		CamerPawn->ZoomOut();
	}
}

bool ACWPlayerController::OnSwipeStarted(const FVector2D& SwipePosition)
{
	ResetEndSwipeNow();

	bool bResult = false;
	ACWCameraPawn* CamerPawn = GetCameraPawn();
	if ((nullptr != CamerPawn) && IsValidScreenPoint(SwipePosition))
	{
		// Get intersection point with the plan used to move around
		FHitResult Hit;
		if (GetHitResultAtScreenPosition(SwipePosition, COLLISION_PANCAMERA/*CurrentClickTraceChannel*/, true, Hit))
		{
			// 关闭弹簧臂平滑移动
			//CamerPawn->SpringArm->bEnableCameraLag = false;
			StartSwipeCoords = Hit.ImpactPoint;
			bResult = true;

			//CWG_WARNING("-->> OnSwipeStarted, StartPos[%s] CurPos[%s] InScreenLoc[%s] Actor[%s].",
			//	*StartSwipeCoords.ToString(), *StartSwipeCoords.ToString(), *SwipePosition.ToString(), *Hit.GetActor()->GetName());
		}
	}
	return bResult;
}

bool ACWPlayerController::OnSwipeUpdate(const FVector2D& SwipePosition)
{
	bool bResult = false;
	ACWCameraPawn* CamerPawn = GetCameraPawn();
	if ((nullptr != CamerPawn) && IsCanMoveCamera && IsValidScreenPoint(SwipePosition) && !StartSwipeCoords.IsNearlyZero())
	{
		FHitResult Hit;
		if (GetHitResultAtScreenPosition(SwipePosition, COLLISION_PANCAMERA/*CurrentClickTraceChannel*/, true, Hit))
		{
			FVector NewSwipeCoords = Hit.ImpactPoint;
			FVector Delta = StartSwipeCoords - NewSwipeCoords;
			// Flatten Z axis - we are not interested in that.
			Delta.Z = 0.0f;
			if (!Delta.IsNearlyZero())
			{
				FVector NewLoc = CamerPawn->GetActorLocation() + Delta;
				CamerPawn->SetActorLocation(NewLoc, true);	// 增加碰撞
				bResult = true;

				//CWG_WARNING("-->> OnSwipeUpdate, StartPos[%s] CurPos[%s] InScreenLoc[%s] - Delta[%s] Actor[%s].",
					//*StartSwipeCoords.ToString(), *NewSwipeCoords.ToString(), *SwipePosition.ToString(), *Delta.ToString(), *Hit.GetActor()->GetName());
			}
		}
	}
	return bResult;
}

bool ACWPlayerController::OnSwipeReleased(const FVector2D& SwipePosition)
{
	bool bResult = false;
	ResetEndSwipeNow();
	return bResult;
}

void ACWPlayerController::OnLeftMouseDown()
{
	OnLeftMouseDown_Impl(FVector(GetMousePoint(), 0.f));
}

void ACWPlayerController::OnPressedKeyP()
{
	Super::OnPressedKeyP();

	//SwitchPauseGameInClient();
	//ToggleUIFightWindowShow();
}

void ACWPlayerController::OnPressedKeyTab()
{
	Super::OnPressedKeyTab();

	// 切换视口角度
	if (ACWCameraPawn* CameraPawn = GetCameraPawn())
	{
		CameraPawn->SwitchNextViewAngle();
	}
}

void ACWPlayerController::OnPressedKeyLeftShift()
{
	Super::OnPressedKeyLeftShift();

	// 切换选定棋子
	OnPlayerSwitchSelectedPawn();
}

void ACWPlayerController::OnPressedKeyRightShift()
{
	Super::OnPressedKeyRightShift();

	// 切换选定棋子
	OnPlayerSwitchSelectedPawn();
}

void ACWPlayerController::OnLeftMouseUp()
{
	OnLeftMouseUp_Impl(FVector(GetMousePoint(), 0.f));
}

void ACWPlayerController::OnLeftMouseRepeat()
{
	//CWG_LOG(">> %s::OnLeftMouseRepeat.", *GetName());
}

void ACWPlayerController::OnLeftMouseDoubleClick()
{
	//CWG_LOG(">> %s::OnLeftMouseDoubleClick. Time[%s] ", *GetName(), *FDateTime::Now().ToString());
}

void ACWPlayerController::OnLeftMouseAxis()
{
	//CWG_LOG(">> %s::OnLeftMouseAxis.", *GetName());
}

void ACWPlayerController::OnRightMouseUp()
{
	IsCanYawCamera = false;
	MovementInput.Set(0.f, 0.f);

	ECWBattleState BattleState = GetBattleState();
	switch (BattleState)
	{
	case ECWBattleState::Ready:
	{
		HandleRightMouseUpInReady();
	}break;
	}
}

void ACWPlayerController::OnRightMouseDown()
{
	IsCanYawCamera = true;
	MovementInput.Set(0.f, 0.f);

	ECWBattleState BattleState = GetBattleState();
	switch (BattleState)
	{
	case ECWBattleState::Ready:
	{
		HandleRightMouseDownInReady();
	}break;
	}
}

void ACWPlayerController::OnLeftMouseUp_Impl(const FVector& InScreenLoc /*= FVector::ZeroVector*/)
{
	bLeftMousePress = false;
	IsCanMoveCamera = false;
	MovementInput.Set(0.f, 0.f);

	// 滑动结束
	OnSwipeReleased(FVector2D(InScreenLoc));

	ECWBattleState BattleState = GetBattleState();
	switch (BattleState)
	{
	case ECWBattleState::Ready:
	{
		HandleLeftMouseUpInReady(InScreenLoc);
	}break;
	case ECWBattleState::Fighting:
	{
		HandleLeftMouseUpInFighting(InScreenLoc);
	}break;
	}
}

void ACWPlayerController::OnLeftMouseDown_Impl(const FVector& InScreenLoc /*= FVector::ZeroVector*/)
{
	bLeftMousePress = true;
	IsCanMoveCamera = true;

	// 滑动开始
	OnSwipeStarted(FVector2D(InScreenLoc));

	ECWBattleState BattleState = GetBattleState();
	switch (BattleState)
	{
	case ECWBattleState::Ready:
	{
		HandleLeftMouseDownInReady(InScreenLoc);
	}break;
	case ECWBattleState::Fighting:
	{
		HandleLeftMouseDownInFighting(InScreenLoc);
	}break;
	}
}

void ACWPlayerController::OnTouchStarted(ETouchIndex::Type FingerIndex, FVector InScreenLoc)
{
	//CWG_LOG(">> %s::OnTouchStarted, FingerIndex[%d] InScreenLoc[%s].", *GetName(), (int32)FingerIndex, *InScreenLoc.ToString());

	OnLeftMouseDown_Impl(InScreenLoc);
}

void ACWPlayerController::OnTouchMoved(ETouchIndex::Type FingerIndex, FVector InScreenLoc)
{
	//CWG_LOG(">> %s::OnTouchMoved, FingerIndex[%d] InScreenLoc[%s].", *GetName(), (int32)FingerIndex, *InScreenLoc.ToString());

	// 滑动更新
	if (OnSwipeUpdate(FVector2D(InScreenLoc)))
	{
		FVector Off = InScreenLoc - StartSwipeCoords;
		GEngine->AddOnScreenDebugMessage(INDEX_NONE, 0.0f, FColor::Green,
			FString::Printf(TEXT(">> OnTouchMoved, TouchPos[%s] InScreenLoc[%s] Off[%s]."), 
				*StartSwipeCoords.ToString(), *InScreenLoc.ToString(), *Off.ToString()), false);
	}
}

void ACWPlayerController::OnTouchStopped(ETouchIndex::Type FingerIndex, FVector InScreenLoc)
{
	//CWG_LOG(">> %s::OnTouchStopped, FingerIndex[%d] InScreenLoc[%s].", *GetName(), (int32)FingerIndex, *InScreenLoc.ToString());

	OnLeftMouseUp_Impl(InScreenLoc);
}

void ACWPlayerController::InitInServer()
{
}

ECWCampTag ACWPlayerController::GetCampTag() const
{
	const ACWPlayerState* MyPlayerState = GetCWPlayerState();
	if (MyPlayerState != nullptr)
	{
		return MyPlayerState->GetCampTag();
	}

	return ECWCampTag::None;
}

ECWCampControllerIndex ACWPlayerController::GetCampControllerIndex() const
{
	const ACWPlayerState* MyPlayerState = GetCWPlayerState();
	if (MyPlayerState != nullptr)
	{
		return MyPlayerState->GetCampControllerIndex();
	}

	return ECWCampControllerIndex::None;
}

bool ACWPlayerController::IsInitInClient() const
{
	return bIsInitInClient;
}

FString ACWPlayerController::GetPawnPeripheralNetIdByIndex(int32 ParamIndex)
{
	std::string TempStrPlayerPeripheralNetId(TCHAR_TO_UTF8(*PeripheralNetId));
	std::stringstream a;
	a << TempStrPlayerPeripheralNetId;
	uint64 uint64PlayerPeripheralNetId = 0;
	a >> uint64PlayerPeripheralNetId;

	std::string TempPeripheralNetId(TCHAR_TO_UTF8(*PeripheralNetId));
	std::stringstream b;
	b << TempPeripheralNetId;
	uint64 uint64PeripheralNetId = 0;
	b >> uint64PeripheralNetId;

	UCWNetPlayerData* TempNetPlayerData = UCWGameInstance::GetInstance()->GetNetPlayerDataMgr()->GetNetPlayerData(uint64PlayerPeripheralNetId);
	if (TempNetPlayerData == nullptr)
	{
		UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::GetPawnPeripheralNetIdByIndex Fail. PlayerPeripheralNetId:%s."), *PeripheralNetId);
		return "";
	}

	UCWNetHeroData* TempHeroData = TempNetPlayerData->GetNetHeroDataByIndex(ParamIndex);
	if (TempHeroData == nullptr)
	{
		UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::GetPawnPeripheralNetIdByIndex Fail. PlayerPeripheralNetId:%s, ParamIndex:%d."), *PeripheralNetId, ParamIndex);
		return "";
	}

	std::ostringstream o;
	o << TempHeroData->UUID;
	std::string strId(o.str());
	FString fstringId(strId.c_str());
	return fstringId;
}

void ACWPlayerController::InitExtraNetHeroData()
{
	UCWNetPlayerData* MyNetPlayerData = GetNetPlayerData();
	if (nullptr != MyNetPlayerData)
	{
		const int32 MinGetIndex = MapPawns.Num();
		ExtraPawnDatas = MyNetPlayerData->GetExtraNetHeroData(MinGetIndex);
	}
	CWG_LOG(">> %s::InitExtraNetHeroData, Init[%s]~ ExtraPawnDatas[%d].", 
		*CWG_NAME(this), *BOOL_TO_FSTRING(nullptr != MyNetPlayerData), ExtraPawnDatas.Num());
}

UCWNetPlayerData* ACWPlayerController::GetNetPlayerData()
{
	std::string TempStrPlayerPeripheralNetId(TCHAR_TO_UTF8(*PeripheralNetId));
	std::stringstream a;
	a << TempStrPlayerPeripheralNetId;
	uint64 uint64PlayerPeripheralNetId = 0;
	a >> uint64PlayerPeripheralNetId;

	std::string TempPeripheralNetId(TCHAR_TO_UTF8(*PeripheralNetId));
	std::stringstream b;
	b << TempPeripheralNetId;
	uint64 uint64PeripheralNetId = 0;
	b >> uint64PeripheralNetId;

	UCWNetPlayerData* MyNetPlayerData = UCWGameInstance::GetInstance()->GetNetPlayerDataMgr()->GetNetPlayerData(uint64PlayerPeripheralNetId);
	if (MyNetPlayerData == nullptr)
	{
		CWG_ERROR(">> %s::GetNetPlayerData Fail. PlayerPeripheralNetId:%s.", *CWG_NAME(this), *PeripheralNetId);
	}
	return MyNetPlayerData;
}

void ACWPlayerController::SpawnPawnsByPawnStart()
{
	if (!IsInServer())
		return;

	//--------------------------------------------------------
	ACWGameState* MainGS = GetGameState();
	ACWPlayerState* MyPlayerState = GetPlayerState();
	check(MainGS && MyPlayerState);

	const float ExtPosZ = 10000.0f;
	const int32 MaxSpawnCnt = MainGS->GetDefaultPawnCnt();

	// 生成棋子: 根据ACWPawnStart
	auto GetPredicate = [this](const ACWPawnStart* Obj) -> bool
	{	// 出生点获得限制
		return Obj->IsSameCampAndCtrl(GetCampTag(), GetCampControllerIndex());
	};
	auto SortPredicate = [](const ACWPawnStart& A, const ACWPawnStart& B) -> bool
	{	// 出生点排序
		return A.PawnIndex < B.PawnIndex;
	};
	TArray<ACWPawnStart*> ArrayPawnStart;
	if (UCWFuncLib::GetAllActors<ACWPawnStart>(this, ArrayPawnStart, GetPredicate, SortPredicate) > 0)
	{
		// 生成棋子
		for (auto PawnStart : ArrayPawnStart)
		{
			const int32 NewIndex = MapPawns.Num();
			FString TempPeripheralNetId = GetPawnPeripheralNetIdByIndex(NewIndex);
			if (ACWPawn* TmpPawn = SpawnPawnByPawnStart(PawnStart, TempPeripheralNetId, -1, ExtPosZ))
			{
				if (MaxSpawnCnt > 0 && MapPawns.Num() >= MaxSpawnCnt)
				{	// 最大生成数限制
					break;
				}
			}
		}

		// 初始化额外棋子数据
		InitExtraNetHeroData();
	}
	else
	{
		CWG_WARNING(">> %s::SpawnPawnsByPawnStart, ArrayPawnStart is empty!", *GetName());
	}
}

ACWPawn* ACWPlayerController::SpawnPawnByPawnStart(ACWPawnStart* InPawnStart, const FString& InUniqueNetId, const int32 InExtPawnId, const float InExtPosZ)
{
	if (InUniqueNetId.IsEmpty())
	{
		CWG_WARNING(">> %s::SpawnPawnByPawnStart, InUniqueNetId[%s] is invalid!", *CWG_NAME(this), *InUniqueNetId);
		return nullptr;
	}

	UWorld* MyWorld = GetWorld();
	TSubclassOf<ACWPawn> SpawnPawnClass = GetDefaultPawnClass();
	if (nullptr == MyWorld || nullptr == SpawnPawnClass)
	{
		CWG_WARNING(">> %s::SpawnPawnByPawnStart, MyWorld[%s]/SpawnPawnClass[%s] is invalid!", *CWG_NAME(this), *CWG_NAME(MyWorld), *CWG_NAME(SpawnPawnClass));
		return nullptr;
	}

	ECWCampTag TempCampTag = GetCampTag();
	ECWCampControllerIndex TempCampControllerIndex = GetCampControllerIndex();

	if (nullptr != InPawnStart && InPawnStart->IsSameCampAndCtrl(TempCampTag, TempCampControllerIndex))
	{
		//UE_LOG(LogCWPlayerController, Log, TEXT("CampTag:%d, CampControllerIndex:%d, tile:%d, x:%d, y:%d, ActorLocation.X:%f, ActorLocation.Y:%f."), (int32)TempCampTag, (int32)TempCampControllerIndex, InPawnStart->Tile, InPawnStart->X, InPawnStart->Y, InPawnStart->GetActorLocation().X, InPawnStart->GetActorLocation().Y);
		ACWPawn* MyPawn = GetWorld()->SpawnActor<ACWPawn>(SpawnPawnClass);
		if (nullptr != MyPawn)
		{
			MyPawn->PossessedBy(this);
			MyPawn->InitPawnInServer(this, InPawnStart, InUniqueNetId, InExtPawnId, InExtPosZ);

			FCWPawnKey PawnKey(MyPawn->GetCampTag(), MyPawn->GetCampControllerIndex(), MyPawn->GetControllerPawnIndex());
			MapPawns.Add(PawnKey, MyPawn);

			MyPawn->SetTile(InPawnStart->Tile);
			MyPawn->SetupAction();

			TScriptDelegate<> MyDelegate1;
			MyDelegate1.BindUFunction(this, FName("RespondPawnActionEndEventInServer"));
			MyPawn->OnPawnnActionEndEventInServer.AddUnique(MyDelegate1);

			TScriptDelegate<> MyDelegate2;
			MyDelegate2.BindUFunction(this, FName("RespondPawnDieEndEventInServer"));
			MyPawn->OnPawnnDieEndEventInServer.AddUnique(MyDelegate2);

			CWG_LOG("------------------------------ Begin SpawnPawnsByPawnStart ---------------------------------");
			AActor* Owner = MyPawn->GetOwner();
			const AActor* NetOwner = MyPawn->GetNetOwner();
			CWG_LOG(">> MyPawn[%s]: Owner:%s.", *CWG_NAME(MyPawn), *CWG_NAME(Owner));
			CWG_LOG(">> MyPawn[%s]: NetOwner:%s.", *CWG_NAME(MyPawn), *CWG_NAME(NetOwner));
			CWG_LOG(">> MyPawn[%s]: Info:%s.", *CWG_NAME(MyPawn), *MyPawn->ToDebugString());
			CWG_LOG("------------------------------ End   SpawnPawnsByPawnStart ---------------------------------");
			return MyPawn;
		}
	}

	return nullptr;
}

bool ACWPlayerController::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWPlayerController::IsMyClientPlayerController() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWPlayerController::IsOtherClientPlayerController() const
{
	return Role == ROLE_SimulatedProxy;
}

void ACWPlayerController::SetPlayerNetData(const FCWPlayerNetData& ParamPlayerNetData)
{
	PlayerNetData = ParamPlayerNetData;
}

FCWPlayerNetData& ACWPlayerController::GetPlayerNetData()
{
	return PlayerNetData;
}

const FCWPlayerNetData& ACWPlayerController::GetPlayerNetData() const
{
	return PlayerNetData;
}

void ACWPlayerController::SetNetPlayerUniqueId(int32 InUniqueId)
{
	NetPlayerUniqueId = InUniqueId;
}

void ACWPlayerController::SetDungeonId(int32 ParamDungeonId)
{
	DungeonId = ParamDungeonId;
}

int32 ACWPlayerController::GetUniqueId() const
{
	return NetPlayerUniqueId;
}

void ACWPlayerController::SetPeripheralNetId(const FString& ParamPeripheralNetId)
{
	PeripheralNetId = ParamPeripheralNetId;
	
	uint64 uint64PeripheralNetId = FCWUtils::FString2Uint64(PeripheralNetId);
	UCWNetPlayerData* TempPlayerNetData = UCWGameInstance::GetInstance()->GetNetPlayerDataMgr()->GetNetPlayerData(uint64PeripheralNetId);
	if (TempPlayerNetData != nullptr)
	{
		PlayerNetData.Id = FCWUtils::Uint642FString(TempPlayerNetData->Id);
		PlayerNetData.Name = TempPlayerNetData->Name;
		PlayerNetData.ServerId = FCWUtils::Uint642FString(TempPlayerNetData->ServerId);
		PlayerNetData.CampId = (int32)TempPlayerNetData->CampId;

		// 加入玩家数据数组
		ACWGameState* MyGameState = GetGameState();
		if (nullptr != MyGameState)
		{
			MyGameState->AddPlayerDataToArray(PlayerNetData);
		}
	}
	else
	{
		UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::SetPeripheralNetId. GetNetPlayerData fail, PeripheralNetId:%s."), *PeripheralNetId);
	}
}

const FString& ACWPlayerController::GetPeripheralNetId()
{
	return PeripheralNetId;
}

TSubclassOf<ACWPawn> ACWPlayerController::GetDefaultPawnClass()
{
	if (nullptr == DefaultPawnClass)
	{
		UClass* TmpPawnClass = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_CWPawn);
		DefaultPawnClass = TmpPawnClass ? TmpPawnClass : ACWPawn::StaticClass();
	}
	return DefaultPawnClass;
}

bool ACWPlayerController::IsAllPawnActionEndInServer()
{
	bool isThereNoEnd = false;
	for (TMap<FCWPawnKey, ACWPawn*>::TConstIterator iter = MapPawns.CreateConstIterator(); iter; ++iter)
	{
		ACWPawn* MyPawn = iter->Value;
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			if (MyPawn->IsDieOrDeath())
				continue;

			if (MyPawn->IsThinkActionNoEndByCurInstructs())
			{
				isThereNoEnd = true;
				break;
			}
		}
	}

	if (!isThereNoEnd)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsAllPawnArrayActionEmptyInServer()
{
	bool isThereNoEnd = false;
	for (TMap<FCWPawnKey, ACWPawn*>::TConstIterator iter = MapPawns.CreateConstIterator(); iter; ++iter)
	{
		ACWPawn* MyPawn = iter->Value;
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			if (MyPawn->IsDieOrDeath())
				continue;

			if (MyPawn->GetActionQueueCount() > 0)
			{
				isThereNoEnd = true;
				break;
			}
		}
	}

	if (!isThereNoEnd)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsDungeonEndInServer()
{
	return bIsDungeonEndInServer;
}

bool ACWPlayerController::IsAllPawnDieEndInServer()
{
	bool isThereNoDieEnd = false;
	for (TMap<FCWPawnKey, ACWPawn*>::TConstIterator iter = MapPawns.CreateConstIterator(); iter; ++iter)
	{
		ACWPawn* MyPawn = iter->Value;
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			if (!MyPawn->IsDieOrDeath())
			{
				isThereNoDieEnd = true;
				break;
			}
		}
	}

	if (!isThereNoDieEnd)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void ACWPlayerController::ForceActionEndInServer()
{
	for (TMap<FCWPawnKey, ACWPawn*>::TConstIterator iter = MapPawns.CreateConstIterator(); iter; ++iter)
	{
		ACWPawn* MyPawn = iter->Value;
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			MyPawn->ForceActionEndInServer();
		}
	}
}

void ACWPlayerController::ForceActionEndInClient()
{
	this->CancelCurSelectedPawnNoEventInClient();

	ACWMap* MyMap = this->GetMap();
	check(MyMap);
	ACWMapTile* CurSelectedTile = this->GetCurSelectedTile();//可能为空
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* MyPawn = *Iter;
		check(MyPawn);
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			MyPawn->ForceActionEndInClient();

			ACWMapTile* MyMoveBeginTile = MyMap->GetTile(MyPawn->GetMoveBeginTile());//可能为空
			if (MyMoveBeginTile != nullptr &&
				CurSelectedTile != nullptr &&
				MyMoveBeginTile->Tile == CurSelectedTile->Tile)
			{
				this->CancelCurSelectedTileInClient();
			}
		}
	}
}

TMap<FCWPawnKey, ACWPawn*>& ACWPlayerController::GetPawns()
{
	return MapPawns;
}

ACWPlayerState* ACWPlayerController::GetCWPlayerState() const
{
	return Cast<ACWPlayerState>(PlayerState);
}

void ACWPlayerController::ResetEndSwipeNow()
{
	StartSwipeCoords.Set(0.0f, 0.0f, 0.0f);
}

void ACWPlayerController::OnCameraRotationUpdate(const float DeltaTime)
{
	if (ACWCameraPawn* CamerPawn = GetCameraPawn())
	{
		// 滑动摄像机(WASD)
		if (!IsCanYawCamera && StartSwipeCoords.IsNearlyZero() && !MovementInput.IsZero())
		{
			// 把移动输入坐标轴的值每秒缩放100个单位
			MovementInput = MovementInput * CamerPawn->CameraMovementDelta;
			FVector NewLocation = CamerPawn->GetActorLocation();
			NewLocation += CamerPawn->GetActorForwardVector() * MovementInput.X * DeltaTime;
			NewLocation += CamerPawn->GetActorRightVector() * MovementInput.Y * DeltaTime;
			CamerPawn->SetActorLocation(NewLocation, true);		// 增加碰撞
		}

		// 旋转摄像机
		if (IsCanYawCamera && !CameraInput.IsZero())
		{
			FRotator NewRotation = CamerPawn->GetActorRotation();
			NewRotation.Yaw += CameraInput.X * CamerPawn->CameraYawDelta;
			CamerPawn->SetActorRotation(NewRotation);
		}
	}
}

ACWCameraPawn* ACWPlayerController::GetCameraPawn()
{
	ACWCameraPawn* RetValue = Cast<ACWCameraPawn>(GetPawn());
	return RetValue;
}

void ACWPlayerController::HandleLeftMouseDownInReady(const FVector& InScreenLoc)
{
	bool bHit = false;
	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	bHit = GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#elif PLATFORM_ANDROID
	FVector2D ScreenLocation2D(InScreenLoc);
	bHit = GetHitResultAtScreenPosition(ScreenLocation2D, CurrentClickTraceChannel, true, TraceHitResult);
#endif
	if (bHit && nullptr != TraceHitResult.GetActor())
	{
		AActor* HitActor = TraceHitResult.GetActor();
		if(ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor))
		{
			IsCanMoveCamera = true;
			ACWMap* const MainMap = GetMap();
			if (ACWPawn* HitPawn = MainMap ? MainMap->GetPawnByTile(HitTile->Tile).Get() : nullptr)
			{	// 点中地图块有棋子
				if (HitPawn->IsAllowOperate())
				{
					IsCanMoveCamera = false;
					ECWPawnInputState CurInputStateId = HitPawn->GetCurInputFSMStateId();
					FCWPawnInputLeftMouseEvent* LeftMouseEvent = new FCWPawnInputLeftMouseEvent(
						(int32)ECWPawnInputEvent::LeftMouseDown, (int)CurInputStateId, ECWFSMStackOp::Set, HitPawn, this);
					HitPawn->GetInputFSM()->DoEvent(LeftMouseEvent);
					return;
				}
			}
			else if(ACWPawnStart* PawnStart = MainMap ? MainMap->GetPawnStartByTile(HitTile->Tile) : nullptr)
			{	// 点中地图块有己方出生点
				ACWPawn* SelectedPawn = GetSelectedPawn(ECWBattleState::Ready);
				if (nullptr != SelectedPawn && SelectedPawn->IsMyClientPawn() && SelectedPawn->GetTile() != PawnStart->GetTile() &&
					PawnStart->IsSameCampAndCtrl(GetCampTag(), GetCampControllerIndex()) &&
					PawnStart->IsSameCampAndCtrl(SelectedPawn->GetCampTag(), SelectedPawn->GetCampControllerIndex()))
				{
					ServerSwitchPawnPosToPointInReady(SelectedPawn, PawnStart);
				}
			}

			// Clearup
			CancelSelectedPawnInReady();
			CancelSelectedTileInReady();
		}
	}
}

void ACWPlayerController::HandleLeftMouseUpInReady(const FVector& InScreenLoc)
{
	bool bHit = false;
	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	bHit = GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#elif PLATFORM_ANDROID
	FVector2D ScreenLocation2D(InScreenLoc);
	bHit = GetHitResultAtScreenPosition(ScreenLocation2D, CurrentClickTraceChannel, true, TraceHitResult);
#endif
	if (bHit && nullptr != TraceHitResult.GetActor())
	{
		AActor* HitActor = TraceHitResult.GetActor();
		if(ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor))
		{
			ACWMap* const MyMapActor = GetMap();
			ACWPawn* SelectedPawn = GetSelectedPawn(ECWBattleState::Ready);
			auto CheckCanRemovePawn = [/*this, SelectedPawn*/]()
			{
				return false;
				//return (!bReadyFinished && nullptr != SelectedPawn && SelectedPawn->IsMyClientPawn() && SelectedPawn->IsShadowVisible());
			};

			if (ACWPawn* HitPawn = MyMapActor ? MyMapActor->GetPawnByTile(HitTile->Tile).Get() : nullptr)
			{	// 点中地图块有棋子
				if (HitPawn->IsAllowOperate())
				{
					if (HitPawn->IsMyClientPawn())
					{
						ECWPawnInputState CurInputStateId = HitPawn->GetCurInputFSMStateId();
						FCWPawnInputLeftMouseEvent* LeftMouseEvent = new FCWPawnInputLeftMouseEvent(
							(int)ECWPawnInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitPawn, this);
						HitPawn->GetInputFSM()->DoEvent(LeftMouseEvent);
						// 隐藏选定棋子虚影
						ShowSelectedPawnShadow(false);

						return;
					}
				}
				
				if(CheckCanRemovePawn())
				{	// 置出棋子
					ServerRemovePawnFromTile(SelectedPawn->GetTile());
				}
			}
			else if (ACWPawnStart* PawnStart = MyMapActor ? MyMapActor->GetPawnStartByTile(HitTile->Tile) : nullptr)
			{	// 点中地图块有己方出生点
				if (nullptr != SelectedPawn && SelectedPawn->IsMyClientPawn() &&
					PawnStart->IsSameCampAndCtrl(GetCampTag(), GetCampControllerIndex()) &&
					PawnStart->IsSameCampAndCtrl(SelectedPawn->GetCampTag(), SelectedPawn->GetCampControllerIndex()))
				{
					if (SelectedPawn->GetTile() != PawnStart->GetTile())
					{
						ServerSwitchPawnPosToPointInReady(SelectedPawn, PawnStart);
					}
				}
				else if(CheckCanRemovePawn())
				{	// 置出棋子
					ServerRemovePawnFromTile(SelectedPawn->GetTile());
				}
			}
			else if(CheckCanRemovePawn())
			{	// 置出棋子
				ServerRemovePawnFromTile(SelectedPawn->GetTile());
			}
			
			// Clearup
			CancelSelectedPawnInReady();
			CancelSelectedTileInReady();
		}
	}

	// 隐藏选定棋子虚影
	ShowSelectedPawnShadow(false);
}

void ACWPlayerController::HandleRightMouseDownInReady()
{
	bool bHit = false;
	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	bHit = GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#endif
	if (bHit && nullptr != TraceHitResult.GetActor() && !bReadyFinished)
	{
		AActor* HitActor = TraceHitResult.GetActor();
		if (ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor))
		{
			ACWMap* const MyMapActor = GetMap();
			if (ACWPawn* HitPawn = MyMapActor ? MyMapActor->GetPawnByTile(HitTile->Tile).Get() : nullptr)
			{	// 点中地图块有棋子
				if (HitPawn->IsMyClientPawn())
				{
					RightSelectPawnInReady = HitPawn;
				}
			}
		}
	}
}

void ACWPlayerController::HandleRightMouseUpInReady()
{
	bool bHit = false;
	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	bHit = GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#endif
	if (bHit && nullptr != TraceHitResult.GetActor() && !bReadyFinished)
	{
		AActor* HitActor = TraceHitResult.GetActor();
		if (ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor))
		{
			ACWMap* const MyMapActor = GetMap();
			ACWPawn* SelectedPawn = GetSelectedPawn(ECWBattleState::Ready);
			ACWPawn* RightSelectedPawn = GetRightMouseSelectedPawn(ECWBattleState::Ready);
			auto CheckCanRemovePawn = [this, RightSelectedPawn]()
			{
				return (nullptr != RightSelectedPawn && RightSelectedPawn->IsMyClientPawn());
			};

			if (ACWPawn* HitPawn = MyMapActor ? MyMapActor->GetPawnByTile(HitTile->Tile).Get() : nullptr)
			{	// 点中地图块有棋子
				if (RightSelectedPawn == HitPawn && CheckCanRemovePawn())
				{
					if (SelectedPawn == RightSelectedPawn)
					{
						// Clearup
						CancelSelectedPawnInReady();
						CancelSelectedTileInReady();
					}
					// 置出棋子
					ServerRemovePawnFromTile(RightSelectedPawn->GetTile());
				}
			}
		}
	}
	// Clearup
	RightSelectPawnInReady = nullptr;
}

void ACWPlayerController::HandleLeftMouseDownInFighting(const FVector& InScreenLoc)
{
	if (IsInServer())
		return;

	ACWPawn* TempCurSelectedPawn = this->GetCurSelectedPawn();
	if (TempCurSelectedPawn != nullptr)
	{
		const bool bCanMove = TempCurSelectedPawn->CanMoveByCurInstructs();
		const bool bCanNormalAttack = TempCurSelectedPawn->CanNormalAttackByCurInstructs();
		const bool bCanCastSkill = TempCurSelectedPawn->CanCastSkillByCurInstructs();
		ECWPawnInputState TempCurInputFSMState = TempCurSelectedPawn->GetCurInputFSMStateId();
		if ((TempCurInputFSMState == ECWPawnInputState::MoveToDest && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::MoveToAttack && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::MoveToWaitingAttack && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::NormalAttack && bCanNormalAttack) ||
			(TempCurInputFSMState == ECWPawnInputState::CastSkillToTile && bCanCastSkill) ||
			(TempCurInputFSMState == ECWPawnInputState::CastSkillToPawn && bCanCastSkill))
		{
			return;
		}

		if (TempCurSelectedPawn->IsDieOrDeath())
		{
			return;
		}
	}

	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#elif PLATFORM_ANDROID
	FVector2D ScreenLocation2D(InScreenLoc);
	GetHitResultAtScreenPosition(ScreenLocation2D, CurrentClickTraceChannel, true, TraceHitResult);
#endif
	AActor* TempDownActor = TraceHitResult.GetActor();
	if (TempDownActor != nullptr)
	{
		//点中的是棋子
		ACWPawn* TempDownPawn = Cast<ACWPawn>(TempDownActor);
		if (TempDownPawn != nullptr)
		{
			//判断棋子是否死亡
			if (TempDownPawn->IsAllowOperate() && !TempDownPawn->IsDieOrDeath())
			{
				//棋子没死亡

				//摄像机不能操作
				//IsCanMoveCamera = false;

				//棋子的数据处理
				OldDownPawn = DownPawn;
				DownPawn = TempDownPawn;

				if (DownPawn->GetCampTag() == GetCampTag() &&
					DownPawn->GetCampControllerIndex() == GetCampControllerIndex() &&
					IsMyTurn(DownPawn) && 
					DownPawn->CanInstructsByCurInstructs())
				{
					//SelectPawnInFight = DownPawn;
					//ShowSelectedPawnShadow(true);

					//NotifyUIShowRoleAttr(DownPawn);
				}


				//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseDownInFighting DownPawn = TempDownPawn DownPawn = %X 1."), DownPawn);
				//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseDownInFighting DownPawn = TempDownPawn DownPawn = %X 2."), this->GetDownPawn());
				
				//ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
				//if (CurSelectedPawn == nullptr || (CurSelectedPawn != nullptr && CurSelectedPawn == TempDownPawn))
				//{
				//	if (TempDownPawn->GetCampTag() == GetCampTag() &&
				//		TempDownPawn->GetCampControllerIndex() == GetCampControllerIndex() &&
				//		IsMyTurn(TempDownPawn) && 
				//		(TempDownPawn->GetInstructs() == 0 || (TempDownPawn->GetInstructs() > 0 && ((TempDownPawn->GetInstructs() & (uint8)ECWInstructType::Await) == 0))))
				//	{
				//		//当前选中了的角色为空或当前选中的角色等于当前按下的角色， 且此角色还有行动能力，显示地图移动提示和拖动阴影

				//		//SelectPawnInFight = TempDownPawn;
				//		//ShowSelectedPawnShadow(true);
				//		//TempDownPawn->ShowHintTile(this);
				//	}
				//}
				//else
				//{
				//	//不处理
				//}
			}
			else
			{
				//棋子已死亡，不处理

				OldDownPawn = DownPawn;
				DownPawn = nullptr;
				ShowSelectedPawnShadow(false);
				SelectPawnInFight = nullptr;
				
				//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseDownInFighting DownPawn = nullptr 1."));
			}
		}
		else
		{
			//点中的是地图格子
			ACWMapTile* TempDownTile = Cast<ACWMapTile>(TempDownActor);
			if (TempDownTile != nullptr)
			{
				//格子的数据处理
				OldDownTile = DownTile;
				DownTile = TempDownTile;

				//格子里是否有棋子
				TWeakObjectPtr<ACWPawn> PawnInTile = GetMap()->GetPawnByTile(DownTile->Tile);
				if (PawnInTile.IsValid())
				{
					//格子里有棋子

					//判断棋子是否死亡
					if (PawnInTile->IsAllowOperate() &&
						!PawnInTile->IsDieOrDeath())
					{
						//棋子没死亡

						//摄像机不能操作
						//IsCanMoveCamera = false;

						//棋子的数据处理
						OldDownPawn = DownPawn;
						DownPawn = PawnInTile.Get();

						if (DownPawn->GetCampTag() == GetCampTag() &&
							DownPawn->GetCampControllerIndex() == GetCampControllerIndex() &&
							IsMyTurn(DownPawn) &&
							DownPawn->CanInstructsByCurInstructs())
						{
							//SelectPawnInFight = DownPawn;
							//ShowSelectedPawnShadow(true);

							//NotifyUIShowRoleAttr(DownPawn);
						}
					}
					else
					{
						//棋子已死亡，不处理
						OldDownPawn = DownPawn;
						DownPawn = nullptr;
						ShowSelectedPawnShadow(false);
						SelectPawnInFight = nullptr;

						ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
						if (CurSelectedPawn != nullptr &&
							CurSelectedPawn->GetCampTag() == GetCampTag() &&
							CurSelectedPawn->GetCampControllerIndex() == GetCampControllerIndex() &&
							IsMyTurn(CurSelectedPawn) &&
							CurSelectedPawn->CanInstructsByCurInstructs())
						{
							uint8 TempMoveAttackDamage = 0x00;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
							if (CurSelectedPawn->IsMoveTile(DownTile->Tile) || CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), DownTile->Tile, TempMoveAttackDamage))
							{
								//IsCanMoveCamera = false;
							}
						}
					}
				}
				else
				{
					//格子里没有棋子

					OldDownPawn = DownPawn;
					DownPawn = nullptr;
					ShowSelectedPawnShadow(false);
					SelectPawnInFight = nullptr;

					ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
					if (CurSelectedPawn != nullptr &&
						CurSelectedPawn->GetCampTag() == GetCampTag() &&
						CurSelectedPawn->GetCampControllerIndex() == GetCampControllerIndex() &&
						IsMyTurn(CurSelectedPawn) &&
						CurSelectedPawn->CanInstructsByCurInstructs())
					{
						uint8 TempMoveAttackDamage = 0x00;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
						TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
						if (CurSelectedPawn->IsMoveTile(DownTile->Tile) || CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), DownTile->Tile, TempMoveAttackDamage))
						{
							//IsCanMoveCamera = false;
						}
					}
				}
			}
			else
			{
				OldDownPawn = DownPawn;
				DownPawn = nullptr;
				ShowSelectedPawnShadow(false);
				SelectPawnInFight = nullptr;
				OldDownTile = DownTile;
				DownTile = nullptr;

				//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseDownInFighting DownPawn = nullptr 4."));
			}
		}
	}
	else
	{
		OldDownPawn = DownPawn;
		DownPawn = nullptr;
		ShowSelectedPawnShadow(false);
		SelectPawnInFight = nullptr;
		OldDownTile = DownTile;
		DownTile = nullptr;

		//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseDownInFighting DownPawn = nullptr 5."));
	}
}

void ACWPlayerController::HandleLeftMouseUpInFighting(const FVector& InScreenLoc)
{
	if (IsInServer())
		return;

	ACWPawn* TempCurSelectedPawn = this->GetCurSelectedPawn();
	if (TempCurSelectedPawn != nullptr)
	{
		const bool bCanMove = TempCurSelectedPawn->CanMoveByCurInstructs();
		const bool bCanNormalAttack = TempCurSelectedPawn->CanNormalAttackByCurInstructs();
		const bool bCanCastSkill = TempCurSelectedPawn->CanCastSkillByCurInstructs();
		ECWPawnInputState TempCurInputFSMState = TempCurSelectedPawn->GetCurInputFSMStateId();
		if ((TempCurInputFSMState == ECWPawnInputState::TurnWaitingAction) ||
			(TempCurInputFSMState == ECWPawnInputState::MoveToDest && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::MoveToAttack && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::MoveToWaitingAttack && bCanMove) ||
			(TempCurInputFSMState == ECWPawnInputState::NormalAttack && bCanNormalAttack) ||
			(TempCurInputFSMState == ECWPawnInputState::CastSkillToTile && bCanCastSkill) ||
			(TempCurInputFSMState == ECWPawnInputState::CastSkillToPawn && bCanCastSkill))
		{
			CWG_WARNING(">> %s::SetPressReadyToDestTile, bCanMove[%d], bCanNormalAttack[%d], bCanCastSkill[%d] State[%s] >> 1-1~", 
				*GetName(), (int32)bCanMove, (int32)bCanNormalAttack, (int32)bCanCastSkill, *FCWToString::ToString(TempCurInputFSMState));
			
			SetPressReadyToDestTile(-1);
			OldDownPawn = nullptr;
			DownPawn = nullptr;
			ShowSelectedPawnShadow(false);
			LongDownTime = 0.0f;
			SelCurSelectedLongDown(false);
			SelectPawnInFight = nullptr;
			OldDownTile = nullptr;
			DownTile = nullptr;
			PressTile = nullptr;
			OldPressTile = nullptr;

			TempCurSelectedPawn->ResetInputStateInClient();
			//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseUpInFighting DownPawn = nullptr 6."));

			return;
		}

		if (TempCurSelectedPawn->IsDieOrDeath())
		{
			UE_LOG(LogCWPlayerController, Log, TEXT("2 ACWPlayerController::SetPressReadyToDestTile -1"));
			this->SetPressReadyToDestTile(-1);

			OldDownPawn = nullptr;
			DownPawn = nullptr;
			ShowSelectedPawnShadow(false);
			LongDownTime = 0.0f;
			SelCurSelectedLongDown(false);
			SelectPawnInFight = nullptr;
			OldDownTile = nullptr;
			DownTile = nullptr;
			PressTile = nullptr;
			OldPressTile = nullptr;

			//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseUpInFighting DownPawn = nullptr 6."));

			return;
		}
	}

	FHitResult TraceHitResult;
#if PLATFORM_WINDOWS
	GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
#elif PLATFORM_ANDROID
	FVector2D ScreenLocation2D(InScreenLoc);
	GetHitResultAtScreenPosition(ScreenLocation2D, CurrentClickTraceChannel, true, TraceHitResult);
#endif
	AActor* HitActor = TraceHitResult.GetActor();
	if (HitActor != nullptr)
	{
		ACWPawn* HitPawn = Cast<ACWPawn>(HitActor);
		if (HitPawn != nullptr)
		{
			//点中的是棋子
			ACWPawn* TempDownPawn = GetDownPawn();
			if (TempDownPawn != nullptr)
			{
				//当前down的棋子是存在的
				
				//判断当前down的棋子是否可操作
				if (TempDownPawn->IsAllowOperate())
				{
					if (TempDownPawn == HitPawn)
					{
						//当前up的棋子和当前down的棋子是相同的棋子
						if (!TempDownPawn->IsDieOrDeath()) //&& (TempDownPawn->GetInstructs() == 0 || (TempDownPawn->GetInstructs() > 0 && ((TempDownPawn->GetInstructs() & (uint8)ECWInstructType::Await) == 0))))
						{
							//棋子没死亡
							ECWPawnInputState CurInputStateId = HitPawn->GetCurInputFSMStateId();
							FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = new FCWPawnInputLeftMouseUpEvent((int)ECWPawnInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitPawn, this);
							HitPawn->GetInputFSM()->DoEvent(LeftMouseUpEvent);
						}
						else
						{
							//棋子已死亡

							//不处理
						}
					}
					else
					{
						//当前up的棋子和当前down的棋子是不相同的棋子

						//ACWPawn* TempCurSelectedPawn = GetCurSelectedPawn();
						if (TempCurSelectedPawn != nullptr)
						{
							//当前选中的棋子和当前downdown的棋子是相同的棋子
							ECWPawnInputState CurInputStateId = HitPawn->GetCurInputFSMStateId();
							FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = new FCWPawnInputLeftMouseUpEvent((int)ECWPawnInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitPawn, this);
							HitPawn->GetInputFSM()->DoEvent(LeftMouseUpEvent);
						}
						else
						{
							//当前选中的棋子和当前downdown的棋子是不相同的棋子

							//不处理	
						}
					}
				}
				else
				{
					//当前down的棋子是不可操作的

					//不处理
				}
			}
			else
			{
				//当前down的棋子是不存在的

				//不处理	
			}
		}
		else
		{
			ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor);
			if (HitTile != nullptr)
			{
				//点中的是地图格子
				ACWMapTile* TempDownTile = GetDownTile();
				if (TempDownTile != nullptr)
				{
					if (TempDownTile == HitTile)
					{
						//当前up的地图格子和当前down的地图格子是相同的地图格子
						ECWMapTileInputState CurInputStateId = HitTile->GetCurInputFSMStateId();
						FCWMapTileInputLeftMouseUpEvent* LeftMouseUpEvent = new FCWMapTileInputLeftMouseUpEvent((int)ECWMapTileInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitTile, this);
						HitTile->GetInputFSM()->DoEvent(LeftMouseUpEvent);
					}
					else
					{
						//当前up的地图格子和当前down的地图格子是不相同的地图格子

						ACWPawn* TempDownPawn = GetDownPawn();
						if (TempDownPawn != nullptr)
						{
							//当前down的棋子是存在的

							ACWPawn* TempCurSelectedDownPawn = GetCurSelectedPawn();
							if (TempCurSelectedDownPawn != nullptr && TempCurSelectedDownPawn == TempDownPawn)
							{
								//当前选中的棋子和当前down的棋子是相同的棋子

								ECWMapTileInputState CurInputStateId = HitTile->GetCurInputFSMStateId();
								FCWMapTileInputLeftMouseUpEvent* LeftMouseUpEvent = new FCWMapTileInputLeftMouseUpEvent((int)ECWMapTileInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitTile, this);
								HitTile->GetInputFSM()->DoEvent(LeftMouseUpEvent);
							}
							else
							{
								//当前选中的棋子和当前downdown的棋子是不相同的棋子

								//不处理
							}
						}
						else
						{
							//当前down的棋子是不存在的

							//不处理
						}
					}
				}
				else
				{
					//当前down的地图格子是不存在的

					ACWPawn* TempDownPawn = GetDownPawn();
					if (TempDownPawn != nullptr && TempDownPawn->IsAllowOperate())
					{
						//当前down的棋子是存在的

						ACWPawn* TempCurSelectedDownPawn = GetCurSelectedPawn();
						if (TempCurSelectedDownPawn != nullptr && TempCurSelectedDownPawn == TempDownPawn)
						{
							//当前选中的棋子和当前down的棋子是相同的棋子

							ECWMapTileInputState CurInputStateId = HitTile->GetCurInputFSMStateId();
							FCWMapTileInputLeftMouseUpEvent* LeftMouseUpEvent = new FCWMapTileInputLeftMouseUpEvent((int)ECWMapTileInputEvent::LeftMouseUp, (int)CurInputStateId, ECWFSMStackOp::Set, HitTile, this);
							HitTile->GetInputFSM()->DoEvent(LeftMouseUpEvent);
						}
						else
						{
							//当前选中的棋子和当前downdown的棋子是不相同的棋子

							//不处理
						}
					}
					else
					{
						//当前down的棋子是不存在的

						//不处理
					}
				}
			}
			else
			{
				//没有点中地图格子

				//不处理
			}
		}
	}

	//UE_LOG(LogCWPlayerController, Log, TEXT("3 ACWPlayerController::SetPressReadyToDestTile -1"));
	//this->SetPressReadyToDestTile(-1);

	OldDownPawn = nullptr;
	DownPawn = nullptr;
	LongDownTime = 0.0f;
	ShowSelectedPawnShadow(false);
	SelectPawnInFight = nullptr;
	OldDownTile = nullptr;
	DownTile = nullptr;
	PressTile = nullptr;
	OldPressTile = nullptr;
	if (GetCurSelectedPawn() != nullptr)
	{
		GetCurSelectedPawn()->SetLongDown(false);
	}

	// 清除拖动标记对象状态
	ACWPawn* CursorOverP = GetCursorOverPawn(ECWBattleState::Fighting);
	if (IsValid(CursorOverP) && IsValid(TempCurSelectedPawn))
	{
		uint8 TempMoveAttackDamage = 0x00;
		TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
		TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
		if (//TempCurSelectedPawn->GetSkillManager()->IsEnoughEnergy() &&
			TempCurSelectedPawn->IsMoveAttackTileFromTile(TempCurSelectedPawn->GetTile(), CursorOverP->GetTile(), TempMoveAttackDamage))
		{
			NotifyUIShowPreview(TempCurSelectedPawn, CursorOverP);
		}
		else
		{
			CursorOverP->ShowHeadIcon(EUIHeadIconType::None);
			NotifyUIHidePreview(TempCurSelectedPawn, CursorOverP);
			//NotifyUIShowRoleAttr(TempCurSelectedPawn);
		}
	}
	CursorOverPawnInFight = nullptr;

	//UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::HandleLeftMouseUpInFighting DownPawn = nullptr 6."));
}

void ACWPlayerController::OnTickLeftMousePressInFighting(float DeltaTime)
{
	if (!IsMyTurn())
		return;

	ACWPawn* MyPawn = GetDownPawn();
	if (MyPawn != nullptr)
	{
		if (MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			ECWPawnInputState TempCurInputFSMState = MyPawn->GetCurInputFSMStateId();
			if (TempCurInputFSMState == ECWPawnInputState::MoveToDest ||
				TempCurInputFSMState == ECWPawnInputState::MoveToAttack ||
				TempCurInputFSMState == ECWPawnInputState::MoveToWaitingAttack ||
				TempCurInputFSMState == ECWPawnInputState::NormalAttack ||
				TempCurInputFSMState == ECWPawnInputState::CastSkillToTile ||
				TempCurInputFSMState == ECWPawnInputState::CastSkillToPawn)
			{
				return;
			}

			if (MyPawn->IsDieOrDeath())
			{
				return;
			}

			if (IsMyTurn(MyPawn) &&
				MyPawn->CanInstructsByCurInstructs())
			{
				FHitResult TraceHitResult;
				GetHitResultUnderCursor(CurrentClickTraceChannel, true, TraceHitResult);
				AActor* HitActor = TraceHitResult.GetActor();
				if (HitActor != nullptr)
				{
					//点中的是棋子
					ACWPawn* HitPawn = Cast<ACWPawn>(HitActor);
					if (HitPawn != nullptr)
					{
						if (MyPawn != HitPawn)
						{
							if (this->IsEnemy(MyPawn, HitPawn))
							{

							}
						}
						else
						{
							ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
							if (CurSelectedPawn == nullptr || (CurSelectedPawn != nullptr && CurSelectedPawn == MyPawn))
							{
								LongDownTime += DeltaTime;

								UE_LOG(LogCWPlayerController, Log, TEXT("4 ACWPlayerController::SetPressReadyToDestTile -1"));
								SetPressReadyToDestTile(-1);
								//if (LongDownTime >= LONG_DOWN_TIME)
								//{
								//	ECWPawnInputState TempCurInputState = (ECWPawnInputState)(MyPawn->GetCurInputFSMStateId());
								//	if (TempCurInputState == ECWPawnInputState::WaitingInput ||
								//		TempCurInputState == ECWPawnInputState::Selected || 
								//		TempCurInputState == ECWPawnInputState::ReadyToMove ||
								//		TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack ||
								//		TempCurInputState == ECWPawnInputState::SelectedAndWantAttack)
								//		//TempCurInputState == ECWPawnInputState::WaitingAttack)
								//	{
								//		//自己变成选中的棋子
								//		ACWMap* const MapActor = GetMap();
								//		CancelCurSelectedTileInClient();
								//		SetCurSelectedPawnInClient(MyPawn, true);
								//		SetCurSelectedTileInClient(MapActor->GetTile(MyPawn->GetTile()));
								//		SelectPawnInFight = DownPawn;
								//		ShowSelectedPawnShadow(true);
								//	}
								//}
							}
						}
					}
					else
					{
						//点中的是地图块
						ACWMapTile* HitTile = Cast<ACWMapTile>(HitActor);
						if (HitTile != nullptr)
						{
							OldPressTile = PressTile;
							PressTile = HitTile;

							if (MyPawn->GetTile() != HitTile->Tile)
							{
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;

								LongDownTime = 0.0f;
								if (MyPawn->IsMoveTile(HitTile->Tile))
								{
									if (OldPressTile == nullptr)
									{
										//UE_LOG(LogCWPlayerController, Log, TEXT("1 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile == nullptr."));
										//if (MyPawn->FindPathAndShowWantMovePathArrow(HitTile->Tile))
										//{
										//	//SetPressReadyToDestTile(HitTile->Tile);
										//}
									}
									else if (OldPressTile != nullptr && OldPressTile->Tile != PressTile->Tile)
									{
										//UE_LOG(LogCWPlayerController, Log, TEXT("2 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile != nullptr && OldDownTile->Tile != HitTile->Tile."));
										//if (MyPawn->FindPathAndShowWantMovePathArrow(HitTile->Tile))
										//{
										//	//UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::SetPressReadyToDestTile"));
										//	SetPressReadyToDestTile(HitTile->Tile);
										//}
									}
									else
									{
										//UE_LOG(LogCWPlayerController, Log, TEXT("5 ACWPlayerController::SetPressReadyToDestTile -1"));
										//SetPressReadyToDestTile(-1);
									}
								}
								else if (MyPawn->IsMoveAttackTileFromTile(MyPawn->GetTile(), HitTile->Tile, TempMoveAttackDamage))
								{
									int intMoveTile = MyPawn->GetMoveTileFromNormalAttackTargetTile(MyPawn->GetTile(), HitTile->Tile, MyPawn->GetCampTag(), MyPawn->GetFindPathInfo());
									if (intMoveTile != -1)
									{
										int RealMoveTile = this->GetPressReadyToDestTile() == -1 ? intMoveTile : this->GetPressReadyToDestTile();
										RealMoveTile = MyPawn->IsAttackTileFromTile(RealMoveTile, HitTile->Tile, TempMoveAttackDamage) ? RealMoveTile : intMoveTile;
										
										ACWMapTile* MoveTile = GetMap()->GetTile(RealMoveTile);
										check(MoveTile);

										if (OldPressTile == nullptr)
										{
											//UE_LOG(LogCWPlayerController, Log, TEXT("3 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile == nullptr."));
											/*if (MyPawn->FindPathAndShowWantMovePathArrow(MoveTile->Tile))
											{
												SetPressReadyToDestTile(MoveTile->Tile);
											}*/
										}
										else if (OldPressTile != nullptr && OldPressTile->Tile != HitTile->Tile)
										{
											if (MyPawn->IsAttackTileFromTile(OldPressTile->Tile, HitTile->Tile, TempMoveAttackDamage))
											{
												//UE_LOG(LogCWPlayerController, Log, TEXT("4 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile != nullptr, OldDownTile->Tile:%d."), OldPressTile->Tile);
												//if (MyPawn->FindPathAndShowWantMovePathArrow(OldPressTile->Tile))
												//{
												//	SetPressReadyToDestTile(OldPressTile->Tile);
												//}
												//else
												//{
												//	//UE_LOG(LogCWPlayerController, Log, TEXT("5 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile != nullptr, MoveTile->Tile:%d."), MoveTile->Tile);
												//	if (MyPawn->FindPathAndShowWantMovePathArrow(MoveTile->Tile))
												//	{
												//		SetPressReadyToDestTile(MoveTile->Tile);
												//	}
												//}
											}
											else
											{
												//UE_LOG(LogCWPlayerController, Log, TEXT("6 ACWPlayerController::OnTickLeftMousePressInFighting OldDownTile != nullptr, MoveTile->Tile:%d."), MoveTile->Tile);
												/*if (MyPawn->FindPathAndShowWantMovePathArrow(MoveTile->Tile))
												{
													SetPressReadyToDestTile(MoveTile->Tile);
												}*/
											}
										}
										else
										{
											//UE_LOG(LogCWPlayerController, Log, TEXT("6 ACWPlayerController::SetPressReadyToDestTile -1"));
											//SetPressReadyToDestTile(-1);
										}

										OldPressTile = MoveTile;
									}
								}
								else
								{
									MyPawn->HideWantMovePathArrow();

									UE_LOG(LogCWPlayerController, Log, TEXT("7 ACWPlayerController::SetPressReadyToDestTile -1"));
									SetPressReadyToDestTile(-1);
								}
							}
							else
							{
								ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
								if (CurSelectedPawn == nullptr || (CurSelectedPawn != nullptr && CurSelectedPawn == MyPawn))
								{
									LongDownTime += DeltaTime;
									//if (LongDownTime >= LONG_DOWN_TIME)
									//{
									//	ECWPawnInputState TempCurInputState = (ECWPawnInputState)(MyPawn->GetCurInputFSMStateId());
									//	if (TempCurInputState == ECWPawnInputState::WaitingInput ||
									//		TempCurInputState == ECWPawnInputState::Selected ||
									//		TempCurInputState == ECWPawnInputState::ReadyToMove ||
									//		TempCurInputState == ECWPawnInputState::ReadyToMoveAndWantAttack ||
									//		TempCurInputState == ECWPawnInputState::SelectedAndWantAttack)
									//		//TempCurInputState == ECWPawnInputState::WaitingAttack)
									//	{
									//		//自己变成选中的棋子
									//		this->SetCurSelectedPawnInClient(MyPawn, true);
									//		SelectPawnInFight = DownPawn;
									//		ShowSelectedPawnShadow(true);
									//	}
									//}
								}

								//MyPawn->HideWantMovePathArrow();
								//UE_LOG(LogCWPlayerController, Log, TEXT("8 ACWPlayerController::SetPressReadyToDestTile -1"));
								SetPressReadyToDestTile(-1);
							}
						}
						else
						{
							OldPressTile = nullptr;
							PressTile = nullptr;

							//UE_LOG(LogCWPlayerController, Log, TEXT("9 ACWPlayerController::SetPressReadyToDestTile -1"));
							//SetPressReadyToDestTile(-1);

							UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::OnTickLeftMousePressInFighting No Hit."));
						}
					}
				}
			}
		}
	}
}

void ACWPlayerController::SetPressReadyToDestTile(int ParamDestTile)
{
	PressReadyToDestTile = ParamDestTile;

	//UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::SetPressReadyToDestTile ParamDestTile:%d."), ParamDestTile);
}

int32 ACWPlayerController::GetPressReadyToDestTile() const
{
	//UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::GetPressReadyToDestTile PressReadyToDestTile:%d."), PressReadyToDestTile);
	return PressReadyToDestTile;
}

void ACWPlayerController::SelCurSelectedLongDown(bool ParamIsLongDown)
{
	ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
	if (CurSelectedPawn != nullptr)
	{
		CurSelectedPawn->SetLongDown(ParamIsLongDown);
	}
}

ACWRandomDungeonGenerator* ACWPlayerController::GetDungeonGenerator()
{
	return UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
}

void ACWPlayerController::ResetMapTileStateInReady(bool bEnableReadyState)
{
	auto NewGetPredicate = [this](const ACWPawnStart* InPawnStart)
	{
		return nullptr != InPawnStart && InPawnStart->IsSameCampAndCtrl(GetCampTag(), GetCampControllerIndex());
	};

	TArray<ACWPawnStart*> PawnStartList;
	UCWFuncLib::GetAllActors<ACWPawnStart>(this, PawnStartList, NewGetPredicate);
	for (const auto PawnStart : PawnStartList)
	{
		const ECWTileRenderType RenderType = bEnableReadyState ? ECWTileRenderType::SwitchInReady : ECWTileRenderType::None;
		PawnStart->ShowTileRender(RenderType);
	}
}

void ACWPlayerController::SetNotOwnPawnHidden(bool bNewHidden)
{
	FConstPawnIterator Iter = GetWorld()->GetPawnIterator();
	for (; Iter; ++Iter)
	{
		ACWPawn* CWP = Cast<ACWPawn>(Iter->Get());
		if (nullptr != CWP && !CWP->IsMyClientPawn() && CWP->IsPawnType(ECWPawnType::Character))
		{
			CWP->SetActorHiddenInGame(bNewHidden);
		}
	}
}

bool ACWPlayerController::SwitchPawnPosInReady(ACWPawn* InP1, ACWPawn* InP2, int32 InTile1, int32 InTile2)
{
	ACWMap* const MyMap = GetMap();
	if (nullptr == MyMap || nullptr == InP1 || nullptr == InP2 || InP1 == InP2
		|| !UCWFuncLib::IsPartner(InP1, InP2))
	{
		return false;
	}
	int32 Tile1 = /*(InTile1 > 0) ? InTile1 :*/ InP1->GetTile();
	int32 Tile2 = /*(InTile2 > 0) ? InTile2 :*/ InP2->GetTile();
	FVector Pos1 = InP1->GetActorLocation();
	FVector Pos2 = InP2->GetActorLocation();
	InP1->SetTile(Tile2);
	InP2->SetTile(Tile1);
	InP1->SetActorLocation(Pos2);
	InP2->SetActorLocation(Pos1);

	return true;
}

bool ACWPlayerController::SwitchPawnPosToPointInReady(ACWPawn* InSelect, ACWPawnStart* InTarget)
{
	ACWMap* const MyMap = GetMap();
	if (nullptr == MyMap || nullptr == InSelect || nullptr == InTarget || InSelect->GetTile() == InTarget->GetTile() ||
		!InTarget->IsSameCampAndCtrl(InSelect->GetCampTag(), InSelect->GetCampControllerIndex()))
	{
		return false;
	}

	/*FVector NewPos = InSelect->GetActorLocation();
	NewPos.X = InTarget->X;
	NewPos.Y = InTarget->Y;*/
	InSelect->SetTile(InTarget->GetTile());
	//InSelect->SetActorLocation(NewPos);
	return true;
}

bool ACWPlayerController::ServerSwitchPawnPosToPointInReady_Validate(ACWPawn* InSelect, ACWPawnStart* InTarget)
{
	return true;
}

void ACWPlayerController::ServerSwitchPawnPosToPointInReady_Implementation(ACWPawn* InSelect, ACWPawnStart* InTarget)
{
	if (SwitchPawnPosToPointInReady(InSelect, InTarget))
	{
		ClientSwitchPawnPosToPointInReady(InSelect, InTarget);
	}
}

void ACWPlayerController::ClientSwitchPawnPosToPointInReady_Implementation(ACWPawn* InSelect, ACWPawnStart* InTarget)
{
	if (SwitchPawnPosToPointInReady(InSelect, InTarget))
	{
		//InSelect->ClientShowEffect();
	}
}

bool ACWPlayerController::IsReadyFinished() const
{
	return bReadyFinished;
}

bool ACWPlayerController::ServerSetReadyFinished_Validate(bool bReadyOK)
{
	return true;
}

void ACWPlayerController::ServerSetReadyFinished_Implementation(bool bReadyOK)
{
	bReadyFinished = bReadyOK;

	ACWGameState* GameState = GetGameState<ACWGameState>();
	if (nullptr != GameState)
	{
		GameState->ServerPlayerReadyStateChange(this, bReadyFinished);
	}
}

bool ACWPlayerController::ServerSwitchPawnPosInReady_Validate(ACWPawn* P1, ACWPawn* P2)
{
	return true;
}

void ACWPlayerController::ServerSwitchPawnPosInReady_Implementation(ACWPawn* P1, ACWPawn* P2)
{
	if (SwitchPawnPosInReady(P1, P2))
	{
		ClientSwitchPawnPosInReady(P1, P2, P1->GetTile(), P2->GetTile());
	}
}

void ACWPlayerController::ClientSwitchPawnPosInReady_Implementation(ACWPawn* P1, ACWPawn* P2, int32 InTile1, int32 InTile2)
{
	if (SwitchPawnPosInReady(P1, P2, InTile1, InTile2))
	{
		//P1->ClientShowEffect();
		//P2->ClientShowEffect();
	}
}

void ACWPlayerController::RespondBattleAfterMapSetupEventInServer()
{
	if (!IsInServer())
		return;

	//根据相关数据，生成相关棋子
	SpawnPawnsByPawnStart();	
}

void ACWPlayerController::RespondBattleStateChangedEventInClient(const ECWBattleState& ParamOldBattleState, const ECWBattleState& ParamCurBattleState)
{
	if (!IsInServer())
	{
		UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::RespondBattleStateChangedEventInClient. OldBattleState:%d, CurBattleState:%d."), (int)ParamOldBattleState, (int)ParamCurBattleState);

		/*ACWPlayerState* MyPlayerState = GetCWPlayerState();
		if (MyPlayerState == nullptr)
			return;*/

		if (ParamCurBattleState == ECWBattleState::Ready)
		{
			InitReadyStateData();
		}
		else if (ParamOldBattleState == ECWBattleState::Ready && ParamCurBattleState == ECWBattleState::Fighting)
		{
			ClearReadyStateData();
		}
		else if (ParamOldBattleState == ECWBattleState::Fighting && ParamCurBattleState == ECWBattleState::Settlement)
		{
			IsCanMoveCamera = false;
			IsCanYawCamera = false;
		}
	}
}

void ACWPlayerController::RespondPawnTileChangedEventInClient(
	const ECWCampTag PawnCampTag,
	const ECWCampControllerIndex PawnCampControllerIndex,
	const int32 PawnControllerPawnIndex,
	const int PawnOldTile,
	const int PawnCurTile)
{
	UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::RespondPawnTileChangedEventInClient. PawnCampTag:%d, PawnCampControllerIndex:%d, PawnControllerPawnIndex：%d, PawnOldTile:%d, PawnCurTile:%d."), (int)PawnCampTag, (int)PawnCampControllerIndex, (int)PawnControllerPawnIndex, PawnOldTile, PawnCurTile);

	ACWPawn* MyPawn = this->GetPawnByCampTagAndControllerIndexAndPawnIndex(PawnCampTag, PawnCampControllerIndex, PawnControllerPawnIndex);
	if (MyPawn == nullptr)
		return;

}

void ACWPlayerController::RespondPawnIdChangedEventInClient(
	const ECWCampTag PawnCampTag,
	const ECWCampControllerIndex PawnCampControllerIndex,
	const int32 PawnControllerPawnIndex,
	const int ParamPawnId)
{
	UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::RespondPawnIdChangedEventInClient. PawnCampTag:%d, PawnCampControllerIndex:%d, PawnControllerPawnIndex：%d, ParamPawnId:%d."), (int)PawnCampTag, (int)PawnCampControllerIndex, (int)PawnControllerPawnIndex, ParamPawnId);

	ACWPawn* MyPawn = this->GetPawnByCampTagAndControllerIndexAndPawnIndex(PawnCampTag, PawnCampControllerIndex, PawnControllerPawnIndex);
	if (MyPawn == nullptr)
		return;
}


void ACWPlayerController::RespondPawnActionEndEventInServer(
	const ECWCampTag PawnCampTag,
	const ECWCampControllerIndex PawnCampControllerIndex,
	const int32 PawnControllerPawnIndex)
{
	if (GetCampTag() == PawnCampTag &&
		GetCampControllerIndex() == PawnCampControllerIndex)
	{
		if (IsAllPawnActionEndInServer())
		{
			ACWGameMode* MyGameMode = Cast<ACWGameMode>(GetWorld()->GetAuthGameMode());
			check(MyGameMode);
			ECWBattleFightingState TempCurBattleFightingState = (ECWBattleFightingState)(MyGameMode->GetBattleFightingFSM()->GetCurrentStateId());
			if (TempCurBattleFightingState == ECWBattleFightingState::Normal)
			{
				//MyGameMode->SomePlayerControllerActionEnd(this);
				MyGameMode->ToWaitingEndState();
			}
		}

		ClientRespondPawnActionEnd(PawnCampTag, PawnCampControllerIndex, PawnControllerPawnIndex);
	}
	else
	{
		UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::RespondPawnActionEndEventInServer fail, GetCampTag():%d, GetCampControllerIndex():%d, PawnCampTag:%d, PawnControllerPawnIndex:%d."), (int)GetCampTag(), (int)GetCampControllerIndex(), (int)PawnCampTag, (int)PawnControllerPawnIndex);
	}
}

void ACWPlayerController::RespondPawnDieEndEventInServer(
	const ECWCampTag PawnCampTag,
	const ECWCampControllerIndex PawnCampControllerIndex,
	const int32 PawnControllerPawnIndex)
{
	if (GetCampTag() == PawnCampTag &&
		GetCampControllerIndex() == PawnCampControllerIndex)
	{
		if (IsAllPawnDieEndInServer())
		{
			ACWGameMode* MyGameMode = Cast<ACWGameMode>(GetWorld()->GetAuthGameMode());
			check(MyGameMode);
			MyGameMode->SomePlayerControllerDieEnd(this);
		}

		if (IsAllPawnActionEndInServer())
		{
			ACWGameMode* MyGameMode = Cast<ACWGameMode>(GetWorld()->GetAuthGameMode());
			check(MyGameMode);
			ECWBattleFightingState TempCurBattleFightingState = (ECWBattleFightingState)(MyGameMode->GetBattleFightingFSM()->GetCurrentStateId());
			if (TempCurBattleFightingState == ECWBattleFightingState::Normal)
			{
				//MyGameMode->SomePlayerControllerActionEnd(this);
				MyGameMode->ToWaitingEndState();
			}
		}
	}
	else
	{
		UE_LOG(LogCWPlayerController, Error, TEXT("ACWPlayerController::RespondPawnDieEndEventInServer fail, GetCampTag():%d, GetCampControllerIndex():%d, PawnCampTag:%d, PawnControllerPawnIndex:%d."), (int)GetCampTag(), (int)GetCampControllerIndex(), (int)PawnCampTag, (int)PawnControllerPawnIndex);
	}
}

bool ACWPlayerController::CanActionPawn(const ACWPawn* InPawn)
{
	return IsValidActor(InPawn) && InPawn->IsPawnType(ECWPawnType::Character) && IsPartner(InPawn) && InPawn->IsCanAction();
}

int32 ACWPlayerController::GetCanActionPawnList(TArray<ACWPawn*>& OutPawnList)
{
	ACWMap* MyMapActor = GetMap();
	const bool bIsMyTurn = IsMyTurn();
	const ECWBattleState MyBattleState = GetBattleState();
	if (MyBattleState != ECWBattleState::Fighting || !IsValidActor(MyMapActor) || !bIsMyTurn)
	{
		//CWG_WARNING(">> %s::OnSwitchSelectedPawn, No! MyBattleState[%d] IsMyTurn[%d].", *GetName(), (int32)MyBattleState, (int32)bIsMyTurn);
		return INDEX_NONE;
	}

	// 条件: 获取/排序
	auto NewGetPredicate = [this](const ACWPawn* InPawn) -> bool
	{
		return CanActionPawn(InPawn);
	};
	auto NewSortPredicate = [](const ACWPawn& InLeftPawn, const ACWPawn& InRightPawn) -> bool
	{
		const int32 LeftPawnIdx = InLeftPawn.GetPawnUniqueIdx();
		const int32 RightPawnIdx = InRightPawn.GetPawnUniqueIdx();
		return LeftPawnIdx < RightPawnIdx;
	};

	// 获取优先目标
	int32 RetValue = UCWFuncLib::GetAllActors<ACWPawn>(this, OutPawnList, NewGetPredicate, NewSortPredicate);
	return RetValue;
}

void ACWPlayerController::OnPlayerSwitchSelectedPawn()
{
	ACWMap* MyMapActor = GetMap();
	TArray<ACWPawn*> CanActionPawnList;
	const int32 CanActionPawnNum = GetCanActionPawnList(CanActionPawnList);
	if (CanActionPawnNum <= 0 || nullptr == MyMapActor)
	{
		return;
	}

	// 检测是否有棋子在操作
	ACWPawn* CurSelectedPawn = GetCurSelectedPawn();
	ECWPawnInputState CurInputFSMState = CurSelectedPawn ? CurSelectedPawn->GetCurInputFSMStateId() : ECWPawnInputState::None;
	if (CurInputFSMState == ECWPawnInputState::MoveToDest ||
		CurInputFSMState == ECWPawnInputState::MoveToAttack ||
		CurInputFSMState == ECWPawnInputState::MoveToWaitingAttack ||
		CurInputFSMState == ECWPawnInputState::NormalAttack ||
		CurInputFSMState == ECWPawnInputState::CastSkillToTile ||
		CurInputFSMState == ECWPawnInputState::CastSkillToPawn)
	{
		ClientSendMessage(BattleSiwtchPawn);
		return;
	}

	// 选择优先目标棋子
	ACWPawn* NewSelectedPawn = !CanActionPawn(CurSelectedPawn) ? CanActionPawnList[0] : nullptr;
	const int32 CurSelectedUniqueIdx = CurSelectedPawn ? CurSelectedPawn->GetPawnUniqueIdx() : INDEX_NONE;
	if (nullptr == NewSelectedPawn)
	{
		NewSelectedPawn = CanActionPawnList[0];	// 先选择第一个
		for (int32 i = 0; i < CanActionPawnNum; ++i)
		{
			ACWPawn* GamePawn = CanActionPawnList[i];
			const int32 GPawnUniqueIdx = GamePawn->GetPawnUniqueIdx();
			if (GPawnUniqueIdx > CurSelectedUniqueIdx)
			{
				NewSelectedPawn = GamePawn;
				break;
			}
		}
	}

	// TODO: 切换自己棋子
	if (nullptr != NewSelectedPawn)
	{
		if (CurSelectedPawn != NewSelectedPawn)
		{
			CancelPlayerInputData();
			SetCurSelectedPawnInClient(NewSelectedPawn);
			// 设置选定地图格子
			const int32 TileNumber = NewSelectedPawn->GetTile();
			ACWMapTile* NewSelectedTile = MyMapActor ? MyMapActor->GetTile(TileNumber) : nullptr;
			if (nullptr != NewSelectedTile)
			{
				SetCurSelectedTileInClient(NewSelectedTile);
			}
		}
	}
}

void ACWPlayerController::ShowHitMarkSpline(const bool bEnableMark, const int32 InHitMarkTile)
{
	// Check Battle State
	const ECWBattleState BattleState = GetBattleState();
	if (BattleState != ECWBattleState::Fighting)
	{
		return;
	}

	// Check Spline Actor
	const bool bValidSplineActor = IsValidActor(SplineHitMaskActor);
	if (bEnableMark && !bValidSplineActor)
	{
		UClass* ClassSplineActor = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_AimLine);
		if (nullptr == ClassSplineActor)
		{
			CWG_ERROR(">> ShowHitMarkSpline, Fail!!! BP_AimLine is nullptr.");
			return;
		}
		SplineHitMaskActor = GetWorld()->SpawnActor<ACWSplineActor>(ClassSplineActor);
	}else if (bEnableMark && bValidSplineActor)
	{	// Clearup
		//SplineHitMaskActor->HideAllParticleComps();
		SplineHitMaskActor->DestroyAllParticleComps();
	}else if (!bEnableMark && bValidSplineActor)
	{	// Clearup
		//SplineHitMaskActor->HideAllParticleComps();
		SplineHitMaskActor->DestroyAllParticleComps();
		return;
	}else if (!bEnableMark && !bValidSplineActor)
	{
		return;
	}

	// Check Game Actor
	ACWMap* MyMapActor = GetMap();
	ACWRandomDungeonGenerator* Generator = GetDungeonGenerator();
	ACWDungeonTile* HitMarkDungeonTile = Generator ? Generator->GetDungeonTile(InHitMarkTile) : nullptr;
	if (nullptr == MyMapActor || nullptr == Generator || nullptr == HitMarkDungeonTile)
	{
		CWG_WARNING(">> %s::ShowHitMarkSpline, bEnableMark[%d] InHitMarkTile[%d] is invalid!", *GetName(), (int32)bEnableMark, InHitMarkTile);
		return;
	}

	// Check Hit Mark Pawn(Pawn & MyClientPawn)
	ACWPawn* HitMarkPawn = PlayerState ? GetCurSelectedPawn() : nullptr;//MyMapActor->GetPawnByTile(InHitMarkTile).Get();
	if (nullptr == HitMarkPawn || !HitMarkPawn->IsPawnType(ECWPawnType::Character) || !HitMarkPawn->IsMyClientPawn())
	{
		CWG_LOG(">> %s::ShowHitMarkSpline, bEnableMark[%d] InHitMarkTile[%d] HitMarkPawn is invalid!", *GetName(), (int32)bEnableMark, InHitMarkTile);
		return;
	}

	// 条件: 获取/排序
	auto NewGetPredicate = [this](const ACWPawn* InPawn) -> bool
	{
		return IsValidActor(InPawn) && InPawn->IsPawnType(ECWPawnType::Character) && IsEnemy(InPawn) && !InPawn->IsDieOrDeath();
	};

	TArray<ACWPawn*> AllEnemyPawns;
	int32 EnemyPawnNum = UCWFuncLib::GetAllActors<ACWPawn>(this, AllEnemyPawns, NewGetPredicate);
	if (EnemyPawnNum > 0)
	{
		// 获取可标记敌人棋子
		TArray<ACWPawn*> CasterMarkEnemyPawns;
		for (int32 i = 0; i < EnemyPawnNum; ++i)
		{
			ACWPawn* EnemyPawn = AllEnemyPawns[i];
			const int32 EnemyPawnTile = EnemyPawn->GetTile();
			if (EnemyPawn->RefreshMoveAttackDamageTile(EnemyPawnTile, false))
			{
				uint8 TileProperty = MyMapActor->GetMoveAttackDamage(InHitMarkTile);
				const ECWMapTileMoveAttackDamageType DamageType = (ECWMapTileMoveAttackDamageType)TileProperty;
				if ((TileProperty & (uint8)ECWMapTileMoveAttackDamageType::Attack) > 0/* ||
					(TileProperty & (uint8)ECWMapTileMoveAttackDamageType::Attack) > 0*/)
				{
					CasterMarkEnemyPawns.AddUnique(EnemyPawn);
				}
			}
		}

		// TODO: 绘制标记显示
		//const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("HitMarkOffsetZ"));
		//const float HitMarkOffsetZ = (ConstData && !ConstData->Param.IsEmpty()) ? FSTRING_TO_FLOAT(ConstData->Param) : 200.f;
		FVector EndPoint = HitMarkDungeonTile->GetActorLocation();
		EndPoint.Z = HitMarkPawn->GetHitMarkOverrideZ();
		TArray<FVector> InTargetPoints;
		for (int32 k = 0; k < CasterMarkEnemyPawns.Num(); ++k)
		{
			const ACWPawn* EnemyPawn = CasterMarkEnemyPawns[k];
			FVector StartPoint = EnemyPawn->GetActorLocation();
			StartPoint.Z = EnemyPawn->GetHitMarkOverrideZ();
			InTargetPoints.AddUnique(StartPoint);
			/*TArray<FVector> InPoints = GetMarkLinePath(StartPoint, EndPoint);
			SplineHitMaskActor->SetSplineWorldPoints(k, InPoints, ECWSplineMeshType::HitMark);*/
		}
		SplineHitMaskActor->SetActorLocation(EndPoint);
		SplineHitMaskActor->SetParticleTargetLocations(InTargetPoints);
	}
}

TArray<FVector> ACWPlayerController::GetMarkLinePath(const FVector& InStartPoint, const FVector& InEndPoint, const uint8 InCalcType)
{
	TArray<FVector> RetValue;
	switch (InCalcType)
	{
	case 0:
	{
		const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("HitMarkDistFactor"));
		const float SplineHeightFactor = (ConstData && !ConstData->Param.IsEmpty()) ? FSTRING_TO_FLOAT(ConstData->Param) : 0.3f;

		const FVector NewOffset = (InEndPoint - InStartPoint) / 2.f;
		const float NewDistance = FVector::Dist(InStartPoint, InEndPoint);
		const FVector InMidPoint = InStartPoint + NewOffset + FVector(0.f, 0.f, NewDistance * SplineHeightFactor);
		RetValue.AddUnique(InStartPoint); RetValue.AddUnique(InMidPoint); RetValue.AddUnique(InEndPoint);
		//CWG_WARNING(">> ShowHitMark Point, StartPoint[%s] MidPoint[%s] EndPoint[%s] NewOffset[%s] NewDistance[%f].", 
			//*InStartPoint.ToString(), *InMidPoint.ToString(), *InEndPoint.ToString(), *NewOffset.ToString(), NewDistance);
	}break;
	}

	return RetValue;
}

void ACWPlayerController::ShowMoveAttackSpline(const TArray<ACWMapTile*>& InMoveTiles, const TArray<ACWMapTile*>& InAttackTiles)
{
	// Close Function
	//return;

	// Check Battle State
	const ECWBattleState BattleState = GetBattleState();
	if (BattleState != ECWBattleState::Ready && BattleState != ECWBattleState::Fighting)
	{
		return;
	}

	// Check Spline Actor
	const bool bValidSplineActor = IsValidActor(SplineMoveActor);
	if (!bValidSplineActor)
	{
		//UClass* ClassSplineActor = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_SplineActor);
		//ClassSplineActor = ClassSplineActor ? ClassSplineActor : ACWSplineActor::StaticClass();
		SplineMoveActor = GetWorld()->SpawnActor<ACWSplineActor>(/*ClassSplineActor*/ACWSplineActor::StaticClass());
		check(SplineMoveActor);
		// Setter
		SplineMoveActor->SetSplineMeshPosTangent(FVector::ZeroVector, FVector::ZeroVector, FVector::ZeroVector, FVector::ZeroVector);
	}
	else
	{	// Clearup
		SplineMoveActor->DestroyAllComponent();
	}

	const int32 MoveTileNum = InMoveTiles.Num();
	const int32 AttackTileNum = InAttackTiles.Num();
	if (MoveTileNum <= 0 && AttackTileNum <= 0)
	{
		CWG_WARNING(">> %s::ShowMoveAttackSpline, MoveTileNum[0] AttackTileNum[0] is invalid!", *GetName());
		return;
	}

	int32 NewSplineLineIdx = 0;
	TArray<FIntFringe> OutFringeArray;
	// Calc Fringe Spline(MoveTile)
	if (GetMoveFringeLineArray(OutFringeArray, InMoveTiles) >= 4)
	{
		DrawFringeLineSpline(OutFringeArray, NewSplineLineIdx, ECWSplineMeshType::MoveArea, false);
	}

	// Calc Fringe Spline(AttackTile)
	if (GetAttackFringeLineArray(OutFringeArray, InAttackTiles, InMoveTiles) >= 4)
	{
		DrawFringeLineSpline(OutFringeArray, NewSplineLineIdx, ECWSplineMeshType::AttackArea, false);
	}
}

int32 ACWPlayerController::GetMoveFringeLineArray(TArray<FIntFringe>& OutFringeArray, const TArray<ACWMapTile*>& InTiles)
{
	OutFringeArray.Empty();
	// Check Game Actor
	ACWMap* MyMapActor = GetMap();
	if (nullptr == MyMapActor)
	{
		CWG_WARNING(">> GetMoveFringeLineArray, MyMapActor is nullptr!!!");
		return 0;
	}
	const int32 HalfDistance = MyMapActor->getGridWidth() / 2;
	//const int32 HalfDistanceY = MyMapActor->getGridHeight() / 2;
	
	// Calc Fringe Spline
	const int32 InTileNum = InTiles.Num();
	for (int32 i = 0; i < InTileNum; ++i)
	{
		ACWMapTile* MapTileActor = InTiles[i];
		const int32 MapTileNum = MapTileActor ? MapTileActor->GetTile() : INDEX_NONE;
		if (MapTileNum != INDEX_NONE)
		{
			const FVector TilePoint = MapTileActor->GetActorLocation();
			FIntVector TileCoord = FIntVector::ZeroValue;
			MyMapActor->tile2xy(MapTileNum, TileCoord.X, TileCoord.Y);

			// 下边缘
			FIntVector DTileCoord = FIntVector(TileCoord.X, TileCoord.Y - 1, 0);
			const int32 DTileNum = MyMapActor->xy2tile(DTileCoord.X, DTileCoord.Y);
			ACWMapTile* DTileActor = MyMapActor->GetTile(DTileNum);
			if ((nullptr == DTileActor) ||
				(nullptr != DTileActor && !InTiles.Contains(DTileActor)))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Down_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BD_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ED_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Down_")));
				UCWFuncLib::PrintTxtInfo(DTileActor, INT_TO_FTEXT(DTileNum));
				CWG_WARNING(">> OutFringeArray, Down: MapTileNum[%d] DTileNum[%d] NewFringe[%s].", MapTileNum, DTileNum, *NewFringe.ToString());*/
			}

			// 右边缘
			FIntVector RTileCoord = FIntVector(TileCoord.X + 1, TileCoord.Y, 0);
			const int32 RTileNum = MyMapActor->xy2tile(RTileCoord.X, RTileCoord.Y);
			ACWMapTile* RTileActor = MyMapActor->GetTile(RTileNum);
			if ((nullptr == RTileActor) ||
				(nullptr != RTileActor && !InTiles.Contains(RTileActor)))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Right_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BR_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ER_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Right_")));
				UCWFuncLib::PrintTxtInfo(RTileActor, INT_TO_FTEXT(RTileNum));
				CWG_WARNING(">> OutFringeArray, Right: MapTileNum[%d] RTileNum[%d] NewFringe[%s].", MapTileNum, RTileNum, *NewFringe.ToString());*/
			}

			// 上边缘
			FIntVector TTileCoord = FIntVector(TileCoord.X, TileCoord.Y + 1, 0);
			const int32 TTileNum = MyMapActor->xy2tile(TTileCoord.X, TTileCoord.Y);
			ACWMapTile* TTileActor = MyMapActor->GetTile(TTileNum);
			if ((nullptr == TTileActor) ||
				(nullptr != TTileActor && !InTiles.Contains(TTileActor)))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Top_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BT_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ET_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Top_")));
				UCWFuncLib::PrintTxtInfo(TTileActor, INT_TO_FTEXT(TTileNum));
				CWG_WARNING(">> OutFringeArray, Top: MapTileNum[%d] TTileNum[%d] NewFringe[%s].", MapTileNum, TTileNum, *NewFringe.ToString());*/
			}

			// 左边缘
			FIntVector LTileCoord = FIntVector(TileCoord.X - 1, TileCoord.Y, 0);
			const int32 LTileNum = MyMapActor->xy2tile(LTileCoord.X, LTileCoord.Y);
			ACWMapTile* LTileActor = MyMapActor->GetTile(LTileNum);
			if ((nullptr == LTileActor) ||
				(nullptr != LTileActor && !InTiles.Contains(LTileActor)))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Left_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BL_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("EL_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Left_")));
				UCWFuncLib::PrintTxtInfo(LTileActor, INT_TO_FTEXT(LTileNum));
				CWG_WARNING(">> OutFringeArray, Left: MapTileNum[%d] LTileNum[%d] NewFringe[%s].", MapTileNum, LTileNum, *NewFringe.ToString());*/
			}
		}
	}
	return OutFringeArray.Num();
}

int32 ACWPlayerController::GetAttackFringeLineArray(TArray<FIntFringe>& OutFringeArray, const TArray<ACWMapTile*>& InTiles, const TArray<ACWMapTile*>& InMoveTiles)
{
	OutFringeArray.Empty();
	// Check Game Actor
	ACWMap* MyMapActor = GetMap();
	if (nullptr == MyMapActor)
	{
		CWG_WARNING(">> GetMoveFringeLineArray, MyMapActor is nullptr!!!");
		return 0;
	}
	const int32 HalfDistance = MyMapActor->getGridWidth() / 2;
	//const int32 HalfDistanceY = MyMapActor->getGridHeight() / 2;

	// Calc Fringe Spline
	const int32 InTileNum = InTiles.Num();
	for (int32 i = 0; i < InTileNum; ++i)
	{
		ACWMapTile* MapTileActor = InTiles[i];
		const int32 MapTileNum = MapTileActor ? MapTileActor->GetTile() : INDEX_NONE;
		if (MapTileNum != INDEX_NONE)
		{
			const FVector TilePoint = MapTileActor->GetActorLocation();
			FIntVector TileCoord = FIntVector::ZeroValue;
			MyMapActor->tile2xy(MapTileNum, TileCoord.X, TileCoord.Y);

			// 下边缘
			FIntVector DTileCoord = FIntVector(TileCoord.X, TileCoord.Y - 1, 0);
			const int32 DTileNum = MyMapActor->xy2tile(DTileCoord.X, DTileCoord.Y);
			ACWMapTile* DTileActor = MyMapActor->GetTile(DTileNum);
			if ((nullptr == DTileActor) ||
				(nullptr != DTileActor && !InTiles.Contains(DTileActor)/* && !InMoveTiles.Contains(DTileActor)*/))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Down_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BD_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ED_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Down_")));
				UCWFuncLib::PrintTxtInfo(DTileActor, INT_TO_FTEXT(DTileNum));
				CWG_WARNING(">> OutFringeArray, Down: MapTileNum[%d] DTileNum[%d] NewFringe[%s].", MapTileNum, DTileNum, *NewFringe.ToString());*/
			}

			// 右边缘
			FIntVector RTileCoord = FIntVector(TileCoord.X + 1, TileCoord.Y, 0);
			const int32 RTileNum = MyMapActor->xy2tile(RTileCoord.X, RTileCoord.Y);
			ACWMapTile* RTileActor = MyMapActor->GetTile(RTileNum);
			if ((nullptr == RTileActor) ||
				(nullptr != RTileActor && !InTiles.Contains(RTileActor)/* && !InMoveTiles.Contains(RTileActor)*/))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Right_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BR_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ER_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Right_")));
				UCWFuncLib::PrintTxtInfo(RTileActor, INT_TO_FTEXT(RTileNum));
				CWG_WARNING(">> OutFringeArray, Right: MapTileNum[%d] RTileNum[%d] NewFringe[%s].", MapTileNum, RTileNum, *NewFringe.ToString());*/
			}

			// 上边缘
			FIntVector TTileCoord = FIntVector(TileCoord.X, TileCoord.Y + 1, 0);
			const int32 TTileNum = MyMapActor->xy2tile(TTileCoord.X, TTileCoord.Y);
			ACWMapTile* TTileActor = MyMapActor->GetTile(TTileNum);
			if ((nullptr == TTileActor) ||
				(nullptr != TTileActor && !InTiles.Contains(TTileActor)/* && !InMoveTiles.Contains(TTileActor)*/))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X + HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Top_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BT_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("ET_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Top_")));
				UCWFuncLib::PrintTxtInfo(TTileActor, INT_TO_FTEXT(TTileNum));
				CWG_WARNING(">> OutFringeArray, Top: MapTileNum[%d] TTileNum[%d] NewFringe[%s].", MapTileNum, TTileNum, *NewFringe.ToString());*/
			}

			// 左边缘
			FIntVector LTileCoord = FIntVector(TileCoord.X - 1, TileCoord.Y, 0);
			const int32 LTileNum = MyMapActor->xy2tile(LTileCoord.X, LTileCoord.Y);
			ACWMapTile* LTileActor = MyMapActor->GetTile(LTileNum);
			if ((nullptr == LTileActor) ||
				(nullptr != LTileActor && !InTiles.Contains(LTileActor)/* && !InMoveTiles.Contains(LTileActor)*/))
			{
				const FIntFringe NewFringe = FIntFringe(
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y + HalfDistance, TilePoint.Z),
					FIntVector(TilePoint.X - HalfDistance, TilePoint.Y - HalfDistance, TilePoint.Z),
					MapTileNum, TEXT("Left_"));
				OutFringeArray.Add(NewFringe);

				// Temp Code
				/*const FString& NewTxtB = FString::Printf(TEXT("BL_%d_%d"), OutFringeArray.Num(), NewFringe.BeginPoint.Z);
				const FString& NewTxtE = FString::Printf(TEXT("EL_%d_%d"), OutFringeArray.Num(), NewFringe.EndPoint.Z);
				PrintTxtRenderCreateActor(NewFringe.BeginPoint, FSTRING_TO_FTEXT(NewTxtB));
				PrintTxtRenderCreateActor(NewFringe.EndPoint, FSTRING_TO_FTEXT(NewTxtE));
				PrintTxtRenderCreateActor(NewFringe.BeginPoint + (NewFringe.EndPoint - NewFringe.BeginPoint) / 2, FSTRING_TO_FTEXT(TEXT("Left_")));
				UCWFuncLib::PrintTxtInfo(LTileActor, INT_TO_FTEXT(LTileNum));
				CWG_WARNING(">> OutFringeArray, Left: MapTileNum[%d] LTileNum[%d] NewFringe[%s].", MapTileNum, LTileNum, *NewFringe.ToString());*/
			}
		}
	}
	return OutFringeArray.Num();
}

bool ACWPlayerController::DrawFringeLineSpline(TArray<FIntFringe>& InFringeArray, int32& OutSplineIdx, const ECWSplineMeshType InSplineType, const bool bDrawOnce)
{
	// Check Game Actor
	ACWMap* MyMapActor = GetMap();
	if (nullptr == MyMapActor)
	{
		CWG_WARNING(">> DrawFringeLineSpline, MyMapActor is nullptr!!!");
		return false;
	}

	// Calc Fringe Spline
	bool bIsDrawOk = false;
	if (InFringeArray.Num() >= 4)
	{
		// Offset Height
		const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(this, FCWCfgKey::CommConst, TEXT("SplineOffsetHeight"));
		int32 NewOffsetHeight = (nullptr != ConstData) ? FSTRING_TO_INT(ConstData->Param) : 5;

		// Main Loop Max Num
		int32 MainLoopMaxFindNum = 0;
		const int32 MaxNearDist = 50;
		auto GetFinalDrawPoint = [NewOffsetHeight](const FIntVector& InPoint)
		{
			return FVector(InPoint) + FVector(0.f, 0.f, NewOffsetHeight);
		};

		while (InFringeArray.Num() > 0)
		{
			// Check...
			if (bDrawOnce && MainLoopMaxFindNum >= 1)
			{
				break;
			}else if (MainLoopMaxFindNum++ >= 101)
			{
				CWG_ERROR(">> Start(InSplineType[%d]), MainLoopMaxFindNum[101].", (int32)InSplineType);
				break;
			}
			
			// Calc singe chunk spline
			int32 MaxFindNum = 0;
			TArray<FVector> DrawPints;
			FIntFringe GetOneFringe = FIntFringe(InFringeArray[0]);
			const FIntFringe StartFringe = GetOneFringe;
			//CWG_ERROR(">> Start(InSplineType[%d]): InFringeArray.Num[%d], GetOneFringe[%s]...", InSplineType, InFringeArray.Num(), *GetOneFringe.ToString());
			while (InFringeArray.Num() > 0)
			{
				// Temp Code
				//PrintTxtRenderActor(GetOneFringe.BeginPoint, FSTRING_TO_FTEXT(TEXT("B_") + INT_TO_FSTRING(MaxFindNum)), FColor::Green);
				//PrintTxtRenderActor(GetOneFringe.EndPoint, FSTRING_TO_FTEXT(TEXT("E_") + INT_TO_FSTRING(MaxFindNum)), FColor::Green);
				//ACWMapTile* TmpMapTile = MyMapActor->GetTile(GetOneFringe.IntParam);
				//UCWFuncLib::PrintTxtInfo(TmpMapTile, INT_TO_FTEXT(GetOneFringe.IntParam), FColor::Green);

				// Check...
				if (MaxFindNum++ >= 1001 || !GetOneFringe.IsValid())
				{
					CWG_ERROR(">> Break(InSplineType[%d]), MaxGetNum[1001] GetOneFringe[%s].", (int32)InSplineType, *GetOneFringe.ToString());
					InFringeArray.Remove(FIntFringe(GetOneFringe));	// Force Remove Invalid Fringe
					break;
				}

				// Search Next Fringe
				DrawPints.AddUnique(GetFinalDrawPoint(GetOneFringe.BeginPoint));
				DrawPints.AddUnique(GetFinalDrawPoint(GetOneFringe.EndPoint));
				const FIntFringe* FindFringe = InFringeArray.FindByPredicate(
				[GetOneFringe, MaxNearDist](const FIntFringe& InFringe)
				{
					return GetOneFringe.IsNearPointXY(InFringe, MaxNearDist);
				});
				if (nullptr != FindFringe)
				{
					FIntFringe NewFindFringe = FIntFringe(*FindFringe);
					InFringeArray.Remove(FIntFringe(GetOneFringe));
					GetOneFringe = NewFindFringe;
					continue;
				}

				const int32 RemainFringeNum = InFringeArray.Num();
				if (RemainFringeNum > 1)
				{
					//CWG_WARNING(">> Break(InSplineType[%d]), FindFringe is nullptr. GetOneFringe[%s] RemainFringeNum[%d].", InSplineType, *GetOneFringe.ToString(), RemainFringeNum);
				}
				InFringeArray.Remove(FIntFringe(GetOneFringe));	// Force Remove Invalid Fringe
				/*PrintTxtRenderCreateActor(
					GetOneFringe.BeginPoint + (GetOneFringe.EndPoint - GetOneFringe.BeginPoint) / 2,
					FSTRING_TO_FTEXT(GetOneFringe.StringParam));*/
				break;
			}
			// Draw Spline Point
			if (DrawPints.Num() >= 4)
			{
				bIsDrawOk = true;
				if (GetOneFringe.IsNearPointXY(StartFringe) &&
					GetOneFringe.IntParam == StartFringe.IntParam)
				{	// Add Start Point
					DrawPints.Add(GetFinalDrawPoint(StartFringe.BeginPoint));
					//DrawPints.Add(GetFinalDrawPoint(StartFringe.EndPoint));
				}
				SplineMoveActor->SetSplineWorldPointsImpl(OutSplineIdx++, DrawPints, InSplineType/*, true*/);
			}
		}
	}else
	{
		CWG_WARNING(">> %s::DrawFringeLineSpline, InSplineType[%d] InFringeArray.Num[%d] is invalid!", *GetName(), (int32)InSplineType, InFringeArray.Num());
	}

	return bIsDrawOk;
}

void ACWPlayerController::HideMoveAttackSpline()
{
	// Close Function
	//return;

	if (IsValidActor(SplineMoveActor))
	{	// Clearup
		SplineMoveActor->DestroyAllComponent();
	}

	// Temp Code
	/*ACWMap* MyMapActor = GetMap();
	if (nullptr != MyMapActor)
	{
		const TArray<ACWMapTile*>& AllMapTiles = MyMapActor->GetArrayTiles();
		for (int32 i = 0; i < AllMapTiles.Num(); ++i)
		{
			ACWMapTile* MapTileActor = AllMapTiles[i];
			UCWFuncLib::PrintTxtInfo(MapTileActor);
		}
	}
	for (const TPair<FIntVector, ACWSimpleActor*>& RenderElem : MapRenderActors)
	{
		ACWSimpleActor* TmpSimpleActor = RenderElem.Value;
		if (nullptr != TmpSimpleActor)
		{
			UCWFuncLib::PrintTxtInfo(TmpSimpleActor);
		}
	}
	for (const TPair<FIntVector, ACWSimpleActor*>& RenderElem : MapRenderCreateActors)
	{
		ACWSimpleActor* TmpSimpleActor = RenderElem.Value;
		if (nullptr != TmpSimpleActor)
		{
			UCWFuncLib::PrintTxtInfo(TmpSimpleActor);
		}
	}*/
}

ACWSimpleActor* ACWPlayerController::GetRenderActor(const FIntVector& InKey)
{
	ACWSimpleActor* RetValue = MapRenderActors.FindRef(InKey);
	if (nullptr == RetValue)
	{
		RetValue = GetWorld()->SpawnActor<ACWSimpleActor>();
		check(RetValue);

		RetValue->SetActorLocation(FVector(InKey));
		MapRenderActors.Add(InKey, RetValue);
	}
	return RetValue;
}

ACWSimpleActor* ACWPlayerController::GetRenderCreateActor(const FIntVector& InKey)
{
	ACWSimpleActor* RetValue = MapRenderCreateActors.FindRef(InKey);
	if (nullptr == RetValue)
	{
		RetValue = GetWorld()->SpawnActor<ACWSimpleActor>();
		check(RetValue);

		RetValue->SetActorLocation(FVector(InKey));
		MapRenderCreateActors.Add(InKey, RetValue);
	}
	return RetValue;
}

void ACWPlayerController::PrintTxtRenderActor(const FIntVector& InKey, const FText& InText /*= FText()*/, const FColor& InClolor)
{
	ACWSimpleActor* TmpSimpleActor = GetRenderActor(InKey);
	UCWFuncLib::PrintTxtInfo(TmpSimpleActor, InText, InClolor, 130, InKey.Z + 100.f);
}

void ACWPlayerController::PrintTxtRenderCreateActor(const FIntVector& InKey, const FText& InText /*= FText()*/)
{
	ACWSimpleActor* TmpSimpleActor = GetRenderCreateActor(InKey);
	UCWFuncLib::PrintTxtInfo(TmpSimpleActor, InText, FColor::Yellow, 70, InKey.Z + 120.f);
}

void ACWPlayerController::ShowMovePathSpline(const TArray<FVector>& InMovePaths)
{
	// Close Function
	//return;

	// Check Battle State
	const ECWBattleState BattleState = GetBattleState();
	if (BattleState != ECWBattleState::Fighting)
	{
		return;
	}

	// Check Spline Actor
	const bool bValidSplineActor = IsValidActor(SplineMovePathActor);
	if (!bValidSplineActor)
	{
		//UClass* ClassSplineActor = FCWCfgUtils::GetAssetClass(this, FCWCommClassKey::BP_SplineActor);
		//ClassSplineActor = ClassSplineActor ? ClassSplineActor : ACWSplineActor::StaticClass();
		SplineMovePathActor = GetWorld()->SpawnActor<ACWSplineActor>(/*ClassSplineActor*/ACWSplineActor::StaticClass());
		check(SplineMovePathActor);
		// Setter
		//SplineMovePathActor->SetSplineMeshPosTangent(FVector::ZeroVector, FVector::ZeroVector, FVector::ZeroVector, FVector::ZeroVector);
	}
	else
	{	// Clearup
		SplineMovePathActor->DestroyAllComponent();
	}

	if (InMovePaths.Num() >= 2)
	{
		SplineMovePathActor->SetSplineWorldPointsImpl(0, InMovePaths, ECWSplineMeshType::MovePath);
	}
}

void ACWPlayerController::HideMovePathSpline()
{
	// Close Function
	//return;

	if (IsValidActor(SplineMovePathActor))
	{	// Clearup
		SplineMovePathActor->DestroyAllComponent();
	}
}

void ACWPlayerController::CWG_ShowHitMarkObjectTile(const bool bEnableMark, const int32 InHitMarkTile)
{
	ShowHitMarkSpline(bEnableMark, InHitMarkTile);
}

void ACWPlayerController::ClientRespondPawnActionEnd_Implementation(
	const ECWCampTag InPawnCampTag, 
	const ECWCampControllerIndex InPawnCampControllerIndex, 
	const int32 PawnControllerPawnIndex)
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnPlayerPawnActionEndClient.Broadcast(InPawnCampTag, InPawnCampControllerIndex, PawnControllerPawnIndex);
	}
}

void ACWPlayerController::ClientSendMessage_Implementation(int32 InMsgId, const FString& InParam)
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnPlayerSendMessage.Broadcast(InMsgId, InParam);
	}
}

const TArray<FCWPawnNetData>& ACWPlayerController::GetExtPawnData()
{
	return ExtraPawnDatas;
}

bool ACWPlayerController::ServerAddPawnToTile_Validate(const FString& InNewNetPawnId, const int32 InTile)
{
	return true;
}

void ACWPlayerController::ServerAddPawnToTile_Implementation(const FString& InNewNetPawnId, const int32 InTile)
{
	if (InNewNetPawnId.IsEmpty() || InTile < 0)
	{
		CWG_ERROR(">> %s::ServerAddPawnToTile, ERROR! InNetPawnId[%s] InTile[%d] is invalid!", *CWG_NAME(this), *InNewNetPawnId, InTile);
		return;
	}

	ACWMap* MyMapActor = GetMap();
	const bool bIsContains = ExtraPawnDatas.ContainsByPredicate(
	[InNewNetPawnId](const FCWPawnNetData& InPawnNetData)
	{
		return InPawnNetData.UUID == InNewNetPawnId;
	});
	if (!IsValidActor(MyMapActor) || !bIsContains)
	{
		CWG_ERROR(">> %s::ServerAddPawnToTile, ERROR! InNetPawnId[%s] InTile[%d] bIsContains[%d] is invalid!", *CWG_NAME(this), *InNewNetPawnId, InTile, (int32)bIsContains);
		return;
	}

	UCWNetPlayerData* MyNetPlayerData = GetNetPlayerData();
	const uint64 MyNetPawnIDUUID = FCWUtils::FString2Uint64(InNewNetPawnId);
	UCWNetHeroData* MyNetHeroData = MyNetPlayerData ? MyNetPlayerData->GetNetHeroData(MyNetPawnIDUUID) : nullptr;
	if (nullptr == MyNetHeroData)
	{
		CWG_ERROR(">> %s::ServerAddPawnToTile, ERROR! MyNetHeroData[%s] InTile[%d] is invalid!", *CWG_NAME(this), *InNewNetPawnId, InTile);
		return;
	}

	ACWPawnStart* PawnStart = MyMapActor->GetPawnStartByTile(InTile);
	if (IsValidActor(PawnStart))
	{
		if (ACWPawn* TmpPawn = MyMapActor->GetPawnByTile(InTile).Get())
		{
			const FString TempNetPawnId = TmpPawn->GetPeripheralNetId();
			const uint64 TempNetPawnIDUUID = FCWUtils::FString2Uint64(TempNetPawnId);
			UCWNetHeroData* TempNetHeroData = MyNetPlayerData ? MyNetPlayerData->GetNetHeroData(TempNetPawnIDUUID) : nullptr;

			if (IsPartner(TmpPawn) && IsValidObject(TempNetHeroData) && TempNetPawnId != InNewNetPawnId)
			{	// 切换棋子
				ExtraPawnDatas.RemoveAll(
				[InNewNetPawnId](const FCWPawnNetData& InPawnNetData)
				{
					return InPawnNetData.UUID == InNewNetPawnId;
				});
				FCWPawnNetData NewPawnNetData = TmpPawn->GetPawnNetData();
				ExtraPawnDatas.AddUnique(NewPawnNetData);
				SortExtPawnIdList();

				MapPawns.Remove(FCWPawnKey(TmpPawn->GetCampTag(), TmpPawn->GetCampControllerIndex(), TmpPawn->GetControllerPawnIndex()));
				TmpPawn->Destroy();

				SpawnPawnByPawnStart(PawnStart, InNewNetPawnId);
			}
		}
		else if (PawnStart->IsSameCampAndCtrl(GetCampTag(), GetCampControllerIndex()))
		{	// 增加棋子
			ExtraPawnDatas.RemoveAll(
			[InNewNetPawnId](const FCWPawnNetData& InPawnNetData)
			{
				return InPawnNetData.UUID == InNewNetPawnId;
			});

			SpawnPawnByPawnStart(PawnStart, InNewNetPawnId);
		}
	}
	else
	{
		CWG_WARNING(">> %s::ServerAddPawnToTile, InTile[%d]/InNetPawnId[%d] is invalid!", *GetName(), InTile, *InNewNetPawnId);
	}
}

bool ACWPlayerController::ServerRemovePawnFromTile_Validate(const int32 InTile)
{
	return true;
}

void ACWPlayerController::ServerRemovePawnFromTile_Implementation(const int32 InTile)
{
	ACWMap* MyMapActor = GetMap();
	if (!IsValidActor(MyMapActor) || InTile < 0)
	{
		CWG_ERROR(">> %s::ServerAddPawnToTile, ERROR! InTile[%d] is invalid!", *CWG_NAME(this), InTile);
		return;
	}

	UCWNetPlayerData* MyNetPlayerData = GetNetPlayerData();
	if (nullptr == MyNetPlayerData)
	{
		CWG_ERROR(">> %s::ServerRemovePawnFromTile, ERROR! MyNetPlayerData[None] InTile[%d] is invalid!", *CWG_NAME(this), InTile);
		return;
	}

	ACWPawnStart* PawnStart = MyMapActor->GetPawnStartByTile(InTile);
	if (IsValidActor(PawnStart))
	{
		if (ACWPawn* TmpPawn = MyMapActor->GetPawnByTile(InTile).Get())
		{
			const FString TempNetPawnId = TmpPawn->GetPeripheralNetId();
			const uint64 TempNetPawnIDUUID = FCWUtils::FString2Uint64(TempNetPawnId);
			UCWNetHeroData* TempNetHeroData = MyNetPlayerData ? MyNetPlayerData->GetNetHeroData(TempNetPawnIDUUID) : nullptr;

			if (IsPartner(TmpPawn) && IsValidObject(TempNetHeroData) && CanRemovePawnInReady())
			{	// 移出棋子
				FCWPawnNetData NewPawnNetData = TmpPawn->GetPawnNetData();
				ExtraPawnDatas.AddUnique(NewPawnNetData);
				SortExtPawnIdList();

				MapPawns.Remove(FCWPawnKey(TmpPawn->GetCampTag(), TmpPawn->GetCampControllerIndex(), TmpPawn->GetControllerPawnIndex()));
				TmpPawn->Destroy();
			}
		}
	}
}

void ACWPlayerController::OnRep_ExtraPawnDataList()
{
	OnExtraPawnDataCallable.Broadcast(ExtraPawnDatas);
}

void ACWPlayerController::OnRep_ReadyFinished()
{
	OnReadyFinished.Broadcast(bReadyFinished);
}

bool ACWPlayerController::CanRemovePawnInReady()
{
	const int32 MyPawnNum = MapPawns.Num();
	bool RetValue = MyPawnNum > 1;
	if (!RetValue)
	{
		ClientSendMessage(ReadyLeastPawnNum, INT_TO_FSTRING(MyPawnNum));
	}
	return RetValue;
}

void ACWPlayerController::SortExtPawnIdList()
{
	/*MapExtraPawnData.Sort(
	[](const int32 Left, const int32 Right)
	{
		return Left < Right;
	});*/
}

void ACWPlayerController::SetupMapForClient()
{
	if (IsMyClientPlayerController())
	{
		for (TActorIterator<ACWMap> Iter(GetWorld()); Iter; ++Iter)
		{
			ACWMap* TempMap = *Iter;
			check(TempMap != nullptr);
			//TempMap->init(DungeonId);
			TempMap->createMapForClient();
			TempMap->GenerateMapTiles();
			break;
		}
	}
}


ACWMap* ACWPlayerController::GetMap()
{
	return UCWFuncLib::GetActor<ACWMap>(this);
}

void ACWPlayerController::RegisterPawnInClient(ACWPawn* ParamPawn)
{
	check(ParamPawn);
	ParamPawn->InitInClient(this);
}

void ACWPlayerController::SetDungeonItemToMapInClient()
{
	//for (TActorIterator<ACWDungeonItem> Iter(GetWorld()); Iter; ++Iter)
	//{
	//	ACWDungeonItem* TempDungeonItem = *Iter;
	//	check(TempDungeonItem != nullptr);
	//
	//	TempDungeonItem->InitInClient(this);
	//
	//	bClientDungeonItemInited = true;
	//}
}

void ACWPlayerController::RegisterDungeonItemInClient(ACWDungeonItem* ParamDungeonItem)
{
	check(ParamDungeonItem);
	ParamDungeonItem->InitInClient(this);
}

ACWPawn* ACWPlayerController::GetPawnByCampTagAndControllerIndexAndPawnIndex(
	ECWCampTag ParamCampTag,
	ECWCampControllerIndex ParamCampControllerIndex, 
	int32 ParamPawnIndex)
{
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* MyPawn = *Iter;
		check(MyPawn);
		if (MyPawn->GetCampTag() == ParamCampTag &&
			MyPawn->GetCampControllerIndex() == ParamCampControllerIndex &&
			MyPawn->GetControllerPawnIndex() == ParamPawnIndex)
		{
			return MyPawn;
		}
	}

	return nullptr;
}

ACWMapTile* ACWPlayerController::GetMapTileByTile(int ParamTile) const
{
	for (TActorIterator<ACWMapTile> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWMapTile* MyMapTile = *Iter;
		check(MyMapTile);
		if (MyMapTile->Tile == ParamTile)
		{
			return MyMapTile;
		}
	}
	return nullptr;
}

void ACWPlayerController::StartActionInServer()
{
	if (!IsInServer())
		return;

	//ClientRPCStartAction();

	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* MyPawn = *Iter;
		check(MyPawn);
		if (MyPawn != nullptr)
			//MyPawn->GetCampTag() == GetCampTag() &&
			//MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			MyPawn->StartActionInServer(GetCampTag(), GetCampControllerIndex());
		}
	}

	this->OnKeyTimeInServer(ECWKeyTimeType::PawnActionBegin);
}

void ACWPlayerController::ClientRPCStartAction_Implementation()
{

}


void ACWPlayerController::ServerRPCDungeonEnd_Implementation()
{
	if (IsInServer())
	{
		bIsDungeonEndInServer = true;

		ACWGameMode* MyGameMode = Cast<ACWGameMode>(GetWorld()->GetAuthGameMode());
		check(MyGameMode);
		ECWBattleState TempCurBattleState = (ECWBattleState)(MyGameMode->GetBattleFSM()->GetCurrentStateId());
		if (TempCurBattleState == ECWBattleState::Dungeon)
		{
			MyGameMode->SomePlayerControllerDungeonEnd();
		}
	}
}

bool ACWPlayerController::ServerRPCDungeonEnd_Validate()
{
	return true;
}

void ACWPlayerController::ServerRPCActionEnd_Implementation()
{
	if (IsInServer())
	{
		Cast<ACWGameMode>(GetWorld()->GetAuthGameMode())->SomePlayerControllerForceActionEnd(this->GetCampTag(), this->GetCampControllerIndex());
	}
}

bool ACWPlayerController::ServerRPCActionEnd_Validate()
{
	return true;
}

void ACWPlayerController::ResetWhenNextTurnBeginInServer()
{
	ClientRPCResetWhenNextTurnBegin();

	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	MyPlayerState->ResetWhenNextTurnBeginInServer();

	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* MyPawn = *Iter;
		check(MyPawn);
		if (MyPawn != nullptr)
			//MyPawn->GetCampTag() == GetCampTag() &&
			//MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			MyPawn->ResetWhenNextTurnBeginInServer(GetCampTag(), GetCampControllerIndex());
		}
	}
	
	this->OnKeyTimeInServer(ECWKeyTimeType::TurnBegin);
}

void ACWPlayerController::TurnEnd()
{
	this->OnKeyTimeInServer(ECWKeyTimeType::TurnEnd);
}

void ACWPlayerController::ClientRPCResetWhenNextTurnBegin_Implementation()
{
	CancelCurSelectedPawnNoEventInClient();
	CancelCurTargetSelectedPawnInClient();
	CancelCurSelectedTileInClient();

	OldDownPawn = nullptr;
	DownPawn = nullptr;
	LongDownTime = 0.0f;
	OldDownTile = nullptr;
	DownTile = nullptr;
	PressTile = nullptr;
	OldPressTile = nullptr;
}

bool ACWPlayerController::IsMyTurn() const
{
	ACWGameState* MyGameState = GetGameState<ACWGameState>();
	check(MyGameState);

	if (this->GetCampTag() == MyGameState->GetCurCampTag() &&
		this->GetCampControllerIndex() == MyGameState->GetCurCampControllerIndex())
	{
		return true;
	}

	return false;
}

bool ACWPlayerController::IsMyTurn(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	ACWGameState* MyGameState = GetGameState<ACWGameState>();
	check(MyGameState);

	if (ParamPawn->GetCampTag() == MyGameState->GetCurCampTag() &&
		ParamPawn->GetCampControllerIndex() == MyGameState->GetCurCampControllerIndex())
	{
		return true;
	}

	return false;
}

bool ACWPlayerController::IsPartner(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	if (ParamPawn->GetCampTag() == MyPlayerState->GetCampTag() &&
		ParamPawn->GetCampControllerIndex() == MyPlayerState->GetCampControllerIndex())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsFriend(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	if (ParamPawn->GetCampTag() == MyPlayerState->GetCampTag() &&
		ParamPawn->GetCampControllerIndex() != MyPlayerState->GetCampControllerIndex())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsEnemy(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	if (ParamPawn->GetCampTag() != MyPlayerState->GetCampTag())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsPartner(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2) const
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() == ParamPawn2->GetCampTag() &&
		ParamPawn1->GetCampControllerIndex() == ParamPawn2->GetCampControllerIndex())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsFriend(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2) const
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() == ParamPawn2->GetCampTag() &&
		ParamPawn1->GetCampControllerIndex() != ParamPawn2->GetCampControllerIndex())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsEnemy(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2) const
{
	check(ParamPawn1);
	check(ParamPawn2);
	if (ParamPawn1->GetCampTag() != ParamPawn2->GetCampTag())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsThereCurSelectedPawn() const
{
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	return IsValidPawnUniqueIdx(MyPlayerState->GetCurCtrlPawnIdx());
}

bool ACWPlayerController::IsThereCurTargetSelectedPawn() const
{
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	return IsValidPawnUniqueIdx(MyPlayerState->GetCurTargetPawnIdx());
}

bool ACWPlayerController::IsThereCurSelectedTile() const
{
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	if (MyPlayerState->GetCurSelectedTile() != -1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ACWPlayerController::IsMeCurSelectedPawn(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState)
	const int32 UniqueIdx = ParamPawn->GetPawnUniqueIdx();
	return IsValidPawnUniqueIdx(UniqueIdx) && (UniqueIdx == MyPlayerState->GetCurCtrlPawnIdx());
}

bool ACWPlayerController::IsMeCurTargetSelectedPawn(const ACWPawn* ParamPawn) const
{
	check(ParamPawn);
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	const int32 UniqueIdx = ParamPawn->GetPawnUniqueIdx();
	return IsValidPawnUniqueIdx(UniqueIdx) && (UniqueIdx == MyPlayerState->GetCurCtrlPawnIdx());
}

void ACWPlayerController::OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType)
{
	if (!IsInServer())
		return;

	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* MyPawn = *Iter;
		check(MyPawn);
		if (MyPawn != nullptr &&
			MyPawn->GetCampTag() == GetCampTag() &&
			MyPawn->GetCampControllerIndex() == GetCampControllerIndex())
		{
			MyPawn->OnKeyTimeInServer(ParamKeyTimeType);
		}
	}
}

void ACWPlayerController::CancelCurSelectedPawnInClient()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	const int32 UniqueIdx = MyPlayerState->GetCurCtrlPawnIdx();
	ACWPawn* CurSelectedPawn = GetPawnByUniqueIdx(this, UniqueIdx);
	if (CurSelectedPawn != nullptr)
	{
		CurSelectedPawn->CancelSelectedInClient();
	}

	ShowSelectedPawnShadow(false);
	SelectPawnInFight = nullptr;
	MyPlayerState->SetCurCtrlPawnIdx(INDEX_NONE);

	NotifyUIHidePreview(CurSelectedPawn);
	NotifyUIHideRoleAttr(CurSelectedPawn);
}

void ACWPlayerController::CancelCurSelectedPawnNoEventInClient()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	const int32 UniqueIdx = MyPlayerState->GetCurCtrlPawnIdx();
	ACWPawn* CurSelectedPawn = GetPawnByUniqueIdx(this, UniqueIdx);
	if (CurSelectedPawn != nullptr)
	{
		CurSelectedPawn->CancelSelectedNoEventInClient();
	}

	ShowSelectedPawnShadow(false);
	SelectPawnInFight = nullptr;
	MyPlayerState->SetCurCtrlPawnIdx(INDEX_NONE);

	NotifyUIHidePreview(CurSelectedPawn, nullptr, 2.5f);
	NotifyUIHideRoleAttr(CurSelectedPawn);
}

void ACWPlayerController::SetCurSelectedPawnInClient(ACWPawn* ParamPawn, bool ParamIsLongDown)
{
	check(ParamPawn);
	CancelCurSelectedPawnInClient();

	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	MyPlayerState->SetCurCtrlPawnIdx(ParamPawn->GetPawnUniqueIdx());

	//SelectPawnInFight = TWeakObjectPtr<ACWPawn>(ParamPawn);
	ParamPawn->SelectedInClient(this, ParamIsLongDown);

	NotifyUIShowRoleAttr(ParamPawn);
}

void ACWPlayerController::CancelCurTargetSelectedPawnInClient()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	const int32 UniqueIdx = MyPlayerState->GetCurTargetPawnIdx();
	ACWPawn* CurTargetSelectedPawn = GetPawnByUniqueIdx(this, UniqueIdx);
	if (nullptr != CurTargetSelectedPawn)
	{
		//CurTargetSelectedPawn->CancelTargetSelected();
		// 目标被取消选中
		CurTargetSelectedPawn->OnBecomeSelectedTarget(false);
	}
	MyPlayerState->SetCurTargetPawnIdx(INDEX_NONE);

	NotifyUIHidePreview(nullptr, CurTargetSelectedPawn);
}

void ACWPlayerController::SetCurTargetSelectedPawnInClient(ACWPawn* ParamPawn)
{
	check(ParamPawn);
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	MyPlayerState->SetCurTargetPawnIdx(ParamPawn->GetPawnUniqueIdx());

	ACWPawn* SelectPawn = GetCurSelectedPawn();
	uint8 TempMoveAttackDamage = 0x00;
	TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
	TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
	if (SelectPawn != nullptr && SelectPawn->IsMoveAttackTileFromTile(SelectPawn->GetTile(), ParamPawn->GetTile(), TempMoveAttackDamage))
	{
		NotifyUIShowPreview(SelectPawn, ParamPawn);
	}

	// 目标被选中
	ParamPawn->OnBecomeSelectedTarget(true, SelectPawn);
}

void ACWPlayerController::CancelCurSelectedTileInClient()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	int CurTile = MyPlayerState->GetCurSelectedTile();
	ACWMapTile* CurSelectedTile = GetMapTileByTile(CurTile);
	if (CurSelectedTile != nullptr)
	{
		CurSelectedTile->CancelSelectedInClient();
	}

	MyPlayerState->SetCurSelectedTile(-1);

	NotifyUIHideTerrain();
}


ACWPawn* ACWPlayerController::GetDownPawn()
{
	//UE_LOG(LogCWPlayerController, Log, TEXT("ACWPlayerController::GetDownPawn DownPawn = %X."), DownPawn);
	if (DownPawn != nullptr)
	{
		return DownPawn;
	}
	else
	{
		if (DownTile != nullptr)
		{
			TWeakObjectPtr<ACWPawn> TempPawn = GetMap()->GetPawnByTile(DownTile->Tile);
			if (TempPawn.IsValid())
			{
				return TempPawn.Get();
			}
			else
			{
				return nullptr;
			}
		}
	}

	return nullptr;
}

ACWMapTile* ACWPlayerController::GetDownTile()
{
	return DownTile;
}

ACWPawn* ACWPlayerController::GetPawnByUniqueIdx(const UObject* InWorldContext, int32 InUniqueId)
{
	if (!IsValidPawnUniqueIdx(InUniqueId))
	{
		return nullptr;
	}

	return UCWFuncLib::GetActor<ACWPawn>(InWorldContext,
	[InUniqueId](const ACWPawn* InPawn)
	{
		const int32 PawnUniqueId = IsValidActor(InPawn) ? InPawn->GetPawnUniqueIdx() : INDEX_NONE;
		return IsValidPawnUniqueIdx(PawnUniqueId) && PawnUniqueId == InUniqueId;
	});
}

bool ACWPlayerController::IsValidPawnUniqueIdx(const int32 InUniqueId)
{
	return InUniqueId > 0;
}

void ACWPlayerController::SetCurSelectedTileInClient(ACWMapTile* ParamMapTile)
{
	check(ParamMapTile);
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);

	MyPlayerState->SetCurSelectedTile(ParamMapTile->Tile);
	ParamMapTile->SelectedInClient(this);

	NotifyUIShowTerrain(ParamMapTile);
}

void ACWPlayerController::CancelPlayerInputData()
{
	//取消当前已选中的格子
	CancelCurSelectedTileInClient();
	//取消已经选中的棋子
	CancelCurSelectedPawnInClient();
	//取消已经选中的目标棋子
	CancelCurTargetSelectedPawnInClient();
}

void ACWPlayerController::CancelSelectedPawnInReady(bool bNeedJumpState)
{
	if (ACWPlayerState* MyPS = this->GetCWPlayerState())
	{
		ACWPawn* CurSelectPawn = GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != CurSelectPawn)
		{
			CurSelectPawn->CancelSelectedInReady(bNeedJumpState);
			SelectPawnInReady = nullptr;
		}
		MyPS->SetCurCtrlPawnIdx(INDEX_NONE);

		NotifyUIHidePreview(CurSelectPawn);
		NotifyUIHideRoleAttr(CurSelectPawn);
	}
}

void ACWPlayerController::CancelSelectedTileInReady()
{
	if (ACWPlayerState* MyPS = this->GetCWPlayerState())
	{
		CancelCurSelectedTileInClient();
	}
}

void ACWPlayerController::SetSelectedPawnInReady(ACWPawn* ParamPawn)
{
	check(ParamPawn);
	if (ACWPlayerState* MyPS = this->GetCWPlayerState())
	{
		CancelSelectedPawnInReady();

		MyPS->SetCurCtrlPawnIdx(ParamPawn->GetPawnUniqueIdx());

		ParamPawn->SelectedInReady(this);
		SelectPawnInReady = ParamPawn;
		ShowSelectedPawnShadow(true);

		NotifyUIShowRoleAttr(ParamPawn);
	}
}

void ACWPlayerController::SetSelectedTileInReady(ACWMapTile* ParamMapTile)
{
	if (ACWPlayerState* MyPS = this->GetCWPlayerState())
	{
		CancelSelectedTileInReady();
		SetCurSelectedTileInClient(ParamMapTile);
	}
}

void ACWPlayerController::InitReadyStateData()
{
	ResetMapTileStateInReady(true);
}

void ACWPlayerController::ClearReadyStateData()
{
	// 取消所有准备操作
	CancelSelectedPawnInReady(false);
	CancelSelectedTileInReady();
	ResetMapTileStateInReady(false);
	//SetNotOwnPawnHidden(false);
	RightSelectPawnInReady = nullptr;
}

void ACWPlayerController::ShowSelectedPawnShadow(bool bNewVisible)
{
	ACWPawn* SelectPawn = GetSelectedPawn(GetBattleState());
	if (nullptr != SelectPawn && IsPartner(SelectPawn)/* && IsMyTurn()*/
		&& (bNewVisible != SelectPawn->IsShadowVisible()))
	{
		SelectPawn->ShowShadowVisible(bNewVisible);
	}
}

ACWPawn* ACWPlayerController::GetSelectedPawn(ECWBattleState InState) const
{
	switch (InState)
	{
	case ECWBattleState::Ready:		return SelectPawnInReady.Get();
	case ECWBattleState::Fighting:	return SelectPawnInFight.Get();
	}
	return nullptr;
}

ACWPawn* ACWPlayerController::GetRightMouseSelectedPawn(ECWBattleState InState) const
{
	switch (InState)
	{
	case ECWBattleState::Ready:		return RightSelectPawnInReady.Get();
	}
	return nullptr;
}

ACWMapTile* ACWPlayerController::GetSelectedTileInReady() const
{
	return SelectTileInReady.Get();
}

ACWPawn* ACWPlayerController::GetCursorOverPawn(ECWBattleState InState) const
{
	switch (InState)
	{
	case ECWBattleState::Fighting:	return CursorOverPawnInFight.Get();
	}
	return nullptr;
}

ACWPawn* ACWPlayerController::GetCurSelectedPawn()
{
	const ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);

	const int32 UniqueIdx = MyPlayerState->GetCurCtrlPawnIdx();
	ACWPawn* CurSelectedPawn = GetPawnByUniqueIdx(this, UniqueIdx);
	return CurSelectedPawn;
}

ACWPawn* ACWPlayerController::GetCurTargetSelectedPawn()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	const int32 UniqueIdx = MyPlayerState->GetCurTargetPawnIdx();
	ACWPawn* CurTargetSelectedPawn = GetPawnByUniqueIdx(this, UniqueIdx);
	return CurTargetSelectedPawn;
}

ACWMapTile* ACWPlayerController::GetCurSelectedTile()
{
	ACWPlayerState* MyPlayerState = this->GetCWPlayerState();
	check(MyPlayerState);
	int CurSelectedTile = MyPlayerState->GetCurSelectedTile();
	ACWMapTile* CurSelectedMapTile = GetMapTileByTile(CurSelectedTile);
	return CurSelectedMapTile;
}

void ACWPlayerController::SetLastCursorActor(AActor* ParamActor)
{
	LastCursorActor = ParamActor;
}

AActor* ACWPlayerController::GetLastCursorActor()
{
	return LastCursorActor;
}

bool ACWPlayerController::ServerEndGame_Validate()
{
	return true;
}

void ACWPlayerController::ServerEndGame_Implementation()
{
	//ClientReturnToLogin();
	//UCWFuncLib::CWGResetServer(this);
}

void ACWPlayerController::SwitchPauseGameInClient()
{
	ServerSwitchPauseGame();
}

bool ACWPlayerController::ServerSwitchPauseGame_Validate()
{
	return true;
}

void ACWPlayerController::ServerSwitchPauseGame_Implementation()
{
	ACWGameState* GameState = GetGameState<ACWGameState>();
	if (IsValid(GameState))
	{
		GameState->ServerSetPauseGame(!GameState->IsPauseGame());
	}
}

bool ACWPlayerController::ServerRefreshLevel_Validate()
{
	return true;
}

void ACWPlayerController::ServerRefreshLevel_Implementation()
{
	UCWFuncLib::CWGServerTravel(this, TEXT("?RESTART"), false);
}

void ACWPlayerController::RefreshLevelInClient()
{
	ServerRefreshLevel();
}

void ACWPlayerController::SwitchGamePlayerRate()
{
	ServerSwitchGamePlayerRate();
}

bool ACWPlayerController::ServerSwitchGamePlayerRate_Validate()
{
	return true;
}

void ACWPlayerController::ServerSwitchGamePlayerRate_Implementation()
{
	if (!IsInServer())
		return;

	ACWGameState* GameState = GetWorld()->GetAuthGameMode()->GetGameState<ACWGameState>();
	check(GameState);

	ECWPawnMoveMode TempPawnMoveMode = GameState->GetPawnMoveMode();
	if (TempPawnMoveMode == ECWPawnMoveMode::One)
	{
		TempPawnMoveMode = ECWPawnMoveMode::Two;
	}
	else
	{
		TempPawnMoveMode = ECWPawnMoveMode::One;
	}
	
	for (TActorIterator<ACWPawn> Iter(GetWorld()); Iter; ++Iter)
	{
		ACWPawn* TempPawn = *Iter;
		check(TempPawn);
		if (TempPawn != nullptr)
		{
			TempPawn->SetMoveModeInServer(TempPawnMoveMode);
		}
	}

	GameState->SetPawnMoveMode(TempPawnMoveMode);
}

void ACWPlayerController::TickLeftMousePressEvt(float DeltaTime)
{
	if (!IsLeftMousePress())
	{
		return;
	}

	ACWPawn* SelectPawn = GetSelectedPawn(GetBattleState());
	if (nullptr != SelectPawn)
	{
		FHitResult HitResult;
		GetHitResultUnderCursor(CurrentClickTraceChannel, true, HitResult);
		SelectPawn->UpdateShadowPosition(HitResult.Location);
	}
}

void ACWPlayerController::OnTickLeftMousePressInReady(float DeltaTime)
{
	if (!IsLeftMousePress())
	{
		return;
	}
}

bool ACWPlayerController::IsLeftMousePress() const
{
	return bLeftMousePress;
}

ECWBattleState ACWPlayerController::GetBattleState() const
{
	ACWGameState* MyGameState = GetGameState<ACWGameState>();
	if (nullptr != MyGameState)
	{
		return MyGameState->GetCurBattleState();
	}
	return ECWBattleState::None;
}


void ACWPlayerController::SelectedAndWantAttackToPawnInClient(ACWPawn* ParamPawn, ACWPawn* ParamTargetPawn)
{
	check(ParamPawn);
	ParamPawn->SelectedAndWantAttackToPawnInClient(this, ParamTargetPawn);
}

void ACWPlayerController::ReadyMoveToDestTileAndWantAttackInClient(ACWPawn* ParamPawn, int ParamDestTile, ACWPawn* ParamTargetPawn)
{
	check(ParamPawn);
	ParamPawn->ReadyMoveToDestTileAndWantAttackInClient(this, ParamDestTile, ParamTargetPawn);

	// 显示受击预览
	ShowHitMarkSpline(true, ParamDestTile);
}

void ACWPlayerController::ReadyMoveToDestTileInClient(ACWPawn* ParamPawn, int ParamDestTile)
{
	check(ParamPawn);
	CancelCurTargetSelectedPawnInClient();
	ParamPawn->ReadyMoveToDestTileInClient(this, ParamDestTile);

	NotifyUIShowRoleAttr(ParamPawn, ParamDestTile);
	NotifyUIShowTerrain(GetMapTileByTile(ParamDestTile));
}

void ACWPlayerController::MoveToDestTileInClient(ACWPawn* ParamPawn, int ParamDestTile)
{
	check(ParamPawn);
	ParamPawn->MoveToDestTileInClient(this, ParamDestTile);
}

void ACWPlayerController::AutoSelectSkillMoveToAttackInClient(ACWPawn* ParamAttackPawn, int32 ParamTargetTile, int32 ParamMoveDestTile)
{
	check(ParamAttackPawn);
	ParamAttackPawn->AutoSelectSkillMoveToAttackInClient(ParamTargetTile, ParamMoveDestTile);

	//取消已经选中的目标棋子
	this->CancelCurTargetSelectedPawnInClient();
}


void ACWPlayerController::AutoSelectSkillAttackInClient(ACWPawn* ParamAttackPawn, int32 ParamTargetTile)
{
	check(ParamAttackPawn);
	ParamAttackPawn->AutoSelectSkillAttackInClient(ParamTargetTile);

	//取消已经选中的目标棋子
	this->CancelCurTargetSelectedPawnInClient();
}

void ACWPlayerController::PawnDeathInServer(ACWPawn* ParamPawn)
{
	check(ParamPawn);

	ParamPawn->DeathInServer();

	FCWPawnKey PawnKey(ParamPawn->GetCampTag(), ParamPawn->GetCampControllerIndex(), ParamPawn->GetControllerPawnIndex());
	ACWPawn* FindPawn = MapPawns.FindRef(PawnKey);
	if (FindPawn != nullptr)
	{
		ParamPawn->Destroy();
	}

	MapPawns.Remove(PawnKey);
}

void ACWPlayerController::NotifyPawnBeginCursorOver(ACWPawn* InPawn)
{
	if (!IsValid(InPawn) || !IsValid(PlayerState))
	{
		return;
	}

	switch (GetBattleState())
	{
	case ECWBattleState::Ready:
		OnBeginCursorOverInReady(InPawn);
		break;
	case ECWBattleState::Fighting:
		OnBeginCursorOverInFight(InPawn);
		break;
	}
}

void ACWPlayerController::NotifyPawnEndCursorOver(ACWPawn* InPawn)
{
	if (!IsValid(InPawn) || !IsValid(PlayerState))
	{
		return;
	}

	switch (GetBattleState())
	{
	case ECWBattleState::Ready:
		OnEndCursorOverInReady(InPawn);
		break;
	case ECWBattleState::Fighting:
		OnEndCursorOverInFight(InPawn);
		break;
	}
}

void ACWPlayerController::OnBeginCursorOverInReady(ACWPawn* InPawn)
{
	if (!IsReadyFinished() && IsLeftMousePress() && IsPartner(InPawn))
	{
		ACWPawn* Selector = GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != Selector && Selector != InPawn)
		{
			InPawn->ShowHeadIcon(EUIHeadIconType::Switch);
		}
	}
}

void ACWPlayerController::OnEndCursorOverInReady(ACWPawn* InPawn)
{
	if (IsPartner(InPawn))
	{
		InPawn->ShowHeadIcon(EUIHeadIconType::None);
	}
}

void ACWPlayerController::OnBeginCursorOverInFight(ACWPawn* InPawn)
{
	if (IsValid(DownPawn) && IsPartner(DownPawn) && DownPawn->IsLongDown() &&
		IsEnemy(InPawn))
	{
		CursorOverPawnInFight = InPawn;
		InPawn->ShowHeadIcon(EUIHeadIconType::Attack);
		NotifyUIShowPreview(DownPawn, InPawn);
	}
	//InPawn->ShowHeadIcon(GetSkillTriggerState())
}

void ACWPlayerController::OnEndCursorOverInFight(ACWPawn* InPawn)
{
	if (IsValid(DownPawn) && IsPartner(DownPawn) && DownPawn->IsLongDown() &&
		IsEnemy(InPawn))
	{
		InPawn->ShowHeadIcon(EUIHeadIconType::None);
		NotifyUIHidePreview(DownPawn, InPawn);
	}
	CursorOverPawnInFight = nullptr;
}

UCWUIFightWindow* ACWPlayerController::GetUIFightWindow() const
{
	UCWUIFightWindow* UIFight = nullptr;
	if (UCWUIManager* UI_Mgr = UI_MGR(this))
	{
		UCWUserWidget* UserWidget = UI_Mgr->GetUIWidget(FUIKey::UIFight);
		UIFight = Cast<UCWUIFightWindow>(UserWidget);
	}
	return UIFight;
}

void ACWPlayerController::NotifyUIShowRoleAttr(ACWPawn* InSelected, const int32 InHitMarkTile)
{
	if (IsValid(InSelected))
	{
		if (UCWUIFightWindow* UIFight = GetUIFightWindow())
		{
			UIFight->OnClickPawn(InSelected);
		}
		InSelected->ShowUserWidget(true);

		// 显示克制信息
		NotifyUIShowRefrain(InSelected, true);

		// 显示地形信息
		const int32 SelectedTileNumber = InSelected->GetTile();
		ACWMapTile* SelectedMapTile = GetMapTileByTile(SelectedTileNumber);
		NotifyUIShowTerrain(SelectedMapTile);

		// 显示受击预览
		int32 HitMarkTile = InHitMarkTile <= INDEX_NONE ? InSelected->GetTile() : InHitMarkTile;
		ShowHitMarkSpline(true, HitMarkTile);
	}
}

void ACWPlayerController::NotifyUIHideRoleAttr(ACWPawn* InSelected)
{
	if (UCWUIFightWindow* UIFight = GetUIFightWindow())
	{
		UIFight->ShowWidgetParts(EUIFightPart::RoleAttr, false);
	}

	InSelected = InSelected ? InSelected : GetCurSelectedPawn();
	if (nullptr != InSelected)
	{
		// 隐藏克制信息
		InSelected->ShowUserWidget(InSelected->IsEnablePawnUI(this));
		NotifyUIShowRefrain(InSelected, false);
	}

	// 隐藏受击预览
	ShowHitMarkSpline(false, INDEX_NONE);
}

void ACWPlayerController::NotifyUIShowPreview(ACWPawn* InSelected, ACWPawn* InTarget)
{
	if (IsValid(InSelected) && IsValid(InTarget))
	{
		if (InTarget->IsPawnType(ECWPawnType::Character))
		{
			FFightPreviewData SelectData = FFightPreviewData();
			FFightPreviewData TargetData = FFightPreviewData();
			if (UCWUIUtil::GetFightPreviewData(InSelected, InTarget, SelectData, TargetData))
			{
				// 预览选定棋子预计掉血
				InSelected->NotifyUpdatePreviewInfo(InTarget, TargetData, SelectData);
				InSelected->NotifyShowPreviewInfo(true);

				InTarget->NotifyUpdatePreviewInfo(InSelected, SelectData, TargetData);
				InTarget->NotifyShowPreviewInfo(true);

				if (UCWUIFightWindow* UIFight = GetUIFightWindow())
				{
					//UIFight->OnClickTargetPawn(InSelected, InTarget);
					UIFight->OnShowPreviewCtrl(InSelected, InTarget, SelectData, TargetData);
				}
			}
		}

		InSelected->ShowUserWidget(true);
		InTarget->ShowUserWidget(true);

		// 暂停延时隐藏目标
		FTimerManager& TimerManager = GetWorldTimerManager();
		TimerManager.PauseTimer(DelayTargetHandle);

		// 显示地形信息
		const int32 TileNumber = InSelected->GetTile();
		ACWMapTile* TempMapTile = GetMapTileByTile(TileNumber);
		NotifyUIShowTerrain(TempMapTile);
	}
}

void ACWPlayerController::NotifyUIHidePreview(ACWPawn* InSelected, ACWPawn* InTarget, const float InDelayHideTarget)
{
	if (UCWUIFightWindow* UIFight = GetUIFightWindow())
	{
		UIFight->OnHidePreviewCtrl();
	}

	// 取消選定自己棋子
	InSelected = InSelected ? InSelected : GetCurSelectedPawn();
	if (nullptr != InSelected)
	{
		InSelected->NotifyShowPreviewInfo(false);
		InSelected->ShowUserWidget(InSelected->IsEnablePawnUI(this));
	}

	// 取消選定自己目標棋子
	InTarget = InTarget ? InTarget : GetCurTargetSelectedPawn();
	if (nullptr != InTarget)
	{
		InTarget->NotifyShowPreviewInfo(false);
		//TODO:
		//if (InDelayHideTarget <= 0.f)
		{
			InTarget->ShowUserWidget(InTarget->IsEnablePawnUI(this));
		}
		//TODO:
		//else
		//{	// 延迟隐藏目标UI
		//	//DelayTargetDelegate.ExecuteIfBound();
		//	auto DelayTargetDelegate = [InTarget, this]() {
		//		if (IsValidActor(InTarget))
		//		{
		//			InTarget->ShowUserWidget(InTarget->IsEnablePawnUI(this));
		//		}
		//	};
		//	FTimerManager& TimerManager = GetWorldTimerManager();
		//	TimerManager.SetTimer(DelayTargetHandle, DelayTargetDelegate, InDelayHideTarget, false);
		//}
	}
}

void ACWPlayerController::NotifyUIShowRefrain(ACWPawn* InSelected, bool bShow)
{
	auto NewGetPredicate = [this](const ACWPawn* InPawn) -> bool
	{
		return IsValidActor(InPawn) && InPawn->IsPawnType(ECWPawnType::Character);
	};

	// 检测所有棋子克制显示
	TArray<ACWPawn*> AllPawnList;
	UCWFuncLib::GetAllActors<ACWPawn>(this, AllPawnList, NewGetPredicate);
	for (ACWPawn* GamePawn : AllPawnList)
	{
		UCWUIPawnWidget* PawnWidget = GamePawn->GetUserWidget();
		if (nullptr != PawnWidget)
		{
			int8 InRefrainType = 0;		// -1:BeRefrain 0:Hide 1:Refrain
			if (bShow && IsValidActor(InSelected) && UCWFuncLib::IsEnemy(InSelected, GamePawn))
			{
				const float RefrainFactor = UCWBattleCalculate::Get()->GetRefrainFactor(InSelected, GamePawn);
				InRefrainType = (RefrainFactor > SMALL_NUMBER) ? 1 : (RefrainFactor < -SMALL_NUMBER) ? -1 : 0;
			}
			PawnWidget->ShowRefrainIcon(InRefrainType);
		}
	}
}

void ACWPlayerController::NotifyUIShowTerrain(ACWMapTile* InSelected)
{
	if (IsValid(InSelected))
	{
		if (UCWUIFightWindow* UIFight = GetUIFightWindow())
		{
			UIFight->OnClickMapTile(InSelected);
		}
	}
	else
	{
		NotifyUIHideTerrain();
	}
}

void ACWPlayerController::NotifyUIHideTerrain()
{
	if (UCWUIFightWindow* UIFight = GetUIFightWindow())
	{
		UIFight->ShowWidgetParts(EUIFightPart::TerrainInfo, false);
		UIFight->ShowWidgetParts(EUIFightPart::LandLayer, false);
	}
}

void ACWPlayerController::ToggleUIFightWindowShow()
{
	if (UCWUIFightWindow* UIFight = GetUIFightWindow())
	{
		const bool bNewVisible = UIFight->IsVisible();
		UIFight->ShowWidget(!bNewVisible);
		/*if (!bNewVisible)
		{
			UIFight->OnBeginFightingState();
		}*/
	}
}
