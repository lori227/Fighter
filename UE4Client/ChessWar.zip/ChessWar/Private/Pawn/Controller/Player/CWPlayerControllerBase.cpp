﻿
#include "CWPlayerControllerBase.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWAssetData.h"
#include "CWUIManager.h"
#include "CWCfgManager.h"
#include "CWRandomEventCtrl.h"
#include "CWPhysicsSystemCtrl.h"
#include "CWElementSystemData.h"
#include "CWRandomDungeonGenerator.h"


ACWPlayerControllerBase::ACWPlayerControllerBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	bShowMouseCursor = true;

	bEnableClickEvents = true;
	bEnableMouseOverEvents = true;
	bEnableTouchEvents = true;
}

ACWPlayerControllerBase::~ACWPlayerControllerBase()
{
}

void ACWPlayerControllerBase::ClientOnPlayerLoginBegin_Implementation()
{
}

void ACWPlayerControllerBase::ClientOnPlayerLoginCompleted_Implementation(const FGameModeData GameModeData)
{
	if (UCWEventMgr* EvtMgr = EVT_MGR(this))
	{
		EvtMgr->OnPlayerLoginCompleted.Broadcast(GameModeData);
	}
}

void ACWPlayerControllerBase::SetupInputComponent()
{
	Super::SetupInputComponent();

	// Key
	InputComponent->BindKey(EKeys::AnyKey, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedAnyKey);
	InputComponent->BindKey(EKeys::Escape, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedKeyEscape);
	InputComponent->BindKey(EKeys::LeftShift, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedKeyLeftShift);
	InputComponent->BindKey(EKeys::RightShift, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedKeyRightShift);
	InputComponent->BindKey(EKeys::Tab, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedKeyTab);
	InputComponent->BindKey(EKeys::P, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedKeyP);

	// Android
#if PLATFORM_ANDROID
	InputComponent->BindKey(EKeys::Android_Back, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedAndroidBack);
	InputComponent->BindKey(EKeys::Android_Menu, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedAndroidMenu);
	InputComponent->BindKey(EKeys::Android_Volume_Up, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedAndroidVolumeUp);
	InputComponent->BindKey(EKeys::Android_Volume_Down, IE_Pressed, this, &ACWPlayerControllerBase::OnPressedAndroidVolumeDown);
#endif

	// handle touch devices
	// PS: 必須是Android 或者 DefaultInput.ini(bUseMouseForTouch=True)
	InputComponent->BindTouch(IE_Pressed, this, &ACWPlayerControllerBase::OnTouchStarted);
	InputComponent->BindTouch(IE_Repeat, this, &ACWPlayerControllerBase::OnTouchMoved);
	InputComponent->BindTouch(IE_Released, this, &ACWPlayerControllerBase::OnTouchStopped);
}

void ACWPlayerControllerBase::PreClientTravel(const FString& PendingURL, ETravelType TravelType, bool bIsSeamlessTravel)
{
	Super::PreClientTravel(PendingURL, TravelType, bIsSeamlessTravel);

	UWorld* MyWorld = GetWorld();
	if (nullptr != MyWorld)
	{
		// TODO: Show LoadScreen

		// TODO: Clear All HUD

	}
}

void ACWPlayerControllerBase::GetAudioListenerPosition(FVector& OutLocation, FVector& OutFrontDir, FVector& OutRightDir)
{
	Super::GetAudioListenerPosition(OutLocation, OutFrontDir, OutRightDir);
}

void ACWPlayerControllerBase::OnPressedAnyKey()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::AnyKey);
	}
}

void ACWPlayerControllerBase::OnPressedKeyEscape()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Escape);
	}
}

void ACWPlayerControllerBase::OnPressedKeyP()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::P);
	}
}

void ACWPlayerControllerBase::OnPressedKeyTab()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Tab);
	}
}

void ACWPlayerControllerBase::OnPressedKeyLeftShift()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::LeftShift);
	}
}

void ACWPlayerControllerBase::OnPressedKeyRightShift()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::RightShift);
	}
}

void ACWPlayerControllerBase::OnPressedAndroidBack()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Android_Back);
	}
}

void ACWPlayerControllerBase::OnPressedAndroidMenu()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Android_Menu);
	}
}

void ACWPlayerControllerBase::OnPressedAndroidVolumeUp()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Android_Volume_Up);
	}
}

void ACWPlayerControllerBase::OnPressedAndroidVolumeDown()
{
	if (UCWEventMgr* Evt_Mgr = EVT_MGR(this))
	{
		Evt_Mgr->OnKeyPressed.Broadcast(EKeys::Android_Volume_Down);
	}
}

void ACWPlayerControllerBase::OnTouchStarted(ETouchIndex::Type FingerIndex, FVector Location)
{
}

void ACWPlayerControllerBase::OnTouchMoved(ETouchIndex::Type FingerIndex, FVector Location)
{
}

void ACWPlayerControllerBase::OnTouchStopped(ETouchIndex::Type FingerIndex, FVector Location)
{
}

bool ACWPlayerControllerBase::IsValidScreenPoint(const FVector2D& InScreenPoint) const
{
	return InScreenPoint.X >= 0.f && InScreenPoint.Y >= 0.f;
}

FVector2D ACWPlayerControllerBase::GetMousePoint()
{
	float NewX = -1.f, NewY = -1.f;
	if (GetMousePosition(NewX, NewY))
	{
		return FVector2D(NewX, NewY);
	}
	return FVector2D(-1.f, -1.f);
}

int32 ACWPlayerControllerBase::GetPlayerId() const
{
	return PlayerState ? PlayerState->PlayerId : INDEX_NONE;
}

void ACWPlayerControllerBase::ClientTravelTo_Implementation(ECWGameStage GameModeType, enum ETravelType TravelType)
{
	switch (GameModeType)
	{
	case ECWGameStage::Login:
	{
		ClientReturnToLogin();
	}break;
	case ECWGameStage::Lobby:
	{
		ClientReturnToLobby();
	}break;
	case ECWGameStage::Battle:
	{
		ClientConnectUEServer();
	}break;
	}
}

void ACWPlayerControllerBase::ClientReturnToLobby_Implementation()
{
	ClientWasKicked(FSTRING_TO_FTEXT(""));
	ClientTravel(ClientLobbyURL, TRAVEL_Absolute);
	//ConsoleCommand("Disconnect");
	CWG_LOG(">> %s::ClientReturnToLobby.", *GetName());
}

void ACWPlayerControllerBase::ClientConnectUEServer_Implementation()
{
	int32 Pid = PlayerState ? PlayerState->PlayerId : -1;
	UCWFuncLib::CWGConnectServer(this, DefaultHostIp, DefaultPort, Pid, this);
}

void ACWPlayerControllerBase::ClientReturnToLogin_Implementation()
{
	ClientTravel(ClientLoginURL, TRAVEL_Absolute);
}

void ACWPlayerControllerBase::CWG_ShowScreenLog(bool isToggled, bool isEnabled)
{
	if (isToggled)
	{
		GAreScreenMessagesEnabled = !GAreScreenMessagesEnabled;
	}else
	{
		GAreScreenMessagesEnabled = isEnabled;
	}
}

void ACWPlayerControllerBase::CWG_DebugGenRandItem(const int32 InTile, const int32 InItemId)
{
	ServerDebugGenRandItem(InTile, InItemId);
}

bool ACWPlayerControllerBase::ServerDebugGenRandItem_Validate(const int32 InTile, const int32 InItemId)
{
	return true;
}

void ACWPlayerControllerBase::ServerDebugGenRandItem_Implementation(const int32 InTile, const int32 InItemId)
{
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	UCWRandomEventCtrl* RandomEventCtrl = Generator ? Generator->GetRandomEvtCtrl() : nullptr;
	if (nullptr != RandomEventCtrl)
	{
		RandomEventCtrl->TestCreateDungeonItem(InTile, InItemId);
	}
}

void ACWPlayerControllerBase::CWG_DebugGenRandEvt(const int32 InTile, const int32 InEvtId)
{
	ServerDebugGenRandEvt(InTile, InEvtId);
}

bool ACWPlayerControllerBase::ServerDebugGenRandEvt_Validate(const int32 InTile, const int32 InEvtId)
{
	return true;
}

void ACWPlayerControllerBase::ServerDebugGenRandEvt_Implementation(const int32 InTile, const int32 InEvtId)
{
	ACWRandomDungeonGenerator* Generator = UCWFuncLib::GetActor<ACWRandomDungeonGenerator>(this);
	UCWRandomEventCtrl* RandomEventCtrl = Generator ? Generator->GetRandomEvtCtrl() : nullptr;
	if (nullptr != RandomEventCtrl)
	{
		RandomEventCtrl->TestCreateDungeonEvt(InTile, InEvtId);
	}
}

uint8 ACWPlayerControllerBase::CWG_ParseObjNatures(const FString& InObjNatures)
{
	uint8 OutValue = FElemUtils::ParseObjNatures(InObjNatures);
	CWG_WARNING(">> ParseObjNatures, InObjNatures[%s] OutValue[%d].", *InObjNatures, (int32)OutValue);

	return OutValue;
}

bool ACWPlayerControllerBase::CWG_ObjHasNatureType(uint8 InObjNatureTypes, enum EObjNatureType InObjNatureType)
{
	bool OutValue = FElemUtils::ObjHasNatureType(InObjNatureTypes, InObjNatureType);
	CWG_WARNING(">> ObjHasNatureType, InObjNatureTypes[%d] InObjNatureType[%d] OutValue[%d].", (int32)InObjNatureTypes, (int32)InObjNatureType, (int32)OutValue);

	return OutValue;
}

uint8 ACWPlayerControllerBase::CWG_BitOperationAnd(uint8 InA, uint8 InB)
{
	uint8 OutValue = InA & InB;
	CWG_WARNING(">> CWG_BitOperation-And, InA[%d] InB[%d] OutValue[%d].", (int32)InA, (int32)InB, (int32)OutValue);

	return OutValue;
}

uint8 ACWPlayerControllerBase::CWG_BitOperationOr(uint8 InA, uint8 InB)
{
	uint8 OutValue = InA | InB;
	CWG_WARNING(">> CWG_BitOperation-Or, InA[%d] InB[%d] OutValue[%d].", (int32)InA, (int32)InB, (int32)OutValue);

	return OutValue;
}

void ACWPlayerControllerBase::CWG_DebugPyhsics(const int32 InCasterNetIdx, const int32 InReceiverNetIdx, const int32 InMoveNum)
{
	ServerDebugPyhsics(InCasterNetIdx, InReceiverNetIdx, InMoveNum);
	//UCWPhysicsSystemCtrl::TestHorizontalForced2Move(this, InCasterNetIdx, InReceiverNetIdx, InMoveNum);
}

bool ACWPlayerControllerBase::ServerDebugPyhsics_Validate(const int32 InCasterNetIdx, const int32 InReceiverNetIdx, const int32 InMoveNum)
{
	return true;
}

void ACWPlayerControllerBase::ServerDebugPyhsics_Implementation(const int32 InCasterNetIdx, const int32 InReceiverNetIdx, const int32 InMoveNum)
{
	UCWPhysicsSystemCtrl::TestHorizontalForced2Move(this, InCasterNetIdx, InReceiverNetIdx, InMoveNum);
}

#if !UE_BUILD_SHIPPING
static bool bEnableDebugPawn = false;
#endif

void ACWPlayerControllerBase::CWG_EnableDebugPawn(const bool bEnable)
{
#if !UE_BUILD_SHIPPING
	bEnableDebugPawn = bEnable;
	CWG_ServerEnableDebugPawn(bEnable);
#endif
}

bool ACWPlayerControllerBase::CWG_ServerEnableDebugPawn_Validate(const bool bEnable)
{
	return true;
}

void ACWPlayerControllerBase::CWG_ServerEnableDebugPawn_Implementation(const bool bEnable)
{
#if !UE_BUILD_SHIPPING
	bEnableDebugPawn = bEnable;
#endif
}

void ACWPlayerControllerBase::CWG_DebugPawn(const int32 InNetPawnIdx)
{
	CWG_DebugPawnEx(InNetPawnIdx);
	ServerDebugPawn(InNetPawnIdx);
}

bool ACWPlayerControllerBase::ServerDebugPawn_Validate(const int32 InNetPawnIdx)
{
	return true;
}

void ACWPlayerControllerBase::ServerDebugPawn_Implementation(const int32 InNetPawnIdx)
{
	CWG_DebugPawnEx(InNetPawnIdx);
}

void ACWPlayerControllerBase::CWG_DebugPawnEx(const int32 InNetPawnIdx)
{
#if !UE_BUILD_SHIPPING
	if (!bEnableDebugPawn)
	{
		return;
	}

	/*TArray<ACWPawn*> OutAllPawnArray;
	UCWFuncLib::GetAllActors<ACWPawn>(this, OutAllPawnArray,
	[](const ACWPawn* InPawn)
	{
		return InPawn->GetPawnUniqueIdx() > 0;
	});
	for (const ACWPawn* TmpNetPawn : OutAllPawnArray)
	{
		CWG_LOG(">> DebugPawn: %s.", *TmpNetPawn->ToDebugString());
	}*/

	ACWPawn* NetPawn = UCWFuncLib::GetActor<ACWPawn>(this,
	[InNetPawnIdx](const ACWPawn* InPawn)
	{
		return InPawn->GetPawnUniqueIdx() == InNetPawnIdx;
	});
	if (IsValidActor(NetPawn))
	{
		CWG_LOG("------------------------------ Begin CWG_DebugPawnEx ---------------------------------");
		AActor* Owner = NetPawn->GetOwner();
		const AActor* NetOwner = NetPawn->GetNetOwner();
		CWG_LOG(">> DebugPawn[%s]: Owner:%s.", *CWG_NAME(NetPawn), *CWG_NAME(Owner));
		CWG_LOG(">> DebugPawn[%s]: NetOwner:%s.", *CWG_NAME(NetPawn), *CWG_NAME(NetOwner));
		CWG_LOG(">> DebugPawn[%s]: Info:%s.", *CWG_NAME(NetPawn), *NetPawn->ToDebugString());
		CWG_LOG("------------------------------ End   CWG_DebugPawnEx ---------------------------------");
	}
#endif
}

void ACWPlayerControllerBase::CWG_ConnectServer(const FString& InIp, const FString& InPort, const FString& InPID)
{
	FString NewCmd = "Open " + InIp + ":" + InPort + "?Pid=" + InPID;
	UKismetSystemLibrary::ExecuteConsoleCommand(this, NewCmd, this);
}

void ACWPlayerControllerBase::CWG_ServerTravel(const FString& InURL)
{
	ServerServerTravel(InURL);
}

void ACWPlayerControllerBase::CWG_MoveToTile(const int32 InPawnIdx, const int32 InTile)
{
	ServerMoveToTile(InPawnIdx, InTile);
}

void ACWPlayerControllerBase::CWG_ParseString(const FString& InParam)
{
	FString ParamString = TEXT("");
	TArray<FString> OutArray;
	ParamString.ParseIntoArray(OutArray, TEXT("|"), false);
	CWG_WARNING(">> %s::CWG_ParseString, OutArray.Num[%d].", *GetName(), OutArray.Num());
}

void ACWPlayerControllerBase::CWG_CheckAudioEvent()
{
	const FString& ContentDir = FPaths::ProjectContentDir();
	const FString& FilePath = ContentDir + "AudioResource\\Event\\";
	CWG_LOG("FilePath[%s]", *FilePath);

	UCWCfgManager* CfgMgr = CFG_MGR(this);
	const UCWConfigTable* ConfigTable = CfgMgr ? CfgMgr->GetConfigTable(FCWCfgKey::PawnAsset) : nullptr;
	if (nullptr == ConfigTable)
	{
		CWG_WARNING(">> CWG_CheckAudioEvent, ConfigTable is nullptr!!!");
		return;
	}
	
	TArray<FString> OutFiles;
	UCWFuncLib::ScanDirectory(OutFiles, FilePath/*InFilePath*/, TEXT("*.uasset"));

	const TArray<FName>& AllName = ConfigTable->GetRowNames();
	for (int32 i = 0; i < AllName.Num(); ++i)
	{
		const FString& RowName = FNAME_TO_FSTRING(AllName[i]);
		if (!RowName.IsEmpty() && RowName.Contains(TEXT("AS_")))
		{
			FCWPawnAssetData* AssetData = ConfigTable->GetRow<FCWPawnAssetData>(RowName);
			const FString& AssetName = (nullptr != AssetData) ? AssetData->AssetPtr.GetAssetName() : TEXT("");
			if (!AssetName.IsEmpty())
			{
				if (OutFiles.ContainsByPredicate([AssetName](const FString& InFileName)
				{
					return InFileName.Contains(AssetName);
				}))
				{
					CWG_LOG("--> RowName[%s] AssetName[%s] AssetPath[%s] is Ok!", *RowName, *AssetName, *AssetData->AssetPtr.GetLongPackageName());
				}
				else
				{
					CWG_WARNING("--> RowName[%s] AssetName[%s] AssetPath[%s] is Fail!", *RowName, *AssetName, *AssetData->AssetPtr.GetLongPackageName());
				}
			}
		}
	}
}

bool ACWPlayerControllerBase::ServerMoveToTile_Validate(const int32 InPawnIdx, const int32 InTile)
{
	return true;
}

void ACWPlayerControllerBase::ServerMoveToTile_Implementation(const int32 InPawnIdx, const int32 InTile)
{
	ACWPawn* NetPawn = UCWFuncLib::GetActor<ACWPawn>(this,
	[InPawnIdx](const ACWPawn* InPawn)
	{
		return InPawn->GetPawnUniqueIdx() == InPawnIdx;
	});
	if (IsValidActor(NetPawn))
	{
		NetPawn->SetTile(InTile);
	}
}

bool ACWPlayerControllerBase::ServerServerTravel_Validate(const FString& InURL)
{
	return true;
}

void ACWPlayerControllerBase::ServerServerTravel_Implementation(const FString& InURL)
{
	UCWFuncLib::CWGServerTravel(this, InURL);
}
