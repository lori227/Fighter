#include "CWPlayerNetData.h"
#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWPawnDataStruct.h"
#include "CWCastSkillContext.h"


FCWPlayerNetData::FCWPlayerNetData()
{
	Reset();
}

FCWPlayerNetData::FCWPlayerNetData(const FCWPlayerNetData& r)
{
	*this = r;
}

FCWPlayerNetData& FCWPlayerNetData::operator = (const FCWPlayerNetData& r)
{
	if (this == &r)
		return *this;

	 this->Id = r.Id;
	 this->Name = r.Name;
	 this->ServerId = r.ServerId;
	 this->CampId = r.CampId;

	return *this;
}

bool operator == (const FCWPlayerNetData& l, const FCWPlayerNetData& r)
{
	if (l.Id == r.Id &&
		l.Name == r.Name &&
		l.ServerId == r.ServerId &&
		l.CampId == r.CampId)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void FCWPlayerNetData::Reset()
{
	this->Id = 0;
	this->Name = "";
	this->ServerId = 0;
	this->CampId = 0;
}

FString FCWPlayerNetData::ToString() const
{
	return FString::Printf(TEXT("Id[%s] Name[%s] ServerId[%s] CampId[%d]"), *Id, *Name, *ServerId, CampId);
}
