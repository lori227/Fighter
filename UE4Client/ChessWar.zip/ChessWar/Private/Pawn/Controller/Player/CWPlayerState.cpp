﻿
#include "CWPlayerState.h"
#include "ConstructorHelpers.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWPawn.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWPlayerState, All, All);

ACWPlayerState::ACWPlayerState(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurSelectedTile(INDEX_NONE)
	, CurCtrlPawnIdx(INDEX_NONE)
	, CurTargetPawnIdx(INDEX_NONE)
{
}

void ACWPlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWPlayerState, PlayerUniqueId);
	DOREPLIFETIME(ACWPlayerState, CampTag);
	DOREPLIFETIME(ACWPlayerState, CampControllerIndex);
}

void ACWPlayerState::ResetWhenNextTurnBeginInServer()
{
	CurSelectedTile = CurCtrlPawnIdx = CurTargetPawnIdx = INDEX_NONE;
}

void ACWPlayerState::SetCampTag(ECWCampTag ParamCampTag)
{
	CampTag = ParamCampTag;
}

ECWCampTag ACWPlayerState::GetCampTag() const
{
	return CampTag;
}

void ACWPlayerState::SetCampControllerIndex(ECWCampControllerIndex ParamControllerIndex)
{
	CampControllerIndex = ParamControllerIndex;
}


ECWCampControllerIndex ACWPlayerState::GetCampControllerIndex() const
{
	return CampControllerIndex;
}

void ACWPlayerState::SetCurSelectedTile(int ParamTile)
{
	CurSelectedTile = ParamTile;
}

int ACWPlayerState::GetCurSelectedTile() const
{
	return CurSelectedTile;
}

bool ACWPlayerState::IsInServer() const
{
	return Role == ROLE_Authority;
}

bool ACWPlayerState::IsMyClientPlayerState() const
{
	return Role == ROLE_AutonomousProxy;
}

bool ACWPlayerState::IsOtherClientPlayerState() const
{
	return Role == ROLE_SimulatedProxy;
}

int32 ACWPlayerState::GetCurCtrlPawnIdx() const
{
	return CurCtrlPawnIdx;
}

void ACWPlayerState::SetCurCtrlPawnIdx(int32 InPawnIdx)
{
	CurCtrlPawnIdx = InPawnIdx;
}

int32 ACWPlayerState::GetCurTargetPawnIdx() const
{
	return CurTargetPawnIdx;
}

void ACWPlayerState::SetCurTargetPawnIdx(int32 InPawnIdx)
{
	CurTargetPawnIdx = InPawnIdx;
}
