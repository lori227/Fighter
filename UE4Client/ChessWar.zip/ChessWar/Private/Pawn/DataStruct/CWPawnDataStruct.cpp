#include "CWPawnDataStruct.h"

FCWPawnDataStruct::FCWPawnDataStruct()
	: PawnId(0)
	, OwnElemId(INDEX_NONE)
	, IsMelee(0)
	, IsLongRange(0)
	, SkillIdForNormalAttack(0)
	, IsSkeletalMesh(0)
	, ArmTypeValue(0)
	, ActionTypeVal(ECWActionType::AT_None)
	, AttackTypeValue(0)
{
	AttackValue = 0.f;
	PhysicalDefenceValue = 0.f;
	MagicDefenceValue = 0.f;
	HealthValue = 0.f;
	EnergyValue = 0.f;
	TalentValue = 0.f;
	MoveValue = 0.f;
	CriticalDamageFactorValue = 0.f;
	CriticalHitRateValue = 0.f;
	SpeedValue = 0.f;
	FinalDamageValue = 0.f;
	HitRateValue = 0.f;
	AvoidanceRateValue = 0.f;
	BlockRateValue = 0.f;
	TerrainDefinceFactorValue = 0.f;
	TerrainDefinceValue = 0.f;
	TerrainTalentFactorValue = 0.f;
	TerrainTalentValue = 0.f;
	PropertRestrictFactorValue = 0.f;
	PropertRestrictValue = 0.f;
	DefincePostureFactorValue = 0.f;
	DefincePostureValue = 0.f;
	FinalDamageFactorValue = 0.f;
	MoveAnimSpeedRate = 0.f;
	MoveSpeed = 0.f;
	MoveAnimSpeedRate2 = 0.f;
	MoveSpeed2 = 0.f;
	bIsAvatarChangePart = false;
	bIsChangeAvatarAnimInstance = false;
	bIsPlayOtherAnimForTestAvarta = false;

	bPhyBMovedForce = false;
	bPhyBFallenForce = false;
	PhyLateralFDMG = 0;
	PhyLateralFMove = 0;
	PhyLateralFBuff = 0;
	PhyLateralFEvent = 0;
	PhyVerticalFDMG = 0;
	PhyVerticalFMove = 0;
	PhyVerticalFBuff = 0;
	PhyVerticalFEvent = 0;
}

FCWPawnDataStruct::~FCWPawnDataStruct()
{
}
