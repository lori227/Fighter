#include "CWPawnDataUtils.h"


std::vector<float> FCWPawnDataUtils::GetArrayMeshScaleFromString(const FString& ParamString)
{
	std::vector<float> ArrayMeshScale;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempMeshScale = FCString::Atof(*TempString);
		ArrayMeshScale.push_back(TempMeshScale);
	}

	return ArrayMeshScale;
}

std::vector<int32> FCWPawnDataUtils::GetArrayEffectIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayEffectId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempEffectId = FCString::Atoi(*TempString);
		ArrayEffectId.push_back(TempEffectId);
	}

	return ArrayEffectId;
}