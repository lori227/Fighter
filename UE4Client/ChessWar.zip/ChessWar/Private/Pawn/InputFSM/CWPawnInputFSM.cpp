#include "CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"


UCWPawnInputFSM::UCWPawnInputFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWPawnInputFSM::Init(ACWPawn* ParamParant)
{
	Parant = ParamParant;
}

ACWPawn* UCWPawnInputFSM::GetParantPawn()
{
	return Parant;
}