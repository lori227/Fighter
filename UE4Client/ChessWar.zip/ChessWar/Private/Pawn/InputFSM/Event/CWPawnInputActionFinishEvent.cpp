#include "CWPawnInputActionFinishEvent.h"


FCWPawnInputActionFinishEvent::FCWPawnInputActionFinishEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputActionFinishEvent::FCWPawnInputActionFinishEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}