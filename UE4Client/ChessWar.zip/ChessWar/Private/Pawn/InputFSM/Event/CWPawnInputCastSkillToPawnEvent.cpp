#include "CWPawnInputCastSkillToPawnEvent.h"


FCWPawnInputCastSkillToPawnEvent::FCWPawnInputCastSkillToPawnEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputCastSkillToPawnEvent::FCWPawnInputCastSkillToPawnEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ACWPawn* ParamTargetPawn)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,TargetPawn(ParamTargetPawn)
{

}

FCWPawnInputCastSkillToPawnEvent::FCWPawnInputCastSkillToPawnEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int32 ParamTargetTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, TargetTile(ParamTargetTile)
{

}