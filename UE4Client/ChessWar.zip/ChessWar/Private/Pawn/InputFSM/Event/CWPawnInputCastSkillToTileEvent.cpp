#include "CWPawnInputCastSkillToTileEvent.h"


FCWPawnInputCastSkillToTileEvent::FCWPawnInputCastSkillToTileEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputCastSkillToTileEvent::FCWPawnInputCastSkillToTileEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}

FCWPawnInputCastSkillToTileEvent::FCWPawnInputCastSkillToTileEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamTargetTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,TargetTile(ParamTargetTile)
{

}