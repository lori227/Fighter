﻿
#include "CWPawnInputLeftMouseEvent.h"

#include "CWPawn.h"
#include "CWPlayerController.h"

FCWPawnInputLeftMouseEvent::FCWPawnInputLeftMouseEvent()
	:FCWFSMEvent()
{
}

FCWPawnInputLeftMouseEvent::FCWPawnInputLeftMouseEvent(
	int ParamEventId, 
	int ParamToStateId,
	ECWFSMStackOp ParamStackOp, 
	ACWPawn* ParamEvtPawn,
	ACWPlayerController* ParamClientOpPc
)
	: FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, EvtPawn(ParamEvtPawn)
	, ClientOpPc(ParamClientOpPc)
{
}