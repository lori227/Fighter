#include "CWPawnInputLeftMouseUpEvent.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "Pawn/CWPawn.h"

FCWPawnInputLeftMouseUpEvent::FCWPawnInputLeftMouseUpEvent()
	:FCWFSMEvent()
{

}

FCWPawnInputLeftMouseUpEvent::FCWPawnInputLeftMouseUpEvent(
	int ParamEventId, 
	int ParamToStateId,
	ECWFSMStackOp ParamStackOp, 
	ACWPawn* ParamPawn,
	ACWPlayerController* ParamPlayerControllerInClient
)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,Pawn(ParamPawn)
	,PlayerControllerInClient(ParamPlayerControllerInClient)
{

}