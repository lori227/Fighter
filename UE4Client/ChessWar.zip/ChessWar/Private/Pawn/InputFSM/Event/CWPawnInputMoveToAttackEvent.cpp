#include "CWPawnInputMoveToAttackEvent.h"
#include "CWPawn.h"


FCWPawnInputMoveToAttackEvent::FCWPawnInputMoveToAttackEvent()
	:FCWFSMEvent()
{

}

FCWPawnInputMoveToAttackEvent::FCWPawnInputMoveToAttackEvent(
	int ParamEventId,
	int ParamToStateId, 
	ECWFSMStackOp ParamStackOp, 
	int ParamSkillId,
	int ParamTargetTile,
	int ParamMoveDestTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,SkillId(ParamSkillId)
	,TargetTile(ParamTargetTile)
	,MoveDestTile(ParamMoveDestTile)
{

}