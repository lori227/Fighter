#include "CWPawnInputMoveToDestEvent.h"
#include "CWPawn.h"


FCWPawnInputMoveToDestEvent::FCWPawnInputMoveToDestEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputMoveToDestEvent::FCWPawnInputMoveToDestEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}

FCWPawnInputMoveToDestEvent::FCWPawnInputMoveToDestEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, Tile(ParamTile)
{

}