#include "CWPawnInputMoveToWaitingAttackEvent.h"
#include "CWPawn.h"


FCWPawnInputMoveToWaitingAttackEvent::FCWPawnInputMoveToWaitingAttackEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputMoveToWaitingAttackEvent::FCWPawnInputMoveToWaitingAttackEvent(
	int ParamEventId, 
	int ParamToStateId, 
	ECWFSMStackOp ParamStackOp, 
	int ParamTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, Tile(ParamTile)
{

}