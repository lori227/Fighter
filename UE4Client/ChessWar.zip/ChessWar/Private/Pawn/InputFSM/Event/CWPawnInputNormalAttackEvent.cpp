#include "CWPawnInputNormalAttackEvent.h"


FCWPawnInputNormalAttackEvent::FCWPawnInputNormalAttackEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputNormalAttackEvent::FCWPawnInputNormalAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}

FCWPawnInputNormalAttackEvent::FCWPawnInputNormalAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ACWPawn* ParamTargetPawn)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,TargetPawn(ParamTargetPawn)
{

}

FCWPawnInputNormalAttackEvent::FCWPawnInputNormalAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int32 ParamTargetTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, TargetTile(ParamTargetTile)
{

}