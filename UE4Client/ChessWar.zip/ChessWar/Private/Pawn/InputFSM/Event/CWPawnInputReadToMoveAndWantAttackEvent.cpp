#include "CWPawnInputReadyToMoveAndWantAttackEvent.h"


FCWPawnInputReadyToMoveAndWantAttackEvent::FCWPawnInputReadyToMoveAndWantAttackEvent()
	:FCWFSMEvent()
{

}

FCWPawnInputReadyToMoveAndWantAttackEvent::FCWPawnInputReadyToMoveAndWantAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamTile, ACWPawn* ParamTargetPawn)
	: FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	, Tile(ParamTile)
	, TargetPawn(ParamTargetPawn)
{

}