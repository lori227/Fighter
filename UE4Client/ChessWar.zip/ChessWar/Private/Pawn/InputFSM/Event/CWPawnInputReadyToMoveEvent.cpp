#include "CWPawnInputReadyToMoveEvent.h"


FCWPawnInputReadyToMoveEvent::FCWPawnInputReadyToMoveEvent()
	:FCWFSMEvent()
{

}

FCWPawnInputReadyToMoveEvent::FCWPawnInputReadyToMoveEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, int ParamTile)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,Tile(ParamTile)
{

}