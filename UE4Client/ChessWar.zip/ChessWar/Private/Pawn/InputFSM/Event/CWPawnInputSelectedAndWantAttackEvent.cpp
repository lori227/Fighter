#include "CWPawnInputSelectedAndWantAttackEvent.h"
#include "CWPawn.h"


FCWPawnInputSelectedAndWantAttackEvent::FCWPawnInputSelectedAndWantAttackEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputSelectedAndWantAttackEvent::FCWPawnInputSelectedAndWantAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ACWPawn* ParamTargetPawn)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,TargetPawn(ParamTargetPawn)
{


}
