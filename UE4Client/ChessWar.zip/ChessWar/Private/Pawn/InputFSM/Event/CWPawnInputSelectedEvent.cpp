#include "CWPawnInputSelectedEvent.h"


FCWPawnInputSelectedEvent::FCWPawnInputSelectedEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputSelectedEvent::FCWPawnInputSelectedEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}
