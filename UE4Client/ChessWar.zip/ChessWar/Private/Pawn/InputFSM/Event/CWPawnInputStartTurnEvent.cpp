#include "CWPawnInputStartTurnEvent.h"


FCWPawnInputStartTurnEvent::FCWPawnInputStartTurnEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputStartTurnEvent::FCWPawnInputStartTurnEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}