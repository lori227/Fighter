#include "CWPawnInputWaitingAttackEvent.h"


FCWPawnInputWaitingAttackEvent::FCWPawnInputWaitingAttackEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputWaitingAttackEvent::FCWPawnInputWaitingAttackEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}