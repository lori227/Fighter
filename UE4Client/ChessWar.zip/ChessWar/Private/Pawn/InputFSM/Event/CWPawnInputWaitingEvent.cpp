#include "CWPawnInputWaitingEvent.h"


FCWPawnInputWaitingEvent::FCWPawnInputWaitingEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputWaitingEvent::FCWPawnInputWaitingEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}