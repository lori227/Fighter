#include "CWPawnInputWaitingTurnEvent.h"


FCWPawnInputWaitingTurnEvent::FCWPawnInputWaitingTurnEvent()
	:FCWFSMEvent()
{

}


FCWPawnInputWaitingTurnEvent::FCWPawnInputWaitingTurnEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}