#include "CWPawnInputFinishState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWMap.h"
#include "CWMapTile.h"
#include "CWPlayerController.h"
#include "CWPawnInputLeftMouseUpEvent.h"
#include "CWFuncLib.h"

FCWPawnInputFinishState::FCWPawnInputFinishState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputFinishState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputFinishState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	if (MyPawn->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(MyPawn->GetParantController());
		if (MyPlayerController != nullptr)
		{
			ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
			if (MyPawn == CurSelectedPawn)
			{
				MyPlayerController->CancelCurSelectedPawnNoEventInClient();
				ACWMap* MyMap = MyPlayerController->GetMap();

				ACWMapTile* CurSelectedTile = MyPlayerController->GetCurSelectedTile();
				ACWMapTile* MyMoveBeginTile = MyMap->GetTile(MyPawn->GetMoveBeginTile());
				if (MyMoveBeginTile != nullptr &&
					CurSelectedTile != nullptr &&
					MyMoveBeginTile->Tile == CurSelectedTile->Tile)
				{
					MyPlayerController->CancelCurSelectedTileInClient();
				}
			}
		}
	}

	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputFinishState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWPawnInputFinishState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputFinishState::Tick(float DeltaTime)
{

}

void FCWPawnInputFinishState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWMap* MyMap = MyPlayerController->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);


		//是否已有选中棋子
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			//当前已有选中棋子

			if (MyPlayerController->IsMyTurn(CurSelectedPawn) &&
				CurSelectedPawn->CanInstructsByCurInstructs())
			{

				//如果是自己
				if (MyPawn == CurSelectedPawn)
				{
					//则取消选中自己
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
				//当前选中的棋子是同伴
				else if (MyPlayerController->IsPartner(MyPawn, CurSelectedPawn))
				{
					//取消已经选中的目标棋子
					MyPlayerController->CancelCurTargetSelectedPawnInClient();

					//自己变成目标棋子
					MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
				}
				//当前选中的棋子是友方的棋子（暂无友方，暂不实现）
				else if (MyPlayerController->IsFriend(MyPawn, CurSelectedPawn))
				{

				}
				//当前选中的棋子是敌方的棋子
				else if (MyPlayerController->IsEnemy(MyPawn, CurSelectedPawn))
				{
					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
				else
				{
				}
			}
			else
			{
				//如果是自己
				if (MyPawn == CurSelectedPawn)
				{
					//当前选中的棋子是自己

					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
				else
				{
					//当前选中的棋子不是自己

					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
			}
		}
		else
		{
			//当前还没有选中棋子

			//取消选中地形格子
			MyPlayerController->CancelCurSelectedTileInClient();

			//则直接选中了这个棋子
			MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

			//把棋子所在格子变成选中的格子
			MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
		}
	}
}