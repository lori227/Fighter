#include "CWPawnInputMoveToDestState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Map/CWMap.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWMapTile.h"

FCWPawnInputMoveToDestState::FCWPawnInputMoveToDestState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{
	
}


bool FCWPawnInputMoveToDestState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputMoveToDestState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputMoveToDestState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	if (MyPawn->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(MyPawn->GetParantController());
		if (MyPlayerController != nullptr)
		{
			MyPlayerController->CancelCurSelectedPawnNoEventInClient();
			ACWMap* MyMap = MyPlayerController->GetMap();

			ACWMapTile* CurSelectedTile = MyPlayerController->GetCurSelectedTile();
			ACWMapTile* MyMoveBeginTile = MyMap->GetTile(MyPawn->GetMoveBeginTile());
			if (MyMoveBeginTile != nullptr &&
				CurSelectedTile != nullptr &&
				MyMoveBeginTile->Tile == CurSelectedTile->Tile)
			{
				MyPlayerController->CancelCurSelectedTileInClient();
			}
		}
	}
}

void FCWPawnInputMoveToDestState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWPawnInputMoveToDestState::Tick(float DeltaTime)
{

}