#include "CWPawnInputMoveToWaitingAttackState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Map/CWMap.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWMapTile.h"

FCWPawnInputMoveToWaitingAttackState::FCWPawnInputMoveToWaitingAttackState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputMoveToWaitingAttackState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
	case ECWPawnInputEvent::CancelToWaitingInput:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::WaitingAttack:
		if (Event->ToStateId == ECWPawnInputState::WaitingAttack)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputMoveToWaitingAttackState::OnEnter(const FCWFSMEvent* Event)
{

}

void FCWPawnInputMoveToWaitingAttackState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWPawnInputMoveToWaitingAttackState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWPawnInputMoveToWaitingAttackState::Tick(float DeltaTime)
{

}