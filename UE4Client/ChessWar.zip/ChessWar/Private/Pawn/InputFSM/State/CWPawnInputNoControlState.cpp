#include "CWPawnInputNoControlState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawnInputLeftMouseUpEvent.h"
#include "CWMap.h"
#include "CWPlayerController.h"
#include "CWPlayerState.h"
#include "CWMapTile.h"
#include "CWPawn.h"

FCWPawnInputNoControlState::FCWPawnInputNoControlState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputNoControlState::CanTranstion(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);

	ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(MyPawn->GetParantController());
	check(MyPlayerController);

	if (MyPawn->GetCampTag() == MyPlayerController->GetCampTag() &&
		MyPawn->GetCampControllerIndex() == MyPlayerController->GetCampControllerIndex())
	{
		return true;
	}
	else
	{
		return false;
	}

	
}

void FCWPawnInputNoControlState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputNoControlState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWPawnInputNoControlState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputNoControlState::Tick(float DeltaTime)
{

}

void FCWPawnInputNoControlState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWMap* MyMap = MyPlayerController->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		//是否已有选中棋子
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			//当前已有选中棋子

			//如果是自己
			if (MyPawn == CurSelectedPawn)
			{
				//则取消选中自己
				MyPlayerController->CancelCurSelectedPawnInClient();

				//取消选中地形格子
				MyPlayerController->CancelCurSelectedTileInClient();
			}
			//当前选中的棋子是同伴
			else if (MyPlayerController->IsPartner(MyPawn, CurSelectedPawn))
			{
				//取消已经选中的棋子
				MyPlayerController->CancelCurSelectedPawnInClient();

				//取消选中地形格子
				MyPlayerController->CancelCurSelectedTileInClient();

				//自己变成选中的棋子
				MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

				//把棋子所在格子变成选中的格子
				MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
			}
			//当前选中的棋子是友方的棋子（暂无友方，暂不实现）
			else if (MyPlayerController->IsFriend(MyPawn, CurSelectedPawn))
			{

			}
			//当前选中的棋子是敌方的棋子
			else if (MyPlayerController->IsEnemy(MyPawn, CurSelectedPawn))
			{
				if (MyPlayerController->IsMyTurn(CurSelectedPawn) &&
					CurSelectedPawn->CanInstructsByCurInstructs())
				{
					//获得当前选中的目标棋子
					ACWPawn* CurTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

					//判断当前选中的目标棋子是否存在
					if (CurTargetSelectedPawn != nullptr)
					{
						//当前选中的目标棋子是存在

						//判断当前选中的目标棋子是否自己
						if (CurTargetSelectedPawn == MyPawn)
						{
							//当前选中的目标棋子就是自己
							if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
							{
								//判断自己是不是在此棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//自己是在此棋子的攻击范围里
									MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
								}
								else
								{
									//自己不是在此棋子的攻击范围里
									UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::SelectedAndWantAttack)
							{
								//判断自己是不是在此棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//自己是在此棋子的攻击范围里
									MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
								}
								else
								{
									//自己不是在此棋子的攻击范围里
									UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMoveAndWantAttack)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									ACWPawn* OldTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

									//敌人头顶的Icon设置
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (MoveTile != CurSelectedPawn->GetTile())
										{
											if (OldTargetSelectedPawn == MyPawn)
											{
												int ReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
												int RealMoveTile = ReadyToDestTile != -1 ? ReadyToDestTile : MoveTile;
												//角色移动攻击
												MyPlayerController->AutoSelectSkillMoveToAttackInClient(
													CurSelectedPawn,
													MyPawn->GetTile(),
													RealMoveTile);
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
										}
										else
										{
											if (OldTargetSelectedPawn == MyPawn)
											{
												int ReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
												if (ReadyToDestTile != CurSelectedPawn->GetTile())
												{
													int RealMoveTile = ReadyToDestTile != -1 ? ReadyToDestTile : MoveTile;
													//角色移动攻击
													MyPlayerController->AutoSelectSkillMoveToAttackInClient(
														CurSelectedPawn,
														MyPawn->GetTile(),
														RealMoveTile);
												}
												else
												{
													MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
												}
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

									//敌人头顶的Icon设置
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (CurSelectedPawn->IsLongDown())
										{
											CurSelectedPawn->SetLongDown(false);

											//角色移动攻击
											MyPlayerController->AutoSelectSkillMoveToAttackInClient(
												CurSelectedPawn,
												MyPawn->GetTile(),
												MoveTile);
										}
										else
										{
											if (MoveTile != CurSelectedPawn->GetTile())
											{
												//uint8 TempMoveAttackDamage = 0x00;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
												//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
												if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), MyPawn->GetTile(), TempMoveAttackDamage))
												{
													//角色调整准备移动的目标格子
													MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), MyPawn);
												}
												else
												{
													//角色调整准备移动的目标格子
													MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
												}
											}
											else
											{
												int TempReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
												if (TempReadyToDestTile == CurSelectedPawn->GetTile())
												{
													//角色进入等待攻击状态
													MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
												}
												else
												{
													//角色调整准备移动的目标格子
													MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
												}
											}
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
								else
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

									//敌人头顶的Icon设置
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (CurSelectedPawn->IsLongDown())
										{
											CurSelectedPawn->SetLongDown(false);

											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
											RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, MyPawn->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
											if (RealMoveTile != CurSelectedPawn->GetTile())
											{
												//角色移动攻击
												MyPlayerController->AutoSelectSkillMoveToAttackInClient(
													CurSelectedPawn,
													MyPawn->GetTile(),
													RealMoveTile);
											}
											else
											{
												MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
											}
										}
										else
										{
											if (MoveTile != CurSelectedPawn->GetTile())
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
											else
											{
												//角色进入等待攻击状态
												MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
											}
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
								else
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
								}
							}
							else
							{
								//不处理
							}
						}
						else
						{
							//当前选中的目标棋子不是自己

							if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
								}
								else
								{
									//不处理
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
									
									//设置头顶Icon
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (MoveTile != CurSelectedPawn->GetTile())
										{
											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), MyPawn->GetTile(), TempMoveAttackDamage))
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), MyPawn);
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}

										}
										else
										{
											int TempReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
											if (TempReadyToDestTile == CurSelectedPawn->GetTile())
											{
												//角色进入等待攻击状态
												MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
								else
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

									//敌人头顶的Icon设置
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (CurSelectedPawn->IsLongDown())
										{
											CurSelectedPawn->SetLongDown(false);

											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
											RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, MyPawn->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
											if (RealMoveTile != CurSelectedPawn->GetTile())
											{
												//角色移动攻击
												MyPlayerController->AutoSelectSkillMoveToAttackInClient(
													CurSelectedPawn,
													MyPawn->GetTile(),
													RealMoveTile);
											}
											else
											{
												MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
											}
										}
										else
										{
											if (MoveTile != CurSelectedPawn->GetTile())
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
											else
											{
												//角色进入等待攻击状态
												MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
											}
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
								else
								{
									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::SelectedAndWantAttack)
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

								//敌人头顶的Icon设置
								CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

								int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
								if (MoveTile != -1)
								{
									if (MoveTile != CurSelectedPawn->GetTile())
									{
										//判断此次选中棋子的移动范围里的格子 是否是已准备移动到目标点格子
										if (CurSelectedPawn->GetReadyToDestTile() == MoveTile)
										{
											//此次选中棋子的移动范围里的格子 是已准备移动到目标点格子

											//角色移动
											MyPlayerController->MoveToDestTileInClient(CurSelectedPawn, MoveTile);
										}
										else
										{
											//此次选中棋子的移动范围里的格子 不是已准备移动到目标点格子

											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
										}
									}
									else
									{
										//角色进入等待攻击状态
										MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
									}
								}
								else
								{
									UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
								}
							}
							else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMoveAndWantAttack)
							{
								//判断自己是否是在当前选中棋子的攻击范围里
								uint8 TempMoveAttackDamage = 0x00;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
								TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
								if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
								{
									ACWPawn* OldTargetSelectedPawn = MyPlayerController->GetCurTargetSelectedPawn();

									//取消已经选中的目标棋子
									MyPlayerController->CancelCurTargetSelectedPawnInClient();

									//自己变成目标棋子
									MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

									//敌人头顶的Icon设置
									CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

									int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
									if (MoveTile != -1)
									{
										if (MoveTile != CurSelectedPawn->GetTile())
										{
											if (OldTargetSelectedPawn == MyPawn)
											{
												//角色移动攻击
												MyPlayerController->AutoSelectSkillMoveToAttackInClient(
													CurSelectedPawn,
													MyPawn->GetTile(),
													MoveTile);
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
										}
										else
										{
											//角色进入等待攻击状态
											MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
										}
									}
									else
									{
										UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
									}
								}
							}
							else 
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
							}
						}
					}
					else
					{
						//当前选中的目标棋子不存在

						if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
						{
							//取消已经选中的目标棋子
							MyPlayerController->CancelCurTargetSelectedPawnInClient();

							//自己变成目标棋子
							MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
						}
						else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::ReadyToMove)
						{
							//判断自己是否是在当前选中棋子的攻击范围里
							uint8 TempMoveAttackDamage = 0x00;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
							if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

								//敌人头顶的Icon设置
								CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

								int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
								if (MoveTile != -1)
								{
									if (CurSelectedPawn->IsLongDown())
									{
										CurSelectedPawn->SetLongDown(false);

										//角色移动攻击
										MyPlayerController->AutoSelectSkillMoveToAttackInClient(
											CurSelectedPawn,
											MyPawn->GetTile(),
											MoveTile);
									}
									else
									{
										if (MoveTile != CurSelectedPawn->GetTile())
										{
											//uint8 TempMoveAttackDamage = 0x00;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
											//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
											if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), MyPawn->GetTile(), TempMoveAttackDamage))
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), MyPawn);
											}
											else
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
											}
										}
										else
										{
											if (CurSelectedPawn->IsAttackTileFromTile(CurSelectedPawn->GetReadyToDestTile(), MyPawn->GetTile(), TempMoveAttackDamage))
											{
												//角色调整准备移动的目标格子
												MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, CurSelectedPawn->GetReadyToDestTile(), MyPawn);
											}
											else
											{
												int TempReadyToDestTile = CurSelectedPawn->GetReadyToDestTile();
												if (TempReadyToDestTile == CurSelectedPawn->GetTile())
												{
													//角色进入等待攻击状态
													MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
												}
												else
												{
													//角色调整准备移动的目标格子
													MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
												}
											}
										}
									}
								}
								else
								{
									UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
								}
							}
							else
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
							}
						}
						else if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::Selected)
						{
							//判断自己是否是在当前选中棋子的攻击范围里
							uint8 TempMoveAttackDamage = 0x00;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
							TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
							if (CurSelectedPawn->IsMoveAttackTileFromTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), TempMoveAttackDamage))
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);

								//敌人头顶的Icon设置
								CurSelectedPawn->SetEnemyHeadIconInAttackSingle(MyPawn);

								int MoveTile = CurSelectedPawn->GetMoveTileFromNormalAttackTargetTile(CurSelectedPawn->GetTile(), MyPawn->GetTile(), CurSelectedPawn->GetCampTag(), CurSelectedPawn->GetFindPathInfo());
								if (MoveTile != -1)
								{
									if (CurSelectedPawn->IsLongDown())
									{
										CurSelectedPawn->SetLongDown(false);

										//uint8 TempMoveAttackDamage = 0x00;
										//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Attack;
										//TempMoveAttackDamage |= (uint8)ECWMapTileMoveAttackDamageType::Damage;
										int RealMoveTile = MyPlayerController->GetPressReadyToDestTile() == -1 ? MoveTile : MyPlayerController->GetPressReadyToDestTile();
										RealMoveTile = CurSelectedPawn->IsAttackTileFromTile(RealMoveTile, MyPawn->GetTile(), TempMoveAttackDamage) ? RealMoveTile : MoveTile;
										if (RealMoveTile != CurSelectedPawn->GetTile())
										{
											//角色移动攻击
											MyPlayerController->AutoSelectSkillMoveToAttackInClient(
												CurSelectedPawn,
												MyPawn->GetTile(),
												RealMoveTile);
										}
										else
										{
											MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, MyPawn->GetTile());
										}
									}
									else
									{
										if (MoveTile != CurSelectedPawn->GetTile())
										{
											//角色调整准备移动的目标格子
											MyPlayerController->ReadyMoveToDestTileAndWantAttackInClient(CurSelectedPawn, MoveTile, MyPawn);
										}
										else
										{
											//角色进入等待攻击状态
											MyPlayerController->SelectedAndWantAttackToPawnInClient(CurSelectedPawn, MyPawn);
										}
									}
								}
								else
								{
									UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
								}
							}
							else
							{
								//取消已经选中的目标棋子
								MyPlayerController->CancelCurTargetSelectedPawnInClient();

								//自己变成目标棋子
								MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
							}
						}
						else
						{
							//取消已经选中的目标棋子
							MyPlayerController->CancelCurTargetSelectedPawnInClient();

							//自己变成目标棋子
							MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
						}
					}
				}
				else
				{
					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
			}
			else
			{
				UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputNoControlState::HandleLeftMouseUp impossible"));
			}
		}
		else
		{
			//当前还没有选中棋子

			//取消选中地形格子
			MyPlayerController->CancelCurSelectedTileInClient();

			//则直接选中了这个棋子
			MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

			//把棋子所在格子变成选中的格子
			MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
		}
	}
}