
#include "CWPawnInputNoCtrlInReadyState.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWFSMEvent.h"
#include "CWPawnInputFSM.h"
#include "CWPlayerController.h"
#include "CWPawnInputLeftMouseEvent.h"


FCWPawnInputNoCtrlInReadyState::FCWPawnInputNoCtrlInReadyState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{
}

bool FCWPawnInputNoCtrlInReadyState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWPawnInputNoCtrlInReadyState::OnEnter(const FCWFSMEvent* Event)
{
}

void FCWPawnInputNoCtrlInReadyState::OnExit(const FCWFSMEvent* Event)
{
}

void FCWPawnInputNoCtrlInReadyState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputNoCtrlInReadyState::Tick(float DeltaTime)
{
}

void FCWPawnInputNoCtrlInReadyState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	const FCWPawnInputLeftMouseEvent* LeftMouseEvent = static_cast<const FCWPawnInputLeftMouseEvent*>(Event);
	if (nullptr != LeftMouseEvent && nullptr != LeftMouseEvent->EvtPawn && nullptr != LeftMouseEvent->ClientOpPc)
	{
		ACWPlayerController* ClientOpPc = LeftMouseEvent->ClientOpPc;

		ACWMap* MyMap = ClientOpPc->GetMap();
		ACWPawn* MyPawn = static_cast<UCWPawnInputFSM*>(Parent)->GetParantPawn();
		check(MyPawn && MyMap && ">> MyPawn or MyMap is Null!");

		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPawn* CurSelectedPawn = ClientOpPc->GetCurSelectedPawn();
		//ACWPawn* CurSelectedPawn = ClientOpPc->GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != CurSelectedPawn)
		{
			// 当前选中棋子是自己
			if (MyPawn == CurSelectedPawn)
			{
				FCWStaticFuncInReady::OpPcCanceSelectedPawn(ClientOpPc);
			}
			// 当前选中棋子是同伴/敌方棋子
			else if (ClientOpPc->IsPartner(MyPawn, CurSelectedPawn) ||
				ClientOpPc->IsEnemy(MyPawn, CurSelectedPawn))
			{
				FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
			}
			// 当前选中棋子是友方棋子
			else if (ClientOpPc->IsFriend(MyPawn, CurSelectedPawn))
			{
			}
		}
		else
		{
			FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
		}
	}
}

void FCWStaticFuncInReady::OpPcCanceSelectedPawn(ACWPlayerController* InOpPc)
{
	check(InOpPc);
	InOpPc->CancelSelectedPawnInReady();
	InOpPc->CancelSelectedTileInReady();
}

void FCWStaticFuncInReady::OpPCSelectedPawn(ACWPlayerController* InOpPc, ACWPawn* InPawn, ACWMapTile* InMapTile)
{
	check(InOpPc && InPawn && InMapTile);
	OpPcCanceSelectedPawn(InOpPc);
	InOpPc->SetSelectedPawnInReady(InPawn);
	InOpPc->SetSelectedTileInReady(InMapTile);
}
