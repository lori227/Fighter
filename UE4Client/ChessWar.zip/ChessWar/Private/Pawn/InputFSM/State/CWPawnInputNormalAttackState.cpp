#include "CWPawnInputNormalAttackState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/CWPawn.h"
#include "Map/CWMap.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWMapTile.h"

FCWPawnInputNormalAttackState::FCWPawnInputNormalAttackState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputNormalAttackState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputNormalAttackState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	if (MyPawn->GetParantControllerType() == ECWControllerType::NetPlayer)
	{
		ACWPlayerController* MyPlayerController = Cast<ACWPlayerController>(MyPawn->GetParantController());
		if (MyPlayerController != nullptr)
		{
			MyPlayerController->CancelCurSelectedPawnNoEventInClient();
			ACWMap* MyMap = MyPlayerController->GetMap();

			ACWMapTile* CurSelectedTile = MyPlayerController->GetCurSelectedTile();
			ACWMapTile* MyMoveBeginTile = MyMap->GetTile(MyPawn->GetMoveBeginTile());
			if (MyMoveBeginTile != nullptr &&
				CurSelectedTile != nullptr &&
				MyMoveBeginTile->Tile == CurSelectedTile->Tile)
			{
				MyPlayerController->CancelCurSelectedTileInClient();
			}
		}
	}
	
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputNormalAttackState::OnExit(const FCWFSMEvent* Event)
{
	
}

void FCWPawnInputNormalAttackState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWPawnInputNormalAttackState::Tick(float DeltaTime)
{

}