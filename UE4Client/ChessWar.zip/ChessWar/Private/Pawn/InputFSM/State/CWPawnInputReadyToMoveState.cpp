#include "CWPawnInputReadyToMoveState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawnInputReadyToMoveEvent.h"
#include "CWPawnInputLeftMouseUpEvent.h"
#include "CWPawn.h"
#include "CWPlayerController.h"
#include "CWPlayerState.h"
#include "CWMapTile.h"
#include "CWMap.h"

FCWPawnInputReadyToMoveState::FCWPawnInputReadyToMoveState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputReadyToMoveState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
	case ECWPawnInputEvent::CancelToWaitingInput:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::SelectedAndWantAttack:
		if (Event->ToStateId == ECWPawnInputState::SelectedAndWantAttack)
			return true;
		break;
	case ECWPawnInputEvent::ReadyToMoveAndWantAttack:
		if (Event->ToStateId == ECWPawnInputState::ReadyToMoveAndWantAttack)
			return true;
		break;
	case ECWPawnInputEvent::MoveToDest:
		if (Event->ToStateId == ECWPawnInputState::MoveToDest)
			return true;
		break;
	case ECWPawnInputEvent::MoveToAttack:
		if (Event->ToStateId == ECWPawnInputState::MoveToAttack)
			return true;
		break;
	case ECWPawnInputEvent::MoveToWaitingAttack:
		if (Event->ToStateId == ECWPawnInputState::MoveToWaitingAttack)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputReadyToMoveState::OnEnter(const FCWFSMEvent* Event)
{
	FCWPawnInputReadyToMoveEvent* ReadyToMoveEvent = (FCWPawnInputReadyToMoveEvent*)(Event);
	check(ReadyToMoveEvent);

	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SetMoveBeginTile(MyPawn->GetTile());
	MyPawn->SetMoveBeginPos(MyPawn->GetActorLocation());
	MyPawn->SetMoveBeginRotator(MyPawn->GetActorRotation());
	
	MyPawn->SetReadyToDestTile(ReadyToMoveEvent->Tile);

	MyPawn->RestoreEnemyHeadIconInAttackRange();
	MyPawn->RestorePartnerHeadIconInSupportRange();

	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(101);
}

void FCWPawnInputReadyToMoveState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputReadyToMoveState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	//玩家已经选了一个准备移动的目标格子，然后又选了别的准备移动的目标格子
	case ECWPawnInputEvent::ReadyToMove:
		HandleReadyToMove(Event);
		break;
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputReadyToMoveState::Tick(float DeltaTime)
{

}

void FCWPawnInputReadyToMoveState::HandleReadyToMove(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);

	FCWPawnInputReadyToMoveEvent* ReadyToMoveEvent = (FCWPawnInputReadyToMoveEvent*)Event;
	if (ReadyToMoveEvent != nullptr)
	{
		MyPawn->SetReadyToDestTile(ReadyToMoveEvent->Tile);
	}
}

void FCWPawnInputReadyToMoveState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWMap* MyMap = MyPlayerController->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		//是否已有选中棋子
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			//当前已有选中棋子

			if (MyPlayerController->IsPartner(CurSelectedPawn))
			{
				//当前选中的棋子是自己方的

				//如果是自己
				if (MyPawn == CurSelectedPawn)
				{
					//则取消选中自己
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
				else
				{
					UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputReadyToMoveState::HandleLeftMouseUp impossible"));
				}
			}
			else
			{
				UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputReadyToMoveState::HandleLeftMouseUp impossible"));
			}
		}
		else
		{
			UE_LOG(LogCWPawnInputFSM, Error, TEXT("FCWPawnInputReadyToMoveState::HandleLeftMouseUp impossible"));
		}
	}
}