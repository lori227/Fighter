﻿#include "CWPawnInputSelectedAndWantAttackState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Pawn/InputFSM/Event/CWPawnInputLeftMouseUpEvent.h"
#include "Pawn/InputFSM/Event/CWPawnInputSelectedEvent.h" 
#include "Pawn/Controller/Player/CWPlayerController.h"

FCWPawnInputSelectedAndWantAttackState::FCWPawnInputSelectedAndWantAttackState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputSelectedAndWantAttackState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
	case ECWPawnInputEvent::CancelToWaitingInput:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::ReadyToMove:
		if (Event->ToStateId == ECWPawnInputState::ReadyToMove)
			return true;
		break;
	case ECWPawnInputEvent::ReadyToMoveAndWantAttack:
		if (Event->ToStateId == ECWPawnInputState::ReadyToMoveAndWantAttack)
			return true;
		break;
	case ECWPawnInputEvent::NormalAttack:
		if (Event->ToStateId == ECWPawnInputState::NormalAttack)
			return true;
		break;
	case ECWPawnInputEvent::CastSkillToTile:
		if (Event->ToStateId == ECWPawnInputState::CastSkillToTile)
			return true;
		break;
	case ECWPawnInputEvent::CastSkillToPawn:
		if (Event->ToStateId == ECWPawnInputState::CastSkillToPawn)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputSelectedAndWantAttackState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);

	MyPawn->SetReadyToDestTile(-1);
	MyPawn->HideWantMovePathArrow();
	MyPawn->ShowShadowVisible(false);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(101);
}

void FCWPawnInputSelectedAndWantAttackState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputSelectedAndWantAttackState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputSelectedAndWantAttackState::Tick(float DeltaTime)
{

}



void FCWPawnInputSelectedAndWantAttackState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (MyPawn == CurSelectedPawn)
		{
			//取消已经选中的棋子
			MyPlayerController->CancelCurSelectedPawnInClient();

			//把棋子所在格子变成选中的格子
			MyPlayerController->CancelCurSelectedTileInClient();
		}
		else
		{
			UE_LOG(LogCWPawnInputFSM, Log, TEXT("FCWPawnInputSelectedState::HandleLeftMouseUp impossible"));
		}
	}
}