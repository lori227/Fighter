﻿
#include "CWPawnInputSelectedInReadyState.h"

#include "CWMap.h"
#include "CWFSM.h"
#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWComDef.h"
#include "CWFSMEvent.h"
#include "CWPawnInputFSM.h"
#include "CWPlayerController.h"

#include "CWPawnInputLeftMouseEvent.h"

FCWPawnInputSelectedInReadyState::FCWPawnInputSelectedInReadyState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{
}

bool FCWPawnInputSelectedInReadyState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWPawnInputSelectedInReadyState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(101);
}

void FCWPawnInputSelectedInReadyState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->ShowHeadIcon(EUIHeadIconType::None);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputSelectedInReadyState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseDown:
		HandleLeftMouseDown(Event);
		break;
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputSelectedInReadyState::Tick(float DeltaTime)
{
}

void FCWPawnInputSelectedInReadyState::HandleLeftMouseDown(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseEvent* LeftMouseEvent = (FCWPawnInputLeftMouseEvent*)Event;
	if (LeftMouseEvent != nullptr &&
		LeftMouseEvent->EvtPawn != nullptr &&
		LeftMouseEvent->ClientOpPc != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseEvent->ClientOpPc;
		check(MyPlayerController);

		ACWPawn* CurSelectedPawn = MyPlayerController->GetSelectedPawn(ECWBattleState::Ready);
		if (MyPawn == CurSelectedPawn)
		{
			MyPlayerController->CancelSelectedPawnInReady();
			MyPlayerController->CancelSelectedTileInReady();
		}
		else
		{
			CWG_WARNING(" >> FCWPawnInputSelectedInReadyState::HandleLeftMouseDown impossible");
		}
	}
}

void FCWPawnInputSelectedInReadyState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseEvent* LeftMouseEvent = (FCWPawnInputLeftMouseEvent*)Event;
	if (LeftMouseEvent != nullptr &&
		LeftMouseEvent->EvtPawn != nullptr &&
		LeftMouseEvent->ClientOpPc != nullptr)
	{
		ACWPawn* MyPawn = Cast<UCWPawnInputFSM>(Parent)->GetParantPawn();
		check(MyPawn);
		ACWPlayerController* ClientOpPc = LeftMouseEvent->ClientOpPc;
		check(ClientOpPc);

		ACWMap* MyMap = ClientOpPc->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPawn* ClientOpPcCurPawn = ClientOpPc->GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != ClientOpPcCurPawn)
		{
			if (MyPawn == ClientOpPcCurPawn)
			{	// 点击同一棋子
			}
			else if (UCWFuncLib::IsPartner(MyPawn, ClientOpPcCurPawn))
			{	// 点击同伴(同一控制器棋子)
				if (!ClientOpPc->IsReadyFinished())
				{
					ClientOpPc->CancelSelectedPawnInReady();
					ClientOpPc->CancelSelectedTileInReady();
					// 切换两个旗子位置
					ClientOpPc->ServerSwitchPawnPosInReady(ClientOpPcCurPawn, MyPawn);
				}
				else
				{
					ClientOpPc->SetSelectedPawnInReady(MyPawn);
					ClientOpPc->SetSelectedTileInReady(MyPawnMapTile);
				}
			}
			else if (UCWFuncLib::IsFriend(MyPawn, ClientOpPcCurPawn))
			{	// 点击队友(同一阵营不同控制器棋子)
			}
			else if (UCWFuncLib::IsEnemy(MyPawn, ClientOpPcCurPawn))
			{	// 点击敌人(跳过)
			}
			else
			{
				CWG_ERROR(" >>>> FCWPawnInputWaitInReadyState::HandleLeftMouseUp, Click No...");
			}
		}
	}
}