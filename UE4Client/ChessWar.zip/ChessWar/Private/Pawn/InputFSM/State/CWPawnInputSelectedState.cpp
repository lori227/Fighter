#include "CWPawnInputSelectedState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "Pawn/CWPawn.h"
#include "Pawn/InputFSM/Event/CWPawnInputLeftMouseUpEvent.h"
#include "Pawn/InputFSM/Event/CWPawnInputSelectedEvent.h" 
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWSkill.h"

FCWPawnInputSelectedState::FCWPawnInputSelectedState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputSelectedState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
	case ECWPawnInputEvent::CancelToWaitingInput:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::SelectedAndWantAttack:
		if (Event->ToStateId == ECWPawnInputState::SelectedAndWantAttack)
			return true;
		break;
	case ECWPawnInputEvent::ReadyToMove:
		if (Event->ToStateId == ECWPawnInputState::ReadyToMove)
			return true;
		break;
	case ECWPawnInputEvent::ReadyToMoveAndWantAttack:
		if (Event->ToStateId == ECWPawnInputState::ReadyToMoveAndWantAttack)
			return true;
		break;
	case ECWPawnInputEvent::MoveToDest:
		if (Event->ToStateId == ECWPawnInputState::MoveToDest)
			return true;
		break;
	case ECWPawnInputEvent::MoveToAttack:
		if (Event->ToStateId == ECWPawnInputState::MoveToAttack)
			return true;
		break;
	case ECWPawnInputEvent::MoveToWaitingAttack:
		if (Event->ToStateId == ECWPawnInputState::MoveToWaitingAttack)
			return true;
		break;
	case ECWPawnInputEvent::NormalAttack:
		if (Event->ToStateId == ECWPawnInputState::NormalAttack)
			return true;
		break;
	case ECWPawnInputEvent::CastSkillToPawn:
		if (Event->ToStateId == ECWPawnInputState::CastSkillToPawn)
			return true;
		break;
	case ECWPawnInputEvent::CastSkillToTile:
		if (Event->ToStateId == ECWPawnInputState::CastSkillToTile)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputSelectedState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SetMoveBeginTile(MyPawn->GetTile());
	MyPawn->SetMoveBeginPos(MyPawn->GetActorLocation());
	MyPawn->SetMoveBeginRotator(MyPawn->GetActorRotation());
	MyPawn->SetReadyToDestTile(-1);

	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(101);
}

void FCWPawnInputSelectedState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputSelectedState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputSelectedState::Tick(float DeltaTime)
{

}



void FCWPawnInputSelectedState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (MyPawn == CurSelectedPawn)
		{
			if (CurSelectedPawn->IsLongDown())
			{
				CurSelectedPawn->SetLongDown(false);

				UCWSkill* TempSkill = CurSelectedPawn->GetAutoSelectSkillRecord();
				if (TempSkill != nullptr &&
					!TempSkill->IsNormalAttack() &&
					(TempSkill->GetSkillDataStruct()->TargetType > 0 && ((TempSkill->GetSkillDataStruct()->TargetType & (int32)ECWSkillTargetType::Self) > 0)))
				{
					MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, CurSelectedPawn->GetTile());
				}
				else
				{
					// 取消当前选中棋子
					//MyPlayerController->CancelCurSelectedPawnInClient();

					// 取消当前选中格子
					//MyPlayerController->CancelCurSelectedTileInClient();
				}
			}
			else
			{
				UCWSkill* TempSkill = CurSelectedPawn->GetAutoSelectSkillRecord();
				if (TempSkill != nullptr &&
					!TempSkill->IsNormalAttack() &&
					(TempSkill->GetSkillDataStruct()->TargetType > 0 && ((TempSkill->GetSkillDataStruct()->TargetType & (int32)ECWSkillTargetType::Self) > 0)))
				{
					MyPlayerController->AutoSelectSkillAttackInClient(CurSelectedPawn, CurSelectedPawn->GetTile());
				}
				else
				{
					// 取消当前选中棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					// 取消当前选中格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
			}
		}
		else
		{
			UE_LOG(LogCWPawnInputFSM, Log, TEXT("FCWPawnInputSelectedState::HandleLeftMouseUp impossible"));
		}
	}
}