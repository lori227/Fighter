﻿
#include "CWPawnInputWaitInReadyState.h"

#include "CWMap.h"
#include "CWFSM.h"
#include "CWPawn.h"
#include "CWMapTile.h"
#include "CWFuncLib.h"
#include "CWComDef.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWPawnInputFSM.h"
#include "CWPlayerController.h"

#include "CWPawnInputLeftMouseEvent.h"
#include "CWPawnInputNoCtrlInReadyState.h"

FCWPawnInputWaitInReadyState::FCWPawnInputWaitInReadyState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{
}

bool FCWPawnInputWaitInReadyState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWPawnInputWaitInReadyState::OnEnter(const FCWFSMEvent* Event)
{
}

void FCWPawnInputWaitInReadyState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* OwnerPawn = Cast<UCWPawnInputFSM>(Parent)->GetParantPawn();
	if (nullptr != OwnerPawn)
	{
		OwnerPawn->ShowHeadIcon(EUIHeadIconType::None);
	}
}

void FCWPawnInputWaitInReadyState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseDown:
		HandleLeftMouseDown(Event);
		break;
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputWaitInReadyState::Tick(float DeltaTime)
{
}

void FCWPawnInputWaitInReadyState::HandleLeftMouseDown(const FCWFSMEvent* Event)
{
	const FCWPawnInputLeftMouseEvent* LeftMouseEvent = static_cast<const FCWPawnInputLeftMouseEvent*>(Event);
	if (nullptr != LeftMouseEvent && nullptr != LeftMouseEvent->EvtPawn && nullptr != LeftMouseEvent->ClientOpPc)
	{
		ACWPlayerController* ClientOpPc = LeftMouseEvent->ClientOpPc;

		ACWMap* MyMap = ClientOpPc->GetMap();
		ACWPawn* MyPawn = static_cast<UCWPawnInputFSM*>(Parent)->GetParantPawn();
		check(MyPawn && MyMap && ">> MyPawn or MyMap is Null!");

		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		//ACWPawn* CurSelectedPawn = ClientOpPc->GetCurSelectedPawn();
		ACWPawn* CurSelectedPawn = ClientOpPc->GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != CurSelectedPawn)
		{
			if (MyPawn == CurSelectedPawn)
			{	// 点击同一棋子
				FCWStaticFuncInReady::OpPcCanceSelectedPawn(ClientOpPc);
			}
			else if (UCWFuncLib::IsPartner(MyPawn, CurSelectedPawn))
			{	// 点击同伴(同一控制器棋子)
				if (!ClientOpPc->IsReadyFinished())
				{
					FCWStaticFuncInReady::OpPcCanceSelectedPawn(ClientOpPc);
					// 切换两个旗子位置
					ClientOpPc->ServerSwitchPawnPosInReady(CurSelectedPawn, MyPawn);
				}
				else
				{
					FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
				}
			}
			else if (UCWFuncLib::IsFriend(MyPawn, CurSelectedPawn))
			{	// 点击队友(同一阵营不同控制器棋子)
			}
			else if (UCWFuncLib::IsEnemy(MyPawn, CurSelectedPawn))
			{	// 点击敌人(跳过)
				FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
			}
		}
		else
		{
			FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
		}
	}
}

void FCWPawnInputWaitInReadyState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	const FCWPawnInputLeftMouseEvent* LeftMouseEvent = static_cast<const FCWPawnInputLeftMouseEvent*>(Event);
	if (nullptr != LeftMouseEvent && nullptr != LeftMouseEvent->EvtPawn && nullptr != LeftMouseEvent->ClientOpPc)
	{
		ACWPlayerController* ClientOpPc = LeftMouseEvent->ClientOpPc;

		ACWMap* MyMap = ClientOpPc->GetMap();
		ACWPawn* MyPawn = static_cast<UCWPawnInputFSM*>(Parent)->GetParantPawn();
		check(MyPawn && MyMap && ">> MyPawn or MyMap is Null!");

		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		//ACWPawn* CurSelectedPawn = ClientOpPc->GetCurSelectedPawn();
		ACWPawn* ClientOpPcCurPawn = ClientOpPc->GetSelectedPawn(ECWBattleState::Ready);
		if (nullptr != ClientOpPcCurPawn)
		{	// 已有选中棋子
			if (MyPawn == ClientOpPcCurPawn)
			{	// 点击同一棋子(按下即选中)
			}
			else if (UCWFuncLib::IsPartner(MyPawn, ClientOpPcCurPawn))
			{	// 点击同伴(同一控制器棋子)
				if (!ClientOpPc->IsReadyFinished())
				{
					FCWStaticFuncInReady::OpPcCanceSelectedPawn(ClientOpPc);
					// 切换两个旗子位置
					ClientOpPc->ServerSwitchPawnPosInReady(ClientOpPcCurPawn, MyPawn);
				}
				else
				{
					FCWStaticFuncInReady::OpPCSelectedPawn(ClientOpPc, MyPawn, MyPawnMapTile);
				}
			}
			else if (UCWFuncLib::IsFriend(MyPawn, ClientOpPcCurPawn))
			{	// 点击队友(同一阵营不同控制器棋子)
			}
			else if (UCWFuncLib::IsEnemy(MyPawn, ClientOpPcCurPawn))
			{	// 点击敌人(跳过)
			}
		}
	}
}