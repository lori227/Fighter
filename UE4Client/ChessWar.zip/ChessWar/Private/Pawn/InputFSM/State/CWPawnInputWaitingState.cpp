#include "CWPawnInputWaitingState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "Pawn/InputFSM/Event/CWPawnInputLeftMouseUpEvent.h"
#include "Pawn/InputFSM/Event/CWPawnInputSelectedEvent.h" 
#include "Pawn/CWPawn.h"
#include "Pawn/Controller/Player/CWPlayerController.h"
#include "CWMap.h"
#include "CWMapTile.h"
#include "CWPawnInputNormalAttackEvent.h"

FCWPawnInputWaitingState::FCWPawnInputWaitingState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputWaitingState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnWaitingAction:
		if (Event->ToStateId == ECWPawnInputState::TurnWaitingAction)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish:
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	case ECWPawnInputEvent::TurnStartAction:
	case ECWPawnInputEvent::CancelToWaitingInput:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::Selected:
		if (Event->ToStateId == ECWPawnInputState::Selected)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputWaitingState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);

	MyPawn->HideHintTile();

	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(100);
}

void FCWPawnInputWaitingState::OnExit(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputWaitingState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputWaitingState::Tick(float DeltaTime)
{

}

void FCWPawnInputWaitingState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWMap* MyMap = MyPlayerController->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		
		//是否已有选中棋子
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			//当前已有选中棋子

			//如果是自己
			if (MyPawn == CurSelectedPawn)
			{
				if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
				{
					//TODO:
				}
				else
				{
					//则取消选中自己
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
			}
			//当前选中的棋子是同伴
			else if (MyPlayerController->IsPartner(CurSelectedPawn))
			{
				if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
				{
					//TODO:
				}
				else
				{
					if (CurSelectedPawn->CanInstructsByCurInstructs())
					{
						//取消已经选中的目标棋子
						MyPlayerController->CancelCurTargetSelectedPawnInClient();

						//自己变成目标棋子
						MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
					}
					else
					{
						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();

						//取消选中地形格子
						MyPlayerController->CancelCurSelectedTileInClient();

						//自己变成选中的棋子
						MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

						//把棋子所在格子变成选中的格子
						MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
					}
				}
			}
			//当前选中的棋子是友方的棋子（暂无友方，暂不实现）
			else if (MyPlayerController->IsFriend(CurSelectedPawn))
			{

			}
			//当前选中的棋子是敌方的棋子
			else if (MyPlayerController->IsEnemy(CurSelectedPawn))
			{
				if (CurSelectedPawn->GetCurInputFSMStateId() == ECWPawnInputState::WaitingAttack)
				{
					FCWPawnInputNormalAttackEvent* NormalAttackEvent = new FCWPawnInputNormalAttackEvent((int32)ECWPawnInputEvent::NormalAttack, (int32)ECWPawnInputState::NormalAttack, ECWFSMStackOp::Set, MyPawn);
					CurSelectedPawn->GetInputFSM()->DoEvent(NormalAttackEvent);
				}
				else
				{
					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
			}
			else
			{
			}
		}
		else
		{
			//当前还没有选中棋子

			//取消选中地形格子
			MyPlayerController->CancelCurSelectedTileInClient();

			//则直接选中了这个棋子
			MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

			//把棋子所在格子变成选中的格子
			MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
		}
	}
}