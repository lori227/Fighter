#include "CWPawnInputWaitingTurnState.h"
#include "FSM/CWFSM.h"
#include "FSM/CWFSMState.h"
#include "Pawn/InputFSM/CWPawnInputFSM.h"
#include "FSM/CWFSMEvent.h"
#include "CWPawnInputLeftMouseUpEvent.h"
#include "CWMap.h"
#include "CWPawn.h"
#include "CWPlayerController.h"

FCWPawnInputWaitingTurnState::FCWPawnInputWaitingTurnState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}


bool FCWPawnInputWaitingTurnState::CanTranstion(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::TurnStartAction:
		if (Event->ToStateId == ECWPawnInputState::WaitingInput)
			return true;
		break;
	case ECWPawnInputEvent::TurnActionFinish://被打死的情况
		if (Event->ToStateId == ECWPawnInputState::TurnInputFinish)
			return true;
		break;
	}
	return false;
}

void FCWPawnInputWaitingTurnState::OnEnter(const FCWFSMEvent* Event)
{
	ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
	check(MyPawn);
	MyPawn->SkeletalMeshComponent->SetCustomDepthStencilValue(0);
}

void FCWPawnInputWaitingTurnState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWPawnInputWaitingTurnState::DoEvent(const FCWFSMEvent* Event)
{
	switch ((ECWPawnInputEvent)Event->EventId)
	{
	case ECWPawnInputEvent::LeftMouseUp:
		HandleLeftMouseUp(Event);
		break;
	}
}

void FCWPawnInputWaitingTurnState::Tick(float DeltaTime)
{

}

void FCWPawnInputWaitingTurnState::HandleLeftMouseUp(const FCWFSMEvent* Event)
{
	FCWPawnInputLeftMouseUpEvent* LeftMouseUpEvent = (FCWPawnInputLeftMouseUpEvent*)Event;
	if (LeftMouseUpEvent != nullptr &&
		LeftMouseUpEvent->Pawn != nullptr &&
		LeftMouseUpEvent->PlayerControllerInClient != nullptr)
	{
		ACWPawn* MyPawn = ((UCWPawnInputFSM*)Parent)->GetParantPawn();
		check(MyPawn);

		ACWPlayerController* MyPlayerController = LeftMouseUpEvent->PlayerControllerInClient;
		check(MyPlayerController);

		ACWMap* MyMap = MyPlayerController->GetMap();
		check(MyMap);
		ACWMapTile* MyPawnMapTile = MyMap->GetTile(MyPawn->GetTile());
		check(MyPawnMapTile);

		ACWPlayerState* MyPlayerState = MyPlayerController->GetCWPlayerState();
		check(MyPlayerState);

		//是否已有选中棋子
		ACWPawn* CurSelectedPawn = MyPlayerController->GetCurSelectedPawn();
		if (CurSelectedPawn != nullptr)
		{
			//当前已有选中棋子

			if (MyPlayerController->IsPartner(CurSelectedPawn))
			{
				//当前选中的棋子是自己方的

				//如果是自己
				if (MyPawn == CurSelectedPawn)
				{
					//则取消选中自己
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
				//当前选中的棋子是同伴
				else if (MyPlayerController->IsPartner(MyPawn, CurSelectedPawn))
				{
					//判断是否当前选中的棋子轮到它可以行动了
					if (MyPlayerController->IsMyTurn(CurSelectedPawn) &&
						CurSelectedPawn->CanInstructsByCurInstructs())
					{
						//是当前选中的棋子轮到它可以行动了

						//取消已经选中的目标棋子
						MyPlayerController->CancelCurTargetSelectedPawnInClient();

						//自己变成目标棋子
						MyPlayerController->SetCurTargetSelectedPawnInClient(MyPawn);
					}
					else
					{
						//不是当前选中的棋子轮到它可以行动了

						//取消已经选中的棋子
						MyPlayerController->CancelCurSelectedPawnInClient();

						//取消选中地形格子
						MyPlayerController->CancelCurSelectedTileInClient();

						//自己变成选中的棋子
						MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

						//把棋子所在格子变成选中的格子
						MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
					}
				}
				//当前选中的棋子是友方的棋子（暂无友方，暂不实现）
				else if (MyPlayerController->IsFriend(MyPawn, CurSelectedPawn))
				{

				}
				//当前选中的棋子是敌方的棋子
				else if (MyPlayerController->IsEnemy(MyPawn, CurSelectedPawn))
				{
					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
				else
				{
				}
			}
			else
			{
				//当前选中的棋子是敌方的 或其他情况

				//判断当前选中的棋子是否自己
				if (MyPawn == CurSelectedPawn)
				{
					//自己就是当前选中的棋子

					//则取消选中自己
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();
				}
				else
				{
					//自己不是当前选中的棋子

					//取消已经选中的棋子
					MyPlayerController->CancelCurSelectedPawnInClient();

					//取消选中地形格子
					MyPlayerController->CancelCurSelectedTileInClient();

					//自己变成选中的棋子
					MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

					//把棋子所在格子变成选中的格子
					MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
				}
			}
		}
		else
		{
			//当前还没有选中棋子

			//取消选中地形格子
			MyPlayerController->CancelCurSelectedTileInClient();

			//则直接选中了这个棋子
			MyPlayerController->SetCurSelectedPawnInClient(MyPawn);

			//把棋子所在格子变成选中的格子
			MyPlayerController->SetCurSelectedTileInClient(MyPawnMapTile);
		}
	}
}