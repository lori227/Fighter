#include "CWPawnInstructs.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWPawnInstructs, All, All);

FCWPawnInstructs::FCWPawnInstructs()
{
	Reset();
}

FCWPawnInstructs::FCWPawnInstructs(const FCWPawnInstructs& r)
{
	*this = r;
}


FCWPawnInstructs& FCWPawnInstructs::operator = (const FCWPawnInstructs& r)
{
	if (this == &r)
		return *this;

	Instructs = r.Instructs;
	bIsOriginal = r.bIsOriginal;
	SourcePawnCampTag = r.SourcePawnCampTag;
	SourcePawnCampControllerIndex = r.SourcePawnCampControllerIndex;
	SourcePawnControllerPawnIndex = r.SourcePawnControllerPawnIndex;
	SourceSkillId = r.SourceBuffId;
	SourceBuffId = r.SourceBuffId;
	SourceBuffUniqueId = r.SourceBuffUniqueId;
	SourceAffectorId = r.SourceAffectorId;

	return *this;
}

void FCWPawnInstructs::Reset()
{
	Instructs = 0xff;
	bIsOriginal = true;
	SourcePawnCampTag = 0;
	SourcePawnCampControllerIndex = 0;
	SourcePawnControllerPawnIndex = 0;
	SourceSkillId = 0;
	SourceBuffId = 0;
	SourceBuffUniqueId = 0;
	SourceAffectorId = 0;
}

