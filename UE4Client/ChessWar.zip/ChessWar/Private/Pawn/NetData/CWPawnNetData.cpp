﻿#include "CWPawnNetData.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWPawnDataStruct.h"
#include "CWCastSkillContext.h"


FCWPawnNetData::FCWPawnNetData()
{
	Reset();
}

FCWPawnNetData::FCWPawnNetData(const FCWPawnNetData& r)
{
	*this = r;
}

FCWPawnNetData& FCWPawnNetData::operator = (const FCWPawnNetData& r)
{
	if (this == &r)
		return *this;

	this->Rand = r.Rand;
	this->UUID = r.UUID;
	this->Race = r.Race;
	this->Profession = r.Profession;
	this->Name = r.Name;
	this->Sex = r.Sex;
	this->Identity = r.Identity;
	this->Birthday = r.Birthday;
	this->Age = r.Age;
	this->Quality = r.Quality;
	this->Level = r.Level;
	this->Weapon = r.Weapon;
	this->ActiveSkillId = r.ActiveSkillId;
	this->PassivitySkillId = r.PassivitySkillId;
	this->InnateSkillId = r.InnateSkillId;
	this->Str = r.Str;
	this->Dex = r.Dex;
	this->Con = r.Con;
	this->Int = r.Int;
	return *this;
}

bool operator == (const FCWPawnNetData& l, const FCWPawnNetData& r)
{
	if (l.Rand == r.Rand &&
		l.UUID == r.UUID &&
		l.Race == r.Race &&
		l.Profession == r.Profession &&
		l.Name == r.Name &&
		l.Sex == r.Sex &&
		l.Identity == r.Identity &&
		l.Birthday == r.Birthday &&
		l.Age == r.Age &&
		l.Quality == r.Quality &&
		l.Level == r.Level &&
		l.Weapon == r.Weapon &&
		l.Str == r.Str &&
		l.Dex == r.Dex &&
		l.Con == r.Con &&
		l.Int == r.Int)
	{

		if (l.ActiveSkillId.Num() == r.ActiveSkillId.Num())
		{
			for (int i = 0; i < l.ActiveSkillId.Num(); ++i)
			{
				if (l.ActiveSkillId[i] != r.ActiveSkillId[i])
					return false;
			}
		}
		else
		{
			return false;
		}

		if (l.PassivitySkillId.Num() == r.PassivitySkillId.Num())
		{
			for (int i = 0; i < l.PassivitySkillId.Num(); ++i)
			{
				if (l.PassivitySkillId[i] != r.PassivitySkillId[i])
					return false;
			}
		}
		else
		{
			return false;
		}

		if (l.InnateSkillId.Num() == r.InnateSkillId.Num())
		{
			for (int i = 0; i < l.InnateSkillId.Num(); ++i)
			{
				if (l.PassivitySkillId[i] != r.PassivitySkillId[i])
					return false;
			}
		}
		else
		{
			return false;
		}
	
		return true;
	}
	else
	{
		return false;
	}
}

void FCWPawnNetData::Reset()
{
	Rand = 0;
	UUID = "";
	Race = 0;
	Profession = 0;
	Name = "";
	Sex = 0;
	Identity = 0;
	Birthday = "";
	Age = 0;
	Quality = 0;
	Level = 0;
	Weapon = 0;
	ActiveSkillId.Empty();
	PassivitySkillId.Empty();
	InnateSkillId.Empty();
	Str = 0;
	Dex = 0;
	Con = 0;
	Int = 0;
}

FString FCWPawnNetData::ToDebugString() const
{
	FString ActiveSkillIds = TEXT("");
	for (int32 Elem : ActiveSkillId)
	{
		ActiveSkillIds += INT_TO_FSTRING(Elem) + TEXT("|");
	}

	FString PassivitySkillIds = TEXT("");
	for (int32 Elem : PassivitySkillId)
	{
		PassivitySkillIds += INT_TO_FSTRING(Elem) + TEXT("|");
	}

	FString InnateSkillIds = TEXT("");
	for (int32 Elem : InnateSkillId)
	{
		PassivitySkillIds += INT_TO_FSTRING(Elem) + TEXT("|");
	}
	return FString::Printf(TEXT("Race[%d] Profession[%d] Weapon[%d] Str[%d] Dex[%d] Con[%d] Int[%d] ActiveSkillIds[%s] PassivitySkillIds[%s] InnateSkillIds[%s]"), 
		Race, Profession, Weapon, Str, Dex, Con, Int, *ActiveSkillIds, *PassivitySkillIds, *InnateSkillIds);
}

float FCWPawnNetData::GetNetDataPropertyByPropertyId(int32 ParamPropertyId)
{
	switch (ParamPropertyId)
	{
	case 1:
		return (float)Str;
		break;
	case 2:
		return (float)Dex;
		break;
	case 3:
		return (float)Int;
		break;
	case 4:
		return (float)Con;
		break;
	}
	
	return 1.0f;
}