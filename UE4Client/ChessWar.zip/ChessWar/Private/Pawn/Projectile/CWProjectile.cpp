﻿
#include "CWProjectile.h"
#include "Particles/ParticleSystemComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCastSkillContext.h"
#include "CWGameMode.h"
#include "CWBattleCalculate.h"
#include "CWSkillManager.h"
#include "CWSkill.h"
#include "CWBattleCalculate.h"
#include "CWPawnBattlePropertyComponent.h"
#include "CWPlayerController.h"
#include "CWAudioVideoMgr.h"
#include "CWDungeonItemVisibility.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWProjectile, All, All);

ACWProjectile::ACWProjectile(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MoveSpeed(1.0f)
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(FName("Root"));

	StaticMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(FName("StaticMeshComponent"));
	StaticMeshComponent->SetupAttachment(RootComponent);
	StaticMeshComponent->SetNotifyRigidBodyCollision(false);
	StaticMeshComponent->SetVisibility(true);
	StaticMeshComponent->SetEnableGravity(false);
	//StaticMeshComponent->BodyInstance.SetCollisionProfileName("Projectile");

	//SphereComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	//SphereComponent->SetupAttachment(RootComponent);
	//SphereComponent->SetEnableGravity(false);
	//SphereComponent->SetCollisionProfileName(TEXT("OverlapAll"));
	
	ProjectileMovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>(FName("ProjectileMovement"));
	//ProjectileMovementComponent->bAutoActivate = false;
	ProjectileMovementComponent->UpdatedComponent = RootComponent;
	ProjectileMovementComponent->InitialSpeed = MoveSpeed;
	//ProjectileMovementComponent->MaxSpeed = MoveSpeed;
	ProjectileMovementComponent->bRotationFollowsVelocity = true;
	ProjectileMovementComponent->bShouldBounce = false;
	ProjectileMovementComponent->ProjectileGravityScale = 0.0f; 
									
	InitialLifeSpan = 10.0f;
}

void ACWProjectile::BeginPlay()
{
	Super::BeginPlay();

	//UpdateSpeed();
	//SphereComponent->OnComponentHit.AddDynamic(this, &ACWProjectile::OnHit);
}

bool ACWProjectile::IsInServer() const
{
	return GetNetMode() <= NM_ListenServer;
}

void ACWProjectile::OnRep_MoveSpeed()
{
	UpdateSpeed();
}

void ACWProjectile::UpdateSpeed()
{
	//CWG_LOG(">> [%s] [%s.UpdateSpeed], MoveSpeed[%d] .", *NETMODE_TO_STRING(GetNetMode()), *GetName(), MoveSpeed);
	float InCurSpeed = MoveSpeed;
	ProjectileMovementComponent->InitialSpeed = InCurSpeed;
	//ProjectileMovementComponent->MaxSpeed = InCurSpeed;

	FVector& MoveVelocity = ProjectileMovementComponent->Velocity;
	MoveVelocity = MoveVelocity.GetSafeNormal() * InCurSpeed;

	ProjectileMovementComponent->UpdateComponentVelocity();
}

void ACWProjectile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ACWProjectile::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ACWProjectile, MoveSpeed);
}

bool ACWProjectile::Init(TSharedPtr<UCWCastSkillContext> ParamCastSkillContext)
{
	check(ParamCastSkillContext);
	CastSkillContextPtr = ParamCastSkillContext;

	SetMoveSpeed(ParamCastSkillContext->CastSkillDataStruct->ProjectileInitialSpeed);

	for (TArray<TWeakObjectPtr<ACWPawn>>::TIterator iter = ArrayHitPawns.CreateIterator(); iter; ++iter)
	{
		TWeakObjectPtr<ACWPawn> PawnPtr = *iter;
		if (PawnPtr.IsValid())
		{
			HitTarget(PawnPtr.Get());
		}
	}
	ArrayHitPawns.Empty();

	return true;
}

void ACWProjectile::SetMoveSpeed(const float InSpeed)
{
	MoveSpeed = InSpeed;
	UpdateSpeed();
}

void ACWProjectile::Destroyed()
{
	Super::Destroyed();
}

void ACWProjectile::NotifyActorBeginOverlap(AActor* OtherActor)
{
	Super::NotifyActorBeginOverlap(OtherActor);

	UE_LOG(LogCWProjectile, Log, TEXT("ACWProjectile::NotifyActorBeginOverlap Begin, %s."), *(OtherActor->GetName()));

	const bool bServer = IsInServer();
	const AActor* TOwner = GetOwner();
	

	ACWPawn* HitPawn = Cast<ACWPawn>(OtherActor);
	if (HitPawn == nullptr)
	{
		ACWDungeonItemVisibility* TempDungeonItemVisibility = Cast<ACWDungeonItemVisibility>(OtherActor);
		if (TempDungeonItemVisibility != nullptr)
		{
			HitPawn = Cast<ACWPawn>(TempDungeonItemVisibility->GetOwner());
		}
	}

	if (bServer && nullptr != HitPawn && HitPawn->IsAllowOperate() && OtherActor != this && OtherActor != TOwner)
	{
		CWG_LOG(">> [%s] %s::NotifyActorBeginOverlap, HitPawn[%s].", *NETMODE_TO_STRING(GetNetMode()), *GetName(), *HitPawn->GetDisplayName());

		if (!CastSkillContextPtr.IsValid())
		{
			ArrayHitPawns.AddUnique(HitPawn);
			UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::NotifyActorBeginOverlap Fail, !CastSkillContextPtr.IsValid(), %s."), *HitPawn->GetDisplayName());
			return;
		}

		HitTarget(HitPawn);
	}
}

/*
void ACWProjectile::ComputeMovement(float DeltaTime, FVector& OutMoveDelta, FQuat& OutNewRotation)
{
	Super::ComputeMovement(DeltaTime, OutMoveDelta, OutNewRotation);
}*/

void ACWProjectile::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if ((OtherActor != nullptr) && (OtherActor != this) && (OtherComp != nullptr) && OtherComp->IsSimulatingPhysics())
	{
		//OtherComp->AddImpulseAtLocation(GetVelocity() * 20.0f, GetActorLocation());
	}

	//Destroy();
}

void ACWProjectile::HitTarget(ACWPawn* TargetPawn)
{
	if (CastSkillContextPtr->CastSkillDataStruct->IsAOE == 1)
	{
		if (CastSkillContextPtr->PlayerControllerWeakPtr.IsValid())
		{
			if (!CastSkillContextPtr->PlayerControllerWeakPtr->IsEnemy(TargetPawn))
			{
				UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::HitTarget Fail, !IsEnemy, %s."), *(TargetPawn->GetDisplayName()));
				return;
			}

			bool TempIsFind = false;
			for (TArray<int32>::TIterator Iter = CastSkillContextPtr->ArrayDamageTile.CreateIterator(); Iter; ++Iter)
			{
				int32 TempTile = *Iter;
				if (TargetPawn->GetTile() == TempTile)
				{
					TempIsFind = true;
				}
			}

			if (!TempIsFind)
			{
				UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::HitTarget Fail, ArrayDamageTile not inTile, %s."), *(TargetPawn->GetDisplayName()));
				return;
			}
		}
		else
		{
			UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::HitTarget Fail, PlayerControllerWeakPtr is not valid 1, %s."), *(TargetPawn->GetDisplayName()));
			return;
		}
	}
	else
	{
		if (CastSkillContextPtr->ProjectileTargetPawnWeakPtr.IsValid())
		{
			if (CastSkillContextPtr->ProjectileTargetPawnWeakPtr != TargetPawn)
			{
				UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::HitTarget Fail, CastSkillContextPtr->ProjectileTargetPawnWeakPtr != TargetPawn, %s, %s."), *CastSkillContextPtr->ProjectileTargetPawnWeakPtr->GetDisplayName(), *(TargetPawn->GetDisplayName()));
				return;
			}
		}
		else
		{
			UE_LOG(LogCWProjectile, Warning, TEXT("ACWProjectile::HitTarget Fail, PlayerControllerWeakPtr is not valid 2, %s."), *(TargetPawn->GetDisplayName()));
			return;
		}
	}

	for (TArray<TWeakObjectPtr<ACWPawn>>::TIterator iter = ArrayPawns.CreateIterator(); iter; ++iter)
	{
		TWeakObjectPtr<ACWPawn> PawnPtr = *iter;
		if (PawnPtr.IsValid())
		{
			if (PawnPtr.Get() == TargetPawn)
			{
				UE_LOG(LogCWProjectile, Error, TEXT("ACWProjectile::HitTarget Fail, ArrayPawns has TargetPawn, %s."), *(TargetPawn->GetDisplayName()));
				return;
			}
		}
	}

	ArrayPawns.AddUnique(TargetPawn);
	UE_LOG(LogCWProjectile, Log, TEXT("ACWProjectile::HitTarget Success, TargetPawn, %s."), *(TargetPawn->GetDisplayName()));

	UCWPawnBattlePropertyComponent* TargetPawnBattlePropertComponent = TargetPawn->GetBattleProperty();
	check(TargetPawnBattlePropertComponent);
	//------------------------------------------------------------------------
	//技能产生伤害
	if (CastSkillContextPtr->CastSkillDataStruct->DamageCount > 0)
	{
		int TempDamageIndexWhenCastSkill = 0;
		if (CastSkillContextPtr->PawnWeakPtr.IsValid())
		{
			TempDamageIndexWhenCastSkill = CastSkillContextPtr->PawnWeakPtr->GetDamageIndexWhenCastSkill();
		}

		//------------------------------------------------------------------------
		UCWBattleCalculate::Get()->CalculateDamageBySkill(CastSkillContextPtr, TargetPawn, TempDamageIndexWhenCastSkill++);
		TargetPawn->BeHitInServer(
			CastSkillContextPtr->PawnCampTag,
			CastSkillContextPtr->PawnCampControllerIndex,
			CastSkillContextPtr->PawnControllerPawnIndex,
			CastSkillContextPtr->CastSkillDataStruct->SkillId,
			CastSkillContextPtr->bIsCounterAttack);

		//目标当前血量 血量检测
		if (IsValid(TargetPawn))
		{
			float TempCurTargetHealth = TargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
			if (TempCurTargetHealth <= 0.0f)
			{
				TargetPawn->DieInServer();
			}
		}
		//------------------------------------------------------------------------

		if (CastSkillContextPtr->PawnWeakPtr.IsValid())
		{
			CastSkillContextPtr->PawnWeakPtr->SetDamageIndexWhenCastSkill(TempDamageIndexWhenCastSkill);
		}
	}
	//------------------------------------------------------------------------
	if (CastSkillContextPtr->PawnWeakPtr.IsValid())
	{
		//------------------------------------------------------------------------
		//获得当前的释放技能
		UCWSkill* TempSkill = nullptr;
		int SkillIdWhenCastSkill = CastSkillContextPtr->PawnWeakPtr->GetSkillIdWhenCastSkill();
		if (SkillIdWhenCastSkill == -1)
		{
			TempSkill = CastSkillContextPtr->PawnWeakPtr->GetSkillManager()->GetNormalAttack();
		}
		else
		{
			TempSkill = CastSkillContextPtr->PawnWeakPtr->GetSkillManager()->GetSkill(SkillIdWhenCastSkill);
		}
		if (TempSkill == nullptr)
		{
			UE_LOG(LogCWProjectile, Error, TEXT("ACWProjectile::HitTarget Fail, TempSkill == nullptr, SkillIdWhenCastSkill:%d."), SkillIdWhenCastSkill);
			return;
		}
		//------------------------------------------------------------------------
		//计算关键时间点
		ECWKeyTimeType TempKeyTimeType = ECWKeyTimeType::None;
		if (CastSkillContextPtr->PawnWeakPtr->GetDamageIndexWhenCastSkill() == 1 || CastSkillContextPtr->PawnWeakPtr->GetDamageIndexWhenCastSkill() == 0)
		{
			TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage01 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage01 : ECWKeyTimeType::InitiativeSkillDamage01;
		}
		else if (CastSkillContextPtr->PawnWeakPtr->GetDamageIndexWhenCastSkill() == 2)
		{
			TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage02 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage02 : ECWKeyTimeType::InitiativeSkillDamage02;
		}
		else if (CastSkillContextPtr->PawnWeakPtr->GetDamageIndexWhenCastSkill() == 3)
		{
			TempKeyTimeType = TempSkill->IsNormalAttack() ? ECWKeyTimeType::NormalAttackDamage03 : TempSkill->IsPassivitySkill() ? ECWKeyTimeType::PassivitySkillDamage03 : ECWKeyTimeType::InitiativeSkillDamage03;
		}
		//------------------------------------------------------------------------
		//关键时间点触发 产生伤害
		CastSkillContextPtr->PawnWeakPtr->OnKeyTimeInServer(TempKeyTimeType);
		//------------------------------------------------------------------------
		//技能产生Buff
		//if (!TempSkill->IsNormalAttack())
		{
			if (CastSkillContextPtr->PawnWeakPtr->GenerateBuffByCastSkillContext(CastSkillContextPtr, TargetPawn, TargetPawnBattlePropertComponent, TempSkill, TempKeyTimeType))
			{
				TempSkill->IncreaseTriggerBuffCountForRound();
			}
			else
			{
				//UE_LOG(LogCWProjectile, Error, TEXT("ACWProjectile::HitTarget InServer, GenerateBuffByCastSkillContext fail."));
			}
		}
	}
	//------------------------------------------------------------------------
	//目标当前血量 血量检测
	if (IsValid(TargetPawn))
	{
		float CurTargetHealth = TargetPawnBattlePropertComponent->GetCurPropertySet().GetPropertyByFloat(ECWBattleProperty::Health);
		if (CurTargetHealth <= 0.0f)
		{
			TargetPawn->DieInServer();
		}
	}
	//------------------------------------------------------------------------

	HitTargetCount++;
	NetMulticastOnHitTarget(TargetPawn);

	if (HitTargetCount >= CastSkillContextPtr->CastSkillDataStruct->TargetMax)
		this->Destroy();
}

void ACWProjectile::NetMulticastOnHitTarget_Implementation(AActor* HitTarget)
{
	if (IsInServer())
	{
		return;
	}

	if (UCWAudioVideoMgr* AVMgr = AV_MGR(this))
	{
		AVMgr->PlayAudioByCfg(this, TEXT("Tw_NormalAttack01_hit"));
	}
}
