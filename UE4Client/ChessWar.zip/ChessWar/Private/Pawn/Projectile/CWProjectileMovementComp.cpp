﻿
#include "CWProjectileMovementComp.h"


UCWProjectileMovementComp::UCWProjectileMovementComp(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCWProjectileMovementComp::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

/*
void UCWProjectileMovementComp::ComputeMovement(float DeltaTime, FVector& OutMoveDelta, FQuat& OutNewRotation)
{
	Super::ComputeMovement(DeltaTime, OutMoveDelta, OutNewRotation);
}*/
