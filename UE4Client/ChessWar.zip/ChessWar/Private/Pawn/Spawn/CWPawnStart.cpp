
#include "CWPawnStart.h"

#include "CWMap.h"
#include "CWMapTile.h"
#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWMapTileRender.h"
#include "CWPlayerController.h"


ACWPawnStart::ACWPawnStart(const FObjectInitializer& ObjectInitializer)
:Super(ObjectInitializer)
{
	bReplicates = true;
	PrimaryActorTick.bCanEverTick = false;
	PrimaryActorTick.bStartWithTickEnabled = false;

	SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
}

void ACWPawnStart::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME_CONDITION(ACWPawnStart, CampTag, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, CampControllerIndex, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, PawnIndex, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, PawnId, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, Tile, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, X, COND_InitialOnly);
	DOREPLIFETIME_CONDITION(ACWPawnStart, Y, COND_InitialOnly);
}

void ACWPawnStart::BeginPlay()
{
	Super::BeginPlay();

	/*if (!IsNetMode(NM_DedicatedServer))
	{
		UCWEventMgr* EvtMgr = EVT_MGR(this);
		if (nullptr != EvtMgr && IsLocalPCPawnStart())
		{
			ADD_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this, &ACWPawnStart::OnBattleStateChangeInClient, TEXT("OnBattleStateChange"));
		}
	}*/
}

void ACWPawnStart::Destroyed()
{
	Super::Destroyed();

	/*if (!IsNetMode(NM_DedicatedServer))
	{
		UCWEventMgr* EvtMgr = EVT_MGR(this);
		if (nullptr != EvtMgr && IsLocalPCPawnStart())
		{
			REMOVE_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this);
		}
	}*/
}

bool ACWPawnStart::IsLocalPCPawnStart() const
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		return CampTag == LocalPC->GetCampTag() && CampControllerIndex == LocalPC->GetCampControllerIndex();
	}
	return false;
}

bool ACWPawnStart::IsSameCampAndCtrl(ECWCampTag InCamp, ECWCampControllerIndex InCtrlIndex) const
{
	return InCamp == CampTag && InCtrlIndex == CampControllerIndex;
}

void ACWPawnStart::ShowTileRender(const ECWTileRenderType InRenderType)
{
	ACWMap* const MyMapActor = GetMapActor();
	ACWMapTile* MapTile = MyMapActor ? MyMapActor->GetTile(Tile) : nullptr;
	if (nullptr != MapTile)
	{
		if (InRenderType != ECWTileRenderType::None)
		{
			RenderObjPtr = MapTile->ShowHintTile(InRenderType, nullptr);
		}else if (RenderObjPtr.IsValid())
		{
			MapTile->HideHintTile(RenderObjPtr.Get(), nullptr);
			RenderObjPtr->Reset();
		}
	}
}

int32 ACWPawnStart::GetTile() const
{
	return Tile;
}

ACWMap* ACWPawnStart::GetMapActor()
{
	return UCWFuncLib::GetActor<ACWMap>(this);
}

ACWPlayerController* ACWPawnStart::GetLocalPC() const
{
	APlayerController* FirstPC = GetWorld()->GetFirstPlayerController();
	ACWPlayerController* LocalPC = Cast<ACWPlayerController>(FirstPC);
	return LocalPC;
}

void ACWPawnStart::OnBattleStateChangeInClient(const ECWBattleState InOldState, const ECWBattleState InCurState)
{
	switch (InCurState)
	{
	case ECWBattleState::Ready:
	{
		ShowTileRender();
	}break;
	case ECWBattleState::Fighting:
	{
		ShowTileRender(ECWTileRenderType::None);
	}break;
	}
}

