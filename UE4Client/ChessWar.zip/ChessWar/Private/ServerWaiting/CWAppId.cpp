
#include "CWAppId.h"

union AppIdData
{
	uint64 _id;
	struct AppData
	{
		uint16 _server_type;
		uint16 _zone_id;
		uint32 _worker_id;
	} _app_data;
};

CWAppId::CWAppId()
{
	_data = new AppIdData();
	_data->_id = 0;
	_str_app_id = "0.0.0.0";
}

CWAppId::CWAppId(uint64 appid)
{
	_data = new AppIdData();
	FromUInt64(appid);
}

CWAppId::CWAppId(const std::string& strappid)
{
	_data = new AppIdData();
	FromString(strappid);
}

CWAppId::CWAppId(const CWAppId& appid)
{
	_data = new AppIdData();

	_data->_id = appid._data->_id;
	_str_app_id = appid._str_app_id;
}

CWAppId& CWAppId::operator=(const CWAppId& appid)
{
	if (_data == nullptr)
	{
		_data = new AppIdData();
	}

	_data->_id = appid._data->_id;
	_str_app_id = appid._str_app_id;

	return *this;
}

CWAppId::~CWAppId()
{
	delete _data;
}

void CWAppId::FromUInt64(uint64 appid)
{
	_data->_id = appid;
	_str_app_id = printf("%d.%d.%d", _data->_app_data._server_type, _data->_app_data._zone_id, _data->_app_data._worker_id);
}

void CWAppId::FromString(std::string strappid)
{
	_str_app_id = strappid;
	_data->_app_data._server_type = atoi(SplitString(strappid, ".").c_str());
	_data->_app_data._zone_id = atoi(SplitString(strappid, ".").c_str());
	_data->_app_data._worker_id = atoi(SplitString(strappid, ".").c_str());
}


uint32 CWAppId::GetType() const
{
	return _data->_app_data._server_type;
}

void CWAppId::SetType(uint32 value)
{
	_data->_app_data._server_type = static_cast<uint16>(value);
	FromUInt64(_data->_id);
}

uint32 CWAppId::GetZoneId() const
{
	return _data->_app_data._zone_id;
}

void CWAppId::SetZoneId(uint32 value)
{
	_data->_app_data._zone_id = static_cast<uint16>(value);
	FromUInt64(_data->_id);
}


uint32 CWAppId::GetWorkId() const
{
	return _data->_app_data._worker_id;
}

void CWAppId::SetWorkId(uint32 value)
{
	_data->_app_data._worker_id = value;
	FromUInt64(_data->_id);
}

uint64 CWAppId::GetId() const
{
	return _data->_id;
}

const std::string& CWAppId::ToString() const
{
	return _str_app_id;
}


const std::string& CWAppId::ToString(uint64 appid)
{
	static CWAppId _app_id;
	_app_id.FromUInt64(appid);

	return _app_id.ToString();
}

uint64 CWAppId::ToUInt64(const std::string& strappid)
{
	static CWAppId _app_id;
	_app_id.FromString(strappid);
	return _app_id.GetId();
}

std::string CWAppId::SplitString(std::string& srcstring, std::string split)
{
	if (srcstring.empty())
	{
		return "";
	}

	std::string result = "";
	auto pos = srcstring.find(split);
	if (pos == std::string::npos)
	{
		result = srcstring;
		srcstring.clear();
		return result;
	}

	result = srcstring.substr(0, pos);
	srcstring = srcstring.substr(pos + split.size());
	return result;
}


