#include "CWNetHeroData.h"


UCWNetHeroData::UCWNetHeroData(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

