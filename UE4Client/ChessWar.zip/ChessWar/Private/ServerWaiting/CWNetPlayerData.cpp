﻿
#include "CWNetPlayerData.h"

#include "CWUtils.h"
#include "CWPawnNetData.h"


DECLARE_LOG_CATEGORY_CLASS(LogCWNetPlayerData, All, All);

UCWNetPlayerData::UCWNetPlayerData(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

UCWNetHeroData* UCWNetPlayerData::GetNetHeroData(uint64 ParamUUID)
{
	if (MapNetHeroData.Contains(ParamUUID))
	{
		UCWNetHeroData* TempNetHeroData = MapNetHeroData[ParamUUID];
		return TempNetHeroData;
	}

	return nullptr;
}

UCWNetHeroData* UCWNetPlayerData::GetNetHeroDataByIndex(int32 ParamIndex)
{
	int32 TempIndex = 0;
	for (TMap<uint64, UCWNetHeroData*>::TIterator iter = MapNetHeroData.CreateIterator(); iter; ++iter)
	{
		if (TempIndex == ParamIndex)
		{
			return iter->Value;
		}

		TempIndex++;
	}

	return nullptr;
}


TArray<FCWPawnNetData> UCWNetPlayerData::GetExtraNetHeroData(int32 InMinIndex)
{
	int32 TempIndex = 0;
	TArray<FCWPawnNetData> RetValue;
	TMap<uint64, UCWNetHeroData*>::TIterator Iter = MapNetHeroData.CreateIterator();
	for (; Iter; ++Iter)
	{
		if (TempIndex >= InMinIndex)
		{
			const FString NewNetId = FCWUtils::Uint642FString(Iter->Key);
			const UCWNetHeroData* NetHeroData = Iter->Value;
			const int32 NewProfession = NetHeroData ? NetHeroData->Profession : INDEX_NONE;
			if (!NewNetId.IsEmpty() && NewProfession > 0)
			{
				FCWPawnNetData NewPawnNetData = FCWPawnNetData();
				NewPawnNetData.UUID = NewNetId;
				NewPawnNetData.Race = (int32)NetHeroData->Race;
				NewPawnNetData.Profession = NewProfession;
				NewPawnNetData.Name = NetHeroData->Name;
				NewPawnNetData.Sex = (int32)NetHeroData->Sex;
				NewPawnNetData.Identity = (int32)NetHeroData->Identity;
				//NewPawnNetData.Birthday = (int32)NetHeroData->Birthday;
				NewPawnNetData.Age = (int32)NetHeroData->Age;
				NewPawnNetData.Quality = (int32)NetHeroData->Quality;
				NewPawnNetData.Level = (int32)NetHeroData->Level;
				NewPawnNetData.Weapon = (int32)NetHeroData->Weapon;
				NewPawnNetData.ActiveSkillId = NetHeroData->ActiveSkillId;
				NewPawnNetData.PassivitySkillId = NetHeroData->PassivitySkillId;
				NewPawnNetData.InnateSkillId = NetHeroData->InnateSkillId;
				NewPawnNetData.Str = (int32)NetHeroData->Str;
				NewPawnNetData.Dex = (int32)NetHeroData->Dex;
				NewPawnNetData.Con = (int32)NetHeroData->Con;
				NewPawnNetData.Int = (int32)NetHeroData->Int;

				RetValue.Add(NewPawnNetData);
			}
		}
		++TempIndex;
	}

	return RetValue;
}

bool UCWNetPlayerData::AddNetHeroData(uint64 ParamUUID, UCWNetHeroData* ParamNetHeroData)
{
	if (ParamUUID == 0)
	{
		UE_LOG(LogCWNetPlayerData, Error, TEXT("UCWNetPlayerData::AddNetHeroData..., ParamUUID:%d."), ParamUUID);
		return false;
	}

	if (MapNetHeroData.Contains(ParamUUID))
	{
		return false;
	}

	check(ParamNetHeroData);
	MapNetHeroData.Add(ParamUUID, ParamNetHeroData);
	return true;
}

void UCWNetPlayerData::RemoveAllNetHeroData()
{
	for (TMap<uint64, UCWNetHeroData*>::TIterator iter = MapNetHeroData.CreateIterator(); iter; ++iter)
	{
		UCWNetHeroData* TempNetHeroData = iter->Value;
		check(TempNetHeroData);
		TempNetHeroData->ConditionalBeginDestroy();
		TempNetHeroData = nullptr;
	}

	MapNetHeroData.Empty();
}