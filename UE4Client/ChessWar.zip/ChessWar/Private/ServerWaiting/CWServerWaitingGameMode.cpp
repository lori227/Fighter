#include "CWServerWaitingGameMode.h"

#include "Engine/World.h"
#include "CWGameInstance.h"
#include "CWTCPServerClient.h"
#include "CWServerWaitingFSM.h"
#include "CWFSMTranstion.h"
#include "CWServerWaitingConnectState.h"
#include "CWServerWaitingUsingState.h"
#include "CWServerWaitingWaitingState.h"
#include "CWServerWaitingClusterAuthState.h"
#include "CWServerWaitingClusterVerifyState.h"
#include "CWServerWaitingToConnectEvent.h"
#include "CWServerWaitingRegisterToRoomState.h"
#include "CWEventMgr.h"
#include "CWCommandMgr.h"
#include "CWUtils.h"
#include "CWServerWaitingToRegisterToRoomEvent.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingGameMode, All, All);

ACWServerWaitingGameMode* ACWServerWaitingGameMode::s_this = nullptr;

ACWServerWaitingGameMode::ACWServerWaitingGameMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	s_this = this;

	PrimaryActorTick.bCanEverTick = true;

	ServerWaitingFSM = nullptr;
}

void ACWServerWaitingGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	UCWGameInstance::GetInstance()->GetTCPServerClient()->SetReceiveMessageCallbackFn(&ACWServerWaitingGameMode::ProcessReceiveMessage);

	SetupServerWaitingFSM();

	UCWEventMgr::OnLevelLoadComplete.AddUObject(this, &ACWServerWaitingGameMode::OnLevelLoadComplete);

	UCWGameInstance::GetInstance()->SetRoomId(0);
	UCWGameInstance::GetInstance()->SetRoomServerId(0);
	UCWGameInstance::GetInstance()->SetMatchId(0);

	//check(ServerWaitingFSM != nullptr);
	//ServerWaitingFSM->Startup((int)ECWServerWaitingState::Connect);

	//FCWServerWaitingToConnectEvent* toConnectEvent = new FCWServerWaitingToConnectEvent((int)ECWServerWaitingEvent::ToConnect, (int)ECWServerWaitingState::Connect, ECWFSMStackOp::Set, "192.168.1.155", 10001);
	//ServerWaitingFSM->DoEvent(toConnectEvent);
}

void ACWServerWaitingGameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
}

void ACWServerWaitingGameMode::Destroyed()
{
	if (UCWGameInstance::GetInstance() != nullptr && UCWGameInstance::GetInstance()->GetTCPServerClient() != nullptr)
	{
		UCWGameInstance::GetInstance()->GetTCPServerClient()->SetReceiveMessageCallbackFn(nullptr);
	}

	Super::Destroyed();
}

void ACWServerWaitingGameMode::SetupServerWaitingFSM()
{
	if (ServerWaitingFSM == nullptr)
	{
		ServerWaitingFSM = NewObject<UCWServerWaitingFSM>();
		check(ServerWaitingFSM != nullptr);
		ServerWaitingFSM->Init(this);
		ServerWaitingFSM->AddState(new FCWServerWaitingConnectState(ServerWaitingFSM, (int)ECWServerWaitingState::Connect));
		ServerWaitingFSM->AddState(new FCWServerWaitingClusterAuthState(ServerWaitingFSM, (int)ECWServerWaitingState::ClusterAuth));
		ServerWaitingFSM->AddState(new FCWServerWaitingClusterVerifyState(ServerWaitingFSM, (int)ECWServerWaitingState::ClusterVerify));
		ServerWaitingFSM->AddState(new FCWServerWaitingRegisterToRoomState(ServerWaitingFSM, (int)ECWServerWaitingState::RegisterToRoom));
		ServerWaitingFSM->AddState(new FCWServerWaitingWaitingState(ServerWaitingFSM, (int)ECWServerWaitingState::Waiting));
		ServerWaitingFSM->AddState(new FCWServerWaitingUsingState(ServerWaitingFSM, (int)ECWServerWaitingState::Using));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Connect, (int)ECWServerWaitingState::ClusterAuth));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Connect, (int)ECWServerWaitingState::ClusterVerify));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::ClusterAuth, (int)ECWServerWaitingState::Connect));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::ClusterVerify, (int)ECWServerWaitingState::RegisterToRoom));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::ClusterVerify, (int)ECWServerWaitingState::Connect));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::RegisterToRoom, (int)ECWServerWaitingState::Waiting));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::RegisterToRoom, (int)ECWServerWaitingState::Connect));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Waiting, (int)ECWServerWaitingState::Using));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Waiting, (int)ECWServerWaitingState::Connect));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Using, (int)ECWServerWaitingState::Waiting));
		ServerWaitingFSM->AddTranstion(new FCWFSMTranstion((int)ECWServerWaitingState::Using, (int)ECWServerWaitingState::Connect));
	}
}

void ACWServerWaitingGameMode::SetToken(const std::string& ParamToken)
{
	token = ParamToken;
}

const std::string& ACWServerWaitingGameMode::GetToken() const
{
	return token;
}

bool ACWServerWaitingGameMode::ProcessReceiveMessage(UCWNetMessage* ParamNetMsg)
{
	check(s_this);
	check(s_this->ServerWaitingFSM);
	s_this->ServerWaitingFSM->DoNetMessage(ParamNetMsg);
	return true;
}

void ACWServerWaitingGameMode::OnLevelLoadComplete(const float LoadTime, const FString& MapName)
{
	UE_LOG(LogCWServerWaitingGameMode, Log, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., MapName:%s."), *MapName);
	ENetMode NetMode = UCWGameInstance::GetInstance()->GetWorld()->GetNetMode();
	UE_LOG(LogCWServerWaitingGameMode, Log, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., NetMode:%d."), (int32)NetMode);
	if (NetMode == NM_DedicatedServer)
	{
		if (MapName.Contains(TEXT("ServerWaiting")))
		{
			ESocketConnectionState TempSocketConnectionState = UCWGameInstance::GetInstance()->GetTCPServerClient()->GetConnectionState();
			UE_LOG(LogCWServerWaitingGameMode, Log, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., TempSocketConnectionState:%d."), (int32)TempSocketConnectionState);
			if (UCWGameInstance::GetInstance()->GetTCPServerClient()->GetConnectionState() != ESocketConnectionState::SCS_Connected)
			{
				UE_LOG(LogCWServerWaitingGameMode, Log, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., ServerWaitingFSM->Startup((int)ECWServerWaitingState::Connect)"));
				ServerWaitingFSM->Startup((int)ECWServerWaitingState::Connect);

				FString TempGatewayIp = CWCommandMgr::GetGateWayIp();
				if (TempGatewayIp == "")
				{
					UE_LOG(LogCWServerWaitingGameMode, Error, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete, TempGatewayIp == \"\"."));
					return;
				}

				int32 TempGatewayPort = CWCommandMgr::GetGateWayPort();
				if (TempGatewayPort == INDEX_NONE)
				{
					UE_LOG(LogCWServerWaitingGameMode, Error, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., TempGatewayPort == INDEX_NONE."));
					return;
				}

				FCWServerWaitingToConnectEvent* toConnectEvent = new FCWServerWaitingToConnectEvent((int)ECWServerWaitingEvent::ToConnect, (int)ECWServerWaitingState::Connect, ECWFSMStackOp::Set, FCWUtils::FString2StdString(TempGatewayIp), TempGatewayPort);
				ServerWaitingFSM->DoEvent(toConnectEvent);
			}
			else
			{
				UCWGameInstance::GetInstance()->SetRoomId(0);
				UCWGameInstance::GetInstance()->SetRoomServerId(0);
				UCWGameInstance::GetInstance()->SetMatchId(0);

				UE_LOG(LogCWServerWaitingGameMode, Log, TEXT("ACWServerWaitingGameMode::OnLevelLoadComplete..., ServerWaitingFSM->Startup((int)ECWServerWaitingState::RegisterToRoom)"));
				ServerWaitingFSM->Startup((int)ECWServerWaitingState::RegisterToRoom);
			}
		}
	}
}