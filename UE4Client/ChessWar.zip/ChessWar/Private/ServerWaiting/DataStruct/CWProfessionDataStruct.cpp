#include "CWProfessionDataStruct.h"

FCWProfessionDataStruct::FCWProfessionDataStruct()
{
	ProfessionId = 0;
	ProfessionName = "";
	MoveType = 0;
	MoveValue = 0;
	EnergyValue = 0;
	Sword = false;
	Spear = false;
	Axe = false;
	Bow = false;
	Stick = false;
	AttackType = 0;
	NormalAttackId = 0;
	HealthSource = 0.0f;
	HealthAddition = 0.0f;
	AttackSource = 0.0f;
	AttackAddition = 0.0f;
	TalentSource = 0.0f;
	TalentAddition = 0.0f;
	PhysicalDefenceSource = 0.0f;
	PhysicalDefenceAddition = 0.0f;
	MagicDefenceSource = 0.0f;
	MagicDefenceAddition = 0.0f;
	MoveAnimSpeedRate = 0.0f;
	MoveSpeed = 0.0f;
	MoveAnimSpeedRate2 = 0.0f;
	MoveSpeed2 = 0.0f;
	IconId = "";
	ClickAudioId = "";
	BattleDistType = UINT8_MAX;
	ArrayMeshScale = "1|1|1";
	HitMarkHeight = 200.f;
}

FCWProfessionDataStruct::~FCWProfessionDataStruct()
{

}
