#include "CWProfessionDataUtils.h"


std::vector<float> FCWProfessionDataUtils::GetArrayMeshScaleFromString(const FString& ParamString)
{
	std::vector<float> ArrayMeshScale;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		float TempMeshScale = FCString::Atof(*TempString);
		ArrayMeshScale.push_back(TempMeshScale);
	}

	return ArrayMeshScale;
}
