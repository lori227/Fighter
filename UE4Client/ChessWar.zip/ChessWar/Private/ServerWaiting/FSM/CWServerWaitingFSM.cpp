#include "CWServerWaitingFSM.h"
#include "CWServerWaitingGameMode.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingFSM, All, All);


UCWServerWaitingFSM::UCWServerWaitingFSM(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void UCWServerWaitingFSM::Init(ACWServerWaitingGameMode* ParamServerWaitingGameMode)
{
	ServerWaitingGameMode = ParamServerWaitingGameMode;
}

ACWServerWaitingGameMode* UCWServerWaitingFSM::GetServerWaitingGameMode()
{
	return ServerWaitingGameMode;
}

void UCWServerWaitingFSM::BeginDestroy()
{
	Super::BeginDestroy();
}
