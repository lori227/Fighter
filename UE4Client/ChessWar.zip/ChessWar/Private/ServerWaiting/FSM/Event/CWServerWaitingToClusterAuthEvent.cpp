#include "CWServerWaitingToClusterAuthEvent.h"


FCWServerWaitingToClusterAuthEvent::FCWServerWaitingToClusterAuthEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToClusterAuthEvent::FCWServerWaitingToClusterAuthEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}