#include "CWServerWaitingToClusterVerifyEvent.h"


FCWServerWaitingToClusterVerifyEvent::FCWServerWaitingToClusterVerifyEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToClusterVerifyEvent::FCWServerWaitingToClusterVerifyEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}