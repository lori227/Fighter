#include "CWServerWaitingToConnectEvent.h"


FCWServerWaitingToConnectEvent::FCWServerWaitingToConnectEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToConnectEvent::FCWServerWaitingToConnectEvent(
	int ParamEventId, 
	int ParamToStateId, 
	ECWFSMStackOp ParamStackOp,
	const std::string& ParamIp,
	int ParamPort)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
	,Ip(ParamIp)
	,Port(ParamPort)
{


}