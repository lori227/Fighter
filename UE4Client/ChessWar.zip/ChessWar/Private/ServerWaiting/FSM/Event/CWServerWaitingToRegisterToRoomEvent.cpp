#include "CWServerWaitingToRegisterToRoomEvent.h"


FCWServerWaitingToRegisterToRoomEvent::FCWServerWaitingToRegisterToRoomEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToRegisterToRoomEvent::FCWServerWaitingToRegisterToRoomEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}