#include "CWServerWaitingToUsingEvent.h"


FCWServerWaitingToUsingEvent::FCWServerWaitingToUsingEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToUsingEvent::FCWServerWaitingToUsingEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}