#include "CWServerWaitingToWaitingEvent.h"


FCWServerWaitingToWaitingEvent::FCWServerWaitingToWaitingEvent()
	:FCWFSMEvent()
{

}


FCWServerWaitingToWaitingEvent::FCWServerWaitingToWaitingEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp)
	:FCWFSMEvent(ParamEventId, ParamToStateId, ParamStackOp)
{


}