
#include "CWServerWaitingClusterAuthState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWServerWaitingFSM.h"
#include "CWNetMessage.h"
#include "FrameMessage.pb.h"
#include "CWServerWaitingGameMode.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingClusterAuthState, All, All);

FCWServerWaitingClusterAuthState::FCWServerWaitingClusterAuthState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWServerWaitingClusterAuthState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingClusterAuthState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingClusterAuthState, Log, TEXT("FCWServerWaitingClusterAuthState::OnEnter..."));

	FString TempUEServerId = CWCommandMgr::GetUEServerId();
	if (TempUEServerId == "")
	{
		UE_LOG(LogCWServerWaitingClusterAuthState, Error, TEXT("FCWServerWaitingClusterAuthState::OnEnter, TempUEServerId == \"\"."));
		return;
	}

	KFMsg::S2SClusterAuthToMasterReq req;
	req.set_clientid(FCWUtils::FStringAppId2Uint64Id(TempUEServerId));
	req.set_clusterkey("route@kframe,./");
	const std::string strR = req.SerializeAsString();

	UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
	TempNetMsg->NetHead.MsgId = KFMsg::S2S_CLUSTER_AUTH_TO_MASTER_REQ;
	TempNetMsg->CopyData((uint8*)strR.c_str(), strR.length());
	UCWGameInstance::GetInstance()->GetTCPServerClient()->Send(TempNetMsg);
	UE_LOG(LogCWServerWaitingClusterAuthState, Log, TEXT("Send, msgid:%d, TempUEServerId:%s."), KFMsg::S2S_CLUSTER_AUTH_TO_MASTER_REQ, *TempUEServerId);
}

void FCWServerWaitingClusterAuthState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingClusterAuthState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingClusterAuthState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_CLUSTER_AUTH_TO_CLIENT_ACK)
	{
		KFMsg::S2SClusterAuthToClientAck ack;
		ack.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		TempFSM->GetServerWaitingGameMode()->SetToken(ack.token());

		UCWGameInstance::GetInstance()->GetTCPServerClient()->Disconnect();

		FCWServerWaitingToConnectEvent* toConnectEvent = new FCWServerWaitingToConnectEvent((int)ECWServerWaitingEvent::ToConnect, (int)ECWServerWaitingState::Connect, ECWFSMStackOp::Set, ack.listen().ip(), ack.listen().port());
		TempFSM->DoEvent(toConnectEvent);
	}
}

void FCWServerWaitingClusterAuthState::Tick(float DeltaTime)
{

}
