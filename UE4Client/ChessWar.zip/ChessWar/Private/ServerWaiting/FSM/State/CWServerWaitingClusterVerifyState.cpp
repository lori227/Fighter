
#include "CWServerWaitingClusterVerifyState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWServerWaitingFSM.h"
#include "CWServerWaitingGameMode.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWCommandMgr.h"
#include "CWUtils.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingClusterVerifyState, All, All);

FCWServerWaitingClusterVerifyState::FCWServerWaitingClusterVerifyState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWServerWaitingClusterVerifyState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingClusterVerifyState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingClusterVerifyState, Log, TEXT("FCWServerWaitingClusterVerifyState::OnEnter..."));
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	FString TempUEServerId = CWCommandMgr::GetUEServerId();
	if (TempUEServerId == "")
	{
		UE_LOG(LogCWServerWaitingClusterVerifyState, Error, TEXT("FCWServerWaitingClusterVerifyState::OnEnter, TempUEServerId == \"\"."));
		return;
	}

	KFMsg::S2SClusterVerifyToProxyReq req;
	req.set_token(TempFSM->GetServerWaitingGameMode()->GetToken());
	req.set_serverid(FCWUtils::FStringAppId2Uint64Id(TempUEServerId));
	const std::string strR = req.SerializeAsString();

	UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
	TempNetMsg->NetHead.MsgId = KFMsg::S2S_CLUSTER_VERIFY_TO_PROXY_REQ;
	TempNetMsg->CopyData((uint8*)strR.c_str(), strR.length());
	UCWGameInstance::GetInstance()->GetTCPServerClient()->Send(TempNetMsg);
	UE_LOG(LogCWServerWaitingClusterVerifyState, Log, TEXT("Send, msgid:%d, TempUEServerId:%s."), KFMsg::S2S_CLUSTER_VERIFY_TO_PROXY_REQ, *TempUEServerId);
}

void FCWServerWaitingClusterVerifyState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingClusterVerifyState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingClusterVerifyState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_CLUSTER_VERIFY_TO_CLIENT_ACK)
	{
		KFMsg::S2SClusterVerifyToClientAck ack;
		ack.ParseFromArray(Params->Data, Params->NetHead.DataLength);

		UE_LOG(LogCWServerWaitingClusterVerifyState, Log, TEXT("FCWServerWaitingClusterVerifyState::DoNetMessage..., MsgId:%d, serverid:%d."), Params->NetHead.MsgId, ack.serverid());
		if (ack.serverid() == 0)
		{
			FTimerDelegate EventCallback;
			EventCallback.BindLambda([=]()
			{
				FString TempGatewayIp = CWCommandMgr::GetGateWayIp();
				if (TempGatewayIp == "")
				{
					UE_LOG(LogCWServerWaitingClusterVerifyState, Error, TEXT("FCWServerWaitingClusterVerifyState::DoNetMessage, TempGatewayIp == \"\"."));
					return;
				}

				int32 TempGatewayPort = CWCommandMgr::GetGateWayPort();
				if (TempGatewayPort == INDEX_NONE)
				{
					UE_LOG(LogCWServerWaitingClusterVerifyState, Error, TEXT("FCWServerWaitingClusterVerifyState::DoNetMessage..., TempGatewayPort == INDEX_NONE."));
					return;
				}

				FCWServerWaitingToConnectEvent* toConnectEvent = new FCWServerWaitingToConnectEvent((int)ECWServerWaitingEvent::ToConnect, (int)ECWServerWaitingState::Connect, ECWFSMStackOp::Set, FCWUtils::FString2StdString(TempGatewayIp), TempGatewayPort);
				TempFSM->DoEvent(toConnectEvent);
			});

			FTimerHandle TempTimerHandle;
			UCWGameInstance::GetInstance()->GetWorld()->GetTimerManager().SetTimer(TempTimerHandle, EventCallback, 1.0f, false, 1.0f);
		}
		else
		{
			FCWServerWaitingToRegisterToRoomEvent* toRegisterToRoomEvent = new FCWServerWaitingToRegisterToRoomEvent((int)ECWServerWaitingEvent::ToRegisterToRoom, (int)ECWServerWaitingState::RegisterToRoom, ECWFSMStackOp::Set);
			TempFSM->DoEvent(toRegisterToRoomEvent);
		}
	}
}

void FCWServerWaitingClusterVerifyState::Tick(float DeltaTime)
{

}
