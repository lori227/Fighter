
#include "CWServerWaitingConnectState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWServerWaitingFSM.h"
#include "CWNetMessage.h"
#include "CWServerWaitingToClusterAuthEvent.h"
#include "FrameMessage.pb.h"
#include "CWUtils.h"
#include "CWCommandMgr.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingConnectState, All, All);

FCWServerWaitingConnectState::FCWServerWaitingConnectState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWServerWaitingConnectState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingConnectState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingConnectState, Log, TEXT("FCWServerWaitingConnectState::OnEnter..."));
	if (Event->EventId == (int)ECWServerWaitingEvent::ToConnect)
	{	
		FCWServerWaitingToConnectEvent* toConnectEvent = (FCWServerWaitingToConnectEvent*)Event;
		HandleConnect(toConnectEvent->Ip, toConnectEvent->Port);
	}
}

void FCWServerWaitingConnectState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingConnectState::DoEvent(const FCWFSMEvent* Event)
{
	if (Event->EventId == (int)ECWServerWaitingEvent::ToConnect)
	{
		FCWServerWaitingToConnectEvent* toConnectEvent = (FCWServerWaitingToConnectEvent*)Event;
		HandleConnect(toConnectEvent->Ip, toConnectEvent->Port);
	}
}

void FCWServerWaitingConnectState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_REGISTER_TO_SERVER_ACK)
	{
		KFMsg::RegisterToServerAck ack;
		ack.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		if (ack.apptype() == "master")
		{
			FCWServerWaitingToClusterAuthEvent* toClusterAuthEvent = new FCWServerWaitingToClusterAuthEvent((int)ECWServerWaitingEvent::ToClusterAuth, (int)ECWServerWaitingState::ClusterAuth, ECWFSMStackOp::Set);
			TempFSM->DoEvent(toClusterAuthEvent);
		}
		else if (ack.apptype() == "proxy")
		{
			FCWServerWaitingToClusterVerifyEvent* toClusterVerifyEvent = new FCWServerWaitingToClusterVerifyEvent((int)ECWServerWaitingEvent::ToClusterVerify, (int)ECWServerWaitingState::ClusterVerify, ECWFSMStackOp::Set);
			TempFSM->DoEvent(toClusterVerifyEvent);
		}
	}
}

void FCWServerWaitingConnectState::Tick(float DeltaTime)
{

}

void FCWServerWaitingConnectState::HandleConnect(const std::string& ParamIp, int ParamPort)
{
	if (!UCWGameInstance::GetInstance()->GetTCPServerClient()->Connect(ParamIp.c_str(), ParamPort))
	{
		UE_LOG(LogCWServerWaitingConnectState, Error, TEXT("���ӷ�����ʧ��..., ip:%s, port:%d."), ParamIp.c_str(), ParamPort);
		return;
	}

	FString TempUEServerId = CWCommandMgr::GetUEServerId();
	if (TempUEServerId == "")
	{
		UE_LOG(LogCWServerWaitingConnectState, Error, TEXT("FCWServerWaitingConnectState::HandleConnect, TempUEServerId == \"\"."));
		return;
	}

	FString TempUEServerIp = CWCommandMgr::GetUEServerIp();
	if (TempUEServerIp == "")
	{
		UE_LOG(LogCWServerWaitingConnectState, Error, TEXT("FCWServerWaitingConnectState::HandleConnect, TempUEServerIp == \"\"."));
		return;
	}

	int32 TempUEServerPort = CWCommandMgr::GetUEServerPort();
	if (TempUEServerPort == INDEX_NONE)
	{
		UE_LOG(LogCWServerWaitingConnectState, Error, TEXT("FCWServerWaitingConnectState::HandleConnect..., TempUEServerPort == INDEX_NONE."));
		return;
	}

	KFMsg::RegisterToServerReq req;
	req.mutable_listen()->set_appname("battle");
	req.mutable_listen()->set_apptype("client");
	req.mutable_listen()->set_appid(FCWUtils::FStringAppId2Uint64Id(TempUEServerId));
	req.mutable_listen()->set_ip(FCWUtils::FString2StdString(TempUEServerIp));
	req.mutable_listen()->set_port(TempUEServerPort);
	const std::string strR = req.SerializeAsString();

	UCWNetMessage* TempNetMsg = UCWNetMessage::Create();
	TempNetMsg->NetHead.MsgId = KFMsg::S2S_REGISTER_TO_SERVER_REQ;
	TempNetMsg->CopyData((uint8*)strR.c_str(), strR.length());
	UCWGameInstance::GetInstance()->GetTCPServerClient()->Send(TempNetMsg);
	UE_LOG(LogCWServerWaitingConnectState, Log, TEXT("Send, msgid:%d, TempUEServerId:%s."), KFMsg::S2S_REGISTER_TO_SERVER_REQ, *TempUEServerId);
}
