
#include "CWServerWaitingRegisterToRoomState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWServerWaitingFSM.h"
#include "ServerMessage.pb.h"
#include "FrameMessage.pb.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingRegisterToRoomState, All, All);

FCWServerWaitingRegisterToRoomState::FCWServerWaitingRegisterToRoomState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWServerWaitingRegisterToRoomState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingRegisterToRoomState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingRegisterToRoomState, Log, TEXT("FCWServerWaitingRegisterToRoomState::OnEnter..."));
	if (Event->EventId == (int)ECWServerWaitingEvent::ToRegisterToRoom ||
		Event->EventId == (int)ECWFSMEvent::Startup)
	{
		HandleRegisterToRoom();
	}
}

void FCWServerWaitingRegisterToRoomState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingRegisterToRoomState::DoEvent(const FCWFSMEvent* Event)
{
	if (Event->EventId == (int)ECWServerWaitingEvent::ToRegisterToRoom)
	{
		HandleRegisterToRoom();
	}
}

void FCWServerWaitingRegisterToRoomState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_ROUTE_MESSAGE_TO_CLIENT_ACK)
	{
		KFMsg::S2SRouteMessageToClientAck routeAck;
		routeAck.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		if (routeAck.msgid() == KFMsg::S2S_REGISTER_BATTLE_TO_BATTLE_ACK)
		{
			KFMsg::S2SRegisterBattleToBattleAck ack;
			ack.ParseFromArray(routeAck.msgdata().c_str(), routeAck.msgdata().length());

			UE_LOG(LogCWServerWaitingRegisterToRoomState, Log, TEXT("FCWServerWaitingRegisterToRoomState::DoNetMessage..., msgid:%d, result:%d."), routeAck.msgid(), ack.result());
			if (!ack.result())
			{
				FTimerDelegate EventCallback;
				EventCallback.BindLambda([=]()
				{
					FString TempGatewayIp = CWCommandMgr::GetGateWayIp();
					if (TempGatewayIp == "")
					{
						UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::DoNetMessage, TempGatewayIp == \"\"."));
						return;
					}

					int32 TempGatewayPort = CWCommandMgr::GetGateWayPort();
					if (TempGatewayPort == INDEX_NONE)
					{
						UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::DoNetMessage..., TempGatewayPort == INDEX_NONE."));
						return;
					}

					FCWServerWaitingToConnectEvent* toConnectEvent = new FCWServerWaitingToConnectEvent((int)ECWServerWaitingEvent::ToConnect, (int)ECWServerWaitingState::Connect, ECWFSMStackOp::Set, FCWUtils::FString2StdString(TempGatewayIp), TempGatewayPort);
					TempFSM->DoEvent(toConnectEvent);
				});

				FTimerHandle TempTimerHandle;
				UCWGameInstance::GetInstance()->GetWorld()->GetTimerManager().SetTimer(TempTimerHandle, EventCallback, 1.0f, false, 5.0f);
			}
			else
			{
				FCWServerWaitingToWaitingEvent* toWaitingEvent = new FCWServerWaitingToWaitingEvent((int)ECWServerWaitingEvent::ToWaiting, (int)ECWServerWaitingState::Waiting, ECWFSMStackOp::Set);
				TempFSM->DoEvent(toWaitingEvent);
			}
		}
		else
		{
			if (Params->NetHead.MsgId != 0)
			{
				UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::DoNetMessage..., routeAck.msgid():%d"), routeAck.msgid());
			}
		}
	}
	else
	{
		if (Params->NetHead.MsgId != 0)
		{
			UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::DoNetMessage..., Params->NetHead.MsgId:%d"), Params->NetHead.MsgId);
		}
	}
}

void FCWServerWaitingRegisterToRoomState::Tick(float DeltaTime)
{

}

void FCWServerWaitingRegisterToRoomState::HandleRegisterToRoom()
{
	FString TempUEServerId = CWCommandMgr::GetUEServerId();
	if (TempUEServerId == "")
	{
		UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::HandleRegisterToRoom, TempUEServerId == \"\"."));
		return;
	}

	FString TempUEServerIp = CWCommandMgr::GetUEServerIp();
	if (TempUEServerIp == "")
	{
		UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::HandleRegisterToRoom, TempUEServerIp == \"\"."));
		return;
	}

	int32 TempUEServerPort = CWCommandMgr::GetUEServerPort();
	if (TempUEServerPort == INDEX_NONE)
	{
		UE_LOG(LogCWServerWaitingRegisterToRoomState, Error, TEXT("FCWServerWaitingRegisterToRoomState::HandleRegisterToRoom..., TempUEServerPort == INDEX_NONE."));
		return;
	}

	KFMsg::S2SRegisterBattleToRoomReq req;
	req.set_serverid(FCWUtils::FStringAppId2Uint64Id(TempUEServerId));
	req.set_version("0.0.0.0");
	req.set_ip(FCWUtils::FString2StdString(TempUEServerIp));
	req.set_port(TempUEServerPort);
	UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_REGISTER_BATTLE_TO_ROOM_REQ, &req);
	UE_LOG(LogCWServerWaitingRegisterToRoomState, Log, TEXT("Send, msgid:%d, TempUEServerId:%s, TempUEServerIp:%s, TempUEServerPort:%d."), KFMsg::S2S_REGISTER_BATTLE_TO_ROOM_REQ, *TempUEServerId, *TempUEServerIp, TempUEServerPort);
}
