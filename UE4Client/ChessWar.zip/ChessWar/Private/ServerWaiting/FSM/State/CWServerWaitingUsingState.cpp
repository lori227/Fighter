
#include "CWServerWaitingUsingState.h"

#include "CWFSM.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWServerWaitingFSM.h"
#include "ServerMessage.pb.h"
#include "DefineMessage.pb.h"
#include "FrameMessage.pb.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingUsingState, All, All);

FCWServerWaitingUsingState::FCWServerWaitingUsingState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{
	RunningHeartbeatTime = 0.0f;
}

bool FCWServerWaitingUsingState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingUsingState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingUsingState, Log, TEXT("FCWServerWaitingUsingState::OnEnter..."));

	UCWFuncLib::CWGServerTravel(UCWGameInstance::GetInstance()->GetWorld(), TEXT("/Game/Levels/RandomDungeon/L_randomDungeon_persistent?Game=PVPGM"));
	UE_LOG(LogCWServerWaitingUsingState, Log, TEXT("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`"));
}

void FCWServerWaitingUsingState::OnExit(const FCWFSMEvent* Event)
{

	ResetData();
}

void FCWServerWaitingUsingState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingUsingState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_ROUTE_MESSAGE_TO_CLIENT_ACK)
	{
		KFMsg::S2SRouteMessageToClientAck routeAck;
		routeAck.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		if (routeAck.msgid() == KFMsg::S2S_OPEN_ROOM_TO_BATTLE_REQ)
		{
			KFMsg::S2SOpenRoomToBattleReq req;
			req.ParseFromArray(routeAck.msgdata().c_str(), routeAck.msgdata().length());

			uint64 TempRoomId = UCWGameInstance::GetInstance()->GetRoomId();
			UE_LOG(LogCWServerWaitingUsingState, Log, TEXT("FCWServerWaitingUsingState::DoNetMessage..., MsgId:%d, roomid:%d, matchid:%d, roomserverid:%d, hero_count:%d, TempRoomId:%d."), routeAck.msgid(), req.roomid(), req.matchid(), req.roomserverid(), req.pbplayer().size(), TempRoomId);
			if (TempRoomId != 0)
			{
				if (TempRoomId != req.roomid())
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(req.roomid());
					ack.set_result(false);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWServerWaitingUsingState, Warning, TEXT("Send 1, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
				else
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(req.roomid());
					ack.set_result(true);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWServerWaitingUsingState, Log, TEXT("Send 2, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
			}
		}
		else
		{
			if (Params->NetHead.MsgId != 0)
			{
				UE_LOG(LogCWServerWaitingUsingState, Error, TEXT("FCWServerWaitingUsingState::DoNetMessage..., routeAck.msgid():%d"), routeAck.msgid());
			}
		}
	}
	else
	{
		if (Params->NetHead.MsgId != 0)
		{
			UE_LOG(LogCWServerWaitingUsingState, Error, TEXT("FCWServerWaitingUsingState::DoNetMessage..., Params->NetHead.MsgId:%d"), Params->NetHead.MsgId);
		}
	}
}

void FCWServerWaitingUsingState::Tick(float DeltaTime)
{
	RunningHeartbeatTime += DeltaTime;
	if (RunningHeartbeatTime >= 30.0f)
	{
		HearbeatToServer();
		RunningHeartbeatTime = 0.0f;
	}
}

void FCWServerWaitingUsingState::HearbeatToServer()
{
	KFMsg::S2SHeartBeatToRoomReq req;
	req.set_roomid(UCWGameInstance::GetInstance()->GetRoomId());
	UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToServer(UCWGameInstance::GetInstance()->GetRoomServerId(), KFMsg::S2S_HEART_BEAT_TO_ROOM_REQ, &req);
}

void FCWServerWaitingUsingState::ResetData()
{
	RunningHeartbeatTime = 0.0f;

	UCWGameInstance::GetInstance()->SetRoomId(0);
	UCWGameInstance::GetInstance()->SetRoomServerId(0);
	UCWGameInstance::GetInstance()->SetMatchId(0);
}
