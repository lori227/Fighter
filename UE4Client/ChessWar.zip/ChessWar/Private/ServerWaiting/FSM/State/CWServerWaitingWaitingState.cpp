
#include "CWServerWaitingWaitingState.h"

#include "CWFSM.h"
#include "CWComDef.h"
#include "CWFSMEvent.h"
#include "CWFSMState.h"
#include "CWGameInstance.h"
#include "CWNetPlayerData.h"
#include "CWServerWaitingFSM.h"
#include "DefineMessage.pb.h"
#include "CWNetPlayerDataManager.h"

DECLARE_LOG_CATEGORY_CLASS(LogCWServerWaitingWaitingState, All, All);

FCWServerWaitingWaitingState::FCWServerWaitingWaitingState(UCWFSM* ParamParent, int ParamStateId)
	:FCWFSMState(ParamParent, ParamStateId)
{

}

bool FCWServerWaitingWaitingState::CanTranstion(const FCWFSMEvent* Event)
{
	return true;
}

void FCWServerWaitingWaitingState::OnEnter(const FCWFSMEvent* Event)
{
	UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("FCWServerWaitingWaitingState::OnEnter..."));
}

void FCWServerWaitingWaitingState::OnExit(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingWaitingState::DoEvent(const FCWFSMEvent* Event)
{

}

void FCWServerWaitingWaitingState::DoNetMessage(const UCWNetMessage* Params)
{
	check(Parent);
	UCWServerWaitingFSM* TempFSM = (UCWServerWaitingFSM*)Parent;
	check(TempFSM);

	if (Params->NetHead.MsgId == KFMsg::S2S_ROUTE_MESSAGE_TO_CLIENT_ACK)
	{
		KFMsg::S2SRouteMessageToClientAck routeAck;
		routeAck.ParseFromArray(Params->Data, Params->NetHead.DataLength);
		if (routeAck.msgid() == KFMsg::S2S_OPEN_ROOM_TO_BATTLE_REQ)
		{
			KFMsg::S2SOpenRoomToBattleReq req;
			req.ParseFromArray(routeAck.msgdata().c_str(), routeAck.msgdata().length());

			uint64 TempRoomId = UCWGameInstance::GetInstance()->GetRoomId();
			UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("FCWServerWaitingWaitingState::DoNetMessage..., routeAck.msgid():%d, roomid:%d, matchid:%d, roomserverid:%d, player_count:%d, TempRoomId:%d."), routeAck.msgid(), req.roomid(), req.matchid(), req.roomserverid(), req.pbplayer().size(), TempRoomId);
			if (TempRoomId == 0)
			{
				UCWGameInstance::GetInstance()->SetRoomId(req.roomid());
				UCWGameInstance::GetInstance()->SetRoomServerId(req.roomserverid());
				UCWGameInstance::GetInstance()->SetMatchId(req.matchid());

				//------------------------------------------------------------------------------
				for (int i = 0; i < req.pbplayer().size(); ++i)
				{
					UCWNetPlayerData* TempNetPlayerData = NewObject<UCWNetPlayerData>();
					uint64 TempNetPlayerUUID = 0;
					auto& player = req.pbplayer(i);

					TempNetPlayerData->Id = player.id();
					TempNetPlayerUUID = TempNetPlayerData->Id;
					TempNetPlayerData->ServerId = player.serverid();
					TempNetPlayerData->Name = FString(player.name().c_str());
					TempNetPlayerData->CampId = player.campid();

					UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Id :%d."), i, TempNetPlayerData->Id);
					UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, ServerId :%d."), i, TempNetPlayerData->ServerId);
					UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Name :%s."), i, *TempNetPlayerData->Name);
					UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, CampId :%d."), i, TempNetPlayerData->CampId);

					for (auto iter = player.hero().begin(); iter != player.hero().end(); ++iter)
					{	
						UCWNetHeroData* TempNetHeroData = NewObject<UCWNetHeroData>();
						uint64 TempHeroUUID = 0;
						auto& pbObj = iter->second;
						for (auto iterSubInt32 = pbObj.pbuint32().begin(); iterSubInt32 != pbObj.pbuint32().end(); ++iterSubInt32)
						{
							if (iterSubInt32->first == "race")
							{
								TempNetHeroData->Race = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, race :%d."), i, TempNetHeroData->Race);
							}
							else if (iterSubInt32->first == "profession")
							{
								TempNetHeroData->Profession = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Profession :%d."), i, TempNetHeroData->Profession);
							}
							else if (iterSubInt32->first == "sex")
							{
								TempNetHeroData->Sex = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Sex :%d."), i, TempNetHeroData->Sex);
							}
							else if (iterSubInt32->first == "identity")
							{
								TempNetHeroData->Identity = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Identity :%d."), i, TempNetHeroData->Identity);
							}
							else if (iterSubInt32->first == "age")
							{
								TempNetHeroData->Age = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Age :%d."), i, TempNetHeroData->Age);
							}
							else if (iterSubInt32->first == "quality")
							{
								TempNetHeroData->Quality = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Quality :%d."), i, TempNetHeroData->Quality);
							}
							else if (iterSubInt32->first == "level")
							{
								TempNetHeroData->Level = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Level :%d."), i, TempNetHeroData->Level);
							}
							else if (iterSubInt32->first == "weapon")
							{
								TempNetHeroData->Weapon = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Weapon :%d."), i, TempNetHeroData->Weapon);
							}
							else if (iterSubInt32->first == "str")
							{
								TempNetHeroData->Str = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Str :%d."), i, TempNetHeroData->Str);
							}
							else if (iterSubInt32->first == "dex")
							{
								TempNetHeroData->Dex = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Dex :%d."), i, TempNetHeroData->Dex);
							}
							else if (iterSubInt32->first == "con")
							{
								TempNetHeroData->Con = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Con :%d."), i, TempNetHeroData->Con);
							}
							else if (iterSubInt32->first == "int")
							{
								TempNetHeroData->Int = iterSubInt32->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Int :%d."), i, TempNetHeroData->Int);
							}
						}
						for (auto iterSubInt64 = pbObj.pbuint64().begin(); iterSubInt64 != pbObj.pbuint64().end(); ++iterSubInt64)
						{
							if (iterSubInt64->first == "uuid")
							{
								TempNetHeroData->UUID = iterSubInt64->second;
								TempHeroUUID = TempNetHeroData->UUID;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, UUID :%d."), i, TempNetHeroData->UUID);
							}
							else if (iterSubInt64->first == "birthday")
							{
								TempNetHeroData->Birthday = iterSubInt64->second;
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Birthday :%d."), i, TempNetHeroData->Birthday);
							}
						}
						for (auto iterSubString = pbObj.pbstring().begin(); iterSubString != pbObj.pbstring().end(); ++iterSubString)
						{
							if (iterSubString->first == "name")
							{
								TempNetHeroData->Name = FString(iterSubString->second.c_str());
								UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, Name :%s."), i, *TempNetHeroData->Name);
							}
						}
						for (auto iterArray = pbObj.pbarray().begin(); iterArray != pbObj.pbarray().end(); ++iterArray)
						{
							if (iterArray->first == "active")
							{
								auto map = iterArray->second;
								for (auto iterInt64 = map.pbuint64().begin(); iterInt64 != map.pbuint64().end(); ++iterInt64)
								{
									uint32 v = iterInt64->second;
									TempNetHeroData->ActiveSkillId.Add(v);
									UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, active :%d."), i, v);
								}
							}
							else if (iterArray->first == "passivity")
							{
								auto map = iterArray->second;
								for (auto iterInt64 = map.pbuint64().begin(); iterInt64 != map.pbuint64().end(); ++iterInt64)
								{
									uint32 v = iterInt64->second;
									TempNetHeroData->PassivitySkillId.Add(v);
									UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, passivity :%d."), i, v);
								}
							}
							if (iterArray->first == "innate")
							{
								auto map = iterArray->second;
								for (auto iterInt64 = map.pbuint64().begin(); iterInt64 != map.pbuint64().end(); ++iterInt64)
								{
									uint32 v = iterInt64->second;
									TempNetHeroData->InnateSkillId.Add(v);
									UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("i:%d, innate :%d."), i, v);
								}
							}
						}
						TempNetPlayerData->AddNetHeroData(TempHeroUUID, TempNetHeroData);
					}

					CWG_WARNING(">> player Data[%d]: Id[%I64u] ServerId[%I64u] Name[%s] CampId[%I32u].",
						i, TempNetPlayerData->Id, TempNetPlayerData->ServerId, *TempNetPlayerData->Name, TempNetPlayerData->CampId);
					UCWGameInstance::GetInstance()->GetNetPlayerDataMgr()->AddNetPlayerData(TempNetPlayerUUID, TempNetPlayerData);
				}
				//------------------------------------------------------------------------------
				FCWServerWaitingToUsingEvent* toUsingEvent = new FCWServerWaitingToUsingEvent((int)ECWServerWaitingEvent::ToUsing, (int)ECWServerWaitingState::Using, ECWFSMStackOp::Set);
				TempFSM->DoEvent(toUsingEvent);

				/*KFMsg::S2SOpenRoomToRoomAck ack;
				ack.set_roomid(req.roomid());
				ack.set_result(true);
				UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
				UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("Send 1, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);*/
			}
			else
			{
				if (TempRoomId != req.roomid())
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(req.roomid());
					ack.set_result(false);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWServerWaitingWaitingState, Warning, TEXT("Send 2, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
				else
				{
					KFMsg::S2SOpenRoomToRoomAck ack;
					ack.set_roomid(req.roomid());
					ack.set_result(true);
					UCWGameInstance::GetInstance()->GetTCPServerClient()->SendToRand("room", KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK, &ack);
					UE_LOG(LogCWServerWaitingWaitingState, Log, TEXT("Send 3, msgid:%d."), KFMsg::S2S_OPEN_ROOM_TO_ROOM_ACK);
				}
			}
		}
		else
		{
			if (Params->NetHead.MsgId != 0)
			{
				UE_LOG(LogCWServerWaitingWaitingState, Error, TEXT("FCWServerWaitingWaitingState::DoNetMessage..., routeAck.msgid():%d"), routeAck.msgid());
			}
		}
	}
	else
	{
		if (Params->NetHead.MsgId != 0)
		{
			UE_LOG(LogCWServerWaitingWaitingState, Error, TEXT("FCWServerWaitingWaitingState::DoNetMessage..., Params->NetHead.MsgId:%d"), Params->NetHead.MsgId);
		}
	}
}

void FCWServerWaitingWaitingState::Tick(float DeltaTime)
{

}
