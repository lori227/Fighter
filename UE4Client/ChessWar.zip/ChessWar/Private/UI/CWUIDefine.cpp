﻿
#include "CWUIDefine.h"


// Common ui key.
const FString FUIKey::UITips(		TEXT("UITips"));
const FString FUIKey::UILogin(		TEXT("UILogin"));
const FString FUIKey::UISetting(	TEXT("UISetting"));
const FString FUIKey::UIIconItem(	TEXT("UIIconItem"));
const FString FUIKey::UIFight(		TEXT("UIFight"));
const FString FUIKey::UIResult(		TEXT("UIResult"));
const FString FUIKey::UIItemBuff(	TEXT("UIItemBuff"));
const FString FUIKey::UICommConfirm(TEXT("UICommConfirm"));


FUIWidgetData::FUIWidgetData(const FString& InName)
	: Name(InName)
{
}

FFightPreviewData::FFightPreviewData(
	const FString& InName, const ECWBattleAttackType& InAttackType, 
	int32 InHp, int32 InMHp, int32 InSp,
	int32 InMSp, int32 InDMG, int32 InCRT)
	: Name(InName)
	, AttackType(InAttackType)
	, Hp(InHp)
	, MaxHp(InMHp)
	, Sp(InSp)
	, MaxSp(InMSp)
	, DMG(InDMG)
	, CRT(InCRT)
{
}

FFightPreviewData::FFightPreviewData()
{
	AttackType = ECWBattleAttackType::None;
	Hp = 0;
	MaxHp = 0;
	Sp = 0;
	MaxSp = 0;
	DMG = 0;
	CRT = 0;
}

FUIBuffNodeData::FUIBuffNodeData(int32 InBuffId, int32 InBuffLayerNum, int32 InBuffRemian, const FCWBuffDataStruct& InBuffData)
	: BuffId(InBuffId)
	, BuffLayerNum(InBuffLayerNum)
	, BuffRemian(InBuffRemian)
	, BuffData(InBuffData)
{

}

FUIBuffNodeData::FUIBuffNodeData()
{
	BuffId = 0;
	BuffRemian = 0;
	BuffLayerNum = 0;
}

bool FUIBuffNodeData::operator==(const FUIBuffNodeData& InOther)
{
	if (BuffId == InOther.BuffId &&
		BuffLayerNum == InOther.BuffLayerNum)
	{
		return true;
	}
	return false;
}

bool operator==(const FUIBuffNodeData& InLeft, const FUIBuffNodeData& InRight)
{
	if (InLeft.BuffId == InRight.BuffId &&
		InLeft.BuffLayerNum == InRight.BuffLayerNum)
	{
		return true;
	}
	return false;
}
