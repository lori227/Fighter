﻿
#include "CWUIUtil.h"

#include "Image.h"
#include "TextBlock.h"
#include "Components/Button.h"
#include "Components/ProgressBar.h"
#include "Styling/SlateBrush.h"
#include "Styling/SlateColor.h"
#include "Engine/Texture.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWAudioVideoMgr.h"
#include "CWBattleCalculate.h"
#include "CWBattlePropertySet.h"
#include "CWPawnBattlePropertyComponent.h"


UCWUIUtil::UCWUIUtil(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

float UCWUIUtil::Divide_IntInt(int32 A, int32 B)
{
	if (A == 0 || B == 0)
	{
		return 0.0f;
	}
	return FMath::DivideAndRoundDown<float>(float(A), float(B));
}

void UCWUIUtil::SetPressedPadding(UButton* InButton, float InPadding)
{
	if (IsValid(InButton))
	{
		FButtonStyle& WidgetStyle = InButton->WidgetStyle;
		WidgetStyle.PressedPadding = (InPadding <= 0.5f) ? FMargin() : FMargin(InPadding, InPadding + 1, InPadding, InPadding - 1);
		InButton->SetStyle(WidgetStyle);
	}
}

void UCWUIUtil::SetBtnImage(class UButton* InButton, UTexture* InImage)
{
	if (IsValid(InButton))
	{
		FButtonStyle& WidgetStyle = InButton->WidgetStyle;
		WidgetStyle.Normal.SetResourceObject(InImage);
		WidgetStyle.Hovered.SetResourceObject(InImage);
		WidgetStyle.Pressed.SetResourceObject(InImage);
		//WidgetStyle.Disabled.SetResourceObject(InImage);
		InButton->SetStyle(WidgetStyle);
	}
}

void UCWUIUtil::SetTextBlock_Color(UTextBlock* InText, int32 InValue, int32 HideValue, ESlateVisibility VisibleMode)
{
	if (IsValid(InText))
	{
		ESlateVisibility Visible = (InValue != HideValue ? VisibleMode : ESlateVisibility::Collapsed);
		InText->SetVisibility(Visible);
		if (Visible == VisibleMode)
		{
			FString Symbol = InValue > 0 ? TEXT("+") : TEXT("");
			FString SetText = TEXT("(") + Symbol + INT_TO_FSTRING(InValue) + TEXT(")");
			InText->SetText(FSTRING_TO_FTEXT(SetText));

			FLinearColor Color = (InValue > HideValue ? FLinearColor::Green : FLinearColor::Red);
			InText->SetColorAndOpacity(Color);
		}
	}
}

void UCWUIUtil::SetTextBlock(UTextBlock* InText, int32 InValue, int32 InExtValue)
{
	if (IsValid(InText))
	{
		InText->SetText(FSTRING_TO_FTEXT(INT_TO_FSTRING(InValue)));

		FLinearColor Color = (InExtValue == 0) ? FLinearColor::White : (InExtValue > 0 ? FLinearColor::Green : FLinearColor::Red);
		InText->SetColorAndOpacity(Color);
	}
}

void UCWUIUtil::SetProgressFullImage(UProgressBar* InProgressBar, UTexture* InImage)
{
	if (IsValid(InProgressBar))
	{
		FProgressBarStyle& WidgetStyle = InProgressBar->WidgetStyle;
		WidgetStyle.FillImage.SetResourceObject(InImage);
	}
}

bool UCWUIUtil::SetImageTexture(UImage* InImage, const FString& InAssetId)
{
	if (nullptr == InImage || InAssetId.IsEmpty())
	{
		return false;
	}

	UTexture2D* NewTexture = FCWCfgUtils::GetUIAssetObject<UTexture2D>(InImage, InAssetId);
	InImage->SetBrushFromTexture(NewTexture);
	return (nullptr != NewTexture);
}

bool UCWUIUtil::GetFightPreviewData(ACWPawn* InSelectPawn, ACWPawn* InTargetPawn,
	FFightPreviewData& OutSelectData, FFightPreviewData& OutTargetData)
{
	if (nullptr == InSelectPawn || nullptr == InTargetPawn)
	{
		OutSelectData = OutTargetData = FFightPreviewData();
		return false;
	}
	const UCWPawnBattlePropertyComponent* SelectProperty = InSelectPawn->BattleProperty;
	const UCWPawnBattlePropertyComponent* TargetProperty = InTargetPawn->BattleProperty;

	FUIPreviewExtData SelectExtData, TargetExtData;
	const FCWBattlePropertySet& SelectCurData = SelectProperty->GetCurPropertySet();
	const FCWBattlePropertySet& SelectMaxData = SelectProperty->GetCurMaxTheoreticalPropertySet();
	int32 SelectDMG = UCWBattleCalculate::Get()->PredictCalculateDamageBySkill(InSelectPawn, InTargetPawn, SelectExtData);
	const FString& SelectName = InSelectPawn->GetDisplayName();
	const FCWBattlePropertySet& TargetCurData = TargetProperty->GetCurPropertySet();
	const FCWBattlePropertySet& TargetMaxData = TargetProperty->GetCurMaxTheoreticalPropertySet();
	int32 TargetDMG = UCWBattleCalculate::Get()->PredictCalculateDamageBySkill(InTargetPawn, InSelectPawn, TargetExtData);
	const FString& TargetName = InTargetPawn->GetDisplayName();

	ECWBattleAttackType AttackType1 = SelectCurData.GetPropertyForAttackType(ECWBattleProperty::AttackType);
	int32 Hp1 = SelectCurData.GetPropertyByFloat(ECWBattleProperty::Health);
	int32 MaxHp1 = SelectMaxData.GetPropertyByFloat(ECWBattleProperty::Health);
	int32 Sp1 = SelectCurData.GetPropertyByFloat(ECWBattleProperty::Energy);
	int32 MaxSp1 = SelectMaxData.GetPropertyByFloat(ECWBattleProperty::Energy);
	int32 DMG1 = SelectDMG; // 伤害 SelectCurData.GetProperty<float>(ECWBattleProperty::PhysicalAttack);
	int32 CRT1 = SelectCurData.GetPropertyByFloat(ECWBattleProperty::CriticalHitRate);

	ECWBattleAttackType AttackType2 = TargetCurData.GetPropertyForAttackType(ECWBattleProperty::AttackType);
	int32 Hp2 = TargetCurData.GetPropertyByFloat(ECWBattleProperty::Health);
	int32 MaxHp2 = TargetMaxData.GetPropertyByFloat(ECWBattleProperty::Health);
	int32 Sp2 = TargetCurData.GetPropertyByFloat(ECWBattleProperty::Energy);
	int32 MaxSp2 = TargetMaxData.GetPropertyByFloat(ECWBattleProperty::Energy);
	int32 DMG2 = TargetDMG;
	int32 CRT2 = TargetCurData.GetPropertyByFloat(ECWBattleProperty::CriticalHitRate);

	OutSelectData = FFightPreviewData(SelectName, AttackType1, Hp1, MaxHp1, Sp1, MaxSp1, DMG1, CRT1);
	OutTargetData = FFightPreviewData(TargetName, AttackType2, Hp2, MaxHp2, Sp2, MaxSp2, DMG2, CRT2);

	OutSelectData.ExtData = SelectExtData;
	OutTargetData.ExtData = TargetExtData;

	return true;
}

FString UCWUIUtil::ToTimeFormat(int32 InSec)
{
	const int32 Hour = InSec / 3600;
	if (Hour <= 0)
	{
		return FString::Printf(TEXT("%.2d:%.2d"),
			(InSec - (Hour * 3600)) / 60,
			InSec - (Hour * 3600) - (InSec - (Hour * 3600)) / 60 * 60);
	}

	return FString::Printf(TEXT("%.2d:%.2d:%.2d"),
		Hour,
		(InSec - (Hour * 3600)) / 60,
		InSec - (Hour * 3600) - (InSec - (Hour * 3600)) / 60 * 60);
}

FString UCWUIUtil::ToString(const FBattlePropertyData PropertyData)
{
	return PropertyData.ToString();
}

void UCWUIUtil::PlayUISound(const UObject* InWorldContextObj, const FString& InAkEventName, const UAkAudioEvent* InAkEvent)
{
	if (UCWAudioVideoMgr* AVMgr = AV_MGR(InWorldContextObj))
	{
		AVMgr->PlayAudio(ECWAudioType::AT_UISound, InAkEventName, InAkEvent);
	}
}
