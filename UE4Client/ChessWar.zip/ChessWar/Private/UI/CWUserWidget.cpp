﻿
#include "CWUserWidget.h"

#include "WidgetAnimation.h"
#include "WidgetLayoutLibrary.h"

#include "CWGameState.h"
#include "CWFuncLib.h"
#include "CWUIManager.h"
#include "CWGameInstance.h"
#include "CWPlayerController.h"

UCWUserWidget::UCWUserWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bForcedCaptureMouseEvt(false)
{
}

UCWUserWidget::~UCWUserWidget()
{
}

bool UCWUserWidget::Initialize()
{
	// to do Initialize // editor
	//CWG_LOG(">> %s::Initialize ~", *GetName())

	if (!Super::Initialize())
	{
		return false;
	}
	return true;
}

void UCWUserWidget::BeginDestroy()
{
	//CWG_LOG(">> %s::BeginDestroy ~", *GetName())

	/*if (!IsTemplate() && nullptr != GetUIMgr())
	{
		GetUIMgr()->RemoveUICache(m_WidgetData.Name);
	}*/
	OnBeginDestroy.Broadcast();

	Super::BeginDestroy();
}

bool UCWUserWidget::IsInitialized()
{
	return bInitialized;
}

bool UCWUserWidget::IsCanInitCustom() const
{
	return UCWFuncLib::IsCanInitCustomData(this);
}

bool UCWUserWidget::IsCanDestroyCustom() const
{
	return UCWFuncLib::IsCanDestroyCustomData(this);
}

void UCWUserWidget::InitWidget(const FUIWidgetData& Data)
{
	m_WidgetData = Data;
}

void UCWUserWidget::ShowWidget(bool bNewVisible, int32 ZOrder)
{
	if (bNewVisible)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCWUserWidget::DestroyWidget()
{
	// 移出引用
	if (UCWUIManager* UI_Mgr = UI_MGR(this))
	{
		UI_Mgr->RemoveUICache(m_WidgetData.Name);
	}

	RemoveFromParent();
}

/*bool UCWUserWidget::IsVisible() const
{
	return Super::IsVisible();
}*/

ECWBattleState UCWUserWidget::GetBattleState() const
{
	const ACWGameState* const GameState = GetCWGameState();
	return (GameState ? GameState->GetCurBattleState() : ECWBattleState::None);
}

void UCWUserWidget::SetWidgetScreenPoint(UWidget* InWidget)
{
	APlayerController* LocalPC = UGameplayStatics::GetPlayerController(InWidget, 0);
	if (nullptr != LocalPC && nullptr != InWidget)
	{
		FVector2D ScreenLocation;
		LocalPC->GetMousePosition(ScreenLocation.X, ScreenLocation.Y);
		float ViewportScale = UWidgetLayoutLibrary::GetViewportScale(LocalPC);
		ScreenLocation /= ViewportScale;
		InWidget->SetRenderTranslation(ScreenLocation);
	}
}

bool UCWUserWidget::PlayAnimationByName(const FString& InAnimKey, float StartAtTime, int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode, float PlaybackSpeed)
{
	UWidgetAnimation* AnimInst = GetAnimationByName(InAnimKey);
	if (nullptr != AnimInst)
	{
		PlayAnimation(AnimInst, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed);
		return true;
	}
	return false;
}

bool UCWUserWidget::StopAnimationByName(const FString& InAnimKey)
{
	UWidgetAnimation* AnimInst = GetAnimationByName(InAnimKey);
	if (nullptr != AnimInst)
	{
		StopAnimation(AnimInst);
		return true;
	}
	return false;
}

UWidgetAnimation* UCWUserWidget::GetAnimationByName(const FString& InAnimKey)
{
	if (InAnimKey.IsEmpty())
	{
		return nullptr;
	}

	UWidgetBlueprintGeneratedClass* WidgetClass = GetWidgetTreeOwningClass();
	if (nullptr != WidgetClass)
	{
		for (int i = 0; i < WidgetClass->Animations.Num(); ++i)
		{
			UWidgetAnimation* AnimInst = WidgetClass->Animations[i];
			FString AnimInstName = AnimInst ? AnimInst->GetName() : TEXT("");
			if (nullptr != AnimInst && InAnimKey == AnimInstName)
			{
				return AnimInst;
			}
		}
	}
	return nullptr;
}

void UCWUserWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
}

void UCWUserWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
}

void UCWUserWidget::NativeConstruct()
{
	// to do Initialize // running
	Super::NativeConstruct();

	OnConstruct.Broadcast();
}

void UCWUserWidget::NativeDestruct()
{
	OnDestruct.Broadcast();

	Super::NativeDestruct();
}

UCWGameInstance* UCWUserWidget::GetCWGameInst() const
{
	return GetGameInstance<UCWGameInstance>();
}

ACWGameState* UCWUserWidget::GetCWGameState() const
{
	if (const UWorld* const World = GetWorld())
	{
		return Cast<ACWGameState>(World->GetGameState());
	}
	return nullptr;
}

class APlayerController* UCWUserWidget::GetLocalOwnerPC() const
{
	if (const ULocalPlayer* LocalPlayer = GetOwningLocalPlayer())
	{
		return LocalPlayer->GetPlayerController(GetWorld());
	}
	return nullptr;
}

ACWPlayerController* UCWUserWidget::GetLocalPC() const
{
	APlayerController* LocalPC = GetLocalOwnerPC();
	return Cast<ACWPlayerController>(LocalPC);
}

UCWUIManager* UCWUserWidget::GetUIMgr() const
{
	UCWUIManager* UIMgr = UI_MGR(this);
	return IsValid(UIMgr) ? UIMgr : nullptr;
}

FReply UCWUserWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (bForcedCaptureMouseEvt)
	{
		return FReply::Handled();
	}
	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}

FReply UCWUserWidget::NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (bForcedCaptureMouseEvt)
	{
		return FReply::Handled();
	}
	return Super::NativeOnMouseButtonUp(InGeometry, InMouseEvent);
}

FReply UCWUserWidget::NativeOnMouseButtonDoubleClick(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (bForcedCaptureMouseEvt)
	{
		return FReply::Handled();
	}
	return Super::NativeOnMouseButtonDoubleClick(InGeometry, InMouseEvent);
}
