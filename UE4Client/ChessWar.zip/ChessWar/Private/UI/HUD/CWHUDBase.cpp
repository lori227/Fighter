﻿
#include "CWHUDBase.h"

#include "Engine/Canvas.h"

#include "CWPawn.h"
#include "CWFuncLib.h"
#include "CWEventMgr.h"
#include "CWUIManager.h"
#include "CWPlayerController.h"


ACWHUDBase::ACWHUDBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

ACWHUDBase::~ACWHUDBase()
{
}

void ACWHUDBase::BeginPlay()
{
	Super::BeginPlay();
	
#if !UE_SERVER
	if (UCWFuncLib::IsCanInitCustomData(this))
	{
		if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			EvtMgr->OnHUDBeginPlayed.Broadcast(true);
		}
	}
#endif
}

void ACWHUDBase::BeginDestroy()
{
	Super::BeginDestroy();
}

void ACWHUDBase::Destroyed()
{
#if !UE_SERVER
	if (UCWFuncLib::IsCanDestroyCustomData(this))
	{
		if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			EvtMgr->OnHUDBeginPlayed.Broadcast(false);
		}
	}
#endif

	Super::Destroyed();
}

void ACWHUDBase::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	PlayerOwner = Cast<ACWPlayerController>(GetOwner());
}

void ACWHUDBase::DrawHUD()
{
	if (!IsPendingKillPending() && !IsPendingKill())
	{
		Super::DrawHUD();

		if (bDrawFlyNumbers)
		{
			DrawFlyWorldsNumbers();
		}
	}
}

void ACWHUDBase::FlyWordsEffectImpl(AActor* InActor, const int32 InType, const float InValue, const FString& InParam)
{
	if (bDrawFlyNumbers && InActor != nullptr /*&& InActor != PlayerOwner->GetViewTarget()*/)
	{
		const int32 InNewValue = (int32)InValue;
		for (int32 i = 0; i < FlyWorldsNumbers.Num(); i++)
		{
			if ((FlyWorldsNumbers[i].FlyWorldsPawn == InActor) &&
				(FlyWorldsNumbers[i].FlyWorldsType == InType) &&
				(GetWorld()->GetTimeSeconds() - FlyWorldsNumbers[i].SecondTime < 0.04f))
			{
				FlyWorldsNumbers[i].FlyWorldsValue += InNewValue;
				return;
			}
		}
		// save amount, scale , 2D location
		ACWPawn* GamePawn = Cast<ACWPawn>(InActor);
		const float NewScale = 0.75f;//FMath::RandRange(0.75f, 0.85f);
		const float HalfHeight = GamePawn ? 1.15f * GamePawn->BaseEyeHeight : 0.f;
		FVector NewLocation = InActor->GetActorLocation() + FVector(0.f, 0.f, HalfHeight);
		FlyWorldsNumbers.Add(FCWFlyWorldsNumber(GamePawn, InType, InNewValue, InParam, NewLocation, NewScale, GetWorld()->GetTimeSeconds()));
	}
}

void ACWHUDBase::DrawFlyWorldsNumbers()
{
	FFontRenderInfo TextRenderInfo;
	const float RenderScale = float(Canvas->SizeY) / 1080.0f;

	for (int32 i = 0; i < FlyWorldsNumbers.Num(); i++)
	{
		const int32 FlyWorldsValue = FlyWorldsNumbers[i].FlyWorldsValue;
		FlyWorldsNumbers[i].Scale = FlyWorldsNumbers[i].Scale + 1.7f * GetWorld()->DeltaTimeSeconds;
		const uint8 NewValue = FMath::Min(255, FlyWorldsValue);
		float MaxScale = FMath::Clamp(0.06f * float(NewValue), 1.8f, 2.4f);
		if (FlyWorldsNumbers[i].Scale > MaxScale)
		{
			FlyWorldsNumbers.RemoveAt(i, 1);
			i--;
		}
		else
		{
			float Alpha = 1.f - FMath::Square(FMath::Clamp((FlyWorldsNumbers[i].Scale - 1.f) / (MaxScale - 1.f), 0.f, 1.f));
			FVector ScreenPosition = Canvas->Project(FlyWorldsNumbers[i].WorldPosition);
			float XL, YL;
			FString Symbol = (FlyWorldsValue > 0) ? TEXT("+") : TEXT("");
			FString NumberString = /*(FlyWorldsValue != 0) ? */INT_TO_FSTRING(FlyWorldsValue)/* : TEXT("")*/;
			FString DrawString = FString::Printf(TEXT("%s%s%s"), *FlyWorldsNumbers[i].FlyWorldsParam, *Symbol, *NumberString);
			float NumberScale = RenderScale * FMath::Min(2.0f, FlyWorldsNumbers[i].Scale) * FlyWorldsScale;
			Canvas->TextSize(MediumFont, DrawString, XL, YL, 1.f, 1.f);
			FLinearColor BlackColor = FLinearColor::Black;
			BlackColor.A = Alpha;
			Canvas->SetLinearDrawColor(BlackColor);
			float OutlineScale = 1.075f*NumberScale;
			float Rise = RenderScale * (10.f + (FlyWorldsNumbers[i].Scale - 1.f) * 75.f);
			Canvas->DrawText(MediumFont, DrawString, ScreenPosition.X - 0.5f*XL*OutlineScale, ScreenPosition.Y - OutlineScale * 0.5f*YL - Rise, OutlineScale, OutlineScale, TextRenderInfo);
			FLinearColor NumberColor = FlyWorldsNumbers[i].GetFlyWorldsColor(Alpha);
			Canvas->SetLinearDrawColor(NumberColor);
			Canvas->DrawText(MediumFont, DrawString, ScreenPosition.X - 0.5f*XL*NumberScale, ScreenPosition.Y - NumberScale * 0.5f*YL - Rise, NumberScale, NumberScale, TextRenderInfo);
		}
	}
}

void ACWHUDBase::SetDrawFlyNumbers(const bool bDraw)
{
	bDrawFlyNumbers = bDraw;
}

