﻿
#include "CWUIAttackPreviewCtrl.h"

#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"
#include "Components/HorizontalBox.h"

#include "CWPawn.h"
#include "CWSkill.h"
#include "CWUIUtil.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWUIBuffBtn.h"
#include "CWUIWidgetData.h"
#include "CWBattleCalculate.h"
#include "CWProfessionDataStruct.h"


UCWUIAttackPreviewCtrl::UCWUIAttackPreviewCtrl(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWUIAttackPreviewCtrl::~UCWUIAttackPreviewCtrl()
{
}

void UCWUIAttackPreviewCtrl::InitController(UCWUserWidget* InWindow)
{
	check(InWindow);
	WinWidgetRef = InWindow;

	TrsAttackPreview = Cast<UUserWidget>(InWindow->GetWidgetFromName("TrsAttackPreview"));
	check(TrsAttackPreview.IsValid());

	TrsPreviewNode0 = Cast<UCWUserWidget>(TrsAttackPreview->GetWidgetFromName("TrsPreviewNode0"));
	TrsPreviewNode1 = Cast<UCWUserWidget>(TrsAttackPreview->GetWidgetFromName("TrsPreviewNode1"));
	check(TrsPreviewNode0.IsValid());
	check(TrsPreviewNode1.IsValid());
}

void UCWUIAttackPreviewCtrl::BeginDestroy()
{
	Super::BeginDestroy();
}

void UCWUIAttackPreviewCtrl::UpdatePreviewInfo(ACWPawn* InCasterPawn, ACWPawn* InTargetPawn,
	const FFightPreviewData& InCasterData, const FFightPreviewData& InTargetData)
{
	// Update preview data
	auto UpdatePreviewNode = [](UCWUserWidget* InPreviewNode, ACWPawn* InPawn, ACWPawn* InOtherPawn,
		const FFightPreviewData& InPawnData, const FFightPreviewData& InOtherData, int8 InRefrainType)
	{
		/** --- BASE --- */
		UImage* ImgPro = Cast<UImage>(InPreviewNode->GetWidgetFromName("ImgPro"));
		UTextBlock* TxtLv = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtLv"));
		UTextBlock* TxtName = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtName"));
		UTextBlock* TxtRace = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtRace"));
		UImage* ImgWeapon = Cast<UImage>(InPreviewNode->GetWidgetFromName("ImgWeapon"));
		UImage* ImgRefrain = Cast<UImage>(InPreviewNode->GetWidgetFromName("ImgRefrain"));

		const FString& InName = InPawn->GetDisplayName();
		const FString& InRaceKey = TEXT("TxtRace_") + InPawn->GetRaceId();
		const FString& InRaceName = FCWCfgUtils::GetLanguageString(InPawn, InRaceKey);
		const FString& InWeaponId = InPawn->GetWeaponId();
		const FCWProfessionDataStruct* ProfessionData = InPawn->GetProfessionData();
		const FString& ProIconId = ProfessionData ? ProfessionData->IconId : UICommIconId;
		TxtName->SetText(FSTRING_TO_FTEXT(InName));
		TxtRace->SetText(FSTRING_TO_FTEXT(InRaceName));
		UCWUIUtil::SetImageTexture(ImgPro, ProIconId);
		UCWUIUtil::SetImageTexture(ImgWeapon, InWeaponId);
		const FString& RefrainAssetId =
			(InRefrainType > 0) ? TEXT("icon_Up") :
			(InRefrainType < 0) ? TEXT("icon_Down") : TEXT("");
		bool bSetOk = UCWUIUtil::SetImageTexture(ImgRefrain, RefrainAssetId);
		ImgRefrain->SetVisibility(bSetOk ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

		/** --- HP/SP --- */
		UProgressBar* BarHpPre = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarHpPre"));
		UProgressBar* BarHpCur = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarHpCur"));
		UTextBlock* TxtHp = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtHp"));
		UProgressBar* BarSpPre = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarSpPre"));
		UProgressBar* BarSpCur = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarSpCur"));
		UTextBlock* TxtSp = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtSp"));
		/**  */
		UProgressBar* BarAtk = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarAtk"));
		UTextBlock* TxtATK = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtATK"));
		UTextBlock* TxtATK_Ext = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtATK_Ext"));
		UProgressBar* BarCRI = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarCRI"));
		UTextBlock* TxtCRI = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtCRI"));
		UTextBlock* TxtCRI_Ext = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtCRI_Ext"));
		UProgressBar* BarHIT = Cast<UProgressBar>(InPreviewNode->GetWidgetFromName("BarHIT"));
		UTextBlock* TxtHIT = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtHIT"));
		UTextBlock* TxtHIT_Ext = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtHIT_Ext"));

		const int32 CurHpValue = FMath::Max<int32>(InPawnData.Hp, 0);
		const int32 MaxHpValue = FMath::Max<int32>(InPawnData.MaxHp, 0);
		const float CurHpPercent = UCWUIUtil::Divide_IntInt(CurHpValue, MaxHpValue);
		const int32 PreHpValue = FMath::Max<int32>(InPawnData.Hp - InOtherData.DMG, 0);
		const float PreHpPercent = UCWUIUtil::Divide_IntInt(PreHpValue, MaxHpValue);
		const int32 CurSpValue = FMath::Max<int32>(InPawnData.Sp, 0);
		const int32 MaxSpValue = FMath::Max<int32>(InPawnData.MaxSp, 0);
		const float CurSpPercent = UCWUIUtil::Divide_IntInt(CurSpValue, MaxSpValue);
		const int32 PreSpValue = FMath::Max<int32>(InPawnData.Sp - InPawnData.ExtData.ConsumeEnergy, 0);
		const float PreSpPercent = UCWUIUtil::Divide_IntInt(PreSpValue, MaxSpValue);
		const FString& NewTxtHp = INT_TO_FSTRING(CurHpValue) + TEXT("->") + INT_TO_FSTRING(PreHpValue);
		const FString& NewTxtSp = INT_TO_FSTRING(CurSpValue) + TEXT("->") + INT_TO_FSTRING(PreSpValue);
		BarHpPre->SetPercent(CurHpPercent);
		BarHpCur->SetPercent(PreHpPercent);
		BarSpPre->SetPercent(CurSpPercent);
		BarSpCur->SetPercent(PreSpPercent);
		//TxtHp->SetOpacity(0.f);
		//TxtSp->SetOpacity(0.f);
		TxtHp->SetText(FSTRING_TO_FTEXT(NewTxtHp));
		TxtSp->SetText(FSTRING_TO_FTEXT(NewTxtSp));
		TxtATK->SetText(INT_TO_FTEXT(InOtherData.DMG));
		TxtCRI->SetText(INT_TO_FTEXT(InOtherData.CRT));
		TxtHIT->SetText(INT_TO_FTEXT(0));
		/** Animation */
		if (CurHpPercent > 0.05f || CurSpPercent > 0.05f)
		{
			InPreviewNode->PlayAnimationByName(TEXT("AnimBarFlicker_INST"), 0.f, 0);
		}else
		{
			InPreviewNode->StopAnimationByName(TEXT("AnimBarFlicker_INST"));
			BarHpPre->SetRenderOpacity(1.f);
			BarSpPre->SetRenderOpacity(1.f);
		}

		/** --- BUFF --- */
		UHorizontalBox* TrsBuffList = Cast<UHorizontalBox>(InPreviewNode->GetWidgetFromName("TrsBuffList"));
		UTextBlock* TxtNoneBuff = Cast<UTextBlock>(InPreviewNode->GetWidgetFromName("TxtNoneBuff"));

		TArray<FUIBuffNodeData> PawnBuffArray = InPawn->GetBuffListInfo();
		const int32 PawnBuffNum = PawnBuffArray.Num();
		const int32 TrsBuffListNum = TrsBuffList->GetChildrenCount();
		const int32 MaxIdx = FMath::Max(PawnBuffNum, TrsBuffListNum);
		for (int32 Idx = 0; Idx < MaxIdx; ++Idx)
		{
			UWidget* Widget = TrsBuffList->GetChildAt(Idx);
			if (PawnBuffArray.IsValidIndex(Idx))
			{
				const FVector2D& NewSize = FVector2D(25.f, 25.f);
				if (UCWUIBuffBtn* UIItem = Cast<UCWUIBuffBtn>(Widget))
				{	// 更新
					UIItem->UpdateItem(PawnBuffArray[Idx]);
					UIItem->SetVisibility(ESlateVisibility::Visible);
				}
				else if (const FCWUIWidgetData* WidgetData = FCWCfgUtils::GetUIWidgetData(InPawn, FUIKey::UIItemBuff))
				{
					if (UCWUIBuffBtn* NewItem = CreateWidget<UCWUIBuffBtn>(TrsBuffList, WidgetData->UIWidget))
					{	// 添加
						NewItem->UpdateItem(PawnBuffArray[Idx]);
						NewItem->SetDesiredSizeInViewport(NewSize);
						TrsBuffList->AddChildToHorizontalBox(NewItem);
						NewItem->SetVisibility(ESlateVisibility::Visible);
					}
				}
			}
			else if (IsValid(Widget))
			{	// 隐藏/删除
				Widget->SetVisibility(ESlateVisibility::Collapsed);
			}
		}
		TxtNoneBuff->SetVisibility((PawnBuffNum <= 0) ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	};

	int8 InRefrainType = 0;		// -1:BeRefrain 0:Hide 1:Refrain
	if (IsValidActor(InCasterPawn) && IsValidActor(InTargetPawn) && UCWFuncLib::IsEnemy(InCasterPawn, InTargetPawn))
	{
		const float RefrainFactor = UCWBattleCalculate::Get()->GetRefrainFactor(InCasterPawn, InTargetPawn);
		InRefrainType = (RefrainFactor > SMALL_NUMBER) ? 1 : (RefrainFactor < -SMALL_NUMBER) ? -1 : 0;
	}

	UpdatePreviewNode(TrsPreviewNode0.Get(), InCasterPawn, InTargetPawn, InCasterData, InTargetData, InRefrainType);
	UpdatePreviewNode(TrsPreviewNode1.Get(), InTargetPawn, InCasterPawn, InTargetData, InCasterData, -InRefrainType);
	TrsAttackPreview->SetVisibility(ESlateVisibility::Visible);
}

void UCWUIAttackPreviewCtrl::HidePreviewInfo()
{
	TrsAttackPreview->SetVisibility(ESlateVisibility::Collapsed);
}

