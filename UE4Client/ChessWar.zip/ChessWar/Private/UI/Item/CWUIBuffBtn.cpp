﻿
#include "CWUIBuffBtn.h"

#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "CWUIUtil.h"
#include "CWPawn.h"
#include "CWSkill.h"


UCWUIBuffBtn::UCWUIBuffBtn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWUIBuffBtn::~UCWUIBuffBtn()
{
}

bool UCWUIBuffBtn::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
	}

	return true;
}

void UCWUIBuffBtn::BeginDestroy()
{
	Super::BeginDestroy();
}

void UCWUIBuffBtn::UpdateItem(FUIBuffNodeData InBuffData)
{
	BuffData = InBuffData;

	UCWButton* BtnMain = Cast<UCWButton>(GetWidgetFromName(FName("BtnMain")));
	UTextBlock* TxtRemain = Cast<UTextBlock>(GetWidgetFromName(FName("TxtRemain")));
	UImage* ImgIcon = Cast<UImage>(GetWidgetFromName(FName("ImgIcon")));
	if (nullptr != TxtRemain)
	{
		TxtRemain->SetText(INT_TO_FTEXT(BuffData.BuffRemian));
	}
	if (nullptr != ImgIcon)
	{
		UCWUIUtil::SetImageTexture(ImgIcon, BuffData.BuffData.IconId);
	}
}
