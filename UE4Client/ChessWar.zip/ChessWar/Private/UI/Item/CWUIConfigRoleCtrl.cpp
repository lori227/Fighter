﻿
#include "CWUIConfigRoleCtrl.h"

#include "Components/TextBlock.h"
#include "Components/CanvasPanel.h"
#include "Components/VerticalBox.h"
#include "Components/HorizontalBox.h"
#include "Blueprint/WidgetLayoutLibrary.h"

#include "TimerManager.h"
#include "CWComDef.h"
#include "CWCfgUtils.h"
#include "CWEventMgr.h"
#include "CWCfgManager.h"
#include "CWUIIconItem.h"
#include "CWUserWidget.h"
//#include "CWPawnNetData.h"
#include "CWUIWidgetData.h"
#include "CWClientConstData.h"
#include "CWPlayerController.h"
#include "CWUIAttributeWidgetNew.h"
#include "CWProfessionDataStruct.h"


UCWUIConfigRoleCtrl::UCWUIConfigRoleCtrl(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UCWUIConfigRoleCtrl::~UCWUIConfigRoleCtrl()
{
}

void UCWUIConfigRoleCtrl::InitController(UCWUserWidget* InWindow)
{
	check(InWindow);
	WinWidgetRef = InWindow;

	// TODO: 初始化 Widget - TrsConfigRole
	TrsConfigRole = Cast<UCanvasPanel>(WinWidgetRef->GetWidgetFromName(FName("TrsConfigRole")));
	TrsRoleList = Cast<UVerticalBox>(WinWidgetRef->GetWidgetFromName(FName("TrsRoleList")));

	TrsAtrrTip = Cast<UCWUIAttributeTipWidget>(WinWidgetRef->GetWidgetFromName(FName("TrsAtrrTip")));
	TrsSkillDesc = Cast<UCWUserWidget>(WinWidgetRef->GetWidgetFromName(FName("TrsSkillDesc")));

	TrsMsg = Cast<UCanvasPanel>(WinWidgetRef->GetWidgetFromName(FName("TrsMsg")));
	TxtMsg = Cast<UTextBlock>(WinWidgetRef->GetWidgetFromName(FName("TxtMsg")));

	// Init Evt
	if (ACWPlayerController* LocalPC = WinWidgetRef->GetLocalPC())
	{
		OnUpdateRoleListData(LocalPC->GetExtPawnData());

		//ADD_EVT_DELEGATE(LocalPC->OnSendMessage, this, &UCWUIConfigRole::OnSendMessage, FName("OnSendMessage"));
		ADD_EVT_DELEGATE(LocalPC->OnReadyFinished, this, &UCWUIConfigRoleCtrl::OnPlayerReadyFinished, FName("OnPlayerReadyFinished"));
		ADD_EVT_DELEGATE(LocalPC->OnExtraPawnDataCallable, this, &UCWUIConfigRoleCtrl::OnUpdateRoleListData, FName("OnUpdateRoleListData"));
	}

	TrsAtrrTip->OnShowAttrTip.BindUFunction(this, FName("OnCancelAttrInfoTipHide"));
	TrsAtrrTip->OnHideAttrTip.BindUFunction(this, FName("OnHideAttrInfoTip"));
}

void UCWUIConfigRoleCtrl::BeginDestroy()
{
	if (WinWidgetRef.IsValid() && WinWidgetRef->IsCanDestroyCustom())
	{
		if (ACWPlayerController* LocalPC = WinWidgetRef->GetLocalPC())
		{
			//REMOVE_EVT_DELEGATE(LocalPC->OnSendMessage, this);
			REMOVE_EVT_DELEGATE(LocalPC->OnReadyFinished, this);
			REMOVE_EVT_DELEGATE(LocalPC->OnExtraPawnDataCallable, this);
		}
	}

	Super::BeginDestroy();
}

UFUNCTION(BlueprintCallable)
void UCWUIConfigRoleCtrl::OnHideAttrInfoTip()
{
	FTimerDelegate AttrTipCloseCallback;
	AttrTipCloseCallback.BindLambda([this]()
	{
		TrsAtrrTip.Get()->SetVisibility(ESlateVisibility::Collapsed);
	});
	GetWorld()->GetTimerManager().SetTimer(AttrTipCloseTimer, AttrTipCloseCallback,0.5f,false,0.5f);
}

UFUNCTION(BlueprintCallable)

void UCWUIConfigRoleCtrl::UpDateAttrTipInfo(FCWPawnNetData PawnData)
{
	FCWPawnNetData& PawnNetData = PawnData;
	const FCWProfessionDataStruct* ProfessionData = FCWCfgUtils::GetProfessionData(this, PawnNetData.Profession);
	if (nullptr != ProfessionData) 
	{
		float TempHp = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->HealthSource) * ProfessionData->HealthAddition;
		float TempSp = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->EnergyValue);
		float TempATK = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->AttackSource) * ProfessionData->AttackAddition;
		float TempPhysicDefM = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->PhysicalDefenceSource) * ProfessionData->PhysicalDefenceAddition;
		float TempMagicDEF = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->MagicDefenceSource) * ProfessionData->MagicDefenceAddition;
		float TempTalent = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->TalentSource) * ProfessionData->TalentAddition;
		float TempMov = PawnNetData.GetNetDataPropertyByPropertyId(ProfessionData->MoveValue);
		TArray<int32> TempActSkillId = PawnNetData.ActiveSkillId;
		TArray<int32> TempPassSkillId = PawnNetData.PassivitySkillId;
		TArray<int32> TempInnSkillId = PawnNetData.InnateSkillId;

		// 获取理论最大值
		TArray<int32> NewMaxList = UCWUIAttributeWidgetNew::GetAttrMaxValueList(this);
		auto NewMaxValue = [&NewMaxList](const int32 InIdx)
		{
			return NewMaxList.IsValidIndex(InIdx) ? NewMaxList[InIdx] : 100;
		};
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::Health, TrsAtrrTip->ConversionResultValue(TempHp, 0.f), TrsAtrrTip->ConversionResultValue(TempHp, 0.f));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::Energy, TrsAtrrTip->ConversionResultValue(TempSp, 0.f), TrsAtrrTip->ConversionResultValue(TempSp, 0.f));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::Attack, TrsAtrrTip->ConversionResultValue(TempATK, 0.f), NewMaxValue(0));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::PhysicalDefence, TrsAtrrTip->ConversionResultValue(TempPhysicDefM, 0.f), NewMaxValue(1));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::MagicDefence, TrsAtrrTip->ConversionResultValue(TempMagicDEF, 0.f), NewMaxValue(2));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::Talent, TrsAtrrTip->ConversionResultValue(TempTalent, 0.f), NewMaxValue(3));
		TrsAtrrTip->UpdateAttrValue(ECWBattleProperty::Move, TrsAtrrTip->ConversionResultValue(TempMov, 0.f), NewMaxValue(4));
		TrsAtrrTip->SetActiveSkillId(TempActSkillId);
		TrsAtrrTip->SetPassivitySkillId(TempPassSkillId);
		TrsAtrrTip->SetInnateSkillId(TempInnSkillId);
	}
}

void UCWUIConfigRoleCtrl::OnShowAttrInfoTip(FCWPawnNetData PawnData)
{
	if (ESlateVisibility::Visible != TrsAtrrTip->GetVisibility()|| PawnData.UUID != CurIconItemID)
	{
		if (PawnData.UUID != CurIconItemID)
		{
			TrsAtrrTip.Get()->SetVisibility(ESlateVisibility::Collapsed);
			FTimerHandle TempTimer;
			if (TempTimer != AttrTipCloseTimer) {
				GetWorld()->GetTimerManager().ClearTimer(AttrTipCloseTimer);
			}
		}
		UpDateAttrTipInfo(PawnData);
		TrsAtrrTip.Get()->SetVisibility(ESlateVisibility::Visible);
		UCWUserWidget::SetWidgetScreenPoint(TrsAtrrTip.Get());
		CurIconItemID = PawnData.UUID;
	}
	else 		
	{
		if (AttrTipCloseTimer.IsValid()) 
		{
			GetWorld()->GetTimerManager().ClearTimer(AttrTipCloseTimer);
		}
	}
}

void UCWUIConfigRoleCtrl::OnCancelAttrInfoTipHide()
{
	if (ESlateVisibility::Visible == TrsAtrrTip->GetVisibility()) {
		if (AttrTipCloseTimer.IsValid()) 
		{
			GetWorld()->GetTimerManager().ClearTimer(AttrTipCloseTimer);
		}
	}
}

void UCWUIConfigRoleCtrl::OnPlayerReadyFinished(const bool bIsReadyFinished)
{
	TrsConfigRole->SetVisibility(bIsReadyFinished ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
}

void UCWUIConfigRoleCtrl::OnUpdateRoleListData(const TArray<FCWPawnNetData>& InPawnDatas)
{
	// 设置图标显示
	const int32 TrsRoleListNum = TrsRoleList->GetChildrenCount();
	const int32 MaxIdx = (TrsRoleListNum > InPawnDatas.Num()) ? TrsRoleListNum : InPawnDatas.Num();

	for (int32 Idx = 0; Idx < MaxIdx; ++Idx)
	{
		UWidget* Widget = TrsRoleList->GetChildAt(Idx);
		if (InPawnDatas.IsValidIndex(Idx))
		{
			if (UCWUIIconItem* IconItem = Cast<UCWUIIconItem>(Widget))
			{	// 更新
				IconItem->OnShowAttrTip.BindUFunction(this, FName("OnShowAttrInfoTip"));
				IconItem->OnHideAttrTip.BindUFunction(this, FName("OnHideAttrInfoTip"));
				IconItem->InitItem(InPawnDatas[Idx]);
				IconItem->SetVisibility(ESlateVisibility::Visible);
			}
			else if (const FCWUIWidgetData* WidgetData = FCWCfgUtils::GetUIWidgetData(WinWidgetRef->GetWorld(), FUIKey::UIIconItem))
			{
				if (UCWUIIconItem* NewItem = CreateWidget<UCWUIIconItem>(TrsRoleList.Get(), WidgetData->UIWidget))
				{	// 添加
					TrsRoleList->AddChildToVerticalBox(NewItem);
					NewItem->OnShowAttrTip.BindUFunction(this, FName("OnShowAttrInfoTip"));
					NewItem->OnHideAttrTip.BindUFunction(this, FName("OnHideAttrInfoTip"));
					NewItem->InitItem(InPawnDatas[Idx]);
					NewItem->SetVisibility(ESlateVisibility::Visible);
				}
			}
		}
		else if(IsValid(Widget))
		{	// 隐藏/删除
			Widget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}
