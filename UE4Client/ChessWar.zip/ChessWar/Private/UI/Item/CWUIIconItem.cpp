﻿
#include "CWUIIconItem.h"
#include "WidgetBlueprintLibrary.h"
#include "Components/CanvasPanel.h"
#include "Components/TextBlock.h"
#include "Components/Image.h"

#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWCfgUtils.h"
#include "CWAssetData.h"
#include "CWCfgManager.h"
#include "CWDragDropOp.h"
#include "CWPawnDataStruct.h"
#include "CWProfessionDataStruct.h"


UCWUIIconItem::UCWUIIconItem(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bEnableDragOverride(false)
{
}

UCWUIIconItem::~UCWUIIconItem()
{
}

bool UCWUIIconItem::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		Root = Cast<UCanvasPanel>(GetWidgetFromName(FName("Root")));
		ImgIcon = Cast<UImage>(GetWidgetFromName(FName("ImgIcon")));
		TxtName = Cast<UTextBlock>(GetWidgetFromName(FName("TxtName")));

		SetTxtName(TEXT("-InValid-"));
		//SetIconImg(TEXT("Icon_3"));

		// 需要 Drag 则设置 Visible
		//SetVisibility(ESlateVisibility::Visible);
	}

	return true;
}

void UCWUIIconItem::BeginDestroy()
{
	Super::BeginDestroy();
}

void UCWUIIconItem::InitItem(const FCWPawnNetData& InNetPawnData, const float InScale)
{
	PawnNetData = InNetPawnData;

	OnInitItem();
	SetRenderScale(FVector2D::UnitVector * InScale);
}

void UCWUIIconItem::SetIconImg(const FString& InAssetId)
{
	UTexture2D* Texture = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, InAssetId);
	ImgIcon->SetBrushFromTexture(Texture);
}

void UCWUIIconItem::SetTxtName(const FString& InName)
{
	TxtName->SetText(FSTRING_TO_FTEXT(InName));
}

void UCWUIIconItem::SetOpacity(const float InOpacity /*= 0.5f*/)
{
	Root->SetRenderOpacity(InOpacity);
}

FString UCWUIIconItem::GetNetPawnId() const
{
	return PawnNetData.UUID;
}

int32 UCWUIIconItem::GetNetPawnProfession() const
{
	return PawnNetData.Profession;
}

const FCWPawnNetData& UCWUIIconItem::GetNetPawnData() const
{
	return PawnNetData;
}

void UCWUIIconItem::OnInitItem()
{
	/*if (const FCWPawnDataStruct* PawnData = FCWCfgUtils::GetPawnData(this, PawnId))
	{
		SetIconImg(PawnData->IconId);
		SetTxtName(PawnData->PawnName);
	}*/

	if (PawnNetData.UUID.IsEmpty())
	{
		CWG_ERROR(">> %s::OnInitItem, PawnNetData.UUID is empty!");
		return;
	}

	if (const FCWProfessionDataStruct* ProfessionData = FCWCfgUtils::GetProfessionData(this, PawnNetData.Profession))
	{
		if (!ProfessionData->IconId.IsEmpty())
		{
			SetIconImg(ProfessionData->IconId);
		}
		SetTxtName(ProfessionData->ProfessionName);
	}

	SetOpacity(1.f);
}

FReply UCWUIIconItem::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (bEnableDragOverride)
	{
		return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
	}
	return UWidgetBlueprintLibrary::DetectDragIfPressed(InMouseEvent, this, EKeys::LeftMouseButton).NativeReply;
}

void UCWUIIconItem::NativeOnDragDetected(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent, UDragDropOperation*& OutOperation)
{
	if (bEnableDragOverride)
	{
		return Super::NativeOnDragDetected(InGeometry, InMouseEvent, OutOperation);
	}
	//UUserWidget* DragVisual = UWidgetBlueprintLibrary::CreateWidget(this, );

	if (nullptr == OutOperation)
	{
		UDragDropOperation* DropOp = UWidgetBlueprintLibrary::CreateDragDropOperation(UCWDragDropOp::StaticClass());
		DropOp->Payload = GetDragPayload();
		DropOp->DefaultDragVisual = GetDragDefaultVisual();
		DropOp->Pivot = EDragPivot::CenterCenter;
		DropOp->Offset = FVector2D::ZeroVector;
		OutOperation = DropOp;

		SetOpacity(0.5f);
	}
}

bool UCWUIIconItem::NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	if (bEnableDragOverride)
	{
		return Super::NativeOnDrop(InGeometry, InDragDropEvent, InOperation);
	}

	SetOpacity(1.f);
	return true;
}

void UCWUIIconItem::NativeOnDragCancelled(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation)
{
	if (bEnableDragOverride)
	{
		return Super::NativeOnDragCancelled(InDragDropEvent, InOperation);
	}

	SetOpacity(1.f);
}

void UCWUIIconItem::NativeOnMouseEnter(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	OnShowAttrTip.ExecuteIfBound(PawnNetData);
}

void UCWUIIconItem::NativeOnMouseLeave(const FPointerEvent& InMouseEvent)
{
	OnHideAttrTip.ExecuteIfBound();
}

UWidget* UCWUIIconItem::GetDragDefaultVisual_Implementation()
{
	if (ImgIcon.IsValid())
	{
		return ImgIcon.Get();
	}
	return this;
}

UObject* UCWUIIconItem::GetDragPayload_Implementation()
{
	return this;
}

