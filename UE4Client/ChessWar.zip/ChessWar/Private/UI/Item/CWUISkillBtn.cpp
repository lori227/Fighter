﻿
#include "CWUISkillBtn.h"

#include "CWPawn.h"
#include "CWSkill.h"


UCWUISkillBtn::UCWUISkillBtn(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWUISkillBtn::~UCWUISkillBtn()
{
}

bool UCWUISkillBtn::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		Root = Cast<UCanvasPanel>(GetWidgetFromName(FName("Root")));
		ImgIcon = Cast<UImage>(GetWidgetFromName(FName("ImgIcon")));
		TxtName = Cast<UTextBlock>(GetWidgetFromName(FName("TxtName")));
	}

	return true;
}

void UCWUISkillBtn::BeginDestroy()
{
	Super::BeginDestroy();
}

bool UCWUISkillBtn::IsMyClientPawn(ACWPawn* InPawn)
{
	return InPawn ? InPawn->IsMyClientPawn() : false;
}

int32 UCWUISkillBtn::GetCurSelectSkillIdx(ACWPawn* InPawn)
{
	return InPawn ? InPawn->GetSelectSkillIdx() : INDEX_NONE;
}

bool UCWUISkillBtn::HasTheSkill(ACWPawn* InPawn, const int32 InSkillIdx)
{
	const UCWSkill* PawnSkill = InPawn ? InPawn->GetSkillByIdx(InSkillIdx) : nullptr;
	return (nullptr != PawnSkill);
}

bool UCWUISkillBtn::CanUseTheSkill(ACWPawn* InPawn, const int32 InSkillIdx)
{
	return InPawn ? InPawn->IsSkillCanUse(InSkillIdx) : false;
}

bool UCWUISkillBtn::IsPassivitySkill(ACWPawn* InPawn, const int32 InSkillIdx)
{
	const UCWSkill* PawnSkill = InPawn ? InPawn->GetSkillByIdx(InSkillIdx) : nullptr;
	return (PawnSkill && PawnSkill->IsPassivitySkill());
}

bool UCWUISkillBtn::HasEnoughEnergy(ACWPawn* InPawn, const int32 InSkillIdx)
{
	const UCWSkill* PawnSkill = InPawn ? InPawn->GetSkillByIdx(InSkillIdx) : nullptr;
	return (PawnSkill && PawnSkill->IsEnoughEnergy());
}
