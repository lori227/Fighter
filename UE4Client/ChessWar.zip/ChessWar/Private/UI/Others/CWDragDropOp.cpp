﻿
#include "CWDragDropOp.h"

#include "CWMap.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWPawnStart.h"
#include "CWGameState.h"
#include "CWUIIconItem.h"
#include "CWGameInstance.h"
#include "CWPlayerController.h"


UCWDragDropOp::UCWDragDropOp(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UCWDragDropOp::~UCWDragDropOp()
{
}

void UCWDragDropOp::Drop_Implementation(const FPointerEvent& PointerEvent)
{
	Super::Drop_Implementation(PointerEvent);

	CWG_LOG(">> %s::Drop.", *GetName());
}

void UCWDragDropOp::DragCancelled_Implementation(const FPointerEvent& PointerEvent)
{
	Super::DragCancelled_Implementation(PointerEvent);

	UCWUIIconItem* IconItem = Cast<UCWUIIconItem>(Payload);
	const FString DragItemNetPawnId = IsValidObject(IconItem) ? IconItem->GetNetPawnId() : TEXT("");
	if (DragItemNetPawnId.IsEmpty())
	{
		CWG_ERROR(">> %s::DragCancelled, DragItemNetPawnId is empty!", *GetName());
		return;
	}
	
	// 加入额外棋子(准备)
	FVector2D ScreenSpacePosition(PointerEvent.GetScreenSpacePosition());
	auto Callback = [IconItem, ScreenSpacePosition, DragItemNetPawnId]()
	{
		if (UWorld* const MyWorld = IsValid(IconItem) ? IconItem->GetWorld() : nullptr)
		{
			ACWPlayerController* MyPC = IconItem->GetLocalPC();
			ACWMap* MyMap = UCWFuncLib::GetActor<ACWMap>(MyWorld);
			ACWGameState* MyGameState = MyWorld->GetGameState<ACWGameState>();

			// 限制为准备状态才能操作
			if (!IsValid(MyPC) || !IsValid(MyMap) || !IsValid(MyGameState) || 
				(MyGameState->GetCurBattleState() != ECWBattleState::Ready))
			{
				return;
			}

			// 检测点击位置
			FHitResult HitResult;
			if (UCWFuncLib::GetHitResult(HitResult, ScreenSpacePosition, MyWorld))
			{
				if (ACWMapTile* HitTile = Cast<ACWMapTile>(HitResult.GetActor()))
				{
					if (ACWPawnStart* PawnStart = MyMap->GetPawnStartByTile(HitTile->Tile))
					{
						if (PawnStart->IsSameCampAndCtrl(MyPC->GetCampTag(), MyPC->GetCampControllerIndex()))
						{
							MyPC->ServerAddPawnToTile(DragItemNetPawnId, HitTile->Tile);
							CWG_WARNING(">> DragCancelled, [Callback-Ok], HitTile[%d] NetPawnId[%s].", HitTile->Tile, *DragItemNetPawnId);
							return;
						}
					}
					CWG_LOG(">> DragCancelled, [Callback-No], HitTile[%d] NetPawnId[%s].", HitTile->Tile, *DragItemNetPawnId);
				}
			}
		}
	};

	if (UWorld* const MyWorld = IconItem->GetWorld())
	{
		FTimerManager& TimerManager = MyWorld->GetTimerManager();
		//TimerManager.SetTimerForNextTick(Callback);
		FTimerHandle TimerHandle;
		TimerManager.SetTimer(TimerHandle, Callback, 0.1f, false);
	}
}

void UCWDragDropOp::Dragged_Implementation(const FPointerEvent& PointerEvent)
{
	Super::DragCancelled_Implementation(PointerEvent);

	//CWG_WARNING(">> %S::Dragged.", *GetName());
}
