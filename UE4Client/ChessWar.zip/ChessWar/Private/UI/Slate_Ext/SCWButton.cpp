﻿
#include "SCWButton.h"

void SCWButton::Construct(const FArguments& InArgs)
{

}
