﻿
#include "CWUIAttributeTipWidget.h"

#include "Button.h"
#include "TextBlock.h"
#include "RichTextBlock.h"

#include "CWCommonUtil.h"
#include "CWSkillDataStruct.h"

UCWUIAttributeTipWidget::UCWUIAttributeTipWidget(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}


UCWUIAttributeTipWidget::~UCWUIAttributeTipWidget()
{
}

void UCWUIAttributeTipWidget::InitTipWidget(UCWUserWidget* InWindow)
{
	check(InWindow);
	WinWidgetRef = InWindow;
	TrsSkillDesc = Cast<UCanvasPanel>(WinWidgetRef->GetWidgetFromName(FName("TrsSkillDesc")));
	TxtName = Cast<UTextBlock>(WinWidgetRef->GetWidgetFromName(FName("TxtName")));
	TxtDesc = Cast<URichTextBlock>(WinWidgetRef->GetWidgetFromName(FName("TxtDesc")));
}

void UCWUIAttributeTipWidget::SetActiveSkillId(TArray<int32>& skillID)
{
	ActiveSkillId = skillID;
}

void UCWUIAttributeTipWidget::SetPassivitySkillId(TArray<int32>& skillID)
{
	PassivitySkillId = skillID;
}

void UCWUIAttributeTipWidget::SetInnateSkillId(TArray<int32>& skillID)
{
	InnateSkillId = skillID;
}

bool UCWUIAttributeTipWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}
	if (IsCanInitCustom())
	{
		TWeakObjectPtr<UButton> SkillBtn1 = Cast<UButton>(GetWidgetFromName("BtnSkill1"));
		TWeakObjectPtr<UButton> SkillBtn2 = Cast<UButton>(GetWidgetFromName("BtnSkill2"));
		TWeakObjectPtr<UButton> SkillBtn3 = Cast<UButton>(GetWidgetFromName("BtnSkill3"));

		ADD_EVT_DELEGATE(SkillBtn1->OnHovered, this, &UCWUIAttributeTipWidget::OnActSkillButtonHovered, FName("OnActSkillButtonHovered"));
		ADD_EVT_DELEGATE(SkillBtn2->OnHovered, this, &UCWUIAttributeTipWidget::OnPassSkillButtonHovered, FName("OnPassSkillButtonHovered"));
		ADD_EVT_DELEGATE(SkillBtn3->OnHovered, this, &UCWUIAttributeTipWidget::OnInnSkillButtonHovered, FName("OnInnSkillButtonHovered"));
		ADD_EVT_DELEGATE(SkillBtn1->OnUnhovered, this, &UCWUIAttributeTipWidget::OnActSkillButtonUnHovered, FName("OnActSkillButtonUnHovered"));
		ADD_EVT_DELEGATE(SkillBtn2->OnUnhovered, this, &UCWUIAttributeTipWidget::OnPassSkillButtonUnHovered, FName("OnPassSkillButtonUnHovered"));
		ADD_EVT_DELEGATE(SkillBtn3->OnUnhovered, this, &UCWUIAttributeTipWidget::OnInnSkillButtonUnHovered, FName("OnInnSkillButtonUnHovered"));
	}
	return true;
}

void UCWUIAttributeTipWidget::BeginDestroy()
{
	Super::BeginDestroy();
}

void UCWUIAttributeTipWidget::UpdateAttrValue(ECWBattleProperty InProperty, int32 InCurValue /*= 0*/, int32 InMaxValue /*= 0*/)
{
	FString ProBarName;
	FString TxtAttrName;

	switch (InProperty) {
	case ECWBattleProperty::Health:
	{
		ProBarName = TEXT("BarHp");
		UTextBlock* TxtHp = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtHp")));
		if (nullptr != TxtHp) {
			const FString& NewText = FString::FromInt(InCurValue) + TEXT("/") + FString::FromInt(InMaxValue);
			TxtHp->SetText(FSTRING_TO_FTEXT(NewText));
		}
	}break;
	case ECWBattleProperty::Energy:
	{
		ProBarName = TEXT("BarSp");
		UTextBlock* TxtSp = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtSp")));
		if (nullptr != TxtSp) {
			const FString& NewText = FString::FromInt(InCurValue) + TEXT("/") + FString::FromInt(InMaxValue);
			TxtSp->SetText(FSTRING_TO_FTEXT(NewText));
		}
	}break;
	case ECWBattleProperty::Attack:
	{
		ProBarName = TEXT("BarAtk");
		TxtAttrName = TEXT("TxtATK");
	}break;
	case ECWBattleProperty::PhysicalDefence:
	{
		ProBarName = TEXT("BarDefP");
		TxtAttrName = TEXT("TxtDefP");
	}break;
	case ECWBattleProperty::MagicDefence:
	{
		ProBarName = TEXT("BarDefM");
		TxtAttrName = TEXT("TxtDefM");
	}break;
	case ECWBattleProperty::Talent:
	{
		ProBarName = TEXT("BarTAL");
		TxtAttrName = TEXT("TxtTAL");
	}break;
	case ECWBattleProperty::Move:
	{
		ProBarName = TEXT("BarMOV");
		TxtAttrName = TEXT("TxtMOV");
	}break;
	}

	// Update
	if (!ProBarName.IsEmpty()) {
		UProgressBar* ProBar = Cast<UProgressBar>(GetWidgetFromName(FSTRING_TO_FNAME(ProBarName)));
		if (nullptr != ProBar) {
			ProBar->SetPercent(UCWUIUtil::Divide_IntInt(InCurValue, InMaxValue));
		}
	}
	if (!TxtAttrName.IsEmpty()) {
		UTextBlock* TxtAttr = Cast<UTextBlock>(GetWidgetFromName(FSTRING_TO_FNAME(TxtAttrName)));
		if (nullptr != TxtAttr) {
			UCWUIUtil::SetTextBlock(TxtAttr, InCurValue);
		}
	}
}

int32 UCWUIAttributeTipWidget::ConversionResultValue(float InValue, float InMinValue /*= 0.f*/)
{
	float RetValue = (InValue >= KINDA_SMALL_NUMBER ? InValue + 0.5f : InValue - 0.5f);
	if (RetValue < InMinValue) {
		RetValue = InMinValue;
	}
	return (int32)RetValue;
}

void UCWUIAttributeTipWidget::OnActSkillButtonHovered()
{
	FCWSkillDataStruct* TempSkillData = nullptr;
	int index;
	for (index=0;index < ActiveSkillId.Num();index++)
	{
		if (ActiveSkillId[index]!=0)
			break;
	}
	TempSkillData = FCWCommonUtil::FindCSVRow<FCWSkillDataStruct>(TEXT("CWSkillDataTable"), ActiveSkillId[index]);
	TxtName->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillName));
	TxtDesc->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillDescForDoc));

	SetWidgetScreenPoint(TrsSkillDesc.Get());
	TrsSkillDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
}

void UCWUIAttributeTipWidget::OnActSkillButtonUnHovered()
{
	TrsSkillDesc->SetVisibility(ESlateVisibility::Collapsed);
}

void UCWUIAttributeTipWidget::OnPassSkillButtonHovered()
{
	FCWSkillDataStruct* TempSkillData = nullptr;
	int index;
	for (index = 0; index < PassivitySkillId.Num(); index++) {
		if (PassivitySkillId[index] != 0)
			break;
	}
	TempSkillData = FCWCommonUtil::FindCSVRow<FCWSkillDataStruct>(TEXT("CWSkillDataTable"), PassivitySkillId[index]);
	TxtName->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillName));
	TxtDesc->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillDescForDoc));

	SetWidgetScreenPoint(TrsSkillDesc.Get());
	TrsSkillDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
}

void UCWUIAttributeTipWidget::OnPassSkillButtonUnHovered()
{
	TrsSkillDesc->SetVisibility(ESlateVisibility::Collapsed);
}

void UCWUIAttributeTipWidget::OnInnSkillButtonHovered()
{
	FCWSkillDataStruct* TempSkillData = nullptr;
	int index;
	for (index = 0; index < InnateSkillId.Num(); index++) {
		if (InnateSkillId[index] != 0)
			break;
	}
	TempSkillData = FCWCfgUtils::GetTalentData(this, InnateSkillId[index]);
	TxtName->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillName));
	TxtDesc->SetText(FSTRING_TO_FTEXT(TempSkillData->SkillDescForDoc));

	SetWidgetScreenPoint(TrsSkillDesc.Get());
	TrsSkillDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
}

void UCWUIAttributeTipWidget::OnInnSkillButtonUnHovered()
{
	TrsSkillDesc->SetVisibility(ESlateVisibility::Collapsed);
}

void UCWUIAttributeTipWidget::NativeOnMouseEnter(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	OnShowAttrTip.ExecuteIfBound();
}

void UCWUIAttributeTipWidget::NativeOnMouseLeave(const FPointerEvent& InMouseEvent)
{
	OnHideAttrTip.ExecuteIfBound();
}
