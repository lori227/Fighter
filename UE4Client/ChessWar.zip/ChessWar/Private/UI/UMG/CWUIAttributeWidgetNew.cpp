﻿
#include "CWUIAttributeWidgetNew.h"

#include "Image.h"
#include "TextBlock.h"
#include "ProgressBar.h"
#include "HorizontalBox.h"

#include "CWComDef.h"
#include "CWPawn.h"
#include "CWComDef.h"
#include "CWMapTile.h"
#include "CWUIUtil.h"
#include "CWComDef.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"
#include "CWEventMgr.h"
#include "CWUIIconItem.h"
#include "CWGameState.h"
#include "CWWeatherData.h"
#include "CWDungeonTile.h"
#include "CWWeatherMgr.h"
#include "CWCfgManager.h"
#include "CWGameInstance.h"
#include "CWPawnDataStruct.h"
#include "CWClientConstData.h"
#include "CWBattleCalculate.h"
#include "CWPlayerController.h"
#include "CWSkeletalMeshActor.h"
#include "CWBattlePropertySet.h"
#include "CWProfessionDataStruct.h"
#include "CWRandomDungeonGenerator.h"
#include "CWDungeonRegionDataStruct.h"
#include "CWPawnBattlePropertyComponent.h"

UCWUIAttributeWidgetNew::UCWUIAttributeWidgetNew(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

UCWUIAttributeWidgetNew::~UCWUIAttributeWidgetNew()
{
}

bool UCWUIAttributeWidgetNew::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		//UIIconItem = Cast<UCWUIIconItem>(GetWidgetFromName(FName("UIIconItem")));
		TxtLv = Cast<UTextBlock>(GetWidgetFromName(FName("TxtLv")));
		TxtName = Cast<UTextBlock>(GetWidgetFromName(FName("TxtName")));
		TxtRace = Cast<UTextBlock>(GetWidgetFromName(FName("TxtRace")));
		ImgPro = Cast<UImage>(GetWidgetFromName(FName("ImgPro")));
		ImgWeapon = Cast<UImage>(GetWidgetFromName(FName("ImgWeapon")));
		ImgStaticIcon = Cast<UImage>(GetWidgetFromName(FName("ImgStaticIcon")));
		ImgDynamicIcon = Cast<UImage>(GetWidgetFromName(FName("ImgDynamicIcon")));
	}

	return true;
}

void UCWUIAttributeWidgetNew::BeginDestroy()
{
	Super::BeginDestroy();
}

void UCWUIAttributeWidgetNew::ShowWidget(bool bNewVisible, int32 ZOrder)
{
	Super::ShowWidget(bNewVisible, ZOrder);

	if (!bNewVisible)
	{
		bShowPreviewInfo = false;
		SetSelectCachePawn(nullptr, nullptr);
	}
}

bool UCWUIAttributeWidgetNew::UpdateAttrInfo(ACWPawn* InSelectPawn)
{
	if (nullptr == InSelectPawn || nullptr == InSelectPawn->BattleProperty)
	{
		return false;
	}

	if (bShowPreviewInfo)
	{	// 显示预览界面不在更新选定棋子
		return false;
	}

	const UCWPawnBattlePropertyComponent* PropertyComp = InSelectPawn->BattleProperty;
	const FCWBattlePropertySet& CurProperty = PropertyComp->GetCurPropertySet();
	bool bValidPawn = (CurProperty.GetPropertyByInt(ECWBattleProperty::UniqueId) >= 0);
	if (bValidPawn)
	{
		// 更新动态头像
		const bool bDynamicModelOK = UpdateDynamicIcon(InSelectPawn);

		// 更新属性显示
		SetSelectCachePawn(InSelectPawn);
		const FCWBattlePropertySet& BaseProperty = PropertyComp->GetPropertySetBase();
		const FCWBattlePropertySet& MaxProperty = PropertyComp->GetCurMaxTheoreticalPropertySet();

		float CurHp = CurProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		float MaxHp = MaxProperty.GetPropertyByFloat(ECWBattleProperty::Health);
		float CurSp = CurProperty.GetPropertyByFloat(ECWBattleProperty::Energy);
		float MaxSp = MaxProperty.GetPropertyByFloat(ECWBattleProperty::Energy);

		float CurAtk = CurProperty.GetPropertyByFloat(ECWBattleProperty::Attack);
		float CurPthysDef = CurProperty.GetPropertyByFloat(ECWBattleProperty::PhysicalDefence);
		float CurSpeed = CurProperty.GetPropertyByFloat(ECWBattleProperty::AttackSpeed);
		float CurMagicDef = CurProperty.GetPropertyByFloat(ECWBattleProperty::MagicDefence);
		float CurTalent = CurProperty.GetPropertyByFloat(ECWBattleProperty::Talent);
		float CurMove = CurProperty.GetPropertyByFloat(ECWBattleProperty::Move);

		const float BaseAttack = BaseProperty.GetPropertyByFloat(ECWBattleProperty::Attack);
		const float BasePhysicalDef = BaseProperty.GetPropertyByFloat(ECWBattleProperty::PhysicalDefence);
		const float BaseMagicDef = BaseProperty.GetPropertyByFloat(ECWBattleProperty::MagicDefence);

		// 天气影响
		FCWWeatherAffectData AffectData;
		const ACWGameState* const MyGS = GetCWGameState();
		const int32 WeatherIdx = IsValid(MyGS) ? MyGS->GetWeatherIdx() : INDEX_NONE;
		if (UCWWeatherMgr::IsValidWeatherIdx(WeatherIdx) && SelectPawn.IsValid())
		{
			FCWWeatherAffectData EmptyData;
			const FCWWeatherData* WeatherData = FCWCfgUtils::GetWeatherData(this, WeatherIdx);
			const int8 SelectedPawnDistType = SelectPawn->GetBattleDistType();
			if (SelectedPawnDistType == 0)
			{
				AffectData += WeatherData ? WeatherData->MeleeAffect : EmptyData;
			}else if (SelectedPawnDistType == 1)
			{
				AffectData += WeatherData ? WeatherData->RangedAffect : EmptyData;
			}
		}

		float AtkExt = AffectData.AttackValue;
		float PthysDefExt = AffectData.DefenceValue;
		float SpeedExt = 0;
		float MagicDefExt = AffectData.DefenceValue;
		float TalentExt = AffectData.TalentValue;
		float MoveExt = AffectData.MoveValue;

		// 地形影响 
		const float TerrainDefinceFactor = InSelectPawn->GetDefinceTerrainExtFactor();
		if (!FMath::IsNearlyZero(TerrainDefinceFactor))
		{
			const float PthysDefNum = BasePhysicalDef * TerrainDefinceFactor;
			const float MagicDefNum = BaseMagicDef * TerrainDefinceFactor;
			PthysDefExt += PthysDefNum;
			MagicDefExt += MagicDefNum;
			CurPthysDef += PthysDefNum;
			CurMagicDef += MagicDefNum;
		}

		// BUFF 影响器数据
		const TArray<FCWBattlePropertyAffectorData>& AffectorDatas = PropertyComp->GetArrayPropertyAffectorData();
		for (const FCWBattlePropertyAffectorData& AffectorData : AffectorDatas)
		{
			//if (IsSameConditioin(AffectorData, CastSkillContext))
			/*if (AffectorData.AffectType != ECWPropertyAffectorDataAffectType::Persistent)
			{
				continue;
			}*/
			if (AffectorData.AffectBattlePropertyType == ECWBattleProperty::Attack)
			{
				const float NewAddValue = AffectorData.GetResultValue(BaseAttack);
				AtkExt += NewAddValue;
				CurAtk += NewAddValue;
			}
			else if (AffectorData.AffectBattlePropertyType == ECWBattleProperty::PhysicalDefence)
			{
				const float NewAddValue = AffectorData.GetResultValue(BasePhysicalDef);
				PthysDefExt += NewAddValue;
				CurPthysDef += NewAddValue;
			}
			else if (AffectorData.AffectBattlePropertyType == ECWBattleProperty::MagicDefence)
			{
				const float NewAddValue = AffectorData.GetResultValue(BaseMagicDef);
				MagicDefExt += NewAddValue;
				CurMagicDef += NewAddValue;
			}
		}

		// 更新属性值显示
		TArray<int32> NewMaxList = GetAttrMaxValueList(this);
		auto NewMaxValue = [&NewMaxList](const int32 InIdx)
		{
			return NewMaxList.IsValidIndex(InIdx) ? NewMaxList[InIdx] : 100;
		};
		const float MinExtraValue = -999999.f;
		const int32 NewAtkExt =		ConversionResultValue(AtkExt, MinExtraValue);
		const int32 NewPthysDefExt =ConversionResultValue(PthysDefExt, MinExtraValue);
		const int32 NewSpeedExt =	ConversionResultValue(SpeedExt, MinExtraValue);
		const int32 NewMagicDefExt =ConversionResultValue(MagicDefExt, MinExtraValue);
		const int32 NewTalentExt =  ConversionResultValue(TalentExt, MinExtraValue);
		const int32 NewMoveExt =	ConversionResultValue(MoveExt, MinExtraValue);
		UpdateAttrValue(ECWBattleProperty::Health,			ConversionResultValue(CurHp, 0.f),		ConversionResultValue(MaxHp, 0.f));
		UpdateAttrValue(ECWBattleProperty::Energy,			ConversionResultValue(CurSp, 0.f),		ConversionResultValue(MaxSp, 0.f));
		UpdateAttrValue(ECWBattleProperty::Attack,			ConversionResultValue(CurAtk, 0.f),		NewMaxValue(0),	NewAtkExt);
		UpdateAttrValue(ECWBattleProperty::PhysicalDefence, ConversionResultValue(CurPthysDef, 0.f),NewMaxValue(1), NewPthysDefExt);
		UpdateAttrValue(ECWBattleProperty::MagicDefence,	ConversionResultValue(CurMagicDef, 0.f),NewMaxValue(2), NewMagicDefExt);
		UpdateAttrValue(ECWBattleProperty::Talent,			ConversionResultValue(CurTalent, 0.f),	NewMaxValue(3),	NewTalentExt);
		UpdateAttrValue(ECWBattleProperty::Move,			ConversionResultValue(CurMove, 0.f),	NewMaxValue(4), NewMoveExt);
		UpdateAttrValue(ECWBattleProperty::AttackSpeed,		ConversionResultValue(CurSpeed, 0.f),	NewMaxValue(5),	NewSpeedExt);

		const FString& InName = InSelectPawn->GetDisplayName();
		const FString& InRaceKey = TEXT("TxtRace_") + InSelectPawn->GetRaceId();
		const FString& InRaceName = FCWCfgUtils::GetLanguageString(this, InRaceKey);
		const FString& InWeaponId = InSelectPawn->GetWeaponId();
		const FCWProfessionDataStruct* ProfessionData = InSelectPawn->GetProfessionData();
		const FString& ProIconId = ProfessionData ? ProfessionData->ProIconId : UICommIconId;
		TxtName->SetText(FSTRING_TO_FTEXT(InName));
		TxtRace->SetText(FSTRING_TO_FTEXT(InRaceName));
		UCWUIUtil::SetImageTexture(ImgPro.Get(), ProIconId);
		UCWUIUtil::SetImageTexture(ImgWeapon.Get(), InWeaponId);

		if (!bDynamicModelOK)
		{
			UCWUIUtil::SetImageTexture(ImgStaticIcon.Get(), ProIconId);
		}
		ImgStaticIcon->SetVisibility(bDynamicModelOK ? ESlateVisibility::Collapsed : ESlateVisibility::Visible);
		ImgDynamicIcon->SetVisibility(bDynamicModelOK ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);

		UpdateSkillAndBuffList();
		UpdateSkillStateDesc();

		/** Debug Info */
#if !UE_BUILD_SHIPPING
		if (ACWPlayerController* MyLocalPC = GetLocalPC())
		{
			MyLocalPC->CWG_DebugPawn(InSelectPawn->GetPawnUniqueIdx());
		}
#endif
	}
	return bValidPawn;
}

bool UCWUIAttributeWidgetNew::UpdatePreviewInfo(ACWPawn* InSelectPawn, ACWPawn* InTargetPawn)
{
	if (nullptr == InSelectPawn || nullptr == InTargetPawn)
	{
		return false;
	}

	FFightPreviewData SelectData = FFightPreviewData();
	FFightPreviewData TargetData = FFightPreviewData();
	if (UCWUIUtil::GetFightPreviewData(InSelectPawn, InTargetPawn, SelectData, TargetData))
	{
		SetSelectCachePawn(InSelectPawn, InTargetPawn);
		UpdateSkillAndBuffList();
	}

	return false;
}

int32 UCWUIAttributeWidgetNew::ConversionResultValue(float InValue, float InMinValue /*= 0.f*/)
{
	float RetValue = (InValue >= KINDA_SMALL_NUMBER ? InValue + 0.5f : InValue - 0.5f);
	if (RetValue < InMinValue)
	{
		RetValue = InMinValue;
	}
	return (int32)RetValue;
}

void UCWUIAttributeWidgetNew::UpdateAttrValue(ECWBattleProperty InProperty, int32 InCurValue /*= 0*/, int32 InMaxValue /*= 0*/, int32 InExtValue /*= 0*/)
{
	FString ProBarName;
	FString TxtAttrName;
	FString TxtAttr_ExtName;
	switch (InProperty)
	{
	case ECWBattleProperty::Health:
	{
		ProBarName = TEXT("BarHpCur");
		UTextBlock* TxtHp = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtHp")));
		if (nullptr != TxtHp)
		{
			const FString& NewText = FString::FromInt(InCurValue) + TEXT("/") + FString::FromInt(InMaxValue);
			TxtHp->SetText(FSTRING_TO_FTEXT(NewText));
		}
	}break;
	case ECWBattleProperty::Energy:
	{
		ProBarName = TEXT("BarSpCur");
		UTextBlock* TxtSp = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtSp")));
		if (nullptr != TxtSp)
		{
			const FString& NewText = FString::FromInt(InCurValue) + TEXT("/") + FString::FromInt(InMaxValue);
			TxtSp->SetText(FSTRING_TO_FTEXT(NewText));
		}
	}break;
	case ECWBattleProperty::Attack:
	{
		ProBarName = TEXT("BarAtk");
		TxtAttrName = TEXT("TxtATK");
		TxtAttr_ExtName = TEXT("TxtATK_Ext");
	}break;
	case ECWBattleProperty::PhysicalDefence:
	{
		ProBarName = TEXT("BarDefP");
		TxtAttrName = TEXT("TxtDefP");
		TxtAttr_ExtName = TEXT("TxtDefP_Ext");
	}break;
	case ECWBattleProperty::MagicDefence:
	{
		ProBarName = TEXT("BarDefM");
		TxtAttrName = TEXT("TxtDefM");
		TxtAttr_ExtName = TEXT("TxtDefM_Ext");
	}break;
	case ECWBattleProperty::Talent:
	{
		ProBarName = TEXT("BarTAL");
		TxtAttrName = TEXT("TxtTAL");
		TxtAttr_ExtName = TEXT("TxtTAL_Ext");
	}break;
	case ECWBattleProperty::Move:
	{
		ProBarName = TEXT("BarMOV");
		TxtAttrName = TEXT("TxtMOV");
		TxtAttr_ExtName = TEXT("TxtMOV_Ext");
	}break;
	}

	// Update
	if (!ProBarName.IsEmpty())
	{
		UProgressBar* ProBar = Cast<UProgressBar>(GetWidgetFromName(FSTRING_TO_FNAME(ProBarName)));
		if (nullptr != ProBar)
		{
			ProBar->SetPercent(UCWUIUtil::Divide_IntInt(InCurValue, InMaxValue));
		}
	}
	if (!TxtAttrName.IsEmpty())
	{
		UTextBlock* TxtAttr = Cast<UTextBlock>(GetWidgetFromName(FSTRING_TO_FNAME(TxtAttrName)));
		if (nullptr != TxtAttr)
		{
			UCWUIUtil::SetTextBlock(TxtAttr, InCurValue, InExtValue);
		}
	}
	if (!TxtAttr_ExtName.IsEmpty())
	{
		UTextBlock* TxtAttr_Ext = Cast<UTextBlock>(GetWidgetFromName(FSTRING_TO_FNAME(TxtAttr_ExtName)));
		if (nullptr != TxtAttr_Ext)
		{
			UCWUIUtil::SetTextBlock_Color(TxtAttr_Ext, InExtValue);
		}
	}
}

bool UCWUIAttributeWidgetNew::IsMyOwnerPawn() const
{
	return SelectPawn.IsValid() ? SelectPawn->IsMyClientPawn() : false;
}

void UCWUIAttributeWidgetNew::SetSelectCachePawn(ACWPawn* InSelectPawn, ACWPawn* InTargetPawn)
{
	SelectPawn = InSelectPawn ? TWeakObjectPtr<ACWPawn>(InSelectPawn) : nullptr;
	TargetPawn = (InSelectPawn && InTargetPawn) ? TWeakObjectPtr<ACWPawn>(InTargetPawn) : nullptr;
}

TArray<int32> UCWUIAttributeWidgetNew::GetAttrMaxValueList(const UObject* InWorldContext)
{
	TArray<int32> RetMaxList;
	const FCWClientConstData* ConstData = FCWCfgUtils::GetConstData(InWorldContext, FCWCfgKey::CommConst, TEXT("AttrMaxValue"));
	if (nullptr != ConstData)
	{
		RetMaxList = FCWCfgUtils::FString_To_Array_Int32(ConstData->Param);
	}
	return RetMaxList;
}

bool UCWUIAttributeWidgetNew::UpdateDynamicIcon(ACWPawn* InPawn)
{
	if (nullptr != InPawn && InPawn->IsPawnType(ECWPawnType::Character))
	{
		const FString& NewSMAssetId = InPawn->GetDisplayModelAssetId();
		const FString& NewAnimAssetId = InPawn->GetDisplayModelAnimId();
		const FString& NewAnimAnimClassId = InPawn->GetDisplayModelAnimInstClassId();
		if (!NewSMAssetId.IsEmpty() && !NewAnimAssetId.IsEmpty())
		{
			auto InGetPredicate = [](const ACWSkeletalMeshActor* InActor) -> bool
			{
				return InActor->Tags.Num() == 0;
			};
			ACWSkeletalMeshActor* DisplayModelActor = UCWFuncLib::GetActor<ACWSkeletalMeshActor>(this, InGetPredicate);
			if (nullptr != DisplayModelActor)
			{
				return DisplayModelActor->PlayAnimSequence(NewSMAssetId, NewAnimAnimClassId, NewAnimAssetId);
			}
		}
	}
	return false;
}

void UCWUIAttributeWidgetNew::UpdateSkillAndBuffList()
{
	if (!SelectPawn.IsValid())
	{
		CWG_WARNING(">> %s::UpdateSkillList, SelectPawn is Null!", *GetName());
		return;
	}
	if (IsMyOwnerPawn())
	{	// 确保当前选择技能可用
		SelectPawn->RecalcSelectSkillIdx();
	}
	UpdateSkillState();
	UpdateBuffState();
}

ACWPawn* UCWUIAttributeWidgetNew::GetSelectPawn() const
{
	return SelectPawn.Get();
}

ACWPawn* UCWUIAttributeWidgetNew::GetTargetPawn() const
{
	return TargetPawn.Get(true);
}

/*void UCWUIAttributeWidgetNew::UpdateSkillState()
{
	ACWPawn* MySelectPawn = SelectPawn.Get();
	UHorizontalBox* TrsSkillList = Cast<UHorizontalBox>(GetWidgetFromName(TEXT("TrsSkillList")));
	if (nullptr != MySelectPawn && MySelectPawn->IsPawnType(ECWPawnType::Character))
	{
		TrsSkillList->SetVisibility(ESlateVisibility::Visible);
		for (int32 i = 1; i <= 3; ++i)
		{
			const FString& SkillBtnName = TEXT("BtnSkill") + INT_TO_FSTRING(i);
			UUserWidget* TrsSkillList = Cast<UUserWidget>(GetWidgetFromName(FSTRING_TO_FNAME(SkillBtnName)));
			if (nullptr != TrsSkillList)
			{
				UFunction* BtnFunc = TrsSkillList->FindFunction(TEXT("UpdateData"));
				if (nullptr != BtnFunc)
				{
					FStructOnScope Params(BtnFunc);
					//fillParam(L, offset, BtnFunc, Params.GetStructMemory());
					{
						TrsSkillList->ProcessEvent(BtnFunc, nullptr);
					}
				}
			}
		}
	}
	else
	{
		TrsSkillList->SetVisibility(ESlateVisibility::Collapsed);
	}
}*/
