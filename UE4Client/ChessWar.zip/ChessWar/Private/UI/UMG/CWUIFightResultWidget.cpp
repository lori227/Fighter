﻿
#include "CWUIFightResultWidget.h"

#include "CWButton.h"
#include "CWFuncLib.h"
#include "CWGameState.h"
#include "CWUIManager.h"
#include "CWPlayerController.h"
#include "AkGameplayStatics.h"


UCWUIFightResultWidget::UCWUIFightResultWidget(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bForcedCaptureMouseEvt = true;
}

UCWUIFightResultWidget::~UCWUIFightResultWidget()
{
}

bool UCWUIFightResultWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	// Init
	BtnSetting = Cast<UCWButton>(GetWidgetFromName("BtnSetting"));
	BtnHome = Cast<UCWButton>(GetWidgetFromName("BtnHome"));
	BtnEndGame = Cast<UCWButton>(GetWidgetFromName("BtnEndGame"));
	BtnRestart = Cast<UCWButton>(GetWidgetFromName("BtnRestart"));
	
	// Bind Button delegate
	ADD_EVT_DELEGATE(BtnSetting->OnClicked, this, &UCWUIFightResultWidget::OnClickedBtnSetting, FName("OnClickedBtnSetting"));
	ADD_EVT_DELEGATE(BtnHome->OnClicked, this, &UCWUIFightResultWidget::OnClickedBtnHome, FName("OnClickedBtnHome"));
	ADD_EVT_DELEGATE(BtnEndGame->OnClicked, this, &UCWUIFightResultWidget::OnClickedBtnEndGame, FName("OnClickedBtnEndGame"));
	ADD_EVT_DELEGATE(BtnRestart->OnClicked, this, &UCWUIFightResultWidget::OnClickedBtnRestart, FName("OnClickedBtnRestart"));

	return true;
}

void UCWUIFightResultWidget::BeginDestroy()
{
	Super::BeginDestroy();
}

ECWBattleResult UCWUIFightResultWidget::GetFightResult() const
{
	ACWGameState* GameState = GetCWGameState();
	return GameState ? GameState->GetLocalPlayerFightResult() : ECWBattleResult::Draw;
}

void UCWUIFightResultWidget::OnClickedBtnSetting()
{
	/*if (UCWUIManager* UIMgr = GetUIMgr())
	{
		UIMgr->OpenUI(FUIKey::UISetting, 50);
	}*/
	UCWUIManager::LuaOpenUI(this, "OPEN_GAMESETTING");
}

void UCWUIFightResultWidget::OnClickedBtnHome()
{

}

void UCWUIFightResultWidget::OnClickedBtnEndGame()
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		//LocalPC->ServerEndGame();
		//UCWFuncLib::CWGOpenLevel(LocalPC, TEXT("Login"));
		UCWFuncLib::CWGQuitGame(EQuitPreference::Quit, this, LocalPC);
	}
}

void UCWUIFightResultWidget::OnClickedBtnRestart()
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->RefreshLevelInClient();
	}
}
