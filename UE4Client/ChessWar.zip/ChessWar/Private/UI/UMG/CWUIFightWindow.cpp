﻿
#include "CWUIFightWindow.h"

#include "Image.h"
#include "Button.h"
#include "Overlay.h"
#include "TextBlock.h"
#include "Math/Color.h"
#include "HorizontalBox.h"
#include "WidgetAnimation.h"
#include "Styling/SlateColor.h"
#include "Components/CanvasPanel.h"
#include "Kismet/KismetMathLibrary.h"
#include "WidgetBlueprintGeneratedClass.h"
#include "Blueprint/WidgetLayoutLibrary.h"

#include "CWMap.h"
#include "CWPawn.h"
#include "CWUIUtil.h"
#include "CWButton.h"
#include "CWCfgUtils.h"
#include "CWFuncLib.h"
#include "CWMapTile.h"
#include "CWUIManager.h"
#include "CWGameState.h"
#include "CWSluaManager.h"
#include "UICommConfirm.h"
#include "CWDungeonTile.h"
#include "CWDungeonItem.h"
#include "CWUIPawnWidget.h"
#include "Public/LuaState.h"
#include "CWUIConfigRoleCtrl.h"
#include "CWPlayerController.h"
#include "CWBattlePropertySet.h"
#include "CWUIAttackPreviewCtrl.h"
#include "CWUIAttributeWidgetNew.h"
#include "CWRandomDungeonGenerator.h"


UCWUIFightWindow::UCWUIFightWindow(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	bForcedCaptureMouseEvt = true;

	RemainTime = (int32)INVALID_TIME_VALUE;
}

UCWUIFightWindow::~UCWUIFightWindow()
{
}

bool UCWUIFightWindow::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		// Init Widget Map
		TrsRoleAttr = Cast<UCWUIAttributeWidgetNew>(GetWidgetFromName("TrsRoleAttr"));
		
		TrsSceneTileDesc = Cast<UCWUserWidget>(GetWidgetFromName("TrsSceneTileDesc"));
		TrsWeatherDesc = Cast<UCWUserWidget>(GetWidgetFromName("TrsWeatherDesc"));

		TrsWait = Cast<UCanvasPanel>(GetWidgetFromName("TrsWait"));
		TrsFight = Cast<UCanvasPanel>(GetWidgetFromName("TrsFight"));
		TrsComm = Cast<UCanvasPanel>(GetWidgetFromName("TrsComm"));
		TrsSetting = Cast<UCanvasPanel>(GetWidgetFromName("TrsSetting"));
		TrsReady = Cast<UCanvasPanel>(GetWidgetFromName("TrsReady"));
		TrsMapTile = Cast<UCanvasPanel>(GetWidgetFromName("TrsMapTile"));
		TrsWavedLand = Cast<UCanvasPanel>(GetWidgetFromName("TrsWavedLand"));

		TxtWavedLand = Cast<UTextBlock>(GetWidgetFromName("TxtWavedLand"));
		TxtNextWeather = Cast<UTextBlock>(GetWidgetFromName("TxtNextWeather"));

		TxtMapTile = Cast<UTextBlock>(GetWidgetFromName("TxtMapTile"));
		TxtPlayerMsg = Cast<UTextBlock>(GetWidgetFromName("TxtPlayerMsg"));
		TrsShiftSwitch = Cast<UWidget>(GetWidgetFromName("TrsShiftSwitch"));

		TxtCompNum = Cast<UTextBlock>(GetWidgetFromName("TxtCompNum"));
		TxtEnermyNum = Cast<UTextBlock>(GetWidgetFromName("TxtEnermyNum"));
		ImgComp = Cast<UImage>(GetWidgetFromName("ImgComp"));
		ImgEnermy = Cast<UImage>(GetWidgetFromName("ImgEnermy"));

		// Ready
		BtnStartFight = Cast<UCWButton>(GetWidgetFromName("BtnStartFight"));
		TrsAtrrTip = Cast<UCWUIAttributeTipWidget>(GetWidgetFromName("TrsAtrrTip"));

		// Round
		BtnEndRound = Cast<UCWButton>(GetWidgetFromName("BtnEndRound"));
		ImgCamp = Cast<UImage>(GetWidgetFromName("ImgCamp"));
		ImgTimeRadius = Cast<UImage>(GetWidgetFromName("ImgTimeRadius"));
		TxtCampMain = Cast<UTextBlock>(GetWidgetFromName("TxtCampMain"));
		TxtBtnRound = Cast<UTextBlock>(GetWidgetFromName("TxtBtnRound"));
		TxtRemainTime = Cast<UTextBlock>(GetWidgetFromName("TxtRemainTime"));
		TxtRoundNumTip = Cast<UTextBlock>(GetWidgetFromName("TxtRoundNumTip"));
		TxtRoundNum = Cast<UTextBlock>(GetWidgetFromName("TxtRoundNum"));

		// Weather
		BtnCurWeather = Cast<UCWButton>(GetWidgetFromName("BtnCurWeather"));
		BtnNextWeather = Cast<UCWButton>(GetWidgetFromName("BtnNextWeather"));
		TxtWeather = Cast<UTextBlock>(GetWidgetFromName("TxtWeather"));

		// Speed
		BtnSpeed = Cast<UCWButton>(GetWidgetFromName("BtnSpeed"));
		TxtSpeed = Cast<UTextBlock>(GetWidgetFromName("TxtSpeed"));

		// Setting
		BtnSetting = Cast<UCWButton>(GetWidgetFromName("BtnSetting"));

		// Init Anim Map
		WidgetAnimations.Empty();
		UWidgetBlueprintGeneratedClass* WidgetClass = GetWidgetTreeOwningClass();
		if (nullptr != WidgetClass)
		{
			for (int i = 0; i < WidgetClass->Animations.Num(); ++i)
			{
				// AnimName 实际比蓝图编辑好动画多了后缀_INST
				// PS: Blueprint:TogglePlayerMsgAnim -> AnimName:TogglePlayerMsgAnim_INST
				FString AnimName = WidgetClass->Animations[i]->GetName();
				WidgetAnimations.Add(AnimName, WidgetClass->Animations[i]);
			}
		}

		// Bind Button delegate
		ADD_EVT_DELEGATE(BtnStartFight->OnClicked, this, &UCWUIFightWindow::OnClickedBtnStartFight, FName("OnClickedBtnStartFight"));
		ADD_EVT_DELEGATE(BtnEndRound->OnClicked, this, &UCWUIFightWindow::OnClickedBtnEndRound, FName("OnClickedBtnEndRound"));
		ADD_EVT_DELEGATE(BtnSpeed->OnClicked, this, &UCWUIFightWindow::OnClickedBtnSpeed, FName("OnClickedBtnSpeed"));
		ADD_EVT_DELEGATE(BtnSetting->OnClicked, this, &UCWUIFightWindow::OnClickedBtnSetting, FName("OnClickedBtnSetting"));

		ADD_EVT_DELEGATE(BtnCurWeather->OnHovered, this, &UCWUIFightWindow::OnHoveredBtnCurWeather, FName("OnHoveredBtnCurWeather"));
		ADD_EVT_DELEGATE(BtnCurWeather->OnUnhovered, this, &UCWUIFightWindow::OnUnhoveredBtnCurWeather, FName("OnUnhoveredBtnCurWeather"));
		ADD_EVT_DELEGATE(BtnNextWeather->OnHovered, this, &UCWUIFightWindow::OnHoveredBtnNextWeather, FName("OnHoveredBtnNextWeather"));
		ADD_EVT_DELEGATE(BtnNextWeather->OnUnhovered, this, &UCWUIFightWindow::OnUnhoveredBtnNextWeather, FName("OnUnhoveredBtnNextWeather"));

		// Init Delegate
		if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			ADD_EVT_DELEGATE(EvtMgr->OnRoundRemainTimeChange, this, &UCWUIFightWindow::OnRoundRemainTimeChange, FName("OnRoundRemainTimeChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnReadyRemainTimeChange, this, &UCWUIFightWindow::OnRoundRemainTimeChange, FName("OnRoundRemainTimeChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this, &UCWUIFightWindow::OnBattleStateChanged, FName("OnBattleStateChanged"));
			ADD_EVT_DELEGATE(EvtMgr->OnCameraArmAgree90, this, &UCWUIFightWindow::OnCameraArmAgree90, FName("OnCameraArmAgree90"));
			ADD_EVT_DELEGATE(EvtMgr->OnPlayerPawnActionEndClient, this, &UCWUIFightWindow::OnPlayerPawnActionEnd, FName("OnPlayerPawnActionEnd"));
			ADD_EVT_DELEGATE(EvtMgr->OnRoundIndexChangeInClient, this, &UCWUIFightWindow::OnRoundIndexChange, FName("OnRoundIndexChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnRoundCampChange, this, &UCWUIFightWindow::OnRoundCampChange, FName("OnRoundCampChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnPlayerSendMessage, this, &UCWUIFightWindow::OnPlayerSendMessage, FName("OnPlayerSendMessage"));
			ADD_EVT_DELEGATE(EvtMgr->OnGamePlayerRateChange, this, &UCWUIFightWindow::OnGamePlayerRateChange, FName("OnGamePlayerRateChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnRoleReadyStateChange, this, &UCWUIFightWindow::OnRoleReadyStateChange, FName("OnRoleReadyStateChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnWeatherIdxChange, this, &UCWUIFightWindow::OnWeatherIdxChange, FName("OnWeatherIdxChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnNextWeatherIdxChange, this, &UCWUIFightWindow::OnNextWeatherIdxChange, FName("OnNextWeatherIdxChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnTimePhasesChange, this, &UCWUIFightWindow::OnTimePhasesChange, FName("OnTimePhasesChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnCampANumChange, this, &UCWUIFightWindow::OnCampANumChange, FName("OnCampANumChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnCampBNumChange, this, &UCWUIFightWindow::OnCampBNumChange, FName("OnCampBNumChange"));
			ADD_EVT_DELEGATE(EvtMgr->OnPlayerDataArrayChange, this, &UCWUIFightWindow::OnPlayerDataArrayChange, FName("OnPlayerDataArrayChange"));
		}
	}

	return true;
}

void UCWUIFightWindow::BeginDestroy()
{
	if (IsCanDestroyCustom())
	{
		RemoveAttackPreviewCtrl();

		if (UCWEventMgr* EvtMgr = EVT_MGR(this))
		{
			REMOVE_EVT_DELEGATE(EvtMgr->OnRoundRemainTimeChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnReadyRemainTimeChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnBattleStateChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnCameraArmAgree90, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnPlayerPawnActionEndClient, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnRoundIndexChangeInClient, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnRoundCampChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnPlayerSendMessage, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnGamePlayerRateChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnRoleReadyStateChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnWeatherIdxChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnNextWeatherIdxChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnTimePhasesChange, this);
			REMOVE_EVT_DELEGATE(EvtMgr->OnPlayerDataArrayChange, this);
		}

		UWorld* MyWorld = GetWorld();
		if (IsValidObject(MyWorld))
		{
			FTimerManager& TimerManager = MyWorld->GetTimerManager();
			TimerManager.ClearTimer(AnimBattleStart);
			TimerManager.ClearTimer(AnimSwitchRound);
		}
	}

	Super::BeginDestroy();
}

void UCWUIFightWindow::ShowWidgetParts(EUIFightPart InPart, bool bNewVisible)
{
	UWidget* TargetWidget = nullptr;
	switch (InPart)
	{
	case EUIFightPart::Wait:			{ TargetWidget = TrsWait.Get(); }break;
	case EUIFightPart::Fight:			{ TargetWidget = TrsFight.Get(); }break;
	case EUIFightPart::Comm:			{ TargetWidget = TrsComm.Get(); }break;
	case EUIFightPart::Ready:			{ TargetWidget = TrsReady.Get(); }break;
	case EUIFightPart::RoleAttr:		{ TargetWidget = TrsRoleAttr.Get(); }break;
	//case EUIFightPart::TerrainInfo:	{ TargetWidget = TrsMapTile.Get(); }break;
	//case EUIFightPart::LandLayer:		{ TargetWidget = TrsWavedLand.Get(); }break;
	case EUIFightPart::RefreshMap:		{ TargetWidget = TrsSetting.Get(); }break;
	}

	if (IsValid(TargetWidget))
	{
		if (UCWUserWidget* CWUserWidget = Cast<UCWUserWidget>(TargetWidget))
		{	// 特殊处理
			CWUserWidget->ShowWidget(bNewVisible);
		}
		else
		{
			ESlateVisibility Visible = bNewVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
			TargetWidget->SetVisibility(Visible);
		}
	}
	//CWG_WARNING(">> %s::ShowWidgetParts, Part[%d] bNewVisible[%s].", *GetName(), (int32)Part, *BOOL_TO_FSTRING(bNewVisible));
}

void UCWUIFightWindow::OnClickPawn(ACWPawn* InClickPawn)
{
	bool bUpdateOk = TrsRoleAttr->UpdateAttrInfo(InClickPawn);

	//ShowWidgetParts(EUIFightPart::TerrainInfo, false);
	ShowWidgetParts(EUIFightPart::RoleAttr, true);
}

void UCWUIFightWindow::OnClickTargetPawn(ACWPawn* InSelectPawn, ACWPawn* InTargetPawn)
{
	//bool bUpdateOk = TrsRoleAttr->UpdatePreviewInfo(SelectPawn, TargetPawn);
	//ShowWidgetParts(EUIFightPart::PreviewAtrr, bUpdateOk);

	//CWG_LOG(">> %s::OnClickTargetPawn, .....", *GetName());
}

void UCWUIFightWindow::OnClickMapTile(ACWMapTile* InSelected)
{
	//ShowWidgetParts(EUIFightPart::PlayerAttr, false);

	int32 TileLayer = 0;
	bool bNeedShowTerrain = false;
	if (IsValid(InSelected) && InSelected->GetTile() > -1)
	{
		ACWMap* MyMap = IsValid(InSelected) ? InSelected->GetParantMap() : nullptr;
		ACWRandomDungeonGenerator* Generator = IsValid(InSelected) ? InSelected->GetDungeonGenerator() : nullptr;
		if (nullptr != MyMap && nullptr != Generator)
		{
			if (ACWDungeonTile* DungeonTile = Generator->GetDungeonTile(InSelected->GetTile()))
			{
				// 地形加成
				const FCWDungeonRegionDataStruct* DungeonData = Generator->GetDungeonRegionData(DungeonTile->RegionId);
				const float TerrainDefinceFactor = DungeonData ? DungeonData->TerrainDefinceFactor : 0.f;
				if (!FMath::IsNearlyZero(TerrainDefinceFactor))
				{
					const FString NewTxt = GetTerrainPropertyTxt(TerrainDefinceFactor);
					TxtMapTile->SetText(FSTRING_TO_FTEXT(NewTxt));
					bNeedShowTerrain = true;
				}
				// 地势层数
				TileLayer = Generator->GetGridLayerByTile(InSelected->GetTile());
				if (TileLayer != 0)
				{
					const FString& TxtKey = (TileLayer > 0) ? TEXT("UI_HeightLand_Txt") : TEXT("UI_LowLand_Txt");
					const FString& TextParam = FCWCfgUtils::GetLanguageString(this, TxtKey);
					const FString& TextWord = TextParam.Replace(TEXT("{0}"), *INT_TO_FSTRING(TileLayer));
					TxtWavedLand->SetText(FSTRING_TO_FTEXT(TextWord));
				}
			}
		}
	}

	ShowWidgetParts(EUIFightPart::LandLayer, (TileLayer != 0));
	ShowWidgetParts(EUIFightPart::TerrainInfo, bNeedShowTerrain);
	//CWG_LOG(">> %s::OnClickMapTile, .....", *GetName());
}

void UCWUIFightWindow::OnShowPreviewCtrl(ACWPawn* InCasterPawn, ACWPawn* InTargetPawn,
	const FFightPreviewData& InCasterData, const FFightPreviewData& InTargetData)
{
	if (nullptr != AttackPreviewCtrl)
	{
		AttackPreviewCtrl->UpdatePreviewInfo(InCasterPawn, InTargetPawn, InCasterData, InTargetData);
	}
}

void UCWUIFightWindow::OnHidePreviewCtrl()
{
	if (nullptr != AttackPreviewCtrl)
	{
		AttackPreviewCtrl->HidePreviewInfo();
	}
}

void UCWUIFightWindow::OnBattleStateChanged(ECWBattleState OldState, ECWBattleState CurState)
{
	EUIInputMode InputMode = EUIInputMode::None;
	if (CurState == ECWBattleState::Ready)
	{
		InputMode = EUIInputMode::GameAndUI;

		ShowWidgetParts(EUIFightPart::Wait, false);
		ShowWidgetParts(EUIFightPart::Comm, true);
		ShowWidgetParts(EUIFightPart::Ready, true);
		ShowWidgetParts(EUIFightPart::RefreshMap, true);

		OnBeginReadyState();
	}else if (CurState == ECWBattleState::Fighting)
	{
		InputMode = EUIInputMode::GameAndUI;

		ShowWidgetParts(EUIFightPart::Ready, false);
		ShowWidgetParts(EUIFightPart::Fight, true);

		OnBeginFightingState();
	}else if (CurState == ECWBattleState::Settlement)
	{
		InputMode = EUIInputMode::UIOnly;

		OnBeginSettlementState();
	}

	// Update game input mode
	if (UCWUIManager* UIMgr = UI_MGR(this))
	{
		UIMgr->SetInputMode(InputMode);
	}
}

void UCWUIFightWindow::OnRoundRemainTimeChange(float InTime)
{
	if (RemainTime == (int32)InTime)
	{
		return;
	}

	// 更新倒计时文本
	RemainTime = (int32)InTime;
	FString NewTxt = UCWUIUtil::ToTimeFormat(RemainTime);
	TxtRemainTime->SetText(FSTRING_TO_FTEXT(NewTxt));

	// 更新倒计时圆形百分比
	ACWGameState* MyGameState = GetCWGameState();
	if (nullptr != MyGameState)
	{
		const ECWBattleState BattleState = MyGameState ? MyGameState->GetCurBattleState() : ECWBattleState::None;
		float MaxTime = (BattleState == ECWBattleState::Ready) ? MyGameState->GetMaxReadyTime() :
						(BattleState == ECWBattleState::Fighting) ? MyGameState->GetMaxActionTime() : INVALID_TIME_VALUE;
		if (!FMath::IsNearlyEqual(MaxTime, INVALID_TIME_VALUE))
		{
			UMaterialInstanceDynamic* MID_TimeRadius = ImgTimeRadius->GetDynamicMaterial();
			if (nullptr != MID_TimeRadius)
			{
				const float NewProgress = (MaxTime > 0.f) ? (InTime / MaxTime) : 0.f;
				MID_TimeRadius->SetScalarParameterValue(TEXT("Progress"), NewProgress);
			}
		}
	}
}

void UCWUIFightWindow::OnCameraArmAgree90(bool bIsShowAvatar)
{
	// Close Func
	return;

	ACWMap* MyMapActor = UCWFuncLib::GetActor<ACWMap>(this);
	if (nullptr != MyMapActor)
	{
		TArray<TWeakObjectPtr<ACWPawn>> AllGamePawns = MyMapActor->GetArrayPawns();
		for (int i = 0; i < AllGamePawns.Num(); ++i)
		{
			ACWPawn* GamePawn = AllGamePawns[i].Get();
			if (nullptr != GamePawn && GamePawn->IsPawnType(ECWPawnType::Character))
			{
				GamePawn->ShowMiniAvatar(bIsShowAvatar);
			}
		}
	}
}

void UCWUIFightWindow::OnPlayerPawnActionEnd(const ECWCampTag InPawnCampTag, const ECWCampControllerIndex InPawnCampControllerIndex, const int32 PawnControllerPawnIndex)
{
	CheckShiftSwicthTxtAnim(false);
}

void UCWUIFightWindow::CheckShiftSwicthTxtAnim(const bool bPlayAnim)
{
	const int32 CanActionPawnNum = GetPlayerCanActionPawnNum();
	if (CanActionPawnNum > 0)
	{
		TrsShiftSwitch->SetVisibility(ESlateVisibility::Visible);
		if (bPlayAnim)
		{
			PlayAnimationByName(TEXT("AnimShiftSwitch_INST"));
		}
	}
	else
	{
		StopAnimationByName(TEXT("AnimShiftSwitch_INST"));
		TrsShiftSwitch->SetVisibility(ESlateVisibility::Collapsed);
	}
}

int32 UCWUIFightWindow::GetPlayerCanActionPawnNum()
{
	int32 RetValue = INDEX_NONE;
	ACWPlayerController* MyLocalPC = GetLocalPC();
	if (IsValidActor(MyLocalPC) && MyLocalPC->IsMyTurn())
	{
		TArray<ACWPawn*> CanActionPawnList;
		RetValue = MyLocalPC->GetCanActionPawnList(CanActionPawnList);
	}
	return RetValue;
}

void UCWUIFightWindow::OnRoundIndexChange(int32 InCurRoundIdx, int32 InMaxRoundIdx)
{
	//CheckPlayerShiftSwicthTxt();

	TxtRoundNumTip->SetText(FSTRING_TO_FTEXT("Round"));
	TxtRoundNum->SetText(INT_TO_FTEXT(InCurRoundIdx));

	// Anim Weather
	/*const bool bWeatherChange = ((InCurRoundIdx + 1) % 3 == 0);
	if (bWeatherChange)
	{
		PlayAnimWeather();
	}*/
}

void UCWUIFightWindow::OnRoundCampChange(ECWCampTag InCampTag, ECWCampControllerIndex InCampPlayerIdx)
{
	CheckShiftSwicthTxtAnim(true);

	// 更新回合阵容变化
	ACWPlayerController* LocalPC = GetLocalPC();
	const bool bIsMyTurn = nullptr != LocalPC && LocalPC->IsMyTurn();
	BtnEndRound->SetVisibility(bIsMyTurn ? ESlateVisibility::Visible : ESlateVisibility::HitTestInvisible);

	// 半透显示
	UCanvasPanel* TrsTeamMine = Cast<UCanvasPanel>(GetWidgetFromName("TrsTeamMine"));
	UCanvasPanel* TrsTeamEnemy = Cast<UCanvasPanel>(GetWidgetFromName("TrsTeamEnemy"));
	if (nullptr != TrsTeamMine && nullptr != TrsTeamEnemy)
	{
		TrsTeamMine->SetRenderOpacity(bIsMyTurn ? 1.f : 0.5f);
		TrsTeamEnemy->SetRenderOpacity(!bIsMyTurn ? 1.f : 0.5f);
	}

	//FLinearColor InBackgroundColor = bIsMyTurn ? FLinearColor::FGetHSV(0, 0, 1) : FLinearColor::FGetHSV(0, 0, 0.5);
	FLinearColor NewBtnColor = bIsMyTurn ? FLinearColor::White : FLinearColor::Gray;
	FLinearColor NewImgColor = bIsMyTurn ? FLinearColor::White : FLinearColor::Red;
	BtnEndRound->SetBackgroundColor(NewBtnColor);
	ImgCamp->SetColorAndOpacity(NewImgColor);

	FString NewTxtBtnCamp = bIsMyTurn ? TEXT("OK") : TEXT("ENEMY...");
	FString NewTxtCamp = bIsMyTurn ? TEXT("-YOUR TURN-") : TEXT("-EMEMYS TURN-");
	TxtBtnRound->SetText(FSTRING_TO_FTEXT(NewTxtBtnCamp));
	TxtCampMain->SetText(FSTRING_TO_FTEXT(NewTxtCamp));

	// 结束回合按键
	UImage* ImgEndRound = Cast<UImage>(GetWidgetFromName("ImgEndRound"));
	if (nullptr != ImgEndRound)
	{
		const FString& NewImgKey = bIsMyTurn ? TEXT("ImgCommBtnBG01") : TEXT("ImgCommBtnBG");
		UCWUIUtil::SetImageTexture(ImgEndRound, NewImgKey);
	}
	UOverlay* TrsEndRound = Cast<UOverlay>(GetWidgetFromName("TrsEndRound"));
	if (nullptr != TrsEndRound)
	{
		TrsEndRound->SetRenderOpacity(bIsMyTurn ? 1.f : 0.5f);
	}

	// 箭头/头像流光特效
	UWidget* TrsEffectMine = Cast<UWidget>(GetWidgetFromName("TrsEffectMine"));
	UWidget* TrsEffectEnemy = Cast<UWidget>(GetWidgetFromName("TrsEffectEnemy"));
	if (nullptr != TrsEffectMine && nullptr != TrsEffectEnemy)
	{
		TrsEffectMine->SetVisibility(bIsMyTurn ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
		TrsEffectEnemy->SetVisibility(!bIsMyTurn ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
		UCWUserWidget* WBJiantouMine = Cast<UCWUserWidget>(GetWidgetFromName("WBJiantouMine"));
		UCWUserWidget* WBJiantouEnemy = Cast<UCWUserWidget>(GetWidgetFromName("WBJiantouEnemy"));
		if (nullptr != WBJiantouMine && nullptr != WBJiantouEnemy)
		{
			if (bIsMyTurn)
			{
				WBJiantouMine->PlayAnimationByName(TEXT("jiantou_INST"), 0.f, 0);
				WBJiantouEnemy->StopAnimationByName(TEXT("jiantou_INST"));
			}
			else
			{
				WBJiantouMine->StopAnimationByName(TEXT("jiantou_INST"));
				WBJiantouEnemy->PlayAnimationByName(TEXT("jiantou_INST"), 0.f, 0);
			}
		}
	}

	// 回合切换动画
	PlayAnimationByName(TEXT("AnimSwitchRound_INST"));

	// Sound
	UCWUIUtil::PlayUISound(this, TEXT("UI_Event_Battle_Finish"));
	const FString& TurnSoundKey = 
		FString::Printf(TEXT("UI_Event_Battle_Turn_%s"), bIsMyTurn ? TEXT("Player") : TEXT("Enemy"));
	UCWUIUtil::PlayUISound(this, TurnSoundKey);
}

void UCWUIFightWindow::OnPlayerSendMessage(const int32 InMsgId, const FString& InParam)
{
	const FString& NewText = FCWCfgUtils::GetLanguageString(this, INT_TO_FSTRING(InMsgId));
	if (!NewText.IsEmpty())
	{
		TxtPlayerMsg->SetText(FSTRING_TO_FTEXT(NewText));
		PlayAnimationByName(TEXT("AnimPlayerMsg_INST"));
	}
}

void UCWUIFightWindow::OnPlayerDataArrayChange()
{
	UTextBlock* TxtNameMine = Cast<UTextBlock>(GetWidgetFromName("TxtNameMine"));
	UTextBlock* TxtNameEnemy = Cast<UTextBlock>(GetWidgetFromName("TxtNameEnemy"));
	if (nullptr == TxtNameMine || nullptr == TxtNameEnemy)
	{
		return;
	}

	ACWGameState* MyGameState = GetCWGameState();
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr == MyGameState || nullptr == LocalPC)
	{
		return;
	}
	
	const TArray<FCWPlayerNetData>& PlayerDataArray = MyGameState->GetPlayerDataArray();
	const int32 PlayerDataArrayNum = PlayerDataArray.Num();
	if (PlayerDataArrayNum == 2)
	{
		const int32 MyCamp = (int32)LocalPC->GetCampTag();
		for (int32 i = 0; i < PlayerDataArrayNum; ++i)
		{
			const FCWPlayerNetData& PlayerNetData = PlayerDataArray[i];
			if (PlayerNetData.CampId > INDEX_NONE && PlayerNetData.CampId == MyCamp)
			{
				TxtNameMine->SetText(FSTRING_TO_FTEXT(PlayerNetData.Name));
			}else
			{
				TxtNameEnemy->SetText(FSTRING_TO_FTEXT(PlayerNetData.Name));
			}
			CWG_LOG(">> %s::OnPlayerDataArrayChange, i[%d] MyCamp[%d] PlayerNetData[%s].", *GetName(), i, MyCamp, *PlayerNetData.ToString());
		}
	}else
	{
		//CWG_WARNING(">> %s::OnPlayerDataArrayChange, PlayerDataArrayNum[%d] != 2.", *GetName(), PlayerDataArrayNum);
	}
}

void UCWUIFightWindow::OnCampANumChange(const int32 CampNum)
{
	if (ECWCampTag::A == GetLocalPC()->GetCampTag()) 
	{
		TxtCompNum->SetText(INT_TO_FTEXT(CampNum));
	}
	else if (ECWCampTag::B == GetLocalPC()->GetCampTag())
	{
		TxtEnermyNum->SetText(INT_TO_FTEXT(CampNum));
	}
	ShowCampInfo();
}

void UCWUIFightWindow::OnCampBNumChange(const int32 CampNum)
{
	if (ECWCampTag::B == GetLocalPC()->GetCampTag()) {
		TxtCompNum->SetText(INT_TO_FTEXT(CampNum));
	}
	else if (ECWCampTag::A == GetLocalPC()->GetCampTag()) {
		TxtEnermyNum->SetText(INT_TO_FTEXT(CampNum));
	}
	ShowCampInfo();
}

void UCWUIFightWindow::ShowCampInfo()
{
	TxtCompNum->SetVisibility(ESlateVisibility::Visible);
	TxtEnermyNum->SetVisibility(ESlateVisibility::Visible);
	ImgComp->SetVisibility(ESlateVisibility::Visible);
	ImgEnermy->SetVisibility(ESlateVisibility::Visible);
}

void UCWUIFightWindow::OnGamePlayerRateChange(const int32 InRate)
{
	FString NewTxt = FString::Printf(TEXT("x%d"), InRate);
	TxtSpeed->SetText(FSTRING_TO_FTEXT(NewTxt));
}

void UCWUIFightWindow::OnRoleReadyStateChange(int32 InPid, bool bReadyOk)
{
	ACWPlayerController* LocalPC = GetLocalPC();
	const int32 LocalPCPid = LocalPC ? LocalPC->GetPlayerId() : INDEX_NONE;
	if (LocalPCPid != INDEX_NONE)
	{
		const FString& ImgReadyName = (LocalPCPid == InPid) ? TEXT("ImgReadyMine") : TEXT("ImgReadyEnemy");
		const FString& TxtStateName = (LocalPCPid == InPid) ? TEXT("TxtStateMine") : TEXT("TxtStateEnemy");
		UImage* ImgReady = Cast<UImage>(GetWidgetFromName(FSTRING_TO_FNAME(ImgReadyName)));
		UTextBlock* TxtState = Cast<UTextBlock>(GetWidgetFromName(FSTRING_TO_FNAME(TxtStateName)));

		if (nullptr == ImgReady || nullptr == TxtState)
		{
			CWG_WARNING(">> %s::OnRoleReadyStateChange, ImgReady[%s] TxtState[%s] is nullptr.", *CWG_NAME(this), *CWG_NAME(ImgReady), *CWG_NAME(TxtState));
			return;
		}

		const FString& ImgAssetId = bReadyOk ? TEXT("ImgReadyOk") : TEXT("ImgReadyIng");
		UCWUIUtil::SetImageTexture(ImgReady, ImgAssetId);
		const FString& LanguageId = bReadyOk ? TEXT("TxtReadyOk") : TEXT("TxtReadyIng");
		const FString& NewLanguageTxt = FCWCfgUtils::GetLanguageString(this, LanguageId);
		const FString& NewTxtState = !NewLanguageTxt.IsEmpty() ? NewLanguageTxt : (bReadyOk ? TEXT("READY-OK") : TEXT("READY-ING"));
		TxtState->SetText(FSTRING_TO_FTEXT(NewTxtState));
		//FLinearColor NewColor = bReadyOk ? FLinearColor(0.f, 1.f, 0.f) : FLinearColor(1.f, 1.f, 1.f);
		//TxtState->SetColorAndOpacity(NewColor);
	}
	else
	{
		CWG_WARNING(">> %s::OnRoleReadyStateChange, InPid[%d] bReadyOk[%d] LocalPCPid[INDEX_NONE]", *GetName(), InPid, (int32)bReadyOk);
	}
}

void UCWUIFightWindow::OnWeatherIdxChange(ECWWeatherType InWeatherType, ECWWeatherType InOldWeatherType)
{
	UTextBlock* TxtWeather = Cast<UTextBlock>(GetWidgetFromName("TxtWeather"));
	UCWButton* BtnCurWeather = Cast<UCWButton>(GetWidgetFromName("BtnCurWeather"));
	const FCWWeatherData* WeatherData = FCWCfgUtils::GetWeatherData(this, (int32)InWeatherType);
	if (nullptr == TxtWeather || nullptr == BtnCurWeather || nullptr == WeatherData)
	{
		CWG_WARNING(">> %s::OnWeatherIdxChange, TxtWeather/BtnCurWeather/WeatherData[%d] is nullptr.", *GetName(), (int32)InWeatherType);
		return;
	}

	PlayAnimWeather();

	TxtWeather->SetText(FSTRING_TO_FTEXT(WeatherData->Name));

	const FString& NewWeatherKey = FString::Printf(TEXT("ImgWeather_%d"), (int32)InWeatherType);
	UTexture2D* NewTexture2D = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, NewWeatherKey);
	if (nullptr != NewTexture2D)
	{
		UCWUIUtil::SetBtnImage(BtnCurWeather, NewTexture2D);
	}

}

void UCWUIFightWindow::OnNextWeatherIdxChange(ECWWeatherType InNextWeatherType)
{
	UCWButton* BtnNextWeather = Cast<UCWButton>(GetWidgetFromName("BtnNextWeather"));
	if (nullptr == BtnNextWeather)
	{
		CWG_WARNING(">> %s::OnNextWeatherIdxChange, BtnNextWeather is nullptr.", *GetName());
		return;
	}

	const FString& NewWeatherKey = FString::Printf(TEXT("ImgWeather_%d"), (int32)InNextWeatherType);
	UTexture2D* NewTexture2D = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, NewWeatherKey);
	if (nullptr != NewTexture2D)
	{
		UCWUIUtil::SetBtnImage(BtnNextWeather, NewTexture2D);
	}
}

void UCWUIFightWindow::OnTimePhasesChange(ECWTimePhases InNewTimePhases)
{
	UImage* ImgTimePhases = Cast<UImage>(GetWidgetFromName("ImgTimePhases"));
	if (nullptr != ImgTimePhases)
	{
		const FString& NewAssetId = FString::Printf(TEXT("ImgTimePhases_%d"), (int32)InNewTimePhases);
		UCWUIUtil::SetImageTexture(ImgTimePhases, NewAssetId);

		PlayAnimationByName(TEXT("AnimTimePhases_INST"));
	}

	// Anim Weather
	if (InNewTimePhases == ECWTimePhases::Morning)
	{
		PlayAnimWeather();
	}
}

void UCWUIFightWindow::OnBeginReadyState()
{
	TxtRoundNumTip->SetText(FSTRING_TO_FTEXT("PREPARE"));
	TxtRoundNum->SetText(FSTRING_TO_FTEXT(""));

	OnPlayerDataArrayChange();
	InitConfigRoleInReady();

	PlayAnimationByName(TEXT("AnimStartWidget_INST"));

	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	auto AnimBattleStartCallable = [this]()
	{
		PlayAnimationByName(TEXT("AnimBattleStart_INST"));
	};
	TimerManager.SetTimer(AnimBattleStart, AnimBattleStartCallable, 1.f, false);

	auto AnimSwitchRoundCallable = [this]()
	{
		TxtCampMain->SetText(FSTRING_TO_FTEXT(TEXT("-ARRANGE YOUR SOLDIERS-")));
		PlayAnimationByName(TEXT("AnimSwitchRound_INST"));
	};
	TimerManager.SetTimer(AnimSwitchRound, AnimSwitchRoundCallable, 2.f, false);
}

void UCWUIFightWindow::OnBeginFightingState()
{
	RemoveConfigRoleInReady();
	InitAttackPreviewCtrl();

	/** 战斗状态 */
	UImage* ImgReadyMine = Cast<UImage>(GetWidgetFromName(TEXT("ImgReadyMine")));
	UImage* ImgReadyEnemy = Cast<UImage>(GetWidgetFromName(TEXT("ImgReadyEnemy")));
	UImage* ImgReadyBgMine = Cast<UImage>(GetWidgetFromName(TEXT("ImgReadyBgMine")));
	UImage* ImgReadyBgEnemy = Cast<UImage>(GetWidgetFromName(TEXT("ImgReadyBgEnemy")));
	if (nullptr != ImgReadyMine && nullptr != ImgReadyEnemy && nullptr != ImgReadyBgMine && nullptr != ImgReadyBgEnemy)
	{
		ImgReadyMine->SetVisibility(ESlateVisibility::Collapsed);
		ImgReadyEnemy->SetVisibility(ESlateVisibility::Collapsed);
		ImgReadyBgMine->SetVisibility(ESlateVisibility::Collapsed);
		ImgReadyBgEnemy->SetVisibility(ESlateVisibility::Collapsed);
	}

	UTextBlock* TxtStateMine = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtStateMine")));
	UTextBlock* TxtStateEnemy = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtStateEnemy")));
	if (nullptr != TxtStateMine && nullptr != TxtStateEnemy)
	{
		const FString& NewTxtMine = FCWCfgUtils::GetLanguageString(this, TEXT("TxtYourTurn"));
		const FString& NewTxtEnemy = FCWCfgUtils::GetLanguageString(this, TEXT("TxtEnemyTurn"));
		TxtStateMine->SetText(FSTRING_TO_FTEXT(NewTxtMine));
		//TxtStateMine->SetColorAndOpacity(FLinearColor::Green);
		TxtStateEnemy->SetText(FSTRING_TO_FTEXT(NewTxtEnemy));
		//TxtStateEnemy->SetColorAndOpacity(FLinearColor::Red);
	}else
	{
		CWG_WARNING(">> %s::OnRoleReadyStateChange, ImgReadyMine/TxtStateMine/ImgReadyEnemy/TxtStateEnemy is nullptr.", *CWG_NAME(this));
	}

	// Weather
	ACWGameState* MyGameState = GetCWGameState();
	if (nullptr != MyGameState)
	{
		const ECWWeatherType CurWeather = (ECWWeatherType)MyGameState->GetWeatherIdx();
		const ECWWeatherType NextWeather = (ECWWeatherType)MyGameState->GetNextWeatherIdx();
		OnWeatherIdxChange(CurWeather, ECWWeatherType::Sunshine);
		OnNextWeatherIdxChange(NextWeather);
	}
}

void UCWUIFightWindow::OnBeginSettlementState()
{
	RemoveAttackPreviewCtrl();
}

void UCWUIFightWindow::OnClickedBtnStartFight()
{
	//ShowWidgetParts(EUIFightPart::Ready, false);
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC && !LocalPC->IsReadyFinished())
	{
		LocalPC->ServerSetReadyFinished(true);

		UWidget* TrsBtnStartFight = Cast<UWidget>(GetWidgetFromName("TrsBtnStartFight"));
		UWidget* TrsBtnWaitingStart = Cast<UWidget>(GetWidgetFromName("TrsBtnWaitingStart"));
		if (nullptr != TrsBtnStartFight && nullptr != TrsBtnWaitingStart)
		{
			TrsBtnStartFight->SetVisibility(ESlateVisibility::Collapsed);
			TrsBtnWaitingStart->SetVisibility(ESlateVisibility::HitTestInvisible);
		}
	}
}

void UCWUIFightWindow::OnClickedBtnEndRound()
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC && LocalPC->IsMyTurn())
	{
		UCWUIManager* UI_Mgr = UI_MGR(this);
		TArray<ACWPawn*> CanActionPawnList;
		const int32 CanActionPawnNum = LocalPC->GetCanActionPawnList(CanActionPawnList);
		if (nullptr != UI_Mgr && CanActionPawnNum > 0)
		{
			UUICommConfirm* UICommConfirm = Cast<UUICommConfirm>(UI_Mgr->OpenUI(FUIKey::UICommConfirm, 250));
			if (UCWUIManager::IsValidWidget(UICommConfirm))
			{
				UICommConfirm->SetTxtContentByKey(TEXT("UI_ForceEnd"));
				ADD_EVT_DELEGATE(UICommConfirm->OnOkClick, this, &UCWUIFightWindow::OnOkClickCommConfirm, TEXT("OnOkClickCommConfirm"));
				return;		// 确认框跳出
			}
		}
		else
		{
			LocalPC->ServerRPCActionEnd();
			//TrsShiftSwitch->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void UCWUIFightWindow::OnClickedBtnSpeed()
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->SwitchGamePlayerRate();
	}
}

void UCWUIFightWindow::OnClickedBtnSetting()
{
	/*if (UCWUIManager* UIMgr = GetUIMgr())
	{
		UIMgr->OpenUI(FUIKey::UISetting, 50);
	}*/
	UCWUIManager::LuaOpenUI(this, "OPEN_GAMESETTING");
}

void UCWUIFightWindow::OnOkClickCommConfirm()
{
	ACWPlayerController* LocalPC = GetLocalPC();
	if (nullptr != LocalPC)
	{
		LocalPC->ServerRPCActionEnd();
		//TrsShiftSwitch->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCWUIFightWindow::OnHoveredBtnCurWeather()
{
	ShowWeatherTips(true);
}

void UCWUIFightWindow::OnUnhoveredBtnCurWeather()
{
	ShowWeatherTips(false);
}

void UCWUIFightWindow::OnHoveredBtnNextWeather()
{
	ShowWeatherTips(true, false);
}

void UCWUIFightWindow::OnUnhoveredBtnNextWeather()
{
	ShowWeatherTips(false);
}

void UCWUIFightWindow::ShowTileTips(const FString& InTileTypeName, int32 InTerrainHeight, const FString& InTerrainDefince)
{
	if (!TrsSceneTileDesc.IsValid())
	{
		return;
	}

	// 地块类型名字
	UTextBlock* TxtTileTypeName = Cast<UTextBlock>(TrsSceneTileDesc->GetWidgetFromName("TxtTileTypeName"));
	if (nullptr != TxtTileTypeName)
	{
		TxtTileTypeName->SetText(FSTRING_TO_FTEXT(InTileTypeName));
	}

	// 地形地势高度
	UTextBlock* TxtTerrainHeight = Cast<UTextBlock>(TrsSceneTileDesc->GetWidgetFromName("TxtTerrainHeight"));
	if (nullptr != TxtTerrainHeight)
	{
		FString HeightText;
		if (InTerrainHeight != 0)
		{
			const FString& TxtKey = (InTerrainHeight > 0) ? TEXT("TxtHeightLand") : TEXT("TxtLowLand");
			const FString& TextParam = FCWCfgUtils::GetLanguageString(this, TxtKey);
			HeightText = TextParam.Replace(TEXT("{0}"), *INT_TO_FSTRING(InTerrainHeight));
		}
		else
		{
			HeightText = FCWCfgUtils::GetLanguageString(this, TEXT("TxtMarkerBed"));
		}
		TxtTerrainHeight->SetText(FSTRING_TO_FTEXT(HeightText));
	}

	// 地形防御加成
	UWidget* TrsTerrainDef = Cast<UWidget>(TrsSceneTileDesc->GetWidgetFromName("TrsTerrainDef"));
	if (nullptr != TrsTerrainDef)
	{
		const bool bIsNotValue = InTerrainDefince.IsEmpty();
		TrsTerrainDef->SetVisibility(bIsNotValue ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
		if (!bIsNotValue)
		{
			UTextBlock* TxtTerrainDef = Cast<UTextBlock>(TrsSceneTileDesc->GetWidgetFromName("TxtTerrainDef"));
			if (nullptr != TxtTerrainDef)
			{
				TxtTerrainDef->SetText(FSTRING_TO_FTEXT(InTerrainDefince));
			}
		}
	}

	// 更新控件位置
	SetWidgetScreenPoint(TrsSceneTileDesc.Get());
	TrsSceneTileDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
	UWidget* TrsTileDesc = Cast<UWidget>(TrsSceneTileDesc->GetWidgetFromName("TrsTileDesc"));
	if (nullptr != TrsTileDesc)
	{
		TrsTileDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
	}
}

void UCWUIFightWindow::HideTileTips()
{
	if (TrsSceneTileDesc.IsValid())
	{
		UWidget* TrsTileDesc = Cast<UWidget>(TrsSceneTileDesc->GetWidgetFromName("TrsTileDesc"));
		if (nullptr != TrsTileDesc)
		{
			TrsTileDesc->SetVisibility(ESlateVisibility::Collapsed);
		}
		//TrsSceneTileDesc->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCWUIFightWindow::ShowItemBuffTips(const FString& InDesc)
{
	if (!TrsSceneTileDesc.IsValid())
	{
		return;
	}

	if (InDesc.IsEmpty())
	{
		HideItemBuffTips();
		return;
	}

	UTextBlock* TxtBuffDesc = Cast<UTextBlock>(TrsSceneTileDesc->GetWidgetFromName("TxtBuffDesc"));
	if (nullptr != TxtBuffDesc)
	{
		TxtBuffDesc->SetText(FSTRING_TO_FTEXT(InDesc));
	}

	// 更新控件位置
	SetWidgetScreenPoint(TrsSceneTileDesc.Get());
	TrsSceneTileDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
	UWidget* TrsBuffDesc = Cast<UWidget>(TrsSceneTileDesc->GetWidgetFromName("TrsBuffDesc"));
	if (nullptr != TrsBuffDesc)
	{
		TrsBuffDesc->SetVisibility(ESlateVisibility::HitTestInvisible);
	}
}

void UCWUIFightWindow::HideItemBuffTips()
{
	if (TrsSceneTileDesc.IsValid())
	{
		UWidget* TrsBuffDesc = Cast<UWidget>(TrsSceneTileDesc->GetWidgetFromName("TrsBuffDesc"));
		if (nullptr != TrsBuffDesc)
		{
			TrsBuffDesc->SetVisibility(ESlateVisibility::Collapsed);
		}
		//TrsSceneTileDesc->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCWUIFightWindow::ShowWeatherTips(const bool bNewVisible, const bool bIsCurWeather)
{
	UUserWidget* TrsWeatherDescWidget = TrsWeatherDesc.Get();
	if (nullptr == TrsWeatherDescWidget)
	{
		return;
	}
	if (bNewVisible == false)
	{
		TrsWeatherDescWidget->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	bool bIsSettingOk = false;
	ACWGameState* MyGameState = GetCWGameState();
	UTextBlock* TxtWeather = Cast<UTextBlock>(TrsWeatherDescWidget->GetWidgetFromName("TxtWeather"));
	if (nullptr != TxtWeather && nullptr != MyGameState)
	{
		int32 WeatherIdx = bIsCurWeather ? MyGameState->GetWeatherIdx() : MyGameState->GetNextWeatherIdx();
		const FCWWeatherData* WeatherData = FCWCfgUtils::GetWeatherData(this, WeatherIdx);
		if (nullptr != WeatherData)
		{
			bIsSettingOk = true;
			// 设置天气名字
			TxtWeather->SetText(FSTRING_TO_FTEXT(WeatherData->Name));

			// 更新属性值文本函数
			auto UpdateAttrValueTxtFunc = [](const UUserWidget* InUserWidgetWeather, const int32 InAddValue, const FString& InNewKey, const FString& InAttrName)
			{
				const FString& NewAttrName = InNewKey + InAttrName;
				UUserWidget* WidgetAttr = Cast<UUserWidget>(InUserWidgetWeather->GetWidgetFromName(FSTRING_TO_FNAME(NewAttrName)));
				if (nullptr != WidgetAttr)
				{
					if (InAddValue != 0)
					{
						UTextBlock* TxtAttrValue = Cast<UTextBlock>(WidgetAttr->GetWidgetFromName(TEXT("TxtAttrValue")));
						if (nullptr != TxtAttrValue)
						{
							const FString& Symbol = InAddValue > 0 ? TEXT("+") : TEXT("");
							const FString& NewTxt = Symbol + INT_TO_FSTRING(InAddValue);
							FSlateColor NewColor = InAddValue > 0 ? FLinearColor::Green : FLinearColor::Red;
							TxtAttrValue->SetText(FSTRING_TO_FTEXT(NewTxt));
							TxtAttrValue->SetColorAndOpacity(NewColor);
						}
					}
					WidgetAttr->SetVisibility((InAddValue != 0) ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
				}
			};

			// 更新近远战影响函数
			auto UpdateAffectValueFunc = [UpdateAttrValueTxtFunc](
				const UUserWidget* InUserWidgetWeather, const FCWWeatherAffectData& InAffectData, const FString& InNewKey)
			{
				const FString& NewTrsAffectName = TEXT("TrsAffect") + InNewKey;
				UWidget* TrsAffectNode = Cast<UWidget>(InUserWidgetWeather->GetWidgetFromName(FSTRING_TO_FNAME(NewTrsAffectName)));
				if (nullptr != TrsAffectNode)
				{
					const bool bHasValidValue = InAffectData.IsValidValue();
					if (bHasValidValue)
					{
						const int32 AttackValue = (int32)InAffectData.AttackValue;
						UpdateAttrValueTxtFunc(InUserWidgetWeather, AttackValue, InNewKey, TEXT("AttrAttack"));
						const int32 DefValue = (int32)InAffectData.DefenceValue;
						UpdateAttrValueTxtFunc(InUserWidgetWeather, DefValue, InNewKey, TEXT("AttrDef"));
						const int32 TanlentValue = (int32)InAffectData.TalentValue;
						UpdateAttrValueTxtFunc(InUserWidgetWeather, TanlentValue, InNewKey, TEXT("AttrTanlent"));
						const int32 MoveValue = (int32)InAffectData.MoveValue;
						UpdateAttrValueTxtFunc(InUserWidgetWeather, MoveValue, InNewKey, TEXT("AttrMove"));
					}
					TrsAffectNode->SetVisibility(bHasValidValue ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
				}
			};

			// 更新近远战属性值
			UpdateAffectValueFunc(TrsWeatherDescWidget, WeatherData->MeleeAffect, TEXT("Melee"));
			UpdateAffectValueFunc(TrsWeatherDescWidget, WeatherData->RangedAffect, TEXT("Ranged"));
		}
	}

	// 更新控件位置
	if (bIsSettingOk)
	{
		SetWidgetScreenPoint(TrsWeatherDescWidget);
	}
	TrsWeatherDescWidget->SetVisibility(bIsSettingOk ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

FString UCWUIFightWindow::GetTerrainPropertyTxt(float InTerrainDefinceFactor)
{
	FString NewTxt = TEXT(""/*"DEF"*/);
	int32 NewValue = InTerrainDefinceFactor * 100;
	FString Symbol = NewValue > 0 ? TEXT("+") : TEXT("");
	NewTxt += Symbol + INT_TO_FSTRING(NewValue) + TEXT("%");
	return NewTxt;
}

void UCWUIFightWindow::InitConfigRoleInReady()
{
	if (nullptr == ConfigRoleCtrl)
	{
		ConfigRoleCtrl = NewObject<UCWUIConfigRoleCtrl>(this);
		ConfigRoleCtrl->InitController(this);
	}
	TrsAtrrTip->InitTipWidget(this);
}

void UCWUIFightWindow::RemoveConfigRoleInReady()
{
	if (IsValid(ConfigRoleCtrl))
	{
		ConfigRoleCtrl->ConditionalBeginDestroy();
		ConfigRoleCtrl = nullptr;
	}
}

void UCWUIFightWindow::InitAttackPreviewCtrl()
{
	if (nullptr == AttackPreviewCtrl)
	{
		AttackPreviewCtrl = NewObject<UCWUIAttackPreviewCtrl>(this);
		AttackPreviewCtrl->InitController(this);
	}
}

void UCWUIFightWindow::RemoveAttackPreviewCtrl()
{
	if (IsValid(AttackPreviewCtrl))
	{
		AttackPreviewCtrl->ConditionalBeginDestroy();
		AttackPreviewCtrl = nullptr;
	}
}

FVector2D UCWUIFightWindow::ActorLocationToScreenPoint(const FVector& TargetLocation)
{
	FVector TargetLoc = TargetLocation;
	FVector2D ScreenLoc = FVector2D::ZeroVector;

	APawn* OwningPawn = GetOwningPlayerPawn();
	APlayerController* OwningPlayer = GetOwningPlayer();
	APlayerCameraManager* OwningCamera = OwningPlayer->PlayerCameraManager;

	bool bShowName = UGameplayStatics::ProjectWorldToScreen(OwningPlayer, TargetLoc, ScreenLoc, true);
	if (!bShowName && OwningPawn)
	{
		/*int32 ViewportSizeX = 0, ViewportSizeY = 0;
		OwningPlayer->GetViewportSize(ViewportSizeX, ViewportSizeY);

		FVector Forward = OwningCamera->GetActorForwardVector();/ *OwningPlayer->GetActorForwardVector()* /;
		Forward.Normalize();

		FVector PawnLoc = OwningPawn->GetActorLocation();

		FVector WorldLocNor = PawnLoc - TargetLoc;
		WorldLocNor.Normalize();

		float P = FVector::DotProduct(Forward, WorldLocNor);
		float DS = FVector::Distance(PawnLoc, TargetLoc);
		TargetLoc = TargetLoc + Forward * DS * P * 2;*/

		FVector NewLoc = UKismetMathLibrary::ProjectPointOnToPlane(TargetLoc, 
			/*OwningCamera->GetActorLocation(), OwningCamera->GetActorForwardVector()*/
			OwningCamera->GetCameraLocation(), OwningCamera->GetActorForwardVector());
		TargetLoc = NewLoc - (TargetLoc - NewLoc);

		UGameplayStatics::ProjectWorldToScreen(OwningPlayer, TargetLoc, ScreenLoc, true);
	}

	float ViewportScale = UWidgetLayoutLibrary::GetViewportScale(this);
	FVector2D ViewportSize2D = FVector2D(1280.f, 720.f) / ViewportScale;

	ScreenLoc.X = FMath::Clamp<float>(ScreenLoc.X, 0.f, ViewportSize2D.X);
	ScreenLoc.Y = FMath::Clamp<float>(ScreenLoc.Y, 0.f, ViewportSize2D.Y);

	return ScreenLoc;
}

void UCWUIFightWindow::PlayAnimWeather()
{
	ACWGameState* MyGameState = GetCWGameState();
	if (nullptr == MyGameState)
	{
		return;
	}

	UImage* ImgAnimOld = Cast<UImage>(GetWidgetFromName("ImgAnimOld"));
	UImage* ImgAnimCur = Cast<UImage>(GetWidgetFromName("ImgAnimCur"));
	UImage* ImgAnimNext = Cast<UImage>(GetWidgetFromName("ImgAnimNext"));
	if (nullptr != ImgAnimOld && nullptr != ImgAnimCur && nullptr != ImgAnimNext)
	{
		const int32 OldWeatherIdx = MyGameState->GetOldWeatherIdx();
		const int32 CurWeatherIdx = MyGameState->GetWeatherIdx();
		const int32 NextWeatherIdx = MyGameState->GetNextWeatherIdx();
		const FString& OldWeatherKey = FString::Printf(TEXT("ImgWeather_%d"), OldWeatherIdx);
		const FString& CurWeatherKey = FString::Printf(TEXT("ImgWeather_%d"), CurWeatherIdx);
		const FString& NextWeatherKey = FString::Printf(TEXT("ImgWeather_%d"), NextWeatherIdx);
		UCWUIUtil::SetImageTexture(ImgAnimOld, OldWeatherKey);
		UCWUIUtil::SetImageTexture(ImgAnimCur, CurWeatherKey);
		UCWUIUtil::SetImageTexture(ImgAnimNext, NextWeatherKey);

		PlayAnimationByName("AnimWeatherChange_INST");
	}
}

bool UCWUIFightWindow::PlayAnimationByName(const FString& InAnimKey, float StartAtTime, int32 NumLoopsToPlay,
	EUMGSequencePlayMode::Type PlayMode, float PlaybackSpeed)
{
	if (InAnimKey.IsEmpty())
	{
		return false;
	}

	if (UWidgetAnimation* MyWidgetAnim = WidgetAnimations.FindRef(InAnimKey))
	{
		PlayAnimation(MyWidgetAnim, StartAtTime, NumLoopsToPlay, PlayMode, PlaybackSpeed);
		return true;
	}
	return false;
}

bool UCWUIFightWindow::StopAnimationByName(const FString& InAnimKey)
{
	if (InAnimKey.IsEmpty())
	{
		return false;
	}

	if (UWidgetAnimation* MyWidgetAnim = WidgetAnimations.FindRef(InAnimKey))
	{
		StopAnimation(MyWidgetAnim);
		return true;
	}
	return false;
}

