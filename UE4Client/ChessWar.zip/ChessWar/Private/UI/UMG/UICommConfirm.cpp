﻿
#include "UICommConfirm.h"

#include "TextBlock.h"
#include "CWFuncLib.h"
#include "CWCfgUtils.h"


UUICommConfirm::UUICommConfirm(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UUICommConfirm::~UUICommConfirm()
{
}

bool UUICommConfirm::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}
	
	InitializeImpl();
	return true;
}

void UUICommConfirm::NativeConstruct()
{
	Super::NativeConstruct();
	
	//InitializeImpl();
}

void UUICommConfirm::SetCommConfirmMode(const uint8 InMode)
{
	CommConfirmMode = InMode;

	switch (CommConfirmMode)
	{
	case 1:
	{	// 退出游戏
		SetTxtTitleByKey(TEXT("UI_Notice"));
		SetTxtContentByKey(TEXT("UI_QuitContent"));
	}break;
	}

}

void UUICommConfirm::SetTxtTitleByKey(const FString& InLangKey)
{
	const FString& TmpTxt = FCWCfgUtils::GetLanguageString(this, InLangKey);
	TxtTitle->SetText(FSTRING_TO_FTEXT(TmpTxt));
}

void UUICommConfirm::SetTxtContentByKey(const FString& InLangKey)
{
	const FString& TmpTxt = FCWCfgUtils::GetLanguageString(this, InLangKey);
	TxtContent->SetText(FSTRING_TO_FTEXT(TmpTxt));
}

void UUICommConfirm::InitializeImpl()
{
	if (IsCanInitCustom())
	{
		TxtTitle = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtTitle")));
		TxtContent = Cast<UTextBlock>(GetWidgetFromName(TEXT("TxtContent")));

		BtnOk = Cast<UCWButton>(GetWidgetFromName(TEXT("BtnOk")));
		BtnCancel = Cast<UCWButton>(GetWidgetFromName(TEXT("BtnCancel")));
		
		ADD_EVT_DELEGATE(BtnOk->OnClicked, this, &UUICommConfirm::OnOkButtonClick, TEXT("OnOkButtonClick"));
		ADD_EVT_DELEGATE(BtnCancel->OnClicked, this, &UUICommConfirm::OnCancelButtonClick, TEXT("OnCancelButtonClick"));
	}
}

void UUICommConfirm::OnOkButtonClick()
{
	OnOkClick.Broadcast();

	switch (CommConfirmMode)
	{
	case 1:
	{	// 退出游戏
		UCWFuncLib::CWGQuitGame(EQuitPreference::Type::Quit, this);
	}break;
	}

	DestroyWidget();
}

void UUICommConfirm::OnCancelButtonClick()
{
	OnCancelClick.Broadcast();

	DestroyWidget();
}
