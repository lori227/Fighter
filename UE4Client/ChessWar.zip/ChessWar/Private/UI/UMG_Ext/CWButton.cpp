﻿
#include "CWButton.h"

#include "CWUIUtil.h"
#include "CWComDef.h"
#include "CWEventMgr.h"
#include "CWAudioVideoMgr.h"

#define LOCTEXT_NAMESPACE "CWG_UI_UMG"

UCWButton::UCWButton(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCWButton::PostInitProperties()
{
	Super::PostInitProperties();
}

void UCWButton::PostLoad()
{
	Super::PostLoad();

	ADD_EVT_DELEGATE(OnClicked, this, &UCWButton::OnBtnClicked, FName("OnBtnClicked"));
	ADD_EVT_DELEGATE(OnPressed, this, &UCWButton::OnBtnPressed, FName("OnBtnPressed"));
	ADD_EVT_DELEGATE(OnReleased, this, &UCWButton::OnBtnReleased, FName("OnBtnReleased"));
	ADD_EVT_DELEGATE(OnHovered, this, &UCWButton::OnBtnHovered, FName("OnBtnHovered"));
}

void UCWButton::BeginDestroy()
{
	OnClicked.Clear();
	OnPressed.Clear();
	OnReleased.Clear();
	OnHovered.Clear();

	Super::BeginDestroy();
}

#if WITH_EDITOR
const FText UCWButton::GetPaletteCategory()
{
	return LOCTEXT("CWGame", "CWGame");
}
#endif

void UCWButton::SetEnableSound(bool bEnable)
{
	ClickEffect.bEnableSound = bEnable;
}

void UCWButton::SetEnableClickScale(bool bEnable)
{
	ClickEffect.bEnableClickScale = bEnable;
}

void UCWButton::SetActiveClick(bool bActive)
{
	ClickEffect.bActiveClick = bActive;
}

bool UCWButton::IsActiveClick()
{
	return ClickEffect.bActiveClick;
}

void UCWButton::OnBtnClicked()
{
	if (ClickEffect.bEnableSound)
	{
		UAkAudioEvent* ClickSound = ClickEffect.bActiveClick ? ClickEffect.AkEvent : ClickEffect.ClickSoundInact;
		if (nullptr != ClickSound)
		{
			UCWUIUtil::PlayUISound(this, TEXT(""), ClickSound);
		}
	}
}

void UCWButton::OnBtnPressed()
{
	if (ClickEffect.IsValidClickScale())
	{
		OriginalRenderScale = RenderTransform.Scale;
		SetRenderScale(OriginalRenderScale * ClickEffect.ClickScaleRate);
	}

	if (ClickEffect.bEnableSound && nullptr != ClickEffect.PressedSound)
	{
		UCWUIUtil::PlayUISound(this, TEXT(""), ClickEffect.PressedSound);
	}
}

void UCWButton::OnBtnReleased()
{
	if (ClickEffect.IsValidClickScale())
	{
		SetRenderScale(OriginalRenderScale);
	}
}

void UCWButton::OnBtnHovered()
{
	if (ClickEffect.bEnableSound && nullptr != ClickEffect.HoveredSound)
	{
		UCWUIUtil::PlayUISound(this, TEXT(""), ClickEffect.HoveredSound);
	}
}

#undef LOCTEXT_NAMESPACE

FCWBtnClickData::FCWBtnClickData()
	: AkEvent(nullptr)
	, ClickSoundInact(nullptr)
	, HoveredSound(nullptr)
	, PressedSound(nullptr)
	, bEnableSound(true)
	, bActiveClick(true)
	, bEnableClickScale(false)
	, ClickScaleRate(1.0f)
{
}

FCWBtnClickData::~FCWBtnClickData()
{
}

bool FCWBtnClickData::IsValidClickScale()
{
	return bEnableClickScale && !FMath::IsNearlyEqual(ClickScaleRate, 1.0f);
}
