﻿
#include "CWUIItemWidget.h"

UCWUIItemWidget::UCWUIItemWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWUIItemWidget::~UCWUIItemWidget()
{
}

bool UCWUIItemWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		ResetDefaults();
	}

	return true;
}

void UCWUIItemWidget::ResetDefaults()
{
	UpdateHp();
	UpdateHpColor();
	UpdateName();
}

void UCWUIItemWidget::UpdateHp_Implementation(int32 Num, int32 MaxNum)
{
}

void UCWUIItemWidget::UpdateHpColor_Implementation(bool bInGreen)
{
}

void UCWUIItemWidget::UpdateName_Implementation(const FString& InName)
{
}
