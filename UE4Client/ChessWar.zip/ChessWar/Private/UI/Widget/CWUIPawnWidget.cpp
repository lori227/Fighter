﻿
#include "CWUIPawnWidget.h"

#include "Image.h"
#include "Button.h"
#include "TextBlock.h"
#include "CanvasPanel.h"
#include "ProgressBar.h"
#include "HorizontalBox.h"

#include "CWPawn.h"
#include "CWComDef.h"
#include "CWUIUtil.h"
#include "CWCfgUtils.h"
#include "CWUIBuffBtn.h"
#include "CWCfgManager.h"
#include "CWUIWidgetData.h"
#include "CWPlayerController.h"

UCWUIPawnWidget::UCWUIPawnWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UCWUIPawnWidget::~UCWUIPawnWidget()
{
}

bool UCWUIPawnWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	if (IsCanInitCustom())
	{
		TrsMainNode = Cast<UCanvasPanel>(GetWidgetFromName("TrsMainNode"));

		TrsRoleNode = Cast<UCanvasPanel>(GetWidgetFromName(FName("TrsRoleNode")));
		BarHpCur = Cast<UProgressBar>(GetWidgetFromName(FName("BarHpCur")));
		BarSpCur = Cast<UProgressBar>(GetWidgetFromName(FName("BarSpCur")));
		BarHpPre = Cast<UProgressBar>(GetWidgetFromName(FName("BarHpPre")));
		BarSpPre = Cast<UProgressBar>(GetWidgetFromName(FName("BarSpPre")));
		ImgWeapon = Cast<UImage>(GetWidgetFromName(FName("ImgWeapon")));

		TrsHeadTag = Cast<UCanvasPanel>(GetWidgetFromName(FName("TrsHeadTag")));
		ImgIcon = Cast<UImage>(GetWidgetFromName(FName("ImgIcon")));
		ImgRefrain = Cast<UImage>(GetWidgetFromName(FName("ImgRefrain")));
		TxtIcon = Cast<UTextBlock>(GetWidgetFromName(FName("TxtIcon")));

		//TxtName = Cast<UTextBlock>(GetWidgetFromName(FName("TxtName")));
		//TxtAtkAttr = Cast<UTextBlock>(GetWidgetFromName(FName("TxtAtkAttr")));

		ImgMiniAvatar = Cast<UImage>(GetWidgetFromName(FName("ImageMiniAvatar")));

		// Init Data 
		BarHpPre->SetPercent(0.f);
		BarSpPre->SetPercent(0.f);
	}

	return true;
}

void UCWUIPawnWidget::SetTrsMainNode(bool bNewVisible)
{
	TrsMainNode->SetVisibility(bNewVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

void UCWUIPawnWidget::SetNameText(const FString& InName)
{
	//TxtName->SetText(FSTRING_TO_FTEXT(InName));
}

void UCWUIPawnWidget::SetHPText(int32 Num /*= 10*/, int32 MaxNum /*= 10*/)
{
	const int32 CurValue = FMath::Max<int32>(Num, 0);
	const int32 MaxValue = FMath::Max<int32>(MaxNum, 0);
	const float Percent = UCWUIUtil::Divide_IntInt(CurValue, MaxValue);
	BarHpCur->SetPercent(Percent);
	BarHpPre->SetPercent(0.f);
}

void UCWUIPawnWidget::SetSPText(int32 Num /*= 10*/, int32 MaxNum /*= 10*/)
{
	const int32 CurValue = FMath::Max<int32>(Num, 0);
	const int32 MaxValue = FMath::Max<int32>(MaxNum, 0);
	const float Percent = UCWUIUtil::Divide_IntInt(CurValue, MaxValue);
	BarSpCur->SetPercent(Percent);
}

void UCWUIPawnWidget::SetHPColor(bool bTeammate)
{
	const FString& AssetId = FString::Printf(TEXT("ImgProgress%d"), (int32)bTeammate);
	UTexture2D* Texture = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, AssetId);
	UCWUIUtil::SetProgressFullImage(BarHpCur.Get(), Texture);
	UCWUIUtil::SetProgressFullImage(BarHpPre.Get(), Texture);
}

void UCWUIPawnWidget::ShowPreviewInfo(bool bNewVisible)
{
}

void UCWUIPawnWidget::SetAtkAttrText(ECWBattleAttackType Type)
{
	/*const FString& LangKey = (Type == ECWBattleAttackType::Physical) ? TEXT("Pawn_Physical_Attack") :
							(Type == ECWBattleAttackType::Magic) ? TEXT("Pawn_Magic_Attack") : TEXT("");
	const FString& LangStr = FCWCfgUtils::GetLanguageString(this, LangKey);
	TxtAtkAttr->SetText(FSTRING_TO_FTEXT(LangStr));*/
}

void UCWUIPawnWidget::ShowHeadIcon(EUIHeadIconType IconType /*= EUIHeadIconType::None*/)
{
	TrsHeadTag->SetVisibility(IconType == EUIHeadIconType::None ? ESlateVisibility::Collapsed : ESlateVisibility::HitTestInvisible);

	if (IconType != EUIHeadIconType::None)
	{
		const FString& AssetId = (IconType == EUIHeadIconType::Switch) ? TEXT("icon_switch") :
			(IconType == EUIHeadIconType::Attack) ? TEXT("icon_attack") :
			(IconType == EUIHeadIconType::Support) ? TEXT("icon_support") : TEXT("");
		UTexture2D* Texture = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, AssetId);
		ImgIcon->SetBrushFromTexture(Texture);

		const FString& NewIconTxt = (IconType == EUIHeadIconType::Switch) ? TEXT("Switch") :
			(IconType == EUIHeadIconType::Attack) ? TEXT("Attack") :
			(IconType == EUIHeadIconType::Support) ? TEXT("Support") : TEXT("");
		TxtIcon->SetText(FSTRING_TO_FTEXT(NewIconTxt));
	}
}

void UCWUIPawnWidget::UpdatePreviewInfo(ACWPawn* InOtherPawn, const FFightPreviewData& InOtherData, const FFightPreviewData& InMyData)
{
	const int32 CurValue = FMath::Max<int32>(InMyData.Hp, 0);
	const int32 MaxValue = FMath::Max<int32>(InMyData.MaxHp, 0);
	const float CurPercent = UCWUIUtil::Divide_IntInt(CurValue, MaxValue);
	BarHpPre->SetPercent(CurPercent);

	const int32 PreValue = FMath::Max<int32>(InMyData.Hp - InOtherData.DMG, 0);
	const float PrePercent = UCWUIUtil::Divide_IntInt(PreValue, MaxValue);
	BarHpCur->SetPercent(PrePercent);
}

void UCWUIPawnWidget::UpdateImgWeapon(const FString& InAssetId)
{
	UTexture2D* Texture = FCWCfgUtils::GetUIAssetObject<UTexture2D>(this, InAssetId);
	if (nullptr != Texture)
	{
		ImgWeapon->SetBrushFromTexture(Texture);
	}
	ImgWeapon->SetVisibility(Texture ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

void UCWUIPawnWidget::ShowRefrainIcon(int8 InRefrainType)
{
	const bool bIsShow = (InRefrainType != 0);
	if (bIsShow)
	{
		const FString& AssetId = 
			(InRefrainType > 0) ? TEXT("icon_Up") :
			(InRefrainType < 0) ? TEXT("icon_Down") : TEXT("");
		UCWUIUtil::SetImageTexture(ImgRefrain.Get(), AssetId);
	}
	ImgRefrain->SetVisibility(bIsShow ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

void UCWUIPawnWidget::ShowMiniAvatar(bool bNewVisible)
{
	ImgMiniAvatar->SetVisibility(bNewVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

void UCWUIPawnWidget::UpdateBuffList(ACWPawn* InPawn)
{
	UHorizontalBox* TrsBuffList = Cast<UHorizontalBox>(GetWidgetFromName(FName("TrsBuffList")));
	if (nullptr == InPawn || nullptr == TrsBuffList)
	{
		return;
	}

	//TrsBuffList->SetVisibility(ESlateVisibility::Collapsed);
	TArray<FUIBuffNodeData> PawnBuffArray = InPawn->GetBuffListInfo();
	const int32 TrsBuffListNum = TrsBuffList->GetChildrenCount();
	const int32 MaxIdx = FMath::Max(PawnBuffArray.Num(), TrsBuffListNum);

	for (int32 Idx = 0; Idx < MaxIdx; ++Idx)
	{
		UWidget* Widget = TrsBuffList->GetChildAt(Idx);
		if (PawnBuffArray.IsValidIndex(Idx))
		{
			if (UCWUIBuffBtn* UIItem = Cast<UCWUIBuffBtn>(Widget))
			{	// 更新
				UIItem->UpdateItem(PawnBuffArray[Idx]);
				UIItem->SetVisibility(ESlateVisibility::Visible);
			}
			else if (const FCWUIWidgetData* WidgetData = FCWCfgUtils::GetUIWidgetData(this, FUIKey::UIItemBuff))
			{
				if (UCWUIBuffBtn* NewItem = CreateWidget<UCWUIBuffBtn>(TrsBuffList, WidgetData->UIWidget))
				{	// 添加
					NewItem->UpdateItem(PawnBuffArray[Idx]);
					TrsBuffList->AddChildToHorizontalBox(NewItem);
					NewItem->SetVisibility(ESlateVisibility::Visible);
				}
			}
		}
		else if (IsValid(Widget))
		{	// 隐藏/删除
			Widget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void UCWUIPawnWidget::FlyWordsEffectImpl(const uint8 InType, const float InValue, const FString& InParam /*= TEXT("")*/)
{
}
