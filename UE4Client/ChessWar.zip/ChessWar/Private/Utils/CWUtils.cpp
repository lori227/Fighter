#include "CWUtils.h"
#include <iostream>  
#include <sstream>
#include "CWAppId.h"

FString FCWUtils::StdString2FString(const std::string& ParamString)
{
	FString TempFString(ParamString.c_str());
	return TempFString;
}

std::string FCWUtils::FString2StdString(const FString& ParamString)
{
	std::string TempStdString(TCHAR_TO_UTF8(*ParamString));
	return TempStdString;
}

FString FCWUtils::Uint642FString(uint64 ParamUint64)
{
	std::ostringstream o;
	o << ParamUint64;
	std::string StdString = o.str();
	return StdString2FString(StdString);
}

uint64 FCWUtils::FString2Uint64(const FString& ParamString)
{
	std::string TempStdString = FString2StdString(ParamString);
	std::stringstream o;
	o << TempStdString;
	uint64 ret = 0;
	o >> ret;
	return ret;
}

uint64 FCWUtils::FStringAppId2Uint64Id(const FString& ParamStringAppId)
{
	CWAppId tempUint64AppId(FString2StdString(ParamStringAppId));
	return tempUint64AppId.GetId();
}