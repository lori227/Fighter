#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWAffector.h"
#include "Global/CWGameDefine.h"
//#include "CWActionAgainAffector.generated.h"

struct FCWAffectorDataStruct;
class UCWCastSkillContext;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWActionAgainAffector : public UCWAffector
{
	//GENERATED_UCLASS_BODY()
public:
	UCWActionAgainAffector();
	virtual ~UCWActionAgainAffector();

public:
	virtual bool OnAffect() override;

	virtual bool OnAffectorBegin() override;
	virtual bool OnAffectorEnd() override;

protected:


};