#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include <vector>
#include "Global/CWGameDefine.h"
//#include "CWAffector.generated.h"

class ACWPawn;
class UCWBuff;
class UCWCastSkillContext;
struct FCWAffectorDataStruct;
class UCWPawnBattlePropertyComponent;
struct FCWBattlePropertyAffectorData;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWAffector //: public UObject
{
	//GENERATED_UCLASS_BODY()
public:
	UCWAffector();
	virtual ~UCWAffector();

public:
	/** 通过BuffId 初始化Buff
	 * @param	int AffetorId
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool Init(UCWBuff* ParamParantBuff, int ParamAffetorId, TSharedPtr<UCWCastSkillContext> ParamCastSkillContextPtr);


	/** 设置Affector子类型
	 * @param	int32 Affector子类型
	 * @return	无
	 */
	void SetAffectorSubType(int32 ParamAffectorSubType);


	/** 获得Affector子类型
	 * @param	无
	 * @return	int32 Affector子类型
	 */
	int32 GetAffectorSubType() const;


	/** 设置公式类型
	 * @param	int32 公式类型
	 * @return	无
	 */
	void SetAffectorOperationType(int32 ParamAffectorOperationType);


	/** 获得公式类型
	 * @param	无
	 * @return	int32 公式类型
	 */
	int32 GetAffectorOperationType() const;


	/** 设置参数数组
	 * @param	const std::vector<float>& 参数数组
	 * @return	无
	 */
	void SetArrayAffectorParams(const std::vector<float>& ParamArrayAffectorParams);


	/** 设置 影响器数据可以作用于对象的类型
	 * @param	int32 影响器数据可以作用于对象的类型
	 * @return	无
	 */
	void SetAffectorDataAffectType(int32 ParamAffectorDataAffectType);


	/** 获得 影响器数据可以作用于对象的类型
	 * @param	无
	 * @return	int32 影响器数据可以作用于对象的类型
	 */
	int32 GetAffectorDataAffectType();


	/** 设置 影响器数据可以作用于对象的类型
	 * @param	int32 影响器数据可以作用于对象的类型
	 * @return	无
	 */
	void SetAffectorDataAffectKeyTimeType(int32 ParamAffectorDataAffectKeyTimeType);


	/** 获得 影响器数据可以作用于对象的类型
	 * @param	无
	 * @return	int32 影响器数据可以作用于对象的类型
	 */
	int32 GetAffectorDataAffectKeyTimeType();


	/** 获得AffectorId
	 * @param	无
	 * @return	int32 AffectorId
	 */
	int32 GetAffectorId() const;


	/** 获得Affector数据
	 * @param	无
	 * @return	const FCWAffectorDataStruct* Affector数据
	 */
	const FCWAffectorDataStruct* GetAffectorDataStruct() const;

	/** 检测参数是否匹配 */
	static bool IsValidParamsWithModifyOp(const ECWBattlePropertyModifyOp InModifyOpType, const int32 InParamsSize);

	// Temp Code
	virtual void SetAffectorLimitDistanceType(uint8 InTypeValue);

public:
	virtual bool IsAffectorType(const ECWAffectorType InAffectorType);

	virtual bool OnAffect();

	virtual bool OnAffectorBegin();
	virtual bool OnAffectorEnd();

	virtual bool IsAffectInKeyTime(ECWKeyTimeType ParamKeyTimeType);
	virtual bool IsFinishInKeyTime(ECWKeyTimeType ParamKeyTimeType);

	virtual bool RemoveAffectorDataFromArrayPropertyAffectorData(
		int ParamAffectorId, 
		int ParamBuffId, 
		int ParamBuffUniqueId);

	virtual bool AddAffectorDataFromArrayPropertyAffectorData(const FCWBattlePropertyAffectorData& ParamAffectorData);

protected:
	//UPROPERTY()
	UCWBuff* ParantBuff;

	/** 引用施法技能上下文 */
	TSharedPtr<UCWCastSkillContext> CastSkillContextPtr;

	/** 影响器类型 */
	ECWAffectorType AffectorType;

	/** 此Affector的AffectorId */
	int32 AffectorId;

	/**  AffectorId子类型（或效果器子类型）  （如： 对属性修改型，其子类型是：ECWBattleProperty */
	int32 AffectorSubType;

	/** 公式类型 ECWBattlePropertyModifyOp */
	int32 AffectorOperationType;

	/** 参数数组 */
	TArray<float> ArrayAffectorParams;

	/** 影响器数据可以作用于对象的类型 ECWPropertyAffectorDataAffectType */
	int32 AffectorDataAffectType;

	/** 影响器数据可以作用于对象的类型 ECWKeyTimeType */
	int32 AffectorDataAffectKeyTimeType;

	// 影响器生效条件(0:不限制 1:近战 2:远战) Temp Code
	uint8 AffectorLimitDistanceType;

};
