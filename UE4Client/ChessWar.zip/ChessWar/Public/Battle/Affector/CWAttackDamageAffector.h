#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWAffector.h"
#include "Global/CWGameDefine.h"
//#include "CWAttackDamageAffector.generated.h"

struct FCWAffectorDataStruct;
class UCWCastSkillContext;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWAttackDamageAffector : public UCWAffector
{
	//GENERATED_UCLASS_BODY()
public:
	UCWAttackDamageAffector();
	virtual ~UCWAttackDamageAffector();

public:
	virtual bool OnAffect() override;

	virtual bool IsAffectInKeyTime(ECWKeyTimeType ParamKeyTimeType) override;

protected:

};
