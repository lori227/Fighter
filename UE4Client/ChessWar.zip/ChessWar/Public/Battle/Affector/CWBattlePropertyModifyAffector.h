﻿
#pragma once

#include "CWAffector.h"
#include "CWGameDefine.h"


/**
 * @Brief Affector: 战斗属性修改(ATK/DEF...)
 */
class UCWBattlePropertyModifyAffector : public UCWAffector
{
public:
	UCWBattlePropertyModifyAffector();
	virtual ~UCWBattlePropertyModifyAffector();

public:
	virtual bool OnAffect() override;

	virtual bool OnAffectorBegin() override;
	virtual bool OnAffectorEnd() override;

protected:

};