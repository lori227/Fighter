#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWAffector.h"
#include "Global/CWGameDefine.h"
//#include "CWBeatBackAffector.generated.h"

struct FCWAffectorDataStruct;
class UCWCastSkillContext;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWBeatBackAffector : public UCWAffector
{
	//GENERATED_UCLASS_BODY()
public:
	UCWBeatBackAffector();
	virtual ~UCWBeatBackAffector();

public:
	virtual bool OnAffect() override;

protected:

};
