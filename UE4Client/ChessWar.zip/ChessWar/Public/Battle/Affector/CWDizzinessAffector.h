﻿
#pragma once

#include "CWAffector.h"
#include "CWGameDefine.h"


/**
 * @Brief Affector: 眩晕影响器
 */
class UCWDizzinessAffector : public UCWAffector
{
public:
	UCWDizzinessAffector();
	virtual ~UCWDizzinessAffector();

public:
	virtual bool OnAffectorBegin() override;
	virtual bool OnAffectorEnd() override;

};