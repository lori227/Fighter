#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWAffector.h"
#include "Global/CWGameDefine.h"
//#include "CWForbidActionAffector.generated.h"

struct FCWAffectorDataStruct;
class UCWCastSkillContext;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWForbidActionAffector : public UCWAffector
{
	//GENERATED_UCLASS_BODY()
public:
	UCWForbidActionAffector();
	virtual ~UCWForbidActionAffector();

public:
	virtual bool OnAffect() override;

protected:

};