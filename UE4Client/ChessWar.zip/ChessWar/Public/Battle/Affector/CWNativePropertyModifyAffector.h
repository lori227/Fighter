﻿
#pragma once

#include "CWAffector.h"
#include "CWGameDefine.h"


/**
 * @Brief Affector: 原生属性修改(HP/SP)
 */
class UCWNativePropertyModifyAffector : public UCWAffector
{
public:
	UCWNativePropertyModifyAffector();
	virtual ~UCWNativePropertyModifyAffector();

public:
	virtual bool OnAffect() override;

protected:
	/** 获取公式得出值 */
	virtual bool GetResultValue(int32& OutModifyValue, class UCWPawnBattlePropertyComponent* InBattleProperty);

};