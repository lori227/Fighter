﻿
#pragma once

#include "CWAffector.h"
#include "CWGameDefine.h"


/**
 * @Brief Affector: 防御护盾
 */
class UCWShieldAffector : public UCWAffector
{
public:
	UCWShieldAffector();
	virtual ~UCWShieldAffector();

public:
	virtual bool OnAffect() override;

	virtual bool ConsumeShield(TSharedPtr<UCWCastSkillContext> InCastSkillContext);

protected:
	virtual FString ToString();

protected:
	//~ 施法者相关
	int32 NetPawnUniqueIdx;
	int32 NetPawnSkillId;
	int32 RemainDamageCnt;

};