#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "CWAffector.h"
#include "Global/CWGameDefine.h"
//#include "CWTakeThePlaceOfSomePawnForFightingAffector.generated.h"

struct FCWAffectorDataStruct;
class UCWCastSkillContext;

/**
 * @brief Affector \n
 *
 */
//UCLASS()
class UCWTakeThePlaceOfSomePawnForFightingAffector : public UCWAffector
{
	//GENERATED_UCLASS_BODY()
public:
	UCWTakeThePlaceOfSomePawnForFightingAffector();
	virtual ~UCWTakeThePlaceOfSomePawnForFightingAffector();

public:
	virtual bool OnAffect() override;

protected:

};
