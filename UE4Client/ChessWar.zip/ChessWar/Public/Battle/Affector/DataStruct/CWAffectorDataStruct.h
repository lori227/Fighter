#pragma once
#include "Engine.h"
#include "CWAffectorDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWAffectorDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWAffectorDataStruct();
	virtual ~FCWAffectorDataStruct();
public:

	/** AffectorId */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "AffectorDataStruct")
	int32 AffectorId;

	/** Affector名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "AffectorDataStruct")
	FString AffectorName;

	/** Affector描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "AffectorDataStruct")
	FString AffectorDescForDoc;

	/** 影响器类型（或效果器类型） ECWAffectorType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "AffectorDataStruct")
	int32 AffectorType;
};