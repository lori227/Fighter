#include "CWAffectorDataUtils.h"

std::vector<int32> FCWAffectorDataUtils::GetArrayAffectorIdFromString(const FString& ParamString)
{
	std::vector<int32> ArrayAffectorId;
	TArray<FString> strArray;
	ParamString.ParseIntoArray(strArray, TEXT("|"), false);
	for (TArray<FString>::TConstIterator iter = strArray.CreateConstIterator(); iter; ++iter)
	{
		FString TempString = *iter;
		int32 TempAffectorId = FCString::Atoi(*TempString);
		ArrayAffectorId.push_back(TempAffectorId);
	}

	return ArrayAffectorId;
}

