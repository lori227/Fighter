#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWAffectorDataUtils
{
public:

	/** 从字符串解析出AffectorId数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	AffectorId数组
	 */
	static std::vector<int32> GetArrayAffectorIdFromString(const FString& ParamString);
};