﻿#pragma once


#include "CoreMinimal.h"
#include "Engine.h"
#include <vector>
#include "Global/CWGameDefine.h"
#include "CWBattlePropertySet.h"
#include "CWBattlePropertyAffectorData.generated.h"

USTRUCT(BlueprintType)
struct FCWBattlePropertyAffectorData
{
	GENERATED_USTRUCT_BODY()
public:
	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWBattlePropertyAffectorData();


	/** 拷贝构造函数
	 * @param	const FCWBattlePropertyAffectorData&	另一个影响器数据
	 * @return	无
	 */
	FCWBattlePropertyAffectorData(const FCWBattlePropertyAffectorData& r);


	/** 赋值函数
	 * @param	const FCWBattlePropertyAffectorData&	另一个影响器数据
	 * @return	FCWBattlePropertyAffectorData&		返回自己的引用
	 */
	FCWBattlePropertyAffectorData& operator = (const FCWBattlePropertyAffectorData& r);


	/** 友元==
	 * @param	const FCWBattlePropertyAffectorData&	另一个影响器数据l
	 * @param	const FCWBattlePropertyAffectorData&	另一个影响器数据r
	 * @return	bool true:相等, false:不相等
	 */
	friend bool operator == (const FCWBattlePropertyAffectorData& l, const FCWBattlePropertyAffectorData& r);


	/** 重置
	 * @param	无
	 * @return	无
	 */
	void Reset();

	/** 是否满足条件
	 * @param	
	 * @return	
	 */
	bool IsSameConditioin(TSharedPtr<class UCWCastSkillContext> ParamCastSkillContext) const;

	/** 获取计算公式值 */
	float GetResultValue(const float InBaseValue, const float InDefaultValue = 0.f) const;

	/** ToDebugString */
	FString ToDebugString() const;

public:

	/**< 来源类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWBuffSouceType SouceType;

	/**< 来源唯一Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SourceUniqueId;

	/**< 来源类型Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SourceTypeId;

	/**< 来源自定义参数1 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SourceCustomParam1;

	/**< 来源自定义参数2 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SourceCustomParam2;
	
	/**< 作用类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWPropertyAffectorDataAffectType AffectType;

	/**< 作用时间类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWKeyTimeType AffectKeyTimeType;

	/**< 作用战斗属性类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWBattleProperty AffectBattlePropertyType;

	/**< 作用战斗属性类型的公式类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWBattlePropertyModifyOp BattlePropertyModifyOpType;

	/**< 作用战斗属性类型的公式的相关参数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	TArray<float> BattlePropertyModifyOpParams;

	// 影响器生效条件(0:不限制 1:近战 2:远战) Temp Code
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	uint8 AffectorLimitDistanceType;

};
