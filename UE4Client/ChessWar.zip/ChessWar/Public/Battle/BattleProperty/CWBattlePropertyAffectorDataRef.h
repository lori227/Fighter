#pragma once


#include "CoreMinimal.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWBattlePropertyAffectorData.h"
#include "CWBattlePropertyAffectorDataRef.generated.h"


/**
* @brief 战斗属性影响器数据的引用 \n
*
*/
UCLASS()
class UCWBattlePropertyAffectorDataRef : public UObject
{
	GENERATED_UCLASS_BODY()
public:

	/** 拷贝战斗属性影响器数据
	 * @param	const FCWBattlePropertyAffectorData&	想要拷贝的战斗属性影响器数据
	 * @return	无
	 */
	void Copy(const FCWBattlePropertyAffectorData& ParamPropertyAffectorData);


	/** 获得战斗属性影响器数据
	 * @param	无
	 * @return	FCWBattlePropertyAffectorData&		返回战斗属性影响器数据
	 */
	FCWBattlePropertyAffectorData& GetPropertyAffectorData();


	/** 获得战斗属性影响器数据
	* @param	无
	* @return	const FCWBattlePropertyAffectorData&	返回战斗属性影响器数据
	*/
	const FCWBattlePropertyAffectorData& GetPropertyAffectorData() const;

protected:

	/**< 战斗属性影响器数据 */
	UPROPERTY(VisibleAnywhere)
	FCWBattlePropertyAffectorData PropertyAffectorData;
};
