#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWBattlePropertyModifier.generated.h"


/**
* @brief 战斗相关属性修改器 \n
*
*/
USTRUCT()
struct FCWBattlePropertyModifier
{
	GENERATED_USTRUCT_BODY()

public:

	/** 构造函数
	 */
	FCWBattlePropertyModifier();


	/** 构造函数
	 *	@param	ECWBattleProperty	指定修改的属性类型
	 *	@param	ECWBattlePropertyModifyOp	对属性修改方式类型
	 *	@param	float	Param1
	 *	@param	float	最小值
	 *	@param	float	最大值
	 *	@retrun	无
	 */
	FCWBattlePropertyModifier(
		ECWBattleProperty ParamPropertyType,
		ECWBattlePropertyModifyOp ParamModifyOperateType,
		float ParamParam1,
		float ParamMin,
		float ParamMax
		);


	/** 构造函数
	 *	@param	ECWBattleProperty	指定修改的属性类型
	 *	@param	ECWBattlePropertyModifyOp	对属性修改方式类型
	 *	@param	float	Param1
	 *	@param	float	Param2
	 *	@param	float	最小值
	 *	@param	float	最大值
	 *	@retrun	无
	 */
	FCWBattlePropertyModifier(
		ECWBattleProperty ParamPropertyType,
		ECWBattlePropertyModifyOp ParamModifyOperateType,
		float ParamParam1,
		float ParamParam2,
		float ParamMin,
		float ParamMax
		);
public:
	
	/** 指定修改属性集合里的某个属性的类型 */
	UPROPERTY()
	ECWBattleProperty PropertyType;

	/** 修改操作类型 */
	UPROPERTY()
	ECWBattlePropertyModifyOp ModifyOperateType;

	/** 参数1 */
	UPROPERTY()
	float Param1;

	/** 参数2 */
	UPROPERTY()
	float Param2;

	/** 最小值 */
	float ValueMin;

	/** 最大值 */
	float ValueMax;
};