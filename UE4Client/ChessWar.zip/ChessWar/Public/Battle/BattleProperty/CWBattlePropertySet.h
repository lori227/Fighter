﻿#pragma once


#include "CoreMinimal.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWBattlePropertySet.generated.h"


struct FCWBattlePropertyModifier;

/**
 * @brief 战斗相关属性集合 \n
 *
 */
USTRUCT(BlueprintType)
struct FCWBattlePropertySet
{
	GENERATED_USTRUCT_BODY()
public:

	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWBattlePropertySet();


	/** 拷贝构造函数
	 * @param	const FCWBattlePropertySet&	另一个战斗属性集合
	 * @return	无
	 */
	FCWBattlePropertySet(const FCWBattlePropertySet& r);


	/** 赋值函数
	 * @param	const FCWBattlePropertySet&	另一个战斗属性集合
	 * @return	FCWBattlePropertySet&		返回自己的引用
	 */
	FCWBattlePropertySet& operator = (const FCWBattlePropertySet& r);


	/** 重置
	 * @param	无
	 * @return	无
	 */
	void Reset();


	/** 获取战斗属性值
	 * @param	ECWBattleProperty	战斗属性类型
	 * @return	float					战斗属性值
	 */
	float GetPropertyByFloat(ECWBattleProperty ParamBattlePropertyType) const;


	/** 获取战斗属性值
	 * @param	ECWBattleProperty	战斗属性类型
	 * @return	int32					战斗属性值
	 */
	int32 GetPropertyByInt(ECWBattleProperty ParamBattlePropertyType) const;


	/** 获取战斗属性值
	 * @param	ECWBattleProperty	战斗属性类型
	 * @return	ECWBattleAttackType		战斗属性值
	 */
	ECWBattleAttackType GetPropertyForAttackType(ECWBattleProperty ParamBattlePropertyType) const;
	

	/** 获取战斗属性值
	 * @param	ECWBattleProperty	战斗属性类型
	 * @return	ECWPropertySetAffectorType		战斗属性值
	 */
	ECWPropertySetAffectorType GetPropertyForAffectorType(ECWBattleProperty ParamBattlePropertyType) const;
	

	/** 设置战斗属性值
	 * @param	ECWBattleProperty	战斗属性类型
	 * @return	T					战斗属性值
	 */
	template<typename T>
	void SetProperty(ECWBattleProperty ParamBattlePropertyType, T ParamBattleProperty);


	/** 通过属性修改器修改战斗属性值
	 * @param	const FCWBattlePropertyModifier&	属性修改器
	 * @return	bool	true:修改成功，false:修改失败
	 */
	bool ModifyProperty(const FCWBattlePropertyModifier& Modifier);

public:
	
	/**< 攻击力 01 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AttackValue;

	/**< 物理防御 02 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float PhysicalDefenceValue;

	/**< 魔法防御 03 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float MagicDefenceValue;

	/**< 生命值 04 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float HealthValue;

	/**< 能量值 05 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float EnergyValue;

	/**< 技巧值 06 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float TalentValue;

	/**< 行动力 07 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float MoveValue;

	/**< 暴击率 08 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CriticalHitRateValue;

	/**< 暴击伤害系数 09 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CriticalDamageFactorValue;

	/**< 出手速度 10 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AttackSpeedValue;

	/**< 影响回避率的速度 11 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float SpeedValue;

	/**< 命中率 12 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float HitRateValue;

	/**< 回避率 13 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AvoidanceRateValue;

	/**< 格挡率 14 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float BlockRateValue;


	/**< 攻击力系数 15 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AttackFactorValue;

	/**< 物理防御系数 16 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float PhysicalDefenceFactorValue;

	/**< 魔法防御系数 17 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float MagicDefenceFactorValue;

	/**< 生命值系数 18 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float HealthFactorValue;

	/**< 能量值系数 19 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float EnergyFactorValue;

	/**< 技巧值系数 20 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float TalentFactorValue;

	/**< 行动力系数 21 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float MoveFactorValue;

	/**< 暴击率系数 22 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CriticalHitRateFactorValue;

	/**< 暴击伤害系数系数 23 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CriticalDamageFFValue;

	/**< 出手速度系数 24 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AttackSpeedFactorValue;

	/**< 影响回避率的速度系数 25 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float SpeedFactorValue;

	/**< 命中率系数 26 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float HitRateFactorValue;

	/**< 回避率系数 27 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float AvoidanceRateFactorValue;

	/**< 格挡率系数 28 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float BlockRateFactorValue;


	/**< 防御姿态系数 29 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float DefincePostureFactorValue;

	/**< 防御姿态叠加 30 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float DefincePostureValue;

	/**< 最终伤害系数 31 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float FinalDamageFactorValue;
		
	/**< 最终伤害叠加 32 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float FinalDamageValue;


	/**< 唯一Id 33 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 UniqueIdValue;

	/**< 职业类型 34 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 ProfessionValue;

	/**< 攻击类型 35 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	ECWBattleAttackType AttackTypeValue;


	/**< 属性集合影响类型 36 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	ECWPropertySetAffectorType PropertySetAffectorTypeValue;
};