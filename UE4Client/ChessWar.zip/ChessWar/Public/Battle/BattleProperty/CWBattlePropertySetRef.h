#pragma once


#include "CoreMinimal.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWBattlePropertySet.h"
//#include "CWBattlePropertySetRef.generated.h"


/**
 * @brief 战斗相关属性集合引用对象(对结构包一层，方便放到容器里，以指针的形式放到容器里，而不是struct的方式放到容器里) \n
 *
 */
//UCLASS()
class UCWBattlePropertySetRef //: public UObject
{
	//GENERATED_UCLASS_BODY()
public:

	/** 拷贝战斗属性集合
	 * @param	const FCWBattlePropertySet&	想要拷贝的战斗属性集合
	 * @return	无
	 */
	void Copy(const FCWBattlePropertySet& ParamPropertySet);


	/** 获得战斗属性集合
	 * @param	无
	 * @return	FCWBattlePropertySet&		返回战斗属性集合
	 */
	FCWBattlePropertySet& GetPropertySet();


	/** 获得战斗属性集合
	 * @param	无
	 * @return	const FCWBattlePropertySet&		返回战斗属性集合
	 */
	const FCWBattlePropertySet& GetPropertySet() const;

protected:

	/**< 战斗属性集合 */
	//UPROPERTY(VisibleAnywhere)
	FCWBattlePropertySet PropertySet;
};
