
#pragma once

#include <map>
#include <list>
#include "Engine.h"
#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "InputCoreTypes.h"

#include "CWEventMgr.h"
#include "CWGameDefine.h"
//#include "CWBuff.generated.h"

struct FCWBuffDataStruct;
class UCWBuffManager;
class UCWCastSkillContext;
class UCWAffector;


/**
 * @brief Buff \n
 * 
 */
//UCLASS()
class UCWBuff //: public UObject
{
	//GENERATED_UCLASS_BODY()
public:
	UCWBuff();
	virtual ~UCWBuff();

public:

	/** 通过BuffId 初始化Buff
	 * @param	UCWBuffManager* Buff管理器
	 * @param	int BuffUniqueId
	 * @param	int BuffId
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool InitInServer(UCWBuffManager* ParamParantBuffManager, int ParamBuffUniqueId, int ParamBuffId, TSharedPtr<UCWCastSkillContext> ParamCastSkillContext);


	/** 通过BuffId 初始化Buff
	 * @param	UCWBuffManager* Buff管理器
	 * @param	int BuffUniqueId
	 * @param	int BuffId
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool InitInClient(UCWBuffManager* ParamParantBuffManager, int ParamBuffUniqueId, int ParamBuffId);


	/** 每回合重置数据
	 * @param	无
	 * @return	bool true:重置成功，false:重置失败
	 */
	bool ResetForRound();


	/** 递减此Buff的剩余回合数
	 * @param	无
	 * @return	无
	 */
	void DecreaseRemainLifeRoundCount();


	/** 获得剩余回合数
	 * @param	无
	 * @return	int32 剩余回合数
	 */
	int32 GetCurRemainLifeRoundCount() const;


	/** 获得Buff数据
	 * @param	无
	 * @return	const FCWBuffDataStruct* Buff数据
	 */
	const FCWBuffDataStruct* GetBuffDataStruct() const;


	/** 获得释放技能上下文
	 * @param	无
	 * @return	TSharedRef<UCWCastSkillContext> 释放技能上下文
	 */
	TSharedPtr<UCWCastSkillContext> GetCastSkillContext() const;


	/** 获得Buff唯一Id
	 * @param	无
	 * @return	int32 Buff唯一Id
	 */
	int32 GetBuffUniqueId() const;


	/** 获得BuffId
	 * @param	无
	 * @return	int32 BuffId
	 */
	int32 GetBuffId() const;


	/** 获得Buff管理器
	 * @param	无
	 * @return	UCWBuffManager* Buff管理器
	 */
	UCWBuffManager* GetBuffManager();


	/** 递增此Buff的每回合触发Affector的次数
	 * @param	无
	 * @return	无
	 */
	void IncreaseTriggerAffectorCountForRound();


	/** 获得此Buff的每回合触发Affector的次数
	 * @param	无
	 * @return	int32  此技能的每回合触发Buff的次数
	 */
	int32 GetTriggerAffectorCountForRound() const;

	/** Buff来源 */
	virtual ECWBuffSouceType GetSouceType() const;
	virtual void SetSouceType(const ECWBuffSouceType InSouceType);

	/** 设置当前剩余回合 */
	virtual void SetCurRemainLifeRoundCount(const int32 InRemain);

public:
	bool IsSameKeyTime(ECWKeyTimeType ParamKeyTimeType1, ECWKeyTimeType ParamKeyTimeType2);
	void OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType);

	bool IsSameFinishKeyTime(ECWBuffLifeFinishType ParamLifeFinishType, ECWKeyTimeType ParamKeyTimeType);
	bool IsFinishInKeyTime(ECWKeyTimeType ParamKeyTimeType);

	void OnBuffBeginInServer();
	void OnBuffEndInServer();

	void OnBuffBeginInClient();
	void OnBuffEndInClient();

	/** 检测消耗护盾 */
	virtual bool CheckAndConsumeShield(const int32 InDamageValue, 
		const bool bIsHasImmediatelyUsing = true, TSharedPtr<UCWCastSkillContext> InCastSkillContext = nullptr);

protected:
	float RandomFloat(float Min, float Max);
	bool GenerateAffector(ECWKeyTimeType ParamKeyTimeType);
	UCWAffector* AffectorCreateByAffectorType(ECWAffectorType ParamAffectorType);
	void AddToMap(int32 ParamAffectorId, UCWAffector* ParamAffector);

	/** 更新当前数据 */
	virtual void OnUpdateBuffData();

public:
	/** Buff销毁回调 */
	//UPROPERTY(BlueprintAssignable, Category = "Event")
	FOnBuffDestroyed OnBuffDestroyed;
	EObjElemType RefElemType;

protected:
	/** 施法者技能上下文 */
	TSharedPtr<UCWCastSkillContext> CastSkillContextPtr;

	/** Buff来源 */
	ECWBuffSouceType SouceType;
	
	/** 此Buff的剩余回合数 */
	int32 CurRemainLifeRoundCount;

	/** 此Buff的Buff唯一Id */
	int32 BuffUniqueId;

	/** 此Buff的BuffId */
	int32 BuffId;

	/** 此Buff的所属的Buff管理器 */
	UPROPERTY()
	UCWBuffManager* ParantBuffManager;

	/** 所有Affector */
	std::map<int32, UCWAffector*> MapAffector;

	/** 此Buff的每回合触发Affector的次数 */
	int32 TriggerAffectorCountForRound;
	//------------------------------------------
	//相关结束条件的数据
	/** 普通攻击的次数 */
	int32 TotalNormalAttackCount;

	std::list<int32> ListBuffEffectId;

};
