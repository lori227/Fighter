
#pragma once

#include <list>
#include <map>

#include "Engine.h"
#include "CoreMinimal.h"
#include "UnrealNetwork.h"

#include "CWGameDefine.h"
#include "CWBuffManager.generated.h"

class UCWBuff;
class ACWPawn;
class UCWSkill;
struct FUIBuffNodeData;
class UCWCastSkillContext;

/**
* @brief Buff管理器 \n
*/
UCLASS()
class UCWBuffManager : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	//virtual ~UCWBuffManager();

public:

	/** 通过棋子Id 初始化Buff管理器
	 * @param	ACWPawn* 此Buff管理器的拥有者
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool Init(ACWPawn* ParamParentPawn);


	/** 销毁
	 * @param	无
	 * @return	无
	 */
	void DestoryAll();


	/** 每回合重置数据
	 * @param	无
	 * @return	bool true:重置成功，false:重置失败
	 */
	bool ResetForRound();


	/** 添加一个Buff
	 * @param	UCWBuff* Buff
	 * @return	bool true:添加成功，false:添加失败
	 */
	bool AddBuffInServer(UCWBuff* ParamBuff);


	/** 添加一个Buff
	 * @param	UCWBuff* Buff
	 * @return	bool true:添加成功，false:添加失败
	 */
	bool AddBuffInClient(UCWBuff* ParamBuff);


	/** 生成Buff唯一Id
	 * @param	无
	 * @return	int Buff唯一Id
	 */
	int GenerateBuffUniqueId();


	/** 获得棋子
	 * @param	无
	 * @return	ACWPawn* 棋子
	 */
	ACWPawn* GetPawn();

	/** 移除一个Buff
	 * @param	int32 唯一Id
	 * @param	int32 BuffId
	 * @return	无
	 */
	void RemoveBuffInServer(int32 InBuffUniqueId, int32 InBuffId);

	/** 移除一个Buff
	 * @param	int32 唯一Id
	 * @param	int32 BuffId
	 * @return	无
	 */
	void RemoveBuffInClient(int32 ParamBuffUniqueId, int32 ParamBuffId);

	/** 更新剩余回合-BUFF */
	virtual void OnUpdateBuffInClient(const int32 InBuffUniqueId, const int32 InBuffId, const int32 InRemain);

public:

	void OnKeyTimeInServer(ECWKeyTimeType ParamKeyTimeType);

protected:

	void DecreaseAllBuffRemainLifeRoundCount();
	int32 GetTotalBuffSizeFromDifferentBuffId();
	bool AddBuffToSameBuffId(UCWBuff* ParamBuff);
	bool ReplacedBuffBySameBuffId(UCWBuff* ParamBuff);
	int32 FindReplacedBuffIdByDifferentBuffId(int ParamBuffId);
	bool RemoveBuffByDifferentBuffId(int32 ParamBuffId);

	static int BuffRemainLifeRoundCompare(const void* ParamBuff1, const void* ParamBuff2);

public:
	/** 被动BUFF */
	bool AddPassivityBuff(UCWSkill* ParamPassivitySkill);
	void RemovePassivityBuff(UCWSkill* ParamPassivitySkill);
	void RemovePassivityBuffInClient(const int32 InBuffUniqueId, const int32 InBuffId);

	bool GetBuffInfoList(TArray<FUIBuffNodeData>& OutList);

	/** @Brief	检测消耗护盾
	 *	@Param InDamageValue:			(>0)
	 *	@Param bIsHasImmediatelyUsing:	(如果有:[True:直接使用 False:只检测])
	 *	@Return	返回最终伤害值(有护盾会抵消..)
	 */
	virtual int32 CheckAndConsumeShield(const int32 InDamageValue, 
		const bool bIsHasImmediatelyUsing = true, TSharedPtr<UCWCastSkillContext> InCastSkillContext = nullptr);

	/** Buff来源获取 */
	static ECWBuffSouceType ToBuffSouceType(const ECWSkillSouceType InSkillSouceType);

protected:

	/** 所有Buff */
	std::map<int32, std::list<UCWBuff*>*> MapListBuff;

	/** 被动技能产生的所有Buff */
	std::list<UCWBuff*> ListPassivityBuff;

	/** 此Buff管理器的拥有者 */
	UPROPERTY()
	ACWPawn* ParentPawn;

	/** Buff唯一Id生成器 */
	int BuffUniqueIdGenerator;

};
