﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWBuffDataStruct.generated.h"


USTRUCT(BlueprintType)
struct FCWBuffDataStruct : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWBuffDataStruct();
	virtual ~FCWBuffDataStruct();

public:

	/** BuffId */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 BuffId;

	/** Buff名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString BuffName;

	/** Buff Icon Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString IconId;

	/** Buff描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString BuffDescForDoc;

	/** 是否Debuff 1:是Debuff, 0:不是Debuff */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 IsDebuff;

	/** Buff持续类型 1:按普通回合数, 0:不是按普通回合数消失，走特殊消失类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 LifeType;

	/** Buff持续回合数 0:为瞬时Buff  -1:为无限回合次数的Buff */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 LifeRoundCount;

	/** Buff生效的回合时间点类型 ECWKeyTimeType (Buff持续类型 按普通回合数才有效)*/
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct", meta = (EditCondition = "LifeType == 1"))
	int32 AffactRoundTimeType;

	/** Buff是否马上生效一次*/
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	bool bAffactImmediatelyWhenBuffBegin;

	/** Buff不是按普通回合数消失，走特殊消失类型 ECWBuffLifeFinishType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 LifeFinishType;

	/** Buff不是按普通回合数消失，走特殊消失类型的参数数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayLifeFinishParams;

	/** 叠加层数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 OverlayCount;

	/** 替换规则类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 ReplaceType;
	//-----------------------------------------------
	/** Buff特效Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayBuffEffectId;
	//-----------------------------------------------
	/** 生成Skill数量 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 SkillNum;

	/** 技能触发条件类型枚举值数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArraySkillTriggerConditionType;

	/** 技能触发条件枚举值逻辑操作数组的数组 (触发条件之间是逻辑与还是逻辑或)*/
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArraySkillTriggerConditionLogicOp;

	/** 技能触发条件具体枚举值数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArraySkillTriggerConcretenessCondition;

	/** 技能触发条件具体枚举值参数数组的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayArraySkillTriggerConcretenessConditionParams;
	//-----------------------------------------------
	/** SkillId数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArraySkillId;

	/** SkillId数组的公式类型的数组 ECWBattlePropertyModifyOp */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArraySkillOperationType;

	/** SkillId数组对应的参数数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArraySkillParams;
	
	//-----------------------------------------------
	/** 生成Affector数量 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	int32 AffectorNum;

	/** Affector触发条件类型枚举值数组的数组 ECWTriggerConditionType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerConditionType;

	/** Affector触发条件枚举值逻辑操作数组的数组 (触发条件之间是逻辑与还是逻辑或) ECWTriggerConditionTypeLogicOp */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerConditionLogicOp;

	/** Affector触发条件具体枚举值数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerConcretenessCondition;

	/** Buff触发条件具体枚举值的类型值与参数的比较关系的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerCompareRelatioinOp;

	/** Buff触发条件具体枚举值与参数类型的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerCompareRelatioinOpValueType;

	/** Affector触发条件具体枚举值参数数组的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorTriggerConcretenessParams;

	//-----------------------------------------------
	/** AffectorId数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayAffectorId;

	/** AffectorId子类型数组（或效果器子类型数组）  （如： 对属性修改型，其子类型是：ECWBattleProperty */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayAffectorSubType;

	/** AffectorId数组的公式类型的数组 ECWBattlePropertyModifyOp */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayAffectorOperationType;

	/** AffectorId数组的参数数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayArrayAffectorParams;
	//-----------------------------------------------
	/** 影响器数据可以作用于对象的类型 ECWPropertyAffectorDataAffectType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayAffectorDataAffectType;

	/** 影响器数据可以作用于对象的类型 ECWKeyTimeType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "BuffDataStruct")
	FString ArrayAffectorDataAffectKeyTimeType;

	// 影响器生效条件(0:不限制 1:近战 2:远战) Temp Code
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 AffectorLimitDistanceType;

};