#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWBuffDataUtils
{
public:

	/** 从字符串解析出BuffId数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	BuffId数组
	 */
	static std::vector<int32> GetArrayBuffIdFromString(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector的条件类型
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	Buff触发Affector的条件类型
	 */
	static std::vector<std::vector<int32> > GetArrayArrayAffectorTriggerConditionType(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector的逻辑操作
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	Buff触发Affector的逻辑操作
	 */
	static std::vector<std::vector<int32> > GetArrayArrayAffectorTriggerConditionLogicOp(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector具体枚举值
	* @param   const FString&	字符串
	* @return  std::vector<std::vector<int32> >	Buff触发Affector具体枚举值
	*/
	static std::vector<std::vector<int32> > GetArrayArrayAffectorTriggerConcretenessCondition(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector具体枚举值的类型值与参数的比较关系
	* @param   const FString&	字符串
	* @return  std::vector<std::vector<int32> >	Buff触发Affector具体枚举值的类型值与参数的比较关系
	*/
	static std::vector<std::vector<int32> > GetArrayArrayAffectorTriggerCompareRelatioinOp(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector具体枚举值的类型值与参数的比较关系的参数类型
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	Buff触发Affector具体枚举值的类型值与参数的比较关系的参数类型
	 */
	static std::vector<std::vector<int32> > GetArrayArrayAffectorTriggerCompareRelatioinOpValueType(const FString& ParamString);


	/** 从字符串解析出Buff触发Affector具体枚举值相关参数
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<float> >	Buff触发Affector具体枚举值相关参数
	 */
	static std::vector<std::vector<float> > GetArrayArrayAffectorTriggerConcretenessParams(const FString& ParamString);


	/** 从字符串解析出AffectorId数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	AffectorId数组
	 */
	static std::vector<int32> GetArrayAffectorIdFromString(const FString& ParamString);


	/** 从字符串解析出AffectorSubType数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	AffectorSubType数组
	 */
	static std::vector<int32> GetArrayAffectorSubTypeFromString(const FString& ParamString);


	/** 从字符串解析出ArrayAffectorOperationType数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	ArrayAffectorOperationType数组
	 */
	static std::vector<int32> GetArrayAffectorOperationTypeFromString(const FString& ParamString);
	
	
	/** 从字符串解析出ArrayArrayAffectorParams数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<float> >	ArrayArrayAffectorParams
	 */
	static std::vector<std::vector<float> > GetArrayArrayAffectorParamsFromString(const FString& ParamString);


	/** 从字符串解析出ArrayAffectorDataAffectType数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	ArrayAffectorDataAffectType数组
	 */
	static std::vector<int32> GetArrayAffectorDataAffectTypeFromString(const FString& ParamString);


	/** 从字符串解析出ArrayAffectorDataAffectKeyTimeType数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	ArrayAffectorDataAffectKeyTimeType数组
	 */
	static std::vector<int32> GetArrayAffectorDataAffectKeyTimeTypeFromString(const FString& ParamString);


	/** 从字符串解析出ArrayLifeFinishParams数组
	 * @param	const FString&	字符串
	 * @return  std::vector<float>	ArrayLifeFinishParams数组
	 */
	static std::vector<float> GetArrayLifeFinishParamsFromString(const FString& ParamString);


	/** 从字符串解析出Buff特效Id数组
	 * @param	const FString&	字符串
	 * @return	std::vector<FString>	Buff特效Id数组
	 */
	static std::vector<int32> GetArrayBuffEffectIdFromString(const FString& ParamString);
};