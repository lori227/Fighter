
#pragma once

#include "CWUIDefine.h"
#include "CWGameDefine.h"
#include "CWElementSystemData.h"
#include "CWBattleCalculate.generated.h"

class ACWPawn;
class UCWCastSkillContext;
class UCWPawnBattlePropertyComponent;
struct FCWBattlePropertyAffectorData;

/**
 * @brief 战斗计算 \n
 */
UCLASS()
class UCWBattleCalculate : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure)
	static UCWBattleCalculate* Get();

public:

	/** 预测伤害值（除去暴击）
	 * @param	ACWPawn*    攻击者
	 * @param	ACWPawn*	被攻击者
	 * @return	int	预测的伤害值
	 */
	int32 PredictCalculateDamageBySkill(ACWPawn* AttackPawn, ACWPawn* BeDamagedPawn, FUIPreviewExtData& ExtData);


	/** 提取施法者的信息
	 * @param	TSharedPtr<UCWCastSkillContext>	施法时的上下文
	 * @param	ACWPawn*	施法者
	 * @param	int	伤害下标
	 * @return	bool	true:计算成功，false:计算失败
	 */
	bool CalculateDamageBySkill(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* BeDamagedPawn, int DamageIndex);

	/** 计算元素系统反应 */
	virtual bool CalculateElemReactionBySkill(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn);
	virtual bool CalculateElemReaction(const EObjElemType InNewElemType, ACWPawn* InBeDamagedPawn, const ECWBuffSouceType InSouceType = ECWBuffSouceType::Skill);

	/** 计算物理系统反应 */
	virtual bool CalculatePhysicsSystemBySkill(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn);

	/** 执行血量值计算 */
	virtual bool ExecHealthCalculate(TSharedPtr<UCWCastSkillContext> InCasterContext, ACWPawn* InBeDamagedPawn, const int32 InDamageValue);

public:
	/** 获取效果器数组加成结果值 */
	float GetResultValue(TSharedPtr<UCWCastSkillContext> InCasterContext, const TArray<FCWBattlePropertyAffectorData>& AffectorDataArray,
		const float InBaseValue, const ECWBattleProperty InBattleProperty , const ECWBuffSouceType InSouceType = ECWBuffSouceType::None);

	/** 范围里生成随机数
	 * @param	float	范围下限
	 * @param	float	范围上限
	 * @return	float	随机数
	 */
	float RandomFloat(float Min, float Max);


	/** 计算是否产生暴击
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @return	bool	true:产生暴击，flase:不产生暴击
	 */
	bool IsGenerateCritical(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent
	);

	/** 
	 * @brief	获取棋子克制系数
	 * @return	float	克制系数
	 */
	float GetRefrainFactor(const ACWPawn* AttackPawn, const ACWPawn* BeDamagedPawn) const;


	/** 是否处于防御姿态
	 * @param	ACWPawn*	被伤害的Pawn
	 * @return	bool	true:处于防御姿态，false:没有处于防御姿态
	 */
	bool IsInDefincePosture(ACWPawn* BeDamagedPawn) const;


	/** 获得防御姿态系数
	 * @param	bool	是否处于防御姿态
	 * @return	float	防御姿态系数
	 */
	float GetDefincePostureFactor(bool IsInDP, const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent) const;


	/** 计算基础攻击力
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @return	float	施法者的基础攻击力
	 */
	float CalculateAttackBase(TSharedPtr<UCWCastSkillContext> CastSkillContext);


	/** 计算攻击力的装备加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	基础攻击力
	 * @return	float	攻击力的装备加成
	 */
	float CalculateAttackEquip(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase);


	/** 计算攻击力的暴击加成（里面根据暴击率，计算是否产生暴击）
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础攻击力
	 * @param	float	攻击力的装备加成
	 * @return	float	攻击力的暴击加成
	 */
	float CalculateAttackCritical(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float AttackBase, 
		float AttackEquip
	);


	/** 计算攻击力的被动技能加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	基础攻击力
	 * @param	float	攻击力的装备加成
	 * @return	float	攻击力的被动技能加成
	 */
	float CalculateAttackPassivitySkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip);


	/** 计算攻击力的Buff加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	基础攻击力
	 * @param	float	攻击力的装备加成
	 * @return	float	攻击力的Buff加成
	 */
	float CalculateAttackBuff(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip);
	float CalculateAttackBuffSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip);


	/** 计算攻击力的施法技能的加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	基础攻击力
	 * @param	float	攻击力的装备加成
	 * @return	float	攻击力的施法技能的加成
	 */
	float CalculateAttackCastSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float AttackBase, float AttackEquip);


	/** 计算攻击力的属性克制的加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础攻击力
	 * @param	float	攻击力的装备加成
	 * @param	float	攻击力的暴击加成
	 * @param	float	攻击力的被动技能加成
	 * @param	float	攻击力的Buff加成
	 * @param	float	攻击力的施法技能加成
	 * @return	float	攻击力的属性克制的加成
	 */
	float CalculateAttackArmBeat(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const ACWPawn* BeDamagedPawn,
		float AttackBase,
		float AttackEquip,
		float AttackCritical,
		float AttackPassivitySkill,
		float AttackBuffSkill,
		float AttackCastSkill
	);


	/**
	 * @brief	计算攻击力的天气加成
	 */
	float CalculateAttackWeather(TSharedPtr<UCWCastSkillContext> CastSkillContext);


	/**
	 * @brief	计算攻击力的地势差加成
	 */
	float CalculateAttackWavedLandform(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		float AttackBase,
		float AttackEquip,
		float AttackCritical,
		float AttackPassivitySkill,
		float AttackBuff,
		float AttackCastSkill);

	/**
	 * @brief	计算攻击力的地势差加成系数
	 */
	float GetAttackWavedLandformFactor(TSharedPtr<UCWCastSkillContext> CastSkillContext);

	/** 计算基础防御力
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @return	float	基础防御力
	 */
	float CalculateDefinceBase(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent
	);


	/** 计算防御力的装备加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础防御力
	 * @return	float	防御力的装备加成
	 */
	float CalculateDefinceEquip(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceBase
	);


	/** 计算防御力的防御姿态加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	ACWPawn*	被伤害的Pawn
	 * @param	float	基础防御力
	 * @param	float	防御力的装备加成
	 * @return  float	防御力的防御姿态加成
	 */
	float CalculateDefinceDefincePosture(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		ACWPawn* BeDamagedPawn,
		float DefinceBase,
		float DefinceEquip
	);
	

	/** 计算防御力的被动技能加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础防御力
	 * @param	float	防御力的装备加成
	 * @return  float	防御力的被动技能加成
	 */
	float CalculatDefincePassivitySkill(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceBase,
		float DefinceEquip
	);


	/** 计算防御力的Buff加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础防御力
	 * @param	float	防御力的装备加成
	 * @return  float	防御力的Buff加成
	 */
	float CalculateDefinceBuff(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceBase,
		float DefinceEquip
	);


	/** 计算防御力的地形加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	基础防御力
	 * @param	float	防御力的装备加成
	 * @param	float	防御力的防御姿态加成
	 * @return  float	防御力的被动技能加成
	 * @return  float	防御力的Buff加成
	 * @return  float	防御力的地形加成
	 */
	float CalculateDefinceTerrain(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceBase,
		float DefinceEquip,
		float DefinceDefincePosture,
		float DefincePassivitySkill,
		float DefinceBuff
	);


	/** 
	 * @brief	计算防御力天气加成
	 */
	float CalculateDefinceWeather(ACWPawn* BeDamagedPawn);


	/** 计算最终伤害
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	最终攻击力
	 * @param	float	最终防御力
	 * @return  int	最终伤害
	 */
	int CalculateRealFinalDamage(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		float FinalAttack, 
		float FinalDefince
	);


	/** 计算施法者技巧值(基础)
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @return	float	施法者技巧值(基础)
	 */
	float CalculateTalentBase(TSharedPtr<UCWCastSkillContext> CastSkillContext);


	/** 计算施法者暴击值的装备加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	施法者技巧值(基础)
	 * @return	float	施法者暴击值的装备加成
	 */
	float CalculateCriticalEquip(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase);


	/** 计算施法者暴击值的被动技能加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	施法者技巧值(基础)
	 * @param	float	施法者暴击值的装备加成
	 * @return	float	施法者暴击值的被动技能加成
	 */
	float CalculateCriticalPassivitySkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip);


	/** 计算施法者暴击值的Buff加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	施法者技巧值(基础)
	 * @param	float	施法者暴击值的装备加成
	 * @return	float	施法者暴击值的Buff加成
	 */
	float CalculateCriticalBuff(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip);
	

	/** 计算施法者暴击值的施法技能加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	施法者技巧值(基础)
	 * @param	float	施法者暴击值的装备加成
	 * @return	float	施法者暴击值的Buff加成
	 */
	float CalculateCriticalCastSkill(TSharedPtr<UCWCastSkillContext> CastSkillContext, float TalentBase, float CriticalEquip);


	/** 计算施法者暴击值的地形加成
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @param	float	施法者技巧值(基础)
	 * @param	float	施法者暴击值的装备加成
	 * @param	float	施法者暴击值的被动技能加成
	 * @param	float	施法者暴击值的Buff加成
	 * @param	float	施法者暴击值的施法技能加成
	 * @return	float	施法者暴击值的地形加成
	 */
	float CalculateCriticalTerrain(
		TSharedPtr<UCWCastSkillContext> CastSkillContext,
		float TalentBase, 
		float CriticalEquip, 
		float CriticalPassivitySkill, 
		float CriticalBuff, 
		float CriticalCastSkill
	);


	/** 计算被伤害者的防御技巧（基础）
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @return	float	被伤害者的防御技巧（基础）
	 */
	float CalculateDefinceTalentBase(const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent);


	/** 计算被伤害者的防御暴击值的装备加成
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	被伤害者的防御技巧（基础）
	 * @return	float	被伤害者的防御暴击值的装备加成
	 */
	float CalculateDefinceCriticalEquip(
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceTalentBase
	);


	/** 计算被伤害者的防御暴击值的被动技能加成
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	被伤害者的防御技巧（基础）
	 * @param	float	被伤害者的防御暴击值的装备加成
	 * @return  float	被伤害者的防御暴击值的被动技能加成
	 */
	float CalculateDefinceCriticalPassivitySkill(
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceTalentBase,
		float DefinceCriticalEquip
	);


	/** 计算被伤害者的防御暴击值的Buff加成
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	被伤害者的防御技巧（基础）
	 * @param	float	被伤害者的防御暴击值的装备加成
	 * @return  float	被伤害者的防御暴击值的Buff加成
	 */
	float CalculateDefinceCriticalBuff(
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceTalentBase,
		float DefinceCriticalEquip
	);


	/** 计算被伤害者的防御暴击值的地形加成
	 * @param	const UCWPawnBattlePropertyComponent*	被伤害的Pawn的属性组件
	 * @param	float	被伤害者的防御技巧（基础）
	 * @param	float	被伤害者的防御暴击值的装备加成
	 * @param	float	被伤害者的防御暴击值的被动技能加成
	 * @param	float	被伤害者的防御暴击值的Buff加成
	 * @return  float	被伤害者的防御暴击值的地形加成
	 */
	float CalculatDefinceeCriticalTerrain(
		const UCWPawnBattlePropertyComponent* BeDamagedPawnPropertyComponent,
		float DefinceTalentBase,
		float DefinceCriticalEquip,
		float DefinceCriticalPassivitySkill,
		float DefinceCriticalBuff
	);


	/** 计算最终暴击率
	 * @param	const UCWCastSkillContext*	施法时的上下文
	 * @param	float	最终进攻暴击值
	 * @param	float	最终防御暴击值
	 * @return  float	最终暴击率
	 */
	float CalculateFinalCritical(float FinalAttack, float FinalDefince);


	/** 计算施法者总的最终伤害系数(修正)
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @return  float	施法者总的最终伤害系数(修正)
	 */
	float CalculateFinalDamageFactorTotal(TSharedPtr<UCWCastSkillContext> CastSkillContext);


	/** 计算施法者总的最终伤害叠加（加成）
	 * @param	const FCWCastSkillContext&	施法时的上下文
	 * @return  float	施法者总的最终伤害叠加（加成）
	 */
	float CalculateFinalDamageTotal(TSharedPtr<UCWCastSkillContext> CastSkillContext);

protected:
	bool IsSameConditioin(const FCWBattlePropertyAffectorData& ParamAffectorData, TSharedPtr<UCWCastSkillContext> ParamCastSkillContext);

};
