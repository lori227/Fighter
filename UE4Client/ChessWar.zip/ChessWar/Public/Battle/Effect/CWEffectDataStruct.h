﻿
#pragma once

#include "Engine.h"
#include "CWEffectDataStruct.generated.h"


USTRUCT(BlueprintType)
struct FCWEffectDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWEffectDataStruct();
	virtual ~FCWEffectDataStruct();

	/** 绑定特效 */
	static void SpawnEmitterAttached(const int32 InEffectId, class USceneComponent* AttachToComponent, 
		TFunction<void(UParticleSystemComponent*, UParticleSystem*)> InCallable = nullptr);

public:
	/** 特效名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectName;

	/** 特效描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectDescForDoc;

	/** 特效资源名（Cfg: CWParticleAssetCfg） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectResId;

	/** 特效挂接类型 1：是挂接到角色身上的，0：不是挂接到角色身上 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	int32 EffectAttachType;

	/** 特效挂接的挂接点名 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectAttachName;

	/** 偏移 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectOffset;

	/** 朝向 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectRotator;

	/** 缩放 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	FString EffectScale;

	/** 特效延迟播放时间 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "EffectDataStruct")
	float DelayPlayTime;
};