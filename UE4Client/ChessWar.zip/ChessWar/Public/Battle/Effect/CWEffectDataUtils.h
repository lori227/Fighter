#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWEffectDataUtils
{
public:

	/** 从字符串解析出特效偏移
	 * @param	const FString&	字符串
	 * @return	std::vector<float>	特效偏移
	 */
	static std::vector<float>  GetArrayEffectOffsetFromString(const FString& ParamString);


	/** 从字符串解析出攻击特效朝向
	 * @param	const FString&	字符串
	 * @return	std::vector<float>	特效朝向
	 */
	static std::vector<float> GetArrayEffectRotatorFromString(const FString& ParamString);
};
