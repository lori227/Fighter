﻿
#pragma once

#include "CWBuff.h"
#include "CWEventMgr.h"
#include "CWElementSystemData.h"
#include "Components/ActorComponent.h"
#include "CWElementSystemCtrl.generated.h"

class ACWPawn;


/**
 * @Brief 元素系统控制器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWElementSystemCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWElementSystemCtrl();

	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual bool InitInServer(const int32 InObjElemId);
	virtual bool ResetInServer(const int32 InObjElemId);

public:
	/** 获取元素与元素反应 */
	virtual bool GetElemElemResult(const EObjElemType InElemType, FCWElemWithElemResultData& OutResultData);

	/** 执行元素与元素结果 */
	virtual bool ExecElemElemResult(const FCWElemWithElemResultData& InReactionResult, const ECWBuffSouceType InSouceType/* = ElemSys*/);

	/** 执行元素与性质反应 */
	virtual bool ExecElemNatureReaction(const EObjElemType InElemType, const ECWBuffSouceType InSouceType/* = ElemSys*/);

	/** 检测是否某个技能已经发生反应 */
	virtual bool CheckContextHasReaction(TSharedPtr<UCWCastSkillContext> InCasterContext);

	/** Print */
	virtual FString ToDebugString() const;

protected:
	/** 重置当前元素 */
	virtual bool ResetObjElemType(const EObjElemType InNewElemType);
	/** 添加新Buff */
	virtual bool AddBuffAndResetElemForOwner(const int32 InNewBuffId, const EObjElemType InNewElemType, const ECWBuffSouceType InSouceType);
	virtual bool AddBuffForOwner(const int32 InNewBuffId, const ECWBuffSouceType InSouceType);

	/** 获取棋子类型 */
	virtual ECWPawnType GetOwnerPawnType();

	/** 元素绑定Buff销毁回调 */
	UFUNCTION()
	virtual void OnElemRefBuffDestroyed(const int32 InBuffUniqueId, const int32 InBuffId, const EObjElemType InOwnElemType, const ECWBuffSouceType InSouceType);

protected:
	/** 获取元素与元素结果数据 */
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = Default)
	FCWElemWithElemResultData GetElemWithElemReactionResult(const EObjElemType InOriginalElem, const EObjElemType InCasterElem);

	/** 获取元素与物体性质结果数据 */
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = Default)
	FCWElemWithObjNatureResultData GetElemWithObjNatureReactionResult(const EObjElemType InCasterElem, const EObjNatureType InObjNatureType, const ECWPawnType InObjType);

public:
	UPROPERTY(BlueprintAssignable, Category = "Event")
	FOnObjElemTypeEvent OnObjElemTypeEvent;

protected:
	/** Owner */
	mutable ACWPawn* OwnerPawn;

	/** 物体元素Id */
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	int32 ObjElemId;

	/** 物体性质(可燃烧/可潮湿/可冰冻/可导电/可感染) */
	// EObjNatureType
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	uint8 ObjNatureTypes;

	/** 物体拥有元素 */
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	EObjElemType ObjElemType;

	/** Buff信息 */
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	int32 ObjElemRefBuffId;
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	int32 ObjElemRefBuffUniqueId;

	//~ 施法者相关
	int32 NetPawnUniqueIdx;
	int32 NetPawnSkillId;
	int32 RemainDamageCnt;

};
