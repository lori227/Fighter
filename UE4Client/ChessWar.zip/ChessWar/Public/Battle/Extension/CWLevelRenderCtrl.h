﻿
#pragma once

#include "Components/ActorComponent.h"
#include "CWLevelRenderCtrl.generated.h"

class ACWPawn;

/**
 * @Brief 地图渲染特效控制器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWLevelRenderCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWLevelRenderCtrl();

	virtual void BeginDestroy() override;

protected:
	/** Owner */
	mutable ACWPawn* OwnerPawn;

};
