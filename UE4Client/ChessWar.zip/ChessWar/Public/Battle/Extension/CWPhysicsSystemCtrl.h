﻿
#pragma once

#include "CWPhysicsSystemData.h"
#include "Components/ActorComponent.h"
#include "CWPhysicsSystemCtrl.generated.h"

class ACWPawn;


/**
 * @Brief 物理系统控制器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWPhysicsSystemCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWPhysicsSystemCtrl();

	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual bool InitInServer(const FCWPhysicsSysData& InPhysicsSysData);

public:
	/** 执行水平交互 */
	virtual bool ExecHorizontalForce(const ACWPawn* InCaster = nullptr);

	/** 执行垂直交互 */
	virtual bool ExecVerticalForce(const ACWPawn* InCaster = nullptr);

	/** 是否允许接受交互 */
	virtual bool IsAllowReceiveForce();
	virtual bool IsAllowReceiveHorizontalForce();
	virtual bool IsAllowReceiveVerticalForce();

	/** Print */
	virtual FString ToDebugString() const;

	/** Test */
	static void TestHorizontalForced2Move(const AActor* InWorldContext, const int32 InCasterNetIdx, const int32 InReceiverNetIdx, const int32 InMoveNum);

	// 获取目标格子附近最佳点
	static int32 GetTargetNearOptimumTile(const UObject* InWorldContext, const int32 InTargetTile, const int32 InParamTile);

protected:
	// 执行事件
	virtual void ExecEventForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce);
	// 执行Buff
	virtual void ExecBuffForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce);
	// 执行伤害
	virtual void ExecHurtForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce);
	// 执行强制位移
	virtual void ExecForced2MoveForPawn(const ACWPawn* InCaster, ACWPawn* InReceiver, const bool bHorizontalForce);

private:
	// 执行水平强制位移
	virtual void ExecHorizontalForced2Move(const ACWPawn* InCaster, ACWPawn* InReceiver, const int32 InMoveNum);
	// 执行垂直强制位移
	virtual void ExecVerticalForced2Move(const ACWPawn* InCaster, ACWPawn* InReceiver, const int32 InMoveNum);

protected:
	/** Owner */
	mutable ACWPawn* OwnerPawn;

	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	FCWPhysicsSysData PhysicsSysData;

};
