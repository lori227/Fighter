﻿
#pragma once

#include "CWRandomEvtData.h"
#include "Components/ActorComponent.h"
#include "CWRandomEventCtrl.generated.h"

class ACWPawn;
class ACWDungeonItem;
class ACWRandomDungeonGenerator;


/**
 * @Brief 游戏随机事件控制器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWRandomEventCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWRandomEventCtrl();

	virtual void BeginDestroy() override;
	virtual bool InitInServer();

public:
	// 获取伤害范围格子编号
	static TArray<int32> GetDamageRangeArray(ACWRandomDungeonGenerator* Generator, 
		const FCWRandomEvtGameData& InEvtData, const bool bCheckTargetTileValid = true);

	// 测试生成物件
	virtual void TestCreateDungeonItem(const int32 InTile, const int32 InItemId);
	// 测试生成事件
	virtual void TestCreateDungeonEvt(const int32 InTile, const int32 InEvtId);

protected:
	UFUNCTION()
	virtual void OnRoundChangeInServer(int32 InCurRoundIdx, int32 InMaxRoundIdx);

	// 检测事件(冷却/执行/生成)
	virtual void ExecInitEvtArray();
	virtual void ExecEventArrayReset(const bool bFirstRound = false);

	// 获取随机目标格子
	virtual int32 GetNeedWarnTargetTile(const FCWRandomEvtGameData& InRandomEvtData);
	virtual int32 GetCommTargetTile(const FCWRandomEvtGameData& InRandomEvtData);

	// 触发条件检测
	virtual bool IsConditionOk(const FCWRandomEvtGameData& InRandomEvtData);

	// 触发警告/执行随机事件
	virtual void ToggleEventWarn(const FCWRandomEvtGameData InRandomEvtData, bool bNewVisible);
	virtual bool ExecuteRandomEvt(FCWRandomEvtGameData& InRandomEvtData);

	// 触发伤害范围(陨石/黑洞/惊雷)
	virtual void OnToggleMeteoriteDamage(const FCWRandomEvtGameData& InRandomEvtData);
	virtual void OnToggleDarkHoleDamage(const FCWRandomEvtGameData& InRandomEvtData);
	virtual void OnToggleThunderDamage(const FCWRandomEvtGameData& InRandomEvtData);

	// 作用随机事件
	virtual void AddRandEvtToPawn(ACWPawn* InPawn, const FCWRandomEvtGameData& InRandomEvtData);

	// 创建随机物件子对象
	virtual bool CreateDungeonItem(const FCWRandomEvtGameData& InRandomEvtData);
	virtual bool CreateEvtEffectActor(const FCWRandomEvtGameData& InRandomEvtData, TFunction<void(int32)>&& Callback);

	// NetMulticast
	UFUNCTION(NetMulticast, Reliable)
	virtual void NetMulticastToggleRandEvtWarn(bool bNewVisible, const FCWRandomEvtGameData InRandomEvtData);
	virtual void OnToggleRandEvtWarnInClient(bool bNewVisible, const FCWRandomEvtGameData InRandomEvtData);

	// 地块销毁回调
	UFUNCTION()
	virtual void OnActorDestroyedImpl(AActor* InActor);

protected:
	// 只初始化一次(场景物件 BUFF)
	TArray<FCWRandomEvtGameData> InitEvtArray;

	TArray<FCWRandomEvtGameData> ActiveEvtArray;
	TArray<FCWRandomEvtGameData> InactiveEvtArray;

private:
	TWeakObjectPtr<ACWRandomDungeonGenerator> DungeonGeneratorRef;

};
