﻿
#pragma once

#include "CWStatisticsSystemData.h"
#include "Components/ActorComponent.h"
#include "CWStatisticsSystemCtrl.generated.h"

class ACWPawn;

/**
 * @Brief 统计系统控制器(统计棋子数据)
 */
UCLASS(BlueprintType, Blueprintable)
class UCWStatisticsSystemCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWStatisticsSystemCtrl();

	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual bool InitInServer();

public:
	virtual void SetStatisticsData(ECWStatisticsType InType, int32 InParamValue);
	virtual void AddStatisticsData(ECWStatisticsType InType, int32 InAddValue);
	virtual int32 GetStatisticsData(ECWStatisticsType InType);

	/** 获取统计数据 */
	virtual const TMap<ECWStatisticsType, int32>& GetMapStatisticsData();

	/** Print */
	virtual FString ToDebugString() const;
	static FString ToString(ECWStatisticsType InStatisticsType);

protected:
	/** Owner */
	mutable ACWPawn* OwnerPawn;

	/** 统计数据表 */
	UPROPERTY(VisibleAnywhere, Replicated, Category = Default)
	TMap<ECWStatisticsType, int32> MapStatisticsData;

};
