﻿
#pragma once

#include "CWTalentSystemData.h"
#include "Components/ActorComponent.h"
#include "CWTalentSystemCtrl.generated.h"

class ACWPawn;

/**
 * @Brief 天赋系统控制器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWTalentSystemCtrl : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWTalentSystemCtrl();

	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual bool InitInServer(const int32 InObjTalentId);

public:
	/** 获取天赋组Id */
	const TArray<int32>& GetArrayTalentIds();

	/** Print */
	virtual FString ToDebugString() const;

protected:
	/** Owner */
	mutable ACWPawn* OwnerPawn;

	/** 天赋数组Id */
	UPROPERTY(VisibleAnywhere, Transient, Replicated, Category = Default)
	TArray<int32> ArrayTalentIds;

};
