﻿
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "MovementActorComp.generated.h"


/**
 * @Brief 简单移动对象组件
 */
UCLASS()
class UMovementActorComp : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UMovementActorComp();

	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual void SimpleMoveToTarget(const FVector& InTargetPoint);
	virtual void StopSimpleMoveToTarget();

protected:
	UFUNCTION()
	virtual void OnRep_TargetPoint();

	virtual void SimpleMoveToTargetImpl();

	virtual bool OnTick(float DeltaTime);

protected:
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_TargetPoint)
	FVector TargetPoint;

	/** Handle for OnTick. */
	FDelegateHandle TickDelegateHandle;

};
