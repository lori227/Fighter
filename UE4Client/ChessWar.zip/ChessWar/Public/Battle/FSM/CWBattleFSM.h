#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWFSM.h"
#include "CWBattleFSM.generated.h"

class ACWGameMode;


/**
 * @brief 战斗有限状态机 \n
 *
 */
UCLASS()
class UCWBattleFSM : public UCWFSM
{
	GENERATED_UCLASS_BODY()
public:

	void Init(ACWGameMode* ParamGameMode);

	ACWGameMode* GetGameMode();

	virtual void BeginDestroy() override;

protected:

	UPROPERTY()
	ACWGameMode* GameMode;
};