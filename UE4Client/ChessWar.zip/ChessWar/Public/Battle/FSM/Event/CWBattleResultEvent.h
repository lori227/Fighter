#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "FSM/CWFSMEvent.h"
//#include "CWFSMEvent.generated.h"

class FCWBattleResultEvent : public FCWFSMEvent
{
public:
	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWBattleResultEvent();


	/** 构造函数
	 * @param	int	事件Id
	 * @param	int	目标状态Id
	 * @param	EFSMStackOperation	栈操作
	 * @param   ECWCampTag 赢的阵营
	 * @return	无
	 */
	FCWBattleResultEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp, ECWCampTag ParamCampTag);

public:

	ECWCampTag WinCampTag;
};