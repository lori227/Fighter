#pragma once

#include "CWBattleStateBase.h"


/**
 * @brief 战斗有限状态机里的地图状态 \n
 *
 */
class FCWBattleGungeonState : public FCWBattleStateBase
{
public:

	/** 构造函数
	 * @param	UCWFSM*	状态机
	 * @param	int	状态Id
	 * @return	无
	 */
	FCWBattleGungeonState(UCWFSM* ParamParent, int ParamStateId);


	/** 是否这个事件能发生状态转移
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual bool CanTranstion(const FCWFSMEvent* Params) override;


	/** 进入状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnEnter(const FCWFSMEvent* Params) override;


	/** 退出状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnExit(const FCWFSMEvent* Params) override;


	/** 处理事件
	 * @param	const FCWFSMEvent&	事件
	 * @return	无
	 */
	virtual void DoEvent(const FCWFSMEvent* Params) override;


	/** 帧处理
	 * @param	float	帧间隔
	 * @return	无
	 */
	virtual void Tick(float DeltaTime);


private:

};