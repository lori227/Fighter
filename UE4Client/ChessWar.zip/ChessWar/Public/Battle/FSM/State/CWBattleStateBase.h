﻿
#pragma once

#include "CWFSMState.h"

class ACWGameMode;
class ACWGameState;

/**
 * @brief 战斗有限状态机基类 \n
 */
class FCWBattleStateBase : public FCWFSMState
{
private:
	typedef FCWFSMState Super;

public:
	FCWBattleStateBase(UCWFSM* ParamParent, int ParamStateId);

public:
	template< class T = ACWGameMode >
	T* GetGameMode() const
	{
		UCWBattleFSM* BattleFSM = Cast<UCWBattleFSM>(Parent);
		if (nullptr != BattleFSM)
		{
			return BattleFSM->GetGameMode();
		}
		return nullptr;
	}

	template< class T = ACWGameState >
	T* GetGameState() const
	{
		ACWGameMode* GameMode = GetGameMode();
		if (nullptr != GameMode)
		{
			return GameMode->GetGameState<T>();
		}
		return nullptr;
	}

};