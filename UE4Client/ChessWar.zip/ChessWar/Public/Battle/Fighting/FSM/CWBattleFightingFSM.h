#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWFSM.h"
#include "CWBattleFightingFSM.generated.h"

class UCWBattleFSM;
class ACWGameMode;


/**
 * @brief 战斗有限状态机 \n
 *
 */
UCLASS()
class UCWBattleFightingFSM : public UCWFSM
{
	GENERATED_UCLASS_BODY()
public:

	void Init(ACWGameMode* ParamGameMode);

	ACWGameMode* GetGameMode();

protected:

	UPROPERTY()
	ACWGameMode* GameMode;
};