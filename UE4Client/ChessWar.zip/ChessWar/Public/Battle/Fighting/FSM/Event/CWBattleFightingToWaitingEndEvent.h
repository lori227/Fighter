#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "FSM/CWFSMEvent.h"
//#include "CWFSMEvent.generated.h"

class FCWBattleFightingToWaitingEndEvent : public FCWFSMEvent
{
public:
	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWBattleFightingToWaitingEndEvent();


	/** 构造函数
	 * @param	int	事件Id
	 * @param	int	目标状态Id
	 * @param	EFSMStackOperation	栈操作
	 * @return	无
	 */
	FCWBattleFightingToWaitingEndEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp);
};