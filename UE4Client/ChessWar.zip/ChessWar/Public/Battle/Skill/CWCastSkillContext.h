
#pragma once

#include <vector>
#include "Engine.h"
#include "CoreMinimal.h"
#include "UnrealNetwork.h"

#include "CWGameDefine.h"
#include "CWElementSystemData.h"
#include "CWBattlePropertySet.h"
#include "CWStatisticsSystemData.h"
#include "CWBattlePropertyAffectorData.h"
//#include "CWCastSkillContext.generated.h"

class ACWPawn;
class UCWBattlePropertySetRef;
struct FCWSkillDataStruct;
class UCWBattlePropertyAffectorDataRef;
class ACWPlayerController;

/**
 * @brief 施法时的上下文 \n
 * 有个潜规则：ACWPawn及继承ACWPawn的类，才能释放技能。 \n
 * 注意：普通攻击也算技能，所以此上下文也适合普通攻击
 */
//UCLASS()
class UCWCastSkillContext //: public UObject
{
	//GENERATED_UCLASS_BODY()

public:

	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	UCWCastSkillContext();


	/** 析构函数
	 * @param	无
	 * @return	无
	 */
	~UCWCastSkillContext();


	/** 拷贝构造函数
	 * @param	const UCWCastSkillContext&	另一个施法时的上下文
	 * @return	无
	 */
	UCWCastSkillContext(const UCWCastSkillContext& r);


	/** 赋值函数
	 * @param	const UCWCastSkillContext&	另一个施法时的上下文
	 * @return	UCWCastSkillContext&		返回自己的引用
	 */
	UCWCastSkillContext& operator = (const UCWCastSkillContext& r);

public:

	void CopyArrayAffectorData(const TArray<FCWBattlePropertyAffectorData>& ParamArrayAffectorData);
	void CopyMapStatisticsData(const TMap<enum ECWStatisticsType, int32>& InStatisticsData);


	/** 重新计算当前的理论值集合（最大）
	 * @param	无
	 * @return	bool	true:重新计算， false:没有重新计算
	 */
	bool RecalculateCurMaxTheoreticalPropertySet();

	/** 获取统计数据值 */
	int32 GetStatisticsDataValue(ECWStatisticsType InType, const int32 InDefaultValue = 0) const;

protected:
	bool RecalculateCurMaxTheoreticalPropertyHelp(ECWBattleProperty ParamBattleProperty);

public:
	/**< 施法者弱引用指针 */
	TWeakObjectPtr<ACWPawn> PawnWeakPtr;

	/**< 被伤害者(接收伤害对象) */
	TWeakObjectPtr<ACWPawn> BeDamagedPawnPtr;

	/**< 施法者阵营 */
	ECWCampTag PawnCampTag;

	/**< 施法者阵营控制器下标 */
	ECWCampControllerIndex PawnCampControllerIndex;

	/**< 施法者棋子下标 */
	int32 PawnControllerPawnIndex;

	/**< 是否反击 */
	bool bIsCounterAttack;

	/**< 施法者的位置 */
	FVector PawnPos;

	/**< 施法者的朝向 */
	FRotator PawnRotator;

	/**< 伤害范围的格子 */
	TArray<int32> ArrayDamageTile;

	/**< 施法者的控制器指针 */
	TWeakObjectPtr<ACWPlayerController> PlayerControllerWeakPtr;

	/**< 飞行器目标 */
	TWeakObjectPtr<ACWPawn> ProjectileTargetPawnWeakPtr;

	/**< 施法者施法瞬间的战斗相关基础属性(施法技能) */
	//UPROPERTY(Transient)
	FCWBattlePropertySet CastSkillPropertySet;

	/**< 施法者施法相关数据 */
	const FCWSkillDataStruct* CastSkillDataStruct;

	/**< 战斗相关基础属性(基础) */
	//UPROPERTY(Transient)
	FCWBattlePropertySet PawnPropertySetBase;

	/**< 当前战斗相关属性的理论值 */
	//UPROPERTY(Transient)
	FCWBattlePropertySet PawnCurMaxTheoreticalPropertySet;

	/**< 当前战斗相关属性 */
	//UPROPERTY(Transient)
	FCWBattlePropertySet PawnCurPropertySet;

	/**< 影响器数据的容器 */
	TArray<FCWBattlePropertyAffectorData> PawnArrayPropertyAffectorData;

	/**< 统计数据容器 */
	TMap<enum ECWStatisticsType, int32> PawnMapStatisticsData;

};
