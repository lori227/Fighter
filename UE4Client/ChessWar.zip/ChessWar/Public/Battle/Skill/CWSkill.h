﻿#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "Global/CWGameDefine.h"
#include <vector>
#include "CWSkill.generated.h"

struct FCWSkillDataStruct;
class ACWPawn;
class UCWSkillManager;
class UCWCastSkillContext;

/**
 * @brief 技能 \n
 * 注意：普通攻击也算技能
 */
UCLASS()
class UCWSkill : public UObject
{
	GENERATED_UCLASS_BODY()
public:

	/** 通过技能Id 初始化技能
	 * @param	UCWSkillManager* 此技能的所属的技能管理器
	 * @param	int 技能Id
	 * @param	int 技能下标
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool Init(UCWSkillManager* ParamParantSkillManager, int ParamSkillId, int ParamSkillIndex);


	/** 销毁
	 * @param	无
	 * @return	无
	 */
	void DestoryAll();


	/** 每回合重置数据
	 * @param	无
	 * @return	bool true:重置成功，false:重置失败
	 */
	bool ResetForRound();


	/** 是否有足够的能量
	 * @param	无
	 * @return	bool true:有足够能量，false:没有足够能量
	 */
	bool IsEnoughEnergy() const;


	/** 对棋子释放技能（关卡里的物件也是棋子）
	 * @param	ACWPawn* 棋子
	 * @return	bool true:释放技能成功, false:释放技能失败
	 */
	bool CastSkillToPawn(ACWPawn* ParamTargetPawn);


	/** 对地图格子释放技能
	 * @param	int 地图格子下标
	 * @return	bool true:释放技能成功, false:释放技能失败
	 */
	bool CastSkillToTile(int ParamTile);


	/** 对地图格子反击
	 * @param	int 地图格子下标
	 * @return	bool true:反击成功, false:反击失败
	 */
	bool CounterAttackToTile(int ParamTile);


	/** 此技能是否普通攻击
	 * @param	无
	 * @return	bool true:是普通攻击, false:不是普通攻击
	 */
	bool IsNormalAttack() const;


	/** 此技能是否有动作序列
	 * @param	无
	 * @return	bool true:是否有动作序列, false:不是有动作序列
	 */
	bool IsThereAnimSequence();


	/** 此技能产生飞行器
	 * @param	ACWPawn* 目标棋子
	 * @param	TSharedPtr<UCWCastSkillContext> 释放技能上下文
	 * @return	bool true:成功, false:失败
	 */
	bool GenerateProjectileToPawn(ACWPawn* ParamTargetPawn, TSharedPtr<UCWCastSkillContext> ParamCastSkillContextPtr);


	/** 获得是否被动技能
	 * @param	无
	 * @return	bool true:是被动技能, false:不是被动技能
	 */
	bool IsPassivitySkill() const;


	/** 递增此技能的每回合触发Buff的次数
	 * @param	无
	 * @return	无
	 */
	void IncreaseTriggerBuffCountForRound();


	/** 获得此技能的每回合触发Buff的次数
	 * @param	无
	 * @return	int32  此技能的每回合触发Buff的次数
	 */
	int32 GetTriggerBuffCountForRound() const;


	/** 获得技能数据
	 * @param	无
	 * @return	const FCWSkillDataStruct* 技能数据
	 */
	const FCWSkillDataStruct* GetSkillDataStruct() const;


	/** 获得技能动画
	 * @param	无
	 * @return	const UAnimSequence* 技能动画
	 */
	UAnimSequence* GetSkillAnim();
	ECWPawnAnim GetSkillAnimType();


	/** 获得技能Id
	 * @param	无
	 * @return	int32 技能Id
	 */
	int32 GetSkillId() const;


	/** 获得技能下标
	 * @param	无
	 * @return	int32 技能下标
	 */
	int32 GetSkillIndex() const;

	/** 技能来源 */
	ECWSkillSouceType GetSouceType();
	void SetSouceType(ECWSkillSouceType InSkillSource);

private:


	/** 加载技能动画
	 * @param	无
	 * @return	bool true:加载技能动画成功, false:加载技能动画失败
	 */
	bool LoadSkillAnim();


	/** 挂攻击特效，并播放
	 * @param	无
	 * @return	无
	 */
	void SetupAttackEffectInClient();

protected:
	/** 技能来源 */
	ECWSkillSouceType SourceType;

	/** 此技能的技能Id */
	int32 SkillId;

	/** 此技能的技能下标 */
	int32 SkillIndex;

	/** 此技能的动画 */
	UPROPERTY()
	UAnimSequence* SkillAnim;
	ECWPawnAnim SkillAnimType;

	/** 此技能的技能数据(读配置表) */
	//FCWSkillDataStruct* SkillData;

	/** 此技能的所属的技能管理器 */
	UPROPERTY()
	UCWSkillManager* ParentSkillManager;

	/** 此技能的每回合触发Buff的次数 */
	int32 TriggerBuffCountForRound;
	
};