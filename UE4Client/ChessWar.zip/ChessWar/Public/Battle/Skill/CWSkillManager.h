#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "Global/CWGameDefine.h"
#include "CWSkillManager.generated.h"

class UCWSkill;
class ACWPawn;

/**
 * @brief 技能管理器 \n
 * 注意：普通攻击也算技能
 */
UCLASS()
class UCWSkillManager : public UObject
{
	GENERATED_UCLASS_BODY()
public:
	//virtual ~UCWSkillManager();
public:

	/** 通过棋子Id 初始化技能管理器
	 * @param	ACWPawn* 此技能管理器的拥有者
	 * @return	bool true:初始化成功，false:初始化失败
	 */
	bool Init(ACWPawn* ParamParentPawn);


	/** 销毁
	 * @param	无
	 * @return	无
	 */
	void DestoryAll();


	/** 每回合重置数据
	 * @param	无
	 * @return	bool true:重置成功，false:重置失败
	 */
	bool ResetForRound();


	/** 是否能释放某技能
	 * @param	int 技能Id
	 * @return	bool true:能释放某技能，false:不能释放某技能
	 */
	bool CanCastSkill(int ParamSkillId) const;


	/** 是否能释放某技能
	 * @param	int 技能下标
	  * @return	bool true:能释放某技能，false:不能释放某技能
	 */
	bool CanCastSkillByIndex(int ParamSkillIndex) const;


	/** 是否普通攻击
	 * @param	无
	 * @return	bool true:能普通攻击，false:不能普通攻击
	 */
	bool CanNormalAttack() const;


	/** 是否有足够的能量
	 * @param	int 技能Id
	 * @return	bool true:有足够能量，false:没有足够能量
	 */
	bool IsEnoughEnergy(int ParamSkillId) const;


	/** 是否有足够的能量
	 * @param	int 技能下标
	 * @return	bool true:有足够能量，false:没有足够能量
	 */
	bool IsEnoughEnergyByIndex(int ParamSkillIndex) const;


	/** 普通攻击
	 * @param	ACWPawn* 目标棋子
	 * @return	bool true:普通攻击成功, false:普通攻击失败
	 */
	bool NormalAttackToPawn(ACWPawn* ParamTargetPawn);


	/** 普通攻击
	 * @param	int32 目标格子
	 * @return	bool true:普通攻击成功, false:普通攻击失败
	 */
	bool NormalAttackToTile(int32 ParamTile);


	/** 反击
	 * @param	int32 目标格子
	 * @return	bool true:反击成功, false:反击失败
	 */
	bool CounterAttackToTile(int32 ParamTile);


	/** 对棋子释放技能（关卡里的物件也是棋子）
	 * @param	int32 技能Id
	 * @param	ACWPawn* 目标棋子
	 * @return	bool true:释放技能成功, false:释放技能失败
	 */
	bool CastSkillToPawn(int32 ParamSkillId, ACWPawn* ParamTargetPawn);


	/** 对地图格子释放技能
	 * @param	int32 技能Id
	 * @param	int 目标地图格子下标
	 * @return	bool true:释放技能成功, false:释放技能失败
	 */
	bool CastSkillToTile(int32 ParamSkillId, int ParamTile);


	/** 获得棋子
	 * @param	无
	 * @return	ACWPawn* 棋子
	 */
	ACWPawn* GetParentPawn();
	

	/** 获得棋子
	 * @param	无
	 * @return	const ACWPawn* 棋子
	 */
	const ACWPawn* GetParentPawn() const;


	/** 获得普通攻击
	 * @param	无
	 * @return	const UCWSkill* 普通攻击
	 */
	const UCWSkill* GetNormalAttack() const;


	/** 获得普通攻击
	 * @param	无
	 * @return	UCWSkill* 普通攻击
	 */
	UCWSkill* GetNormalAttack();


	/** 获得反击
	 * @param	无
	 * @return	UCWSkill* 反击
	 */
	UCWSkill* GetCounterAttack();


	/** 获得技能
	 * @param	int 技能Id
	 * @return	const UCWSkill* 技能
	 */
	const UCWSkill* GetSkill(int ParamSkillId) const;


	/** 获得技能
	 * @param	int 技能Id
	 * @return	UCWSkill* 技能
	 */
	UCWSkill* GetSkill(int ParamSkillId);


	/** 获得技能
	 * @param	int 技能下标
	 * @return	const UCWSkill* 技能
	 */
	const UCWSkill* GetSkillByIndex(int ParamSkillIndex) const;


	/** 获得技能
	 * @param	int 技能下标
	 * @return	UCWSkill* 技能
	 */
	UCWSkill* GetSkillByIndex(int ParamSkillIndex);

protected:

	/** 所有技能 */
	UPROPERTY()
	TArray<UCWSkill*> ArraySkills;

	/** 天赋技能 */
	UPROPERTY(Transient)
	TArray<UCWSkill*> ArrayTalentSkill;

	/** 普通攻击 */
	UPROPERTY()
	UCWSkill* NormalAttackBySkill;

	/** 此技能管理器的拥有者 */
	UPROPERTY()
	ACWPawn* ParentPawn;

};
