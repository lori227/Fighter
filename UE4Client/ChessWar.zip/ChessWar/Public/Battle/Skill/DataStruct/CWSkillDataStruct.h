
#pragma once

#include "Engine.h"
#include "CWElementSystemData.h"
#include "CWSkillDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWSkillDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWSkillDataStruct();
	virtual ~FCWSkillDataStruct();

public:

	/** 技能Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 SkillId;

	/** 技能名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString SkillName;

	/** 技能描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString SkillDescForDoc;

	/** 是否普通攻击 1:普通攻击, 0:技能 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 IsNormalAttack;

	/** 是否产生飞行器 1:产生飞行器, 0:不产生飞行器 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 IsGenerateProjectile;

	/** 是否被动技能 1:被动技能, 0:不是被动技能（主动技能） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 IsPassivitySkill;

	/** 目标类型 0x01：敌方, 0x02:同伴方，0x04:自己  0x08：地图格子， 0x10：地图物件（场景物件） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 TargetType;

	/** 释放此技能消耗的能量值 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 ConsumeEnergy;

	/** 是否有动作 1：有动作, 0:没动作 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 IsHasAnim;

	/** 此技能动画路径Id(Cfg: CWPawnAssetCfg) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AnimNameId;

#pragma region		/** 元素系统数据 */

	/** 携带元素类型 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	EObjElemType OwnElemType;

#pragma endregion

#pragma region		/** 物理系统数据 */

	/** 是否产生横向力 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	uint8 bAddLateralForce : 1;

#pragma endregion

	//-----------------------------------------------
	/** 攻击范围是否按自身范围步长来计算 1:按照自身范围步长来计算   ECWAttackRangeType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 AttackRangeType;

	/** 攻击范围参数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AttackRangeParams;

	/** 攻击范围行数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 AttackRangeRowNum;

	/** 攻击范围列数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 AttackRangeColumnNum;

	/** 攻击范围 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AttackRange;
	//-----------------------------------------------
	/** 飞行器路径名 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ProjectileName;

	/** 飞行器偏移向量 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ProjectileOffset;

	/** 飞行器初始速度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	float ProjectileInitialSpeed;
	//-----------------------------------------------
	/** 是否AOE(是否范围伤害效果)  1:是AOE, 0:不是AOE */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 IsAOE;

	/** 最大作用目标数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 TargetMax;

	/** 自动选中优先级 数值越大，优先级越高 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 AutoSelectedPriority;
	//-----------------------------------------------
	//因为技能产生伤害是最基本的功能，还是单独提出来，不放到影响器里去实现
	/** 伤害次数（二连斩，三连斩） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 DamageCount;

	/** 伤害百分比（这是个数组,  具体的伤害时间点，编辑在技能动作里OnAnimDamage） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	float DamageFactor;
	//-----------------------------------------------
	/** 攻击特效Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayAttackEffectId;
	//-----------------------------------------------
	/** 受击特效Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayBeAttackedEffectId;
	//-----------------------------------------------
	/** 强化后的攻击特效Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayIntensifyAttackEffectId;
	//-----------------------------------------------
	/** 强化后的受击特效Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayIntensifyBeAttackedEffectId;
	//-----------------------------------------------
	/** 影响范围(其实是文档里的伤害范围) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectRangeRight;

	/** 影响中心点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectCenterRight;

	/** 影响范围(其实是文档里的伤害范围) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectRangeDown;

	/** 影响中心点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectCenterDown;

	/** 影响范围(其实是文档里的伤害范围) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectRangeLeft;

	/** 影响中心点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectCenterLeft;

	/** 影响范围(其实是文档里的伤害范围) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectRangeUp;

	/** 影响中心点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString AffectCenterUp;
	//-----------------------------------------------
	/** 生成Buff数量 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	int32 BuffNum;

	/** Buff触发条件类型枚举值数组的数组 ECWTriggerConditionType */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerConditionType;

	/** Buff触发条件枚举值逻辑操作数组的数组 (触发条件之间是逻辑与还是逻辑或) ECWTriggerConditionTypeLogicOp */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerConditionLogicOp;

	/** Buff触发条件具体枚举值数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerConcretenessCondition;

	/** Buff触发条件具体枚举值的类型值与参数的比较关系的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerCompareRelatioinOp;

	/** Buff触发条件具体枚举值与参数类型的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerCompareRelatioinOpValueType;

	/** Buff触发条件具体相关参数数组的数组的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayArrayBuffTriggerConcretenessParams;
	//-----------------------------------------------
	/** BuffId数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "SkillDataStruct")
	FString ArrayBuffId;
	//-----------------------------------------------
};