#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWSkillDataUtils
{
public:

	/** 从字符串解析出技能Id数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	技能Id数组
	 */
	static std::vector<int32> GetArraySkillIdFromString(const FString& ParamString);


	/** 从字符串解析出攻击范围参数数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	攻击范围参数数组
	 */
	static std::vector<int32> GetArrayAttackRangeParamsFromString(const FString& ParamString);


	/** 从字符串解析出飞行器偏移向量数组
	 * @param	const FString&	字符串
	 * @return  std::vector<float>	飞行器偏移向量数组
	 */
	static std::vector<float> GetProjectileOffsetFromString(const FString& ParamString);


	/** 从字符串解析出影响范围数组
	 * @param	const FString&	字符串
	 * @return  std::vector<float>	影响范围数组
	 */
	static std::vector<std::vector<int32> > GetAffectRangeFromString(const FString& ParamString);


	/** 从字符串解析出影响范围中心坐标数组
	 * @param	const FString&	字符串
	 * @return  std::vector<float>	影响范围中心坐标数组
	 */
	static std::vector<int32> GetAffectCenterFromString(const FString& ParamString);


	/** 从字符串解析出技能触发Buff的条件类型
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	技能触发Buff的条件类型
	 */
	static std::vector<std::vector<int32> > GetArrayArrayBuffTriggerConditionType(const FString& ParamString);


	/** 从字符串解析出技能触发Buff的逻辑操作
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	技能触发Buff的逻辑操作
	 */
	static std::vector<std::vector<int32> > GetArrayArrayBuffTriggerConditionLogicOp(const FString& ParamString);


	/** 从字符串解析出技能触发Buff具体枚举值
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	技能触发Buff具体枚举值
	 */
	static std::vector<std::vector<int32> > GetArrayArrayBuffTriggerConcretenessCondition(const FString& ParamString);


	/** 从字符串解析出技能触发Buff具体枚举值的类型值与参数的比较关系
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	技能触发Buff具体枚举值的类型值与参数的比较关系
	 */
	static std::vector<std::vector<int32> > GetArrayArrayBuffTriggerCompareRelatioinOp(const FString& ParamString);


	/** 从字符串解析出技能触发Buff具体枚举值的类型值与参数的比较关系的参数类型
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	技能触发Buff具体枚举值的类型值与参数的比较关系的参数类型
	 */
	static std::vector<std::vector<int32> > GetArrayArrayBuffTriggerCompareRelatioinOpValueType(const FString& ParamString);


	/** 从字符串解析出技能触发Buff具体枚举值相关参数
	 * @param   const FString&	字符串
	 * @return  std::vector<std::vector<float> >	技能触发Buff具体枚举值相关参数
	 */
	static std::vector<std::vector<float> > GetArrayArrayBuffTriggerConcretenessParams(const FString& ParamString);


	/** 从字符串解析出BuffId数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	BuffId数组
	 */
	static std::vector<int32> GetArrayBuffIdFromString(const FString& ParamString);


	/** 从字符串解析出受击特效数组
	 * @param	const FString&	字符串
	 * @return	std::vector<FString>	受击特效数组
	 */
	static std::vector<int32> GetArrayAttackEffectIdFromString(const FString& ParamString);


	/** 从字符串解析出受击特效数组
	 * @param	const FString&	字符串
	 * @return	std::vector<FString>	受击特效数组
	 */
	static std::vector<int32> GetArrayBeAttackedEffectIdFromString(const FString& ParamString);


	/** 从字符串解析出受击特效数组
	 * @param	const FString&	字符串
	 * @return	std::vector<FString>	受击特效数组
	 */
	static std::vector<int32> GetArrayIntensifyAttackEffectIdFromString(const FString& ParamString);


	/** 从字符串解析出受击特效数组
	 * @param	const FString&	字符串
	 * @return	std::vector<FString>	受击特效数组
	 */
	static std::vector<int32> GetArrayIntensifyBeAttackedEffectIdFromString(const FString& ParamString);
};
