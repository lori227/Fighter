#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "CWGameDefine.h"
#include "CWDungeonDecorateActor.generated.h"


UCLASS()
class ACWDungeonDecorateActor : public AActor
{
	GENERATED_UCLASS_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	USceneComponent* SceneComponent;
};
