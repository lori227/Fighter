
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWGameDefine.h"
#include "CWDungeonDecorateComponent.generated.h"

class ACWRandomDungeonGenerator;

UCLASS()
class UCWDungeonDecorateComponent : public USceneComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCDoFall();

public:
	virtual void DoFallInServer();
	virtual void FallingInServer(float DeltaTime);

	virtual void DoFallInClient();
	virtual void FallingInClient(float DeltaTime);

	virtual void ResetBeforeRiseInClient();
	virtual void DoRiseInClient();
	virtual void RisingInClient(float DeltaTime);

	int32 GetGameId();
	bool IsDoRiseEnd();

	bool IsInServer() const;

protected:
	virtual void OnRiseCompleteInClient();
	virtual FString GetAkEventByOwnerName();

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoFall;

	float CurFallSpeed;
	float TotalFallTime;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoRise;

	float CurRiseSpeed;

	FVector OriginLocation;
	bool bIsDoRiseEnd;

};
