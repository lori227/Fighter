#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWGameDefine.h"
#include "CWDungeonDecorateRegion.generated.h"

class ACWMap;
class ACWPawn;
class ACWMapTile;
class ACWGameInfo;
class ACWRandomDungeonGenerator;
class ACWDungeonDecorateTile;

UCLASS(BlueprintType, Blueprintable)
class UCWDungeonDecorateRegion : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Tile;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 X;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Y;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Coord;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECWEdgeOutSideDecorateOrientation Orient;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECWDecorateAdjacent Adjacent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 AdjacentTile;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Count;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 RemainCount;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ACWRandomDungeonGenerator* ParentDungeonGeneratorInServer;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<ACWDungeonDecorateTile*> ArrayDecorateTile;
};


