#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWGameDefine.h"
#include "CWDungeonDecorateTile.generated.h"

class ACWMap;
class ACWPawn;
class ACWMapTile;
class ACWGameInfo;
class ACWRandomDungeonGenerator;

UCLASS(BlueprintType, Blueprintable)
class ACWDungeonDecorateTile : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCDoFall();

public:
	virtual bool ServerInitForTest(ACWRandomDungeonGenerator* ParamDungeonGenerator, int32 ParamX, int32 ParamY);
	virtual bool InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, int32 ParamX, int32 ParamY);
	virtual void LoadMesh(const FString& MeshPath);
	
	virtual void DoFallInServer();
	virtual void FallingInServer(float DeltaTime);
	virtual void FallingInClient(float DeltaTime);
	
	virtual bool IsInServer() const;

public:

	/** 获得地图
	 * @param	无
	 * @return  无
	 */
	ACWMap* GetMap();


	/** 获得场景生成器
	 * @param	无
	 * @return  无
	 */
	ACWRandomDungeonGenerator* GetDungeonGenerator();

	int32 GetGameId();
	bool IsBeginPlayInClient();

protected:
	float RandomFloat(float Min, float Max);
	int RandomInt(int Min, int Max);

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Tile;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 X;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Y;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	int32 Coord;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	ECWEdgeOutSideDecorateOrientation Orient;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	ECWDecorateAdjacent Adjacent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	int32 AdjacentTile;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	int32 Count;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	USceneComponent* SceneComponent;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UStaticMeshComponent* StaticMesh;

	ACWRandomDungeonGenerator* ParentDungeonGeneratorInServer;

	bool bIsDoFall;
	float TickTime;
	float CurFallSpeed;
	float TotalFallTime;

	bool bIsBeginPlayInClient;
};


USTRUCT()
struct FCWDecorateAssetParamStruct
{
	GENERATED_USTRUCT_BODY()
public:

	FVector RelativeLoc;
	FRotator RelativeRot;
	FVector RelativeScale;
	FString AssetId;
	ECWDecorateAdjacent Adjacent;
	uint8 Coord;
	bool bIsUsed;
};

