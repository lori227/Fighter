﻿
#pragma once

#include "CWPawn.h"
#include "CWDungeonItem.generated.h"

class ACWMap;
class ACWDungeonItemChild;
struct FCWDungeonItemDataStruct;
class ACWRandomDungeonGenerator;
class ACWDungeonItemVisibility;


UCLASS()
class ACWDungeonItem : public ACWPawn
{
	GENERATED_UCLASS_BODY()

public:
	virtual void BeginPlay() override;
	virtual void Destroyed() override;
	virtual void Tick(float DeltaTime) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	virtual bool InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, const int32 ParamTile, const int32 ParamDungeonItemId, float ParamQEuler, const bool bNeedUniqueIdx = true);
	virtual bool InitInClient(ACWPlayerController* InPc) override;

	virtual void LoadMesh(const FString& MeshPath);

public:
	virtual void DieEndInServer() override;

	virtual FString GetDisplayName() const override;

	virtual bool IsMoveTile(int ParamTile) override;

	virtual UCWSkill* GetAutoSelectSkillRecord() override;

	 virtual bool IsAllowOperate() const override;

	/** 属性克制(武器/行动方式/种族...) */
	virtual FString GetWeaponId() const override;
	virtual FString GetActingId() const override;
	virtual FString GetRaceId() const override;

	/** 被选定/被选定为目标 */
	virtual void SelectedInReady(ACWPlayerController* ParamPc) override;
	virtual void CancelSelectedInReady(bool bNeedJumpState = true) override;

	/** 响应:光标(鼠标)移入移出 */
	virtual void BeginCursorOver();
	virtual void EndCursorOver();

	/** 被选中 */
	virtual void SelectedInClient(ACWPlayerController* ParamPc, bool bLongDown) override;
	virtual void CancelSelectedInClient() override;

	virtual void OnBecomeSelectedTarget(bool bSelected, ACWPawn* InOpPawn = nullptr);

	/** 播放点击音效 */
	virtual void PlayClickAudio() override;

	virtual void DoFallInServer() override;
	virtual void FallingInServer(float DeltaTime) override;
	virtual void FallingInClient(float DeltaTime) override;

	virtual int32 GetGameId();
	virtual bool IsBeginPlayInClient();
	virtual float GetTickTime();

	/** 是否为物件Buff */
	virtual bool IsBuffObject();

	/** 增加特效 */
	virtual void AddEffect(const int32 InEffectId);
	virtual void AddBeAttackedEffect(const int32 InEffectId);

public:
	UFUNCTION()
	void RespondAfterPlayerControllerSetupInClientForDungeonItem();

	UFUNCTION()
	void RespondAfterMapSetupInClientForDungeonItem();

public:
	// 是否可以攻击
	virtual bool IsCanAttack() const;

	// 是否没有碰撞
	virtual bool IsNoCollision() const;

	// 是否能交互
	virtual bool CanInteractive() const;

	virtual FString ToString() const;

	void SetItemVisibilityActor(ACWDungeonItemVisibility* ParamItemVisibility);
	ACWDungeonItemVisibility* GetItemVisibilityActor();

	virtual void SetCustomDepthStencilValueEx(int32 ParamValue);

	/** 获得场景物件数据
	 * @param	无
	 * @return	const FCWDungeonItemDataStruct* 场景物件数据
	 */
	const FCWDungeonItemDataStruct* GetDungeonItemDataStruct() const;
	ACWRandomDungeonGenerator* GetDungeonGenerator();

	/** 检测拾取物件Buff */
	virtual bool CheckOverlapPickup(AActor* InOtherActor);

	/** 设置地图格子下标 */
	virtual void SetTile(int32 ParamTile) override;
	virtual void SetTile(int32 ParamOldTile, int32 ParamTile) override;

protected:
	/** 重置地图格子数据 */
	virtual void ResetMapTileAttribute();

	/** 重置地图物件组数据 */
	virtual void ResetMapObjectGroup();

	//~ Begin ElemSys
	/** 获取拥有元素Id(配置表) */
	virtual int32 GetOwnElemIdByCfg() override;
	//~ End ElemSys

	//~ Begin PhysicsSys
	virtual FCWPhysicsSysData GetPhysicsSysData() override;
	//~ End PhysicsSys

	virtual void SetupBattleProperty() override;

	virtual bool IsInClient() const;
	virtual bool IsInServer() const;

	// 创建可破碎对象
	virtual bool CreateDestructibleActor();

	// 设置生成回合限制
	virtual void SetLifespanRound(const int32 InLifespanRound);

	//~ 战斗属性集修改回调
	virtual void NotifyUpdatePropertyData();

	UFUNCTION()
	virtual void OnRoundChange(int32 InCurRound, int32 InMaxRound);

	/** 响应:重叠 */
	virtual void OnBeginOverlap(AActor* OtherActor) override;
	virtual void OnEndOverlap(AActor* OtherActor) override;

	bool SetObstacle(ACWMap* ParamMap, int32 ParamTile, const FCWDungeonItemDataStruct* ParamDungeonItemData, float ParamQEuler);

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UStaticMeshComponent* StaticMesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 DungeonItemId;

	ACWRandomDungeonGenerator* ParentDungeonGeneratorInServer;

	bool bIsCursorOver;
	bool bIsSelected;

	bool bIsBeginPlayInClient;
	float TickTime;

protected:
	/** 碰撞检测组件 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	USphereComponent* SphereComp;

	/** 粒子组件 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UParticleSystemComponent* ParticleComp;

	/** 存在回合(-1:永久) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	int32 LifespanRound;

	/** Buff-Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	int32 OwnerBuffId;

	/*UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ACWDungeonItemChild* ItemChildActor;*/
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	ACWDungeonItemVisibility* ItemVisibilityActor;
};
