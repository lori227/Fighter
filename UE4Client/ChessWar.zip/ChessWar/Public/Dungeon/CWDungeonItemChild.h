﻿
#pragma once

#include "GameFramework/Actor.h"
#include "CWElementSystemData.h"
#include "CWDungeonItemChild.generated.h"

class ACWDungeonItem;
class UStaticMeshComponent;
class UParticleSystemComponent;


UCLASS()
class ACWDungeonItemChild : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWDungeonItemChild();

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastOnObjElemTypeEvent(const EObjElemType InObjElemType);

protected:
	UFUNCTION(BlueprintNativeEvent, Category = Default)
	void OnObjElemTypeEvent(const EObjElemType InObjElemType);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Default)
	UStaticMeshComponent* DefaultStaticMeshComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Default)
	UParticleSystemComponent* DefaultParticleComp;

};
