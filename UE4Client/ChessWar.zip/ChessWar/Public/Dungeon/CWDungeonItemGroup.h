﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWDungeonItem.h"
#include "CWGameDefine.h"

#include "CWDungeonItemGroup.generated.h"

UCLASS(BlueprintType)
class ACWDungeonItemGroup : public AActor
{
	GENERATED_UCLASS_BODY()
public:
	virtual void BeginPlay() override;
	virtual void Destroyed() override;
	virtual void Tick(float DeltaTime) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
public:
	void Init(int32 ParamTile);

	void DoFallInServer();

	bool AddItem(int32 ParamLayer, ACWDungeonItem* ParamDungeonItem);

	bool IsBeginPlayInClient();

	bool GetAllArrayItem(TArray<ACWDungeonItem*>& ParamOutArrayItem);
	bool GetAllDungeonItemByCanBeAttacked(TArray<ACWDungeonItem*>& ParamOutArrayItem);
	bool GetAllBuffObjects(TArray<ACWDungeonItem*>& ParamOutArrayItem);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	int32 Tile;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	TArray<ACWDungeonItem*> ArrayDungeonItem;
};
