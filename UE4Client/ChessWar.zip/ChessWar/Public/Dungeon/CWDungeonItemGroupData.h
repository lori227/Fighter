
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CWDungeonItem.h"
#include "CWGameDefine.h"

#include "CWDungeonItemGroupData.generated.h"

class ACWRandomDungeonGenerator;

USTRUCT(BlueprintType)
struct FCWDungeonItemGroupData
{
	GENERATED_USTRUCT_BODY()
public:
	FCWDungeonItemGroupData();
	virtual ~FCWDungeonItemGroupData();

public:
	void Init(ACWRandomDungeonGenerator* ParamGenerator, int32 ParamTile);
	bool CanAdd(int32 ParamItemId);
	bool AddItem(int32 ParamItemId, float ParamQEuler);
	bool GetArrayItem(TArray<int32>& ParamOutArrayItem);
	bool GetArrayItemQEuler(TArray<float>& ParamOutArrayItemQEuler);

	bool SetObstacleData(int32 ParamTile, const FCWDungeonItemDataStruct* ParamDungeonItemData, float ParamQEuler);
private:

	ACWRandomDungeonGenerator* Generator;

	int32 Tile;

	UPROPERTY()
	TArray<int32> ArrayItem;

	UPROPERTY()
	TArray<float> ArrayItemQEuler;
};
