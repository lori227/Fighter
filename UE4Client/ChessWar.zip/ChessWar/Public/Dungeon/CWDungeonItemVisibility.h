
#pragma once

#include "GameFramework/Actor.h"
#include "CWElementSystemData.h"
#include "CWDungeonItemVisibility.generated.h"

class ACWDungeonItem;
class UStaticMeshComponent;
class UParticleSystemComponent;


UCLASS()
class ACWDungeonItemVisibility : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWDungeonItemVisibility();

public:

	virtual void BeginPlay() override;

	virtual void NotifyActorBeginCursorOver() override;
	virtual void NotifyActorEndCursorOver() override;

	/** ��Ӧ:���(���)�����Ƴ� */
	virtual void BeginCursorOver();
	virtual void EndCursorOver();

public:
	bool IsInClient() const;
	bool IsInServer() const;

	void SetItemVisibilityCollision(bool ParamCollision);

	void HandleCustomDepthStencilValue(int32 ParamValue);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Default)
	UStaticMeshComponent* DefaultStaticMeshComp;
};
