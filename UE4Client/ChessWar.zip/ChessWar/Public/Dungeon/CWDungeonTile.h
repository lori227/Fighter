﻿#pragma once

#include "CWGameDefine.h"
#include "CWWeatherData.h"
#include "GameFramework/Actor.h"
#include "CWGridSwitchComponen.h"
#include "CWStaticMeshComponent.h"
#include "CWDungeonTile.generated.h"

class ACWMap;
class ACWPawn;
class ACWMapTile;
class ACWGameInfo;
class ACWRandomDungeonGenerator;

UCLASS()
class ACWDungeonTile : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual void BeginPlay() override;
	virtual void Destroyed() override;
	virtual void Tick(float DeltaTime) override;

public:
	/** 响应:光标(鼠标)移入移出 */
	virtual void BeginCursorOver();
	virtual void EndCursorOver();

	virtual bool InitInServer(ACWRandomDungeonGenerator* ParamDungeonGenerator, const int32 InTile, const int32 InRegionId);
	virtual bool ClientUpdate();

	virtual void LoadMesh(const FString& MeshPath);
	virtual void SetOverrideMaterialIdx(const int32 InIdx);

	virtual void SetOffsetZ(float ParamOffsetZ);
	virtual float GetOffsetZ() const;

	virtual void DoFallInServer();
	virtual void FallingInServer(float DeltaTime);
	virtual void FallingInClient(float DeltaTime);

	virtual void DoRiseInServer();
	virtual void DoRiseInClient();
	virtual void DoRiseEndInClient();
	virtual void RisingInServer(float DeltaTime);
	virtual void RisingInClient(float DeltaTime);

	virtual bool IsInServer() const;

public:

	/** 获得地图
	 * @param	无
	 * @return  无
	 */
	ACWMap* GetMap();


	/** 获得场景生成器
	 * @param	无
	 * @return  无
	 */
	ACWRandomDungeonGenerator* GetDungeonGenerator();

	int32 GetGameId();

	bool IsDoRise();
	bool IsDoRised();
	bool IsDoRiseEnd();
	bool IsBeginPlayInClient();
	float GetTickTime();
	int32 GetTile() const;

protected:
	float RandomFloat(float Min, float Max);
	int RandomInt(int Min, int Max);

	UFUNCTION()
	virtual void OnRep_RegionId();

	UFUNCTION()
	virtual void OnRep_ResNameIndex();

	UFUNCTION()
	virtual void OnRep_OverrideMaterialIdx();

	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCDoFall();

	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCDoRise();

	/** 静态网格改变 */
	UFUNCTION()
	virtual void OnStaticMeshChanged();

	/** 天气索引改变 */
	UFUNCTION()
	virtual void OnWeatherIdxChange(ECWWeatherType InWeatherType, ECWWeatherType InOldWeatherType);

	/** 初始化动态材质 */
	virtual void InitStaticMeshMaterial();

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Tile;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 X;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	int32 Y;

	UPROPERTY(Replicated, ReplicatedUsing = OnRep_RegionId)
	int32 RegionId;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Replicated)
	float OffsetZ;

	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ResNameIndex)
	int32 ResNameIndex;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	USceneComponent* SceneComponent;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UCWStaticMeshComponent* StaticMesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoFall;

	ACWRandomDungeonGenerator* ParentDungeonGeneratorInServer;
	float CurFallSpeed;
	float TotalFallTime;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoRise;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoRised;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bIsDoRiseEnd;

	float CurRiseSpeed;

	bool bIsTriggerRise;
	bool bIsBeginPlayInClient;
	float TickTime;
	TArray<FTimerHandle> ArrayTimerHandler;

	/** Event triggered when the tile is do fall. */
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBeginFallInClient, ACWDungeonTile*, InDungeonTile);
	UPROPERTY(BlueprintAssignable, Category = "Game")
	FOnBeginFallInClient OnBeginFallInClient;

protected:
	// Temp ref
	TWeakObjectPtr<ACWGameInfo> GameInfoPtr;
	TWeakObjectPtr<ACWRandomDungeonGenerator> DungeonGeneratorPtr;

	/** 格子材质变化组件 */
	UPROPERTY()
	UCWGridSwitchComponen* GridSwitchComp;

	/** 材质索引Id */
	UPROPERTY(VisibleAnywhere, Replicated, ReplicatedUsing = OnRep_OverrideMaterialIdx)
	int32 OverrideMaterialIdx;

private:
	FTimerHandle ShowTileTipsTimer;
};
