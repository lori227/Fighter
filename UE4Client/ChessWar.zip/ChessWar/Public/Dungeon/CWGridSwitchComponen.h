﻿
#pragma once

#include "Materials/MaterialInstance.h"
#include "Components/ActorComponent.h"
#include "CWGridSwitchComponen.generated.h"


UCLASS(BlueprintType, Blueprintable)
class UCWGridSwitchComponen : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWGridSwitchComponen();

	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;

public:
	UFUNCTION(BlueprintNativeEvent, Category = Default)
	bool InitGridMeshMaterial(UStaticMeshComponent* InStaticMeshComp, UMaterialInstance* InBaseMaterial);

	UFUNCTION(BlueprintNativeEvent, Category = Default)
	bool UpdateGridMeshMaterial(ECWWeatherType InWeatherType);

};
