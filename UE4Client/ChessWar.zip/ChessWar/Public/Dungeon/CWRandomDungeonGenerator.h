﻿
#pragma once

#include <map>
#include <list>
#include <vector>
#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Containers/Array.h"
#include "GameFramework/Character.h"
#include "Components/SceneComponent.h"

#include "Global/CWGameDefine.h"
#include "CWRandomEvtData.h"
#include "CWDungeonDecorateTile.h"
#include "CWRandomDungeonRegionData.h"
#include "CWDungeonItemGroupData.h"
#include "CWDungeonItemGroup.h"
#include "CWLogicRegion.h"
#include "CWRandomDungeonRegionTopography.h"
#include "CWRandomDungeonGenerator.generated.h"

class BSHL2D;
class AStar2D;
class ACWMap;
class ACWPawnStart;
class ACWDungeonTile;
class ACWDungeonItem;
class ACWDungeonItemGroup;
class UCWRandomEventCtrl;
class ACWDungeonDecorateTile;
class UCWDungeonDecorateRegion;
struct FCWGameDataStruct;
struct FCWDungeonDataStruct;
struct FCWDungeonItemDataStruct;
struct FCWDungeonRegionDataStruct;
struct FCWDecorateMeshParamStruct;


DECLARE_DYNAMIC_MULTICAST_DELEGATE(FDungeonTileFallFinishDelegate);

struct FPawnStartData
{
	ECWCampTag CampTag;
	ECWCampControllerIndex CampIdx;
	int32 PawnIdx, PawnId;
	float PawnYaw;

	FPawnStartData(
		ECWCampTag InCampTag,
		ECWCampControllerIndex InCampIdx,
		int32 InPawnId,
		int32 InPawnIdx,
		float InPawnYaw)
		: CampTag(InCampTag)
		, CampIdx(InCampIdx)
		, PawnIdx(InPawnIdx)
		, PawnId(InPawnId)
		, PawnYaw(InPawnYaw)
	{
	}
};

UCLASS(BlueprintType, Blueprintable)
class ACWRandomDungeonGenerator : public AActor
{
	GENERATED_UCLASS_BODY()

public:

	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void Tick(float DeltaTime) override;

	virtual void Serialize(FArchive& Ar) override;

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCDungeonDecorateFall();

	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCRefreshAllLocation();
public:

	UPROPERTY(BlueprintCallable)
	FDungeonTileFallFinishDelegate OnDungeonTileFallFinishEventInServer;

public:

	bool Init(int ParamRandomDungeonId);
	bool IsInit();
	bool GenerateDungeon();
	bool GenerateDungeonForFlatLand();
	bool GenerateDungeonForHighLand();
	bool GenerateDungeonForLowLand();
	bool GenerateDungeonForRegion();
	bool RandomRemoveDungeonExtension();
	bool GenerateDungeonDecorateRegion();
	bool GenerateDungeonDecorateTile();
	bool GenerateDecorateMapByConfig();
	bool GenerateDungeonWall();
	bool GenerateDungeonItemOld();
	bool GenerateDungeonItem();
	bool GeneratePawnStart();
	bool GenerateDungeonFall();
	bool GenerateDungeonFallNew();

	bool GenerateDungeonRegionTopographyByCoord(FCWDungeonDataStruct* ParamDungeonData, ECWEdgeOutSideDecorateCoord ParamCoord, int32 ParamWidth, int32 ParamHeight, ECWDungeonRegionTopography ParamDungeonRegionTopography);
	bool GenerateDungeonRegionToHelp(FCWDungeonDataStruct* ParamDungeonData, int32 ParamWidth, int32 ParamHeight, int32 ParamDungeonRegionId);

	bool GenerateDungeon_2();
	bool GenerateLogicDungeonRegion_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateLogicPawnStartRegion_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateLogicPawnStart_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateLogicGoThroughLine_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateLogicSplitLine_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateLowSpeed_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateHighSpeed_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateStatistics_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateShow_2(FCWDungeonDataStruct* TempDungeonData);
	bool GeneratePawnStart_2();
	
	bool GenerateLogicSplitLineHelp_2(FCWDungeonDataStruct* TempDungeonData, int32 ParamIndex);
	bool GenerateLogicSplitLineHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldOldLogicRegion, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex);
	bool GenerateLogicGoThroughLineHelp_2(FCWDungeonDataStruct* TempDungeonData, int32 ParamIndex, int32 ParamPathLineNum, int32 ParamHighRoadIndex);
	bool GenerateIntersectionStartByLogicRegion(FCWLogicRegion ParamALogicRegion, FCWLogicRegion ParamBLogicRegion, int32& ParamOutX, int32& ParamOutY);
	bool GenerateIntersectionEndByLogicRegion(FCWLogicRegion ParamALogicRegion, FCWLogicRegion ParamBLogicRegion, int32& ParamOutX, int32& ParamOutY);
	bool FindSymmetryLogicRegionFromSpawnRegion(
		FCWDungeonDataStruct* TempDungeonData,
		int32 ParamSpawnRegionRightX,
		int32 ParamSpawnRegionRightY,
		int32 ParamSpawnRegionLeftX,
		int32 ParamSpawnRegionLeftY,
		int32& ParamOutSymmetryRegionRightX,
		int32& ParamOutSymmetryRegionRightY,
		int32& ParamOutSymmetryRegionLeftX,
		int32& ParamOutSymmetryRegionLeftY);
	bool GenerateLogicGoThroughLineStartHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex);
	bool GenerateLogicGoThroughLineHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldOldLogicRegion, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex);
	bool GenerateLogicGoThroughLineEndHelpInner(FCWDungeonDataStruct* TempDungeonData, FCWLogicRegion ParamOldLogicRegion, FCWLogicRegion ParamLogicRegion, ECWDungeonRegionType ParamRegionType, int32 ParamIndex);
	bool FixLogicGoThroughLine(FCWDungeonDataStruct* TempDungeonData);
	bool FixLogicDangerBlock(FCWDungeonDataStruct* TempDungeonData);
	bool FixLogicForbidLine(FCWDungeonDataStruct* TempDungeonData);
	bool FixLogicLowSpeedLine(FCWDungeonDataStruct* TempDungeonData);
	bool ReplaceForbidToLowSpeed(FCWDungeonDataStruct* TempDungeonData);
	bool ReplaceDangerToHighSpeed(FCWDungeonDataStruct* TempDungeonData);
	bool GenertateForbidLine(FCWDungeonDataStruct* TempDungeonData);
	bool FixGlobalLowSpeed(FCWDungeonDataStruct* TempDungeonData);
	int32 GetR(FCWDungeonDataStruct* TempDungeonData);

	static int isCanPassForRegionSplitLine(int px, int py, int cx, int cy);
	static int isCanPassForRegionGoThroughLine(int px, int py, int cx, int cy);
	static int cost(int px, int py, int cx, int cy);
	bool canPassForRegionGoThroughLine(int cx, int cy);
	static int isCanPassForTileGoThroughLine(int px, int py, int cx, int cy);
	bool canPassForTileGoThroughLine(int cx, int cy);

	bool GenerateHighSpeedLandform_2(FCWDungeonDataStruct* TempDungeonData);
	bool RandomDungeonRegionFromZoneType(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamZoneType, const std::vector<int32>& ParamExclusive, int32& ParamOutDungeonRegion);
	bool GenerateDangerBlockLandform_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateDangerForbidLandform_2(FCWDungeonDataStruct* TempDungeonData);
	bool GenerateDangerLowSpeedLandform_2(FCWDungeonDataStruct* TempDungeonData);
	bool FindShortest(
		int32 ParamX,
		int32 ParamY,
		int32& ParamElevationStart,
		int32& ParamElevationEnd,
		std::vector<FIntPoint>& ParamArrayStart,
		std::vector<FIntPoint>& ParamArrayEnd,
		int32& ParamS,
		int32& ParamE);
	int32 IsGoThroughLineOrDangerBlock(int32 ParamX, int32 ParamY);
	int32 GetElevation(int32 ParamX, int32 ParamY);
	bool RandomDungeonRegionFromElevation(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamElevation, const std::vector<int32>& ParamExclusive, int32& ParamOutDungeonRegion);
	int32 GetLandformCount(ECWDungeonRegionStyle ParamDungeonStyle, int32 ParamRegionZoneType);
	bool GeneraterHighRegionElevation(ECWDungeonRegionStyle ParamDungeonStyle);
	bool GeneraterDangerRegionElevationMin(ECWDungeonRegionStyle ParamDungeonStyle);
	bool GeneraterDangerRegionElevationMax(ECWDungeonRegionStyle ParamDungeonStyle);
	bool GeneraterMapGroupZoneType(FCWDungeonDataStruct* TempDungeonData);

	// 获取掉落外围格子数据
	TArray<int32> GetDungeonFallTileArray();

	// 是否当前在掉落状态内(预警/掉落)
	virtual bool IsInDungeonFallState();

	// 生成随机事件控制器
	virtual bool GenerateRandomEvtCtrl();
	virtual UCWRandomEventCtrl* GetRandomEvtCtrl();

	bool GenerateDungeonDecorateFallInServer();
	bool GenerateDungeonDecorateFallInClient();

	void ResetDungeonDecorateBeforeRiseInClient();
	bool DungeonDecorateDoRiseInClient();

	void ResetPawnBeforeDoSpawnActionInClient();
	void PawnDoSpawnActionInClient();

	void RefreshAllLocationInServer();
	void RefreshAllLocationInClient();

	bool DungeonFallWarningInClient(int32 ParamCurDungeonTileFallIndex);
	bool DungeonFallWarningInClientNew(int32 ParamCurDungeonTileFallIndex);
	void HideDungeonFallWarningInClient(int32 ParamCurDungeonTileFallIndex);
	void HideDungeonFallWarningInClientNew(int32 ParamCurDungeonTileFallIndex);

	int GetRandomDungeonRegionTopography(int32 ParamTile, int32& HighLandCount, int32& LowLandCount);
	void RefreshRandomDungeonRegion(int32 ParamTile);
	void RefreshRandomDungeonRegionCenterOrBorder(int32 ParamX, int32 ParamY, int32 ParamTile);
	void RefreshRandomDungeonRegionBase(int32 ParamTile, ECWDungeonRegionStyle ParamDungeonStyle);
	void RefreshRandomDungeonRegionBaseForPawnStart(FCWDungeonDataStruct* ParamDungeonData, int32 ParamTile, ECWDungeonRegionStyle ParamDungeonStyle);

	int32 FindDungeonRegionDataForFlatLandBase(ECWDungeonRegionStyle ParamDungeonStyle);
	int32 FindDungeonRegionDataForHighLandBase(ECWDungeonRegionStyle ParamDungeonStyle);
	int32 FindDungeonRegionDataForLowLandBase(ECWDungeonRegionStyle ParamDungeonStyle);
	FCWDungeonDataStruct* GetDungeonData();
	static FCWDungeonRegionDataStruct* GetDungeonRegionData(int32 ParamDungeonRegionId);
	static FCWDungeonItemDataStruct* GetDungeonItemData(int32 ParamDungeonItemId);

	void DestroyDungeonTileInServer(int32 ParamTile);
	void DestroyDungeonItemInServer(int32 ParamTile);

	ACWDungeonItem* GetDungeonItem(int32 ParamTile);
	TArray<ACWDungeonItem*> GetAllDungeonItem(int32 ParamTile);
	TArray<ACWDungeonItem*> GetAllDungeonItemByCanBeAttacked(int32 ParamTile);
	TArray<ACWDungeonItem*> GetAllBuffObjects(int32 ParamTile);
	virtual ACWDungeonTile* GetDungeonTile(int32 ParamTile);

	bool IsAllDungeonItemBeginPlayInClient();
	bool IsAllDungeonTileBeginPlayInClient();
	bool IsAllDungeonItemTickTimeOKInClient();
	bool IsAllDungeonTileTickTimeOKInClient();
	bool IsAllDungeonTileRiseOKInClient();
	bool IsAllDungeonTileAfterRiseInClient();

	bool IsAllDungeonDecorateDoRiseEndInClient();
	bool IsAllDungeonDecorateTileBeginPlayInClient();

	ECWEdgeOutSideDecorateOrientation CaculateDecorateOrientation(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, int32& OutCount, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationHorizontalForToXMax(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationHorizontalForToXMaxHelp(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, int32 count, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationHorizontalForToXMin(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationHorizontalForToXMinHelp(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, int32 count, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationVerticalForToYMax(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationVerticalForToYMaxHelp(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, int32 count, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationVerticalForToYMin(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	int32 CheckEdgeOutSideDecorateOrientationVerticalForToYMinHelp(int32 ParamX, int32 ParamY, ECWEdgeOutSideDecorateCoord ParamCoord, int32 count, TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, ECWDecorateAdjacent& OutAdjacent, int32& OutAdjacentTile);
	void AddDecorateTile(
		int32 ParamX, 
		int32 ParamY, 
		ECWEdgeOutSideDecorateCoord ParamCoord, 
		ECWEdgeOutSideDecorateOrientation ParamOrient,
		int32 count,
		TArray<ACWDungeonDecorateTile*>& TempArrayDecorateTile, 
		ECWDecorateAdjacent ParamAdjacent, 
		int32 ParamAdjacentTile);

	void JudgeAdjacent(
		ECWEdgeOutSideDecorateCoord ParamCoord,
		ECWEdgeOutSideDecorateOrientation ParamOrient,
		int32 ArrayDungeonGridByt2minx,
		int32 t2minx,
		int32 ArrayDungeonGridByt2maxx,
		int32 t2maxx,
		int32 ArrayDungeonGridByt2miny,
		int32 t2miny,
		int32 ArrayDungeonGridByt2maxy,
		int32 t2maxy,
		ECWDecorateAdjacent& OutAdjacent,
		int32& OutAdjacentTile);

	void PlaceDecorateToSingle(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion);
	void PlaceDecorateToHorizontal(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion);
	void PlaceDecorateToHorizontalHelp(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion, int32 ParamCount);
	void PlaceDecorateToVertical(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion);
	void PlaceDecorateToVerticalHelp(ECWEdgeOutSideDecorateCoord TempCoord, UCWDungeonDecorateRegion* TempDungeonDecorateRegion, int32 ParamCount);

	const TArray<int32>& GetArrayDungeonGrid() const;
	const TArray<int32>& GetArrayDungeonGrid_Z() const;
	const TArray<int32>& GetArrayDungeonRegionId() const;
	
	bool SetArrayDungeonItemObstacle(int32 ParamTile, int32 ParamObstacle);

	// 获取格子地势层数
	virtual int32 GetGridLayerByTile(const int32 InTile);

	bool IsInServer() const;
	bool IsMyClientPawn() const;
	bool IsOtherClientPawn() const;

	virtual class ACWPlayerController* GetLocalPC();

	// 获取场景中心位置
	virtual FVector GetSceneCenterPoint();
	virtual bool IsValidSceneCenterPoint(const FVector& InPoint);

	// 获取单个地块格子大小
	virtual FVector2D GetSingleTileSize();

	/**
	 * @brief	获取最外围各方向位置(上下左右)
	 * @param	InExpandOutTileNum: 向外额外格子数
	 * @return	True: 有效值
	 */
	virtual bool GetEdgeDirectionPoint(FVector& OutDownPoint, FVector& OutTopPoint, 
		FVector& OutRightPoint, FVector& OutLeftPoint, const uint32 InExpandOutTileNum = 0);

	/**
	 * @brief	获取最外围对角位置
	 * @param	InExpandOutTileNum: 向外额外格子数
	 * @return	True: 有效值
	 */
	virtual bool GetEdgeDiagonalPoint(FVector& OutDownRight, FVector& OutDownLeft, 
		FVector& OutTopRight, FVector& OutTopLeft, const uint32 InExpandOutTileNum = 0);

	// 获取棋子出生点数据
	virtual TArray<ACWPawnStart*>& GetPawnStartList();
	virtual ACWPawnStart* GetPawnStartByTile(const int32 InTile);

	// 获取格子偏移
	virtual float GetOffsetZ(const int32 InTile);

	// Getter 
	virtual TArray<ACWDungeonTile*>& GetDungeonTileList();

	// Getter 
	virtual ACWDungeonItemGroup* GetDungeonItemGroup(int32 ParamTile);

	//~ 客户端关卡物件偏移Z
	virtual void ResetObjectExtraOffsetZ();
	virtual float GetObjectExtraOffsetZ();

	// 获取对应格子真实Z位置
	virtual float GetLocationZ(const int32 InTileNumber);

	static void tile2xy(int tile, int& x, int& y);
	static void tile2pos(int tile, FVector& pos);
	static int xy2tile(int x, int y);
	static void xy2pos(int x, int y, FVector& pos);
	static int pos2tile(const FVector& pos);
	static void pos2xy(const FVector& pos, int& x, int& y);

protected:

	float RandomFloat(float Min, float Max);
	int RandomInt(int Min, int Max);
	void RandomShuffle(
		std::vector<int32>& ParamArrayDungeonRegionIdForRandom,
		std::vector<std::vector<int32> >& ParamArrayArrayDungeonRegionRandomMinMaxForRandom,
		std::vector<std::vector<int32> >& ParamArrayArrayDungeonRegionSideMinMaxForRandom,
		int ParamShuffleCount);
	void RandomShuffle(
		std::vector<std::vector<int32> >& ParamArrayDungeonRegionToRandom,
		std::vector<int32>& ParamArrayDungeonRegionIdForRandom,
		int ParamShuffleCount);
	void Swap(std::vector<int32>& lhs, std::vector<int32>& rhs);
	void Swap(int32& lhs, int32& rhs);
	void RandomGridIndexForHighLand(int32& x, int32& y, int32 TempSizeX, int32 TempSizeY, int32 TempHasWall);
	void RandomGridIndexForLowLand(int32& x, int32& y, int32 TempSizeX, int32 TempSizeY, int32 TempHasWall);
	bool IsThereRepetitionForTopography(int32 x, int32 y);
	bool IsThereRepetitionForRegion(int32 x, int32 y);
	bool IsThereFitForItemByQEuler(int32 ParamTile, int32 ParamDungeonItemId, float ParamQEuler);
	bool IsThereFitForItem(int32 ParamTile, int32 ParamDungeonItemId, float& TempOutQEuler);
	bool IsMNObstacle(int32 ParamTile, int32 ParamM, int32 ParamN);
	bool IsMNValid(int32 ParamTile, int32 ParamM, int32 ParamN);
	bool IsMNSameZ(int32 ParamTile, int32 ParamM, int32 ParamN);
	bool IsMNPawnStart(int32 ParamTile, int32 ParamM, int32 ParamN);
	bool IsTherePawnStart(int32 ParamTile);
	bool IsArrayDungeonItemObstacle(int32 ParamTile);
	void PlaceRandomRegionTopography(int32 TempRegionId, ECWDungeonRegionTopography TempRegionTopography, int32 x, int32 y, int32 ParamHighWidth, int32 ParamHighHeight);
	void PlaceRandomRegion(int32 TempRegionId, int32 x, int32 y, int32 ParamHighWidth, int32 ParamHighHeight);
	bool GetFirstDungeonHasWall(FCWRandomDungeonRegionData& ParamDungeonRegionData);
	void RandomShuffle(std::vector<int32>& ParamArrayDoor, int ParamShuffleCount);
	void RandomDungeonItemTile(int32& x, int32& y);
	float RandomDungeonItemEuler();
	bool GeneratePawnStartByIdx(int32 );
	std::vector<ECWEdgeOutSideDecorateCoord> AnalyzeHeightPrefer(int32 TempInt32);

public:
	ACWMap* GetMap();
	int32 GetGameId();
	FCWGameDataStruct* LoadGameData(int32 TempGameId);

	/** 获取地块Z最小值 */
	virtual float GetLowestTileZ();

protected:
	//~ 关卡地块上升
	UFUNCTION()
	virtual void OnLevelSiteRise(const ACWDungeonTile* InTile);
	virtual void OnLevelSiteRiseBegin(const ACWDungeonTile* InTile);

	//~ 随机关卡地块偏移
	virtual bool RandomOffsetTileList(TArray<int32>& OutArray);
	virtual bool RandomOffsetTileZRange(FVector2D& OutOffsetRange);

	//~ 地块偏移高度数据改变
	UFUNCTION()
	virtual void OnRep_ArrayTileOffsetZ();

	/** 战斗状态改变 */
	UFUNCTION()
	virtual void OnBattleStateChange(const ECWBattleState InOldState, const ECWBattleState InCurState);

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCHideFallWarning(int32 ParamCurDungeonTileFallIndex);

protected:
	/**< 静态指针 */
	static ACWRandomDungeonGenerator* s_this;

	/** 随机事件控制器 */
	UPROPERTY(VisibleAnywhere, Category = Default)
	UCWRandomEventCtrl* RandomEventCtrl;

	int RandomDungeonId;

	bool bIsInit;

	int32 DungeonItemIndex;

	UPROPERTY(Replicated)
	int32 DungeonWidth;

	UPROPERTY(Replicated)
	int32 DungeonHeight;

	UPROPERTY(Replicated)
	int32 offsetX;

	UPROPERTY(Replicated)
	int32 offsetY;

	UPROPERTY()
	TArray<FCWRandomDungeonRegionTopography> ArrayRandomDungeonRegionTopography;

	UPROPERTY()
	TArray<FCWRandomDungeonRegionData> ArrayRandomDungeonRegion;

	// 棋子出生点数据
	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<ACWPawnStart*> ArrayPawnStart;

	// 地块格子数据
	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<ACWDungeonTile*> ArrayDungeonTile;

	// 地块物件组数据
	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<ACWDungeonItemGroup*> ArrayDungeonItemGroup;

	// 地块装饰物(外围)
	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<ACWDungeonDecorateTile*> ArrayDungeonDecorateTile;

	// 地块偏移高度数据
	UPROPERTY(VisibleAnywhere, Replicated, ReplicatedUsing = OnRep_ArrayTileOffsetZ)
	TArray<float> ArrayTileOffsetZ;

	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<int32> ArrayDungeonGrid;

	// 地块层数数据
	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<int32> ArrayDungeonGrid_Z;

	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<int32> ArrayDungeonRegionId;

	UPROPERTY(VisibleAnywhere, Replicated)
	TArray<ECWDungeonRegionSpace> ArrayDungeonRegionSpace;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<UCWDungeonDecorateRegion*> ArrayDungeonDecorateRegion;

	typedef std::map<int32, std::vector<FCWDecorateAssetParamStruct>> MapList;
	typedef std::map<ECWDecorateAdjacent, MapList> MapMapList;
	typedef std::map<ECWEdgeOutSideDecorateOrientation, MapMapList> MapMapMapList;
	MapMapMapList MapMapMapListDecorate;

	bool IsTriggerDungeonDecorateDoRiseInClient;
	bool IsTriggerPawnDoSpawnActionInClient;
	bool IsResetPawnBeforeDoSpawnActionInClient;

	UPROPERTY()
	TArray<FCWDungeonItemGroupData> ArrayDungeonItemForData;
	
	UPROPERTY()
	TArray<int32> ArrayDungeonItemObstacle;

	UPROPERTY(VisibleAnywhere)
	float ObjectExtraOffsetZ = .0f;

private:

	int32 SpawnRegionRightX;
	int32 SpawnRegionRightY;
	int32 SpawnRegionLeftX;
	int32 SpawnRegionLeftY;
	std::map<int32, std::map<int32, FCWLogicRegion>> MapLogicRegion;

	int32 HighRegionElevation;
	int32 DangerRegionElevationMin;
	int32 DangerRegionElevationMax;

	TArray<ECWDungeonTileType> ArrayTileTileType;
	TArray<ECWDungeonRegionType> ArrayTileType;
	TArray<int32> ArrayTileGroup;
	TArray<int32> ArrayTileElevation;
	int32 HighRoadIndex;
	BSHL2D* bshl;
	AStar2D* as1;
	AStar2D* as2;
	int32 LogicWidthNum;
	int32 LogicHeightNum;

	TMap<int32, FPawnStartData> MapPawnStart;
	int32 PawnStartRandomIdx;

	std::map<int32, int32> MapGroupZoneType;
	std::map<int32, int32> MapRegionTileCount;

private:
	uint8 bLevelSiteRiseBegin : 1;
	float LowestTileZ;

public:
	void DoFallDown(ACWMap* TempMap, int x, int y, int &totalCount, int curFallCount);
	void DoWarning(ACWMap* TempMap, int x, int y, int &totalCount, int curFallCount);
	void HideWarning(ACWMap* TempMap, int x, int y, int &totalCount, int curFallCount);
	void DoMonsterAction(ECWDungeonArea area, ECWDungeonFallPhase phase);
}; 
