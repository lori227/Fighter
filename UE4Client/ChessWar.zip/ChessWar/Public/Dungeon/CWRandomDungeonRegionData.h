#pragma once


#include "CoreMinimal.h"
#include "Engine.h"
#include <vector>
#include "Global/CWGameDefine.h"
#include "CWBattlePropertySet.h"
#include "CWRandomDungeonRegionData.generated.h"

USTRUCT(BlueprintType)
struct FCWRandomDungeonRegionData
{
	GENERATED_USTRUCT_BODY()
public:
	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWRandomDungeonRegionData();


	/** 拷贝构造函数
	 * @param	const FCWRandomDungeonRegionData&	另一个随机地图区域数据
	 * @return	无
	 */
	FCWRandomDungeonRegionData(const FCWRandomDungeonRegionData& r);


	/** 赋值函数
	 * @param	const FCWRandomDungeonRegionData&	另一个随机地图区域数据
	 * @return	FCWRandomDungeonRegionData&		返回自己的引用
	 */
	FCWRandomDungeonRegionData& operator = (const FCWRandomDungeonRegionData& r);


	/** 友元==
	 * @param	const FCWRandomDungeonRegionData&	另一个随机地图区域数据l
	 * @param	const FCWRandomDungeonRegionData&	另一个随机地图区域数据r
	 * @return	bool true:相等, false:不相等
	 */
	friend bool operator == (const FCWRandomDungeonRegionData& l, const FCWRandomDungeonRegionData& r);


	/** 重置
	 * @param	无
	 * @return	无
	 */
	void Reset();

public:

	/**< 原点x */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 OriginX;

	/**< 原点x */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 OriginY;

	/**< 宽度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SizeX;

	/**< 高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 SizeY;

	/**< 区域Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int32 DungeonRegionId;

	/**< 区域空间类型 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ECWDungeonRegionSpace DungeonRegionSpace;
};
