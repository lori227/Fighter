﻿
#pragma once

#include "Delegate.h"
#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"
#include "Components/StaticMeshComponent.h"
#include "CWStaticMeshComponent.generated.h"


UCLASS(BlueprintType, Blueprintable)
class UCWStaticMeshComponent : public UStaticMeshComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWStaticMeshComponent();

	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
	//virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	virtual bool SetStaticMesh(class UStaticMesh* InNewMesh) override;

public:
	DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnCWStaticMeshChanged);
	virtual FOnCWStaticMeshChanged& OnCWStaticMeshChanged() { return OnStaticMeshChangedDelegate; }
private:
	FOnCWStaticMeshChanged OnStaticMeshChangedDelegate;

};
