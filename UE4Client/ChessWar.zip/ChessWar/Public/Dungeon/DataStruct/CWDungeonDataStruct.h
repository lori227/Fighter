#pragma once
#include "Engine.h"
#include "CWDungeonDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWDungeonDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWDungeonDataStruct();
	virtual ~FCWDungeonDataStruct();
public:

	/** DungeonId */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonId;

	/** Dungeon名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString DungeonName;

	/** Dungeon描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString DungeonDescForDoc;

	/** 原IsRandomDungeon字段拓展|0=固定关卡，1=之前的随机生成规则关卡，2=遭遇战地图生成 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonGenerateMode;

	/** Dungeon宽度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonWidth;

	/** Dungeon高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonHeight;

	/** 用于配置将地图均分为多少个区域|填写A:B，A为列数，B为行数。例如填写4:3就把地图等分为4x3个区域。 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString DungeonZoneNum;

	/** Dungeon宽度外延 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonWidthExtension;

	/** Dungeon高度外延 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonHeightExtension;

	/** Dungeon格子的宽度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonGridWidth;

	/** Dungeon格子的高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonGridHeight;

	/** Dungeon偏移X */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonOffsetX;

	/** Dungeon偏移Y */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 DungeonOffsetY;
	//------------------------------------------------------------------------------
	/** 用于配置分隔线的路线|填写A#B:A#B:A#B|A#B:A#B:A#B，A是区域横坐标，B是区域纵坐标；A#B表示横坐标为A，纵坐标为B的区域，多个区域之间用:连接，构成一条线；多个线用|分隔 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArraySplitLine;

	/** 用于配置生成分隔线的数量|填写A:B，A为随机值下限，B为随机值上限 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString NumOfSplitLine;

	/** 用于配置通行线的数量|填写A:B，A为随机值下限，B为随机值上限，A和B的值最小为1，最大为3 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString NumOfPathLine;

	/** 地块海拔高度决定的额外高度增加量|A:B|C:D|E:F|...；A代表海拔为1的地块高度额外增加量下限，B代表海拔为1的地块高度额外增加量上限；C代表海拔为2的地块高度额外增加量下限，D代表海拔为2的地块高度额外增加量上限；依次类推。 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ElevationHeightIncrement;
	//------------------------------------------------------------------------------
	/** 在随机区域进行升高、降低的随机次数上下限 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonRegionHeightFixMinMax;

	/** 随机升高区域长宽上下限配置 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString	ArrayDungeonRegionUpperAreaSideMinMax;

	/** 随机降低区域长宽上下限配置 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString	ArrayDungeonRegionLowerAreaSideMinMax;

	/** 地图升高、降低区域生成的倾向性  9个区域的枚举 下边:1, 上边:2, 右边:4, 左边:8, 右下角:16, 右上角:32, 左上角:64, 左下角:128， 中间:256 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString HeightPrefer;

	/** 整个战斗地图的高度上下限 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString	HeightLimit;
	//------------------------------------------------------------------------------
	/** Dungeon区域 地貌风格 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	ECWDungeonRegionStyle Style;

	/** Dungeon区域地貌Id的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonRegionId;

	/** Dungeon区域地貌的随机次数的最小值最大值的数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayArrayDungeonRegionRandomMinMax;

	/** 生成区域地貌的宽随机上下限配置 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayArrayDungeonRegionWidthMinMax;

	/** 生成区域地貌的长随机上下限配置 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayArrayDungeonRegionHeightMinMax;
	//------------------------------------------------------------------------------
	/** Dungeon区域的是否有墙 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonRegionHasWall;

	/** Dungeon区域的墙的门随机最小值和最大值 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonRegionWallDoorCountMinMax;

	/** Dungeon区域的墙的门宽随机最小值和最大值 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonRegionWallDoorWidthMinMax;

	/** Dungeon区域的随机物件的生成信息 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayArrayDungeonItemGenerateInfo;

	/** Dungeon区域的外围装饰物的Tags */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	FString ArrayDungeonDecorateTagMinMax;

	/** Dungeon高地格子最小数量，大于此数字会偏移到地形上方 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 HighLandGridCountMin;

	/** Dungeon洼地格子最小数量，大于此数字会偏移到地形下方 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	int32 LowLandGridCountMin;

	/** Dungeon高地洼地格子 Z方向上的偏移量 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	float HighLandOrLowLandGridOffsetZ;
	//-------------------------------------------
	/** 1006换装是否进行测试(临时测试代码) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "DungeonDataStruct")
	bool bIsAvatarTest;
	//-------------------------------------------
	/** A阵营棋子出生点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	TArray<FString> ACampPawnStart;

	/** B阵营棋子出生点 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDataStruct")
	TArray<FString> BCampPawnStart;
	//-------------------------------------------
};