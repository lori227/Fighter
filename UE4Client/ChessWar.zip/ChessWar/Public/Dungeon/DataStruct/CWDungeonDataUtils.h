#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWDungeonDataUtils
{
public:

	/** 从字符串解析出逻辑区域宽高数量
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	逻辑区域宽高数量
	 */
	static std::vector<int32> GetArrayDungeonZoneNumFromString(const FString& ParamString);


	/** 从字符串解析出分隔线的数量
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	分隔线的数量
	 */
	static std::vector<int32> GetArrayNumOfSplitLineFromString(const FString& ParamString);


	/** 从字符串解析出通行线的数量
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	通行线的数量
	 */
	static std::vector<int32> GetArrayNumOfPathLineFromString(const FString& ParamString);


	/** 从字符串解析出地块海拔高度决定的额外高度增加量
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	地块海拔高度决定的额外高度增加量数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayElevationHeightIncrementFromString(const FString& ParamString);


	/** 从字符串解析出分隔线
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	分隔线
	 */
	static std::vector<std::vector<std::vector<int32>>> GetArrayArrayArraySplitLineFromString(const FString& ParamString);



	/** 从字符串解析出区域数组(3x2,2x3,5x5 ...)
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	区域数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionFromString(const FString& ParamString);


	/** 从字符串解析出区域地貌Id数组
	 * @param	const FString&	字符串
	 * @return  std::vector<int32>	区域地貌Id数组
	 */
	static std::vector<int32> GetArrayDungeonRegionIdFromString(const FString& ParamString);


	/** 从字符串解析出区域地貌的随机次数上下限
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 区域地貌的随机次数上下限
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionRandomMinMax(const FString& ParamString);


	/** 从字符串解析出区域地貌的宽随机上下限
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 区域地貌的宽随机上下限
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionWidthMinMax(const FString& ParamString);


	/** 从字符串解析出区域地貌的长随机上下限
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 区域地貌的长随机上下限
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionHeightMinMax(const FString& ParamString);


	/** 从字符串解析出区域是否有墙
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 区域是否有墙
	 */
	static std::vector<int32> GetArrayDungeonRegionHasWall(const FString& ParamString);


	/** 从字符串解析出墙的门随机最小值和最大值
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 墙的门随机最小值和最大值
	 */
	static std::vector<int32> GetArrayDungeonRegionWallDoorCountMinMax(const FString& ParamString);


	/** 从字符串解析出墙的门宽随机最小值和最大值
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 墙的门宽随机最小值和最大值
	 */
	static std::vector<int32> GetArrayDungeonRegionWallDoorWidthMinMax(const FString& ParamString);


	/** 从字符串解析出随机物件的生成信息
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	随机物件的生成信息
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonItemGenerateInfoFromString(const FString& ParamString);


	/** 从字符串解析出Dungeon区域的外围装饰物的Tag最小值和最大值
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> Dungeon区域的外围装饰物的Tag最小值和最大值
	 */
	static std::vector<int32> GetArrayDungeonDecorateTagMinMaxFromString(const FString& ParamString);


	/** 从字符串解析出棋子出生点数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	棋子出生点数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonPawnStartFromString(const FString& ParamString);


	/** 从字符串解析出在随机区域进行升高、降低的随机次数上下限数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	在随机区域进行升高、降低的随机次数上下限数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionHeightFixMinMaxFromString(const FString& ParamString);


	/** 从字符串解析出随机升高区域长宽上下限配置
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	随机升高区域长宽上下限配置
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionUpperAreaSideMinMaxFromString(const FString& ParamString);


	/** 从字符串解析出随机降低区域长宽上下限配置
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> >	随机降低区域长宽上下限配置
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonRegionLowerAreaSideMinMaxFromString(const FString& ParamString);


	/** 从字符串解析出地图升高、降低区域生成的倾向性
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 地图升高、降低区域生成的倾向性
	 */
	static std::vector<int32> GetArrayHeightPreferFromString(const FString& ParamString);


	/** 从字符串解析出整个战斗地图的高度上下限
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 整个战斗地图的高度上下限
	 */
	static std::vector<int32> GetArrayHeightLimitFromString(const FString& ParamString);
};