#pragma once
#include "Engine.h"
#include "CWDungeonDecorateDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWDungeonDecorateDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWDungeonDecorateDataStruct();
	virtual ~FCWDungeonDecorateDataStruct();
public:

	/** DungeonDecorateTag */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateDataStruct")
	FName DungeonDecorateTag;

	/** DungeonDecorate掉落时间 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateDataStruct")
	float FallTime;
};