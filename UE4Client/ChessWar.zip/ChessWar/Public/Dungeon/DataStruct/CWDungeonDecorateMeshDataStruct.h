#pragma once
#include "Engine.h"
#include "CWGameDefine.h"
#include "CWDungeonDecorateMeshDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWDungeonDecorateMeshDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWDungeonDecorateMeshDataStruct();
	virtual ~FCWDungeonDecorateMeshDataStruct();
public:

	/** 装饰物Id（唯一） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FString DecorateId;

	/** AssetId */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FString AssetId;

	/** 旋转 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FRotator Rotator;

	/** 偏移 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FVector Offset;

	/** 缩放 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FVector Scale;

	/** 所占格子范围 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	FString GridRange;

	/** 相邻朝向 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	ECWDecorateAdjacent Adjacent;

	/** 边缘8个区域的枚举 下边:1, 上边:2, 右边:4, 左边:8, 右下角:16, 右上角:32, 左上角:64, 左下角:128 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	uint8 Coord;

	/** 是否使用(方便调试) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonDecorateMeshDataStruct")
	bool bIsUsed;
};