#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class CWDungeonDecorateMeshDataUtils
{
public:

	/** 从字符串解析出装饰模型所占格子
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 装饰模型所占格子
	 */
	static std::vector<int32> GetArrayDecorateMeshGridRange(const FString& ParamString);
};