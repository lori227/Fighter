﻿
#pragma once

#include "Engine.h"
#include "CWDungeonItemDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWDungeonItemDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWDungeonItemDataStruct();
	virtual ~FCWDungeonItemDataStruct();

public:
	virtual FString ToString() const;

public:
	/**< 生命值(被攻击数) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Default)
	int32 HealthValue;

	/** 拥有元素信息Id(Cfg: CWObjElemInfoCfg) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Default)
	int32 OwnElemId;

	/** Dungeon物件名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	FString DungeonItemName;

	/** Dungeon物件描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	FString DungeonItemDescForDoc;

	/** Dungeon物件资源名 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	FString DungeonItemResName;

	/** 物件特效Id(Cfg: CWEffectDataTable) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 EffectId;

	/** 物件子对象资源Id */
	/*UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	FString ItemAssetId;*/

	/** 破碎信息(资源Id) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	FString BrokenAssetId;

	/** 物件类型(0:关卡物件 1:伤害物件 2:BUFF物件) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	uint8 ItemType;

	/** BUFF-ID */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	int32 BuffId;

	/** Dungeon物件是否障碍(影响寻路导航) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 IsObstacle;

	/** Dungeon物件是否可交互 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 CanInteractive;

	/** Dungeon物件是否可碰撞检测  1:不可碰撞检测， 0：可碰撞检测 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 NoCollision;

	/** Dungeon物件是否可攻击 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 CanAttack;

#pragma region		/** 物理系统数据 */

	/** 用于标识实体在被迫移动时能否产生横向力交互 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	uint8 bPhyBMovedForce : 1;

	/** 用于标识实体在被迫移动下坠时能否产生纵向力交互 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	uint8 bPhyBFallenForce : 1;

	/** 用于配置实体在接受横向力交互时受到的伤害 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyLateralFDMG;

	/** 用于配置实体在接受横向力交互时受到的被迫移动 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyLateralFMove;

	/** 用于配置实体在接受横向力交互时受到的BUFF */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyLateralFBuff;

	/** 用于配置实体在接受横向力交互时触发的事件 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyLateralFEvent;

	/** 用于配置实体在接受垂直力交互时受到的伤害 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyVerticalFDMG;

	/** 用于配置实体在接受垂直力交互时受到的被迫移动 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyVerticalFMove;

	/** 用于配置实体在接受垂直力交互时受到的BUFF */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyVerticalFBuff;

	/** 用于配置实体在接受垂直力交互时触发的事件 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PhysicsSystem")
	int32 PhyVerticalFEvent;

#pragma endregion

	/** 物件存在回合 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	uint8 LifespanRound;

	/** 物件存在时间 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	float LifespanTime;

	/** 点击音频Id */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	FString ClickAudioId;

#pragma region
	/** 所属物件层 0:是无效， 1--4是有效值, 对应枚举值ECWDungeonLogicLayer */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	ECWDungeonLogicLayer ObjLayer;

	/** 是否会阻止更低互斥优先级的其他物件生成 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	bool CreationExclusion;

	/** 生成时的互斥优先级 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "DungeonItemDataStruct")
	int32 ExclusionPriority;
#pragma endregion

	/** 障碍信息(占据M*N地图格子) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DungeonItemDataStruct")
	FString Obstacle;
};