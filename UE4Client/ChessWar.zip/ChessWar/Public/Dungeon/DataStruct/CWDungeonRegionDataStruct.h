﻿
#pragma once

#include "Engine.h"
#include "CWStructDefine.h"
#include "CWDungeonRegionDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWDungeonRegionDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWDungeonRegionDataStruct();
	virtual ~FCWDungeonRegionDataStruct();

public:

	/** Dungeon区域Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	int32 DungeonRegionId;

	/** Dungeon区域名称 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString DungeonRegionName;

	/** Dungeon区域描述（用于文档） */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString DungeonRegionDescForDoc;
	//-------------------------------------------------------------------------------------
	/** Dungeon区域 地貌风格 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	ECWDungeonRegionStyle Style;

	/** Dungeon区域 是否是基本地貌 0=不是基本地貌，1=平地基本地貌，2=低地基本地貌，3=高地基本地貌 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	int32 IsBasicRegion;

	/** Dungeon区域 地貌核心资源名(Read Cfg: CWDecorateAssetCfg) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayRegionCenterResId;

	/** Dungeon区域 地貌核心材质资源名(Read Cfg: CWDecorateAssetCfg) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayRegionCenterMaterialId;

	/** Dungeon区域 地貌边际资源名(Read Cfg: CWDecorateAssetCfg) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayRegionBorderResId;

	/** Dungeon区域 地貌可用高度范围 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayRegionHeightMinMax;

	/** Dungeon区域 地貌可通过性 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayRegionPassable;

	/** 海拔高度参数，用于地貌之间的过渡|整数，同一个风格内为从1开始的递增序列 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	int32 Elevation;

	/** 区域适配，用于判断该地貌能够适配什么区域|0=高速区域，1=慢速区域，2=危险区域 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	int32 ZoneType;
	//-------------------------------------------------------------------------------------
	/** Dungeon区域行动力标准消耗(对应兵种(职业?)) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayStandardConsumeMove;

	/** Dungeon区域行动力增量消耗(对应兵种(职业?)) */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayIncrementConsumeMove;

	/** 地形防御系数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	float TerrainDefinceFactor;

	/** 生成的物件Id数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayDungeonItem;

	/** 生成的物件的几率数组 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "DungeonRegionDataStruct")
	FString ArrayDungeonItemPobability;

};
