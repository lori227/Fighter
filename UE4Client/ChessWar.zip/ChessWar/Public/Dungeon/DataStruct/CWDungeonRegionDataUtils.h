#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWDungeonRegionDataUtils
{
public:

	/** 从字符串解析出地图格子的核心资源数组
	 * @param	const FString&	字符串
	 * @return  std::vector<FString> 地图格子的核心资源数组
	 */
	static std::vector<FString> GetArrayDungeonRegionCenterResIdFromString(const FString& ParamString);


	/** 从字符串解析出地图格子的边际资源数组
	 * @param	const FString&	字符串
	 * @return  std::vector<FString> 地图格子的边际资源数组
	 */
	static std::vector<FString> GetArrayDungeonRegionBorderResIdFromString(const FString& ParamString);


	/** 从字符串解析出地貌区域的可用高度范围
	 * @param	const FString&	字符串
	 * @return  std::vector<int32> 地貌区域的可用高度范围
	 */
	static std::vector<int32> GetArrayRegionHeightMinMaxFromString(const FString& ParamString);


	/** 从字符串解析出地貌区域的可通过性
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> > 地貌区域的可通过性
	 */
	static std::vector<std::vector<int32> > GetArrayArrayRegionPassableFromString(const FString& ParamString);


	/** 从字符串解析出行动力标准消耗数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> > 行动力标准消耗数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayStandardConsumeMoveFromString(const FString& ParamString);


	/** 从字符串解析出行动力增量消耗数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> > 行动力增量消耗数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayIncrementConsumeMoveFromString(const FString& ParamString);


	/** 从字符串解析出地图格子的每个物件层生成的几率
	 * @param	const FString&	字符串
	 * @return  std::vector<float> 每个物件层生成的几率数组
	 */
	static std::vector<float> GetArrayDungeonItemPobabilityFromString(const FString& ParamString);


	/** 从字符串解析出区域物件层物件数组
	 * @param	const FString&	字符串
	 * @return  std::vector<std::vector<int32> > 区域物件层物件数组
	 */
	static std::vector<std::vector<int32> > GetArrayArrayDungeonItemFromString(const FString& ParamString);
};