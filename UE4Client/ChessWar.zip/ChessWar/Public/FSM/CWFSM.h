#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWFSMTranstionKey.h"
#include <unordered_map>
#include <list>
#include "CWFSM.generated.h"


class FCWFSMState;
class FCWFSMEvent;
class FCWFSMTranstion;
class UCWNetMessage;

/**
 * @brief 有限状态机 \n
 * 
 */
UCLASS()
class UCWFSM : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	virtual void BeginDestroy() override;

public:

	/** 析构函数
	 * @param	无
	 * @return	无
	 */
	virtual ~UCWFSM();

	/** 添加状态
	 * @param	FCWFSMState*	继承于FCWFSMState的派生类指针
	 * @return	bool	true:添加成功，false:添加失败
	 */
	bool AddState(FCWFSMState* ParamFSMState);


	/** 添加状态转移
	 * @param	FCWFSMTranstion*	状态转移指针
	 * @return	bool	true:添加成功，false:添加失败
	 */
	bool AddTranstion(FCWFSMTranstion* ParamTranstion);


	/** 状态事件触发
	 * @param	const FCWFSMEvent*	状态事件
	 * @return	bool	true:状态事件处理, false:状态事件处理失败
	 */
	virtual bool DoEvent(const FCWFSMEvent* ParamEvent);


	/** 状态事件触发
	 * @param	const UCWNetMessage*	网络事件
	 * @return	bool	true:状态网络事件处理, false:状态网络事件处理失败
	 */
	bool DoNetMessage(const UCWNetMessage* ParamNetMessage);


	/** 帧处理
	 * @param	float	帧间隔
	 * @return	bool	true:状态事件处理, false:状态事件处理失败
	 */
	virtual void Tick(float DeltaTime);


	/** 状态开始运作
	 * @param	int		状态开始的状态
	 * @return	bool	true:启动成功, false:启动失败
	 */
	virtual bool Startup(int StateId);


	/** 获得当前状态
	 * @param	无
	 * @return	FCWFSMState*	当前状态
	 */
	FCWFSMState* GetCurrentState();


	/** 获得当前状态Id
	 * @param	无
	 * @return	int	当前状态Id
	 */
	int GetCurrentStateId() const;


	/** 销毁所有状态
	 * @param	无
	 * @return	无
	 */
	void DestroyAllState();


	/** 销毁所有状态转换
	 * @param	无
	 * @return	无
	 */
	void DestroyAllTranstion();

protected:

	typedef std::unordered_map<int, FCWFSMState*> StateMap;
	typedef std::unordered_map<FCWFSMTranstionKey, FCWFSMTranstion*, FCWFSMTranstionKeyHashFunc, FCWFSMTranstionKeyEqualKey> TranstionMap;
	typedef std::list<FCWFSMState*> StateStack;

	/**< 状态容器 */
	StateMap MapStates;

	/**< 状态转移容器 */
	TranstionMap MapTranstions;

	/**< 状态事件容器 */
	StateStack StackStates;
};