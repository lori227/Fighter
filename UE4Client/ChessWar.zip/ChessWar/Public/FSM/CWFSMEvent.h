#pragma once

#include "CoreMinimal.h"

#include "CWGameDefine.h"


/**
 * @brief 状态事件 \n
 *
 */
class FCWFSMEvent
{
public:

	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	FCWFSMEvent();


	/** 构造函数
	 * @param	int	事件Id
	 * @param	int	目标状态Id
	 * @param	EFSMStackOperation	栈操作
	 * @return	无
	 */
	FCWFSMEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp);


	/** 虚构造函数
	 * @param	无
	 * @return	无
	 */
	virtual ~FCWFSMEvent();

	virtual FString ToString() const;

public:

	/**< 事件Id */
	int32 EventId;

	/**< 跳转状态Id */
	int32 ToStateId;

	/**< 栈操作 */
	ECWFSMStackOp StackOp;
};
