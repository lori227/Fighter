#pragma once

#include "CoreMinimal.h"
#include "CWFuncLib.h"
#include "CWGameDefine.h"
#include "CWFSMState.h"

class UCWFSM;
class FCWFSMEvent;
class UCWNetMessage;

/**
 * @brief 有限状态机的状态基类 \n
 *
 */
class FCWFSMState
{
public:

	/** 构造函数
	 * @param	UCWFSM*	状态机
	 * @param	int	状态Id
	 * @return	无
	 */
	FCWFSMState(UCWFSM* ParamParent, int ParamStateId);


	/** 析构函数
	 * @param	无
	 * @return	无
	 */
	virtual ~FCWFSMState();


	/** 设置所属状态机
	 * @param	UCWFSM*	所属状态机
	 * @return	无
	 */
	virtual void SetParent(UCWFSM* ParamParent);


	/** 是否这个事件能发生状态转移
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual bool CanTranstion(const FCWFSMEvent* Params);


	/** 进入状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnEnter(const FCWFSMEvent* Params);


	/** 退出状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnExit(const FCWFSMEvent* Params);


	/** 处理事件
	 * @param	const FCWFSMEvent&	事件
	 * @return	无
	 */
	virtual void DoEvent(const FCWFSMEvent* Params);


	/** 处理网络消息
	 * @param	const UCWNetMessage* 网络消息
	 * @return	无
	 */
	virtual void DoNetMessage(const UCWNetMessage* ParamNetMessage);


	/** 帧处理
	 * @param	float	帧间隔
	 * @return	无
	 */
	virtual void Tick(float DeltaTime);


	/** 状态处理
	 * @param	float	帧间隔
	 * @return	无
	 */
	virtual void StateProcess(float DeltaTime);


	/** 获得状态Id
	 * @param	无
	 * @return	int	状态Id
	 */
	int GetStateId() const;

protected:

	/**< 状态Id */
	int32 StateId;

	/**< 所属有限状态机 */
	UCWFSM* Parent;

};
