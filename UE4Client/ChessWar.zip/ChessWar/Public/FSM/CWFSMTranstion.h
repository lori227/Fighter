#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
//#include "CWFSMTranstion.generated.h"


/**
 * @brief 有限状态机的状态转移 \n
 *
 */
class FCWFSMTranstion
{
public:

	/** 构造函数
	 * @param	int	起始状态Id
	 * @param	int	目标状态Id
	 * @return	无
	 */
	FCWFSMTranstion(int ParamFromStateId, int ParamToStateId);


	/** 析构函数
	 * @param	无
	 * @return	无
	 */
	virtual ~FCWFSMTranstion();


	/** 获得起始状态Id
	 * @param	无
	 * @return	int	起始状态Id
	 */
	int GetFromStateId() const;


	/** 获得目标状态Id
	 * @param	无
	 * @return	int	目标状态Id
	 */
	int GetToStateId() const;

protected:

	/**< 起始状态Id */
	int	FromStateId;

	/**< 目标状态Id */
	int	ToStateId;
};