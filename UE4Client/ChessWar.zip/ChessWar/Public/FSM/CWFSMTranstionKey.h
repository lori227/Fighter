#pragma once

#include "Global/CWGameDefine.h"


/**
 * @brief ״̬ת��Key \n
 *
 */
struct FCWFSMTranstionKey
{
	int FromStateId;
	int ToStateId;

	FCWFSMTranstionKey()
	{
		FromStateId = -1;
		ToStateId = -1;
	}

	FCWFSMTranstionKey(int ParamFromStateId, int ParamToStateId)
	{
		FromStateId = ParamFromStateId;
		ToStateId = ParamToStateId;
	}

	friend bool operator < (const FCWFSMTranstionKey &k1, const FCWFSMTranstionKey &k2);
};


inline bool operator < (const FCWFSMTranstionKey& k1, const FCWFSMTranstionKey& k2)
{
	return k1.FromStateId < k2.FromStateId || (k1.FromStateId == k2.FromStateId && k1.ToStateId < k2.ToStateId);
}


struct FCWFSMTranstionKeyHashFunc
{
	std::size_t operator()(const FCWFSMTranstionKey &key) const
	{
		//return std::hash<int>()(key.FromStateId) * 10000 + std::hash<int>()(key.ToStateId);
		return HashCombine(key.FromStateId, key.ToStateId);
	};
};


struct FCWFSMTranstionKeyEqualKey
{
	bool operator () (const FCWFSMTranstionKey &lhs, const FCWFSMTranstionKey &rhs) const
	{
		return lhs.FromStateId == rhs.FromStateId && lhs.ToStateId == rhs.ToStateId;
	}
};

