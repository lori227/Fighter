﻿
#pragma once

#include "CWTriggerVolume.h"
#include "CWCameraBlockVolume.generated.h"

/**
 * @brief	摄像机阻挡体积
 */
UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API ACWCameraBlockVolume : public ACWTriggerVolume
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWCameraBlockVolume();

};
