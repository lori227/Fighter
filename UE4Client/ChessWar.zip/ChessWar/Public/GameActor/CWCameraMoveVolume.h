﻿
#pragma once

#include "CWTriggerVolume.h"
#include "CWCameraMoveVolume.generated.h"

/**
 * @brief	摄像机移动体积
 */
UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API ACWCameraMoveVolume : public ACWTriggerVolume
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWCameraMoveVolume();

};
