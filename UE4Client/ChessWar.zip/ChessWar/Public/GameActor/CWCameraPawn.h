﻿
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "CWCameraPawn.generated.h"


UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API ACWCameraPawn : public APawn
{
	GENERATED_BODY()

public:
	ACWCameraPawn();

protected:
	virtual void BeginPlay() override;

public:
	// 相机拉近
	virtual void ZoomIn();
	// 相机拉远
	virtual void ZoomOut();

	// 切换下一个视角
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
	/*virtual*/ bool SwitchNextViewAngle();
	virtual bool SwitchNextViewAngle_Implementation();

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* Camera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UStaticMeshComponent* OriginPos;

	//平移速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float CameraMovementDelta = 500.0f;

	//旋转速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float CameraYawDelta = 3.0f;

	//平移拉近速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float CameraZoomDelta = 25.0f;

	//相机臂最短长度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float CameraZoomLengthMin = 200.0f;

	//相机臂最大长度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float CameraZoomLengthMax = 1000.0f;

};
