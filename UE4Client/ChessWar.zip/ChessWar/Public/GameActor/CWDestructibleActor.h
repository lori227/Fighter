
#pragma once

#include "Public/DestructibleActor.h"
#include "CWDestructibleActor.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWDestructibleActor : public ADestructibleActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWDestructibleActor();

	//~ Begin AActor Interface.
#if WITH_EDITOR
	virtual bool GetReferencedContentObjects(TArray<UObject*>& Objects) const override;
	//virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif // WITH_EDITOR
	//~ End AActor Interface.

protected:
	virtual void BeginPlay() override;

public:
	/** �������п��������� */
	UFUNCTION(BlueprintCallable, Category = Default)
	virtual void SimpleAllDestructible();

	/** ����ָ������������(Root) */
	UFUNCTION(BlueprintCallable, Category = Default)
	virtual void SimpleDestructible();

	/** ����ָ������������ */
	UFUNCTION(BlueprintCallable, Category = Default)
	static void SimpleDestructibleMesh(UDestructibleComponent* InDestructibleComp);

	/** ���ÿ��������� */
	UFUNCTION(BlueprintCallable, Category = Default)
	static void SetDestructibleMesh(UDestructibleComponent* InDestructibleComp, const FString& InAssetId);

	/** Destruct Mesh */
	UFUNCTION(BlueprintCallable, Category = Default)
	static void ApplyDamage(UDestructibleComponent* InDestructibleComp, float DamageAmount);

protected:
	UFUNCTION(BlueprintCallable, Category = Default)
	static void ApplyDamageDestructible(UDestructibleComponent* InDestructibleComp,
			float DamageAmount, const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength);

};
