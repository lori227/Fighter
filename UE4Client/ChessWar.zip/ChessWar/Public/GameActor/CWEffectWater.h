
#pragma once

#include "GameFramework/Actor.h"
#include "CWEffectWater.generated.h"

class UMaterialInterface;
class UStaticMeshComponent;
class UMaterialInstanceDynamic;


UCLASS(BlueprintType, Blueprintable)
class ACWEffectWater : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWEffectWater() {}

	virtual void BeginPlay() override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

public:
	virtual void SetWaterWaterDepth(const float InHeightValue);

protected:
	UFUNCTION(BlueprintCallable)
	virtual void InitialWaterCreation();

	UFUNCTION(BlueprintCallable)
	virtual void UpdateWaterMaterialData();

	UFUNCTION(BlueprintNativeEvent)
	void SetWaterShoreDepth(const float InShoreDepth);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UStaticMeshComponent* WaterSurface;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UMaterialInstanceDynamic* WaterMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* OceanMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float WaterScaleX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float WaterScaleY;

};
