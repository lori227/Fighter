﻿
#pragma once

#include "GameFramework/Actor.h"
#include "CWEffectWaterImpl.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWEffectWaterImpl : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWEffectWaterImpl();

	virtual void Destroyed() override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

public:
	/** 设置水面深度 */
	UFUNCTION(BlueprintCallable)
	virtual bool SetWaterDepth(const float InHeightValue);

	/** 设置水面大小 */
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
	/*virtual */bool SetWaterSize(const FVector2D& InSize);

public:
	//~ 地块信息
	virtual int32 SetTileNumber(const int32 InNumber);
	virtual int32 GetTileNumber();

protected:

	/** 地块编号 */
	UPROPERTY(VisibleAnywhere)
	int32 TileNumber;

};
