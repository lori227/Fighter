
#pragma once

#include "Particles/Emitter.h"
#include "CWEmitterBase.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWEmitterBase : public AEmitter
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWEmitterBase() {}

};
