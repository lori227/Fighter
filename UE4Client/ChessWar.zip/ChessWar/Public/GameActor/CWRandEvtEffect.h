﻿
#pragma once

#include "CWRandomEvtData.h"
#include "GameFramework/Actor.h"
#include "CWRandEvtEffect.generated.h"


UCLASS()
class ACWRandEvtEffect : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWRandEvtEffect();

public:
	virtual bool InitInServer(const FCWRandomEvtGameData& InRandomEvtData);

protected:
	/** 回调: 触发游戏伤害事件 */
	UFUNCTION(BlueprintCallable)
	virtual void OnToggleDamageEvent(int32 InPhase = 0);

public:
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnToggleDamageEvent, int32)
	//UPROPERTY(BlueprintAssignable, Category = "Event")
	FOnToggleDamageEvent OnToggleDamage;

protected:
	uint8 bToggleDamage : 1;

};
