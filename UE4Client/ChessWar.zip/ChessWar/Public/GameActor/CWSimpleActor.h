﻿
#pragma once

#include "GameFramework/Actor.h"
#include "CWSimpleActor.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWSimpleActor : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWSimpleActor();

	virtual void Destroyed() override;

public:
	// Flag
	virtual void SetSimpleFlag(const FString& InFlag);
	virtual FString GetSimpleFlag();

	/** 开启位置更新 */
	UFUNCTION(BlueprintCallable)
	virtual bool StartUpdateLoctionZ(const float InBeginZ, const float InEndZ, const float InSpeed = 20.f);

	UFUNCTION()
	virtual bool OnUpdateLoctionZ(float DeltaTime);

	/** 设置对象位置Z */
	UFUNCTION(BlueprintCallable)
	virtual void SetActorLocationZ(const float InZValue);
	virtual float GetActorLocationZ();

protected:
	/** Flag */
	UPROPERTY(VisibleAnywhere)
	FString SimpleFlag;

	/** Handle for OnTick. */
	FDelegateHandle TickDelegateHandle;

	float TargetLocZSpeed;
	FVector2D TargetLocZ;

};
