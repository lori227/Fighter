﻿
#pragma once

#include "Animation/SkeletalMeshActor.h"
#include "CWSkeletalMeshActor.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWSkeletalMeshActor : public ASkeletalMeshActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWSkeletalMeshActor();
	virtual void BeginPlay() override;
	virtual void Destroyed() override;

public:
	UFUNCTION(BlueprintCallable)
	bool PlayAnimSequence(const FString& InSMId, const FString& InAnimInstClassId, const FString& InAnimId);

protected:
	FVector GetOverrideRelativePoint(const FString& InSMKey);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	TMap<FString, FVector> RelativePointMap;

	FVector InitRelativePoint;
	FString CurSMAssetId;

};
