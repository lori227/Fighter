﻿
#pragma once

#include "GameFramework/Actor.h"
#include "Components/SplineMeshComponent.h"
#include "CWSplineActor.generated.h"

class USplineComponent;
class USplineMeshComponent;


UCLASS(BlueprintType, Blueprintable)
class ACWSplineActor : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWSplineActor();
	virtual void Destroyed() override;

public:
	/** 设置生成点组 */
	UFUNCTION(BlueprintCallable, Category = Default)
	USplineComponent* SetSplineWorldPoints(const int32 InSplineIndex, 
		const TArray<FVector>& InPoints, const ECWSplineMeshType InMeshType = ECWSplineMeshType::HitMark, const bool bSetTangent = false);

	UFUNCTION(BlueprintCallable, Category = Default)
	USplineComponent* SetSplineWorldPointsImpl(const int32 InSplineIndex,
			const TArray<FVector>& InPoints, const ECWSplineMeshType InMeshType = ECWSplineMeshType::HitMark);

	/** 设置模型缩放 */
	UFUNCTION(BlueprintCallable, Category = Default)
	void SetSplineMeshScale(const FVector2D& InStartScale, const FVector2D& InEndScale);

	/** 设置模型位置/切线 */
	UFUNCTION(BlueprintCallable, Category = Default)
	void SetSplineMeshPosTangent(
		const FVector& InStartPosition, const FVector& InStartTangent,
		const FVector& InEndPosition, const FVector& InEndTangent);

	/** Clear */
	void ClearSplinePoints(const int32 InSplineIndex);
	void DestroySplineComponent(const int32 InSplineIndex);
	void DestroyAllComponent();

	/** Create/Getter */
	USplineComponent* CreateSplineComponent(const int32 InSplineIndex);
	USplineComponent* GetSplineComponent(const int32 InSplineIndex);
	USplineComponent* TryGetSplineComponent(const int32 InSplineIndex);
	USplineMeshComponent* CreateSplineMeshComponent(USplineComponent* InSplineComponent, UStaticMesh* InStaticMesh);

	/**  */
	static FVector CheckNeedOffserXY(const FVector& InVector);
	static bool IsEqual2(ESplineMeshAxis::Type InType, const FVector& InPointL, const FVector& InPointR);
	static bool IsEqual3(ESplineMeshAxis::Type InType, const FVector& InPrePoint, const FVector& InCurPoint, const FVector& InNextPoint);
	static bool IsRightAngle(const FVector& InPrePoint, const FVector& InCurPoint, const FVector& InNextPoint);

protected:
	void UpdateSplineCompMesh(USplineComponent* InSplineComponent, const int32 InMeshType = 0);

#pragma region /** Particle */
public:
	//UFUNCTION(BlueprintCallable, Category = Default)
	void SetParticleTargetLocations(const TArray<FVector>& InTargetPoints, const uint8 InType = 0);
	void HideAllParticleComps();
	void DestroyAllParticleComps();

protected:
	/** Update Target Location(Two Point) */
	UFUNCTION(BlueprintNativeEvent, Category = Default)
	bool UpdateParticleTargetLocation(UParticleSystemComponent* InParticleComp, const FVector& InTargteLocation);
	//virtual bool UpdateParticleTargetLocation_Implementation(UParticleSystemComponent* InParticleComp, const FVector& InTargteLocation);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	TArray<UParticleSystemComponent*> ParticleComps;
#pragma endregion

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	TArray<USplineComponent*> SplineComps;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	TArray<USplineMeshComponent*> SplineMeshComps;

	/** SplineComp Scale */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector ArriveTangent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector LeaveTangent;

	/** SplineMesh Scale */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector2D NewStartScale;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector2D NewEndScale;

	/** SplineMesh Pos/Tangent */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector NewStartPosition;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector NewStartTangent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector NewEndPosition;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FVector NewEndTangent;

};
