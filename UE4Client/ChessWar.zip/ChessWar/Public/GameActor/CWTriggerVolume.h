﻿
#pragma once

#include "GameFramework/Actor.h"
//#include "Engine/TriggerBox.h"
#include "CWTriggerVolume.generated.h"

class UBoxComponent;
class UBillboardComponent;

/**
 * @brief	触发体积
 */
UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API ACWTriggerVolume : public AActor/*ATriggerBox*/
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWTriggerVolume();

	virtual void BeginPlay() override;

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	/** Setter box size  */
	virtual void SetBoxExtent(FVector InBoxExtent, bool bUpdateOverlaps = true);

public:
	/** Returns CollisionComponent subobject **/
	UBoxComponent* GetBoxComponent() const { return BoxComp; }

#if WITH_EDITORONLY_DATA
	/** Returns SpriteComponent subobject **/
	UBillboardComponent* GetSpriteComponent() const { return SpriteComponent; }
#endif

protected:
	UFUNCTION()
	virtual void OnRep_BoxExtent();

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UBoxComponent* BoxComp;

#if WITH_EDITORONLY_DATA
	/** Billboard used to see the trigger in the editor */
	UPROPERTY()
	UBillboardComponent* SpriteComponent;
#endif

	/** The extents (radii dimensions) of the box **/
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_BoxExtent)
	FVector BoxExtent;

};
