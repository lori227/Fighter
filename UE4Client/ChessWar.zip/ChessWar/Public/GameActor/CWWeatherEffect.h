
#pragma once

#include "CWEmitterBase.h"
#include "CWWeatherEffect.generated.h"


UCLASS(BlueprintType, Blueprintable)
class ACWWeatherEffect : public ACWEmitterBase
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWWeatherEffect();

	virtual void BeginPlay() override;

};
