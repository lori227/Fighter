﻿/**
 *	Author:		LiuShuang
 *	Date:		2018.09.12
 */
#pragma once

#include "Core.h"
#include "StringConv.h"

// Debug
#define CWG_ASSERT(exp) verify((exp))

DEFINE_LOG_CATEGORY_STATIC(CWGLog, Log, All);
#define CWG_LOG(msg, ...)	  UE_LOG(CWGLog, Log, TEXT(msg), ##__VA_ARGS__)
#define CWG_INFO(msg, ...)    UE_LOG(CWGLog, Display, TEXT(msg), ##__VA_ARGS__)
#define CWG_WARNING(msg, ...) UE_LOG(CWGLog, Warning, TEXT(msg), ##__VA_ARGS__)
#define CWG_ERROR(msg, ...)   UE_LOG(CWGLog, Error, TEXT(msg), ##__VA_ARGS__)
#define CWG_FATAL(msg, ...)   UE_LOG(CWGLog, Fatal, TEXT(msg), ##__VA_ARGS__)

// Type conversion
#define STDSTRING_TO_FSTRING(StringValue)	StringValue.c_str()

#define BOOL_TO_FSTRING(BoolValue)			(BoolValue ? FString("true") : FString("false"))
#define TCHAR_TO_FSTRING(TCharValue)		TCHAR_TO_UTF8(TCharValue)
#define FNAME_TO_FSTRING(FNameValue)		FNameValue.ToString()
#define FTEXT_TO_FSTRING(FTextValue)		FTextValue.ToString()
#define FLOAT_TO_FSTRING(FloatValue)		FString::SanitizeFloat(FloatValue)
#define FSTRING_TO_FNAME(FStringValue)		FName(*FStringValue)
#define FSTRING_TO_INT(FStringValue)		FCString::Atoi(*FStringValue)
#define FSTRING_TO_FLOAT(FStringValue)		FCString::Atof(*FStringValue)
#define FSTRING_TO_FTEXT(FStringValue)		FText::FromString(FStringValue)
#define FSTRING_TO_TCHAR(FStringValue)		*FStringValue//FStringValue.GetCharArray().GetData()
#define FNAME_TO_FTEXT(FNameValue)			FText::FromName(FNameValue)
#define FNAME_TO_TCHAR(FNameValue)			FSTRING_TO_TCHAR(FNAME_TO_FSTRING(FNameValue))
#define FNAME_TO_INT(FNameValue)			FSTRING_TO_INT(FNAME_TO_FSTRING(FNameValue))
#define INT_TO_FSTRING(IntValue)			FString::FromInt(IntValue)
#define INT_TO_FNAME(IntValue)				FSTRING_TO_FNAME(INT_TO_FSTRING(IntValue))
#define INT_TO_FTEXT(IntValue)				FText::FromString(FString::FromInt(IntValue))

// ref from "StringConv.h"
// TCHAR_TO_ANSI(str)
// ANSI_TO_TCHAR(str)
// TCHAR_TO_UTF8(str)
// UTF8_TO_TCHAR(str)

// Name
#define CWG_NAME(UObj)	((UObj) ? UObj->GetName() : FString("None"))

// Timer -- Actor
#define ACreateTimer(Handle, Obj, Method, Rate, bLoop)\
	GetWorldTimerManager().SetTimer(Handle, Obj, Method, Rate * GetActorTimeDilation(), bLoop)

#define ACreateOnceTimer(Obj, Method, Delay)\
{\
	if (Delay <= 0.00001f) {\
		GetWorldTimerManager().SetTimerForNextTick(Obj, Method);\
	}else {\
		FTimerHandle TempHandle; \
		GetWorldTimerManager().SetTimer(TempHandle, Obj, Method, Delay * GetActorTimeDilation(), false); \
	}\
}

#define ACreateTimerNextTick(Obj, Method)\
	GetWorldTimerManager().SetTimerForNextTick(Obj, Method)

#define IMPL_INSTANCE_MANAGER(MGR_TYPE) \
	public: \
	class MGR_TYPE* Get##MGR_TYPE() \
	{ \
		if(nullptr == MGR_TYPE##_INST) \
		{ \
			MGR_TYPE##_INST = NewObject<MGR_TYPE>(); \
		} \
	} \
	protected: \
	UPROPERTY() \
	class MGR_TYPE* MGR_TYPE##_INST; \
		
