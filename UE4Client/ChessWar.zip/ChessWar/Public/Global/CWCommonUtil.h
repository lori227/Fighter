#pragma once

#include "EngineMinimal.h"

#define CSV_TABLE_PATH (TEXT("/Game/Configs/%s.%s"))

DECLARE_LOG_CATEGORY_CLASS(LogCWCommonUtil, Verbose, All);


class FCWCommonUtil
{
public:

	/** 根据枚举值取得对应的字符串描述
	 * @param	const FString&	枚举名
	 * @param	const T	枚举值
	 * @return  FString	枚举值的对应的字符串
	 */
	template<typename T>
	static FString EnumToString(const FString& enumName, const T value)
	{
		const UEnum* pEnum = FindObject<UEnum>(ANY_PACKAGE, *enumName, true);
		if (pEnum != nullptr)
		{
			return pEnum->GetNameStringByIndex(static_cast<uint8>(value));
		}
		return TEXT("INVALID");
	}


	/** 根据枚举值的字符串,找到对应的值
	 * @param	const FString&	枚举名
	 * @param	const FString&	枚举值
	 * @return  T	枚举值
	 */
	template<typename T>
	static T StringToEnum(const FString& enumName, const FString& value)
	{
		const UEnum* pEnum = FindObject<UEnum>(ANY_PACKAGE, *enumName, true);
		if (pEnum != nullptr)
		{
			//return (T)pEnum->FindEnumIndex(FName(*value));
			return (T)pEnum->GetIndexByName(FName(*value), EGetByNameFlags::ErrorIfNotFound);
		}
		return T(0);
	}


	/**  读取表格
	 * @param	const FString&	表名
	 * @param	int32	key
	 * @return  T*	具体内容
	 */
	template<typename T>
	static T* FindCSVRow(const FString& table, int32 key)
	{
		const FString strTable = FString::Printf(CSV_TABLE_PATH, *table, *table);
		const FString strKey = FString::Printf(TEXT("%d"), key);
		UDataTable* pTable = FindObject<UDataTable>(nullptr, *strTable);
		if (!pTable)
		{
			pTable = LoadObject<UDataTable>(nullptr, *strTable);
		}
		if (!pTable)
		{
			UE_LOG(LogCWCommonUtil, Error, TEXT("csv missiong ? %s"), *table);
			return nullptr;
		}
		return pTable->FindRow<T>(FName(*strKey), TEXT("temp csv-data"));
	}

	/**  读取表格
	 * @param	const FString&	表名
	 * @param	int32	key
	 * @return  T*	具体内容
	 */
	template<typename T, typename Predicate>
	static T* FindCSVRow(const FString& table, int32 key, Predicate Pred)
	{
		const FString strTable = FString::Printf(CSV_TABLE_PATH, *table, *table);
		const FString strKey = FString::Printf(TEXT("%d"), key);
		UDataTable* pTable = FindObject<UDataTable>(nullptr, *strTable);
		if (!pTable)
		{
			pTable = LoadObject<UDataTable>(nullptr, *strTable);
		}

		if (!pTable)
		{
			UE_LOG(LogCWCommonUtil, Error, TEXT("csv missiong ? %s"), *table);
			return nullptr;
		}

		//遍历
		TArray<T*> OutRowArray;
		pTable->GetAllRows(TEXT("temp csv-data"), OutRowArray);

		for (auto* t : OutRowArray)
		{
			if (Pred(t))
			{
				return t;
			}
		}
		return nullptr;
	}

	template<typename T>
	static int32 GetCSVRowCount(const FString& table)
	{
		const FString strTable = FString::Printf(CSV_TABLE_PATH, *table, *table);
		UDataTable* pTable = FindObject<UDataTable>(nullptr, *strTable);
		if (!pTable)
		{
			pTable = LoadObject<UDataTable>(nullptr, *strTable);
		}

		if (!pTable)
		{
			UE_LOG(LogCWCommonUtil, Error, TEXT("csv missiong ? %s"), *table);
			return 0;
		}

		TArray<T*> OutRowArray;
		pTable->GetAllRows(TEXT("temp csv-data"), OutRowArray);
		return OutRowArray.Num();
	}


	// 获取特定类型的'默认对象'
	template<typename T>
	static T* GetClassDefaultObject(UClass* InClass);

	static void MoveToLocationBySpeed(AActor * actor, FVector toLocation, float speed, float delta)
	{
		if (nullptr == actor) return;

		FVector curLocation = actor->GetActorLocation();
		FVector moveOffset = (toLocation - curLocation).GetSafeNormal() * speed * delta;
		FVector newLocation = curLocation + moveOffset;
		actor->SetActorLocation(newLocation);
	}
};