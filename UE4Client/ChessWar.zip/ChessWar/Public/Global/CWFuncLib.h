﻿
#pragma once

#include "Engine.h"
#include "CWGameDefine.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CWFuncLib.generated.h"

#define NETMODE_TO_STRING(NetMode) UCWFuncLib::ToString(NetMode)

class UTextRenderComponent;

/**
 *
 */
UCLASS(Abstract)
class CHESSWAR_API UCWFuncLib : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

public:
	/** 控制台命令 */
	UFUNCTION(BlueprintCallable, Category = "CWG|World", meta = (WorldContext = "InWorldContext"))
	static void CWGConsoleCmd(UObject* InWorldContext, const FString& Cmd, APlayerController* SpecificPlayer = nullptr);

	UFUNCTION(BlueprintCallable, Category = "CWG|World", meta = (WorldContext = "InWorldContext"))
	static void CWGQuitGame(TEnumAsByte<EQuitPreference::Type> QuitPreference, UObject* InWorldContext, APlayerController* SpecificPlayer = nullptr);
	
	/** Client连接UE服务器 */
	UFUNCTION(BlueprintCallable, Category = "CWG|World", meta = (WorldContext = "InWorldContext"))
	static void CWGConnectServer(UObject* InWorldContext, const FString& InIp, int32 InPort, int32 InPid, APlayerController* SpecificPlayer = nullptr);
	
	/** Client切换关卡 */
	UFUNCTION(BlueprintCallable, Category = "CWG|World", meta = (WorldContext = "InWorldContext", AdvancedDisplay = "2"))
	static void CWGOpenLevel(UObject* InWorldContext, const FString& LevelName, bool bAbsolute = true, FString Options = FString(TEXT("")));
	
	/** UE服务器地图传送 */
	UFUNCTION(BlueprintCallable, Category = "CWG|World", meta = (WorldContext = "InWorldContext"))
	static void CWGServerTravel(UObject* InWorldContext, const FString& InURL, bool bAbsolute = true);

	UFUNCTION(BlueprintCallable, Category = "CWG|Game", meta = (WorldContext = "InWorldContext"))
	static void CWGResetServer(UObject* InWorldContext);


	static void CWGConnectServerEx(UObject* InWorldContext, const FString& InIp, int32 InPort, const FString& InNetPlayerId, APlayerController* SpecificPlayer = nullptr);

public:
	/** Returns the game instance object  */
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContext"))
	static class UGameInstance* GetGameInst(const UObject* InWorldContext);

	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContext"))
	static class UCWGameInstance* GetCWGameInst(const UObject* InWorldContext);

	// Game
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InUObject"))
	static bool IsValidObjectImpl(const UObject* InUObject);

	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InAActor"))
	static bool IsValidActorImpl(const AActor* InAActor);

	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContext"))
	static bool IsGameWorld(const UObject* InWorldContext);

	UFUNCTION(BlueprintPure, Category = "CWG|Game")
	static bool IsRunningDedicatedServer();

	UFUNCTION(BlueprintPure, Category = "CWG|Game")
	static bool IsRunningGame();

	UFUNCTION(BlueprintPure, Category = "CWG|Game")
	static bool IsRunningClientOnly();

public:
	// Init - Destroy
	UFUNCTION(BlueprintPure, Category = "CWG|Init")
	static bool IsCanInitCustomData(const UObject* InObj);

	UFUNCTION(BlueprintPure, Category = "CWG|Destroy")
	static bool IsCanDestroyCustomData(const UObject* InObj);

public:
	// Pawn
	UFUNCTION(BlueprintPure, Category = "CWG|Pawn")
	static bool IsPartner(const class ACWPawn* ParamPawn1, const class ACWPawn* ParamPawn2);

	UFUNCTION(BlueprintPure, Category = "CWG|Pawn")
	static bool IsFriend(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2);

	UFUNCTION(BlueprintPure, Category = "CWG|Pawn")
	static bool IsEnemy(const ACWPawn* ParamPawn1, const ACWPawn* ParamPawn2);

	template<class T = class ACWGameState>
	static T* GetGameState(const UObject* InWorldContext)
	{
		UWorld* MyWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
		return MyWorld ? MyWorld->GetGameState<T>() : nullptr;
	}

	template<class T = class ACWGameMode>
	static T* GetGameMode(const UObject* InWorldContext)
	{
		UWorld* MyWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
		return MyWorld ? MyWorld->GetAuthGameMode<T>() : nullptr;
	}

	template<class T = class AActor>
	static T* GetActor(const UObject* InWorldContext,
		TFunction<bool(const T*)>&& InGetPredicate = nullptr)
	{
		UWorld* InWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr;
		if (nullptr == InWorld)
		{
			return nullptr;
		}

		for (TActorIterator<T> Iter(InWorld); Iter; ++Iter)
		{
			T* TmpActor = *Iter;
			if (IsValidActorImpl(TmpActor) && 
				(nullptr == InGetPredicate || InGetPredicate(TmpActor)))
			{
				return TmpActor;
			}
		}
		return nullptr;
	}

	template<class T = class AActor>
	static int32 GetAllActors(const UObject* InWorldContext, TArray<T*>& OutArray, 
							TFunction<bool(const T*)>&& InGetPredicate = nullptr,
							TFunction<bool(const T&, const T&)>&& InSortPredicate = nullptr)
	{
		OutArray.Empty();

		if (UWorld* InWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr)
		{
			for (TActorIterator<T> Iter(InWorld); Iter; ++Iter)
			{
				T* TmpActor = *Iter;
				if (IsValidActorImpl(TmpActor) && 
					(nullptr == InGetPredicate || InGetPredicate(TmpActor)))
				{
					OutArray.Add(TmpActor);
				}
			}
			if (nullptr != InSortPredicate)
			{
				OutArray.Sort(InSortPredicate);
			}
		}
		return OutArray.Num();
	}

	template<class T = class UObject>
	static int32 GetAllObjects(const UObject* InWorldContext, TArray<T*>& OutArray)
	{
		OutArray.Empty();

		if (UWorld* InWorld = IsValidObjectImpl(InWorldContext) ? InWorldContext->GetWorld() : nullptr)
		{
			for (TObjectIterator<T> Iter; Iter; ++Iter)
			{
				T* Obj = *Iter;
				if (IsValidObjectImpl(Obj) && Obj->IsA(T::StaticClass()))
				{
					OutArray.Add(Obj);
				}
			}
		}
		return OutArray.Num();
	}

	UFUNCTION(BlueprintPure, Category = "GamePlay|Actor", meta = (WorldContext = "InWorldContext"))
	static AActor* GetOneActor(const UObject* InWorldContext, TSubclassOf<AActor> InActorClass);

	// 销毁对象子对象
	UFUNCTION(BlueprintCallable, Category = "CWG|Actor")
	static void DestroyActorChildren(AActor* InActor);

	// Timer Manager
	//static FTimerManager& GetTimerManager(const UObject* InWorldContext);

	// Hit Trace 
	static bool GetHitResult(FHitResult& OutHitResult, const FVector2D& InScreenSpacePosition, const UObject* InWorldContext = nullptr);

	// Asset
	UFUNCTION(BlueprintPure, Category = "GamePlay|Asset")
	static TSoftObjectPtr<UObject> ToSoftObjectPtr(const FString& InAssetPath);

	UFUNCTION(BlueprintPure, Category = "GamePlay|Asset")
	static TSoftClassPtr<UClass> ToSoftClassPtr(const FString& InClassPath);

	UFUNCTION(BlueprintPure, Category = "GamePlay|Asset")
	static UObject* LoadObject(const TSoftObjectPtr<UObject>& InSoftObjectPtr);

	UFUNCTION(BlueprintPure, Category = "GamePlay|Asset")
	static UClass* LoadClass(const TSoftClassPtr<UClass>& InSoftClassPtr);

	template<class T = UObject>
	static T* LoadObjectImpl(const TSoftObjectPtr<T>& InSoftObjectPtr)
	{
		return Cast<T>(InSoftObjectPtr.LoadSynchronous());
	}

	template<class T = UClass>
	static T* LoadClassImpl(const TSoftClassPtr<T>& InSoftClassPtr)
	{
		return Cast<T>(InSoftClassPtr.LoadSynchronous());
	}

	// Spawn
	UFUNCTION(BlueprintCallable, Category = "GamePlay|Spawn")
	static UTextRenderComponent* PrintTxtInfo(AActor* InActor, 
		const FText& InTxt = FText(), const FColor& InClolor = FColor::Red, const float InSize = 250.f, const float InOffsetZ = 25.f);

	// Material
	UFUNCTION(BlueprintPure, Category = "GamePlay|Material")
	static UMaterialInstanceDynamic* GetPostProcessVolumeMaterial(APostProcessVolume* InPostProcessVolume, FName InMaterialName);

public:
	// To String
	static const FString ToString(const enum ENetMode& NetMode = NM_MAX);

	// Android
	static void CWControlScreenSaver(const bool bAllowScreenSaver = false);

	// Platform Type
	UFUNCTION(BlueprintPure, Category = "CWG|PlatformType")
	static bool IsPlatform(const EPlatformType InType = EPlatformType::Windows);

	UFUNCTION(BlueprintPure, Category = "CWG|PlatformType")
	static bool IsDesktopPlatform();

	UFUNCTION(BlueprintPure, Category = "CWG|PlatformType")
	static bool IsMobilePhonePlatform();

	UFUNCTION(BlueprintCallable, Category = "GamePlay|File")
	static void ScanDirectory(TArray<FString>& OutFiles, const FString& FilePath, const FString& Extension);

	static void FindFilesRecursive(TArray<FString>& FileNames, const TCHAR* StartDirectory, const TCHAR* Filename, bool Files, bool Directories, bool bClearFileNames = true);
	static void FindFilesRecursiveInternal(TArray<FString>& FileNames, const TCHAR* StartDirectory, const TCHAR* Filename, bool Files, bool Directories);
};

/**
 * Test validity of object
 * @param	InUObject		The object to check
 * @return	Return			true if the object is usable: non-null and not pending kill and
 */
static bool IsValidObject(const UObject* InUObject)
{
	return IsValid(InUObject) && 
		!InUObject->GetFName().IsEqual(NAME_None) && 
		//!InUObject->GetFName().IsEqual(TEXT("Invalid")) &&
		!InUObject->HasAnyFlags(RF_ClassDefaultObject | RF_BeginDestroyed | RF_FinishDestroyed);
}
static bool IsValidActor(const AActor* InAActor)
{
	return IsValidObject(InAActor) && !InAActor->IsActorBeingDestroyed();
}
static bool IsValidCompnent(const UActorComponent* InActorComponent)
{
	return IsValidObject(InActorComponent) && !InActorComponent->IsBeingDestroyed();
}

// 重载运算符 ==
static bool operator==(const int32 Int32Value, ECWPawnInputState EnumValue)
{
	return Int32Value == (int32)EnumValue;
}
static bool operator==(ECWPawnInputState EnumValue, const int32 Int32Value)
{
	return Int32Value == EnumValue;
}
