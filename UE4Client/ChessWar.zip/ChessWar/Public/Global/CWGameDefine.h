﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Logging/LogMacros.h"
#include "CWGameDefine.generated.h"


/** when you modify this, please note that this information can be saved with instances
 * also DefaultEngine.ini [/Script/Engine.CollisionProfile] should match with this list **/
#define COLLISION_CAMERAPAWN		ECC_GameTraceChannel1	/** CameraPawn */
#define COLLISION_PANCAMERA			ECC_GameTraceChannel2	/** PanCamera */
#define COLLISION_INVISIBLEWALL		ECC_GameTraceChannel3	/** InvisibleWall */
#define COLLISION_PROJECTILE		ECC_GameTraceChannel3	/** Projectile */


#define CHAR_MINI_MINI_BUFFER_MAX 16
#define CHAR_MINI_MINI_BUFFER_CONTENT_MAX (CHAR_MINI_MINI_BUFFER_MAX-1)
#define CHAR_MINI_BUFFER_MAX 32
#define CHAR_MINI_BUFFER_CONTENT_MAX (CHAR_MINI_BUFFER_MAX-1)
#define CHAR_BUFFER_MAX 256
#define CHAR_BUFFER_CONTENT_MAX (CHAR_BUFFER_MAX-1)
#define CHAR_LONG_BUFFER_MAX 512
#define CHAR_LONG_BUFFER_CONTENT_MAX (CHAR_LONG_BUFFER_MAX-1)
#define CHAR_LONGLONG_BUFFER_MAX 1024
#define CHAR_LONGLONG_BUFFER_CONTENT_MAX (CHAR_LONGLONG_BUFFER_MAX-1)


#define MAX_PAWN_BUFF	40
#define LONG_DOWN_TIME	0.0f
#define FALL_TIME		5.0f
#define SPLINE_Z		20.0f
#define SPLINE_EX_Z		10.0f

#define CLIENT_MAP_TILE_OFFSETZ (2.f)
#define INVALID_TIME_VALUE		(-100.f)

#define PAWN_ANIM_TIME_MAX	3.0f;

 
 // 默认初始化数据
const int32 DefaultPort = 7777;
const FString DefaultHostIp = TEXT("127.0.0.1");
const FString LoginMapName = TEXT("LoginMap");
const FString LobbyMapName = TEXT("Lobby");
const FString ServerEmptyURL = TEXT("EmptyServer?Game=EmptyServerGM");
const FString ServerResetURL = TEXT("ServerWaiting?Game=WaitServerGM");
const FString ServerPVPURL = TEXT("L_randomDungeon_persistent?Game=PVPGM");
const FString ClientLoginURL = TEXT("LoginMap?Game=ChessWar.CWGMLogin");
const FString ClientLobbyURL = TEXT("Lobby?game=Engine.GameModeBase");


/** 自定义颜色 */
const FLinearColor REDHUDCOLOR = FLinearColor(1.0f, 0.05f, 0.0f, 1.0f);
const FLinearColor BLUEHUDCOLOR = FLinearColor(0.1f, 0.1f, 1.0f, 1.0f);
const FLinearColor GOLDCOLOR = FLinearColor(1.f, 0.9f, 0.15f);
const FLinearColor SILVERCOLOR = FLinearColor(0.5f, 0.5f, 0.75f);
const FLinearColor BRONZECOLOR = FLinearColor(0.48f, 0.25f, 0.18f);


enum ECWNetDefine
{
	// mtu = 1500 , data = 1472
	MaxNetDataLength = 1024 * 5,
	MaxReqBuffLength = MaxNetDataLength + 24,		// 投递给网络底层的buff大小
	MaxReceiveBuffLength = 2 * MaxReqBuffLength,		// 接收消息的最大长度

	WaitConnectTimeOut = 5,				// 尝试连接间隔时间  单位 : 秒
	WaitSendTimeOut = 1,				// 等待发送消息时间 单位: 毫秒

	ClintPingTime = 30,				// ping 时间, 单位 : 秒
	ServerPingTimeOut = 70,			// ping 超时, 单位 : 秒
	ConnectorTimeOut = 60000,		// 连接后无操作的超时时间 单位 : 毫秒

	ConncectTime = 5000,			// 重连定时器
	SerializeBuffLength = 1024 * 1024 * 20 + 24,	// 序列化消息的buff长度

	CUT_MSGCHILDBEGIN = 65535,		// 分割的头消息
	CUT_MSGCHILD = 65534,		// 分割的子消息

	///////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////
	ConnectEvent = 1,		// 连接事件
	DisconnectEvent = 2,	// 关闭事件
	FailedEvent = 3,		// 失败事件
	ErrorEvent = 4,			// 错误事件
	ShutEvent = 5,			// 销毁时间
};


UENUM(BlueprintType)
enum class EThreadStatus :uint8
{
	New UMETA(DisplayName = "New"),
	Runnable UMETA(DisplayName = "Runnable"),
	Blocked UMETA(DisplayName = "Blocked"),
	Waiting UMETA(DisplayName = "Waiting"),
	TimedWaiting UMETA(DisplayName = 'TimedWaiting'),
	Terminated UMETA(DisplayName = 'Terminated')
};


/** Brief 游戏阶段
 *
 */
UENUM(BlueprintType)
enum class ECWGameStage : uint8
{
	None,
	Login,			/**< 登陆阶段 */
	Lobby,			/**< 大厅阶段 */
	Battle,			/**< 战斗阶段 */
};

/** Brief 登陆状态
 *
 */
UENUM(BlueprintType)
enum class ECWLoginState : uint8
{
	None,
	CheckVersion,				/**< 版本检测 */
	BatchUpdate,				/**< 补丁更新 */
	ServerAuth,					/**< 服务器授权 */
	ServerList,					/**< 服务器列表 */
	Login,						/**< 登陆 */
};


/** Brief 影响登陆状态的相关事件
 *
 */
UENUM(BlueprintType)
enum class ECWLoginEvent : uint8
{
	None,
	ToCheckVersion,				/**< 到版本检测 */
	ToBatchUpdate,				/**< 到补丁更新 */
	ToServerAuth,				/**< 服务器授权 */
	ToServerList,				/**< 服务器列表 */
	ToLogin,					/**< 到登陆 */

	Max
};


/** Brief 战斗状态
 *
 */
UENUM(BlueprintType)
enum class ECWBattleState : uint8
{
	None,
	Dungeon,					/**< 地图格子 */
	ShowStory,					/**< 展示故事情节 */
	Ready,						/**< 战前准备 */
	Fighting,					/**< 战斗中 */
	Pause,						/**< 暂停(单机可以暂停) */
	Settlement,					/**< 结算 */ 
};

/** Brief 影响战斗状态的相关事件
 * 
 */
UENUM(BlueprintType)
enum class ECWBattleEvent : uint8
{
	None,
	ToDungeon,					/**< 到地图格子 */
	ToReady,					/**< 到战前准备 */
	ReadyTimeOut,				/**< 战前准备的超时 */
	ReadyFinish,				/**< 战前准备的结束 */
	Result,						/**< 战斗出结果 */

	Max
};


/** Brief 战斗结果
 *
 */
UENUM(BlueprintType)
enum class ECWBattleResult : uint8
{
	None,
	Draw,				/**< 平局 */
	Win,				/**< 赢 */
	Lost,				/**< 输 */

	Max
};


/** Brief 战斗状态
 *
 */
UENUM(BlueprintType)
enum class ECWBattleFightingState : uint8
{
	None = (int)ECWBattleEvent::Max + 1,

	NoRunning,					/**< 没有运行 */
	Normal,						/**< 普通 */
	WaitingEnd,					/**< 等待结束 */
	WaitingDungeonTileFall,		/**< 等待地形格子掉落 */
};


/** Brief 影响战斗状态的战斗事件
 *
 */
UENUM(BlueprintType)
enum class ECWBattleFightingEvent : uint8
{
	None,
	ToNoRunning,				/**< 没有运行 */
	ToNormal,					/**< 普通 */
	ToWaitingEnd,				/**< 等待结束 */
	ToWaitingDungeonTileFall,	/**< 等待地形格子掉落 */
};


/** Brief 控制器类型
 *
 */
UENUM(BlueprintType)
enum class ECWControllerType : uint8
{
	None,
	NetPlayer,		/**< 网络玩家 */
	AI,				/**< AI */
};

/** Brief 阵营标签
 *
 */
UENUM(BlueprintType)
enum class ECWCampTag : uint8
{
	None,
	A,				/**< A阵营 */
	B,				/**< B阵营 */
	C,				/**< C阵营 */
	D,				/**< D阵营 */
	E,				/**< E阵营 */
	F,				/**< F阵营 */
	G,				/**< G阵营 */
	H,				/**< H阵营 */

	Max
};

/** Brief 同一个阵营的不同控制器
 *
 */
UENUM(BlueprintType)
enum class ECWCampControllerIndex : uint8
{
	None,

	One,			/**< 01 */
	Two,			/**< 02 */
	Three,			/**< 03 */
	Four,			/**< 04 */
	Five,			/**< 05 */
	Six,			/**< 06 */
	Seven,			/**< 07 */
	Eight,			/**< 08 */

	Max
};

/** Brief 棋子的响应输入的状态
 *
 */
UENUM(BlueprintType)
enum class ECWPawnInputState : uint8
{
	None,
	WaitInReady,				/**< 等待(准备阶段)			01 */
	SelectInReady,				/**< 选中(准备阶段)			02 */
	NoCtrlInReady,				/**< 不能被控制(准备阶段)		03 */
	NoControl,					/**< 不能被控制				04 */	
	TurnWaitingAction,			/**< 等待轮到可操作			05 */
	WaitingInput,				/**< 等待玩家输入				06 */
	Selected,					/**< 选中					07 */
	SelectedAndWantAttack,		/**< 选中并且想要攻击目标		08 */
	ReadyToMove,				/**< 准备移动					09 */
	ReadyToMoveAndWantAttack,	/**< 准备移动并且想要攻击目标	10 */
	MoveToDest,					/**< 移动目标格子				11 */
	MoveToAttack,				/**< 移动攻击					12 */
	MoveToWaitingAttack,		/**< 移动等待攻击				13 */
	WaitingAttack,				/**< 等待攻击					14 */
	NormalAttack,				/**< 普通攻击中				15 */
	CastSkillToTile,			/**< 目标为格子的释放技能中		16 */
	CastSkillToPawn,			/**< 目标为棋子的释放技能中		17 */
	TurnInputFinish,			/**< 行动结束					18 */
};


/** Brief 棋子的响应输入的事件
 * 
 */
UENUM(BlueprintType)
enum class ECWPawnInputEvent : uint8
{
	None,
	LeftMouseDown,				/**< 鼠标左键按下 */
	LeftMouseUp,				/**< 鼠标左键弹起 */

	TurnWaitingAction,			/**< 回合内等待行动 */
	TurnStartAction,			/**< 回合内开始行动 */
	CancelToWaitingInput,		/**< 回到等待输入 */
	Selected,					/**< 选中 */
	SelectedAndWantAttack,		/**< 选中并且想要攻击目标(已选中攻击目标) */
	ReadyToMove,				/**< 准备移动 */
	ReadyToMoveAndWantAttack,	/**< 准备移动并且想要攻击目标(已选中攻击目标) */
	MoveToDest,					/**< 移动目标格子 */
	MoveToAttack,				/**< 移动攻击 */
	MoveToWaitingAttack,		/**< 移动等待攻击 */
	WaitingAttack,				/**< 等待选择攻击目标(还没有选中攻击目标，等待选择攻击目标) */
	NormalAttack,				/**< 普通攻击 */
	CastSkillToTile,			/**< 目标为格子的释放技能中 */
	CastSkillToPawn,			/**< 目标为棋子的释放技能中 */
	TurnActionFinish,			/**< 回合行动结束 */
};


/** Brief 棋子行为状态
 *
 */
UENUM(BlueprintType)
enum class ECWPawnActionState : uint8
{
	None,

	Idle,							/**< 休闲					01 */
	BeHit,							/**< 受击					02 */
	ForceMove,						/**< 被迫移动				03 */
	Dizziness,						/**< 眩晕					04 */
	Die,							/**< 死亡					05 */
	Death,							/**< 躺尸					06 */
	MoveToWaitingAttack,			/**< 移动等待攻击			07 */
	WaitingAttack,					/**< 等待攻击				08 */
	MoveToDest,						/**< 移动到目的地			09 */
	MoveToAttack,					/**< 移动攻击				10 */
	NormalAttack,					/**< 普通攻击				11 */
	CastSkillToTile,				/**< 目标为格子的施法		12 */
	CastSkillToPawn,				/**< 目标为棋子的施法		13 */
	CounterAttack,					/**< 反击					14 */
	End,							/**< 行为结束				15 */


	Max,
};


/** Brief 棋子的行为改变的事件
 *
 */
UENUM(BlueprintType)
enum class ECWPawnActionEvent : uint8
{
	None,
	ToIdle,								/**< 改变到休闲 */
	ToBeHit,							/**< 改变到受击 */
	ToForceMove,						/**< 改变到被迫移动 */
	ToDizziness,						/**< 改变到眩晕 */
	ToDie,								/**< 改变到死亡 */
	ToDeath,							/**< 改变到躺尸 */
	ToMoveToWaitingAttack,				/**< 改变到移动等待攻击 */
	ToWaitingAttack,					/**< 改变到等待攻击 */
	ToMoveToDest,						/**< 改变到移动到目的地 */
	ToMoveToAttack,						/**< 改变到移动攻击 */
	ToNormalAttack,						/**< 改变到普通攻击 */
	ToCastSkillToTile,					/**< 改变到释放技能 */
	ToCastSkillToPawn,					/**< 改变到释放技能 */
	ToEnd,								/**< 改变到行为结束 */
	ForceToEnd,							/**< 强行改变到行为结束 */
};


UENUM(BlueprintType)
enum class ECWPawnActionStateProcess : uint8
{
	NONE,

	HOLD,		
	SUSPEND,
	END,
};

UENUM(BlueprintType)
enum class ECWPawnActionStateChange : uint8
{
	NONE,

	SUCCESS,
	FAILED,	
};


/** Brief 棋子行为的相关动作
 *
 */
UENUM(BlueprintType)
enum class ECWPawnAnim : uint8
{
	None,
	Idle01,				/**< 待机动作01 */
	Idle02,				/**< 待机动作02 */
	Pose01,				/**< 休闲时摆pos的动作01 */
	Pose02,				/**< 休闲时摆pos的动作02 */
	Move01,				/**< 移动动作01 */
	Move02,				/**< 移动动作02 */
	BeHit01,			/**< 受击01 */
	BeHit02,			/**< 受击02 */
	Die01,				/**< 死亡的动作01 */
	Die02,				/**< 死亡的动作02 */
	Death01,			/**< 死亡扑街的动作01 */
	Death02,			/**< 死亡扑街的动作02 */
	NormalAttack01,		/**< 普通攻击01 */
	NormalAttack02,		/**< 普通攻击02 */ 
	Skill01,			/**< 技能01 */
	Skill02,			/**< 技能02 */
	Skill03,			/**< 技能03 */
	IdleNoAction01,		/**< 待机不可行动动作01 */
	IdleNoAction02,		/**< 待机不可行动动作02 */
	Defence01,			/**< 防御01 */
	Defence02,			/**< 防御02 */
	CounterAttack01,	/**< 反击01 */
	CounterAttack02,	/**< 反击02 */
	SpawnAction01,		/**< 出生动作01 */
	SpawnAction02,		/**< 出生动作02 */
	ForceMove,			/**< 强制位移 */
	Dizziness,			/**< 眩晕动作 */
};


/**
 * @Brief	行动方式
 */
UENUM(BlueprintType)
enum class ECWActionType : uint8
{
	AT_None,

	// 行走
	AT_Walking,
	// 乘骑
	AT_Riding,
	// 飞行
	AT_Flying,
	// 水生
	AT_Aquatic

};


/** Brief 兵种
 *
 */
UENUM(BlueprintType)
enum class ECWBattleArmRelation : uint8
{
	None,
	Beat,				/**< 兵种克制 */
	BeBeat,				/**< 兵种被克制 */
	Same,				/**< 兵种相同 */
};


/** Brief 战斗攻击类型
 *
 */
UENUM(BlueprintType)
enum class ECWBattleAttackType : uint8
{
	None,
	Physical,			/**< 物理攻击 */
	Magic,				/**< 魔法攻击 */
};

/** Brief 战斗相关属性
 *
 */
UENUM(BlueprintType)
enum class ECWBattleProperty : uint8
{
	None,
	Attack,					/**< 攻击力					01 */
	PhysicalDefence,		/**< 物理防御				02 */
	MagicDefence,			/**< 魔法防御				03 */
	Health,					/**< 生命值					04 */
	Energy,					/**< 能量值					05 */	
	Talent,					/**< 技巧值					06 */	
	Move,					/**< 行动力					07 */
	CriticalDamageFactor,	/**< 暴击伤害系数			08 */
	CriticalHitRate,		/**< 暴击率					09 */
	AttackSpeed,			/**< 出手速度				10 */
	Speed,					/**< 影响回避率的速度		11 */
	HitRate,				/**< 命中率					12 */		
	AvoidanceRate,			/**< 回避率					13 */		
	BlockRate,				/**< 格挡率					14 */

	AttackFactor,			/**< 攻击力系数(乘)			15 */
	PhysicalDefenceFactor,	/**< 物理防御系数(乘)		16 */
	MagicDefenceFactor,		/**< 魔法防御系数(乘)		17 */
	HealthFactor,			/**< 生命值系数(乘)			18 */
	EnergyFactor,			/**< 能量值系数(乘)			19 */
	TalentFactor,			/**< 技巧值系数(乘)			20 */
	MoveFactor,				/**< 行动力系数(乘)			21 */
	CriticalDamageFF,		/**< 暴击伤害系数系数(乘)	22 */
	CriticalHitRateFactor,	/**< 暴击率系数(乘)			23 */
	AttackSpeedFactor,		/**< 出手速度系数(乘)		24 */
	SpeedFactor,			/**< 影响回避率速度系数(乘)	25 */
	HitRateFactor,			/**< 命中率系数	(乘)		26 */
	AvoidanceRateFactor,	/**< 回避率系数(乘)			27 */
	BlockRateFactor,		/**< 格挡率系数(乘)			28 */

	DefincePostureFactor,	/**< 防御姿态系数(乘)		29 */
	DefincePosture,			/**< 防御姿态叠加(加)		30 */
	FinalDamageFactor,		/**< 最终伤害系数(乘)		31 */
	FinalDamage,			/**< 最终伤害叠加(加)		32 */

	UniqueId,				/**< 唯一Id					33 */
	AttackType,				/**< 攻击类型				34 */
	Profession,				/**< 职业					35 */

	PropertySetAffectorType,/**< 属性集合影响类型		36 */
};

/** Brief 战斗攻击属性修改的操作
 *
 */
UENUM(BlueprintType)
enum class ECWBattlePropertyModifyOp : uint8
{
	None,

	Base_Multiply_Param1_Add_Param2,						/**< result = base * param1 + param2			01 */

	Add_Param1,												/**< result = result + param1 					02 */

	Base_Multiply_Param1_ClampMax_Param2,					/**< result = result + clamp(basevalue * param1, 0.f, param2)	03 */
};

/** Brief 有限状态机栈操作
 *
 */
UENUM(BlueprintType)
enum class ECWFSMStackOp: uint8
{ 
	None,				
	Set,			/**< 设置操作 */
	Push,			/**< 压栈操作 */
	Pop,			/**< 弹栈操作 */
};


/** Brief 属性集合影响类型
 *
 */
UENUM(BlueprintType)
enum class ECWPropertySetAffectorType : uint8
{
	None,
	NormalAttack,		/**< 作用在普通攻击 */	
	Skill,				/**< 作用在技能 */
	All,				/**< 可作用在普通攻击，也可作用在技能 */

	Max,
};


/** Brief 地图格子攻击伤害移动属性
 *
 */
UENUM(BlueprintType)
enum class ECWMapTileMoveAttackDamageType : uint8
{
	None		= 0x00,			
	Move		= 0x01,			/**< 移动区域 */
	Attack		= 0x02,			/**< 攻击区域 */
	Support		= 0x04,			/**< 支援区域 */
	Damage		= 0x08,			/**< 伤害区域 */
	MoveEx		= 0x10,			/**< 移动区域 */
	
	Max,
};


/** Brief 攻击范围类型
 *
 */
UENUM(BlueprintType)
enum class ECWAttackRangeType : uint8
{
	None,
	SelfCenterFromToStep,				/**< 以自己为中心， 从多少步进到多少步进 */
	SelfCenterRectangleFromTo,			/**< 以自己为中心, 从多少步进到多少步进的矩形  */
	SingleForward,						/**< 单个方向的攻击范围为  */

	Max,
};


/** Brief 有限状态机基础事件
 *
 */
UENUM(BlueprintType)
enum class ECWFSMEvent : uint8
{
	None,
	Startup,		/**< 状态机启动 */	
};


/** Brief 地表格子渲染类型
 *
 */
UENUM(BlueprintType)
enum class ECWTileRenderType : uint8
{
	None,
	Foundation,		/**< 基础 */
	Move,			/**< 可移动 */
	Attack,			/**< 可攻击 */
	Selected,		/**< 选中 */
	Support,		/**< 支援 */
	SwitchInReady,	/**< 换位(准备阶段) */
	FallWarning,	/**< 掉落预警 */
	RandEvtWarn,	/**< 随机事件预警 */
};


/** Brief 地表格子渲染类型
 *
 */
UENUM(BlueprintType)
enum class ECWMapTileType : uint8
{
	None		= 0xff,
	NoObstacle	= 0x00,			/**< 非障碍 */
	Obstacle	= 0x01,			/**< 障碍 */

};


/** Brief 地图格子的响应输入的状态
 *
 */
UENUM(BlueprintType)
enum class ECWMapTileInputState : uint8
{
	None,
	WaitingInput,				/**< 等待玩家输入 */
	Selected,					/**< 选中 */
};


/** Brief 地图格子的响应输入的事件
 *
 */
UENUM(BlueprintType)
enum class ECWMapTileInputEvent : uint8
{
	None,
	LeftMouseUp,			/**< 鼠标左键弹起 */
	Selected,				/**< 选中 */
	CancelSelected,			/**< 取消选中 */
};


/** Brief 指令类型
 *
 */
UENUM(BlueprintType)
enum class ECWInstructType : uint8
{
	None			= 0x00,
	Move			= 0x01,		/**< 移动指令 */
	NormalAttack	= 0x02,		/**< 普通攻击指令 */
	CastSkill		= 0x04,		/**< 施法指令 */
	Defence			= 0x08,		/**< 防御指令 */
	Await			= 0x40,		/**< 待机指令 */
};

/** 无法操作指令 */
#define Instruct_InValid (uint8)(0x7f)


/** Brief  攻击目标类型
 *
 */
UENUM(BlueprintType)
enum class ECWAttackTargetType : uint8
{
	None,
	Pawn,			/**< 攻击棋子 */
	Tile,			/**< 攻击地图格子 */
};

/** Brief  攻击方式类型
 *
 */
UENUM(BlueprintType)
enum class ECWAttackModeType : uint8
{
	None,
	NormalAttack,	/**< 普通攻击 */
	Skill,			/**< 技能 */
	Auto,			
};

/** Brief  触发条件类型
 *
 */
UENUM(BlueprintType)
enum class ECWTriggerConditionType : uint8
{
	None,
	KeyTime,					/**< 关键时间点		01 */
	Probability,				/**< 生成几率		02 */
	CastSkillBattleProperty,	/**< 施法者的战斗属性	03 */
	TargetBattleProperty,		/**< 目标的战斗属性	04 */
	RoundTriggerCount,			/**< 回合触发次数	05 */

	Max
};

/** Brief  触发条件类型的逻辑操作枚举
 *
 */
UENUM(BlueprintType)
enum class ECWTriggerConditionTypeLogicOp : uint8
{
	None,
	And,			/**< 逻辑与		01 */
	Or,				/**< 逻辑或		02 */

	Max
};


/** Brief  触发条件类型的比较关系枚举
 *
 */
UENUM(BlueprintType)
enum class ECWTriggerConditionTypeRelationOp : uint8
{
	None,
	Equal,					/**< 等于		01 */
	NoEqual,				/**< 不等于		02 */
	LessThan,				/**< 小于		03 */
	EqualOrLessThan,		/**< 小于或等于	04 */	
	GreaterThan,			/**< 大于		05 */	
	GreaterOrLessThan,		/**< 大于或等于	06 */

	Max
};


/** Brief  触发条件类型的比较关系值的类型
 *
 */
UENUM(BlueprintType)
enum class ECWTriggerConditionTypeRelationOpValueType : uint8
{
	None,
	Value,						/**< 值							01 */
	CurPercentMax,				/**< 当前值与最大值的百分比		02 */
	
	Max
};


/** Brief  关键时间点类型
 *
 */
UENUM(BlueprintType)
enum class ECWKeyTimeType : uint8
{
	None,
	LifeBegin,						/**< 出生（生命）开始时					01 */
	LifeEnd,						/**< 出生（生命）结束时					02 */
	TurnBegin,						/**< 回合开始时							03 */
	TurnEnd,						/**< 回合结束时							04 */
	PawnActionBegin,				/**< 棋子自身行动开始时					05 */
	PawnActionEnd,					/**< 棋子自身行动结束时					06 */
	BuffBegin,						/**< Buff生成时							07 */
	BuffKeyTimeType,				/**< Buff生效时							08 */
	BuffEnd,						/**< Buff消失时							09 */
	PassivitySkillBegin,			/**< 被动技能开始时						10 */
	PassivitySkillEnd,				/**< 被动技能结束时						11 */
	NormalAttackBegin,				/**< 普通攻击开始时						12 */
	NormalAttackEnd,				/**< 普通攻击结束时						13 */
	NormalAttackDamage01,			/**< 普通攻击产生伤害时01				14 */
	NormalAttackDamage02,			/**< 普通攻击产生伤害时02				15 */
	NormalAttackDamage03,			/**< 普通攻击产生伤害时03				16 */
	InitiativeSkillBegin,			/**< 主动技能开始时						17 */
	InitiativeSkillEnd,				/**< 主动技能结束时						18 */
	InitiativeSkillDamage01,		/**< 主动技能产生伤害时01				19 */
	InitiativeSkillDamage02,		/**< 主动技能产生伤害时02				20 */
	InitiativeSkillDamage03,		/**< 主动技能产生伤害时03				21 */
	InitiativeAttackBegin,			/**< 主动攻击开始时						22 */
	InitiativeAttackEnd,			/**< 主动攻击结束时						23 */
	InitiativeAttackDamage01,		/**< 主动攻击产生伤害时01				24 */
	InitiativeAttackDamage02,		/**< 主动技能产生伤害时02				25 */
	InitiativeAttackDamage03,		/**< 主动技能产生伤害时03				26 */
	BeHitBeginByNormalAttack01,		/**< 被攻击方受到普通攻击时的开始01		27 */
	BeHitEndByNormalAttack01,		/**< 被攻击方受到普通攻击时的结束01		28 */
	BeHitBeginByNormalAttack02,		/**< 被攻击方受到普通攻击时的开始02		29 */
	BeHitEndByNormalAttack02,		/**< 被攻击方受到普通攻击时的结束02		30 */
	BeHitBeginByNormalAttack03,		/**< 被攻击方受到普通攻击时的开始03		31 */
	BeHitEndByNormalAttack03,		/**< 被攻击方受到普通攻击时的结束03		32 */
	BeHitBeginByInitiativeSkill01,	/**< 被攻击方受到主动技能时的开始01		33 */
	BeHitEndByInitiativeSkill01,	/**< 被攻击方受击主动技能时的结束01		34 */
	BeHitBeginByInitiativeSkill02,	/**< 被攻击方受击主动技能时的开始02		35 */
	BeHitEndByInitiativeSkill02,	/**< 被攻击方受击主动技能时的结束02		36 */
	BeHitBeginByInitiativeSkill03,	/**< 被攻击方受击主动技能时的开始03		37 */
	BeHitEndByInitiativeSkill03,	/**< 被攻击方受击主动技能时的结束03		38 */
	BeHitBeginByInitiativeAttack01,	/**< 被攻击方受击主动攻击时的开始01		39 */
	BeHitEndByInitiativeAttack01,	/**< 被攻击方受击主动攻击时的结束01		40 */
	BeHitBeginByInitiativeAttack02,	/**< 被攻击方受击主动攻击时的开始02		41 */
	BeHitEndByInitiativeAttack02,	/**< 被攻击方受击主动攻击时的结束02		42 */
	BeHitBeginByInitiativeAttack03,	/**< 被攻击方受击主动攻击时的开始03		43 */
	BeHitEndByInitiativeAttack03,	/**< 被攻击方受击主动攻击时的结束03		44 */
	BuffLifeAll,					/**< Buff存在时的所有时间段				45 */
	PassivitySkillDamage01,			/**< 被动技能产生伤害时01				46 */
	PassivitySkillDamage02,			/**< 被动技能产生伤害时02				47 */
	PassivitySkillDamage03,			/**< 被动技能产生伤害时03				48 */
	PassivitySkillAllDamage,		/**< 被动技能所有产生的伤害时			49 */
	NormalAttackAllDamage,			/**< 普通攻击所有产生的伤害时			50 */
	InitiativeSkillAllDamage,		/**< 主动技能所有产生的伤害时			51 */
	InitiativeAttackAllDamage,		/**< 主动攻击所有产生的伤害时			52 */

	Max
};



/** Brief  Buff结束类型
 *
 */
UENUM(BlueprintType)
enum class ECWBuffLifeFinishType : uint8
{
	None,

	NormalAttackCount,					/**< 普通攻击次数			01 */

	Max
};


/** Brief  触发条件类型
 *
 */
UENUM(BlueprintType)
enum class ECWSkillTargetType : uint8
{
	None			= 0x00,
	Enemy			= 0x01,				/**< 敌方 */
	Partner			= 0x02,				/**< 同伴方 */
	Self			= 0x04,				/**< 自己 */
	Tile			= 0x08,				/**< 地图格子 */
	LevelObject		= 0x10,				/**< 地图物件（场景物件或关卡物件） */		
};


/** Brief  影响器类型(或效果器类型)
 *
 */
UENUM(BlueprintType)
enum class ECWAffectorType : uint8
{
	None,	
	NativePropertyModify,				/**< 原生属性修改(HP/SP)				01 */
	BattlePropertyModify,				/**< 战斗属性修改(ATK/DEF...)			02 */
	AttackDamage,						/**< 攻击伤害型 如：撕裂效果			03 */
	StrengthenNormalAttackDamage,		/**< 强化普通攻击伤害型 				04 */
	ActionAgain,						/**< 可以再次行动（可再次下指令）		05 */
	ForbidAction,						/**< 无法行动（无法下指令）	 			06 */
	BeatBack,							/**< 击退	 						07 */
	TakeThePlaceOfSomePawnForFighting,	/**< 代替其进入战斗	 				08 */
	Dizziness,							/**< 眩晕型							09 */
	Shield,								/**< 护盾							10 */
};


/** @Brief  影响器数据的来源类型
 *
 */
UENUM(BlueprintType)
enum class ECWBuffSouceType : uint8
{
	None				= 0,
	//~ 来源于技能
	Skill				= 1,
	//~ 来源于装备
	Equip				= 2,
	//~ 来源于场景(Buff)
	Scene				= 3,
	//~ 来源于随机事件
	RandEvt				= 4,
	//~ 来源于元素系统
	ElemSys				= 5,
	//~ 来源于天气系统
	WeatherSys			= 6,
	//~ 来源于物理系统
	PhySicsSys			= 7,
	//~ 来源于天赋系统
	TalentSys			= 8,
};

/** @brief	技能来源类型 */
UENUM(BlueprintType, Blueprintable)
enum class ECWSkillSouceType : uint8
{
	None				= 0,
	// 技能
	Skill				= 1,
	// 天赋
	TalentSys			= 7,
};


/** Brief  影响器数据可以作用于对象的类型
 *
 */
UENUM(BlueprintType)
enum class ECWPropertyAffectorDataAffectType : uint8
{
	None,
	Persistent,						/**<持久型, 一直保持，除非移除（对角色战斗相关属性做修改的效果器就是这个类型）	01 */
	InstantInKeyTime,				/**<瞬间型						02 */
};


/** Brief  攻击伤害方向
 *
 */
UENUM(BlueprintType)
enum class ECWAffectDirType : uint8
{
	None,
	Right,						/**<右	01 */
	Down,						/**<下	01 */
	Left,						/**<左	01 */
	Up,							/**<上	01 */
};


/** Brief  地形格子属性
 *
 */
UENUM(BlueprintType)
enum class ECWDungeonTileAttribute : uint8
{
	None		= 0x00,
	Obstacle	= 0x01,					/**<障碍	01 */
	Door		= 0x02,					/**<门	    02 */
	PawnStart   = 0x04,					/**<出生点  04 */
};


/** Brief  棋子类型
 *
 */
UENUM(BlueprintType)
enum class ECWPawnType : uint8
{
	None		= 0x00,
	Character	= 0x01,					/**< 角色	01 */
	DungeonItem = 0x02,					/**< 场景物件	02(BUFF) */
};


/** Brief  棋子移动模式
 *
 */
UENUM(BlueprintType)
enum class ECWPawnMoveMode : uint8
{
	None,
	One,							/**< 1 */
	Two,							/**< 2 */
};


/**
 *	@brief	Platform Type
 */
UENUM(BlueprintType)
enum class EPlatformType : uint8
{
	Unknown,
	Windows,
	PS4,
	XBoxOne,
	Mac,
	IOS,
	Android,
	HTML5,
	Linux,
	Quail,
	Switch
};


/**
 * @brief	克制类型
 */
UENUM()
enum ECWRefrainType
{
	None,
	// 武器
	Weapon,
	// 行动
	Action,
	// 种族
	Race,

	Max
};


/**
 * @brief 角色换装部位，（这里指骨骼模型, 武器不算)
 */
UENUM()
enum class ECWAvatarPart : uint8
{
	None,
	Head,			/**< 头		01 */
	UpperBody,		/**< 上半身	02 */
	LowerBody,		/**< 下半身	03 */
	Foot,			/**< 脚		04 */

	Max,
};


/**
 * @brief 边缘装饰坐标
 * 9个区域的枚举 下边:1, 上边:2, 右边:4, 左边:8, 右下角:16, 右上角:32, 左上角:64, 左下角:128， 中间:256
 */
//UENUM()
enum class ECWEdgeOutSideDecorateCoord : uint16
{
	None					= 0x0000,

	YZero					= 0x0001,				
	YHeightMax				= 0x0002,
	XZero					= 0x0004,
	XWidthMax				= 0x0008,
	XZeroYZero				= 0x0010,
	XZeroYHeightMax			= 0x0020,
	XWidthMaxYHeightMax		= 0x0040,
	YZeroXWidthMax			= 0x0080,
	Center					= 0x0100,
	
	All						= 0xffff,
};


/**
 * @brief 边缘装饰朝向
 */
UENUM()
enum class ECWEdgeOutSideDecorateOrientation : uint8
{
	None,
	Single,				/**< 单独		01 */
	Horizontal,			/**< 水平连续	02 */
	Vertical,			/**< 垂直连续	03 */

	Max,
};


/**
 * @brief 边缘装饰相邻
 */
UENUM()
enum class ECWDecorateAdjacent : uint8
{
	None,
	East,				/**< 与东相邻	01 */
	South,				/**< 与南相邻	02 */
	West,				/**< 与西相邻	03 */
	North,				/**< 与北相邻	04 */

	Max,
};


/**
 * @brief 地形区域地势类型
 */
UENUM()
enum class ECWDungeonRegionTopography : uint8
{
	None		= 0,
	FlatLand	= 1,			/**< 平地	01 */
	HighLand	= 2,			/**< 高地	02 */
	LowLand		= 3,			/**< 洼地	03 */
	Max,
};

/**
 * @brief 地形区域划分
 */
UENUM()
enum class ECWDungeonArea : uint8
{
	RD = 0,
	LD = 1,
	LT = 2,	
	RT = 3,
	Max,
};

/**
 * @brief 地形区域地貌风格
 */
UENUM()
enum class ECWDungeonRegionStyle : uint8
{
	None		= 0,
	Common		= 1,			/**< 通用		01 */
	DarkForest	= 2,			/**< 黑暗森林	02 */

	Max,
};


/**
 * @brief 地形区域地貌空间类型
 */
UENUM()
enum class ECWDungeonRegionSpace : uint8
{
	None = 0,
	Center = 1,			/**< 核心区域	01 */
	Border = 2,			/**< 边际区域	02 */

	Max,
};

/**
 * @brief 地形区域类型
 */
UENUM()
enum class ECWDungeonTileType : uint8
{
	None = 0,
	GoThroughLine = 1,
	Max,
};


/**
 * @brief 地形区域类型
 */
UENUM()
enum class ECWDungeonRegionType : uint8
{
	None = 0,
	SpawnStart = 1,				/**< 出生区域		01 */
	Forbid = 2,					/**< 禁行区域		02 */
	HighSpeed = 3,				/**< 高速区域		03 */
	LowSpeed = 4,				/**< 慢速区域		04 */
	Danger = 5,					/**< 危险区域		05 */
	DangerBlock = 6,			/**< 危险阻塞区域	06 */
	Max,
};


/**
 * @brief 关卡物件层类型
 */
UENUM()
enum class ECWDungeonLogicLayer : uint8
{
	None = 0,
	Surface,
	Item,
	Obstacle,
	Special,
	Max,
};

/**
 * @brief 关卡物件层类型
 */
UENUM()
enum class ECWDungeonFallPhase : uint8
{
	None = 0,
	FallWarn,
	Fall,
	HideFallWarn,
	Max,
};


/** Brief 战斗服务器等待的各种状态
 *
 */
UENUM(BlueprintType)
enum class ECWServerWaitingState : uint8
{
	None,
	Connect			= 2,				/**< 链接 */
	ClusterAuth		= 3,				/**< 族群授权 */
	ClusterVerify	= 4,				/**< 族群验证 */
	RegisterToRoom	= 5,				/**< 注册到房间 */
	Waiting			= 6,				/**< 等待中 */
	Using			= 7,				/**< 使用中 */
};

/** Brief 战斗服务器等待的各种状态的相关事件
 *
 */
UENUM(BlueprintType)
enum class ECWServerWaitingEvent : uint8
{
	None,
	ToConnect			= 2,			/**< 到链接 */
	ToClusterAuth		= 3,			/**< 到族群授权 */
	ToClusterVerify		= 4,			/**< 到族群验证 */
	ToRegisterToRoom	= 5,			/**< 到注册到房间 */
	ToWaiting			= 6,			/**< 到等待中 */
	ToUsing				= 7,			/**< 到使用中 */

	Max
};


/** 玩家发送消息Id */
UENUM()
enum ECWPlayerSendMsgId
{
	ReadyLeastPawnNum	= 1001,
	BattleSiwtchPawn	= 1002,
};


/** 玩家发送消息Id */
UENUM()
enum ECWFlyWordsType
{
	// 增益
	FMT_ReplyComm		= 1000,
	FMT_ReplyHp			= 1001,
	FMT_ReplySp			= 1002,
	FMT_ReplyBuff		= 1003,

	// 伤害
	FMT_DamageComm		= 1100,
	FMT_DamageRefrain	= 1101,
	FMT_DamageCRI		= 1102,

	// 状态
	FMT_StateComm		= 1200,
	FMT_StateAbnormal	= 1201,
	FMT_StateMiss		= 1301,
};


/** 地形加成属性 */
UENUM()
enum ECWTerrainProperty
{
	TP_None,
	/** 地形防御系数(乘) */
	TP_DefinceFactor,
	/** 地形防御叠加(加) */
	TP_Defince,
	/** 地形技巧系数(乘) */
	TP_TalentFactor,
	/** 地形技巧叠加(加) */
	TP_Talent,
	/** 属性限制系数(乘) */
	TP_RestrictFactor,
	/** 属性限制叠加(加) */
	TP_Restrict,
};


/** 绘制曲线网格类型 */
UENUM()
enum class ECWSplineMeshType : uint8
{
	HitMark			= 0,
	MoveArea		= 1,
	AttackArea		= 2,
	MovePath		= 3
};