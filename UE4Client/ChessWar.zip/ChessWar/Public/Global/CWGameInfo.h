#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "UnrealNetwork.h"
#include "Containers/Array.h"
#include "Components/SceneComponent.h"
#include "Global/CWGameDefine.h"
#include <list>
#include <vector>
#include "CWGameInfo.generated.h"



UCLASS()
class ACWGameInfo : public AActor
{
	GENERATED_UCLASS_BODY()
public:
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void Tick(float DeltaTime) override;
public:
	int32 GetGameId();
protected:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	USceneComponent* SceneComponent;

	UPROPERTY(EditAnywhere, Replicated, BlueprintReadWrite)
	int32 GameId;
};