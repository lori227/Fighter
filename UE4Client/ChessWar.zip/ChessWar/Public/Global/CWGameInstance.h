﻿
#pragma once

#include "CoreMinimal.h"
#include "CWGameDefine.h"
#include "Public/Tickable.h"
#include "Engine/GameInstance.h"
#include "CWGameInstance.generated.h"

class UCWManager;
class UCWCfgManager;
class UCWEventMgr;
class UCWUIManager;
class UCWSluaManager;
class UCWWeatherMgr;
class UCWLocalDataMgr;
class UCWAudioVideoMgr;
class UCWLoginModuleInClient;
class UCWTCPServerClient;
class UCWTCPClient;
class UCWNetPlayerDataManager;

/**
 * @brief 游戏实例 \n
 * 游戏全局的管理器
 */
UCLASS(BlueprintType, Blueprintable)
class UCWGameInstance : public UGameInstance, public FTickableGameObject
{
	GENERATED_UCLASS_BODY()

public:
	static UCWGameInstance* GetInstance();

public:
	/** Starts the GameInstance state machine running */
	virtual void StartGameInstance() override;

	virtual void Init() override;
	virtual void Shutdown() override;

	// Begin FTickableGameObject Interface.
	virtual void Tick(float DeltaTime) override;
	inline bool IsTickable(void) const;
	inline TStatId GetStatId(void) const;
	// End FTickableGameObject Interface.

	/** Call to preload any content before loading a map URL, used during seamless travel as well as map loading */
	virtual void PreloadContentForURL(FURL InURL) override;
	virtual void LoadComplete(const float LoadTime, const FString& MapName) override;
	
public:
	UCWCfgManager* GetCfgMgr();
	UCWSluaManager* GetSluaMgr();
	UCWEventMgr* GetEventMgr();
	UCWWeatherMgr* GetWeatherMgr();
	UCWLocalDataMgr* GetLocalDataMgr();
	UCWNetPlayerDataManager* GetNetPlayerDataMgr();
	UCWTCPServerClient* GetTCPServerClient();
	
#if !UE_SERVER
	UCWTCPClient* GetTCPClient();
	UCWLoginModuleInClient* GetLoginModuleInClient();
	UCWUIManager* GetUIMgr();
	UCWAudioVideoMgr* GetAudioVideoMgr();
#endif

public:
	const FString& GetTargetVersionInClient() const;
	void SetTargetVersionInClient(const FString& ParamTargetVersion);

	const FString& GetServerAuthTokenInClient() const;
	void SetServerAuthTokenInClient(const FString& ParamServerAuthToken);

	uint32 GetAccountIdInClient() const;
	void SetAccountIdInClient(uint32 ParamAccountId);

	void SetRoomId(uint64 ParamRoomId);
	uint64 GetRoomId() const;

	void SetRoomServerId(uint64 ParamRoomServerId);
	uint64 GetRoomServerId() const;

	void SetMatchId(uint32 ParamMatchId);
	uint32 GetMatchId() const;

protected:
	void InitCfgMgr();
	void DestroyCfgMgr();

	void InitEventMgr();
	void DestroyEventMgr();

	void InitSluaManager();
	void DestroySluaManager();

	void InitWeatherMgr();
	void DestroyWeatherMgr();

	void InitLocalDataMgr();
	void DestroyLocalDataMgr();

	void InitNetPlayerDataMgr();
	void DestroyNetPlayerDataMgr();

	void InitTCPServerClient();
	void DestroyTCPServerClient();

#if !UE_SERVER
	void InitTCPClient();
	void DestroyTCPClient();

	void InitLoginModuleInClient();
	void DestroyLoginModuleInClient();

	void InitUIManager();
	void DestroyUIManager();

	void InitAudioVideoMgr();
	void DestroyAudioVideoMgr();
#endif

protected:
	static UCWGameInstance* s_this;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FString, TSubclassOf<UCWManager>> ManagerTemplate;

protected:
	UPROPERTY(Transient)
	UCWCfgManager* CfgMgr;

	UPROPERTY(Transient)
	UCWEventMgr* EventMgr;

	UPROPERTY(Transient)
	UCWSluaManager* SluaManager;

	UPROPERTY(Transient)
	UCWWeatherMgr* WeatherMgr;

	UPROPERTY(Transient)
	UCWLocalDataMgr* LocalDataMgr;

	UPROPERTY(Transient)
	UCWLoginModuleInClient* LoginModule;

	UPROPERTY(Transient)
	UCWNetPlayerDataManager* NetPlayerDataMgr;

	UPROPERTY(Transient)
	UCWTCPServerClient* TCPServerClient;
	
	UPROPERTY(Transient)
	UCWTCPClient* TCPClient;
	//------------------------------------
	//客户端数据
	UPROPERTY(Transient)
	FString TargetVersionInClient;

	UPROPERTY(Transient)
	FString ServerAuthTokenInClient;

	UPROPERTY(Transient)
	uint32 AccountId;
	//------------------------------------
	//战斗服务器数据
	uint64 RoomId;
	uint64 RoomServerId;
	uint32 MatchId;
	//------------------------------------
protected:
	UPROPERTY(Transient)
	UCWUIManager* UIManager;

	UPROPERTY(Transient)
	UCWAudioVideoMgr* AudioVideoMgr;

protected:
	bool m_bEnableTick;
	TStatId m_TStatId;

};
