﻿#pragma once

#include "CoreMinimal.h"
#include "CWGameDefine.h"
#include "UnrealNetwork.h"
#include "CWPlayerNetData.h"
#include "GameFramework/GameState.h"
#include "CWGameState.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBattleStateChangedDelegate, const ECWBattleState&, ParamOldBattleState, const ECWBattleState&, ParamCurBattleState);


class ACWPlayerController;

/**
 * @brief 游戏状态 \n
 * 每局游戏的状态信息
 */
UCLASS()
class ACWGameState : public AGameState
{
	GENERATED_UCLASS_BODY()

public:
	virtual void BeginPlay() override;

public:
	/** 每回合开始,数据重置
	 * @param	无
	 * @return	无
	 */
	void ResetWhenNextTurnBeginInServer();


	/** 设置当前网络玩家个数
	 * @param	ECWBattleState 战斗状态
	 * @return	无
	 */
	void SetCurNetPlayerCount(int32 NetPlayerCount);


	/** 获得当前网络玩家个数
	 * @param	无
	 * @return  ECWBattleState 战斗状态
	 */
	int32 GetCurNetPlayerCount() const;
	

	/** 设置当前战斗状态
	 * @param	ECWBattleState 战斗状态
	 * @return	无
	 */
	void SetCurBattleState(ECWBattleState BattleState);


	/** 获得当前战斗状态
	 * @param	无
	 * @return  ECWBattleState 战斗状态
	 */
	ECWBattleState GetCurBattleState() const;


	/** 设置当前战前准备的剩余时间
	 * @param	float	准备剩余时间（单位:秒）
	 * @return  无
	 */
	void SetCurReadyRemainTime(float InReadyRemainTime);

	/** 获得当前战前准备的剩余时间
	 * @param	无
	 * @return  float	准备剩余时间（单位:秒）
	 */
	float GetCurReadyRemainTime() const;


	/** 设置当前已经进行了的回合数
	 * @param	int32	回合数
	 * @return	无
	 */
	void SetCurRoundIndex(int32 RoundIndex);


	/** 获得当前已经进行了的回合数
	 * @param	无
	 * @return  int32	回合数
	 */
	UFUNCTION(BlueprintPure)
	int32 GetCurRoundIndex() const;


	/** 设置当前已经进行了的地形格子下落的次数
	 * @param	int32	地形格子下落的次数
	 * @return	无
	 */
	void SetCurDungeonTileFallIndex(int32 ParamCurDungeonTileFallIndex);


	/** 获得当前已经进行了的地形格子下落的次数
	 * @param	无
	 * @return  int32	地形格子下落的次数
	 */
	int32 GetCurDungeonTileFallIndex() const;


	/** 设置当前行动的阵营的标签
	 * @param	ECWCampTag	行动的阵营的标签
	 * @return  无
	 */
	void SetCurCampTag(ECWCampTag CampTag);


	/** 获得当前行动的阵营的标签
	 * @param	无
	 * @return  ECWCampTag	行动的阵营的标签
	 */
	ECWCampTag GetCurCampTag() const;


	/** 设置当前行动的控制器的下标
	* @param	ECWControllerPawnIndex	当前行动的控制器的下标
	* @return	无
	*/
	void SetCurCampControllerIndex(ECWCampControllerIndex ParamCampControllerIndex);


	/** 获得当前行动的控制器的下标
	* @param	无
	* @return	ECWCampControllerIndex	当前行动的控制器的下标
	*/
	ECWCampControllerIndex GetCurCampControllerIndex() const;


	/** 设置当前行动剩余时间
	 * @param	float	行动剩余时间（单位:秒）
	 * @return  无
	 */
	void SetCurActionRemainTime(float ActionRemainTime);


	/** 获得当前行动剩余时间
	 * @param	无
	 * @return  float	行动剩余时间（单位:秒）
	 */
	float GetCurActionRemainTime() const;

	/** 玩家准备数据 */
	void ServerPlayerReadyStateChange(ACWPlayerController* Player, bool bReadyOk);
	int32 GetCurReadyOkPlayerCnt() const;

	bool IsInServer() const;

	/** 获取胜利阵营
	 * @param	无
	 * @return	ECWCampTag 胜利阵营
	 */
	ECWCampTag GetWinCamp() const;


	/** 获得本地玩家战斗结果
	 * @param	无
	 * @return	ECWBattleResult 本地玩家战斗结果
	 */
	ECWBattleResult GetLocalPlayerFightResult() const;


	/** 获得棋子移动模式
	 * @param	无
	 * @return	ECWPawnMoveMode 棋子移动模式
	 */
	ECWPawnMoveMode GetPawnMoveMode();


	/** 设置棋子移动模式
	 * @param	ECWPawnMoveMode 棋子移动模式
	 * @return	无
	 */
	void SetPawnMoveMode(ECWPawnMoveMode ParamPawnMoveMode);


	//~ Begin pause game
	bool IsPauseGame() const;

	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSetPauseGame(bool bNewPause);
	//void ServerSetPauseGame_Implementation(bool bNewPause);

	//~ Weather 
	virtual int32 GetWeatherIdx() const;
	virtual int32 GetOldWeatherIdx() const;
	UFUNCTION(BlueprintCallable)
	virtual int32 GetNextWeatherIdx() const;

	//~ Game config
	int32 GetDefaultPawnCnt() const;
	int32 GetMinStagePawnCnt() const;
	int32 GetMaxStagePawnCnt() const;

	/** 执行天气检测(回合变化) */
	virtual void ExecWeatherCheckInServer();

	/** Times */
	void SetMaxReadyTime(const float InValue);
	float GetMaxReadyTime();
	void SetMaxActionTime(const float InValue);
	float GetMaxActionTime();

	virtual void SetCampANum(int Companion);
	virtual void SetCampBNum(int Enermy);
	virtual int32 GetCampANum();
	virtual int32 GetCampBNum();

	const TArray<FCWPlayerNetData>& GetPlayerDataArray();
	void AddPlayerDataToArray(FCWPlayerNetData InPlayerData);

public:
	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastRPCResult(ECWCampTag ParamWinCampTag);

	UFUNCTION(NetMulticast, Reliable)
	void NetMulticastReadyStateChange(int32 Pid, bool bReadyFinished);

	UFUNCTION(NetMulticast, Reliable)
	virtual void NetMulticastLevelSiteDrop(const bool bStarted, const int32 InFallIdx);

protected:
	//~ Begin Replication Notification Callbacks
	UFUNCTION()
	virtual void OnRep_CurNetPlayerCount();

	UFUNCTION()
	void OnRep_BattleStateChangedInClient();

	UFUNCTION()
	void OnRep_ClientRoundCamp();

	UFUNCTION()
	void OnRep_ClientRoundTime();

	UFUNCTION()
	void OnRep_ReadyRemainTime();

	UFUNCTION()
	void OnRep_RoundIndex();

	UFUNCTION()
	void OnRep_DungeonTileFallIndex();

	UFUNCTION()
	virtual void OnRep_WeatherIdx(int32 InOldWeatherIdx);

	UFUNCTION()
	virtual void OnRep_NextWeatherIdx();

	UFUNCTION()
	virtual void OnRep_CampANum();

	UFUNCTION()
	virtual void OnRep_CampBNum();

	UFUNCTION()
	virtual void OnRep_ClientPawnMoveMode();

	UFUNCTION()
	virtual void OnRep_PlayerDataArray();

	UFUNCTION()
	virtual void OnLandEarlyWarn(const bool bStart, const int32 InWarnIdx);
	//~ End Replication Notification Callbacks

public:
	UPROPERTY(BlueprintAssignable, Category = "CWGameState")
	FBattleStateChangedDelegate OnBattleStateChangedEventInServer;

	UPROPERTY(BlueprintAssignable, Category = "CWGameState")
	FBattleStateChangedDelegate OnBattleStateChangedEventInClient;

protected:
	int32 GetGameId();
	bool IsFallWarningInClient();
	void FallWarningInClient();

private:
	UPROPERTY(Replicated)
	uint32 bPauseGame : 1;

	/** 当前网络玩家个数 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_CurNetPlayerCount)
	int32 CurNetPlayerCount;

	/** 当前已准备网络玩家 */
	UPROPERTY()
	TArray<ACWPlayerController*> CurNetPlayerReadyArr;

	/** 当前战斗状态 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_BattleStateChangedInClient)
	ECWBattleState CurBattleState;

	/** 老的战斗状态 */
	UPROPERTY(Replicated)
	ECWBattleState OldBattleState;

	/** 最大战前准备时间 */
	UPROPERTY(Replicated)
	float MaxReadyTime;

	/** 最大行动时间 */
	UPROPERTY(Replicated)
	float MaxActionTime;

	/** 当前战前准备的剩余时间 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ReadyRemainTime)
	float CurReadyRemainTime;

	/** 当前行动剩余时间 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ClientRoundTime)
	float CurActionRemainTime;

	/** 当前已经进行了的回合数 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_RoundIndex)
	int32 CurRoundIndex;

	/** 当前已经进行了地形掉落的次数 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_DungeonTileFallIndex)
	int32 CurDungeonTileFallIndex;

	/** 当前行动的阵营的标签 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ClientRoundCamp)
	ECWCampTag CurCampTag;

	/** 当前行动的控制器的下标 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ClientRoundCamp)
	ECWCampControllerIndex CurCampControllerIndex;

	/** 当前行动的棋子的下标 */
	UPROPERTY(Replicated)
	int32 CurPawnIndex;

	UPROPERTY(Transient)
	ECWCampTag WinCampTag;

	/** 天气索引 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_WeatherIdx)
	int32 CurWeatherIdx;
	UPROPERTY(Replicated)
	int32 OldWeatherIdx;
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_NextWeatherIdx)
	int32 NextWeatherIdx;

	UPROPERTY(Replicated, ReplicatedUsing = OnRep_CampANum)
	int32 CampANum;
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_CampBNum)
	int32 CampBNum;

	/** 棋子移动模式 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_ClientPawnMoveMode)
	ECWPawnMoveMode PawnMoveMode;

	/** 玩家信息列表 */
	UPROPERTY(Replicated, ReplicatedUsing = OnRep_PlayerDataArray)
	TArray<FCWPlayerNetData> PlayerDataArray;
};
