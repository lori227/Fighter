﻿
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Logging/LogMacros.h"

#include "CWGameDefine.h"
#include "CWStructDefine.generated.h"


/**
 *	@brief	Game mode data
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FGameModeData
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY()
	ECWGameStage GameStage;
};


/**
 *	@brief	Battle Property Key-Value
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FBattlePropertyData
{
	GENERATED_USTRUCT_BODY()

public:
	FBattlePropertyData() = default;
	virtual ~FBattlePropertyData() = default;

	virtual bool IsValid() const;
	virtual FString ToString() const;

public:
	// 属性类型
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	ECWBattleProperty PropertyKey;

	// 属性百分比系数
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float PropertyFactor;

	// 属性值
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float PropertyValue;
};


/** 地形属性 Pair(Key-Value) */
USTRUCT(BlueprintType)
struct FCWTerrainPropertyData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWTerrainPropertyData() = default;
	virtual ~FCWTerrainPropertyData() = default;

	virtual bool IsValid() const;
	virtual FString ToString() const;

public:
	// 属性类型
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TEnumAsByte<ECWTerrainProperty> Key;

	// 属性百分比系数
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float Factor;

	// 属性值
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float Value;
};

/** 飘字信息 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWFlyWorldsNumber
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY()
	APawn* FlyWorldsPawn;

	UPROPERTY()
	int32 FlyWorldsType;

	UPROPERTY()
	int32 FlyWorldsValue;

	UPROPERTY()
	FString FlyWorldsParam;

	UPROPERTY()
	FVector WorldPosition;

	UPROPERTY()
	float Scale;

	UPROPERTY()
	float SecondTime;

public:
	FCWFlyWorldsNumber()
		: FlyWorldsPawn(NULL), FlyWorldsType(0), FlyWorldsValue(0), FlyWorldsParam(TEXT("")), WorldPosition(FVector(0.f)), Scale(1.f), SecondTime(0.f)
	{
	}

	FCWFlyWorldsNumber(APawn* InPawn, int32 InType, int32 InValue, const FString& InParam, FVector InLoc, float InScale, float InTime)
		: FlyWorldsPawn(InPawn), FlyWorldsType(InType), FlyWorldsValue(InValue), FlyWorldsParam(InParam), WorldPosition(InLoc), Scale(InScale), SecondTime(InTime)
	{
	}

public:
	/** 获取飘字颜色 */
	FLinearColor GetFlyWorldsColor(float InNewAlpha);

};


/** Fringe Define */
USTRUCT(BlueprintType)
struct FIntFringe
{
	GENERATED_USTRUCT_BODY()
public:
	FIntFringe();
	FIntFringe(const FIntFringe& InOther);
	FIntFringe(const FIntVector& InBeginPoint, 
		const FIntVector& InEndPoint, const int32 InIntParam, const FString& InStrParam);

	FIntFringe& operator =(const FIntFringe& InOther);
	bool operator ==(const FIntFringe& InOther);
	friend bool operator == (const FIntFringe& InLeft, const FIntFringe& InRight);

	bool IsValid() const;
	FString ToString() const;
	bool IsNearPointXY(const FIntFringe& InOther, int32 ErrorTolerance = 0) const;

public:
	FIntVector BeginPoint;
	FIntVector EndPoint;
	FString StringParam;
	int32 IntParam;

};


/** ToString */
struct FCWToString 
{
public:
	FCWToString() {}
	virtual ~FCWToString() {}

public:
	static FString ToString(const ECWSkillSouceType InEnumType);
	static FString ToString(const ECWBuffSouceType InEnumType);
	static FString ToString(const ECWBattleProperty InEnumType);
	static FString ToString(const ECWPawnActionState InEnumType);
	static FString ToString(const ECWBattlePropertyModifyOp InEnumType);
	static FString ToString(const ECWPropertyAffectorDataAffectType InEnumType);

	static FString ToString(const ECWPawnInputState InEnumType);

};
