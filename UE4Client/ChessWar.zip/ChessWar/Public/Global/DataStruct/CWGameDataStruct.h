﻿
#pragma once

#include "Engine.h"
#include "CWGameDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWGameDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWGameDataStruct();
	virtual ~FCWGameDataStruct();
public:

	/** GameId */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 GameId;

	/** 地图Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 DungeonId;

	/** 第一次DungeonTile掉落的回合数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 FirstDungeonTileFallRoundIndex;

	/** DungeonTile掉落的间隔回合数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 DungeonTileFallRoundInterval;

	/** DungeonTile掉落的最大次数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 DungeonTileFallCountMax;

	/** DungeonTile掉落的时间间隔 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	float DungeonTileFallInterval;

	/** DungeonTile上升的时间随机范围 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	FString DungeonTileRiseRandomMinMax;

	/** DungeonTile上升的起始高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	float DungeonTileRiseBeginZ;

	/** DungeonTile上升的起始速度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	float DungeonTileRiseBeginSpeed;

	/** DungeonTile上升的减速度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	float DungeonTileRiseDeceleration;

	///////////////////////////////////////////////////////////////////////////
	/** 安全区起始X坐标 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 SafeAreaMinX;

	/** 安全区起始Y坐标 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 SafeAreaMinY;

	/** 安全区结束X坐标 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 SafeAreaMaxX;

	/** 安全区结束Y坐标 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 SafeAreaMaxY;

	/** 每回合掉落块数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	int32 EachRoundFallNum;

	/** 地块掉落延时时间(FirstTime|OtherTime) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "GameDataStruct")
	FString LandFallDelay;
	///////////////////////////////////////////////////////////////////////////
};