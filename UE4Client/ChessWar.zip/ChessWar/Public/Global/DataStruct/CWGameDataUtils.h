#pragma once

#include <list>
#include <vector>
#include "CWGameDefine.h"


class FCWGameDataUtils
{
public:

	/** 从字符串解析出DungeonTile上升的时间随机范围
	 * @param	const FString&	字符串
	 * @return  std::vector<float>	DungeonTile上升的时间随机范围
	 */
	static std::vector<float> GetArrayDungeonTileRiseRandomMinMaxFromString(const FString& ParamString);
};