﻿
#pragma once

#include "CWGameModeBase.h"
#include "CWGMEmptyServer.generated.h"

/**
 * Dedicated server "empty shell" for advertising that this server is available to host a game.
 */
UCLASS()
class CHESSWAR_API ACWGMEmptyServer : public ACWGameModeBase
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWGMEmptyServer();

public:
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual void InitGameState() override;

};
