﻿
#pragma once

#include "CWGameModeBase.h"
#include "CWGMLogin.generated.h"


UCLASS()
class CHESSWAR_API ACWGMLogin : public ACWGameModeBase
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWGMLogin() {}

public:
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;

};
