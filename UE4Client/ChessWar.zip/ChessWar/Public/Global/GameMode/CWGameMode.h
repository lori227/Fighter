﻿
#pragma once

#include "CWGameModeBase.h"
#include "CWGameInstance.h"
#include "Pawn/CWPawnKey.h"
#include "CWGameMode.generated.h"


class ACWCameraPawn;
class ACWGameState;
class UCWBattleFSM;
class ACWMap;
class UCWGameInstance;
class ACWGameState;
class ACWPlayerController;
class UCWBattleFightingFSM;
class ACWGameInfo;
struct FCWGameDataStruct;
class ACWRandomDungeonGenerator;
struct FCWDungeonDataStruct;
class UCWNetMessage;


DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBattleAfterSetupMapDelegate);

/**
 * @brief 游戏模式 \n
 * 每局游戏的规则
 */
UCLASS()
class ACWGameMode : public ACWGameModeBase
{
	GENERATED_UCLASS_BODY()

public:
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual void PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage) override;
	virtual APlayerController* Login(UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage);
	virtual void PostLogin(APlayerController* NewPlayer) override;
	virtual UClass* GetDefaultPawnClassForController_Implementation(AController* InController) override;
	virtual AActor* ChoosePlayerStart_Implementation(AController* Player) override;
	virtual void Logout(AController* Exiting) override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void StartPlay() override;
	virtual void Destroyed() override;

protected:
	// ~ Begin Player Login
	virtual void OnPlayerLoginBegin(APlayerController* NewPlayer, const FString& Options) override;
	virtual void OnPlayerLoginCompleted(APlayerController* NewPlayer) override;
	// ~ Begin Player Login 

public:

	static ACWGameMode* s_this;
	static bool ProcessReceiveMessage(UCWNetMessage* ParamNetMsg);

public:
	/** 获得游戏的实例
	 * @param	无
	 * @return  UCWGameInstance*	游戏的实例
	 */
	UCWGameInstance* GetCWGameInstance();


	/** 加载游戏规则配置
	 * @param	无
	 * @return  无
	 */
	void LoadConfig();


	/** 创建游戏状态参数
	 * @param	无
	 * @return  无
	 */
	void SetupGameStateParams();


	/** 获得游戏Id
	 * @param	无
	 * @return  无
	 */
	int32 GetGameId();


	/** 创建战斗状态机
	 * @param	无
	 * @return  无
	 */
	void SetupBattleFSM();


	/** 创建战斗状态机
	 * @param	无
	 * @return  无
	 */
	void SetupBattleFightingFSM();


	/** 创建地图
	 * @param	无
	 * @return  无
	 */
	void SetupMapForServer();


	/** 创建地随机地图
	 * @param	无
	 * @return  无
	 */
	void SetupRandomGungeonForServer();


	/** 创建地随机地图
	 * @param	无
	 * @return  无
	 */
	void SetupRandomGungeonForClient();


	/** 创建首回合信息
	 * @param	无
	 * @return  无
	 */
	void SetupFirstTurnInfo();


	/** 生成网络玩家唯一Id
	 * @param	无
	 * @return	int32	网络玩家唯一Id
	 */
	int32 GenerateNetPlayerUniqueId();

	/** 获得阵营数
	 * @param	无
	 * @return	int32	阵营数
	 */
	int32 GetCampCount() const;


	/** 获得战前准备时间
	 * @param	无
	 * @return	float	战前准备时间
	 */
	float GetReadyTime() const;


	/** 获得总回合数
	 * @param	无
	 * @return	int32	总回合数
	 */
	int32 GetTotalRoundCount() const;


	/** 获得行动时间
	 * @param	无
	 * @return	int32	行动时间
	 */
	float GetActionTime() const;


	/** 获得PlayerController
	 * @param	ECWCampTag	阵营
	 * @param	ECWCampControllerIndex	阵营控制器下标
	 * @return	ACWPlayerController*	获得PlayerController
	 */
	ACWPlayerController* GetPlayerControllerByCampTagAndControllerIndex(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);


	/** 设置敌方人数和我方人数
	 * @param	无
	 * @return	无
	 */
	void SetCampNum();


	/** 某玩家此回合行为强行结束
	 * @param	ECWCampTag	玩家控制器的阵营
	 * @param	ECWCampControllerIndex	玩家控制器的下标
	 * @return	无
	 */
	void SomePlayerControllerForceActionEnd(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);


	/** 某玩家此回合行为结束
	 * @param	ACWPlayerController*	玩家控制器
	 * @return	无
	 */
	bool TryNext(ACWPlayerController* ParamPlayerController);


	/** 某玩家地形处理结束
	 * @param	无
	 * @return	无
	 */
	void SomePlayerControllerDungeonEnd();


	/** 某玩家此回合行为结束
	 * @param	ACWPlayerController*	玩家控制器
	 * @return	无
	 */
	void SomePlayerControllerDieEnd(ACWPlayerController* ParamPlayerController);
	

	/** 某玩家此回合行为结束
	 * @param	无
	 * @return	无
	 */
	void CurWaitingEndPlayerControllerActionEnd();


	/** 下一个回合
	 * @param	无
	 * @return	无
	 */
	void NextTurn();


	/** 下一个回合
	 * @param	无
	 * @return	无
	 */
	void GungeonTileFallEndAndNextTurnBegin();


	/** 当前回合结束
	 * @param	无
	 * @return	无
	 */
	void TurnEnd();


	/** 获得游戏有限状态机
	 * @param	无
	 * @return	UCWBattleFSM* 游戏有限状态机
	 */
	UCWBattleFSM* GetBattleFSM();


	/** 获得战斗有限状态机
	 * @param	无
	 * @return	UCWBattleFightingFSM* 战斗有限状态机
	 */
	UCWBattleFightingFSM* GetBattleFightingFSM();


	/** 跳转到等待当前操作方行动结束
	 * @param	无
	 * @return	无
	 */
	void ToWaitingEndState();


	/** 生成网络 Pawn idx
	 * @param	无
	 * @return	int32 Pawn idx
	 */
	int32 GenerateNetPawnUniqueIdx();


	/** 地形格子掉落
	 * @param	无
	 * @return	无
	 */
	void GenerateGungeonTileFall();


	/** 所有刷新位置
	 * @param	无
	 * @return	无
	 */
	void RefreshAllLocation();

public:
	UPROPERTY(BlueprintCallable, Category = "CWGameMode")
	FBattleAfterSetupMapDelegate OnBattleAfterSetupMapEventInServer;

	UFUNCTION()
	void RespondBattleStateChangedEventInServer(const ECWBattleState& ParamOldBattleState, const ECWBattleState& ParamCurBattleState);

	UFUNCTION()
	void RespondDungeonTileFallFinishInServer(const int32 ParamCurDungeonTileFallIndex);

protected:
	// 生成动态关卡对象
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "CWGameMode")
	void GenerateLevelMsicObj();

	// 关卡场地掉落开始
	UFUNCTION(BlueprintNativeEvent, Category = "CWGameMode")
	void OnLevelSiteDropStart();

	// 关卡场地掉落完成
	UFUNCTION(BlueprintNativeEvent, Category = "CWGameMode")
	void OnLevelSiteDropComplete(const int32 Cycles = 1, const float ChangeDis = -126.0f);
	
public:
	bool DoNetMessage(const UCWNetMessage* ParamNetMessage);

	bool IsSameCampAllControllerActionEnd(ECWCampTag ParamCampTag);
	bool IsSameCampAllControllerDieEnd(ECWCampTag ParamCampTag);
	bool IsSameCampAllControllerDungeonEnd(ECWCampTag ParamCampTag);
	bool IsCampControllerActionEnd(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);
	void SameCampNextControllerAction(ECWCampTag ParamCampTag);
	void SameCampAllControllerTurnEnd(ECWCampTag ParamCampTag);
	bool IsAllCampActionEnd();
	bool IsAllCampDieEnd();
	bool IsAllCampDungeonEnd();
	void NextCampAction();
	void SomeCampControllerFirstAction(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);
	bool IsGungeonTileFallGenerate();
	ACWRandomDungeonGenerator* GetRandomDungeonGenerator();

	//------------------------------------------------------
	bool IsAllCampArrayActionEmpty();
	bool IsSameCampAllControllerArrayActionEmpty(ECWCampTag ParamCampTag);
	int32 GetCampNoDieCount(ECWCampTag& ParamOutCampTag);
	bool HandleRoundResult();
	//------------------------------------------------------
private:
	/** 每回合开始,数据重置
	 * @param	无
	 * @return	无
	 */
	void ResetWhenNextTurnBeginInServer();


	/** 获得GameData数据
	 * @param	无
	 * @return	FCWGameDataStruct* GameData数据
	 */
	FCWGameDataStruct* GetGameDataStruct();

private:
	void HearbeatToServer();
private:

	UPROPERTY()
	int32 NetPlayerCount;

	/** 此局阵营数(读配置) */
	UPROPERTY(config)
	int32 CampCount;

	/** 战前准备时间(读配置) */
	UPROPERTY(config)
	float ReadyTime;

	/** 总回合数(读配置) */
	UPROPERTY(config)
	int32 TotalRoundCount;

	/** 行动时间(读配置) */
	UPROPERTY(config)
	float ActionTime;

	/** 玩家唯一Id生成器 */
	UPROPERTY()
	int32 NetPlayerUniqueIdGenerater;

	/** 战斗有限状态机 */
	UPROPERTY()
	UCWBattleFSM* BattleFSM;

	UPROPERTY()
	UCWBattleFightingFSM* BattleFightingFSM; 

	/** 战斗地图 */
	UPROPERTY()
	ACWMap* BattleMap;

	bool bIsCreated;

	UPROPERTY()
	ACWRandomDungeonGenerator* RandomDungeonGenerator;

	int32 NetPawnUniqueIdxGenerater;

	float RunningHeartbeatTime;
};
