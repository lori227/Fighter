﻿
#pragma once

#include "CWStructDefine.h"
#include "GameFramework/GameMode.h"
#include "CWGameModeBase.generated.h"

class ACWPlayerController;
class ACWPlayerControllerBase;

/**
 *
 */
UCLASS()
class CHESSWAR_API ACWGameModeBase : public AGameMode
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWGameModeBase();

public:
	virtual void PreInitializeComponents() override;

	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual void PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage) override;
	virtual APlayerController* Login(UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage);
	virtual void PostLogin(APlayerController* NewPlayer) override;

public:
	// Kick player
	virtual void KickPlayerToLobby(APlayerController* PC, const FString& Reason);
	virtual void KickAllPlayersToLobby(const FString& Reason);

	// Net Mode
	bool IsServer() const;
	bool IsDedicatedServer() const;
	bool IsStandalone() const;

protected:
	// ~ Begin Player Login
	virtual void OnPlayerLoginBegin(APlayerController* NewPlayer, const FString& Options);
	virtual void InitPlayerBaseData(ACWPlayerControllerBase* NewPlayer, const FString& Options);

	virtual void OnPlayerLoginCompleted(APlayerController* NewPlayer);
	virtual void InitPlayerExtraData(ACWPlayerControllerBase* NewPlayer);

	// ~ Begin Player Login 

	// Never allow the engine to start replays, we'll do it manually
	bool IsHandlingReplays() override { return false; }

protected:
	FGameModeData GameModeDateBase;

};
