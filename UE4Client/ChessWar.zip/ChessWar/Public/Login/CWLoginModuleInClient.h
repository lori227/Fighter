#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "Online/HTTP/Public/HttpModule.h"
#include "Global/CWGameDefine.h"
#include "CWLoginModuleInClient.generated.h"

class UCWLoginFSM;
class UCWGameInstance;
struct FCWClientVersionDataStruct;

/**
 * @brief 客户端登陆逻辑模块 \n
 *
 */
UCLASS()
class UCWLoginModuleInClient : public UObject
{
	GENERATED_UCLASS_BODY()
public:

	bool Init(UCWGameInstance* InGI);
	void Destroy();

	bool Start();
	void Finish();
	void OnLevelLoadComplete(const float LoadTime, const FString& MapName);


	UFUNCTION()
	void OnPlayerLoginCompleted(const FGameModeData GameModeData);

private:

	void SetupLoginFSM();
	FCWClientVersionDataStruct* GetLocalClientVersionData();

private:
	/** 登陆有限状态机 */
	UPROPERTY()
	UCWLoginFSM* LoginFSM;

	UPROPERTY()
	UCWGameInstance* GI;
};
