#pragma once
#include "Engine.h"
#include "CWClientVersionDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWClientVersionDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWClientVersionDataStruct();
	virtual ~FCWClientVersionDataStruct();
public:

	/** 客户端基础版本 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "ClientVersionDataStruct")
	FString ClientBaseVersion;

	/** 版本Json的URL */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "ClientVersionDataStruct")
	FString VersionJsonUrl;
};