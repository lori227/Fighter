#pragma once
#include "Engine.h"
#include "CWServerInfoDataStruct.generated.h"

USTRUCT(BlueprintType)
struct FCWServerInfoDataStruct : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	FCWServerInfoDataStruct();
	virtual ~FCWServerInfoDataStruct();
public:

	/** ��������Ȩ��URL */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "ServerInfoDataStruct")
	FString ServerAuthUrl;
};