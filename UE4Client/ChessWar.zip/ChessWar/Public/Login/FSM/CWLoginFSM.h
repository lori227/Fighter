#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "CWFSM.h"
#include "CWLoginFSM.generated.h"

class UCWGameInstance;

/**
 * @brief 客户端登陆有限状态机 \n
 *
 */
UCLASS()
class UCWLoginFSM : public UCWFSM
{
	GENERATED_UCLASS_BODY()
public:

	void Init(UCWGameInstance* InGI);
	UCWGameInstance* GetCWGameInstance();
protected:

	UPROPERTY()
	UCWGameInstance* GI;
};