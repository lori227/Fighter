#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Engine.h"
#include "Global/CWGameDefine.h"
#include "FSM/CWFSMEvent.h"
//#include "CWFSMEvent.generated.h"

class FCWLoginToServerAuthEvent : public FCWFSMEvent
{
public:
	/** ���캯��
	 * @param	��
	 * @return	��
	 */
	FCWLoginToServerAuthEvent();


	/** ���캯��
	 * @param	int	�¼�Id
	 * @param	int	Ŀ��״̬Id
	 * @param	EFSMStackOperation	ջ����
	 * @return	��
	 */
	FCWLoginToServerAuthEvent(int ParamEventId, int ParamToStateId, ECWFSMStackOp ParamStackOp);
};