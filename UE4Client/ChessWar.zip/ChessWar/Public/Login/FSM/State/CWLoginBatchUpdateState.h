
#pragma once

#include "CWFSMState.h"
#include "CoreMinimal.h"
#include "Engine.h"
#include "UnrealNetwork.h"
#include "Online/HTTP/Public/HttpModule.h"
#include "Global/CWGameDefine.h"

struct FCWClientVersionDataStruct;

/**
 * @brief 登陆有限状态机里的补丁更新状态 \n
 */
class FCWLoginBatchUpdateState : public FCWFSMState
{
public:

	/** 构造函数
	 * @param	UCWFSM*	状态机
	 * @param	int	状态Id
	 * @return	无
	 */
	FCWLoginBatchUpdateState(UCWFSM* ParamParent, int ParamStateId);


	/** 是否这个事件能发生状态转移
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual bool CanTranstion(const FCWFSMEvent* Params) override;


	/** 进入状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnEnter(const FCWFSMEvent* Params) override;


	/** 退出状态
	 * @param	const FCWFSMEvent&	引起状态转变的事件
	 * @return	无
	 */
	virtual void OnExit(const FCWFSMEvent* Params) override;


	/** 处理事件
	 * @param	const FCWFSMEvent&	事件
	 * @return	无
	 */
	virtual void DoEvent(const FCWFSMEvent* Params) override;


	/** 帧处理
	 * @param	float	帧间隔
	 * @return	无
	 */
	virtual void Tick(float DeltaTime);

public:
	void GetPatchPakFromHttp();

	void OnRequestComplete(FHttpRequestPtr ParamHttpRequest, FHttpResponsePtr ParamHttpResponse, bool ParamSucceeded);
	void OnRequestProgress(FHttpRequestPtr ParamHttpRequest, int32 ParamBytesSent, int32 ParamBytesReceived);

protected:
	FCWClientVersionDataStruct* GetLocalClientVersionData();
	void SetTargetVersionToGameInstanceInClient(const FString& ParamTargetVersion);
private:
	FString PatchPakFinalUrl;
	FString TargetVersion;
	FString VersionJsonContent;
};
