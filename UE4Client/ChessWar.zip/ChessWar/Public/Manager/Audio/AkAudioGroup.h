﻿
#pragma once

#include "Engine/GameEngine.h"
#include "AkAudioGroup.generated.h"

/*------------------------------------------------------------------------------------
	UAkAudioGroup
------------------------------------------------------------------------------------*/
UCLASS(meta = (BlueprintSpawnableComponent))
class CHESSWAR_API UAkAudioGroup : public UObject
{
	GENERATED_BODY()

};
