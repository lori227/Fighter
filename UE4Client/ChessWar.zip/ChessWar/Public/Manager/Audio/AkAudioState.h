﻿
#pragma once

#include "Engine/GameEngine.h"
#include "AkAudioState.generated.h"

/*------------------------------------------------------------------------------------
	UAkAudioState
------------------------------------------------------------------------------------*/
UCLASS(meta = (BlueprintSpawnableComponent))
class CHESSWAR_API UAkAudioState : public UObject
{
	GENERATED_BODY()

};
