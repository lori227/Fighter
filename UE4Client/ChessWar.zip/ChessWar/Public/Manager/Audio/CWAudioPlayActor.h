﻿
#pragma once

#include "CoreMinimal.h"
#include "CWAudioVideoDef.h"
#include "GameFramework/Actor.h"
#include "CWAudioPlayActor.generated.h"


UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API ACWAudioPlayActor : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~ACWAudioPlayActor();
	virtual bool Init(const ECWAudioType InType);

	virtual bool IsAudioType(const ECWAudioType InType) const;

protected:
	UPROPERTY(EditAnywhere)
	TEnumAsByte<ECWAudioType> AudioType;

};
