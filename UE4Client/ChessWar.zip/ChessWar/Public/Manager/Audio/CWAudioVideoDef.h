﻿
#pragma once

#include "CoreMinimal.h"
#include "CWAudioVideoDef.generated.h"

class UAkComponent;

// 声音播放对象类型
UENUM()
enum ECWAudioType
{
	AudioType_None,

	// 天气
	AT_Weather,
	// 时间段
	AT_TimePhases,
	// 关卡杂项(石头掉落...)
	AT_LevelMisc,
	// 游戏角色
	AT_GamePawn,
	// 背景音乐(2D)
	AT_BgMusic,
	// 界面声音(2D)
	AT_UISound,
	// 主音频
	AT_MainAudio,

	AT_Max UMETA(Hidden)
};


// 声音设置类型
UENUM(BlueprintType, Blueprintable)
enum class EAudioSetType : uint8
{
	// 环境
	AST_Env,
	// 音乐
	AST_Music,
	// 音效
	AST_Sound,
	// 语音
	AST_Voice,
	// 总音量
	AST_Master
};


// 声音操作类型
UENUM(BlueprintType, Blueprintable)
enum class ECWAudioOpType : uint8
{
	OT_Play,
	OT_Switch,
	OT_Stop,
};


USTRUCT(BlueprintType, Blueprintable)
struct FCWAudioEvtData
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	TEnumAsByte<ECWAudioType> AudioType;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	ECWAudioOpType OpType;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	FString Event;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	FString Group;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	FString State;

};


USTRUCT(BlueprintType, Blueprintable)
struct FCWAudioPlayData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWAudioPlayData();
	FCWAudioPlayData(UAkComponent* InAkComp, const FString& InEvt, 
		const bool bInStop, const ECWAudioType Type, const uint32 InPlayingID);

	FCWAudioPlayData(UAkComponent* InAkComp, const uint32& InEvtId);
	virtual ~FCWAudioPlayData() {}

public:
	// 总是播放事件
	virtual bool IsAlwaysPlay() const;
	virtual bool IsNeedAwaken() const;

	virtual bool IsStop() const;
	virtual bool IsDiffer(const FString& InEvt) const;

public:
	//TWeakObjectPtr<AActor> Acotr;
	TWeakObjectPtr<UAkComponent> AkComp;

	FString EventName;
	FString CurGroup;
	FString CurState;

	uint32 EventId;
	uint32 PlayingID;

	uint8 bStop : 1;
	ECWAudioType AudioType;
};

/** 上升完成声音数据(准备阶段外围物件) */
struct FPeripherySceneObj
{
	static const FString StoneRaise;

	static const FString StoneKey;
	static const FString StoneEvt;

	static const FString TreeKey;
	static const FString TreeEvt;
};


//namespace CWWwiseDef
//{
	struct EvtBgMusic
	{
		static const FString Bank;
		static const FString Combat;
		struct State
		{
			static const FString CombatPre;
			static const FString CombatIng;
			static const FString CombatWin;
			static const FString CombatLose;
		};
	};


	struct EvtAmbient
	{
		static const FString Bank;
		static const FString Weather;
		struct StateWT
		{
			static const FString Sunshine;
			static const FString Rain;
			static const FString Blizzard;
		};

		static const FString Environ;
		struct StateEV
		{
			static const FString Morning;
			static const FString Afternoon;
			static const FString Night;
		};
	};



//};
