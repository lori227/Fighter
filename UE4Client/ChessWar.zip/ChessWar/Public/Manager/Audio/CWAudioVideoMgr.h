﻿
#pragma once

#include "CoreMinimal.h"
#include "CWManager.h"
#include "CWWeatherData.h"
#include "CWAudioVideoDef.h"
#include "CWAudioVideoMgr.generated.h"

#if !UE_SERVER
	#define AV_MGR(UObj) UCWAudioVideoMgr::GetAVMgr(UObj)
#else
	#define AV_MGR(UObj) nullptr
#endif

class ACWPawn;
class UAkAudioBank;
class UAkAudioEvent;
class UAkComponent;
class UCWGameInstance;
class UAnimSequenceBase;


UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API UCWAudioVideoMgr : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWAudioVideoMgr* GetAVMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGI) override;
	virtual void Destroy() override;

public:
	/** Comm Audio Type */
	virtual bool PlayAudioByCfg(ECWAudioType AudioType, const FString& InAudioId);
	virtual bool PlayAudio(ECWAudioType AudioType, const FString& AkEventName, const UAkAudioEvent* AkEvent = nullptr);
	virtual bool SwitchAudio(ECWAudioType AudioType, const FString& InGroup, const FString& InState);
	virtual bool StopAudio(ECWAudioType AudioType);

	/** Simple Audio By Cfg */
	virtual bool PlayAudioByCfg(AActor* InActor, const FString& InAudioId);
	virtual bool SimplePlayAudio(AActor* InActor, 
		const UAkAudioEvent* InAkEvent = nullptr, const FString& InAkEventName = TEXT(""),
		const FString& InGroup = TEXT(""), const FString& InState = TEXT(""), 
		const UAkAudioBank* InAkBank = nullptr, const FString& InAkBankName = TEXT(""));
	virtual bool SimpleStopAudio(AActor* InActor);

	/** Anim Audio */
	virtual void AddToAnimAudioList(UAkComponent* InAkComp);
	virtual void RemoveFromAnimAudioList(UAkComponent* InAkComp);

	/** Other Audio */
	virtual bool PlayAudioById(ECWAudioType AudioType, const uint32& EventId);
	virtual bool SwitchAudioById(ECWAudioType AudioType, const uint32& GroupId, const uint32& StateId);

	/** Audio Bank */
	virtual bool LoadBank(const FString& InBankName, const UAkAudioBank* InAkBank = nullptr);
	virtual bool UnloadBank(const FString& InBankName, const UAkAudioBank* InAkBank = nullptr);
	virtual void ClearAllBanks();

	virtual UAkComponent* GetAkComp(ECWAudioType AudioType, float InOcclusionRefreshInterval = 0.f);
	virtual UAkComponent* GetAkComp(AActor* InActor, float InOcclusionRefreshInterval = 0.f);
	
	// Set Audio Language
	virtual bool SetAkAudioLanguage(const FString& InLanguageKey);
	virtual FString GetAkAudioLanguage();

public:
	/** Setting Audio */
	UFUNCTION(BlueprintCallable, Category = "CWG|AV|Volume")
	virtual bool SetAkAudioVolume(EAudioSetType InAudioType, const float InVolume, const int32 InterpolationTimeMs = 0);

	UFUNCTION(BlueprintCallable, Category = "CWG|AV|Volume-Test")
	virtual bool SetAkAudioEnable(const bool bInEnable);

	// Use for Audio Mgr control
	virtual bool IsAkAudioEnableInMgr() const;

protected:
	FCWAudioPlayData* GetAudioPlayData(ECWAudioType AudioType);
	void AddAudioPlayData(ECWAudioType AudioType, const FCWAudioPlayData& InPlayData);
	void ClearAllPlayData();

	class FAudioDevice* GetAudioDevice() const;
	class FAkAudioDevice* GetAkAudioDevice() const;
	UAkComponent* GetListenerAkComp();

	UAkComponent* GetPlayAkComp(ECWAudioType AudioType);
	AActor* GetPlayAkActor(ECWAudioType AudioType);

	AActor* GetAmbientPlayActor();
	AActor* GetUISoundPlayActor();

	// 预加载音频Bank
	virtual void PreLoadBank(const FString& LevelName = TEXT(""));
	// 关卡加载完成
	virtual void OnLevelLoadComplete(const float LoadTime, const FString& MapName);

protected:
	//FPakPlatformFile::Initialize

	UFUNCTION()
	virtual void OnBattleStateChange(const ECWBattleState OldState, const ECWBattleState NewState);

	UFUNCTION()
	virtual void OnWeatherIdxChange(ECWWeatherType NewWeatherIdx, ECWWeatherType InOldType);

	UFUNCTION()
	virtual void OnTimePhasesChange(ECWTimePhases NewTimePhases);

	UFUNCTION()
	virtual void OnBattleResult(const ECWBattleResult InResult);

	UFUNCTION()
	virtual void OnLevelSiteDrop(const bool bStarted, const int32 InFallIdx);

	UFUNCTION()
	virtual void OnCameraArmLength(const float InLength);

protected:
	UPROPERTY(BlueprintReadOnly)
	uint8 bEnableAudioPlay : 1;

	TArray<FString> AudioBankList;

	UPROPERTY()
	TMap<TEnumAsByte<ECWAudioType>, FCWAudioPlayData> AudioPlayMap;

	// Simple Audio 
	TArray<TWeakObjectPtr<UAkComponent>> SimpleAudioPlayList;

	// Anim Audio 
	TArray<TWeakObjectPtr<UAkComponent>> AnimAudioPlayList;

	float AkAudioMainVolume;

};
