﻿
#pragma once

#include "Components/ActorComponent.h"
#include "CWCommActorComp.generated.h"

class UAkAudioEvent;


UCLASS(BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class UCWCommActorComp : public UActorComponent
{
	GENERATED_UCLASS_BODY()

public:
	virtual bool PlayAudio(const UAkAudioEvent* InAkEvent = nullptr, const FString& InAkEventName = TEXT(""));

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UAkAudioEvent* DefaultAkEvent;

};
