/////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Audiokinetic Wwise generated include file. Do not edit.
//
/////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __WWISE_IDS_H__
#define __WWISE_IDS_H__

#include <AK/SoundEngine/Common/AkTypes.h>

namespace AK
{
    namespace EVENTS
    {
        static const AkUniqueID AMB_DRAGON50101 = 306883804U;
        static const AkUniqueID APPEAR_1003 = 3227332785U;
        static const AkUniqueID APPEAR_1005 = 3227332791U;
        static const AkUniqueID ATTACK_1003 = 1093717616U;
        static const AkUniqueID ATTACK_1005 = 1093717622U;
        static const AkUniqueID CLICK = 1584507803U;
        static const AkUniqueID COMBAT = 2764240573U;
        static const AkUniqueID ENVIRONMENT = 1229948536U;
        static const AkUniqueID HUNT_1003 = 3718307017U;
        static const AkUniqueID HUNT_1005 = 3718307023U;
        static const AkUniqueID KH_DIE01 = 272494214U;
        static const AkUniqueID KH_MOVE01 = 2574898921U;
        static const AkUniqueID KH_NORMALATTACK01 = 2859023287U;
        static const AkUniqueID KH_SKILL01 = 1735830983U;
        static const AkUniqueID MOVING_1003 = 2282626794U;
        static const AkUniqueID MOVING_1005 = 2282626796U;
        static const AkUniqueID MUTE_ALL_NO = 3875277560U;
        static const AkUniqueID MUTE_ALL_YES = 2162521346U;
        static const AkUniqueID NEXTROUND = 1369835138U;
        static const AkUniqueID OPENING_OUT_STONE = 3972178532U;
        static const AkUniqueID OPENING_OUT_TREE = 1676925417U;
        static const AkUniqueID OPENING_STONERAISE_IN = 306076963U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_BLACKHOLE = 1138524160U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_BLACKHOLE_WARNING = 2641604717U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_BUFF_GF = 4111245226U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_BUFF_HD = 4228688565U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_BUFF_HP = 4228688545U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_HUOYUNSHI_BEGINANDFLY = 1709631049U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_HUOYUNSHI_HIT = 3283859539U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_LEI_HIT = 422432611U;
        static const AkUniqueID PLAY_SPE_RANDOMEVENT_LEI_WARNING = 3928486216U;
        static const AkUniqueID PLAY_STONE = 2702709145U;
        static const AkUniqueID SELECT_1003 = 1430999896U;
        static const AkUniqueID SELECT_1005 = 1430999902U;
        static const AkUniqueID SFX_IMPACT_STONE_BREAKEN = 299588236U;
        static const AkUniqueID SFX_IMPACT_TREE_BREAKEN = 2240610195U;
        static const AkUniqueID STOP_STONE = 2129442639U;
        static const AkUniqueID TW_DIE01 = 3592884108U;
        static const AkUniqueID TW_MOVE01 = 817718763U;
        static const AkUniqueID TW_NORMALATTACK01_HIT = 1205837767U;
        static const AkUniqueID TW_NORMALATTACK01_WHOOSH = 414801258U;
        static const AkUniqueID TW_SKILL01 = 1865311125U;
        static const AkUniqueID WEATHER = 317282339U;
    } // namespace EVENTS

    namespace SWITCHES
    {
        namespace COMBAT
        {
            static const AkUniqueID GROUP = 2764240573U;

            namespace SWITCH
            {
                static const AkUniqueID BATTLE1 = 2813898844U;
                static const AkUniqueID BATTLE2 = 2813898847U;
                static const AkUniqueID BATTLE3 = 2813898846U;
                static const AkUniqueID BATTLE4 = 2813898841U;
                static const AkUniqueID IN_COMBAT = 2116791127U;
                static const AkUniqueID LOSE = 221232726U;
                static const AkUniqueID PRE_COMBAT = 594494091U;
                static const AkUniqueID WIN = 979765101U;
            } // namespace SWITCH
        } // namespace COMBAT

        namespace COVERING
        {
            static const AkUniqueID GROUP = 750697806U;

            namespace SWITCH
            {
                static const AkUniqueID FIRE = 2678880713U;
                static const AkUniqueID GRASS = 4248645337U;
                static const AkUniqueID SNOW = 787898836U;
                static const AkUniqueID WATER = 2654748154U;
            } // namespace SWITCH
        } // namespace COVERING

        namespace ENVIRONMENT
        {
            static const AkUniqueID GROUP = 1229948536U;

            namespace SWITCH
            {
                static const AkUniqueID AFTERNOON = 390531879U;
                static const AkUniqueID MORNING = 1924633667U;
                static const AkUniqueID NIGHT = 1011622525U;
            } // namespace SWITCH
        } // namespace ENVIRONMENT

        namespace FS_TYPE
        {
            static const AkUniqueID GROUP = 1742771999U;

            namespace SWITCH
            {
                static const AkUniqueID WALK_X1 = 701890964U;
                static const AkUniqueID WALK_X2 = 701890967U;
            } // namespace SWITCH
        } // namespace FS_TYPE

        namespace IMPACT_LEVEL
        {
            static const AkUniqueID GROUP = 1322522276U;

            namespace SWITCH
            {
                static const AkUniqueID HEAVY = 2732489590U;
                static const AkUniqueID LIGHT = 1935470627U;
                static const AkUniqueID MEDIUM = 2849147824U;
                static const AkUniqueID SUPER = 3117632406U;
            } // namespace SWITCH
        } // namespace IMPACT_LEVEL

        namespace IMPACT_MATERIALS
        {
            static const AkUniqueID GROUP = 3451013472U;

            namespace SWITCH
            {
                static const AkUniqueID ARMOUR = 4151873597U;
                static const AkUniqueID BONE = 1744723399U;
                static const AkUniqueID FLESH = 1153642577U;
            } // namespace SWITCH
        } // namespace IMPACT_MATERIALS

        namespace IMPACT_SKILL
        {
            static const AkUniqueID GROUP = 1461837517U;

            namespace SWITCH
            {
                static const AkUniqueID NORMAL_ATTACK = 4127791551U;
                static const AkUniqueID SKILL_01 = 80674498U;
                static const AkUniqueID SKILL_02 = 80674497U;
                static const AkUniqueID SKILL_03 = 80674496U;
                static const AkUniqueID SKILL_04 = 80674503U;
            } // namespace SWITCH
        } // namespace IMPACT_SKILL

        namespace IMPACT_TYPE
        {
            static const AkUniqueID GROUP = 2161705626U;

            namespace SWITCH
            {
                static const AkUniqueID CRITICAL_STRIKE = 3965318803U;
                static const AkUniqueID NORMAL_ATTACK = 4127791551U;
            } // namespace SWITCH
        } // namespace IMPACT_TYPE

        namespace IMPACT_WEAPON
        {
            static const AkUniqueID GROUP = 1378694922U;

            namespace SWITCH
            {
                static const AkUniqueID BOW = 546945295U;
                static const AkUniqueID LANCE = 3413887606U;
                static const AkUniqueID SPEAR = 573839388U;
                static const AkUniqueID SWORD = 2454616260U;
            } // namespace SWITCH
        } // namespace IMPACT_WEAPON

        namespace MATERIALS
        {
            static const AkUniqueID GROUP = 4050929301U;

            namespace SWITCH
            {
                static const AkUniqueID STONE = 1216965916U;
            } // namespace SWITCH
        } // namespace MATERIALS

        namespace SKILL
        {
            static const AkUniqueID GROUP = 4161132316U;

            namespace SWITCH
            {
                static const AkUniqueID NORMAL_ATTACK = 4127791551U;
                static const AkUniqueID SKILL_01 = 80674498U;
                static const AkUniqueID SKILL_02 = 80674497U;
                static const AkUniqueID SKILL_03 = 80674496U;
                static const AkUniqueID SKILL_04 = 80674503U;
            } // namespace SWITCH
        } // namespace SKILL

        namespace TYPE
        {
            static const AkUniqueID GROUP = 2970581085U;

            namespace SWITCH
            {
                static const AkUniqueID CRITICAL_STRIKE = 3965318803U;
                static const AkUniqueID NORMAL_ATTACK = 4127791551U;
            } // namespace SWITCH
        } // namespace TYPE

        namespace VOICE
        {
            static const AkUniqueID GROUP = 3170124113U;

            namespace SWITCH
            {
                static const AkUniqueID ATTACK = 180661997U;
                static const AkUniqueID DEATH = 779278001U;
                static const AkUniqueID HUNT = 3126836862U;
                static const AkUniqueID MOVING = 2649703675U;
                static const AkUniqueID SELETE = 1180924481U;
            } // namespace SWITCH
        } // namespace VOICE

        namespace WEAPON
        {
            static const AkUniqueID GROUP = 3893417221U;

            namespace SWITCH
            {
                static const AkUniqueID BOW = 546945295U;
                static const AkUniqueID LANCE = 3413887606U;
                static const AkUniqueID SPEAR = 573839388U;
                static const AkUniqueID SWORD = 2454616260U;
            } // namespace SWITCH
        } // namespace WEAPON

        namespace WEATHER
        {
            static const AkUniqueID GROUP = 317282339U;

            namespace SWITCH
            {
                static const AkUniqueID BLIZZARD = 3610151219U;
                static const AkUniqueID RAIN = 2043403999U;
                static const AkUniqueID SUNSHINE = 1044971270U;
            } // namespace SWITCH
        } // namespace WEATHER

    } // namespace SWITCHES

    namespace GAME_PARAMETERS
    {
        static const AkUniqueID AMB = 1117531639U;
        static const AkUniqueID AMB_DISTANCE = 2342375655U;
        static const AkUniqueID MASTER = 4056684167U;
        static const AkUniqueID MUS = 712897226U;
        static const AkUniqueID SE = 1584861537U;
        static const AkUniqueID STOP_AMB_STONE = 1411796790U;
        static const AkUniqueID VO = 1534528548U;
    } // namespace GAME_PARAMETERS

    namespace BANKS
    {
        static const AkUniqueID INIT = 1355168291U;
        static const AkUniqueID SOUNDBANK_AMB = 2411724025U;
        static const AkUniqueID SOUNDBANK_CONTROL = 1946824962U;
        static const AkUniqueID SOUNDBANK_MUSIC = 474740052U;
        static const AkUniqueID SOUNDBANK_SFX_IMPACT_OBJECT = 1612844129U;
        static const AkUniqueID SOUNDBANK_SFX_ROLE_1001TWINBLAST = 3499247260U;
        static const AkUniqueID SOUNDBANK_SFX_ROLE_1003KHAIMERA = 230914596U;
        static const AkUniqueID SOUNDBANK_SPECIALEVENT = 3007674816U;
        static const AkUniqueID SOUNDBANK_UI_BASIC = 1571099830U;
    } // namespace BANKS

    namespace BUSSES
    {
        static const AkUniqueID AMB = 1117531639U;
        static const AkUniqueID AMB_ITEM = 1565215768U;
        static const AkUniqueID BLIZZARD_RAIN = 1669118448U;
        static const AkUniqueID ENVIRONMENT = 1229948536U;
        static const AkUniqueID IMPACT = 3257506471U;
        static const AkUniqueID MASTER_AUDIO_BUS = 3803692087U;
        static const AkUniqueID MUS = 712897226U;
        static const AkUniqueID ROLE = 2026920489U;
        static const AkUniqueID SE = 1584861537U;
        static const AkUniqueID SPEVENT = 288152540U;
        static const AkUniqueID SUN = 644904077U;
        static const AkUniqueID UI = 1551306167U;
        static const AkUniqueID VO = 1534528548U;
        static const AkUniqueID WEATHER = 317282339U;
    } // namespace BUSSES

    namespace AUX_BUSSES
    {
        static const AkUniqueID REVERB = 348963605U;
    } // namespace AUX_BUSSES

    namespace AUDIO_DEVICES
    {
        static const AkUniqueID NO_OUTPUT = 2317455096U;
        static const AkUniqueID SYSTEM = 3859886410U;
    } // namespace AUDIO_DEVICES

}// namespace AK

#endif // __WWISE_IDS_H__
