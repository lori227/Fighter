﻿
#pragma once

#include "Engine/EngineTypes.h"
//#include "CWCommandMgr.generated.h"

class CWCommandMgr;
typedef TSharedPtr<CWCommandMgr> CWCommandMgrPtr;


class CWCommandMgr
{
public:
	/*static CWCommandMgrPtr Instance()
	{
		static CWCommandMgrPtr Inst = TSharedPtr<CWCommandMgr>(new CWCommandMgr);
		return Inst;
	}*/

	virtual ~CWCommandMgr();

protected:
	CWCommandMgr();

public:
	/** UE-Server Unique Id */
	static const FString GetUEServerId();
	/** UE-Server Unique Ip */
	static const FString GetUEServerIp();
	/** UE-Server Unique Port */
	static const int32 GetUEServerPort();

	/** Gate-Way Unique Ip */
	static const FString GetGateWayIp();
	/** Gate-Way Unique Port */
	static const int32 GetGateWayPort();

};
