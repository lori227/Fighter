﻿
#pragma once

#include "Engine/EngineTypes.h"

#include "CWStructDefine.h"
#include "CWManager.generated.h"

class UCWGameInstance;


UCLASS(BlueprintType, Blueprintable)
class UCWManager : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWManager();

public:
	virtual bool InitMgr(UCWGameInstance* InGlobalGI);
	virtual void Tick(float DeltaTime);
	virtual void Destroy();

	virtual UWorld* GetWorld() const override;
	virtual void BeginDestroy() override;

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Mgr")
	static bool IsInEditor();

protected:
	TWeakObjectPtr<UCWGameInstance> Global_GI;

};
