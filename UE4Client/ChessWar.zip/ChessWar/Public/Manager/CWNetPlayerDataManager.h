#pragma once

#include "CoreMinimal.h"
#include "CWManager.h"
#include "LuaState.h"
#include "CWNetPlayerDataManager.generated.h"

class UCWGameInstance;
class UCWNetPlayerData;

UCLASS()
class CHESSWAR_API UCWNetPlayerDataManager : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWNetPlayerDataManager* GetNetPlayerDataMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGlobalGI) override;
	virtual void Tick(float DeltaTime) override;
	virtual void Destroy() override;

public:

	UCWNetPlayerData* GetNetPlayerData(uint64 ParamUUID);
	bool AddNetPlayerData(uint64 ParamUUID, UCWNetPlayerData* ParamNetPlayerData);

	void RemoveAllNetPlayerData();
protected:

	UPROPERTY()
	TMap<uint64, UCWNetPlayerData*> MapNetPlayerData;
};
