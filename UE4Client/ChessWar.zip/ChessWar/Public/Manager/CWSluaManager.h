#pragma once

#include "CoreMinimal.h"
#include "CWManager.h"
#include "LuaState.h"
#include "CWSluaManager.generated.h"


class UCWGameInstance;

UCLASS()
class CHESSWAR_API UCWSluaManager : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWSluaManager* GetSluaMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGlobalGI) override;
	virtual void Tick(float DeltaTime) override;
	virtual void Destroy() override;
public:
	void ResetInClient();

	UFUNCTION()
	void OnPlayerLoginCompleted(const FGameModeData GameModeData);
public:

	slua::LuaState* ClientLuaState();
	slua::LuaState* ServerLuaState();

protected:

	slua::LuaState m_clientLuaState;
	slua::LuaState m_serverLuaState;

	FString m_loadedLevelName;

	bool m_bIsLuaMainServerStarted;
	bool m_bIsLuaMainClientStarted;
};
