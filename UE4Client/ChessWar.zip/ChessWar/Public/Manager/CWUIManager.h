﻿/**
 *	Author:		LiuShuang
 *	Date:		2018.09.12
 */
#pragma once

#include "CoreMinimal.h"

#include "Classes/InputCoreTypes.h"

#include "CWManager.h"
#include "CWUserWidget.h"
#include "CWUIManager.generated.h"

#if !UE_SERVER
	#define UI_MGR(UObj) UCWUIManager::GetUIMgr(UObj)
#else
	#define UI_MGR(UObj) nullptr
#endif

class UCWGameInstance;


UCLASS()
class CHESSWAR_API UCWUIManager : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWUIManager* GetUIMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGlobalGI) override;
	virtual void Destroy() override;

public:
	UFUNCTION(BlueprintCallable)
	void SetInputMode(EUIInputMode InputMode = EUIInputMode::GameAndUI);
	UFUNCTION(BlueprintCallable)
	void ShowMouseCursor(bool bShow = true);

	UFUNCTION(BlueprintCallable, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static void LuaOpenUI(const UObject* InWorldContextObj, const FString& InUIKey);

	UFUNCTION(BlueprintCallable, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static void LuaCloseUI(const UObject* InWorldContextObj, const FString& InUIKey);

public:
	UFUNCTION(BlueprintCallable)
	virtual UUserWidget* OpenUI(const FString& UIName, const int32 ZOrder = 0);
	UFUNCTION(BlueprintCallable)
	virtual bool DestroyUI(const FString& UIName);
	UFUNCTION(BlueprintCallable)
	virtual UUserWidget* HideUI(const FString& UIName);

	UFUNCTION(BlueprintCallable)
	void ClearUICache();
	UFUNCTION(BlueprintCallable)
	void RemoveUICache(const FString& UIName);

	UFUNCTION(BlueprintPure)
	UTexture2D* GetTexture2D(const FString& TextName);

	UFUNCTION(BlueprintPure)
	UCWUserWidget* GetUIWidget(const FString& UIName);

	UFUNCTION(BlueprintCallable)
	UCWUserWidget* CreateUIWidget(const FString& UIName);

	UFUNCTION(BlueprintPure)
	class ACWPlayerController* GetLocalPC();
	UFUNCTION(BlueprintPure)
	class APlayerController* GetPlayerController() const;

	UFUNCTION(BlueprintPure)
	TSubclassOf<UCWUserWidget> GetUITemplate(const FString& UIName);

	// Pawn UI
	UFUNCTION(BlueprintCallable)
	virtual uint8 SetEnablePawnUI(uint8 InMode);
	UFUNCTION(BlueprintPure)
	virtual uint8 GetEnablePawnUIMode() const;
	// Handler: Pawn ui state change
	virtual void OnUpdateWolrdPawnUI();

	// Camera Shake
	UFUNCTION(BlueprintCallable)
	virtual void PlayCameraShake(TSubclassOf<class UCameraShake> InShake);
	UFUNCTION(BlueprintCallable)
	virtual void StopCameraShake(TSubclassOf<class UCameraShake> InShake);
	UFUNCTION(BlueprintCallable)
	virtual void StopAllCameraShake();

	// Camera Anim
	UFUNCTION(BlueprintCallable)
	virtual void PlayCameraAnim(class UCameraAnim* AnimToPlay, float Scale = 1.f, float Rate = 1.f, 
		float BlendInTime = 0.f, float BlendOutTime = 0.f, bool bLoop = false, bool bRandomStartTime = false, 
		ECameraAnimPlaySpace::Type Space = ECameraAnimPlaySpace::CameraLocal, FRotator CustomPlaySpace = FRotator::ZeroRotator);
	UFUNCTION(BlueprintCallable)
	virtual void StopCameraAnim(class UCameraAnim* AnimToStop);
	UFUNCTION(BlueprintCallable)
	virtual void StopAllCameraAnims(bool bImmediate = false);

	// Camera Cinematic Mode
	UFUNCTION(BlueprintCallable, Category = "CWG|Cinematic", meta = (bHidePlayer = "true", bAffectsHUD = "true"))
	virtual void SetCinematicMode(bool bInCinematicMode, bool bHidePlayer = true, 
		bool bAffectsHUD = false, bool bAffectsMovement = false, bool bAffectsTurning = false);

	// Load Map Callback
	void OnPreLoadMap(const FString& MapName);
	void OnPreloadContentForURL(FURL InURL);
	void OnPostLoadMapWithWorld(UWorld* World);
	void OnLevelLoadComplete(const float LoadTime, const FString& MapName);

	// Load Screen
	/** Show the native loading screen, such as on a map transfer. If bPlayUntilStopped is false, it will be displayed for PlayTime and automatically stop */
	UFUNCTION(BlueprintCallable, Category = "CWG|UI|Loading")
	static void PlayLoadingScreen(bool bPlayUntilStopped, float PlayTime);

	/** Turns off the native loading screen if it is visible. This must be called if bPlayUntilStopped was true */
	UFUNCTION(BlueprintCallable, Category = "CWG|UI|Loading")
	static void StopLoadingScreen();

	UFUNCTION(BlueprintPure)
	static bool IsValidWidget(const UCWUserWidget* Widget);

protected:
	UFUNCTION()
	virtual void OnKeyPressed(const FKey InKey);

	UFUNCTION()
	virtual void OnWindowTitleBarCloseClicked();

	UFUNCTION()
	virtual void OnHUDBeginPlayed(const bool bBeginPlay);

	UFUNCTION()
	virtual void OnPlayerLoginCompleted(const FGameModeData InGameModeData);

	UFUNCTION()
	virtual void OnSendMessage(const int32 InMsgId, const FString& InParam);

protected:
	/** ui template */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = UIWidgets)
	TMap<FString, TSubclassOf<UCWUserWidget>> UIWidgets;

	/** ui cache */
	UPROPERTY()
	TMap<FString, TWeakObjectPtr<UCWUserWidget>> UICache;

	FGameModeData GameModeData;

	// 0:动态显示 1:常全显示 2:常乙方显示 
	uint8 EnablePawnUIMode;

};
