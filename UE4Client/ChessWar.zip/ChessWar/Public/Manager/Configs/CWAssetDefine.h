﻿
#pragma once

#include "CoreMinimal.h"
#include "CWGameDefine.h"
//#include "CWAssetDefine.generated.h"

#pragma region /** MapTile */

#define STR_Empty ("")

#define Default_TileMeshPath (FTileAssetPath::Floor)


struct FTileAssetPath
{
	/** 地块默认网格(StaticMesh) */
	static const FString Floor_CursorOver;
	static const FString Floor_AttackRange;
	static const FString Floor_AttackTarget;
	static const FString Floor_SupportRange;
	static const FString Floor_SupportTarget;
	static const FString Floor_SwitchInReady;
	static const FString Floor_MoveRange;
	static const FString Floor_MoveTarget;
	static const FString Floor_WarnFall;
	static const FString Floor_WarnRandEvt;

	/** 地块渲染网格(StaticMesh) */
	static const FString Render_Move;
	static const FString Render_Attack;
	static const FString Render_SelectNormal;
	static const FString Render_SelectGreen;
	static const FString Render_SelectAttackTarget;

};

struct FTileParticleAssetId
{
	static const FString Particle_CursorOver;
	static const FString Particle_AttackTarget;
	static const FString Particle_SwitchInReady;
	static const FString Particle_Support;
	static const FString Particle_Selected;
	static const FString Particle_SelectedAttackTarget;
	static const FString Particle_WarnFall;
	static const FString Particle_WarnRandEvt;
};

#pragma endregion /** MapTile */

struct FCWCommClassKey 
{
	/** AI */
	static const FString BP_AITarget;
	static const FString BP_AIPawn;

	/** CameraBlockVolume */
	static const FString BP_CameraMoveVolume;
	static const FString BP_CameraBlockVolume;

	/** Water */
	static const FString BP_WaterEffect;

	/** Pawn */
	static const FString BP_CWPawn;
	static const FString BP_CWPawnStart;

	/** ElemSys Comp */
	static const FString BP_ElemSysCtrl;

	/** PhysicsSys Comp */
	static const FString BP_PhysicsSysCtrl;

	/** ArrowRender */
	static const FString BP_ArrowRender;

	/** MapTile */
	static const FString BP_CWMapTile;
	static const FString BP_TileRender;

	/** CWSplineActor */
	static const FString BP_SplineActor;
	static const FString BP_AimLine;

	/** GridSwitchEx */
	static const FString BP_GridSwitchEx;

};

struct FCWCommAssetKey
{
	static const FString Particle_HitMark;
};
