
#pragma once

#include "CoreMinimal.h"
#include "Engine/StreamableManager.h"
#include "CWAssetManager.generated.h"


UCLASS()
class CHESSWAR_API UCWAssetManager : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	//UCWAssetManager* GetAssetMgr(const UObject* WorldContext = nullptr);

public:
#pragma region
	/** 
	 * 异步加载多个资源
	 * @param TargetsToStream const TArray<FStringAssetReference>& 
	 * @param DelegateToCall FStreamableDelegate 
	 * @param Priority TAsyncLoadPriority   加载优先级
	 */
	void RequestAsyncLoad(const TArray<FStringAssetReference>& TargetsToStream, FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority = 1);
	
	/**
	 * 异步加载单个资源
	 * @param TargetToStream const FStringAssetReference&
	 * @param DelegateToCall FStreamableDelegate 
	 * @param Priority		 TAsyncLoadPriority   加载优先级
	 */
	void RequestAsyncLoad(const FStringAssetReference& TargetToStream, FStreamableDelegate DelegateToCall, TAsyncLoadPriority Priority = 1);
	
	/** 
	 * 异步加载多个资源
	 * @param TargetsToStream const TArray<FStringAssetReference>& 
	 * @param Callback TFunction<void()>&& 
	 * @param Priority TAsyncLoadPriority   加载优先级
	 */
	void RequestAsyncLoad(const TArray<FStringAssetReference>& TargetsToStream, TFunction<void()>&& Callback, TAsyncLoadPriority Priority = 1);
	
	/** 
	 * 异步加载单个资源
	 * @param TargetToStream const FStringAssetReference& 
	 * @param Callback TFunction<void()>&& 
	 * @param Priority TAsyncLoadPriority   加载优先级
	 */
	void RequestAsyncLoad(const FStringAssetReference& TargetToStream, TFunction<void()>&& Callback, TAsyncLoadPriority Priority = 1);
	
	/* 
	 * 同步加载单个资源
	 * @param	FSoftObjectPath	const FSoftObjectPath& 
	 */
	template< class T = UObject >
	inline T* LoadSynchronous(const FSoftObjectPath& Target)
	{
		//return StreamMgr.SynchronousLoadType<T>(Target);
		return StreamMgr.LoadSynchronous<T>(Target, true);
	}

#pragma endregion

private:
	FStreamableManager StreamMgr;

};
