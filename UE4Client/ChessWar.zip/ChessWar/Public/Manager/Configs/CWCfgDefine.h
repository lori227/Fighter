﻿
#pragma once

#include "CoreMinimal.h"
//#include "CWCfgDefine.generated.h"

#define GET_CFG_PATH(Path, File) FString(Path + TEXT(File) + TEXT(".") + TEXT(File) + TEXT("'"))


struct FCWCfgKey
{
	static const FString Main;

#pragma region /** 资源配置 */

	static const FString Asset;
	static const FString ClassAsset;
	static const FString UIAsset;
	static const FString PawnAsset;
	static const FString MeshAsset;

	//场景外围装饰资源配置
	static const FString DecorateAsset;

	// 关卡物体资源
	static const FString LevelItemAsset;

	// 特效资源表
	static const FString ParticleAsset;

#pragma endregion /** 资源配置 */

	static const FString Audio;
	static const FString Weather;
	static const FString PawnData;
	/** 技能数据 */
	static const FString SkillData;
	/** 天赋数据 */
	static const FString TalentData;
	static const FString UIWidget;
	static const FString LevelItem;

	static const FString Language;
	static const FString CommConst;
	static const FString ConstLocal;
	static const FString BattleConst;

	/** 随机事件 */
	static const FString RandomEvt;

	/** Buff */
	static const FString BuffCfg;

	/** 物体元素数据 */
	static const FString ObjElemInfo;
	static const FString ObjWithElemReaction;

	/** 克制数据 */
	static const FString RefrainType;
	static const FString RefrainFactor;
	static const FString RefrainRelation;

	/** 特效数据表 */
	static const FString EffectCfg;

	/** 游戏数据表 */
	static const FString GameCfg;
	/** 职业数据表 */
	static const FString ProfessionCfg;

	/** 地形 */
	static const FString DungeonRegionCfg;

	// --- 检测(检测主表) ---
	//static TArray<FString> GetMainCfgAllTable();

};
