﻿
#pragma once

#include "CWManager.h"
#include "CWAssetData.h"
#include "CWCfgDefine.h"
#include "CWTableRowBase.h"
#include "CWCfgManager.generated.h"

#define CFG_MGR(UObj) UCWCfgManager::GetCfgMgr(UObj)

struct FCWAudioData;
//struct FCWMainCfgData;
struct FCWWeatherData;
struct FCWUIWidgetData;
struct FCWLanguageData;
struct FCWPawnDataStruct;
struct FCWClientConstData;
struct FCWRefrainTypeData;
struct FCWRefrainFactorData;
struct FCWRefrainRelationData;

/**
 *	#配置表数据缓存器
 */
UCLASS(BlueprintType)
class CHESSWAR_API UCWConfigTable : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWConfigTable();

public:
	static UCWConfigTable* CreateCfgTable(UDataTable* InTable);

	template <class T = FCWTableRowBase>
	/*const*/ T* GetRow(const FName& InRowName) const {
		uint8* RowData = CacheCfgTable->FindRowUnchecked(InRowName);
		return (RowData ? reinterpret_cast<T*>(RowData) : nullptr);
	}

	template <class T = FCWTableRowBase>
	/*const*/ T* GetRow(const FString& InRowName) const {
		return GetRow<T>(FName(*InRowName));
	}

	const UDataTable* GetBaseTable() const;

	TArray<FName> GetRowNames() const;

	template <class T>
	void GetAllRows(OUT TArray<T*>& OutRowArray) const
	{
		CacheCfgTable->GetAllRows(TEXT(""), OutRowArray);
	}

protected:
	UPROPERTY()
	UDataTable* CacheCfgTable;
};


/**
 *	#配置表数据管理器
 */
UCLASS(BlueprintType)
class CHESSWAR_API UCWCfgManager : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UCWCfgManager();
	virtual ~UCWCfgManager();

	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWCfgManager* GetCfgMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGI) override;
	virtual void Destroy() override;

public:
	const UCWConfigTable* GetConfigTable(const FString& InCfgKey);
	UDataTable* CreateTableFromMainCfg(const FString& InCfgKey);

	template <class T = FCWTableRowBase>
	/*const*/ T* GetCfgRowData(const FString& InCfgKey, const FString& InRowName) {
		if (const UCWConfigTable* ConfigTable = GetConfigTable(InCfgKey))
		{
			return ConfigTable->GetRow<T>(InRowName);
		}
		return nullptr;
	}

	template <class T = FCWTableRowBase>
	/*const*/ T* GetCfgRowData(const FString& InCfgKey, const FName& InRowName) {
		if (const UCWConfigTable* ConfigTable = GetConfigTable(InCfgKey))
		{
			return ConfigTable->GetRow<T>(InRowName);
		}
		return nullptr;
	}

protected:
	UPROPERTY()
	TMap<FString, const UCWConfigTable*> CacheCfgTableMap;

	UPROPERTY(EditAnywhere, Category = Default)
	TSoftObjectPtr<UDataTable> MainCfgTable;

};
