﻿
#pragma once

#include "CWAssetData.h"
#include "CWCfgDefine.h"
#include "CWTableRowBase.h"

class UCWConfigTable;

struct FCWAudioData;
//struct FCWMainCfgData;
struct FCWWeatherData;
struct FCWUIWidgetData;
struct FCWLanguageData;
struct FCWRandomEvtData;
struct FCWGameDataStruct;
struct FCWPawnDataStruct;
struct FCWBuffDataStruct;
struct FCWSkillDataStruct;
struct FCWObjElemInfoData;
struct FCWClientConstData;
struct FCWRefrainTypeData;
struct FCWEffectDataStruct;
struct FCWRefrainFactorData;
struct FCWRefrainRelationData;
struct FCWProfessionDataStruct;
struct FCWDungeonItemDataStruct;
struct FCWDungeonRegionDataStruct;
struct FCWObjWithElemReactionData;

/**
 *	#配置表工具
 */
class FCWCfgUtils
{
public:
	//~ 配置路径
	static FString Get_Cfg_Path(const FString& Path, const FString& File);

	static FVector FString_To_FVector(const FString& InString, 
		const FVector& InDefaultVector = FVector::ZeroVector, const TCHAR* pchDelim = TEXT("|"));

	static TArray<int32> FString_To_Array_Int32(const FString& InString, const TCHAR* pchDelim = TEXT("|"));
	static TArray<float> FString_To_Array_Float(const FString& InString, const TCHAR* pchDelim = TEXT("|"));
	static TArray<FString> FString_To_Array_FString(const FString& InString, const TCHAR* pchDelim = TEXT("|"));
	
public:
	//~ 配置表
	static const UCWConfigTable* GetCfg(const UObject* WorldContext, const FString& InCfgKey);

	//~ 总表配置
	//static const FCWMainCfgData* GetMainCfgData(const UObject* WorldContext, const FString& InCfgName);

#pragma region /** 资源配置 */
	//~ 资源配置(通用)
	static /*const*/ FCWAssetData* GetAssetData(const UObject* WorldContext, const FString& InAssetId);

	template<class T = UObject>
	static T* GetAssetObject(const UObject* WorldContext, const FString& InAssetId) {
		FCWAssetData* AssetData = FCWCfgUtils::GetAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadObject<T>() : nullptr;
	}

	//~ 资源配置(Class)
	static /*const*/ FCWClassAssetData* GetClassAssetData(const UObject* WorldContext, const FString& InAssetId);

	template<class T = UClass>
	static T* GetAssetClass(const UObject* WorldContext, const FString& InAssetId) {
		FCWClassAssetData* AssetData = FCWCfgUtils::GetClassAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadClass<T>() : nullptr;
	}

	//~ 资源配置(UI)
	static /*const*/ FCWUIAssetData* GetUIAssetData(const UObject* WorldContext, const FString& InAssetId);

	template<class T = UObject>
	static T* GetUIAssetObject(const UObject* WorldContext, const FString& InAssetId) {
		FCWUIAssetData* AssetData = FCWCfgUtils::GetUIAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadObject<T>() : nullptr;
	}

	//~ 资源配置(Pawn)
	static /*const*/ FCWPawnAssetData* GetPawnAssetData(const UObject* WorldContext, const FString& InAssetId);

	template<class T = UObject>
	static T* GetPawnAssetObject(const UObject* WorldContext, const FString& InAssetId) {
		FCWPawnAssetData* AssetData = FCWCfgUtils::GetPawnAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadObject<T>() : nullptr;
	}

	template<class T = UClass>
	static T* GetPawnAssetClass(const UObject* WorldContext, const FString& InAssetId) {
		FCWPawnAssetData* AssetData = FCWCfgUtils::GetPawnAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadClass<T>() : nullptr;
	}

	//~ 网格配置(Mesh)
	static /*const*/ FCWMeshAssetData* GetMeshAssetData(const UObject* WorldContext, const FString& InAssetId);

	template<class T = UObject>
	static T* GetMeshAssetObject(const UObject* WorldContext, const FString& InAssetId) {
		FCWMeshAssetData* AssetData = FCWCfgUtils::GetMeshAssetData(WorldContext, InAssetId);
		return AssetData ? AssetData->LoadObject<T>() : nullptr;
	}

	static /*const*/ FCWAssetData* GetAssetDataFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId);

	template<class T = UObject>
	static T* GetAssetObjectFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId) {
		FCWAssetData* AssetData = FCWCfgUtils::GetAssetDataFromCfg(WorldContext, InAssetCfg, InAssetId);
		return AssetData ? AssetData->LoadObject<T>() : nullptr;
	}

	static /*const*/ FCWAssetData* GetClassAssetDataFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId);

	template<class T = UClass>
	static T* GetAssetClassFromCfg(const UObject* WorldContext, const FString& InAssetCfg, const FString& InAssetId) {
		FCWAssetData* AssetData = FCWCfgUtils::GetClassAssetDataFromCfg(WorldContext, InAssetCfg, InAssetId);
		return AssetData ? AssetData->LoadClass<T>() : nullptr;
	}

#pragma endregion

	//~ UI 配置
	static TSubclassOf<UUserWidget> GetUIWidget(const UObject* WorldContext, const FString& InWidget);
	static const FCWUIWidgetData* GetUIWidgetData(const UObject* WorldContext, const FString& InWidget);

	//~ 天气配置
	static const FCWWeatherData* GetWeatherData(const UObject* WorldContext, const int32 InId);

	//~ 音频配置
	static const FCWAudioData* GetAudioData(const UObject* WorldContext, const FString& InSoundId);

	//~ 棋子配置
	static const FCWPawnDataStruct* GetPawnData(const UObject* WorldContext, const int32 InPawnId);

	//~ 技能配置
	static const FCWSkillDataStruct* GetSkillData(const UObject* WorldContext, const int32 InSkillId);

	//~ 天赋配置
	static /*const*/ FCWSkillDataStruct* GetTalentData(const UObject* WorldContext, const int32 InTalentId);

	//~ 物件配置
	static const FCWDungeonItemDataStruct* GetLevelItemData(const UObject* WorldContext, const int32 InItemId);

	//~ 克制配置
	static bool GetBelongRefrainTypeArray(const UObject* WorldContext, const FString& InId, TArray<FString>& OutList);
	static FString GetBelongRefrainTypeString(const UObject* WorldContext, const FString& InId);

	static const FCWRefrainTypeData* GetRefrainTypeData(const UObject* WorldContext, const FString& InTypeId);
	static const FCWRefrainFactorData* GetRefrainFactorData(const UObject* WorldContext, const FString& InFactorId);
	static const FCWRefrainRelationData* GetRefrainRelationData(const UObject* WorldContext, const FString& InRelationId);

	//~ 语言配置
	static const FCWLanguageData* GetLanguageData(const UObject* WorldContext, const FString& InId);
	static FString GetLanguageString(const UObject* WorldContext, const FString& InId);

	//~ 常量配置
	static const FCWClientConstData* GetConstData(const UObject* WorldContext, const FString& InConstCfg, const FString& InId);

	//~ 随机事件配置
	static const FCWRandomEvtData* GetRandomEvtData(const UObject* WorldContext, const int32 InId);

	//~ Buff配置
	static const FCWBuffDataStruct* GetBuffData(const UObject* WorldContext, const int32 InBuffId);

	//~ 物件元素信息
	static const FCWObjElemInfoData* GetObjElemInfoData(const UObject* WorldContext, const int32 InObjElemId);

	//~ 元素与物件反应
	static const FCWObjWithElemReactionData* GetObjWithElemReactionData(const UObject* WorldContext, const int32 InReactionId);

	//~ 特效数据信息
	static const FCWEffectDataStruct* GetEffectData(const UObject* InWorldContext, const int32 InEffectId);

	//~ 游戏数据信息
	static const FCWGameDataStruct* GetGameData(const UObject* InWorldContext, const int32 InGameId);

	//~ 职业数据信息
	static const FCWProfessionDataStruct* GetProfessionData(const UObject* InWorldContext, const int32 InProfessionId);

	//~ 地形数据
	static const FCWDungeonRegionDataStruct* GetDungeonRegionData(const UObject* InWorldContext, const int32 InRegionId);

};
