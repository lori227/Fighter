﻿
#pragma once

#include "Engine/DataTable.h"
#include "CWTableRowBase.generated.h"


USTRUCT(BlueprintType)
struct CHESSWAR_API FCWTableRowBase : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWTableRowBase();
	virtual ~FCWTableRowBase();

	virtual void OnPostDataImport(const UDataTable* InDataTable, const FName InRowName, TArray<FString>& OutCollectedImportProblems)
	{
		//RowName = InRowName;
		FTableRowBase::OnPostDataImport(InDataTable, InRowName, OutCollectedImportProblems);
	}

protected:
	//FName RowName;

};
