﻿
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
#include "CWAssetData.generated.h"

#pragma region		/** 资源通用结构 */

/**
 *	#资源配置数据(资源和类)
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWAssetData : public FCWTableRowBase // public UDataAsset
{
	GENERATED_USTRUCT_BODY()

public:
	// UKismetSystemLibrary::LoadAsset
	// UKismetSystemLibrary::LoadAssetClass

	template<class T = UObject>
	T* LoadObject()
	{
		T* OutObj = LoadObjectByAssetPath<T>();
		OutObj = OutObj ? OutObj : LoadObjectByAssetPtr<T>();
		return OutObj;
	}

	template<class T = UClass>
	T* LoadClass()
	{
		/*T* OutClass = LoadClassByClassPath<T>();
		OutClass = OutClass ? OutClass : LoadClassByClassPtr<T>();*/
		T* OutClass = LoadClassByClassPtr<T>();
		return OutClass;
	}

protected:
	template<class T = UObject>
	T* LoadObjectByAssetPath()
	{
		return Cast<T>(AssetPath.TryLoad());
	}

	template<class T = UObject>
	T* LoadObjectByAssetPtr()
	{
		return Cast<T>(AssetPtr.LoadSynchronous());
	}

	/*template<class T = UClass>
	T* LoadClassByClassPath()
	{
		return Cast<T>(ClassPath.TryLoadClass());
	}*/

	template<class T = UClass>
	T* LoadClassByClassPtr()
	{
		return Cast<T>(ClassPtr.LoadSynchronous());
	}

public:
	/** 资源路径 */
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSoftObjectPath /*FStringAssetReference*/ AssetPath;

	/** 资源路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UObject> /*TAssetPtr<UObject>*/ AssetPtr;

	/** 类型路径 */
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//FSoftClassPath /*FStringClassReference*/ ClassPath;

	/** 类型路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<UObject> /*TAssetSubclassOf<UObject>*/ ClassPtr;

};


/**
 *	#资源配置数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWCommAssetData : public FCWTableRowBase // public UDataAsset
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UObject>
	T* LoadObject()
	{
		return Cast<T>(AssetPtr.LoadSynchronous());
	}

public:
	/** 资源路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UObject> /*TAssetPtr<UObject>*/ AssetPtr;

};


/**
 *	#类资源配置数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWClassAssetData : public FCWTableRowBase // public UDataAsset
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UClass>
	T* LoadClass()
	{
		return Cast<T>(ClassPtr.LoadSynchronous());
	}

public:
	/** 类型路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<UObject> /*TAssetSubclassOf<UObject>*/ ClassPtr;

};

#pragma endregion	/** 资源通用结构 */


/**
 *	#UI资源配置数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWUIAssetData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UObject>
	T* LoadObject()
	{
		return Cast<T>(AssetPtr.LoadSynchronous());
	}

public:
	/** 资源路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UObject> /*TAssetPtr<UObject>*/ AssetPtr;

};


/**
 *	#棋子资源配置数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWPawnAssetData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UObject>
	T* LoadObject()
	{
		return Cast<T>(AssetPtr.LoadSynchronous());
	}

	template<class T = UClass>
	T* LoadClass()
	{
		return Cast<T>(ClassPtr.LoadSynchronous());
	}

public:
	/** 资源路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UObject> /*TAssetPtr<UObject>*/ AssetPtr;

	/** 类型路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<UObject> /*TAssetSubclassOf<UObject>*/ ClassPtr;

};


/**
 *	#Mesh资源配置数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWMeshAssetData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UObject>
	T* LoadObject()
	{
		return Cast<T>(AssetPtr.LoadSynchronous());
	}

public:
	/** 资源路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UObject> /*TAssetPtr<UObject>*/ AssetPtr;

};
