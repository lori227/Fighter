﻿
#pragma once

#include "CWAudioVideoDef.h"
#include "CWTableRowBase.h"
#include "CWAudioData.generated.h"

class UAkAudioBank;
class UAkAudioEvent;


/**
 * #音频配置数据结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWAudioData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	/** Wwise audio type */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TEnumAsByte<ECWAudioType> AudioType;

	/** Wwise Ak Bank */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UAkAudioBank* AkBank;

	/** Wwise Ak Event */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UAkAudioEvent* AkEvent;

	/** Wwise Ak Event */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay)
	FString AkEventName;

	/** Wwise Ak Group */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString AkGroup;

	/** Wwise Ak State */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString AkState;

	/** Ext Desc */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay)
	FString ExtDesc;

};
