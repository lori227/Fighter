﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWClientConstData.generated.h"


/**
 * @brief	自定义数据结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWClientConstData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Param;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay)
	FString Desc;

};
