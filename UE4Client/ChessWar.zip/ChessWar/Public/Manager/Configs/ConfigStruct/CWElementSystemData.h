﻿
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
#include "CWElementSystemData.generated.h"


/**
 * @Brief	元素类型
 */
UENUM(BlueprintType)
enum class EObjElemType : uint8
{
	// None
	OET_None		= 0		UMETA(DisplayName = "None"),
	// 火
	OET_Fire		= 1		UMETA(DisplayName = "Fire"),
	// 水
	OET_Water		= 2		UMETA(DisplayName = "Water"),
	// 冰
	OET_Ice			= 3		UMETA(DisplayName = "Ice"),
	// 雷
	OET_Thunder		= 4		UMETA(DisplayName = "Thunder"),
	// 毒
	OET_Venom		= 5		UMETA(DisplayName = "Venom"),

	OET_Max					UMETA(Hidden)
};


/**
 * @Brief	物体状态类型
 */
UENUM(BlueprintType)
enum class EObjNatureType : uint8
{
	// None
	ONT_None		= 0		UMETA(DisplayName = "None"),
	// 可燃物(与火反应)
	ONT_Fire		= 1		UMETA(DisplayName = "CanFire"),
	// 可湿物(与水反应)
	ONT_Water		= 2		UMETA(DisplayName = "CanWater"),
	// 可冰物(与冰反应)
	ONT_Ice			= 3		UMETA(DisplayName = "CanIce"),
	// 可导体(与雷反应)
	ONT_Thunder		= 4		UMETA(DisplayName = "CanThunder"),
	// 可感染物(与毒反应)
	ONT_Venom		= 5		UMETA(DisplayName = "CanVenom"),

	ONT_Max					UMETA(Hidden)
};


/**
 * @Brief	元素与元素结果类型
 */
UENUM(BlueprintType)
enum class EElemWithElemResultType : uint8
{
	// 不反应
	EWERT_None				= 0	UMETA(DisplayName = "None"),
	// 抵消(消除现在元素)
	EWERT_Clear				= 1	UMETA(DisplayName = "Clear"),
	// 抵消并附加Buff(例如:爆炸..)
	EWERT_ClearAlsoAddBuff	= 2	UMETA(DisplayName = "ClearAlsoAddBuff"),
	// 只附加Buff
	EWERT_OnlyAddBuff		= 3	UMETA(DisplayName = "OnlyAddBuff"),
	// 生成元素(并且执行性质反应)
	EWERT_GenElem			= 4	UMETA(DisplayName = "GenElem"),
	// 覆盖元素
	EWERT_CoverElem			= 5	UMETA(DisplayName = "CoverElem"),
};


/**
 * @Brief	元素与元素反应结果
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWElemWithElemResultData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWElemWithElemResultData();
	virtual ~FCWElemWithElemResultData();

public:
	/** Print */
	virtual FString ToDebugString() const;

	virtual int32 GetOutBuffId(ECWPawnType InPawnType) const ;

public:
	/** 结果类型 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	EElemWithElemResultType ResultType;

	/** 结果元素(主要结果元素) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category = Default)
	EObjElemType OutElemType;

	/** 结果元素(覆盖情况,次要元素) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category = Default)
	EObjElemType OutExtraElemType;

	/** 结果Buff(Pawn) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category = Default)
	int32 OutPawnBuffId;

	/** 结果Buff(LevelItem) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category = Default)
	int32 OutItemBuffId;

};


/**
 * @Brief	元素与物体性质反应结果
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWElemWithObjNatureResultData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWElemWithObjNatureResultData();
	virtual ~FCWElemWithObjNatureResultData();

public:
	/** 结果元素 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	EObjElemType ResultElemType;

	/** 结果Buff */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 ResultBuffId;

};


/**
 * @Brief	元素与物件反应配置结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWObjWithElemReactionData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWObjWithElemReactionData();
	virtual ~FCWObjWithElemReactionData();

public:
	/** 施法元素 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	EObjElemType CastElem;

	/** 接收元素对象性质 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	EObjNatureType ResObjNature;

	/** 接收元素对象类型 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	ECWPawnType ResObjType;

	/** 接收元素对象反应结果(元素) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	EObjElemType ResObjFinalElem;

	/** 接收元素对象反应结果(Buff) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	int32 ResObjExtraBuffId;

};


/**
 * @Brief	物件元素信息数据结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWObjElemInfoData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWObjElemInfoData();
	virtual ~FCWObjElemInfoData();

public:
	/** Print */
	virtual FString ToDebugString() const;

public:
	// RowName : ObjElemId(对象元素Id)

	/** 描述 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	FText Desc;

	/** 对象元素 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	EObjElemType ObjElemType;

	/** 对象性质 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	FString ObjNatures;

};


/** 元素工具集合 */
struct FElemUtils 
{
	/** 字符串 */
	static FString ToOETString(const EObjElemType InObjElemType);
	static FString ToElemElemResultString(const EElemWithElemResultType InType);

	/** 获取对象性质集合 */
	static uint8 ParseObjNatures(const FString& InObjNatures, const TCHAR* pchDelim = TEXT(","));

	/** 对象性质集合是否包含 性质 */
	static bool ObjHasNatureType(uint8 InObjNatureTypes, EObjNatureType InObjNatureType);

	/** 元素类型/性质类型是否有效 */
	static bool IsValidObjElemType(const EObjElemType InObjElemType);

	static bool IsObjElemTypeInRange(const EObjElemType InObjElemType);
	static bool IsObjNatureTypeInRange(const EObjNatureType InObjNatureType);

};
