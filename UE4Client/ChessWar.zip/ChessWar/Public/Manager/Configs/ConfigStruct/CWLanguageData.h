﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWLanguageData.generated.h"


/**
 * @brief	语言文字配置结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWLanguageData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText Language;

};
