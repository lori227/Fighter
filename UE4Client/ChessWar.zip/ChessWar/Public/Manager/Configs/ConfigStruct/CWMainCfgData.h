﻿
#pragma once

#include "CWCfgDefine.h"
#include "CWTableRowBase.h"
#include "CWMainCfgData.generated.h"


/**
 * #总表配置数据结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWMainCfgData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	template<class T = UObject>
	T* LoadObject()
	{
		return Cast<T>(CfgPtr.LoadSynchronous());
	}
		
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UDataTable> /*TAssetPtr<UDataTable>*/ CfgPtr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay)
	FString CfgDesc;

};
