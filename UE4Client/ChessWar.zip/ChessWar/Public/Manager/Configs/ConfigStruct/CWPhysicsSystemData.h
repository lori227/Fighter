﻿
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
#include "CWPhysicsSystemData.generated.h"

struct FCWPawnDataStruct;
struct FCWDungeonItemDataStruct;

/**
 * @brief	物理系统数据(单位或物件)
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWPhysicsSysData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWPhysicsSysData();
	virtual ~FCWPhysicsSysData();

public:
	virtual FCWPhysicsSysData& InitDefault();

	virtual bool IsValidExecPhysicsSysData();

	virtual FCWPhysicsSysData& InitByPawnData(const FCWPawnDataStruct* InPawnData);
	virtual FCWPhysicsSysData& InitByItemData(const FCWDungeonItemDataStruct* InItemData);

	/** Print */
	virtual FString ToDebugString() const;

public:
#pragma region		/** 物理系统数据 */

	/** 用于标识实体在被迫移动时能否产生横向力交互 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 bPhyBMovedForce : 1;

	/** 用于标识实体在被迫移动下坠时能否产生纵向力交互 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 bPhyBFallenForce : 1;

	/** 用于配置实体在接受横向力交互时受到的伤害 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyLateralFDMG;

	/** 用于配置实体在接受横向力交互时受到的被迫移动 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyLateralFMove;

	/** 用于配置实体在接受横向力交互时受到的BUFF */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyLateralFBuff;

	/** 用于配置实体在接受横向力交互时触发的事件 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyLateralFEvent;

	/** 用于配置实体在接受垂直力交互时受到的伤害 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyVerticalFDMG;

	/** 用于配置实体在接受垂直力交互时受到的被迫移动 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyVerticalFMove;

	/** 用于配置实体在接受垂直力交互时受到的BUFF */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyVerticalFBuff;

	/** 用于配置实体在接受垂直力交互时触发的事件 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	int32 PhyVerticalFEvent;

#pragma endregion

};