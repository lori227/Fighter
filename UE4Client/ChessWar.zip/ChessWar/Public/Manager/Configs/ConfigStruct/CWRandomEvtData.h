﻿
#pragma once

#include "CWWeatherData.h"
#include "CWTableRowBase.h"
#include "CWRandomEvtData.generated.h"


/**
 *	#随机事件数据结构
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWRandomEvtData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWRandomEvtData();

	/** Print */
	virtual FString ToDebugString() const;

public:
	// RowName: 事件ID

	/** 名字 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString Name;

	/** 概率(0-100) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 Prob;

	/** 物件ID */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 ItemId;

	/** 携带元素类型 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EObjElemType OwnElemType;

	/** 特效ID(特效播放完->触发伤害范围->生成场景物品) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 EffectId;

	/** 事件类型(0:直接生成物件 1:火陨石 2:黑洞 3:惊雷(直接加BUFF)) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 EvtType;

	/** BUFF-ID */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 BuffId;

	/** 范围类型 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 RangeType;

	/** 范围大小 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 RangeSize;

	/** 生成类型(产生规则 0:每回合触发(默认) 1:跟随场景生成一次) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 GenerateType;

	/** 生成位置(0:任意地势 1:高地势 2:低地势) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 GenerateLandType;

	/** 生成目标(0:任意目标 1:空地块) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 GenerateTargetType;

	/** 生成天气(0:任意天气) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	ECWWeatherType GenerateWeather;

	/**	生成单个?(用于生成前特效/表现) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 bGenerateSingle : 1;

	/**	生成间隔(用于生成前特效/表现) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float GenerateInterval;

	/**	周期值(冷却) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 CycleValue;

	/**	是否预警? */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 bNeedWarn : 1;

};

/** 随机事件游戏数据 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWRandomEvtGameData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWRandomEvtGameData();

	bool operator==(const FCWRandomEvtGameData& InOther)
	{
		return EvtId != 0 && EvtId == InOther.EvtId;
	}

	friend bool operator==(const FCWRandomEvtGameData& A, const FCWRandomEvtGameData& B)
	{
		return A.EvtId != 0 && A.EvtId == B.EvtId;
	}

public:
	/** 事件Id */
	UPROPERTY()
	int32 EvtId;
	/** 事件对应配置数据 */
	UPROPERTY()
	FCWRandomEvtData CfgData;

	/** 冷却值(CfgData.CycleValue) */
	UPROPERTY()
	int8 CoolingValue;
	/** 等待激活回合数(预警) */
	UPROPERTY()
	int8 WaitActiveRound;
	/** 释放目标格子(中心) */
	UPROPERTY()
	int32 TargetTile;
	
	/** 释放目标格子(AOE) */
	//UPROPERTY()
	//TArray<int32> AOETiles;

};


/**
 *	#随机事件伤害数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWRandomEvtHurtData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWRandomEvtHurtData();
	virtual ~FCWRandomEvtHurtData();

public:
	// RowName: 伤害ID

	/** 名字 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString Name;

	/** 伤害值 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 Value;

	/** 伤害回合数 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 RoundNum;

	/** 伤害元素属性 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 ElemType;

	/** 伤害对象(ECWPawnType) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	uint8 TargetType;

};

