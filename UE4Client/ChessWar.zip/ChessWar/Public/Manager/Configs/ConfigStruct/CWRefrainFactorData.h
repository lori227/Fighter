﻿
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
#include "CWRefrainFactorData.generated.h"


/**
 * @brief	克制系数配置结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWRefrainFactorData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	//~ RowName
	// ECWRefrainType

	/** 克制系数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float RefrainFactor;

	/** 被克制系数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BeRefrainFactor;

};
