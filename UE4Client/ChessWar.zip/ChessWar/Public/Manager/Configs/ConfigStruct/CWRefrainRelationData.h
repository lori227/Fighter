﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWRefrainRelationData.generated.h"


/**
 * @brief	克制关系配置结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWRefrainRelationData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	//~ RowName
	// 克制类型Id - FCWRefrainTypeData -> RowName

	/** 优势类型(武器) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString WeaponStrength;

	/** 劣势类型(武器) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString WeaponWeak;

	/** 优势类型(行动) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString ActingStrength;

	/** 劣势类型(行动) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString ActingWeak;

	/** 优势类型(种族) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString RaceStrength;

	/** 劣势类型(种族) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString RaceWeak;

};
