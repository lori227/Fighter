﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWRefrainTypeData.generated.h"


/**
 * @brief	克制类型分类配置结构
 */
USTRUCT(BlueprintType)
struct CHESSWAR_API FCWRefrainTypeData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()
		
public:
	//~ RowName
	// 克制类型Id

	/** 克制类型所拥有Id */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString OwnerIds;

};
