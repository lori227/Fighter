﻿
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
//#include "CWStatisticsSystemData.generated.h"


/**
 * @brief	统计类型
 */
UENUM(BlueprintType, Blueprintable)
enum class ECWStatisticsType : uint8
{
	// 当前回合移动攻击步数
	RoundMoveAttackStep				= 1,

};
