﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWUIWidgetData.generated.h"

class UUserWidget;

/**
 *	#UI界面数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWUIWidgetData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	/** 类型路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<UUserWidget> UIWidget;

};
