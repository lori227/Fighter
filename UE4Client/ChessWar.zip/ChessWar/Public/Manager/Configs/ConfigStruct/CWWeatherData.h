﻿
#pragma once

#include "CWTableRowBase.h"
#include "CWElementSystemData.h"
#include "CWWeatherData.generated.h"


UENUM(BlueprintType, Blueprintable)
enum class ECWWeatherType : uint8
{
	None,
	// 晴天
	Sunshine,
	// 雨天
	Rain,
	// 暴雪
	Blizzard,

	Max			UMETA(Hidden)
};

UENUM(BlueprintType, Blueprintable)
enum class ECWTimePhases : uint8
{
	// 深夜
	Night,
	// 上午
	Morning,
	// 下午
	Afternoon,
};

/**
 *	#天气影响数据
 */
USTRUCT(BlueprintType)
struct FCWWeatherAffectData
{
	GENERATED_USTRUCT_BODY()

public:
	FCWWeatherAffectData();
	~FCWWeatherAffectData();

	FCWWeatherAffectData operator+(const FCWWeatherAffectData& InOther);
	FCWWeatherAffectData operator-(const FCWWeatherAffectData& InOther);
	FCWWeatherAffectData& operator+=(const FCWWeatherAffectData& InOther);
	FCWWeatherAffectData& operator-=(const FCWWeatherAffectData& InOther);

	bool IsValidValue() const;

public:
	// !对应结构 FCWPawnDataStruct

	/**< 攻击力 01 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float AttackValue;

	/**< 防御 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float DefenceValue;

	/**< 技巧值 06 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float TalentValue;

	/**< 行动力 07 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float MoveValue;
};


/**
 *	#天气数据
 */
USTRUCT(BlueprintType, Blueprintable)
struct FCWWeatherData : public FCWTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FCWWeatherData();
	virtual ~FCWWeatherData();

public:
	/** Print */
	virtual FString ToDebugString() const;

public:
	/** 天气类型 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECWWeatherType WeatherType;

	/** 携带元素类型 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EObjElemType OwnElemType;

	/** 特效路径 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString EffectId;

	/** 近战影响 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FCWWeatherAffectData MeleeAffect;

	/** 近战影响 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FCWWeatherAffectData RangedAffect;

	/** 名字 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Name;

	/** 说明 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Desc;

};
