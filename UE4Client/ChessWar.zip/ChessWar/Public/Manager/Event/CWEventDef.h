﻿
#pragma once

#include "Delegate.h"
#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"

#define ADD_EVT_DELEGATE(DynamicMulticastDelegate, InUObj, InMethodPtr, InFuncName)\
		DynamicMulticastDelegate.__Internal_AddUniqueDynamic(InUObj, InMethodPtr, InFuncName)

#define REMOVE_EVT_DELEGATE(DynamicMulticastDelegate, InUObj)\
		DynamicMulticastDelegate.RemoveAll(InUObj)

// 关卡加载
DECLARE_MULTICAST_DELEGATE_OneParam(FOnOnPreloadContentForURL, FURL);
DECLARE_MULTICAST_DELEGATE_TwoParams(FOnLevelLoadComplete, const float, const FString&);
