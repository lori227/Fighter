﻿/**
 *	Author:		LiuShuang
 *	Date:		2018.09.12
 */
#pragma once

#include "CoreMinimal.h"
#include "InputCoreTypes.h"

#include "CWManager.h"
#include "CWUIDefine.h"
#include "CWEventDef.h"
#include "CWStructDefine.h"
#include "CWWeatherData.h"
#include "CWEventMgr.generated.h"

#define EVT_MGR(UObj) UCWEventMgr::GetEventMgr(UObj)


//~ Begin Game Event
#pragma region	  /** Game Event */

/** 玩家登陆完成 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPlayerLoginCompleted, const FGameModeData, InGameModeData);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnHUDBeginPlayed, const bool, bBeginPlay);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNetPlayerCountChange, const int32, InPlayerCount);

/** 玩家准备状态 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnRoleReadyStateChange, int32, InPid, bool, bReadyOk);
//DECLARE_MULTICAST_DELEGATE_TwoParams(FOnRoleReadyStateChange, int32 / *Pid* / , bool / *bReadyOk* / );

/** 准备剩余时间 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnReadyRemainTimeChange, float, InTime);

/** 战斗回合 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnRoundRemainTimeChange, float, InTime);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnRoundIndexChange, int32, InCurRoundIdx, int32, InMaxRoundIdx);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnRoundCampChange, ECWCampTag, InCampTag, ECWCampControllerIndex, InCampPlayerIdx);

/** 战斗结果 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBattleResult, const ECWBattleResult, InBattleResult);
/** 战斗状态 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnBattleStateChange, const ECWBattleState, InOldState, const ECWBattleState, InCurState);
/** 关卡地形上升(准备前) */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLevelSiteRise, const ACWDungeonTile*, InTileObj);
/** 关卡地形掉落(预警掉落) */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLevelSiteDrop, const bool, bStartSiteDrop, const int32, InFallIdx);
/** 关卡地形掉落预警 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLevelSiteDropEarlyWarnClient, const bool, bStart, const int32, InWarnIdx);

/** 天气/时间 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnWeatherIdxChange, ECWWeatherType, InWeatherType, ECWWeatherType, InOldWeatherType);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnNextWeatherIdxChange, ECWWeatherType, InNextWeatherType);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTimePhasesChange, ECWTimePhases, InTimePhases);

/** 敌方人数/我方人数 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCampANumChange, int, InCompanionNum);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCampBNumChange, int, InEnermyNum);

/** 角色移动加速 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnGamePlayerRateChange, const int32, InRate);

/** 事件分发(按键) */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnKeyPressed, const FKey, InKey);

/** Buff销毁 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnBuffDestroyed, const int32, InBuffUniqueId, 
	const int32, InBuffId, const EObjElemType, InOwnElemType, const ECWBuffSouceType, InSouceType);

/** 对象元素改变事件 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnObjElemTypeEvent, const EObjElemType, InObjElemType);

/** 弹簧臂长度 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCameraArmLength, const float, InLength);
/** 弹簧臂90度俯视 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCameraArmAgree90, const bool, IsShow);

/** 玩家客户端消息 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnPlayerSendMessage, const int32, InMsgId, const FString&, InParam);

/** 玩家棋子动作结束 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnPlayerPawnActionEndClient, 
	const ECWCampTag, InPawnCampTag, const ECWCampControllerIndex, InPawnCampControllerIndex, const int32, PawnControllerPawnIndex);

/** 玩家数据数组 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPlayerDataArrayChange);

/** 更新雪地脚印目标 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAddSnowfieldTarget, AActor*, InTarget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnRemoveSnowfieldTarget, AActor*, InTarget);

#pragma endregion /** Game Event */


/**
 *	#事件管理器
 */
UCLASS(BlueprintType, Blueprintable)
class CHESSWAR_API UCWEventMgr : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UCWEventMgr();

	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWEventMgr* GetEventMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGI) override;
	virtual void Destroy() override;

protected:
	virtual void ClearAllEvents();

public:
	//~ Level load
	static FOnOnPreloadContentForURL OnPreloadContentForURL;
	static FOnLevelLoadComplete OnLevelLoadComplete;

	//~ Key Evt
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	/*static */FOnKeyPressed OnKeyPressed;

	//~ Player Msg
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	/*static */FOnPlayerSendMessage OnPlayerSendMessage;

	//~ Player Load
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnHUDBeginPlayed OnHUDBeginPlayed;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnPlayerLoginCompleted OnPlayerLoginCompleted;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnNetPlayerCountChange OnNetPlayerCountChange;

	//~ Battle Ready
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRoleReadyStateChange OnRoleReadyStateChange;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnReadyRemainTimeChange OnReadyRemainTimeChange;

	//~ Begin Fighting
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRoundCampChange OnRoundCampChange;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRoundRemainTimeChange OnRoundRemainTimeChange;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRoundIndexChange OnRoundIndexChangeInClient;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRoundIndexChange OnRoundIndexChangeInServer;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnGamePlayerRateChange OnGamePlayerRateChange;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnBattleStateChange OnBattleStateChange;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnBattleResult OnBattleResult;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnLevelSiteRise OnLevelSiteRise;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnLevelSiteDrop OnLevelSiteDrop;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnLevelSiteDropEarlyWarnClient OnLevelDropEarlyWarnClient;
	
	//~ End Fighting

	//~ Weather
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnWeatherIdxChange OnWeatherIdxChange;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnNextWeatherIdxChange OnNextWeatherIdxChange;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnTimePhasesChange OnTimePhasesChange;

	//~ Camp&Ener Num
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnCampANumChange OnCampANumChange;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnCampBNumChange OnCampBNumChange;

	//~ Camera Arm Length
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnCameraArmLength OnCameraArmLength;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnCameraArmAgree90 OnCameraArmAgree90;

	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnPlayerPawnActionEndClient OnPlayerPawnActionEndClient;

	/** Player Data Array */
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnPlayerDataArrayChange OnPlayerDataArrayChange;

	/** SnowfieldTarget */
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnAddSnowfieldTarget OnAddSnowfieldTarget;
	UPROPERTY(BlueprintAssignable, Category = "CWG|Evt")
	FOnRemoveSnowfieldTarget OnRemoveSnowfieldTarget;
};
