﻿
#pragma once

#include "CWSaveGame.h"
#include "CWAudioVideoDef.h"
#include "CWGameSettingSG.generated.h"


/** audio volume data */
USTRUCT(BlueprintType)
struct CHESSWAR_API FAudioSetting
{
	GENERATED_USTRUCT_BODY()

public:
	FAudioSetting();
	FAudioSetting(EAudioSetType InType, bool bNewEnableAudio, float InVolume);

public:
	bool operator!=(const FAudioSetting& InOther) const
	{
		return (AudioSetType != InOther.AudioSetType) ||
				(bEnableAudio != InOther.bEnableAudio) ||
				!FMath::IsNearlyEqual(AudioTypeVolume, InOther.AudioTypeVolume);
	}

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	EAudioSetType AudioSetType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 bEnableAudio : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	float AudioTypeVolume;
};

/**
 * 
 */
UCLASS()
class CHESSWAR_API UCWGameSettingSG : public UCWSaveGame
{
	GENERATED_UCLASS_BODY()
	
public:
	virtual ~UCWGameSettingSG();

	UFUNCTION(BlueprintPure)
	static UCWGameSettingSG* GetClassDefaultObj();

	UFUNCTION(BlueprintCallable)
	static UCWGameSettingSG* NewGameSettingSG(UObject* InOuter);

	UFUNCTION(BlueprintCallable)
	static void InitResScreenSetting(UCWGameSettingSG* InObject);

	UFUNCTION(BlueprintCallable)
	static void SetAudioVolume(UCWGameSettingSG* InObject, EAudioSetType InAudioSetType, float InAudioTypeVolume);

	UFUNCTION(BlueprintCallable)
	static bool CompareProperty(UCWGameSettingSG* InLeftObj, UCWGameSettingSG* InRightObj);

	UFUNCTION(BlueprintCallable)
	static UCWGameSettingSG* CopyProperty(UCWGameSettingSG* InOpObj, UCWGameSettingSG* InFromObj);

	UFUNCTION(BlueprintCallable)
	static void ResetDefaultSetting(UCWGameSettingSG* InOpObj, const uint8 InPageIdx);

	UFUNCTION(BlueprintPure)
	static UCWGameSettingSG* GetGameSetData(const FString& SlotName = TEXT("SG_GameSetting"), const int32 UserIndex = 0);

	UFUNCTION(BlueprintCallable)
	static bool SaveGameSetData(UCWGameSettingSG* InGameSettingSG, const FString& SlotName = TEXT("SG_GameSetting"), const int32 UserIndex = 0);

public:
	//~ Begin GameSetting
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 EnablePawnUIMode;
	//~ End GameSetting

	//~ Begin GraphSetting
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	FIntPoint Resolution;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	uint8 bWindowMode : 1;
	//~ End GraphSetting

	//~ Begin AudioSetting
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Default)
	TArray<FAudioSetting> AudioSettings;
	//~ End GraphSetting

};
