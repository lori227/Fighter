
#pragma once

#include "CWManager.h"
#include "CWLocalDataMgr.generated.h"

#define LocalData_MGR(UObj) UCWLocalDataMgr::GetLocalDataMgr(UObj)

class UCWGameSettingSG;

/**
 *
 */
UCLASS()
class CHESSWAR_API UCWLocalDataMgr : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWLocalDataMgr* GetLocalDataMgr(const UObject* InWorldContextObj = nullptr);

public:
	UFUNCTION(BlueprintPure)
	UCWGameSettingSG* GetGameSettingData();
	
private:
	UPROPERTY(Transient)
	UCWGameSettingSG* GameSettingData;

};
