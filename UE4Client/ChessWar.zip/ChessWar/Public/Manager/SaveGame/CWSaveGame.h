
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "CWSaveGame.generated.h"

/**
 *
 */
UCLASS()
class CHESSWAR_API UCWSaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	/*	@see UGameplayStatics::CreateSaveGameObject
	 *	@see UGameplayStatics::SaveGameToSlot
	 *	@see UGameplayStatics::DoesSaveGameExist
	 *	@see UGameplayStatics::LoadGameFromSlot
	 *	@see UGameplayStatics::DeleteGameInSlot
	 */
};
