﻿
#pragma once

//#include "Components/ActorComponent.h"

#include "CWManager.h"
#include "CWWeatherData.h"
#include "CWWeatherMgr.generated.h"


class AEmitter;
class ACWDungeonTile;
class ACWSimpleActor;
class UCWGameInstance;
class ADirectionalLight;
class ACWEffectWaterImpl;

struct FCWTimeData
{
	float Intensity;
	FQuat LightQuat;
};

UCLASS(BlueprintType, Blueprintable)
class UCWWeatherMgr : public UCWManager
{
	GENERATED_UCLASS_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "CWG|Game", meta = (WorldContext = "InWorldContextObj"))
	static class UCWWeatherMgr* GetWeatherMgr(const UObject* InWorldContextObj = nullptr);

	virtual bool InitMgr(UCWGameInstance* InGI) override;
	virtual void Destroy() override;

	virtual bool OnTick(float DeltaTime);

	// 天气相关
	static int32 GenerateWeatherIdx(const int32 InCurRound);
	static bool IsValidWeatherIdx(const int32 InIdx);

protected:
	virtual AEmitter* GetEmitterActor();
	virtual ADirectionalLight* GetLightActor();

	// 获取天气粒子
	virtual UParticleSystem* GetWeatherEmitter(ECWWeatherType InIdx) const;

	// 时间差变化Tick
	virtual void EnableTimePhasesTick();
	virtual void DisEnableTimePhasesTick();

	// 检测地块效果变化
	virtual void CheckDungeonEffectChange(ECWWeatherType InNewType, ECWWeatherType InOldType);

	// 地块格子销毁回调
	UFUNCTION()
	virtual void OnTileBeginFallInClient(ACWDungeonTile* InTileObj);

	// 回合改变回调
	UFUNCTION()
	virtual void OnRoundChange(int32 CurRound, int32 MaxRound);

	// 天气变化回调
	UFUNCTION()
	virtual void OnWeatherIdxChange(ECWWeatherType NewWeatherIdx, ECWWeatherType InOldWeatherIdx);

	UFUNCTION()
	virtual void OnExit();

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CWG|BlendFunc")
	TEnumAsByte<enum EViewTargetBlendFunction> BlendFunction;

	FCWTimeData FinalRotData;
	//FTimerHandle TimerHandle;

	/** Handle for OnTick. */
	FDelegateHandle TickDelegateHandle;

	TWeakObjectPtr<AEmitter> EmitterActor;
	TWeakObjectPtr<ADirectionalLight> LightActor;

private:
	// 水面相关
	TWeakObjectPtr<ACWSimpleActor> WaterPanelParent;
	TArray<TWeakObjectPtr<ACWEffectWaterImpl>> WaterPanelList;

};
