#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Global/CWGameDefine.h"

struct FVector;


/**
 * @brief 攻击格子 \n
 *
 */
class CWAttackGrid
{
public:
	/**< 攻击格子下标 */
	int Tile;

	/**< 棋子格子下标 */
	int PawnTile;

	/**< 以DamageCenter为基点，方向是 */
	uint8 Dir;

	/**< 格子属性 */
	uint8 MAD;
public:

	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	CWAttackGrid();


	/** 拷贝构造
	 * @param	const CWAttackGrid&	其他格子
	 * @return	无
	 */
	CWAttackGrid(const CWAttackGrid& rhs);


	/** 重载操作符=
	 * @param	const CWAttackGrid&	其他格子
	 * @return	CWDamageGrid&	返回自己
	 */
	CWAttackGrid& operator=(const CWAttackGrid& rhs);


	friend bool operator==(const CWAttackGrid& lhs, const CWAttackGrid& rhs);
};