#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Global/CWGameDefine.h"

struct FVector;


/**
 * @brief 伤害格子 \n
 *
 */
class CWDamageGrid
{
public:
	/**< 伤害格子下标 */
	int Tile;

	/**< 棋子格子下标 */
	int PawnTile;

	/**< 攻击格子下标 DamageCenter */
	int AttackTile;

	/**< 以DamageCenter为基点，方向是 */
	uint8 Dir;

	/**< 格子属性 */
	uint8 MAD;
public:

	/** 构造函数
	 * @param	无
	 * @return	无
	 */
	CWDamageGrid();


	/** 拷贝构造
	 * @param	const CWDamageGrid&	其他格子
	 * @return	无
	 */
	CWDamageGrid(const CWDamageGrid& rhs);


	/** 重载操作符=
	* @param	const CWDamageGrid&	其他格子
	* @return	CWDamageGrid&	返回自己
	*/
	CWDamageGrid& operator=(const CWDamageGrid& rhs);


	friend bool operator==(const CWDamageGrid& lhs, const CWDamageGrid& rhs);
};