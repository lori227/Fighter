﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "UnrealNetwork.h"
#include "Containers/Array.h"
#include "Components/SplineComponent.h"
#include "Components/SceneComponent.h"
#include "CWAttackGrid.h"
#include "CWDamageGrid.h"
#include "Global/CWGameDefine.h"
#include <list>
#include <vector>
#include "CWPawnFindPathInfo.h"
#include "CWMap.generated.h"

struct FVector;
class ACWPawn;
class FCWAStar;
class ACWGameMode;
class ACWMapTile;
class ACWPawnStart;
class ACWArrowRender;
class FCWPathExplorer;
class USceneComponent;
class ACWMapTileRender;
class ACWPlayerController;
class UCWMapTileHintHandlerComponent;
struct FCWDungeonDataStruct;
class ACWRandomDungeonGenerator;
class CWPEGrid;


DECLARE_DYNAMIC_MULTICAST_DELEGATE(FAfterMapSetupInClientDelegate);

UCLASS()
class ACWMap : public AActor
{
	GENERATED_UCLASS_BODY()

public:
	ACWMap();
	virtual ~ACWMap();

protected:
	virtual void BeginPlay() override;
	virtual void BeginDestroy() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	/** 是否在服务器
	 * @param	无
	 * @return	bool	true:在服务器, false:不在服务器
	 */
	bool IsInServer() const;


	/** 是否在自己客户端的地图
	 * @param	无
	 * @return	bool	true:在自己的客户端, false:不在自己的客户端
	 */
	bool IsInMyClientMap() const;


	/** 是否在其他客户端的地图
	 * @param	无
	 * @return	bool	true:在其他的客户端, false:不在其他的客户端
	 */
	bool IsInOtherClientMap() const;


	/** 生成地图Tile
	 * @param	无
	 * @return	无
	 */
	void GenerateMapTiles();


	/** 移动棋子
	 * @param	ACWPawn* 	棋子
	 * @param	int			老格子
	 * @param	int			新格子
	 * @return	bool		true:移动成功，false:移动失败
	 */
	bool MovePawn(ACWPawn* ParamPawn, int ParamOldTile, int ParamCurTile);


	/** 是否有棋子
	 * @param	ACWPawn* 	棋子
	 * @param	int			格子
	 * @return	bool		true:有棋子，false:没有棋子
	 */
	bool IsTherePawn(int ParamCurTile);


	/** 获得地图格子
	 * @param	int	格子下标
	 * @return	ACWMapTile*	地图格子
	 */
	ACWMapTile* GetTile(int32 ParamTile);


	/** 销毁地图格子
	 * @param	int	格子下标
	 * @return	无
	 */
	void RemoveTile(int32 ParamTile);


	/** 每回合开始,数据重置
	 * @param	无
	 * @return	无
	 */
	void ResetWhenNextTurnBeginInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);


	/** 每回合开始行动,数据重置
	 * @param	无
	 * @return	无
	 */
	void StartActionInServer(ECWCampTag ParamCampTag, ECWCampControllerIndex ParamCampControllerIndex);


	ACWArrowRender* GetArrowRenderFromCache();
	void AddSplinePoint(FVector pos);
	void RomoveAllSplinePoint();

	/** 初始化
	 * @param	int
	 * @return	无
	 */
	void init(int ParamDungeonId);


	/** 反初始化
	 * @param	无
	 * @return	无
	 */
	void uninit();


	/** 创建地图数据内存
	 * @param	无
	 * @return	bool	true:创建成功，false:创建失败
	 */
	bool createMapForServer();


	/** 创建地图数据内存
	 * @param	无
	 * @return	bool	true:创建成功，false:创建失败
	 */
	bool createMapForClient();


	/** 销毁地图数据内存
	 * @param	无
	 * @return	无
	 */
	void destroyMap();


	/** 获得地图宽度
	 * @param	无
	 * @return	int	地图宽度
	 */
	int getWidth() const; 


	/** 获得地图高度
	 * @param	无
	 * @return	无	地图高度
	 */
	int getHeight() const;

	int getGridWidth() const;
	int getGridHeight() const;
	int getOffsetX() const;
	int getOffsetY() const;

	/** 用A*寻路
	 * @param	FCWPathExplorer& 寻路探测器（如果寻路成功，寻路的路径也存在里面）
	 * @param	const FVector& 目标点
	 * @param	int	寻路步进限制
	 * @param	ECWCampTag	寻路的阵营
	 * @param	FCWPawnFindPathInfo	寻路的数据
	 * @return	bool	true:寻路成功，false:寻路失败
	 */
	bool pathExplorerFindPathAStar(FCWPathExplorer& pe, const FVector& destPos, int limitStep, ECWCampTag movingCampTag, FCWPawnFindPathInfo ParamFindPathInfo);


	/** 查找离目标点最近的非障碍点
	 * @param	int	目标点格子x（在障碍里）
	 * @param	int	目标点格子y（在障碍里）
	 * @param	int&	离目标点最近的非障碍点格子的x
	 * @param	int&	离目标点最近的非障碍点格子的y
	 * @return	bool	true:查找到离目标点最近的非障碍点, false:没有查找到离目标点最近的非障碍点
	 */
	bool findNoBarrierNearestDest(int dx, int dy, int& ndx, int& ndy);


	/** 根据路径移动
	 * @param	FCWPathExplorer&	要根据路径移动的寻路探测器
	 * @param	float	要移动的速度
	 * @param	float	时间间隔
	 * @return	bool	true:路径处理成功，false:路径处理失败
	 */
	bool pathExplorerProgress(FCWPathExplorer& pe, float speed, float deltaTime);


	/** 设置格子属性
	 * @param	int x	格子x
	 * @param	int y	格子y
	 * @param	uint8	格子属性
	 * @return	无
	 */
	void setMapTileAttribute(int x, int y, uint8 attr);


	/** 获得格子属性
	 * @param	int x	格子x
	 * @param	int y	格子y	
	 * @return	uint8	格子属性
	 */
	uint8 getMapTileAttribute(int x, int y) const;


	/** 设置格子属性
	 * @param	int 	格子下标
	 * @param	uint8	格子属性
	 * @return	无
	 */
	void setMapTileAttribute(int tile, uint8 attr);


	/** 获得格子属性
	 * @param	int 	格子下标	
	 * @return	uint8	格子属性
	 */
	uint8 getMapTileAttribute(int tile) const;


	/** 设置格子属性
	 * @param	const FVector& 	格子世界坐标
	 * @param	uint8	格子属性
	 * @return	无
	 */
	void setMapTileAttribute(const FVector& pos, uint8 attr);


	/** 获得格子属性
	 * @param	const FVector& 	格子世界坐标
	 * @param	uint8	格子属性
	 * @return	无
	 */
	uint8 getMapTileAttribute(const FVector& pos) const;

	void ResetArrayMoveAttackDamage();
	uint8 GetMoveAttackDamage(int ParamTile) const;
	void SetMoveAttackDamage(int ParamTile, uint8 ParamMoveAttackDamage);
	const TArray<uint8>& GetArrayMoveAttackDamage() const;

	ECWAffectDirType GetAffectDir(int ParamSourceTile, int ParamTargetTile);

	void ResetVectorAttack();
	void SetVectorAttackGrid(int ParamTile, int ParamPawnTile, ECWAffectDirType ParamDir, uint8 ParamMoveAttackDamage);

	void ResetVectorDamage();
	void SetVectorDamageGrid(int ParamTile, int ParamPawnTile, int ParamAttackTile, ECWAffectDirType ParamDir, uint8 ParamMoveAttackDamage);
	const std::vector<std::list<CWDamageGrid>>& GetVectorDamageGrid() const;

	bool ConsumeMove(const std::list<CWPEGrid>& ParamListPEGrid, int ParamMove, FCWPawnFindPathInfo ParamFindPathInfo);

	/** 从A格子移动到B格子，所付出移动代价
	 * @param	int	地图px
	 * @param	int	地图py
	 * @param	int	地图cx
	 * @param	int	地图cy
	 * @param	FCWPawnFindPathInfo 寻路信息
	 * @return	int	移动代价
	 */
	int cost(int px, int py, int cx, int cy, FCWPawnFindPathInfo ParamFindPathInfo);


	/** 某个格子能否通过
	 * @param	int	地图x
	 * @param	int	地图y
	 * @return	bool	true:能通过，false:不能通过
	 */
	bool canPass(int x, int y) const;


	/** 某个格子能否通过
	 * @param	int	地图cx
	 * @param	int	地图cy
	 * @return	bool	true:能通过，false:不能通过
	 */
	bool canPassIncludeEnemy(int x, int y, ECWCampTag movingCampTag) const;


	bool isThereEnemy(int tile, ECWCampTag movingCampTag) const;
	bool isTherePartner(int tile, ECWCampTag movingCampTag, ECWCampControllerIndex movingCampControllerIndex) const;
	bool isTherePawn(int tile) const;
	bool IsMe(
		ECWCampTag ParamCampTag, 
		ECWCampControllerIndex ParamCampControllerIndex,
		int32 ParamControllerPawnIndex,
		int tile) const;

	TWeakObjectPtr<ACWPawn> GetPawnByTile(const int32 InTile);
	TArray<TWeakObjectPtr<ACWPawn>> GetArrayPawns();

	FCWDungeonDataStruct* GetDungeonData();
	ACWRandomDungeonGenerator* GetDungeonGenerator();

	/** 获取棋子出生点数据 */
	virtual ACWPawnStart* GetPawnStartByTile(const int32 InTile);

	/** 获取地块格子数组 */
	virtual const TArray<ACWMapTile*>& GetArrayTiles();

public:
	UPROPERTY(BlueprintCallable)
	FAfterMapSetupInClientDelegate OnAfterMapSetupInClient;

	UFUNCTION()
	void OnRep_ClientChangeArrayPawns();

	UFUNCTION()
	virtual void OnRep_DungeonId(int32 InOldDungeonId);

public:
	/** 某个格子能否通过
	 * @param	int	地图格子下标
	 * @return	bool	true:能通过，false:不能通过
	 */
	bool canPass(int tile) const;


	/** 某个格子能否通过
	 * @param	int	地图格子下标
	 * @param	const ACWPawn*	要移动的棋子
	 * @return	bool	true:能通过，false:不能通过
	 */
	bool canPass(int tile, const ACWPawn* ParamMovePawn) const;


	/** 某个格子能否通过
	 * @param	(const FVector&	地图格子世界坐标
	 * @return	bool	true:能通过，false:不能通过
	 */
	bool canPass(const FVector& pos) const;


	/** tile转化成xy
	 * @param	int	格子下标
	 * @param	int&	格子x
	 * @param	int&	格子y
	 * @return	无
	 */
	static void tile2xy(int tile, int& x, int& y);


	/** tile转化成pos
	 * @param	int	格子下标
	 * @param	FVector&	格子世界坐标
	 * @return	无
	 */
	static void tile2pos(int tile, FVector& pos);


	/** xy转化成tile
	 * @param	int	格子x
	 * @param	int	格子y
	 * @return	int 格子下标
	 */
	static int xy2tile(int x, int y);


	/** xy转化成pos
	 * @param	int	格子x
	 * @param	int	格子y
	 * @param	FVector&	格子世界坐标
	 * @return	无
	 */
	static void xy2pos(int x, int y, FVector& pos);


	/** pos转化成tile
	 * @param	const FVector&	格子世界坐标
	 * @return	int	格子下标
	 */
	static int pos2tile(const FVector& pos);


	/** pos转化成xy
	 * @param	const FVector&	格子世界坐标
	 * @param	int&	格子x
	 * @param	int&	格子y
	 * @return	无
	 */
	static void pos2xy(const FVector& pos, int& x, int& y);

	/** 客户端初始化 */
	bool IsInitInClient() const;
	void InitInClient();

	bool IsSameZ(int px, int py, int cx, int cy);
	bool IsSameZ(int pt, int ct);
	int GetAbsZ(int pt, int ct);
	int GetStandardConsumeMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo);
	int GetIncrementConsumeMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo);
	bool CanMove(int ct, FCWPawnFindPathInfo ParamFindPathInfo);
protected:
	/** 起点目标点同格子,填充路径队列
	 * @param	FCWPathExplorer&	寻路探测器
	 * @return	无
	 */
	void _fillSameGridToPathExplorer(FCWPathExplorer& pe);


	/** A*寻路成功后,填充路径队列
	 * @param	FCWPathExplorer&	寻路探测器
	 * @return	无
	 */
	void _fillASPathToPathExplorer(FCWPathExplorer& pe);

protected:
	/**< 静态指针 */
	static ACWMap* s_this;

	/**< 地图数据 */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Replicated)
	TArray<uint8> m_map;

	UPROPERTY(VisibleAnywhere, Replicated, ReplicatedUsing = OnRep_ClientChangeArrayPawns)
	TArray<TWeakObjectPtr<ACWPawn>> ArrayPawns;
	
	bool bIsInitInClient;

	/**< 地图Id */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, ReplicatedUsing = OnRep_DungeonId)
	int m_dungeonId;

	/**< 地图格子总数 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	int m_mapSize;

	/**< 地图宽度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_mapWidth;

	/**< 地图高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_mapHeight;

	/**< 每个格子的宽度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_gridWidth;

	/**< 每个格子的高度 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_gridHeight;

	/**< 偏移X */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_offsetX;
	
	/**< 偏移Y */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	int m_offsetY;

	/**< A*寻路 */
	FCWAStar* m_as;

	/**< 寻路探测器 */
	FCWPathExplorer* m_pe;

	/**< 地图格子 */
	UPROPERTY()
	TArray<ACWMapTile*> ArrayTiles;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	USplineComponent* Spline;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 ArrowDensity;

	UPROPERTY()
	TArray<FVector> ArrayArrowPos;

	std::list<ACWArrowRender*> ListArrowRenderUsed;
	std::list<ACWArrowRender*> ListArrowRenderCache;

	UPROPERTY()
	TArray<uint8> ArrayMoveAttackDamage;

	std::vector<std::list<CWAttackGrid>> VectorListAttack;
	std::vector<std::list<CWDamageGrid>> VectorListDamage;

};


class MapTileCompare
{
public:
	MapTileCompare(ACWMap* ParamMyMap, int ParamBeginTile, ECWCampTag ParamCampTag, FCWPawnFindPathInfo ParamFindPathInfo);
	bool operator()(int lhs, int rhs);

public:
	int BeginTile;
	ECWCampTag CampTag;
	FCWPawnFindPathInfo FindPathInfo;
	ACWMap* MyMap;

};
