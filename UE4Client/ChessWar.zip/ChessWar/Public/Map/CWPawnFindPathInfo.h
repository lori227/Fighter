
#pragma once

#include "CWGameDefine.h"
#include "CWTableRowBase.h"
#include "CWPawnFindPathInfo.generated.h"

USTRUCT(BlueprintType)
struct FCWPawnFindPathInfo
{
	GENERATED_USTRUCT_BODY()

public:
	FCWPawnFindPathInfo();
	virtual ~FCWPawnFindPathInfo();

public:

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PawnFindPathInfo")
	int32 Profession;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PawnFindPathInfo")
	int32 MoveType;
};