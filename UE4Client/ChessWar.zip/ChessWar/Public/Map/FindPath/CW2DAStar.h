﻿#pragma once

#include "CoreMinimal.h"
#include "UnrealNetwork.h"
#include "Global/CWGameDefine.h"


typedef int(*ASCallBackFuncValid)(int px, int py, int cx, int cy);
typedef int(*ASCallBackFuncCost)(int px, int py, int cx, int cy);

class ASNode2D
{
public:

	int f;					///<Fitness
	int g;					///<goal
	int h;					///<heuristic.
	int	x;					///<横坐标
	int y;					///<纵坐标
	int	id;					///<唯一ID(x*rows+y)
	ASNode2D* parent;		///<父节点
	ASNode2D* children[8];	///<子节点
	int	numChildren;		///<子节点的个数
	ASNode2D* next;			///<下个节点(用于Open表和Closed表)

	///构造
	inline ASNode2D(int _x = -1, int _y = -1)
		:f(0)
		, g(0)
		, h(0)
		, x(_x)
		, y(_y)
		, id(-1)
		, parent(NULL)
		//children
		, numChildren(0)
		, next(NULL)
	{
		memset(children, 0, sizeof(children));
	}

private:

	///拷贝构造(禁用)
	ASNode2D(const ASNode2D& rhs);

	///赋值操作符(禁用)
	ASNode2D& operator=(const ASNode2D& rhs);
};

class ASStack2D
{
public:
	ASNode2D* data;
	ASStack2D* next;

	///构造
	inline ASStack2D()
		:data(NULL)
		, next(NULL)
	{
	}

private:

	///拷贝构造(禁用)
	ASStack2D(const ASStack2D& rhs);

	///赋值操作符(禁用)
	ASStack2D& operator=(const ASStack2D& rhs);
};


class AStar2D
{
public:

	///构造
	AStar2D();

	///析构
	~AStar2D();

	///生成路径
	bool generatePath(int sx, int sy, int dx, int dy, int limitStep);

	///设置列数
	void setColumnNum(int cn);

	///获得当前最好节点
	ASNode2D* getCurBestNode() const;

	///获得步数
	int getStep() const;

protected:

	///准备工作
	void _ready(int sx, int sy, int dx, int dy);

	///步进
	int _step();

	///添加节点到Open表
	void _addToOpenList(ASNode2D* addNode);

	///得到Open表最好的节点,并将其移到closed表
	ASNode2D* _getBestNodeInOpenList();

	///查找Open表是否有此ID的节点
	ASNode2D* _findNodeInOpenList(int id) const;

	///Open表清除
	void _clearOpenList();

	///查找Closed表是否有此ID的节点
	ASNode2D* _findNodeInClosedList(int id) const;

	///Closed表清除
	void _clearClosedList();

	///创建子节点
	void _createChildren(ASNode2D* p);

	///链接子节点
	void _linkChild(ASNode2D* p, int cx, int cy);

	///刷新父节点
	void _updateParents(ASNode2D* p);

	///压栈
	void _push(ASNode2D* node);

	///出栈
	ASNode2D* _pop();

	///清空Statck
	void _clearStack();

	///坐标转唯一id
	int _coordinate2ID(int x, int y);

private:

	///拷贝构造(禁用)
	AStar2D(const AStar2D& rhs);

	///赋值操作符(禁用)
	AStar2D& operator=(const AStar2D& rhs);

protected:

	///<列数(用于计算ASNode2D.id)
	int m_columns;

	///<起点横坐标
	int	m_sx;

	///<起点纵坐标
	int	m_sy;

	///<终点横坐标
	int	m_dx;

	///<终点纵坐标
	int	m_dy;

	///<终点唯一ID
	int m_did;

	///<步数
	int m_step;

	///<Open表
	ASNode2D* m_open;

	///<Closed表
	ASNode2D* m_closed;

	///<当前最好节点
	ASNode2D* m_curBestNode;

	///<堆栈
	ASStack2D* m_stack;

public:

	///<是否有效格子的回调函数
	ASCallBackFuncValid m_isValidFunc;

	///<代价的回调函数
	ASCallBackFuncCost m_costFunc;
};
