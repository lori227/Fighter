
cd /data/deploy
./bin/kfdeploy app=deploy.agent id=12.0.1 log=1.0 service=0.0