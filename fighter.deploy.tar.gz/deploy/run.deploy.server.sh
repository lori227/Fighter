
cd /data/deploy
./bin/kfdeploy app=deploy.server id=11.0.1 log=1.0 service=0.0
